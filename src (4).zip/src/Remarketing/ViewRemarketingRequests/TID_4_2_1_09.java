package Remarketing.ViewRemarketingRequests;

import java.text.DateFormat;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.time.DateUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;
import tools.TotalView.RC_Remarketing;

public class TID_4_2_1_09 {
	
	
	public void VerifyViewRemarketingRequests_ManageSaleTab_ClientDirectedSale(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
        ArrayList<String> getWindows = new ArrayList<String>(driver.getWindowHandles());
        String displaymessage = "";
        String msg = "Saved Successfully";
        String TRS = "";
	    String VPT = "";
	    String VSD = "";
	    String TI = "";
	    String LI = "";
	    String comments = "";
	    String DA = "";
        String msg1 = "Successfully Updated!";
        String ColumnNames ="Date;Event;Created By";
        String alertmessage = "Proceeding with the cancellation will require the unit to go back on billing.  Are you sure you want to proceed with cancellation?";
        
        RC_Global.login(driver);
	    RC_Global.navigateTo(driver,"Remarketing","View Remarketing Requests", "");
	    RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Request Type", "Client Directed Sale", true);
	    RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Agreement Type", "Open End", true);
	    RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Sale Status", "Submitted", true);
	    RC_Global.clickButton(driver, "Search", false,true);
	    RC_Global.waitElementVisible(driver,30,"//tbody//tr[1]","Grid Row",true,false);
	    RC_Remarketing.selectRowWithSalesStatusFromGrid(driver, "Submitted", true); 
//	    RC_Global.waitUntilPanelVisibility(driver, "View Remarketing Requests", "TV", false);
	    RC_Global.waitElementVisible(driver, 30, "(//h5/span[contains(text(), 'View Remarketing Requests')])[2]", "View Remarketing Requests panel after clicking on 'Select Vehicle'", false, false);
	    RC_Global.panelAction(driver, "xpathclose", "(//h5[span[contains(text(), 'View Remarketing Requests')]])[1]", true, false);
	    Thread.sleep(1000);
	    RC_Global.panelAction(driver, "expand", "View Remarketing Requests", true, false);
	   
	    String Tab = "Sale Status;Manage Sale;Transportation;Condition Report;Title;Document Center;Request Summary";
	    RC_Remarketing.validateTabNames(driver, Tab, false);
	    RC_Global.clickUsingXpath(driver,"//a[text()='Manage Sale']", "Manage Sale",false,true);
	    RC_Remarketing.toggleOptionValues(driver, "Request Type", false);
	    
	    RC_Global.createNode(driver, "Validation of Sections for 'Client Directed Sale' type with 'Open End' agreement type");
	    TRS = driver.findElement(By.xpath("(//legend[text()='Termination Request Summary'])[1]")).getText();
	    VPT = driver.findElement(By.xpath("(//legend[text()='Vehicle Program Termination'])[1]")).getText();
	    VSD = driver.findElement(By.xpath("(//legend[text()='Vehicle Sales Details'])[1]")).getText();
	    TI = driver.findElement(By.xpath("(//legend[normalize-space(text()='Title Information')])[4]")).getText();
	    String BuyerInformation = driver.findElement(By.xpath("(//div/legend[normalize-space(text()='Buyer Information')])[5]")).getText();
	    String MailingInformation = driver.findElement(By.xpath("(//div/legend[normalize-space(text()='Mailing Information')])[6]")).getText();
	    LI = driver.findElement(By.xpath("(//div/legend[normalize-space(text()='Lienholder Information')])[7]")).getText();
	    comments = driver.findElement(By.xpath("(//div/label[text()='Comments:'])[1]")).getText();
	    DA = driver.findElement(By.xpath("(//legend[text()='Disclosure Agreement'])[1]")).getText();
	    if(TRS.equalsIgnoreCase("Termination Request Summary"))
	    {
	    	queryObjects.logStatus(driver, Status.INFO, "Termination Request Summary section is ", "Displayed", null);
	    }

	    if(VPT.equalsIgnoreCase("Vehicle Program Termination"))
	    {
	    	queryObjects.logStatus(driver, Status.INFO, "Vehicle Program Termination section is ", "Displayed", null);
	    }
	    if(VSD.equalsIgnoreCase("Vehicle Sales Details"))
	    {
	    	queryObjects.logStatus(driver, Status.INFO, "Vehicle Sales Details section is ", "Displayed", null);
	    }
	    if(TI.contains("Title Information"))
	    {
	    	queryObjects.logStatus(driver, Status.INFO, "Title Information section is ", "Displayed", null);
		    if(BuyerInformation.equalsIgnoreCase("Buyer Information"))
		    {
		    	queryObjects.logStatus(driver, Status.INFO, "Under Title Information section Buyer Information is ", "Displayed ", null);
		    }
		    if(MailingInformation.equalsIgnoreCase("Mailing Information"))
		    {
		    	queryObjects.logStatus(driver, Status.INFO, "Under Title Information section Mailing Information is ", "Displayed ", null);
		    }
		    
	    }
	    if(LI.equalsIgnoreCase("Lienholder Information"))
	    {
	    	queryObjects.logStatus(driver, Status.INFO, "Lienholder Information section is ", "Displayed", null);
	    }
	    if(comments.contains("Comments"))
	    {
	    	queryObjects.logStatus(driver, Status.INFO, "comments section is ", "Displayed", null);
	    }
	    if(DA.equalsIgnoreCase("Disclosure Agreement"))
	    {
	    	queryObjects.logStatus(driver, Status.INFO, "Disclosure Agreement section is ", "Displayed", null);
	    }

	    RC_Global.createNode(driver, "Button status validation");
	    RC_Global.buttonStatusValidation(driver, "Open", "Enable", false);
	    RC_Global.buttonStatusValidation(driver, "Email", "Enable", false);
	    RC_Global.buttonStatusValidation(driver, "Print", "Enable", false);
	
	    RC_Global.clickUsingXpath(driver, "(//button[text()='Open'])[2]", "Open button", false,true);
	    Thread.sleep(2000);
	    driver.switchTo().window(getWindows.get(0));
	    Thread.sleep(1000);
	    RC_Global.clickUsingXpath(driver, "(//button[text()='Email'])[2]", "Email button", false,true);
	    RC_Global.waitElementVisible(driver, 60, "//h3[text()='Request Summary Message']", "Email Documents",false, true);
	    Thread.sleep(1000);
	    RC_Global.clickUsingXpath(driver, "(//button[normalize-space(text()='Cancel')])[2]", "Cancel button", false, false);
	    Thread.sleep(1000);
	    
		WebElement element = driver.findElement(By.xpath("(//input[contains(@ng-model,'BuyerVehicleTerminationContact') and @placeholder='First Name'])[1]"));
		String input = "Charles";
		RC_Global.enterInput(driver, input, element , false, false);
		RC_Global.clickUsingXpath(driver, "(//button[contains(@ng-click,'save')])[1]", "Save button", false,true);
		//if(driver.findElements(By.xpath("//h3[span[normalize-space(span=' address entered.')]]")).size()>0)
		//{
		//	RC_Global.clickUsingXpath(driver, "//button[text()='Select Recommended Address']", "Select Recommended Address button", false,true);
		//	RC_Global.clickUsingXpath(driver, "(//button[contains(@ng-click,'save')])[1]", "Save button", false,true);
		//} 
		//else {
		//	 RC_Global.verifyDisplayedMessage(driver, msg,true); 
		//}
		Thread.sleep(3000);
		 if((driver.findElements(By.xpath("//span[text()=' address entered.']")).size()>0))
		 {
		 RC_Global.clickButton(driver, "Save As Entered", true, false);
		 Thread.sleep(4000);}
		 RC_Global.verifyDisplayedMessage(driver, msg,true);
		 
	     RC_Global.clickUsingXpath(driver,"//div[2]/button[text()='History']", "History",false,true);
		 RC_Global.waitUntilPanelVisibility(driver, "Client Directed Sale - History", "TV", false,true);
		 RC_Global.panelAction(driver, "expand", "Client Directed Sale - History", false, false);
		 
		 RC_Global.createNode(driver,"Validate section : Client Directed Sale - History");
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Client Directed Sale - History", "Unit Number:", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Client Directed Sale - History", "Vehicle Description:", false);
	     RC_Remarketing.screenSectionDetailsValidation(driver, "Client Directed Sale - History", "Plate Number:", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Client Directed Sale - History", "VIN:", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Client Directed Sale - History", "Vehicle Status:", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Client Directed Sale - History", "Plate State:", false);
	     RC_Remarketing.screenSectionDetailsValidation(driver, "Client Directed Sale - History", "Customer Vehicle Number:", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Client Directed Sale - History", "Agreement Type:", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Client Directed Sale - History", "Plate Expiration:", false);
	     
		 RC_Global.createNode(driver,"History Column Names validation");
		 RC_Remarketing.verifyHistoryGridColumns(driver, ColumnNames, false);
		 
		 RC_Global.clickButton(driver, "Expand All", false,true);
		 RC_Global.clickButton(driver, "Collapse All", false,true);
		
		RC_Global.createNode(driver,"History Updated value validation");
		Format f = new SimpleDateFormat("MM/dd/yyyy");
		String Date = f.format(new Date());
		 String createddate = driver.findElement(By.xpath("(//div[contains(@ng-repeat,'renderedColumns') and @role='gridcell']/div/span)[1]")).getText();
		 //String username = driver.findElement(By.xpath("//a/span//span[@id='Span1']")).getText();
		 String createdBy = driver.findElement(By.xpath("(//div[3][contains(@ng-repeat,'renderedColumns') and @role='gridcell']/div)[4]")).getText();
		 Thread.sleep(1000);
		 if(createdBy.toUpperCase().contains(RC_Global.userLogged)) 
		 {
//			 Calendar cal = Calendar.getInstance();
//			 DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
//			 cal.add(Calendar.DATE, -1);
//			 if(createddate.equals(dateFormat.format(cal.getTime())))
			 if(createddate.equals(Date))
			 {
				queryObjects.logStatus(driver, Status.INFO, "History updated with "+createddate+" ",createdBy , null);
			 }
			 else {
				 queryObjects.logStatus(driver, Status.WARNING, "History is not updated", "" , null);
			 }
		 }
		 
	
		 RC_Global.clickUsingXpath(driver, "(//div[span[text()='Edit Manage Sales Tab']])[1]", "Edit Manage Sales Tab hyperlink", false,true);
		 String Original = driver.findElement(By.xpath("(//div[4][contains(@ng-repeat,'renderedColumns') and @role='gridcell']/div)[2]")).getText();
		 String Updated = driver.findElement(By.xpath("(//div[4][contains(@ng-repeat,'renderedColumns') and @role='gridcell']/div)[3]")).getText();
				 
		 if(input.equalsIgnoreCase(Updated))
		 {
			 queryObjects.logStatus(driver, Status.INFO, "Orignal data----> "+Original+" and Updated data",Updated , null);
		 }
		 
		 RC_Global.downloadAndVerifyFileDownloaded(driver, "Export", "Export to Excel Functionality",false);
		 RC_Global.panelAction(driver, "close", "Client Directed Sale - History", false, false);
		 RC_Global.waitUntilPanelVisibility(driver, "View Remarketing Requests", "TV", false,true);
		 RC_Global.panelAction(driver, "expand", "View Remarketing Requests", false, false);
		 RC_Global.clickUsingXpath(driver, "(//button[contains(@ng-click,'cancelRemarketingRequest')])[2]", "CancelRemarketingRequest button", false,true);
		 if(driver.findElements(By.xpath("//h3[text()='Confirm']")).size()>0){
	    	 RC_Global.verifyDisplayedMessage(driver,alertmessage,false);
	    	 RC_Global.clickUsingXpath(driver, "(//button[normalize-space(text()='OK')])[1]", "Ok button", false, false);
	    	 Thread.sleep(2000);
	        }
		 
		 RC_Global.verifyDisplayedMessage(driver, msg1,false); 
		 
	     RC_Global.panelAction(driver, "close", "View Remarketing Requests", false, false);
	    
	     RC_Global.navigateTo(driver,"Remarketing","View Remarketing Requests", "");
	     
	     WebElement element1 = driver.findElement(By.xpath("//input[@placeholder='Unit Number']"));
	     RC_Global.enterInput(driver, RC_Remarketing.unitnumber, element1 , true,true);
	     RC_Global.clickButton(driver, "Search", false,true);
	     RC_Global.waitElementVisible(driver,60,"//tbody//tr[1]","Grid Row",true, false);
	     Thread.sleep(4000);
	     if (driver.findElements(By.xpath("//tbody//tr")).size()>1) {
	    	 RC_Global.clickUsingXpath(driver, "(//tbody//tr)[1]/td[2]", "Selecting a record from multiple records for the unit number search", false,true);
	    	 Thread.sleep(1000);
	    	 RC_Global.clickButton(driver, "Select Vehicle",true,true);
	 		RC_Manage.waitUntilMethods(driver, "(//button[text()='Select Vehicle '])[1]/div[@ng-show='vm.isSelectingTermination']","class","ng-hide", "attribute visible");
	     }
	     RC_Manage.waitUntilMethods(driver, "(//h5[span[text()='View Remarketing Requests']])[2]","","", "visible");
	     RC_Global.panelAction(driver, "xpathclose", "(//h5/span[contains(text(), 'View Remarketing Requests')])[1]/..", false, false);
	     RC_Global.panelAction(driver, "expand", "View Remarketing Requests", false, false);
	     RC_Global.buttonStatusValidation(driver, "cancelRemarketingRequest ", "Disable",false);
	     RC_Global.buttonStatusValidation(driver, "Save", "Disable",false);
	     if(driver.findElements(By.xpath("//div[span[text()='"+Date+"']]")).size()>0) {
	    	 queryObjects.logStatus(driver, Status.INFO, "Sale Status Last Updated as Today's date ",Date , null);
	     }
	     if(driver.findElements(By.xpath("//div[span[text()='Canceled']]")).size()>0) {
	    	 String Canceled = driver.findElement(By.xpath("//div[label[text()='Current Sale Status']]/../div/span")).getText();
	    	 queryObjects.logStatus(driver, Status.INFO, "Current Sale Status Updated as ",Canceled , null);
	     }
	     
	     RC_Global.panelAction(driver, "close", "View Remarketing Requests", true,true);
	     
	     queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}
}