package Remarketing.ViewRemarketingRequests;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;
import tools.TotalView.RC_Remarketing;

public class TID_4_2_1_10 {
	public void MTS_RemarketingDocumentCenterInternalser(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		String DocumentType = "All;3rd Party Inspection Report;Affidavit;Auction Sale Docs;Bill of Sale;Billing Termination Form;Carfax;Checks and Wires;Condition Report;Disposition;GDP Work Order;Odometer and Damage Disclosure;Payoff Approval Form;POA - Title;Power of Attorney;Title";
		String GridColumn ="Document Type;Description;Date Added;Added By;Preview Document Image;Select";
		String ValidationMsg1 = "\"Document Type\" is a required field.";
		String ValidationMsg2 = "\"Document File\" is a required field.";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Remarketing", "View Remarketing Requests", "");
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "",true);
		RC_Global.clickButton(driver, "Search",true,true);
		RC_Global.waitElementVisible(driver,30,"//tbody//tr[1]","Grid Row",true, false);
		RC_Global.clickUsingXpath(driver, "//tbody//tr[1]/td[1]", "Select Grid Row", true, false);
		RC_Global.clickButton(driver, "Select Vehicle", true,true);
		RC_Manage.waitUntilMethods(driver, "(//button[text()='Select Vehicle '])[1]/div[@ng-show='vm.isSelectingTermination']","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 30, "(//h5[span[text()='View Remarketing Requests']])[2]", "View Remarketing Requests", true, false);
		RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='View Remarketing Requests']])[1]", true, false);
		RC_Global.panelAction(driver, "expand", "View Remarketing Requests", true, false);
		
		RC_Global.clickUsingXpath(driver, "//a[text()='Document Center']", "Document Center Tab", true,true);
		RC_Global.dropdownValuesValidation(driver,DocumentType,"(//select[contains(@id,'docTypeSelect')])[2]",false,true);
		
		RC_Global.createNode(driver, "Document Tab Column Name Validation");
		if(driver.findElements(By.xpath("//div//div//span[normalize-space(text())='Document Type']")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Column Name Document Type is", "Present", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Column Name Document Type is", "Not Present", null);

		if(driver.findElements(By.xpath("//div//div//span[normalize-space(text())='Description']")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Column Name Description is", "Present", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Column Name Description is", "Not Present", null);
		
		if(driver.findElements(By.xpath("//div//div//span[normalize-space(text())='Date Added']")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Column Name Date Added is", "Present", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Column Name Date Added is", "Not Present", null);

		
		if(driver.findElements(By.xpath("(//div//div//span[normalize-space(text())='Added By'])[2]")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Column Name Added By is", "Present", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Column Name Added By is", "Not Present", null);
		
		if(driver.findElements(By.xpath("//div//div//span[normalize-space(text())='Preview Document Image']")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Column Name Preview Document Image is", "Present", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Column Name Preview Document Image is", "Not Present", null);
		
		if(driver.findElements(By.xpath("(//div//div//span[normalize-space(text())='Select'])[2]")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Column Name Select is", "Present", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Column Name  Select is", "Not Present", null);
		
		
		
		RC_Global.clickButton(driver, "Upload Document", true,true);
		RC_Global.createNode(driver, "Upload Document Section Validation");
		if(driver.findElements(By.xpath("//div//h3[contains(text(),' Upload Document')]")).size()>0)
			 queryObjects.logStatus(driver, Status.PASS, "Upload Document header", "is found", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Upload Document header", "is not found", null);
		
		String UploadDocHeader = driver.findElement(By.xpath("//div//h3[contains(text(),'Upload Document')]/following::b//i")).getText();
		if(UploadDocHeader.length()>0)
			 queryObjects.logStatus(driver, Status.PASS, UploadDocHeader, " header text found", null);
		else
			 queryObjects.logStatus(driver, Status.FAIL, UploadDocHeader, " header text not found", null);
		String UploadDocmentLabel1=driver.findElement(By.xpath("(//label[contains(@for,'docTypeSelect')])[3]")).getText();
		String UploadDocmentLabel2=driver.findElement(By.xpath("(//label[contains(@for,'docFile')])[2]")).getText();
		String UploadDocmentLabel3=driver.findElement(By.xpath("(//label[contains(@for,'docDate')])[2]")).getText();
		String UploadDocmentLabel4=driver.findElement(By.xpath("(//label[contains(@for,'docDescription')])[2]")).getText();
		
		if(UploadDocmentLabel1.length()>0)
			 queryObjects.logStatus(driver, Status.PASS, UploadDocmentLabel1, " label found", null);
		else
			 queryObjects.logStatus(driver, Status.FAIL, UploadDocmentLabel1, " label not found", null);
		
		
		if(UploadDocmentLabel2.length()>0)
			 queryObjects.logStatus(driver, Status.PASS, UploadDocmentLabel2, " label found", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, UploadDocmentLabel2, " label not found", null);
		
		if(UploadDocmentLabel3.length()>0)
			 queryObjects.logStatus(driver, Status.PASS, UploadDocmentLabel3, " label found", null);
		else
			 queryObjects.logStatus(driver, Status.FAIL, UploadDocmentLabel3, " label not found", null);
		
		if(UploadDocmentLabel4.length()>0)
			 queryObjects.logStatus(driver, Status.PASS, UploadDocmentLabel4, " label found", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, UploadDocmentLabel4, " label not found", null);
		
		 RC_Global.buttonStatusValidation(driver,"Save","Enable",true);
		 RC_Global.buttonStatusValidation(driver,"Cancel","Enable",true);
		 
		 RC_Global.clickUsingXpath(driver, "(//button[contains(text(),'Save')])[8]", "Save Button", true,true);
		RC_Global.verifyDisplayedMessage(driver,ValidationMsg1,true);
		RC_Global.verifyDisplayedMessage(driver,ValidationMsg2,true);
		if(driver.findElements(By.xpath("(//select[@id='docTypeSelect'])[3]")).size()>0)
			 driver.findElement(By.xpath("(//select[@id='docTypeSelect'])[3]")).click();
			 driver.findElement(By.xpath("(//select[@id='docTypeSelect'])[3]/option[text()='Affidavit']")).click();
			 
		String DocumentTypeSelected =  driver.findElement(By.xpath("(//select[@id='docTypeSelect'])[3]")).getText();
		if(DocumentTypeSelected.length()>0)
			 queryObjects.logStatus(driver, Status.PASS, "Selected Document Type", DocumentTypeSelected, null);
		
		String UploadedDocumentDate =  driver.findElement(By.xpath("(//input[@id='documentDateField'])[2]")).getText();
		
		if(UploadedDocumentDate.length()>0)
			 queryObjects.logStatus(driver, Status.PASS, "Selected Document Type", UploadedDocumentDate, null);
		
		WebElement DocumentUpload= driver.findElement(By.xpath("(//input[@file-data='fileInput'])[2]"));
		String UploadfileName="Sample_Invoiceupdate.xlsx";
        DocumentUpload.sendKeys(String.valueOf(String.valueOf(String.valueOf(System.getProperty("user.dir")))) + File.separator +"Uploadfiles\\"+UploadfileName+"");
        WebElement DocDes = driver.findElement(By.xpath("(//input[@id='docDescription'])[2]"));
        RC_Global.enterInput(driver, "Document Description",DocDes,true,true);
		RC_Global.clickUsingXpath(driver, "(//button[contains(text(),'Save')])[8]", "Save Button", true,true);
		Thread.sleep(6000);
	//	RC_Global.waitElementVisible(driver, 30, "(//h4[text()='Document Upload Successful'])[1]", "Document Upload Successful", true);
		RC_Global.clickUsingXpath(driver, "//div[contains(@class,'document-preview-container')]//img","Preview Image",true,true);
		
		RC_Global.verifySortFunction(driver, "Document Type",true);
		RC_Global.verifySortFunction(driver, "Description",true);
		RC_Global.verifySortFunction(driver, "Date Added",true);
		
		driver.findElement(By.xpath("//div//input[contains(@type,'checkbox')]")).click();
		String winHandleBefore = driver.getWindowHandle();
		RC_Global.clickButton(driver, "Open", true,true);
		Thread.sleep(2000);
		driver.switchTo().window(winHandleBefore);
		winHandleBefore = driver.getWindowHandle();
		RC_Global.clickButton(driver, "Email", true,true);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}
}
