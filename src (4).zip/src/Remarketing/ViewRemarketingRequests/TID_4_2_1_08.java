package Remarketing.ViewRemarketingRequests;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Remarketing;

public class TID_4_2_1_08 {
	public void MTS_TerminateServiceOnly_TitleTab_InternalUser(WebDriver driver, BFrameworkQueryObjects queryObjects)throws Exception
	{
		String menu = "Remarketing";
		String firstSubMenu = "View Remarketing Requests";
		String ShippingDetailsMessage ="Please select additional secured vehicle whose Titles are to be shipped to the same Auction Vendor";
		String AdditionalShipping ="Are additional titles being shipped? *";
		String[] ColumnNames = {"Unit Number","Current Sales Status","Vendor","Select"};
		boolean flag = false;
		String UploadTitleMessageDis = "Please select document type, document date, description and choose file to upload.";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,"");
		RC_Global.enterCustomerNumber(driver, "LS007656", "", "", true);
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver,"Sale Status","Secured", true);
		RC_Global.clickButton(driver, "Search",true,true);
		RC_Global.waitElementVisible(driver,30,"//tbody//tr[1]","Grid Row",true, false);
		RC_Global.clickUsingXpath(driver, "//tbody//tr[1]", "Select record which has sales status as Secure", true, false);
		RC_Global.clickUsingXpath(driver, "(//button[text()='Select Vehicle '])[1]", "Select Vehicle", true,true);
//		RC_Global.waitElementVisible(driver, 30,"//h3[text()='Sale Status']", "Sale Status Tab", true,false);
		RC_Global.waitElementVisible(driver, 30, "(//h5[span[text()='View Remarketing Requests']])[2]", "View Remarketing Requests", false, false);
		RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='View Remarketing Requests']])[1]", false, false);
		Thread.sleep(2000);
		//	RC_Global.panelAction(driver, "expand", "View Remarketing Requests", true, false);
		RC_Global.clickUsingXpath(driver, "(//h5[span[text()='View Remarketing Requests']]/i[contains(@class,'fa-expand') and @ng-click='maximize(panel)'])[1]", "Expand the View Remarketing Tab", false,true);
		RC_Global.clickUsingXpath(driver, "//a[text()='Title']", "Title Tab", true,true);
		
		List<WebElement> UploadTitle = driver.findElements(By.xpath("//button[text()='Upload Title']"));
		List<WebElement> RequestTitle = driver.findElements(By.xpath("//button[text()='Request Title']"));
		if(UploadTitle.size()==1 && RequestTitle.size()==1 )
			queryObjects.logStatus(driver, Status.PASS, "Upload Title and Request Title Buttons are displaying in Title Tab", "Displayed", null);
		else
		{
			BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Upload Title and Request Title Buttons are not displaying in Title Tab", "Not Displayed", null);
			RC_Global.endTestRun(driver);
		}
		//Validate 'Title Information' feature box  
		RC_Global.verifyScreenComponents(driver, "lable", "Title Requested: ", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Title Sent: ", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Tracking No: ", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Title Received: ", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Title Status: ", false);
		
		
		RC_Global.clickButton(driver, "Request Title", true,true);
		RC_Global.verifyDisplayedMessage(driver, "Title Requested Successfully", true);
		String TitleRequested = driver.findElement(By.xpath("//label[text()='Title Requested: ']/following::span")).getText();
		String SystemDate = (new SimpleDateFormat("MM/dd/yyyy")).format(new Date());
		if(!TitleRequested.contains(SystemDate))
			queryObjects.logStatus(driver, Status.PASS, "Title Requested Date Displaying Correctly as", ""+TitleRequested, null);
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Title Requested Date Displaying Incorrect", "Failed", null);
			RC_Global.endTestRun(driver);
		}
		String ShippingDetailsMes = driver.findElement(By.xpath("//p[contains(text(),'additional secured vehicle whose Titles')]")).getText();
		String AdditionalLabel = driver.findElement(By.xpath("//label[contains(text(),'additional titles')]")).getText();
		
		if(ShippingDetailsMes.equalsIgnoreCase(ShippingDetailsMes))
			queryObjects.logStatus(driver, Status.PASS, "Shipping Details Message Displaying Correctly as", ""+ShippingDetailsMes, null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Shipping Details Message Displaying Incorrect", "Failed", null);
		
		if(AdditionalLabel.equalsIgnoreCase(AdditionalShipping))
			queryObjects.logStatus(driver, Status.PASS, "Additional Label Message Displaying Correctly as", ""+AdditionalLabel, null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Additional Label Message Displaying Incorrect", "Failed", null);
		
		List<WebElement> ShippingLabelYesBttn = driver.findElements(By.xpath("//label[text()='Yes' and @ng-model='vm.additionalTitle']"));
		List<WebElement> ShippingLabelNoBttn = driver.findElements(By.xpath("//label[text()='No' and @ng-model='vm.additionalTitle']"));
		
		if(ShippingLabelYesBttn.size()==1 && ShippingLabelNoBttn.size()==1 )
			queryObjects.logStatus(driver, Status.PASS, "ShippingLabel Yes and No Button", "Displayed", null);
		else
		{
			BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "ShippingLabel Yes and No Button", "Not Displayed", null);
			RC_Global.endTestRun(driver);
		}
		for(int i=0; i<ColumnNames.length; i++) {
			String ColumnName = driver.findElement(By.xpath("//div[@role='button']//span[text()='"+ColumnNames[i]+"']")).getText();
			if(ColumnName.equalsIgnoreCase(ColumnNames[i]))
			{ flag = true;}		
		}
		if(flag)
			   queryObjects.logStatus(driver, Status.PASS, "Column Names Validation", "Column Names are verified", null);
		else
			   queryObjects.logStatus(driver, Status.FAIL, "Column Names Validation", "Column Names Validation Failed", null);
		//24- pending
		//25 -- upload Button
		RC_Global.clickButton(driver,"Upload Title", true,true);
		String UploadTitleBox = driver.findElement(By.xpath("//h3[text()=' Upload Title']")).getText();
		String UploadTitleMessage = driver.findElement(By.xpath("(//i[contains(text(),'Please select document type')])[1]")).getText();
		if(UploadTitleBox.equalsIgnoreCase("Upload Title"))
			queryObjects.logStatus(driver, Status.PASS, "Upload Document header", "is found", null);	
		else
		{
		queryObjects.logStatus(driver, Status.FAIL, "Upload Document header", "is not found", null);
		RC_Global.endTestRun(driver);
		}
		if(UploadTitleMessage.equalsIgnoreCase(UploadTitleMessageDis))
			 queryObjects.logStatus(driver, Status.PASS, UploadTitleMessage, " header text found", null);
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, UploadTitleMessage, " header text not found", null);
			RC_Global.endTestRun(driver);
		}
		
		RC_Global.verifyScreenComponents(driver, "lable", "Document Type ", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Document File ", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Document Date ", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Description", false);
		String DefaultDocType = driver.findElement(By.xpath("//select//option[@label='Title' and @selected]")).getText();
		if(DefaultDocType.equalsIgnoreCase("Title"))
			queryObjects.logStatus(driver, Status.PASS, "Default Document Type selected is", ""+DefaultDocType, null);
		else
		{
			BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Default Document Type selected is", "Not correct", null);
			RC_Global.endTestRun(driver);
		}
		RC_Global.buttonStatusValidation(driver, "Save", "Enable", false);
		RC_Global.buttonStatusValidation(driver, "Cancel", "Enable", false);
		//32
		RC_Global.clickUsingXpath(driver, "(//button[contains(text(),'Save')])[7]", "Save Button", true,true);
		RC_Global.waitElementVisible(driver, 30, "//h4[contains(text(),'is a required field.')]", "", false, false);
		
		String ErrorMesDoc = driver.findElement(By.xpath("//h4[contains(text(),'is a required field.')]")).getText();
		if(ErrorMesDoc.contains("is a required field."))
			queryObjects.logStatus(driver, Status.PASS, "Error Message Displayed is correct", ""+ErrorMesDoc, null);
		else
		{
			BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Error Message Displayed is Incorrect", "", null);
			RC_Global.endTestRun(driver);
		}
		WebElement DocumentUpload= driver.findElement(By.xpath("(//input[contains(@type,'file')])[1]"));
		String UploadfileName="Sample_Invoiceupdate.xlsx";
        DocumentUpload.sendKeys(String.valueOf(String.valueOf(String.valueOf(System.getProperty("user.dir")))) + File.separator +"Uploadfiles\\"+UploadfileName+"");
		WebElement Description = driver.findElement(By.xpath("(//input[@id='docDescription'])[1]"));
		RC_Global.enterInput(driver, "Upload Document",Description, false,true);	
		RC_Global.clickUsingXpath(driver, "(//button[contains(text(),'Save')])[7]", "Save Button", true,true);
		try {
			RC_Global.waitElementVisible(driver, 30, "//h4[contains(text(),'Document Upload Successful')]","Document Upload Successful", false, false);
			RC_Global.verifyDisplayedMessage(driver, "Document Upload Successful", false);
		}catch (Exception e) {
			RC_Global.waitElementVisible(driver, 30, "//h4[contains(text(),'Upload Title Failed. Please try again in a moment')]","Document upload error message", false, false);
			RC_Global.verifyDisplayedMessage(driver, "Upload Title Failed. Please try again in a moment", false);
		}
		RC_Global.clickUsingXpath(driver, "(//button[text()='History'])[5]", "History Link", true, true);
		RC_Global.waitElementVisible(driver, 30, "(//h5//span[1])[1]","History Page", false, false);
//		RC_Global.waitElementVisible(driver, 30, "//button[text()='Expand All']","History Page", false, false);
		RC_Global.panelAction(driver, "close","View Remarketing Requests", true, false);
	//	String panelName = driver.findElement(By.xpath("(//h5//span[1])[1]")).getText();
		RC_Global.panelAction(driver, "expand","Merchants to Sell and Terminate Services Only - History", true, false);
				
		RC_Global.verifyScreenComponents(driver, "labelValue", "Unit Number:", false);
		RC_Global.verifyScreenComponents(driver, "labelValue", "Vehicle Description:", false);
		RC_Global.verifyScreenComponents(driver, "labelValue", "Plate Number:", false);
		RC_Global.verifyScreenComponents(driver, "labelValue", "VIN:", false);
		RC_Global.verifyScreenComponents(driver, "labelValue", "Vehicle Status:", false);
		RC_Global.verifyScreenComponents(driver, "labelValue", "Plate State:", false);
		RC_Global.verifyScreenComponents(driver, "labelValue", "Customer Vehicle Number:", false);
		RC_Global.verifyScreenComponents(driver, "labelValue", "Agreement Type:", false);
		RC_Global.verifyScreenComponents(driver, "labelValue", "Plate Expiration:", false);
		
		RC_Remarketing.verifyHistoryGridColumns(driver, "Date;Event;Created By", false);
		RC_Global.buttonStatusValidation(driver, "Expand All", "Enable", true);
		String HisClmn1 = driver.findElement(By.xpath("//span[text()='Date']")).getText();
		String HisClmn2 = driver.findElement(By.xpath("//span[text()='Event']")).getText();
		String HisClmn3 = driver.findElement(By.xpath("//span[text()='Created By']")).getText();
		if(HisClmn1.equalsIgnoreCase("Date") && HisClmn2.equalsIgnoreCase("Event") && HisClmn3.equalsIgnoreCase("Created By"))
			queryObjects.logStatus(driver, Status.PASS, "History Page Column validation is", "Successfully", null);
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "History Page Column validation", "Failed", null);
			RC_Global.endTestRun(driver);
		}	
		RC_Global.clickButton(driver, "Expand All", true,false);
		String createdByName = driver.findElement(By.xpath("//span[@id='user-menu-name']/preceding-sibling::span")).getText();
		
		if(driver.findElement(By.xpath("(//div[@role='rowgroup'][2]//div[@role='row']/div[1])[1]")).getText().equalsIgnoreCase(RC_Global.getDateTime(driver, "MM/dd/yyyy", 0, false))) {
			queryObjects.logStatus(driver, Status.INFO, "Verifying the Created Date", "Successful", null);
			if(driver.findElement(By.xpath("(//div[@role='rowgroup'][2]//div[@role='row']/div[3])[1]")).getText().toUpperCase().contains(RC_Global.userLogged))
				queryObjects.logStatus(driver, Status.INFO, "Verifying the Created By --- "+RC_Global.userLogged, "Successful", null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verifying the Created By --- "+RC_Global.userLogged, "The Created By is not the same as "+RC_Global.userLogged, null);
		} else
			queryObjects.logStatus(driver, Status.FAIL, "Verifying the Created Date", "The create date is not today's date", null);
				
	/*	if(driver.findElement(By.xpath("(//div[@role='rowgroup'][2]//div[@role='row']/div[2])[1]")).getText().equalsIgnoreCase("Submit a Cancellation"))
			queryObjects.logStatus(driver, Status.INFO, "Verifying the event --- 'Submit a Cancellation'", "Successful", null);
		else 
			queryObjects.logStatus(driver, Status.FAIL, "Verifying the event --- 'Submit a Cancellation'", "The event is not as expected", null);
		*/
	
		
		RC_Global.buttonStatusValidation(driver,"Collapse All", "Enable", true);

		List<WebElement> First = driver.findElements(By.xpath("//a[text()='First']"));
		List<WebElement> Previous = driver.findElements(By.xpath("//a[text()='Previous']"));
		List<WebElement> Next = driver.findElements(By.xpath("//a[text()='Next']"));
		List<WebElement> Last = driver.findElements(By.xpath("//a[text()='Last']"));
		if(First.size()>0 &&Previous.size()>0 &&Next.size()>0 &&Last.size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Pagination is present at the bottom of page", "Displayed", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Pagination is present at the bottom of page", "Not displayed", null);
		   
		  
		RC_Global.downloadAndVerifyFileDownloaded(driver, "Export", "Event History", true);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
		
	}	
}
