package Remarketing.ViewRemarketingRequests;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Billing;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Remarketing;

public class TID_4_2_1_07 {
	public void VerifyViewRemarketingRequests_ManageSaleTab_MerchantsToSell(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		String menu = "Remarketing";
        String firstSubMenu = "View Remarketing Requests";
        ArrayList<String> getWindows = new ArrayList<String>(driver.getWindowHandles());
        String TRS= "";
        String VPT= "";
        String VPLC= "";
        String CV= "";
        String DA= "";
        String[] GridColumn={"Vendor Name;Rating;Distance;Address;City;State;Zip;AutoIMS Auction;Auction Run Day"};
        
        RC_Global.login(driver);
	    RC_Global.navigateTo(driver,menu,firstSubMenu, "");
	    RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Request Type", "Merchants to Sell", true);
	    RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Sale Status", "Title Received", true);
	    RC_Global.clickButton(driver, "Search", false,true);
	    RC_Global.waitElementVisible(driver,30,"//tbody//tr[1]","Grid Row",true, false);
	    RC_Remarketing.selectRowWithSalesStatusFromGrid(driver, "Title Received", true);
		RC_Global.waitElementVisible(driver, 30,"//h3[text()='Sale Status']", "Sale Status Tab", true, false);
	    RC_Global.clickUsingXpath(driver, "(//h5[span[text()='View Remarketing Requests']]/i[@ng-click='closePanel()'])[1]", "Close View Remarketing Search Page", true, false);
		RC_Global.panelAction(driver, "expand", "View Remarketing Requests", true, false);

	    if(driver.findElements(By.xpath("//a[contains(text(),'Sale Status')]")).size()>0)
	    	queryObjects.logStatus(driver, Status.INFO, "Sale Status tab is ", "displayed", null);
	    else
	    	queryObjects.logStatus(driver, Status.INFO, "Sale Status tab is ", "Not displayed", null);
	    
	    if(driver.findElements(By.xpath("//a[contains(text(),'Manage Sale')]")).size()>0)
	    	queryObjects.logStatus(driver, Status.INFO, "Manage Sale tab is ", "displayed", null);
	    else
	    	queryObjects.logStatus(driver, Status.INFO, "Manage Sale tab is ", "Not displayed", null);
	    
	    
	    if(driver.findElements(By.xpath("//a[contains(text(),'Transportation')]")).size()>0)
	    	queryObjects.logStatus(driver, Status.INFO, "Transportation tab is ", "displayed", null);
	    else
	    	queryObjects.logStatus(driver, Status.INFO, "Transportation tab is ", "Not displayed", null);
	    
	    if(driver.findElements(By.xpath("//a[contains(text(),'Condition Report')]")).size()>0)
	    	queryObjects.logStatus(driver, Status.INFO, "Condition Report tab is ", "displayed", null);
	    else
	    	queryObjects.logStatus(driver, Status.FAIL, "Condition Report tab is ", "Not displayed", null);
	    
	    if(driver.findElements(By.xpath("//a[contains(text(),'Title')]")).size()>0)
	    	queryObjects.logStatus(driver, Status.PASS, "Title tab is ", "displayed", null);
	    else
	    	queryObjects.logStatus(driver, Status.FAIL, "Title tab is ", "Not displayed", null);
	    
	    if(driver.findElements(By.xpath("//a[contains(text(),'Document Center')]")).size()>0)
	    	queryObjects.logStatus(driver, Status.PASS, "Document Center tab is ", "displayed", null);
	    else
	    	queryObjects.logStatus(driver, Status.FAIL, "Document Center tab is ", "Not displayed", null);
	    
	    if(driver.findElements(By.xpath("//a[contains(text(),'Request Summary')]")).size()>0)
	    	queryObjects.logStatus(driver, Status.PASS, "Request Summary tab is ", "displayed", null);
	    else
	    	queryObjects.logStatus(driver, Status.FAIL, "Request Summary tab is ", "Not displayed", null);
	    
	    RC_Global.clickUsingXpath(driver,"//a[contains(text(),'Manage Sale')]", "Manage Sale",false,true);	  
	    RC_Remarketing.requesttypeToggleOption(driver, "Request Type", false);

	    TRS = driver.findElement(By.xpath("(//legend[text()='Termination Request Summary'])[1]")).getText();
	    VPT = driver.findElement(By.xpath("(//legend[text()='Vehicle Program Termination'])[1]")).getText();
	    VPLC = driver.findElement(By.xpath("(//legend[text()='Vehicle Pickup Location and Contact'])[2]")).getText();
	    CV = driver.findElement(By.xpath("//legend[contains(text(),'Consign Vehicle')]")).getText();
	    DA = driver.findElement(By.xpath("(//legend[text()='Disclosure Agreement'])[1]")).getText();
	    if(TRS.equalsIgnoreCase("Termination Request Summary"))
	     queryObjects.logStatus(driver, Status.PASS, "Termination Request Summary section is ", "Displayed", null);
	    else
	    	 queryObjects.logStatus(driver, Status.INFO, "Termination Request Summary section is not ", "Displayed", null);

	    if(VPT.equalsIgnoreCase("Vehicle Program Termination"))
	     queryObjects.logStatus(driver, Status.PASS, "Vehicle Program Termination section is ", "Displayed", null);
	    else
	     queryObjects.logStatus(driver, Status.INFO, "Vehicle Program Termination section is not ", "Displayed", null);
	    
	    
	    if(VPLC.equalsIgnoreCase("Vehicle Pickup Location and Contact"))
	    	queryObjects.logStatus(driver, Status.PASS, "Vehicle Pickup Location and Contact section is ", "Displayed", null);
	    else
	    	 queryObjects.logStatus(driver, Status.INFO, "Vehicle Pickup Location and Contact section is not ", "Displayed", null);
	    
	    if(CV.equalsIgnoreCase("Consign Vehicle"))
	     queryObjects.logStatus(driver, Status.PASS, "Consign Vehicle section is ", "Displayed", null);
	    else
	    	 queryObjects.logStatus(driver, Status.INFO, "Consign Vehicle section is not ", "Displayed", null);
	    
	    if(DA.equalsIgnoreCase("Disclosure Agreement"))
	     queryObjects.logStatus(driver, Status.PASS, "Disclosure Agreement section is ", "Displayed", null);
	    else
	     queryObjects.logStatus(driver, Status.INFO, "Disclosure Agreement is not ", "Displayed", null);
	    
	    
	    RC_Global.buttonStatusValidation(driver, "Cancel Remarketing Request ", "Enable",false);
	    
	    RC_Global.createNode(driver,"Validate section :Termination Request Summary");
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Termination Request Summary", "Request Submitted On: ", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Termination Request Summary", "Confirmation Number:", false);
	     RC_Remarketing.screenSectionDetailsValidation(driver, "Termination Request Summary", "Optional Driver Message Sent:", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Termination Request Summary", "Request Submitted By:", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Termination Request Summary", "Driver/Pool Name:", false);
		 
		 
		 RC_Global.createNode(driver,"Validate section :Vehicle Program Termination");
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Program Termination", "Is the Driver still an active Employee with the Company? ", false);
	     RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Program Termination", "Is Driver remaining enrolled in Fuel?", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Program Termination", "Is Driver remaining enrolled in Personal Use?", false);
		 
		 RC_Global.createNode(driver,"Validate section :Vehicle Pickup Location and Contact");
		 
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Pickup Location and Contact", "Default Contact & Location", false);
	     RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Pickup Location and Contact", "Pickup Location Type", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Pickup Location and Contact", "Business Name", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Pickup Location and Contact", "Address 1 ", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Pickup Location and Contact", "Address 2", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Pickup Location and Contact", "City", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Pickup Location and Contact", "State", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Pickup Location and Contact", "Zip Code", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Pickup Location and Contact", "Comments", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Pickup Location and Contact", "Pickup Contact First Name", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Pickup Location and Contact", "Pickup Contact Last Name", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Pickup Location and Contact", "Pickup Contact Email", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Pickup Location and Contact", "Pickup Contact Phone", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Pickup Location and Contact", "Secondary Vehicle Pickup Contact?", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Pickup Location and Contact", "Secondary Contact First Name", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Pickup Location and Contact", "Secondary Contact Last Name", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Pickup Location and Contact", "Secondary Email", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Pickup Location and Contact", "Secondary Phone", false);
		 
		 int fieldCount = driver.findElements(By.xpath("(//manage-sale//pickup-location-and-contact[1]//div[@class='panel-body'])[9]//div[@class='row top-padding']/div/div[@class='row access-row']/div[2]")).size();
		 if(driver.findElements(By.xpath("(//manage-sale//pickup-location-and-contact[1]//div[@class='panel-body'])[9]//div[@class='row top-padding']/div/div[@class='row access-row']/div[2]/*[@disabled='disabled']")).size()==(fieldCount-2))
			 queryObjects.logStatus(driver, Status.INFO, "Validating if all fields are disabled", "All fields are disabled", null);
		 else
			 queryObjects.logStatus(driver, Status.FAIL, "Validating if all fields are disabled", "One or more fields are not disabled", null);
		 
		 
		 RC_Global.createNode(driver,"Validate section :Consign Vehicle");
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Consign Vehicle", "Vendor Name:", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Consign Vehicle", "Vendor Address:", false);
	     RC_Remarketing.screenSectionDetailsValidation(driver, "Consign Vehicle", "City, State ZIP:", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Consign Vehicle", "Contact Name:", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Consign Vehicle", "Contact Email:", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Consign Vehicle", "Contact Phone:", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Consign Vehicle", "Drop off by", false);
	     RC_Remarketing.screenSectionDetailsValidation(driver, "Consign Vehicle", "Vendor Rating:", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Consign Vehicle", "Blanket POA on file:", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Consign Vehicle", "POA Expiration Date:", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Consign Vehicle", "AutoIMS Auction:", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Consign Vehicle", "Auction Run Day:", false);
		 
		 RC_Global.buttonStatusValidation(driver, "Vendor Search", "Enable",false);
		 RC_Global.clickButton(driver, "Vendor Search", false,true); 
		 RC_Global.waitUntilPanelVisibility(driver, "Consignment Search", "TV", false, true);
		 
		 RC_Global.panelAction(driver, "expand", "Consignment Search", false, true);
		 RC_Global.waitElementVisible(driver,60,"((//div[@role='rowgroup'])[14]//div[@role='row'])[1]","Vendor Search Results Grid",true, false);
		 
		 Thread.sleep(1000);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vendor Search", "Enter an Address, Zip Code, City, State to find a Vendor Near You", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vendor Search", "Within X Miles", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vendor Search", "Vendor Name", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vendor Search", "Vendor Name", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vendor Search", "Vendor Phone Number", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vendor Search", "Vendor Code", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vendor Search", "Vendor Rating", false);
		 
		 for(int itr=0;itr<GridColumn.length;itr++)
		 {
			 if(driver.findElements(By.xpath("//div//span[contains(text(),'"+GridColumn[0]+"')]")).size()>0)
				 queryObjects.logStatus(driver, Status.PASS, "Grid column"+GridColumn[0], " is displayed", null);
			 else
				 queryObjects.logStatus(driver, Status.INFO, "Grid column"+GridColumn[0], " is not displayed", null);
		 }

		 RC_Global.waitElementVisible(driver,30,"(//div[contains(@role,'gridcell')]//div[contains(text(),'Friday') or contains(text(),'Tuesday') or contains(text(),'Wednesday')or contains(text(),'Thursday')])[1]","Grid Row",true, false);
		 RC_Global.clickUsingXpath(driver, "(//div[contains(@role,'gridcell')]//div[contains(text(),'Friday') or contains(text(),'Tuesday') or contains(text(),'Wednesday')or contains(text(),'Thursday')])[1]","Grid Row",true, false);
		 RC_Global.clickButton(driver, "Select Vendor", true,true);
		 
		 if(driver.findElements(By.xpath("(//div//h4[contains(text(),'You must submit request to consigner prior to changing tabs.')])[2]")).size()>0)
			 queryObjects.logStatus(driver, Status.PASS, "You must submit request to consigner prior to changing tabs.", "Displayed", null);
		 else
			 queryObjects.logStatus(driver, Status.INFO, "You must submit request to consigner prior to changing tabs.", "Message is not Displayed", null);
		 RC_Global.panelAction(driver, "expand", "View Remarketing Requests", true, false);
		 RC_Global.clickButton(driver, "Submit Request to Consigner", true,true);

		 RC_Global.waitElementVisible(driver,30,"//div//h3[contains(text(),'Confirm')]","Popup Message",true,false);
		 RC_Global.clickButton(driver, "Submit", true,true);
		 Thread.sleep(3000);
		 RC_Global.waitElementVisible(driver, 30, "(//span[contains(text(),'Consigned')])[1]","Current sales Status change", true,true);
		 String CurrentSalesStatus = driver.findElement(By.xpath("(//span[contains(text(),'Consigned')])[1]")).getText(); 
		 if(CurrentSalesStatus.contains("Consigned"))
				queryObjects.logStatus(driver, Status.PASS, "The Current Status is ", CurrentSalesStatus, null);
		 else
				queryObjects.logStatus(driver, Status.FAIL, "The Current Status Displayed is Incorrect", CurrentSalesStatus, null);
		
		 queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
			
	}
}