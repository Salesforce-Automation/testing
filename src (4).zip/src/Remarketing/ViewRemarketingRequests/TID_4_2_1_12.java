package Remarketing.ViewRemarketingRequests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;
import tools.TotalView.RC_Remarketing;

public class TID_4_2_1_12 {
	public void ValidateTitleReceivedStatus(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		
		String menu = "Remarketing";
        String firstSubMenu = "View Remarketing Requests";
        
		RC_Global.login(driver);
	    RC_Global.navigateTo(driver,menu,firstSubMenu, "");
	    RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Sale Status", "Title Received", true);
	    RC_Global.clickButton(driver, "Search", false,true);
	    RC_Global.waitElementVisible(driver,30,"//tbody//tr[1]","Grid Row",true,false);
	    RC_Remarketing.selectRowWithSalesStatusFromGrid(driver, "Title Received", true);
	    RC_Manage.waitUntilMethods(driver, "(//h5[span[text()='View Remarketing Requests']])[2]","","", "visible");
	    RC_Global.clickUsingXpath(driver, "(//h5[span[text()='View Remarketing Requests']]/i[@ng-click='closePanel()'])[1]", "close", true, false);
	    RC_Global.waitUntilPanelVisibility(driver, "View Remarketing Requests", "TV", false,false);
	    RC_Global.panelAction(driver, "expand", "View Remarketing Requests", true,false);
	    RC_Global.waitElementVisible(driver, 30, "(//div/div[1]/button[contains(@ng-click,'vm.history()')])[1]", "History",false,false);
	    
	    String SaleStatus=driver.findElement(By.xpath("(//div/p/span)[1]")).getText();
	    queryObjects.logStatus(driver, Status.INFO, "sale status is updated to", SaleStatus, null);
	    Thread.sleep(1000);       	
	    
	    RC_Global.clickUsingXpath(driver,"//a[text()='Title']", "Title",false,true); 
	    RC_Global.waitElementVisible(driver, 30, "(//div/fieldset/div[3]/div[1])[5]", "Title Information",false,false);
	    
	    RC_Global.createNode(driver,"Validate section : Title Information");
	    RC_Remarketing.screenSectionDetailsValidation(driver, "Title Information", "Title Requested:", true);
	    RC_Remarketing.screenSectionDetailsValidation(driver, "Title Information", "Title Sent:", true);
	    RC_Remarketing.screenSectionDetailsValidation(driver, "Title Information", "Tracking No:", true);
	    RC_Remarketing.screenSectionDetailsValidation(driver, "Title Information", "Title Received:",true);
	    RC_Remarketing.screenSectionDetailsValidation(driver, "Title Information", "Title Status:",true);
	    
	    RC_Global.panelAction(driver, "close", "View Remarketing Requests",false,false);
	    queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	    
	   
	}
}
