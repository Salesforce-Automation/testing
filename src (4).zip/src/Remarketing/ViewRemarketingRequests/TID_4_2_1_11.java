package Remarketing.ViewRemarketingRequests;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.LeaseWave.RC_LW_Global;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;
import tools.TotalView.RC_Remarketing;

public class TID_4_2_1_11 {
	public void LWIntegrationForSecuredStatus(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		String menu = "Remarketing";
        String firstSubMenu = "View Remarketing Requests";
        String msg = "Saved Successfully";
    	JavascriptExecutor executor = (JavascriptExecutor)driver;
        RC_Global.login(driver);    
	    RC_Global.navigateTo(driver,menu,firstSubMenu, "");
	//	RC_Global.enterCustomerNumber(driver, "LS008737", "", "", true);
	    RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Sale Status", "Submitted", true);
	    RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Request Type", "Merchants to Sell", true);
	    RC_Global.clickButton(driver, "Search", false,true) ;
	    RC_Global.waitElementVisible(driver, 60, "//tbody//tr[1]", "Grid load", true,false);
	    RC_Remarketing.selectRowWithSalesStatusFromGrid(driver, "Submitted", true);
	    Thread.sleep(2000);
		RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='View Remarketing Requests']])[1]", false,false);
	    RC_Global.waitUntilPanelVisibility(driver, "View Remarketing Requests", "TV", false,false);
	    RC_Global.panelAction(driver, "expand", "View Remarketing Requests", true,false);
	    
	    RC_Global.clickUsingXpath(driver,"//a[text()='Manage Sale']", "Manage Sale",false,false); 
	    String UnitNumber = driver.findElement(By.xpath("(//label[text()='Unit Number']//following::div/a)[1]")).getText();
	    RC_Global.clickButton(driver, "Vendor Search", false,true); 
	    RC_Global.validateHeaderName(driver, "Consignment Search", false);
	    RC_Global.panelAction(driver, "expand", "Consignment Search", false,false);
	 //   RC_Global.clickButton(driver, "Search", false);
	  //  RC_Global.waitElementVisible(driver, 30, "//span[text()='Vendor Name']", "Vendor Name", false);
	 //   RC_Global.scrollById(driver, "//span[text()='Vendor Name']");
	    RC_Remarketing.selectNonAutoImsRecord(driver,true);
	    Thread.sleep(2000);
		 WebElement SelectVendor= driver.findElement(By.xpath("//button[text()='Select Vendor']"));
		 executor.executeScript("arguments[0].scrollIntoView(true);",SelectVendor);
		 executor.executeScript("document.body.style.zoom = '30%'");
		 Thread.sleep(2000);
		 executor.executeScript("document.body.style.zoom = '100%'");
	    RC_Global.clickButton(driver, "Select Vendor", false,true); 
	    RC_Global.panelAction(driver, "expand", "View Remarketing Requests", false,false); 
	    RC_Global.verifyDisplayedMessage(driver, "You must submit request to consigner prior to changing tabs.", false);
	    RC_Global.clickButton(driver, "Submit Request to Consigner", false,true);
	    if(driver.findElements(By.xpath("//h3[text()='Confirm']")).size()>0)
	    {
	    	RC_Global.verifyDisplayedMessage(driver, "Upon submission, vehicle pickup request will be sent to your email address for processing.", false);
	 	    RC_Global.clickButton(driver,"Submit", false,false);	
	    }
	    RC_Manage.waitUntilMethods(driver, "//i[@ng-show='vm.isRequestingSubmitConsigner']","class","ng-hide", "attribute visible");
	    RC_Global.verifyDisplayedMessage(driver, "Saved Successfully", false);
	    Thread.sleep(4000);
	    RC_Global.clickUsingXpath(driver,"//a[text()='Transportation']", "Transportation",false,true); 
	    RC_Global.waitElementVisible(driver, 30, "//fieldset/form/div[1]/div/legend[contains(@class,'marg-top-15')]", "Consignment Details",false,false);
	    /* Format f = new SimpleDateFormat("MM/dd/yyyy");
	    String Date = f.format(new Date());
	    WebElement element = driver.findElement(By.xpath("//input[@placeholder ='Secured Date']"));
	    RC_Global.enterInput(driver, Date, element, false,false);*/
	    if (driver.findElement(By.xpath("//input[@placeholder='Secured Date']")).isEnabled()) {
	    driver.findElement(By.xpath("//input[@placeholder='Secured Date']")).sendKeys(RC_Manage.AddDateStr(0,"MM/dd/yyyy" , "minute", null, ""));
	    }

	    RC_Global.clickUsingXpath(driver,"(//label[@name='buttonBillingNo'])[2]", "Stop",false,false);
	    RC_Global.clickButton(driver, "Save",true,true);
	    Thread.sleep(4000);
	    executor.executeScript("document.body.style.zoom = '80%'");
	    RC_Global.verifyDisplayedMessage(driver, msg,true);
	    executor.executeScript("document.body.style.zoom = '100%'"); 
	    RC_Global.panelAction(driver, "close", "View Remarketing Requests", true,false);
	    Thread.sleep(3000);
	    
	    RC_LW_Global.leaseWaveLogin(driver,true);
	    RC_Global.clickUsingXpath(driver,"//a[contains(text(),'Portfolio Management')]", "Portfolio Management",true,true);
        RC_Global.waitElementVisible(driver, 30, "//a[contains(text(),'Portfolio Management')]", "Portfolio Management",false,false);
            String home =  driver.findElement(By.xpath("//a[contains(text(),'Portfolio Management')]")).getText();
           
           if(home.contains("Portfolio Management")) {
            queryObjects.logStatus(driver, Status.PASS, "Navigation to Portfolio Management Menu", "Successfully", null);
        }
           
        RC_Global.clickUsingXpath(driver,"//td[@accesskey='2' and text()='.Lease']", "Lease",true,false);
        RC_Global.clickUsingXpath(driver,"//tr/td[@accesskey='D']/div[text()='Off Roa']", "Off Road Details",true,false);
        RC_Global.clickUsingXpath(driver,"//tr/td[@accesskey='S']/div[text()='ingle Lease']", "Single Lease",true,false);
        
        RC_Global.waitElementVisible(driver, 30, "//span[span[text()='Lease List']]", "Lease List header",false,true);
        WebElement element1 = driver.findElement(By.xpath("//td[@lw_friendlyname ='Unit Number' ]/input"));
		RC_Global.enterInput(driver, UnitNumber, element1 , true,true);
		RC_Global.clickUsingXpath(driver, "//button[@accesskey ='H' and text()='Searc']", "Search", false,true);
		RC_Global.clickUsingXpath(driver, "//button[@accesskey ='S' and text()='elect']", "Select", false,true);
		RC_Global.waitElementVisible(driver, 30, "//span[span[text()='Off Road Details']]", "Off Road Details header",false,false);
		
	if(driver.findElements(By.xpath("//h2/span[text()='Off Road Details']")).size()>0)
	{
		if(driver.findElements(By.xpath("//input[contains(@name,'chkStopBilling') and @checked ='checked']")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "'Stop Billing' field is checked ", "Successfully", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "'Stop Billing' field is not checked ", "", null);
		
		 Format T = new SimpleDateFormat("M/dd/yyyy");
	     String TDate = T.format(new Date());
		String SBDate = driver.findElement(By.xpath("//input[contains(@name,'StopBillingDate_input')]")).getAttribute("value");
		
		if(!SBDate.isEmpty())
			queryObjects.logStatus(driver, Status.PASS, "'Stop Billing Date' displayed today's date ", "Successfully", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "'Stop Billing Date' is not displayed today's date ", "", null);
	}
	    
	 	Thread.sleep(2000);
	    RC_Global.clickUsingXpath(driver, "//button[@accesskey ='C' and text()='lose']", "Close", false,true);
	    Thread.sleep(2000);
		RC_Global.waitElementVisible(driver, 30, "(//span[text()='Lease List'])[1]", "Lease List",false,false);
	    RC_LW_Global.leaseWaveLogOut(driver,true);
	   
	    RC_Global.login(driver);
	    RC_Global.navigateTo(driver,menu,firstSubMenu, "");
	    RC_Global.enterInput(driver, UnitNumber, driver.findElement(By.xpath("//input[@placeholder='Unit Number']")), false,true);
	    RC_Global.clickButton(driver, "Search", false,true);
	    RC_Remarketing.selectRowWithSalesStatusFromGrid(driver, "Secured", true);
	    RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='View Remarketing Requests']])[1]", false,false);
	    RC_Global.waitUntilPanelVisibility(driver, "View Remarketing Requests", "TV", false,false);
	    RC_Global.panelAction(driver, "expand", "View Remarketing Requests", true,false);
	    RC_Global.clickUsingXpath(driver,"//a[text()='Transportation']", "Transportation",false,true); 
	    RC_Global.waitElementVisible(driver, 30, "//legend[text()='Consignment Details']", "Consignment Details", false,false);
	    RC_Global.clickUsingXpath(driver,"(//label[text()='Resume'])[2]", "Resume",false,true);
	    RC_Global.clickButton(driver, "Save",true,true);
	    Thread.sleep(2000);
	    executor.executeScript("document.body.style.zoom = '80%'");
	    RC_Global.verifyDisplayedMessage(driver, msg,true);
	    executor.executeScript("document.body.style.zoom = '100%'");
	    RC_Global.panelAction(driver, "close", "View Remarketing Requests", true,false);
	    Thread.sleep(3000);
	    
	    RC_LW_Global.leaseWaveLogin(driver,true);
	    RC_Global.clickUsingXpath(driver,"//a[contains(text(),'Portfolio Management')]", "Portfolio Management",true,true);
        RC_Global.waitElementVisible(driver, 30, "//a[contains(text(),'Portfolio Management')]", "Portfolio Management",false,false);
        RC_Global.waitElementVisible(driver, 30, "//a[contains(text(),'Portfolio Management')]", "Portfolio Management",false,false);
        String home1 =  driver.findElement(By.xpath("//a[contains(text(),'Portfolio Management')]")).getText();
       
       if(home1.contains("Portfolio Management")) {
        queryObjects.logStatus(driver, Status.PASS, "Navigation to Portfolio Management Menu", "Successfully", null);
    }
       
    RC_Global.clickUsingXpath(driver,"//td[@accesskey='2' and text()='.Lease']", "Lease",true,false);
    RC_Global.clickUsingXpath(driver,"//tr/td[@accesskey='D']/div[text()='Off Roa']", "Off Road Details",true,false);
    RC_Global.clickUsingXpath(driver,"//tr/td[@accesskey='S']/div[text()='ingle Lease']", "Single Lease",true,false);
    
    RC_Global.waitElementVisible(driver, 30, "//span[span[text()='Lease List']]", "Lease List header",false,true);
    WebElement element2 = driver.findElement(By.xpath("//td[@lw_friendlyname ='Unit Number' ]/input"));
	RC_Global.enterInput(driver, UnitNumber, element2 , true,true);
	RC_Global.clickUsingXpath(driver, "//button[@accesskey ='H' and text()='Searc']", "Search", false,true);
	RC_Global.clickUsingXpath(driver, "//button[@accesskey ='S' and text()='elect']", "Select", false,true);
	RC_Global.waitElementVisible(driver, 30, "//span[span[text()='Off Road Details']]", "Off Road Details header",false,false);
	if(driver.findElements(By.xpath("//h2/span[text()='Off Road Details']")).size()>0)
	{
		
		if(!(driver.findElements(By.xpath("//input[contains(@name,'chkStopBilling') and @checked ='checked']")).size()>0))
		{
			queryObjects.logStatus(driver, Status.PASS, "'Stop Billing' field is unchecked ", "Successfully", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "'Stop Billing' field is checked ", "", null);
		}
		
		String SBDate = driver.findElement(By.xpath("//input[contains(@name,'StopBillingDate_input')]")).getAttribute("value");
		
		if(SBDate.contains("Select"))
		{
			queryObjects.logStatus(driver, Status.PASS, "'Stop Billing Date' not displayed date ", "Successfully", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "'Stop Billing Date' is displayed today's date ", "", null);
		}
	}
		Thread.sleep(2000);
	    RC_Global.clickUsingXpath(driver, "//button[@accesskey ='C' and text()='lose']", "Close", false,true);
	    Thread.sleep(2000);
		RC_Global.waitElementVisible(driver, 30, "(//span[text()='Lease List'])[1]", "Lease List",false,false);
	    RC_LW_Global.leaseWaveLogOut(driver,true); 
	    
	    queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	    
}
}