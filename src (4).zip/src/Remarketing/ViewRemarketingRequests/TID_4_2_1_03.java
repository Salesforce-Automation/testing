package Remarketing.ViewRemarketingRequests;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_4_2_1_03 {
	public void VerifyViewRemarketingRequests_OpenEnd_LeaseTurnIn_SaleStatus(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		String cancellationRequestMessage = "Submitting a cancellation request does not guarantee this transaction can be cancelled. Cancellation of this request may result in additional charges. Please consult with your Customer Service Representative at 877-870-4999 or clientserviceteam@merchantsfleet.com before proceeding.";
		String cancellationRequestConfirmMessage = "Your request will be reviewed and confirmation if the transaction can be cancelled and any additional charges will be provided by your Client Service Representative within 2 business days.";
		boolean cancellationReasonChange  = false;
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Remarketing", "View Remarketing Requests", "");
		
		RC_Global.createNode(driver, "Selecting Lease Turn In and Open End filter options");
		driver.findElement(By.xpath("//label[text()='Request Type']/following-sibling::select/option[text()='All']")).click();//Unselect 'All'
		driver.findElement(By.xpath("//label[text()='Request Type']/following-sibling::select/option[text()='Lease Turn In']")).click();
		
		driver.findElement(By.xpath("//label[text()='Agreement Type']/following-sibling::select/option[text()='All']")).click();//Unselect 'All'
		driver.findElement(By.xpath("//label[text()='Agreement Type']/following-sibling::select/option[text()='Open End']")).click();
		
		RC_Global.clickButton(driver, "Search", true,true);
		RC_Global.waitElementVisible(driver, 30, "//table/tbody/tr[1]", "First record ", true, false);
		RC_Global.clickUsingXpath(driver, "(//tbody//tr[1]/td[6])[1]", "First record available in the grid", true, false);
		
		RC_Global.clickButton(driver, "Select Vehicle", true,true);
		RC_Manage.waitUntilMethods(driver, "(//button[text()='Select Vehicle '])[1]/div[@ng-show='vm.isSelectingTermination']","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 30, "(//h5[span[text()='View Remarketing Requests']])[2]", "View Remarketing Requests", true, true);
		
		RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='View Remarketing Requests']])[1]", true, false);
		RC_Global.panelAction(driver, "expand", "View Remarketing Requests", true, false);
		
		RC_Global.waitElementVisible(driver, 30, "//ul/li/a[text()='Sale Status']", "Validate Sale Status", false, false);
		RC_Global.verifyColumnNames(driver, "Sale Status;Status Updated On;Notes;Added By", false);
		
		RC_Global.clickButton(driver, "History", true,true);
		RC_Global.waitUntilPanelVisibility(driver, "Lease Turn In - History", "TV", true, false);
		
		String previousComment = "";
		if(driver.findElements(By.xpath("//history//span[@id='tableStatusNoResults']")).size()==0) {
			if(driver.findElement(By.xpath("(//div[div[h5[span[text()='Lease Turn In - History']]]]//div[@role='rowgroup'][2]//div[@role='row']/div[2])[1]")).getText().equalsIgnoreCase("Submit a Cancellation")) {
				RC_Global.clickUsingXpath(driver, "(//span[text()='Submit a Cancellation'])[1]", "Latest Submit a Cancellation link", true,true);
				previousComment = driver.findElement(By.xpath("(//div[div[h5[span[text()='Lease Turn In - History']]]]//div[@role='rowgroup'][2]//div[@role='row']/div[4])[3]")).getText();
			}
		}
		RC_Global.panelAction(driver, "close", "Lease Turn In - History", false, false);
		RC_Global.panelAction(driver, "expand", "View Remarketing Requests", false, false);
		
		RC_Global.buttonStatusValidation(driver, "Cancel Remarketing Request", "Enable", true);
		RC_Global.clickButton(driver, "Cancel Remarketing Request", true,true);
		
		RC_Global.createNode(driver, "Validate Cancellation Request Message");
		if(driver.findElements(By.xpath("//h4/b[text()='"+cancellationRequestMessage+"']")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Cancellation Request Message Validation", "Success", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Cancellation Request Message Validation", "Fail", null);
		
		RC_Global.createNode(driver, "Reason textbox validation");
		
		//Verifying buttons
		if(driver.findElements(By.xpath("//button[text()='Submit Cancellation']")).size()>0)
			queryObjects.logStatus(driver, Status.INFO, "Verifying that the Submit Cancellation button", "Successful", null);
		
		if(driver.findElements(By.xpath("//button[text()='Close']")).size()>0)
			queryObjects.logStatus(driver, Status.INFO, "Verifying that the Submit Cancellation button", "Successful", null);
		
		WebElement element = driver.findElement(By.xpath("//cancel-remarketing-request-modal-component//textarea[@placeholder='Comments']"));
		RC_Global.enterInput(driver, "Cancellation Reason", element, true, true);
		
		RC_Global.clickButton(driver, "Close", false, false);
		
		RC_Global.clickButton(driver, "Cancel Remarketing Request", true, false);
		
		RC_Global.clickButton(driver, "Submit Cancellation", false,true);
		if(driver.findElements(By.xpath("//h4[text()='Add comment before submit']")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verifying that the comment box is Mandatory", "Successful", null);
					
		element = driver.findElement(By.xpath("//cancel-remarketing-request-modal-component//textarea[@placeholder='Comments']"));
		String cancellationReason = "Cancellation Reason - "+RandomStringUtils.randomNumeric(2);
		if(cancellationReason.equalsIgnoreCase(previousComment))
			cancellationReason = "Cancellation Reason - 0"+RandomStringUtils.randomNumeric(2);
		
		RC_Global.enterInput(driver, cancellationReason, element, true, false);
		RC_Global.clickButton(driver, "Submit Cancellation", false,true);
		
		Thread.sleep(5000);
		RC_Global.waitElementVisible(driver, 30, "//h4[@class='cancel-remarketing-header']", "Cancellation Request Header", false, false);
		
		if(driver.findElements(By.xpath("//b[text()='"+cancellationRequestConfirmMessage+"']")).size()>0)
			queryObjects.logStatus(driver, Status.INFO, "Verifying the message after submitting cancellation", "Successful", null);
			
		if(driver.findElements(By.xpath("//button[text()='Close']")).size()>0)
			RC_Global.clickButton(driver, "Close", false,true);
		
		//Validate the contents of the email received --- Cannot be validated
		
		
		int cancellationMsgCount = driver.findElements(By.xpath("//div[div[h3[text()='Sale Status']]]//span[text()='Cancellation request has been sent to Merchants� Remarketing']")).size();
		List<WebElement> gridValidationValues = driver.findElements(By.xpath("(//div[div[h3[text()='Sale Status']]]//span[text()='Cancellation request has been sent to Merchants� Remarketing'])["+cancellationMsgCount+"]/ancestor::div[3]/div"));
		
		RC_Global.createNode(driver, "Validate History Hyperlink");
		RC_Global.clickButton(driver, "History", true,true);
		RC_Global.waitUntilPanelVisibility(driver, "Lease Turn In - History", "TV", true, false);
		
		RC_Global.panelAction(driver, "close", "View Remarketing Requests", false, false);
		RC_Global.panelAction(driver, "expand", "Lease Turn In - History", false, false);
		
		RC_Global.clickButton(driver, "Expand All", false,true);
		if(driver.findElements(By.xpath("(//div[@role='rowgroup'])[2]//div[@role='columnheader']/div[@role='button']")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Validation of Expand All button", "Successful", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Validation of Expand All button", "Expected to Collapse grid content", null);
		
		RC_Global.clickButton(driver, "Collapse All", false,true);
		if(driver.findElements(By.xpath("(//div[@role='rowgroup'])[2]//div[@role='columnheader']/div[@role='button']")).size()==0)
			queryObjects.logStatus(driver, Status.PASS, "Validation of Collapse All button", "Successful", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Validation of Collapse All button", "Expected to Collapse grid content", null);
		
		RC_Global.verifyColumnNames(driver, "Date;Event;Created By", false);

		//Validate History value grid		
		String createdByName = driver.findElement(By.xpath("//span[@id='user-menu-name']/preceding-sibling::span")).getText();
		
		if(driver.findElement(By.xpath("(//div[@role='rowgroup'][2]//div[@role='row']/div[1])[1]")).getText().equalsIgnoreCase(RC_Global.getDateTime(driver, "MM/dd/yyyy", 0, false)))
			queryObjects.logStatus(driver, Status.INFO, "Verifying the Created Date", "Successful", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verifying the Created Date", "The create date is not today's date", null);
				
		if(driver.findElement(By.xpath("(//div[@role='rowgroup'][2]//div[@role='row']/div[2])[1]")).getText().equalsIgnoreCase("Submit a Cancellation"))
			queryObjects.logStatus(driver, Status.INFO, "Verifying the event --- 'Submit a Cancellation'", "Successful", null);
		else 
			queryObjects.logStatus(driver, Status.FAIL, "Verifying the event --- 'Submit a Cancellation'", "The event is not as expected", null);
		
	/*	if(driver.findElement(By.xpath("(//div[@role='rowgroup'][2]//div[@role='row']/div[3])[1]")).getText().contains(createdByName))
			queryObjects.logStatus(driver, Status.INFO, "Verifying the Created By --- "+createdByName, "Successful", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verifying the Created By --- "+createdByName, "The Created By is not the same as "+createdByName, null);*/
		
		if(driver.findElement(By.xpath("(//div[@role='rowgroup'][2]//div[@role='row']/div[2])[1]")).getText().equalsIgnoreCase("Submit a Cancellation")) {
			RC_Global.clickUsingXpath(driver, "//span[text()='Submit a Cancellation']", "Submit a Cancellation link", true,true);
			
			//Verify Columns
			List<WebElement> columns = driver.findElements(By.xpath("(//div[@role='rowgroup'])[2]//div[@role='columnheader']/div[@role='button']"));
			String[] colNames = {"Customer Number","Customer Name","Reason","Fleet Number","Fleet Name","Account Number","Account Name","Sub-Account Number","Sub-Account Name"};
			
			int iter = 0;
			for(WebElement col:columns) {
				if(col.getText().equalsIgnoreCase(colNames[iter])) {
					iter++;
				}
			}
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "Validation of Submit a Cancellation", "Submit a Cancellation link is unavailable", null);
			
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
