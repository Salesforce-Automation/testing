package Remarketing.ViewRemarketingRequests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_4_2_1_05 {
	public void MTS_LeaseTurnInConditionReportsTab(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		String[] GridColumn ={"Customer Number","Customer Name","Date Received","Fleet Number","Fleet Name","Account Number","Account Name","Sub-Account Number","Sub-Account Name"};
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Remarketing", "View Remarketing Requests", "");
		WebElement UnitNumber = driver.findElement(By.xpath("//input[contains(@placeholder,'Unit Number')]"));
	    RC_Global.enterInput(driver, "661288",UnitNumber, true,true);
	    RC_Global.clickButton(driver, "Search",true,true);
	    RC_Global.waitElementVisible(driver,30,"//tbody//tr[1]","Grid Row",true, false);
		RC_Global.clickUsingXpath(driver, "//tbody//tr[1]/td[1]", "Select Grid Row", true, false);
	
		RC_Global.panelAction(driver,"xpathclose","(//h5[span[text()='View Remarketing Requests']])[1]",true, false);
		RC_Global.panelAction(driver,"expand","View Remarketing Requests",true, false);
		RC_Global.clickUsingXpath(driver, "//a[contains(text(),'Condition Report')]", "Condition Report Tab clicked", true,true);
		
		RC_Global.waitElementVisible(driver,30,"//div//h3[contains(text(),'Condition Report')]","Condition Report Header",true,false);
		if(driver.findElements(By.xpath("//div//h3[contains(text(),'Condition Report')]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.INFO, "Header Text - Condition Report", " Displayed", null);
		}
		if(driver.findElements(By.xpath("(//div//button[contains(text(),'Open')])[4]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.INFO, "Open Button", " Present", null);
		}
		if(driver.findElements(By.xpath("(//div//button[contains(text(),'Email')])[4]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.INFO, "Email Button", " Present", null);
		}
		if(driver.findElements(By.xpath("(//div//button[contains(text(),'Print')])[4]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.INFO, "Print Button", " Present", null);
		}
		RC_Global.clickUsingXpath(driver, "(//h3[contains(text(),'Condition Report')]/../following::div//button[contains(text(),'Email')])[1]","Email Button Clicked", false,true);
		Thread.sleep(2000);
		RC_Global.waitElementVisible(driver,90,"//h3[contains(text(),'Condition Report Message')]","Condition Report Message Screen",true,true);
		
		String To=driver.findElement(By.xpath("//div//h3[contains(text(),'Condition Report Message')]/../following::label[1]")).getText();
		String Cc=driver.findElement(By.xpath("//div//h3[contains(text(),'Condition Report Message')]/../following::label[2]")).getText();
		String Bcc=driver.findElement(By.xpath("//div//h3[contains(text(),'Condition Report Message')]/../following::label[3]")).getText();
		String Subject=driver.findElement(By.xpath("//div//h3[contains(text(),'Condition Report Message')]/../following::label[4]")).getText();
		String SubjecText=driver.findElement(By.xpath("//input[@id='mail_subject']")).getAttribute("ng-model");
		String Content = driver.findElement(By.xpath("//div[@ng-model='vm.emailInfo.email']")).getText();
		
		
		
		
		queryObjects.logStatus(driver, Status.INFO, "Condition Report Message has "+To, " Field", null);
		queryObjects.logStatus(driver, Status.INFO, "Condition Report Message has "+Cc, " Field", null);
		queryObjects.logStatus(driver, Status.INFO, "Condition Report Message has "+Bcc, " Field", null);
		queryObjects.logStatus(driver, Status.INFO, "Condition Report Message has "+Subject+" Field has", SubjecText, null);
		queryObjects.logStatus(driver, Status.INFO, "Condition Report Message has "+Bcc, " Field", null);
		queryObjects.logStatus(driver, Status.INFO, "Condition Report Message has mail body", Content, null);
		
		RC_Global.clickButton(driver, "Cancel", true,true);
		Thread.sleep(1000);
		
		RC_Global.clickUsingXpath(driver, "//h3[contains(text(),'Condition Report')]/../../../div/button","History button", false,true);
		RC_Global.createNode(driver, "Merchants to Sell and Terminate Services Only - History");
		RC_Global.waitUntilPanelVisibility(driver, "Merchants to Sell and Terminate Services Only - History", "TV", false,false);
		
		RC_Global.panelAction(driver,"xpathclose","(//h5[span[text()='View Remarketing Requests']])[1]",true, false);
		//RC_Global.panelAction(driver,"xpathclose","(//h5[span[text()='View Remarketing Requests']])[2]",true, false);
		RC_Global.panelAction(driver,"expand","Merchants to Sell and Terminate Services Only - History",true, false);
		
		if(driver.findElements(By.xpath("(//div[contains(@role,'columnheader')]//div[contains(@role,'button')]//span[contains(text(),'Date')])[4]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.INFO, "Grid has column name ", " Date", null);
		}
		
		if(driver.findElements(By.xpath("//div[contains(@role,'columnheader')]//div[contains(@role,'button')]//span[contains(text(),'Event')]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.INFO, "Grid has column name ", " Event", null);
		}
		
		if(driver.findElements(By.xpath("//div[contains(@role,'columnheader')]//div[contains(@role,'button')]//span[contains(text(),'Created By')]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.INFO, "Grid has column name ", " Created By", null);
		}
		
		RC_Global.clickButton(driver, "Expand All", true,true);
		int Arylength = GridColumn.length;
		for(int itr=0;itr<Arylength;itr++)
		{
			if(driver.findElements(By.xpath("(//div//div//span[contains(text(),'"+GridColumn[itr]+"')])[1]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.INFO, "Grid has column name ", GridColumn[itr], null);
			}
		}
		
	}

}
