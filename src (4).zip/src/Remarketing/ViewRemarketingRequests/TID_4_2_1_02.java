package Remarketing.ViewRemarketingRequests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;
import tools.TotalView.RC_Remarketing;

public class TID_4_2_1_02 {

	public void ValidateViewRemarketingGridResult(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
		
		String columnName ="Customer #;Customer Name;Unit Number;CVN;Submission Date;Request Type;Sales Status;Status Last Updated;Days Open;VIN;Year;Make;Model;Driver/Pool Name;Pool Contact;Agreement Type;Odometer Reading;3rd Party Inspection Required;Fleet #;Fleet Name;Account #;Account Name;Sub-Account #;Sub-Account Name";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Remarketing", "View Remarketing Requests", "");
		RC_Global.enterCustomerNumber(driver, "151141", "", "", true);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.waitElementVisible(driver,30,"//tbody//tr[1]","Grid Row",true, false);
		RC_Global.verifyColumnNames(driver, columnName,true);
		RC_Global.verifySortFunction(driver, "Submission Date", false);
		
		 RC_Global.createNode(driver,"Verify Unit Number as hypertext and navigate to Vehicle Details page");
	        RC_Global.clickUsingXpath(driver,"(//tbody//tr[1]/td[3])[1]", "Unit Number",false, false);
	        RC_Global.validateHeaderName(driver, "Vehicle Details",false);
	        RC_Global.panelAction(driver, "close","Vehicle Details",false, false);
	        RC_Global.panelAction(driver, "expand", "View Remarketing Requests",false, false);
	        
	     RC_Global.createNode(driver,"Verify CVN displayed as hypertext and navigate to Vehicle Details page");
	        RC_Global.clickUsingXpath(driver, "//span[1][text()='CVN']", "customer vehicle number", true, false);
	        RC_Global.clickUsingXpath(driver,"(//tbody//tr[1]/td[4])[1]", "CVN",false, false);
	        RC_Global.validateHeaderName(driver, "Vehicle Details",false);
	        RC_Global.panelAction(driver, "close","Vehicle Details",false, false);
	        RC_Global.panelAction(driver, "expand", "View Remarketing Requests",false, false);
	        RC_Global.clickUsingXpath(driver, "//span[1][text()='CVN']", "customer vehicle number", true, false);
	        
	     RC_Global.createNode(driver,"Verify Sales Status displayed as hypertext and navigate to View Remarketing Requests page");
	        RC_Global.verifySortFunction(driver, "Sales Status", false);
	        RC_Global.clickUsingXpath(driver,"(//tbody//tr[1]/td[7]/a)[1]", "Sales Status",false, false);
	        RC_Manage.waitUntilMethods(driver, "(//h5[span[text()='View Remarketing Requests']])[2]","","", "visible");
	        RC_Global.validateHeaderName(driver, "View Remarketing Requests",false);
	        RC_Global.clickUsingXpath(driver, "(//h5[span[text()='View Remarketing Requests']]/i[@ng-click='closePanel()'])[2]", "close", true, false);
	        RC_Global.panelAction(driver, "expand", "View Remarketing Requests",true, false);
	        
	        String value= driver.findElement(By.xpath("(//tbody//tr[1]/td[5])[1]")).getText();
			RC_Remarketing.isValidDateFormat(driver, "MM/DD/YYYY", value, false);
			//days open
			String submissionDate = driver.findElement(By.xpath("(//tbody//tr[2]/td[5])[1]")).getText();
			String openDays = driver.findElement(By.xpath("(//tbody//tr[2]/td[9])[1]")).getText();
			RC_Remarketing.dateOpenCount(driver, submissionDate, openDays, false);
			
			RC_Global.clickUsingXpath(driver, "(//tbody//tr[1]/td[6])[1]", "grid row", true, false);
			RC_Global.buttonStatusValidation(driver, "Select Vehicle", "Enable", true);
			RC_Global.clickUsingXpath(driver, "//li//a[text()='Next']", "Next Grid", false, false);
			RC_Global.clickUsingXpath(driver, "//li//a[text()='Previous']", "Previous Grid", false, false);
			RC_Global.clickUsingXpath(driver, "//li//a[text()='Last']", "Last Grid", false, false);
			RC_Global.clickUsingXpath(driver, "//li//a[text()='First']", "First Grid", false, false);
			RC_Global.selectDropdownOption(driver, "entries per page", "10", false, false);
			RC_Global.downloadAndVerifyFileDownloaded(driver, "Export", "Export to Excel Functionality",true);
			
			queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
			
	        
	}
}
