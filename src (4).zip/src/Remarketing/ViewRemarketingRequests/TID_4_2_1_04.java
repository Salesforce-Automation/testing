package Remarketing.ViewRemarketingRequests;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;
import tools.TotalView.RC_Remarketing;

public class TID_4_2_1_04 {
	public void  MerchantsToSell_OpenEnd_LeaseTurnIn_RequestSummaryTab(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
		
		String TRS= "";
		String VPT= "";
		String VPLC= "";
		String DA= "";
		String displaymessage = "Please see the attached Vehicle Termination Request Summary for 698462";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Remarketing", "View Remarketing Requests", "");
		RC_Global.enterCustomerNumber(driver, "151141", "", "",true);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.waitElementVisible(driver, 30, "//tbody//tr[1]", "Table to Appear", true,false);
		RC_Global.clickUsingXpath(driver, "(//tbody//tr[1]/td[6])[1]", "grid row", true, false);
		RC_Global.clickButton(driver, "Select Vehicle", true,true);
		RC_Manage.waitUntilMethods(driver, "(//button[text()='Select Vehicle '])[1]/div[@ng-show='vm.isSelectingTermination']","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 30, "(//h5[span[text()='View Remarketing Requests']])[2]", "View Remarketing Requests", true, false);
		RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='View Remarketing Requests']])[1]", true, false);
		RC_Global.panelAction(driver, "expand", "View Remarketing Requests", true, false);
	    RC_Global.waitUntilPanelVisibility(driver, "View Remarketing Requests", "TV", false, false);
	    //RC_Global.panelAction(driver, "expand", "View Remarketing Requests", true, false);
		RC_Global.clickUsingXpath(driver, "//a[text()='Request Summary']", "Request Summary Tab", true,true);
		TRS = driver.findElement(By.xpath("(//legend[text()='Termination Request Summary'])[3]")).getText();
		VPT = driver.findElement(By.xpath("(//legend[text()='Vehicle Program Termination'])[5]")).getText();
		VPLC = driver.findElement(By.xpath("//legend[text()='Vehicle Pickup Location & Contact Details']")).getText();
		DA = driver.findElement(By.xpath("(//legend[text()='Disclosure Agreement'])[2]")).getText();
		if(TRS.equalsIgnoreCase("Termination Request Summary"))
		{
		 queryObjects.logStatus(driver, Status.INFO, "Termination Request Summary section is ", "Displayed", null);
		}
		if(VPT.equalsIgnoreCase("Vehicle Program Termination"))
		{
		 queryObjects.logStatus(driver, Status.INFO, "Vehicle Program Termination section is ", "Displayed", null);
		}
		if(VPLC.equalsIgnoreCase("Vehicle Pickup Location & Contact Details"))
		{
		 queryObjects.logStatus(driver, Status.INFO, "Vehicle Pickup Location & Contact Details section is ", "Displayed", null);
		}
		if(DA.equalsIgnoreCase("Disclosure Agreement"))
		{
		 queryObjects.logStatus(driver, Status.INFO, "Disclosure Agreement section is ", "Displayed", null);
		}
		
		RC_Global.createNode(driver,"Validate section :Termination Request Summary");
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Termination Request Summary", "Request Submitted On:", true);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Termination Request Summary", "Confirmation Number:", true);
	     RC_Remarketing.screenSectionDetailsValidation(driver, "Termination Request Summary", "Optional Driver Message Sent:", true);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Termination Request Summary", "Request Submitted By:", true);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Termination Request Summary", "Driver/Pool Name:", true);
		 
		 RC_Global.createNode(driver,"Validate section :Vehicle Program Termination");
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Program Termination", "Is the Driver still an active Employee with the Company?", true);
	     RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Program Termination", "Is Driver remaining enrolled in Fuel?",  true);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Program Termination", "Is Driver remaining enrolled in Personal Use?",  true);
		 
		 RC_Global.createNode(driver,"Validate section :Vehicle Pickup Location & Contact Details");
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Pickup Location & Contact Details", "Pickup Location Type:",  true);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Pickup Location & Contact Details", "Pickup Address 1:",  true);
	     RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Pickup Location & Contact Details", "Pickup Address 2:",  true);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Pickup Location & Contact Details", "Pickup City, State, Zip:",  true);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Pickup Location & Contact Details", "Comments:",  true);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Pickup Location & Contact Details", "Pickup Contact Name:",  true);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Pickup Location & Contact Details", "Pickup Contact Email:", true);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Pickup Location & Contact Details", "Pickup Contact Phone:",  true);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Vehicle Pickup Location & Contact Details", "Alternate Phone:",  true);
		 
		 
		 RC_Global.createNode(driver,"Validate section :Disclosure Agreement");
		 String dataDetails = driver.findElement(By.xpath("(//legend[text()='Disclosure Agreement']/..//following::div//div//div//label[contains(text(),'Disclosed Odometer:')]/following::span)[1]")).getText();
		 queryObjects.logStatus(driver,Status.PASS,"Section :Disclosure Agreement has label Disclosed Odometer: with value",dataDetails, null);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Disclosure Agreement", "The odometer reading reflects the amount of mileage in excess of the mechanical limits of the odometer", true);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Disclosure Agreement", "The reading is not the actual mileage and should not be relied upon Warning Odometer Discrepancy",  true);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Disclosure Agreement", "Is the vehicle drivable?",  true);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Disclosure Agreement", "Has the vehicle sustained damage from a single occurance", true);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Disclosure Agreement", "Has the vehicle been stolen or recovered?",  true);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Disclosure Agreement", "Has the vehicle been submerged in water or sustained flood damage?",  true);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Disclosure Agreement", "Has the vehicle been salvaged or rebuilt?", true);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Disclosure Agreement", "Has the airbag(s) in the vehicle been removed, rendered inoperable or has an airbag",  true);
		  
		 RC_Global.scrollById(driver, "(//legend[text()='Disclosure Agreement'])[2]");
		 RC_Global.clickUsingXpath(driver, "(//button[normalize-space(text())='Open'])[6]", "Open",true,true);
		 Thread.sleep(2000);
	     RC_Global.clickUsingXpath(driver, "(//button[normalize-space(text())='Email'])[6]", "Email",true,true);
	     RC_Global.waitElementVisible(driver, 30, "//h3[text()='Request Summary Message']", "Email Documents",false, false);
	     RC_Global.verifyDisplayedMessage(driver,displaymessage,true);
	     Thread.sleep(1000);
	     RC_Global.clickButton(driver, "Cancel",true,false);
	     
	     queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	 	
	}

}
