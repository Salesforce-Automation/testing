package Remarketing.ViewRemarketingRequests;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Remarketing;

public class TID_4_2_1_01 {

	public void VerifyViewRemarketingRequestSearchFields(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
		
		String searchFilters= "Customer Number;Unit Number;Customer Vehicle Number;VIN;Request Type;Sale Status;Agreement Type;3rd Party Inspection Required;Year;Make;Model;Client Data Field 1-7;Client Data Value";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Remarketing", "View Remarketing Requests", "");
		RC_Global.validateHeaderName(driver, "View Remarketing Requests", false);
		RC_Global.validateSpecifiedSearchFilters(driver, searchFilters, true);
		RC_Remarketing.multiSelectValues(driver, "requestType", true);
		RC_Remarketing.multiSelectValues(driver, "saleStatus", true);
		RC_Remarketing.multiSelectValues(driver, "agreementType", true);
		RC_Remarketing.multiSelectValues(driver, "thirdPartyInspectionRequired", true);
		RC_Global.buttonStatusValidation(driver, "Search", "Presence", false);
		RC_Global.buttonStatusValidation(driver, "Reset", "Presence", false);
		RC_Global.panelAction(driver, "close", "View Remarketing Requests", false, false);
		RC_Global.logout(driver, false);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
		
	}
}
