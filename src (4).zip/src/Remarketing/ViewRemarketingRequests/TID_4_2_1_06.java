package Remarketing.ViewRemarketingRequests;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;
import tools.TotalView.RC_Remarketing;

public class TID_4_2_1_06 {
	public void MerchantsToSell_LeaseTurnInTransportationTabNon_AutoIMS(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Remarketing", "View Remarketing Requests", "");
		RC_Global.enterCustomerNumber(driver, "LS008737", "", "", true);
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver,"Request Type","Merchants to Sell", true);
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver,"Sale Status","Submitted", true);
	    RC_Global.clickButton(driver, "Search", false,true);
	    RC_Global.waitElementVisible(driver,30,"//tbody//tr[1]","Grid Row",true, false);
		RC_Global.clickUsingXpath(driver, "//tbody//tr[1]", "Select Grid Row", true, false);
	    RC_Global.clickButton(driver, "Select Vehicle", false,true);
	    RC_Manage.waitUntilMethods(driver, "(//button[text()='Select Vehicle '])[1]/div[@ng-show='vm.isSelectingTermination']","class","ng-hide", "attribute visible");
	    RC_Global.waitElementVisible(driver,30,"(//h5[span[text()='View Remarketing Requests']])[2]","View Remarketing page",true, false);
		RC_Global.panelAction(driver,"xpathclose","(//h5[span[text()='View Remarketing Requests']])[1]",true, false);
		RC_Global.panelAction(driver,"expand","View Remarketing Requests",true, false);
		RC_Global.clickUsingXpath(driver, "//a[text()='Manage Sale']", "Manage Sale Tab", true,true);
		RC_Global.clickButton(driver, "Vendor Search", false,true);
		RC_Global.waitUntilPanelVisibility(driver, "Consignment Search", "TV", false, false);
		Thread.sleep(3000);
		 RC_Global.waitElementVisible(driver,30,"(//div[contains(@role,'gridcell')]//div[contains(text(),'Friday') or contains(text(),'Tuesday') or contains(text(),'Wednesday')or contains(text(),'Thursday')])[1]","Grid Row",true,true);
		 RC_Global.panelAction(driver, "expand", "Consignment Search", false, false);
		 RC_Global.waitElementVisible(driver,60,"((//div[@role='rowgroup'])[14]//div)[2]","Grid Load",true, false); 
		 Thread.sleep(2000);
		 RC_Remarketing.selectNonAutoImsRecord(driver,true);
		 Thread.sleep(2000);
		 
		 RC_Global.clickUsingXpath(driver, "//button[text()='Select Vendor']", "Select Vendor button", true,true);
		 Thread.sleep(2000);
		 RC_Global.panelAction(driver, "expand", "View Remarketing Requests", true, false);
		 RC_Global.clickButton(driver, "Submit Request to Consigner", true, true);
		 RC_Global.waitElementVisible(driver,30,"//div//h3[contains(text(),'Confirm')]","Popup Message",true, false);
		 RC_Global.clickButton(driver, "Submit", true,true);
		 Thread.sleep(3000);
		 RC_Global.waitElementVisible(driver, 30, "(//span[contains(text(),'Consigned')])[1]","Current sales Status change", true, true);
		 String CurrentSalesStatus = driver.findElement(By.xpath("(//span[contains(text(),'Consigned')])[1]")).getText(); 
		 if(CurrentSalesStatus.contains("Consigned"))
				queryObjects.logStatus(driver, Status.PASS, "The Current Status is ", CurrentSalesStatus, null);
		 else
				queryObjects.logStatus(driver, Status.FAIL, "The Current Status Displayed is Incorrect", CurrentSalesStatus, null);
		
		
		RC_Global.clickUsingXpath(driver, "//a[text()='Transportation']", "Transportation Tab", true,true);
		
		RC_Global.createNode(driver,"Validate section : Transporation Tab");
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Vehicle Pickup Location and Contact", false);
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Consignment Details", false);
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Notes", false);
		
		RC_Global.createNode(driver,"Vehicle Pickup Location and Contact: Section Validation");
		RC_Global.verifyScreenComponents(driver, "label", "Pickup Location Type", false);
		RC_Global.verifyScreenComponents(driver, "label", "Address 1", false);
		RC_Global.verifyScreenComponents(driver, "label", "Address 2", false);
		RC_Global.verifyScreenComponents(driver, "label", "City", false);
		RC_Global.verifyScreenComponents(driver, "label", "State", false);
		RC_Global.verifyScreenComponents(driver, "label", "Zip Code", false);
		RC_Global.verifyScreenComponents(driver, "label", "Comments", false);
		RC_Global.verifyScreenComponents(driver, "label", "Pickup Contact First Name", false);
		RC_Global.verifyScreenComponents(driver, "label", "Pickup Contact Last Name", false);
		RC_Global.verifyScreenComponents(driver, "label", "Pickup Contact Email", false);
		RC_Global.verifyScreenComponents(driver, "label", "Pickup Contact Phone", false);
		RC_Global.verifyScreenComponents(driver, "label", "Ext", false);
		RC_Global.verifyScreenComponents(driver, "label", "Alternate Phone", false);
		RC_Global.verifyScreenComponents(driver, "label", "Ext", false);

		WebElement PhoneNum = driver.findElement(By.xpath("(//input[@id='phone1'])[2]"));
		PhoneNum.clear();
		RC_Global.enterInput(driver, "(243) 446-5555",PhoneNum, true, false);
		driver.findElement(By.xpath("(//input[@id='email1'])[2]")).clear();
	    RC_Global.clickButton(driver, "Send to Auction", false,true); 
	    RC_Global.waitElementVisible(driver, 30, "//h4[contains(text(),'Upon submission')]", "Popup message", true,true);
	    RC_Global.clickButton(driver, "Submit", false,true);
	    RC_Global.verifyDisplayedMessage(driver,"Successfully Updated!", true);
	    
		RC_Global.clickUsingXpath(driver, "//a[text()='Manage Sale']", "Manage Sale", true,true);
		String ManageSalePhoNUm = driver.findElement(By.xpath("(//input[@placeholder='Phone' and @disabled='disabled'])[2]")).getAttribute("value");
		if(ManageSalePhoNUm.contains("(243) 446-5555"))
			queryObjects.logStatus(driver, Status.PASS, "Vehicle Information is matching", "", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Vehicle Information is not matching", "", null);

		RC_Global.clickUsingXpath(driver, "//a[text()='Transportation']", "Transportation Tab", true,true);
		RC_Global.createNode(driver,"Consignment Details section Validation");
		RC_Global.verifyScreenComponents(driver, "label", "Consigner Name:", false);
		RC_Global.verifyScreenComponents(driver, "label", "Consigner Address:", false);
		RC_Global.verifyScreenComponents(driver, "label", "Contact Name:", false);
		RC_Global.verifyScreenComponents(driver, "label", "Contact Email:", false);
		RC_Global.verifyScreenComponents(driver, "label", "Contact Phone:", false);
		RC_Global.verifyScreenComponents(driver, "label", "Secured Date:", false);
		RC_Global.verifyScreenComponents(driver, "label", "Sold Date:", false);
		RC_Global.verifyScreenComponents(driver, "label", "Condition Report Mileage:", false);
		RC_Global.verifyScreenComponents(driver, "label", "Billing:", false);
		
		
		List<WebElement> SecureDateIn = driver.findElements(By.xpath("//input[@placeholder='Secured Date']"));
		List<WebElement> CondtnReMil = driver.findElements(By.xpath("//input[@name='ConditionReportMileage']"));		
		if(SecureDateIn.size()==1) {
			if (driver.findElement(By.xpath("//input[@placeholder='Secured Date']")).isEnabled()) {
				driver.findElement(By.xpath("//input[@placeholder='Secured Date']")).sendKeys(RC_Manage.AddDateStr(0,"MM/dd/yyyy" , "minute", null, ""));
				queryObjects.logStatus(driver, Status.PASS, "Secured Date Field is displayed as the enabled", "User is able to enter Date value", null);
				RC_Manage.isValidDateFormat(driver, "MM/dd/yyyy", "Secured Date", driver.findElement(By.xpath("//input[@placeholder='Secured Date']")).getAttribute("value"), false);
			} else {
				queryObjects.logStatus(driver, Status.FAIL, "Secured Date Field is disabled", "User is not able to enter value", null);
			}
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "Secured Date Field is not displayed", "", null);
		RC_Global.createNode(driver, "Condition Report Mileage Field Data Type Validation");
		if(CondtnReMil.size()==1) {
			if (driver.findElement(By.xpath("//input[@name='ConditionReportMileage']")).isEnabled()) {				
				driver.findElement(By.xpath("//input[@name='ConditionReportMileage']")).sendKeys("A12B$");
				queryObjects.logStatus(driver, Status.PASS, "Condition Report Mileage Field is enabled", "User is able to value in Condition Report Mileage", null);
				if (driver.findElement(By.xpath("//input[@name='ConditionReportMileage']")).getAttribute("value").contains("12")) {
					queryObjects.logStatus(driver, Status.PASS, "Enter value in Condition Report Mileage Field ", "Condition Report Mileage accepts only numeric value", null);
				} else {
					queryObjects.logStatus(driver, Status.FAIL, "Enter value in Condition Report Mileage Field", "Condition Report Mileage accepts values other than numeric values", null);
				}
			} else {
				queryObjects.logStatus(driver, Status.FAIL, "Condition Report Mileage Field is disabled", "User is not able to enter value", null);
			}
		} else
		queryObjects.logStatus(driver, Status.FAIL, "Condition Report Mileage Field is not displayed", "User is not able to enter numeric value in Condition Report Mileage", null);

		//history
		RC_Global.createNode(driver, "History Validation");
		RC_Global.clickUsingXpath(driver, "(//button[text()='History'])[3]", "History Hyperlink", true,false);
		RC_Global.waitUntilPanelVisibility(driver, "Merchants to Sell - History", "TV", true,false);
		RC_Global.panelAction(driver,"close", "View Remarketing Requests", true, false);
		RC_Global.panelAction(driver,"expand", "Merchants to Sell - History", true, false);
		List<WebElement> HistoryRec = driver.findElements(By.xpath("//span[text()='Transportation Vehicle Pickup']"));
		HistoryRec.get(0).click();
		Thread.sleep(1000);
		String NewPhoneNum = driver.findElement(By.xpath("//div[text()='2434465555']")).getText();
		if(NewPhoneNum.contains("2434465555"))
		queryObjects.logStatus(driver, Status.PASS, "Updated data is reflecting in History", "", null);
		else
		queryObjects.logStatus(driver, Status.FAIL, "Updated data is not reflecting in History", "", null);
		
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
	
}
