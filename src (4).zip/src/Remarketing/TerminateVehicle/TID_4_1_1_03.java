package Remarketing.TerminateVehicle;

import java.util.ArrayList;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;
import tools.TotalView.RC_Remarketing;

public class TID_4_1_1_03 {
	public void TerminateVehicle_VerifyCVT_MerchantsToSell(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		ArrayList<String> getWindows = new ArrayList<String>(driver.getWindowHandles());
		String displaymessage = "Please see the attached, the Odometer and Damage Disclosure for 236-Patterson Dental Supply - Unit #611831.";
		String displayedmessage = "Please see the attached Remarketing Request Confirmation for 236-Patterson Dental Supply - Unit # 611831.";
		String alertmessage = "Odometer reading entered is less than Latest Odometer for this vehicle.  Click �OK� to submit termination or click �Cancel� to change the entered Odometer reading.";
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		WebDriverWait wait = new WebDriverWait(driver,50);
		String [] contactInfoLabel = {"Pickup Location Type","Address 1","City","State","Zip Code","Pickup Contact First Name","Pickup Contact Last Name","Pickup Contact Email","Pickup Contact Phone"};
		String [] contactInfo = {"Residence","1461 Bluejay Rd","Abington","PA","19001-2207","GAIL","BOYD","","(585) 472-4488"};
			
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Remarketing", "Terminate Vehicle", "");
		RC_Global.enterCustomerNumber(driver, "LS010143", "", "", true);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.waitElementVisible(driver,30,"//tbody//tr[1]","Grid Load",true,false);
		RC_Remarketing.selectRowWithAgreementTypeFromGrid(driver,"Open End",true);
	    RC_Global.clickButton(driver, "Select Vehicle",true,true);
	    RC_Manage.waitUntilMethods(driver, "(//button[text()='Select Vehicle '])[1]/div[@ng-show='vm.isSelectingVehicle']","class","ng-hide", "attribute visible");
	   // RC_Global.waitElementVisible(driver, 30, "(//h5[span[text()='Terminate Vehicle']])[2]", "TermateVehicle Page", true);
	    try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//h5[span[text()='Terminate Vehicle']])[2]")));}
		catch(Exception e) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Vehicle Pickup Information']")));}
	    Thread.sleep(2000);
		RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='Terminate Vehicle']])[1]", false,false);
		try {
			driver.findElement(By.xpath("//h5[span[text()='Vehicle Pickup Information']]/i[contains(@class,'fa-expand') and @ng-click='maximize(panel)']")).click();
			Thread.sleep(3000);
		}
		catch(Exception e) {
		    RC_Global.panelAction(driver, "expand", "Terminate Vehicle", true,false);
		    RC_Global.clickUsingXpath(driver, "//div[2]/div/input[@type='radio']", "Merchants to Sell", true,true);
		    RC_Global.clickButton(driver, "Next", false,true);
		}
	    
	     RC_Global.clickUsingXpath(driver, "(//label[text()=' Driver/Pool '])[1]", "Driver/Pool", true,true);
	     RC_Remarketing.vehicleProgramTermination(driver, "Yes", "No", "No", true);
	     RC_Remarketing.enterVehiclePickupLocationAndContactInformation(driver, contactInfoLabel, contactInfo, true);
	     
	     RC_Global.clickUsingXpath(driver, "(//button[text()='Next'])[1]", "Next", true,true);
	     Thread.sleep(2000);
	     if(driver.findElements(By.xpath("//span[text()=' address entered.']")).size()>0){
	            RC_Global.clickButton(driver, "Save As Entered", false,true);
	        }
	     RC_Global.waitUntilPanelVisibility(driver, "Disclosure Agreement", "TV", false,false);
	     RC_Global.validateHeaderName(driver, "Disclosure Agreement",false);
	     
	     WebElement nameElement = driver.findElement(By.xpath("//input[@placeholder='Odometer']"));
     	 RC_Global.enterInput(driver, RandomStringUtils.randomNumeric(4), nameElement,true,false);
     	
	     RC_Remarketing.damageDisclosure(driver,"Yes", "No", "No", "No", "No", "No", "",true);
	     RC_Global.clickButton(driver, "Open", false,true);
		    Thread.sleep(2000);
		    driver.switchTo().window(getWindows.get(0));
		    Thread.sleep(1000);
		    RC_Global.clickButton(driver, "Email",true,true);
		    RC_Global.waitElementVisible(driver, 30, "//h3[text()='Disclosure Agreement Message']", "Email Documents",false,false);
		    RC_Global.verifyDisplayedMessage(driver,displaymessage,true);
	     RC_Global.clickButton(driver, "Cancel",true,false);
	     RC_Global.clickButton(driver, "Submit Vehicle Termination", true,true);
	     RC_Manage.waitUntilMethods(driver, "//div[@ng-show='vm.isSubmitting']","class","ng-hide", "attribute visible");
	     Thread.sleep(1000);
	     if(driver.findElements(By.xpath("//h3[text()='Confirm']")).size()>0){
	    	 RC_Global.verifyDisplayedMessage(driver,alertmessage,true);
	    	 RC_Global.clickUsingXpath(driver, "(//button[normalize-space(text()='OK')])[1]", "Ok button", true,false);
	    	 Thread.sleep(3000);
	        }
	     
	     RC_Global.waitUntilPanelVisibility(driver, "Driver Message", "TV", false, false);
	     RC_Global.validateHeaderName(driver, "Driver Message",false);
	     RC_Global.clickButton(driver, "Email",true,true);
	 	Thread.sleep(2000);
	     RC_Global.waitElementVisible(driver, 30, "//h3[text()='Email Driver Message']", "Email Documents",false,false);
	     Thread.sleep(1000);
	     RC_Global.scrollById(driver, "(//button[normalize-space(text()='Cancel')])[2]");
	     RC_Global.clickUsingXpath(driver, "(//button[normalize-space(text()='Cancel')])[2]", "Cancel",false,false);
	     RC_Global.clickButton(driver, "Next", false,true);
	     RC_Global.waitUntilPanelVisibility(driver, "Confirmation", "TV", false,false);
	     RC_Global.validateHeaderName(driver, "Confirmation",false);
	     RC_Global.clickButton(driver, "Open", false,true);
	     Thread.sleep(4000);
	     driver.switchTo().window(getWindows.get(0));
	     RC_Global.clickButton(driver, "Email",true,true);
	 	Thread.sleep(2000);
	     RC_Global.waitElementVisible(driver, 30, "//h3[text()='Request Summary Message']", "Email Documents",false,false);
	     RC_Global.verifyDisplayedMessage(driver,displayedmessage,true);
	     Thread.sleep(1000);
	     RC_Global.clickButton(driver, "Cancel",true,false);
	     RC_Global.clickButton(driver, "Terminate Another Vehicle",true,true);
	     RC_Global.waitUntilPanelVisibility(driver, "Terminate Vehicle", "TV", false,false);
	     RC_Global.panelAction(driver, "close", "Terminate Vehicle",false,false);
	     	 
	     queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
	
}
