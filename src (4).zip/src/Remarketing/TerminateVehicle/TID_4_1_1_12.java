package Remarketing.TerminateVehicle;

import java.util.ArrayList;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_4_1_1_12 {
	public void TerminateVehicle_ValidateVehicleStatusSearchFilters  (WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Remarketing", "Terminate Vehicle", "");
		RC_Global.validateHeaderName(driver, "Terminate Vehicle", true);

		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Active lease", true);
		RC_Global.clickButton(driver, "Search", false,false);
		RC_Global.waitElementVisible(driver, 60, "//table//tbody//tr", "Search Grid Record", false,false);
		RC_Global.validateTheGridColumnContent(driver,"Vehicle Status","Active lease","",false);

		RC_Global.clickButton(driver, "Reset", false,false);
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Active services only", true);
		RC_Global.clickButton(driver, "Search", false,false);
		RC_Global.waitElementVisible(driver, 60, "//table//tbody//tr", "Search Grid Record", false,false);
		RC_Global.validateTheGridColumnContent(driver,"Vehicle Status","Active services only","",false);

		RC_Global.clickButton(driver, "Reset", false,false);
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Pending Activation", true);
		RC_Global.clickButton(driver, "Search", false,false);
		RC_Global.waitElementVisible(driver, 60, "//table//tbody//tr", "Search Grid Record", false,false);
		RC_Global.validateTheGridColumnContent(driver,"Vehicle Status","Pending Activation","",false);

		RC_Global.clickButton(driver, "Reset", false,false);
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Pending termination", true);
		RC_Global.clickButton(driver, "Search", false,false);
		RC_Global.waitElementVisible(driver, 60, "//table//tbody//tr", "Search Grid Record", false,false);
		RC_Global.validateTheGridColumnContent(driver,"Vehicle Status","Pending termination","",false);
		//RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='Terminate Vehicle']])[1]", false,true);
		
		//RC_Global.logout(driver, false);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
