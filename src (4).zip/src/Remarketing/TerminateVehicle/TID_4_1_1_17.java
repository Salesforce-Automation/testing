package Remarketing.TerminateVehicle;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;
import tools.TotalView.RC_Remarketing;

public class TID_4_1_1_17 {
	
	public static String Name = "Test Sample";
	public void TerminateVehicle_TerminateServicesOnlyOnTitleManagement(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		
		String[] buyerInfoLabel = {"","Name", "Contact First Name", "Contact Last Name", "Address 1", "City", "State", "Zip Code", "Phone"};
		String[] buyerInfo = {"","Christal Beard", "Christal", "Beard", "2909 RING RD", "ELIZABETHTOWN", "KY", "42701-9119", "(308) 440-3896"};
		ArrayList<String> getWindows = new ArrayList<String>(driver.getWindowHandles());
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Remarketing", "Terminate Vehicle", "");
		RC_Global.enterCustomerNumber(driver, "LS010161", "", "",true);
		RC_Global.clickButton(driver, "Search",true,true);
		RC_Global.waitElementVisible(driver,30,"//tbody//tr[1]","Grid Row",true,false);
		
		RC_Global.clickUsingXpath(driver, "//div/span[text()='Agreement Type']", "Sort Agreement Type", false,false);
		RC_Global.clickUsingXpath(driver, "//div/span[text()='Agreement Type']", "Sort Agreement Type", false,false);
		
		RC_Remarketing.selectRowWithAgreementTypeFromGrid(driver, "Services Only", false);
		RC_Global.clickUsingXpath(driver, "//tbody//tr[1]/td[1]", "Select Grid Row", false,false);
		
		String DriverFullName = driver.findElement(By.xpath("//tbody//tr[1]/td[9]")).getText();
		String DriverFirstName = DriverFullName.split(" ")[0];
		String DriverLastName = DriverFullName.split(" ")[1];
		
		RC_Remarketing.selectRowWithAgreementTypeFromGrid(driver,"Services Only",true);
		RC_Global.clickButton(driver, "Select Vehicle", true,true);
		RC_Manage.waitUntilMethods(driver, "(//button[text()='Select Vehicle '])[1]/div[@ng-show='vm.isSelectingVehicle']","class","ng-hide", "attribute visible");
		
		Thread.sleep(2000);
		RC_Global.panelAction(driver,"xpathclose","(//h5[span[text()='Terminate Vehicle']])[1]",false,false);
		RC_Global.panelAction(driver,"expand","Terminate Vehicle",true,false);
		
		RC_Global.waitElementVisible(driver,30,"(//label[contains(text(),'Terminate Services Only')]/../input[contains(@type,'radio')])[1]","Radio Button",true,true);
		boolean TerminateService= RC_Global.waitElementVisible(driver,30,"(//label[contains(text(),'Terminate Services Only')]/../input[contains(@type,'radio')])[1]","Radio Button",true,false);
		if(TerminateService==true)
			queryObjects.logStatus(driver, Status.INFO, "Terminate Service only Radio Button", "Present", null);
		
		boolean MerchantsSellAndTerminate =  RC_Global.waitElementVisible(driver,30,"(//label[contains(text(),'Merchants to Sell and Terminate Services Only')]/../input[contains(@type,'radio')])[1]","Radio Button",true,false);
		if(MerchantsSellAndTerminate=true)
			queryObjects.logStatus(driver, Status.INFO, "Merchants to Sell and Terminate Services Only Radio Button", "Present", null);
		
		RC_Global.radioButton(driver, "Terminate Vehicle", "Terminate Services Only", false);
	//	RC_Global.clickUsingXpath(driver, "(//label[contains(text(),'Terminate Services Only')]/../input[contains(@type,'radio')])[1]", "Radio Button", true);
		RC_Global.clickButton(driver, "Next", true,true);
		RC_Global.waitUntilPanelVisibility(driver,"Services Termination Request","TV",true,false);
		
		 RC_Global.createNode(driver,"Validation of Title Management");
		 String TitleManagement = driver.findElement(By.xpath("//div[1]/label[text()='Title Management']//ancestor::div[2]//span")).getText();
		 if(TitleManagement.equalsIgnoreCase("Yes"))
			 queryObjects.logStatus(driver,Status.PASS,"'Title Management' as value",  TitleManagement, null);
		 else	
			 queryObjects.logStatus(driver,Status.INFO,"'Title Management' as ", "Empty value/ No" , null);
		 
		 
		 //Validate the 'Services Termination Request' screen sections -- Missing
		 
		 RC_Global.createNode(driver,"Billing Details Section");
		 String BillDetail1 = driver.findElement(By.xpath("(//fieldset//legend[contains(text(),'Billing Details')]/../following::label[contains(text(),'In Service Date:')][1]/../following::div//span)[1]")).getText();
		 String BillDetail2 = driver.findElement(By.xpath("(//fieldset//legend[contains(text(),'Billing Details')]/../following::label[contains(text(),'Months in Service:')][1]/../following::div//span)[1]")).getText();
		 
		 queryObjects.logStatus(driver, Status.PASS, "Billing Details - In Service Date", ""+BillDetail1,null );
		 queryObjects.logStatus(driver, Status.PASS, "Billing Details - Months in Service:", ""+BillDetail2,null );
		 
		 RC_Global.createNode(driver, " Validation of 'Title Mailing Information' Section for Title Management enrolled ");
	        for(int i=1; i<=11;i++)
	        {
	        	String fields = driver.findElement(By.xpath("(//mailing-information//div[4]/div["+i+"]/div[1]/label)[2]")).getText();
	        	if(fields!=null)
	        	queryObjects.logStatus(driver, Status.PASS, "Title Mailing Information Section fields", fields,null );
	        	else
	        	queryObjects.logStatus(driver, Status.INFO, "Title Mailing Information Section fields", "Not Found",null );	
	        }
	        
	        RC_Global.createNode(driver, "Validate the Message displayed under Vehicle Program termination Section");
			String Driver = driver.findElement(By.xpath("//div[1][label[normalize-space(text())='Driver Status:']]/../div[2]/div[1]")).getText();
			String Fuel = driver.findElement(By.xpath("//div[1][label[normalize-space(text())='Fuel:']]/../div[2]/div[1]")).getText();
			String Personaluse = driver.findElement(By.xpath("//div[1][label[normalize-space(text())='Personal Use:']]/../div[2]/div[1]")).getText();
			
			queryObjects.logStatus(driver, Status.INFO, "Driver Status: ", Driver, null);
			queryObjects.logStatus(driver, Status.INFO, "Fuel: ", Fuel, null);
			queryObjects.logStatus(driver, Status.INFO, "Personal Use: ", Personaluse, null);
			
			RC_Global.createNode(driver, "Validation of Button in services termination request");
			RC_Global.buttonStatusValidation(driver, "Back", "Presence", false);
			RC_Global.buttonStatusValidation(driver, "Submit Vehicle Termination", "Presence", false);
			RC_Manage.waitUntilMethods(driver, "//div[@ng-show='vm.isSubmitting']","class","ng-hide", "attribute visible");
		    Thread.sleep(1000);
		RC_Remarketing.vehicleProgramTermination(driver, "Yes", "Yes", "No", false);
		Thread.sleep(2000);
		if(TitleManagement.equalsIgnoreCase("Yes")) {
			RC_Global.createNode(driver, "Enter the Title Mailing information data values");
			WebElement element = driver.findElement(By.xpath("(//input[contains(@ng-model,'mailingVehicleTerminationLocation.BusinessName') and @placeholder='Name'])[2]"));
			Name = "Test Sample";
			RC_Global.enterInput(driver, Name, element  , false,false);
			
			String FirstName = "Test";
	        WebElement element1= driver.findElement(By.xpath("(//input[contains(@ng-model,'mailingVehicleTerminationContact.FirstName') and @placeholder='First Name'])[2]"));
			RC_Global.enterInput(driver, FirstName, element1, false,false);
			
			String LastName = "Sample";
			WebElement element2= driver.findElement(By.xpath("(//input[contains(@ng-model,'mailingVehicleTerminationContact.LastName') and @placeholder='Last Name'])[2]"));
			RC_Global.enterInput(driver, LastName, element2, false,false);
			
			String Address1 = "1031 Mendota Heights Rd";
			RC_Global.enterInput(driver, Address1, driver.findElement(By.xpath("(//input[contains(@ng-model,'mailingVehicleTerminationLocation.AddressLine1Text') and @placeholder='Address'])[2]")), true,false);
			String city = "Saint Paul";
			RC_Global.enterInput(driver, city, driver.findElement(By.xpath("(//input[contains(@ng-model,'mailingVehicleTerminationLocation.AddressCityName') and @placeholder='City'])[2]")), true,false);
		
			 if(driver.findElements(By.xpath("(//select[contains(@ng-model,'mailingVehicleTerminationLocation.AddressStateCode') and @name='state'])[2]")).size()>0)
			 {
				 driver.findElement(By.xpath("(//select[contains(@ng-model,'mailingVehicleTerminationLocation.AddressStateCode') and @name='state'])[2]")).click();
				 driver.findElement(By.xpath("(//select[contains(@ng-model,'mailingVehicleTerminationLocation.AddressStateCode') and @name='state'])[2]/option[text()='MN']")).click();
				 String state =  driver.findElement(By.xpath("(//select[contains(@ng-model,'mailingVehicleTerminationLocation.AddressStateCode') and @name='state'])[2]/option[text()='MN']")).getText();
			 }
			 String Zipcode = "55120-1419";
			 RC_Global.enterInput(driver, Zipcode, driver.findElement(By.xpath("(//input[contains(@ng-model,'mailingVehicleTerminationLocation.AddressZipCode') and @placeholder='Zip Code'])[2]")), true,false);
			 String Phone = "(651) 686-1762";
			 RC_Global.enterInput(driver, Phone, driver.findElement(By.xpath("(//input[contains(@ng-model,'mailingVehicleTerminationContact.PhoneNumberFormatted') and @placeholder='Phone'])[2]")), true,false);
		}
		 RC_Global.clickButton(driver, "Back",true,true);
		 RC_Global.clickButton(driver, "Next",true,true);
		 RC_Global.clickUsingXpath(driver, "(//button[text()='Submit Vehicle Termination'])[1]", "Submit Vehicle Termination button", false,true);
		 RC_Manage.waitUntilMethods(driver, "//div[@ng-show='vm.isSubmitting']","class","ng-hide", "attribute visible");
		 Thread.sleep(1000);
		 if((driver.findElements(By.xpath("//span[text()=' address entered.']")).size()>0))
		 {
		 RC_Global.clickButton(driver, "Save As Entered", true, false);
		 Thread.sleep(2000);}
		 RC_Global.verifyDisplayedMessage(driver, "Successfully Submitted", false);
		 RC_Global.waitUntilPanelVisibility(driver,"Confirmation","TV",true,false);
		 
		 RC_Global.createNode(driver, "Validation of Current Sale Status");
		 String currentSaleStatus = driver.findElement(By.xpath("//div[1]/label[text()='Current Sale Status']//ancestor::div[2]//span")).getText();
		 if(currentSaleStatus.equalsIgnoreCase("Submitted"))
			 queryObjects.logStatus(driver,Status.PASS,"'Current Sale Status' as value",  currentSaleStatus, null);
		 else
			 queryObjects.logStatus(driver,Status.INFO,"'Current Sale Status' as ", "Empty value" , null);
		 
		 
		 RC_Global.createNode(driver, "Validation of Terminate Request Summary section");
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Termination Request Summary", "Request Submitted On:", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Termination Request Summary", "Confirmation Number:", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Termination Request Summary", "Request Submitted By:", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Termination Request Summary", "Driver/Pool Name:", false);
		 
		 RC_Global.createNode(driver, "Validation of Vehicle Program Termination section");
		 String VPTDriver = driver.findElement(By.xpath("(//div/legend[text()='Vehicle Program Termination']/../following::div/label)[1]")).getText();
		 String VPTfuel = driver.findElement(By.xpath("(//div/legend[text()='Vehicle Program Termination']/../following::div/label)[2]")).getText();
		 String VPTpersonal = driver.findElement(By.xpath("(//div/legend[text()='Vehicle Program Termination']/../following::div/label)[3]")).getText();
			
		 String driverValue = driver.findElement(By.xpath("(//div/legend[text()='Vehicle Program Termination']/../following::div/label)[1]//ancestor::div[2]//span")).getText();
		 String fuelValue = driver.findElement(By.xpath("(//div/legend[text()='Vehicle Program Termination']/../following::div/label)[2]//ancestor::div[2]//span")).getText();
		 String personalValue = driver.findElement(By.xpath("(//div/legend[text()='Vehicle Program Termination']/../following::div/label)[3]//ancestor::div[2]//span")).getText();
		 
		 queryObjects.logStatus(driver,Status.PASS,"Vehicle Program Termination section has label '"+VPTDriver+"' with value",driverValue, null);
		 queryObjects.logStatus(driver,Status.PASS,"Vehicle Program Termination section has label '"+VPTfuel+"' with value",fuelValue, null);
		 queryObjects.logStatus(driver,Status.PASS,"Vehicle Program Termination section has label '"+VPTpersonal+"' with value",personalValue, null);
			
		 RC_Global.createNode(driver, "Validation of Title Mailing Information section");
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Title Mailing Information", "Contact First Name:", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Title Mailing Information", "Contact Last Name:", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Title Mailing Information", "Name:", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Title Mailing Information", "Address 1:", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Title Mailing Information", "Address 2:", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Title Mailing Information", "City:", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Title Mailing Information", "State:", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Title Mailing Information", "Zip Code:", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Title Mailing Information", "Phone:", false);
		 RC_Remarketing.screenSectionDetailsValidation(driver, "Title Mailing Information", "Email:", false);
		 
		 RC_Global.clickButton(driver, "Open", true,true);
		 Thread.sleep(2000);
		    driver.switchTo().window(getWindows.get(0));
		    RC_Global.clickButton(driver, "Email", true,true);
		    RC_Global.buttonStatusValidation(driver, "Send", "Enable", false);
		    RC_Global.clickButton(driver, "Cancel",true,false);		     
		    RC_Global.logout(driver, false);
		    
		    queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);    
		     
	}
}
