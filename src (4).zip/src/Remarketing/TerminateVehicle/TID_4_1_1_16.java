package Remarketing.TerminateVehicle;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;
import tools.TotalView.RC_Remarketing;

public class TID_4_1_1_16 {

	public void TerminateVehicle_VerifyVehicleProgramTerminationBasedOnEnrollment(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		String alertmessage = "Odometer reading entered is less than Latest Odometer for this vehicle.  Click �OK� to submit termination or click �Cancel� to change the entered Odometer reading.";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
		RC_Global.enterCustomerNumber(driver, "LS008737", "", "", true);
		RC_Global.waitElementVisible(driver, 60, "//a[text()='Customer Summary']", "Customer Summary",true,false);
		RC_Global.clickUsingXpath(driver, "//a[text()='Fuel']", "Fuel Tab", false,true);
        RC_Global.waitElementVisible(driver, 60, "//label[text()='Enrolled in Fuel']", "Fuel",true,false);
        if(driver.findElements(By.xpath("//label[text()='Enrolled in Fuel']/../div//button[text()='Yes']")).size()>0) {
            String FuelEnrollment= "";
            FuelEnrollment= driver.findElement(By.xpath("//label[text()='Enrolled in Fuel']/../div//button[contains(@class,'disabled-active-button') and normalize-space(text())='Yes']")).getText();
            queryObjects.logStatus(driver, Status.INFO, "Enrollment in Fuel as ", FuelEnrollment, null);
        }
       
        RC_Global.clickUsingXpath(driver, "//a[text()='Personal Use']", "Personal Use Tab", false,true);
        RC_Global.waitElementVisible(driver, 60, "//legend[text()='Personal Use']", "Personal Use",true,false);
        if(driver.findElements(By.xpath("//label[contains(text(),'Enrolled In Personal Use')]/../div//button[contains(@class,'disabled-active-button') and normalize-space(text())='Yes']")).size()>0) {
            String PersonalUseEnrollment= "";
            PersonalUseEnrollment= driver.findElement(By.xpath("//label[contains(text(),'Enrolled In Personal Use')]/../div//button[normalize-space(text())='Yes']")).getText();
            queryObjects.logStatus(driver, Status.INFO, "Enrollment in Personal Use as ", PersonalUseEnrollment, null);
        }
        
		RC_Global.clickUsingXpath(driver, "//a[text()='Remarketing']", "Remarketing Tab", true,true);
		if(driver.findElements(By.xpath("//label[text()='Enrolled In Remarketing *']/../div//label[text()='Yes']")).size()>0) {
            String RemarketingEnrollment= "";
            RemarketingEnrollment= driver.findElement(By.xpath("//label[contains(text(),'Enrolled In Remarketing')]/../div//label[contains(@class,'disabled-active-button') and normalize-space(text())='Yes']")).getText();
            queryObjects.logStatus(driver, Status.INFO, "Enrollment in Remarketing as ", RemarketingEnrollment, null);
        }

		
		List<WebElement> Toggle = driver.findElements(By.xpath("(//label[normalize-space((text())='No') and (contains(@class, 'disabled-active-button'))])[4]"));
    	Thread.sleep(2000);
    	if(Toggle.size()>0) {
    		queryObjects.logStatus(driver,Status.INFO,"Optional Driver message for Vehicle Pickup Button is", "No Enabled", null);}
    	else{
    		queryObjects.logStatus(driver,Status.INFO,"Optional Driver message for Vehicle Pickup Button is", "No Disabled", null);
    	    RC_Global.clickUsingXpath(driver, "(//label[text()='No'])[4]", "Enrolled No", false,false);
		    RC_Global.clickButton(driver, "Save", true,true);
		    RC_Global.verifyDisplayedMessage(driver, "Update successful",true);}
    	
	
		RC_Global.panelAction(driver, "close", "Customer Administration", true,false);
		RC_Global.navigateTo(driver, "Remarketing", "Terminate Vehicle", "");
		RC_Global.enterCustomerNumber(driver, "LS008737", "", "", true);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.waitElementVisible(driver,30,"//tbody//tr[1]","Grid Row",true,false);
		RC_Remarketing.selectRowWithAgreementTypeFromGrid(driver,"Open End",true);
	    RC_Global.clickButton(driver, "Select Vehicle",true,true);
	    RC_Manage.waitUntilMethods(driver, "(//button[text()='Select Vehicle '])[1]/div[@ng-show='vm.isSelectingVehicle']","class","ng-hide", "attribute visible");
	    RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='Terminate Vehicle']])[1]", false,false);
	    RC_Global.waitUntilPanelVisibility(driver, "Terminate Vehicle", "TV", false,false);
	    RC_Global.panelAction(driver, "expand", "Terminate Vehicle", true,false);
	    RC_Global.clickUsingXpath(driver, "//div[2]/div/input[@type='radio']", "Merchants to Sell", true,true);
	    RC_Global.clickButton(driver, "Next", false,true);
	    
	    RC_Global.createNode(driver, "Terminate Vehicle -- Vehicle Pickup Location and Contact Information");
	    RC_Global.scrollById(driver, "//legend[text()='Vehicle Pickup Location and Contact']");
	    RC_Global.selectDropdownOption(driver, "Pickup Location Type", "Residence", true,false);
	    WebElement element= driver.findElement(By.xpath("(//input[@placeholder='Address 1'])[1]"));
		RC_Global.enterInput(driver, "40A Commerce Way", element, true,false);
		WebElement element1= driver.findElement(By.xpath("(//div[label[normalize-space(text())='City']]/../div//input[contains(@ng-disabled,'VehiclePickupDetailsDisabled')])[1]"));
		RC_Global.enterInput(driver, "Totowa", element1, true,false);
	//	RC_Global.selectDropdownOption(driver, "State", "NJ", false);
		driver.findElement(By.xpath("(//select[@id='state'])[4]")).click();
		driver.findElement(By.xpath("(//select[@id='state'])[4]/option[text()='NJ']")).click();
//		WebElement elementst= driver.findElement(By.xpath("(//div[label[normalize-space(text())='State']]/../div//select[contains(@ng-disabled,'VehiclePickupDetailsDisabled')])[1]"));
//		RC_Global.enterInput(driver, "NJ", elementst, true);
		WebElement element2= driver.findElement(By.xpath("(//div[label[normalize-space(text())='Zip Code']]/../div//input[contains(@ng-disabled,'VehiclePickupDetailsDisabled')])[1]"));
		RC_Global.enterInput(driver, "07512-3106", element2, true,false);
		WebElement element3= driver.findElement(By.xpath("(//div[label[normalize-space(text())='Pickup Contact First Name']]/../div//input[contains(@ng-disabled,'VehiclePickupDetailsDisabled')])[1]"));
		RC_Global.enterInput(driver, "Daniel", element3, true,false);
		WebElement element4= driver.findElement(By.xpath("(//div[label[normalize-space(text())='Pickup Contact Last Name']]/../div//input[contains(@ng-disabled,'VehiclePickupDetailsDisabled')])[1]"));
		RC_Global.enterInput(driver, "Santiago", element4, true,false);
		WebElement phonenumber = driver.findElement(By.xpath("(//div[label[normalize-space(text())='Pickup Contact Phone']]/../div//input[contains(@ng-disabled,'VehiclePickupDetailsDisabled')])[1]"));
    	RC_Global.enterInput(driver, RandomStringUtils.randomNumeric(10), phonenumber,true,false);
    	JavascriptExecutor executor = (JavascriptExecutor) driver;
		Thread.sleep(1000);
		executor.executeScript("document.body.style.zoom = '80%'");
		Thread.sleep(2000);
		executor.executeScript("document.body.style.zoom = '100%'");
	    
//	    String[] contactInfoLabel = {"Pickup Location Type", "Address 1", "City", "State", "Zip Code", "Pickup Contact First Name", "Pickup Contact Last Name", "Pickup Contact Email", "Pickup Contact Phone"};
//        String[] contactInfo = {"Residence", "40A Commerce Way", "Totowa", "NJ", "07512-3106", "Daniel", "Santiago", "anthony.piszel@pattersondental.com", "(970) 378-2730"};
//        RC_Global.scrollById(driver, "//legend[text()='Vehicle Pickup Location and Contact']");
//	    RC_Remarketing.enterVehiclePickupLocationAndContactInformation(driver, contactInfoLabel, contactInfo, true);
		
		RC_Global.clickUsingXpath(driver, "(//label[contains(@name,'SecondaryContactIndicatorNo')])[1]", "Secondary Contact No", true,false);
	     RC_Remarketing.vehicleProgramTermination(driver, "Yes", "No", "No", true);
	     RC_Global.clickUsingXpath(driver, "(//button[text()='Next'])[1]", "Next", true,true);
	     if(driver.findElements(By.xpath("//span[text()=' address entered.']")).size()>0){
	            RC_Global.clickButton(driver, "Save As Entered", false,false);
	            Thread.sleep(2000);
	        }
	     
		   Thread.sleep(1000);
		   executor.executeScript("document.body.style.zoom = '30%'");
		   Thread.sleep(2000);
		   executor.executeScript("document.body.style.zoom = '100%'");
	     RC_Global.waitUntilPanelVisibility(driver, "Disclosure Agreement", "TV", false,false);
	     RC_Global.validateHeaderName(driver, "Disclosure Agreement",false);
	     
     	 RC_Remarketing.damageDisclosure(driver,"Yes", "No", "No", "No", "No", "No","10,000", true);
     	 RC_Global.clickButton(driver, "Submit Vehicle Termination", true,true);
	     	RC_Manage.waitUntilMethods(driver, "//div[@ng-show='vm.isSubmitting']","class","ng-hide", "attribute visible");
		    Thread.sleep(1000);
	     if(driver.findElements(By.xpath("//h3[text()='Confirm']")).size()>0){
	    	 RC_Global.verifyDisplayedMessage(driver,alertmessage,true);
	    	 RC_Global.clickUsingXpath(driver, "(//button[normalize-space(text()='OK')])[1]", "Ok button", true,false);
	    	 Thread.sleep(2000);
	        }
	     //Driver Message screen
	     List<WebElement> screenvalidation = driver.findElements(By.xpath("//h5//span[normalize-space(text())='Driver Message']"));
	    	Thread.sleep(2000);
	    	if(!(screenvalidation.size()>0)) {
	    		queryObjects.logStatus(driver,Status.PASS,"Driver Message screen not displayed due to optional driver message for Vehicle Pickup set to", "No", null);}
	    	else{
	    		queryObjects.logStatus(driver,Status.PASS,"Driver Message screen is", "displayed", null);
	    		RC_Global.clickButton(driver, "Next", true, true);}
	    	    
	   
	     RC_Global.waitUntilPanelVisibility(driver, "Confirmation", "TV", false,false);
	     RC_Global.validateHeaderName(driver, "Confirmation",false);
	     String requestsubmitdate = driver.findElement(By.xpath("(//div[1]/label[normalize-space(text())='Request Submitted On:']/following::div/span)[1]")).getText();
	     String requestsubmitby = driver.findElement(By.xpath("(//div[1]/label[normalize-space(text())='Request Submitted By:']/following::div/span)[1]")).getText();
	     String disclosedodometer = driver.findElement(By.xpath("//div[1]/label[normalize-space(text())='Disclosed Odometer:']/following-sibling::span")).getText();
     	 
	        queryObjects.logStatus(driver, Status.PASS, "Request submitted date of vehicle on---->", requestsubmitdate, null);
			queryObjects.logStatus(driver, Status.PASS, "Request submitted for vehicle by---->", requestsubmitby, null);
			queryObjects.logStatus(driver, Status.PASS, "Disclosure agreement odometer reading---->", disclosedodometer, null);
	     
	     queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
			
	}
}
