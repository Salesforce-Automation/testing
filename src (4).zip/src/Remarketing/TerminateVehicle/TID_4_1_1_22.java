package Remarketing.TerminateVehicle;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;
import tools.TotalView.RC_Remarketing;

public class TID_4_1_1_22 {
	public void TerminateVehicle_VerifyCVTClientDirectedSaleUsingExternalUser(WebDriver driver, BFrameworkQueryObjects queryObjects)throws Exception {
		
		String[] buyerInfoLabel = {"Buyer Type", "Buyer Name", "Contact First Name", "Contact Last Name", "Address 1", "City", "State", "Zip Code", "Phone"};
		String[] buyerInfo = {"Dealer/Remarketer", "Nancy Romero", "Deb", "Tanner", "13211 Merriman Rd", "Livonia", "MI", "48150-1826", "(970) 378-2030"};
		
		
		RC_Global.externalUserLogin(driver, "kentuckytest", "Yes");
		RC_Global.waitElementVisible(driver, 30, "//span[text()='Remarketing']", "Remarketing module", true, false);
		RC_Global.navigateTo(driver, "Remarketing", "Terminate Vehicle", "");
		
//		driver.findElement(By.xpath("//label[text()='Vehicle Status']/following-sibling::select/option[@class]")).click();
//		driver.findElement(By.xpath("//label[text()='Vehicle Status']/following-sibling::select/option[@class]")).click();
//		driver.findElement(By.xpath("//label[text()='Vehicle Status']/following-sibling::select/option[text()='Active services only']")).click();//Unselect 'Active services only'

		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Active lease", true);
		RC_Global.clickButton(driver, "Search", true,true);
		//RC_Global.waitElementVisible(driver, 30, "//table/tbody/tr[1]", "First record ", true, false);
		//RC_Global.clickUsingXpath(driver, "//table/tbody/tr[1]", "First record available in the grid", true, false);
		RC_Remarketing.selectRowWithAgreementTypeFromGrid(driver,"Open End",true);
		RC_Global.clickUsingXpath(driver, "(//button[normalize-space(text())='Select Vehicle'])[1]", "Select Vehicle", true,true);
		Thread.sleep(2000);
		RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='Terminate Vehicle']])[1]", false, false);
		RC_Global.panelAction(driver, "expand", "Terminate Vehicle", true, false);
		
		RC_Global.radioButton(driver, "Terminate Vehicle", "Client Directed Sale", true);
		
		RC_Global.clickButton(driver, "Next", true,true);
		RC_Global.waitUntilPanelVisibility(driver, "Title Information", "TV", true, false);
		
		RC_Global.enterInput(driver, "29500.00", driver.findElement(By.xpath("//input[@placeholder = 'Purchase Price']")), true,true);
		Thread.sleep(3000);
		RC_Remarketing.enterBuyerInformation(driver, buyerInfoLabel, buyerInfo, false);
		Thread.sleep(3000);
		RC_Global.clickUsingXpath(driver, "//label[@name = 'buttonLienHolderIndicatorNo' and text()='No']", "No for Lienholder Information", false,true);
		RC_Global.radioButton(driver, "Mailing Information", "Same as Buyer", true);
		
		RC_Global.clickUsingXpath(driver, "//label[@name = 'buttonEmployeeActiveWithCompanyIndicatorNo' and text()='No']", "Selected No for Active Employee", false, false);
		
		//Open, Email, Print]
		RC_Global.clickUsingXpath(driver, "//button[text()='Open']", "Open button", false,true);
		Thread.sleep(5000	);
		ArrayList<String> getWindows = new ArrayList<String>(driver.getWindowHandles());
		//driver.switchTo().window(getWindows.get(1)).close();
		driver.switchTo().window(getWindows.get(0));
		RC_Global.buttonStatusValidation(driver, "Print", "Enable", true);
		RC_Global.clickUsingXpath(driver, "//button[text()='Email']", "Email button", false,true);
		RC_Global.clickButton(driver, "Cancel", false, false);

		RC_Global.clickUsingXpath(driver, "(//button[text()='Next'])[2]", "Next button", true,true);

		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//p[contains(text(),'Entered Price is less than Current Book Value. Additional fees may apply')]")).size()>0)
			RC_Global.clickButton(driver, "OK", true, false);
		else if(driver.findElements(By.xpath("//p[contains(text(),'Entered Purchase Price is less than Current Book Value. Additional Fees may apply.')]")).size()>0)
//		else if(driver.findElements(By.xpath("//p[text()='Entered Purchase Price is less than Current Book Value. Additional Fees may apply.']")).size()>0)
			RC_Global.clickButton(driver, "OK", true, false);
		
		RC_Global.waitUntilPanelVisibility(driver, "Disclosure Agreement", "TV", true, false);
		RC_Remarketing.damageDisclosure(driver, "Yes", "No", "No", "No", "No", "No", "30000", true);
		//getWindows = new ArrayList<String>(driver.getWindowHandles());
		//Open, Email, Print
		RC_Global.clickUsingXpath(driver, "//button[text()='Open']", "Open button", false,true);
		Thread.sleep(5000);
		//driver.switchTo().window(getWindows.get(1)).close();
		driver.switchTo().window(getWindows.get(0));
		RC_Global.buttonStatusValidation(driver, "Print", "Enable", true);
		RC_Global.clickUsingXpath(driver, "//button[text()='Email']", "Email button", false,true);
		RC_Global.clickButton(driver, "Cancel", false, false);
		
		RC_Global.clickButton(driver, "Submit Vehicle Termination", true,true);
		RC_Manage.waitUntilMethods(driver, "//div[@ng-show='vm.isSubmitting']","class","ng-hide", "attribute visible");
	    Thread.sleep(1000);
		if(driver.findElements(By.xpath("//p[contains(text(),'Odometer reading entered is less than Latest Odometer for this vehicle.')]")).size()>0)
			RC_Global.clickButton(driver, "OK", true, false);
		
		RC_Global.waitUntilPanelVisibility(driver, "Confirmation", "TV", true, false);
		RC_Global.verifyDisplayedMessage(driver, "Successfully Submitted", false);
		
		//Open, Email, Print]
		RC_Global.clickUsingXpath(driver, "//button[text()='Open']", "Open button", false,true);
		Thread.sleep(5000);
	//	getWindows = new ArrayList<String>(driver.getWindowHandles());
	//	driver.switchTo().window(getWindows.get(1)).close();
		driver.switchTo().window(getWindows.get(0));
		RC_Global.buttonStatusValidation(driver, "Print", "Enable", true);
		RC_Global.clickUsingXpath(driver, "//button[text()='Email']", "Email button", false,true);
		RC_Global.clickButton(driver, "Cancel", false, false);
		
		RC_Global.clickButton(driver, "Terminate Another Vehicle", true,true);
		RC_Global.waitUntilPanelVisibility(driver, "Terminate Vehicle", "TV", true, false);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
