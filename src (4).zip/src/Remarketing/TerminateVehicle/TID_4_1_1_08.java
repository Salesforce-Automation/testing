package Remarketing.TerminateVehicle;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_4_1_1_08 {
	
	public void TerminateVehicle_ValidateTheResultGridAndHyperlinks(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		String columnName ="Customer Name;Unit Number;CVN;Vehicle Status;Year;Make;Model;VIN;Driver/Pool Name;Agreement Type;Fleet #;Fleet Name;Account #;Account Name;Sub-Account #;Sub-Account Name";
		
		String menu = "Remarketing";
        String firstSubMenu = "Terminate Vehicle";
		
		RC_Global.login(driver);
	    RC_Global.navigateTo(driver,menu,firstSubMenu, "");
		RC_Global.enterCustomerNumber(driver, "LS008737", "", "", true);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.waitElementVisible(driver,30,"//tbody//tr[1]","Grid Row",true,false);
		RC_Global.verifyColumnNames(driver, columnName,true);
		
		RC_Global.createNode(driver,"Select Grid row");
		RC_Global.clickUsingXpath(driver, "//div[2]//table/tbody/tr[1]","",true,false);
		RC_Global.createNode(driver,"Verify Unit Number as hypertext and navigate to Vehicle Details page");
		RC_Global.clickUsingXpath(driver,"//tbody/tr[1]/td[2]", "Unit Number",false,false);
		Thread.sleep(2000);
		RC_Global.validateHeaderName(driver, "Vehicle Details",false);
        RC_Global.panelAction(driver, "close","Vehicle Details",false,false);
        RC_Global.panelAction(driver, "expand", "Terminate Vehicle",false,false);
        
        RC_Global.createNode(driver,"Verify CVN displayed as hypertext and navigate to Vehicle Details page");
        RC_Global.clickUsingXpath(driver,"//tbody/tr[1]/td[3]", "CVN",false,false);
        Thread.sleep(2000);
        RC_Global.validateHeaderName(driver, "Vehicle Details",false);
        RC_Global.panelAction(driver, "close","Vehicle Details",false ,false);     
        RC_Global.panelAction(driver, "expand", "Terminate Vehicle",false,false);   
		
        RC_Global.createNode(driver,"Verify Driver/Pool Name displayed as hypertext and navigate to Driver Details page");
        RC_Global.clickUsingXpath(driver,"//tbody/tr[1]/td[9]", "Driver/Pool Name",false,false);
        Thread.sleep(2000);
        RC_Global.validateHeaderName(driver, "Driver Details",false);
        RC_Global.panelAction(driver, "close","Driver Details",false,false);
        RC_Global.panelAction(driver, "expand", "Terminate Vehicle",false,false);
        RC_Global.downloadAndVerifyFileDownloaded(driver, "Export", "Export to Excel Functionality",true);
        
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
