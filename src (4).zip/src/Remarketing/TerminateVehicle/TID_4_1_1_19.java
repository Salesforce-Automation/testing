package Remarketing.TerminateVehicle;

import java.util.ArrayList;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;
import tools.TotalView.RC_Remarketing;

public class TID_4_1_1_19 {
	
	public void TerminateVehicle_VerifyCVT_TerminateServicesOnlyusingExternaluser (WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
		
		
		RC_Global.externalUserLogin(driver, "tuffQAtestDontChange", "Yes");
		RC_Global.navigateTo(driver, "Remarketing", "Terminate Vehicle", "");
		RC_Global.validateHeaderName(driver, "Terminate Vehicle", true);
		RC_Global.clickButton(driver, "Search", false,true);
	
		RC_Global.waitElementVisible(driver,30,"//tbody//tr[1]","Grid Row",true,false);
		RC_Global.clickUsingXpath(driver, "//div/span[text()='Agreement Type']", "Sort Agreement Type", false,false);
		RC_Global.clickUsingXpath(driver, "//div/span[text()='Agreement Type']", "Sort Agreement Type", false,false);
		
		RC_Remarketing.selectRowWithAgreementTypeFromGrid(driver, "Services Only", true);
		RC_Global.clickButton(driver, "Select Vehicle", true,true);
		RC_Manage.waitUntilMethods(driver, "(//button[text()='Select Vehicle '])[1]/div[@ng-show='vm.isSelectingVehicle']","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 30, "(//h5/span[contains(text(), 'Terminate Vehicle')])[2]", "Terminate Vehicle Header", false,false);
		RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='Terminate Vehicle']])[1]", false,false);
		RC_Global.panelAction(driver, "expand", "Terminate Vehicle", false,false);
		
		RC_Global.createNode(driver, "Validate the button status before vehicle termination method selection");
		RC_Global.buttonStatusValidation(driver, "Next", "Disable", true);
		
		RC_Global.createNode(driver, "Vehicle Termination method selection");
		RC_Global.radioButton(driver, "Terminate Vehicle", "Terminate Services Only", false);
		
		ArrayList<String> getWindows = new ArrayList<String>(driver.getWindowHandles());
		
		
		RC_Global.createNode(driver, "Validate the button status after vehicle termination method selection");
		RC_Global.buttonStatusValidation(driver, "Next", "Enable", true);
		RC_Global.clickButton(driver, "Next", false,true);
		RC_Remarketing.vehicleProgramTermination(driver, "Yes", "No", "No", false);
		RC_Global.clickButton(driver, "Submit Vehicle Termination", true,true);
		RC_Manage.waitUntilMethods(driver, "//div[@ng-show='vm.isSubmitting']","class","ng-hide", "attribute visible");
	    Thread.sleep(1000);
		RC_Global.verifyDisplayedMessage(driver, "Successfully Submitted", false);
		Thread.sleep(2000);
		RC_Global.clickUsingXpath(driver, "//button[text()='Open']", "Open button", false,true);
		driver.switchTo().window(getWindows.get(0));
		RC_Global.buttonStatusValidation(driver, "Print", "Enable", true);
		RC_Global.clickUsingXpath(driver, "//button[text()='Email']", "Email button", false,true);
		RC_Global.clickButton(driver, "Cancel", false,false);
		RC_Global.clickButton(driver, "Terminate Another Vehicle", false,true);
		RC_Global.waitElementVisible(driver, 30, "//h5/span[contains(text(), 'Terminate Vehicle')]", "Terminate Vehicle Header", false,false);
		RC_Global.logout(driver, false);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}

