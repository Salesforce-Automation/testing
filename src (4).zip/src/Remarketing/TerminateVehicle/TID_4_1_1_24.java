package Remarketing.TerminateVehicle;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Remarketing;

public class TID_4_1_1_24 {
	public void TerminateVehicle_VerifyCVTClientDirectedSaleUsingExternalUser(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		String[] buyerInfoLabel = {"Buyer Type", "Buyer Name", "Contact First Name", "Contact Last Name", "Address 1", "City", "State", "Zip Code", "Phone"};
		String[] buyerInfo = {"Dealer/Remarketer", "Nancy Romero", "Deb", "Tanner", "13211 Merriman Rd", "Livonia", "MI", "48150-1826", "(970) 378-2030"};
		String AgreementType = "Closed End";
		String clientDirectedSaleError = "Please contact your Client Service Representative at 877-870-4999 or clientserviceteam@merchantsfleet.com for this request";
		
		RC_Global.externalUserLogin(driver, "TestUser09", "Yes");
//		RC_Global.login(driver);
		RC_Global.waitElementVisible(driver, 30, "//span[text()='Remarketing']", "Remarketing module", true, false);
		RC_Global.navigateTo(driver, "Remarketing", "Terminate Vehicle", "");
		
//		driver.findElement(By.xpath("//label[text()='Vehicle Status']/following-sibling::select/option[@class]")).click();
//		driver.findElement(By.xpath("//label[text()='Vehicle Status']/following-sibling::select/option[@class]")).click();
//		driver.findElement(By.xpath("//label[text()='Vehicle Status']/following-sibling::select/option[text()='Active services only']")).click();//Unselect 'Active services only'

		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Active lease", true);
		RC_Global.clickButton(driver, "Search", true,true);
		RC_Global.waitElementVisible(driver, 30, "//table/tbody/tr[1]", "First record ", true, false);
		driver.findElement(By.xpath("//table/tbody/tr[1]")).click();
		
		RC_Remarketing.selectRowWithAgreementTypeFromGrid(driver,AgreementType,true);
		RC_Global.clickUsingXpath(driver, "(//button[normalize-space(text())='Select Vehicle'])[1]", "Select Vehicle", true,true);
		Thread.sleep(2000);
		RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='Terminate Vehicle']])[1]", false, false);
		RC_Global.panelAction(driver, "expand", "Terminate Vehicle", true, false);
		
		if(driver.findElements(By.xpath("//div[label[text()='Client Directed Sale']]/input")).size()>0) {
			if(driver.findElements(By.xpath("//div[label[text()='Client Directed Sale']]/input[@disabled= 'disabled']")).size()>0) {
				queryObjects.logStatus(driver, Status.PASS, "External Users with request type 'Closed End' ", "cannot submit 'Client Directed Sale' termination request", null);
				
				RC_Global.createNode(driver, "Client Directed Sale selection error message of request type 'Closed End' for External User");
				if(driver.findElements(By.xpath("//span[text()=' "+clientDirectedSaleError+" ']")).size()>0)
					queryObjects.logStatus(driver, Status.PASS, "Error message validation Successful", "Error message: "+clientDirectedSaleError+" occurs.", null);
				
			}
		
//			else {
//		RC_Global.radioButton(driver, "Terminate Vehicle", "Client Directed Sale", true);
		
//		RC_Global.clickButton(driver, "Download Disclosure Form", true);
//		Thread.sleep(5000);
//		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
//		driver.switchTo().window(tabs.get(1)).close();
//		driver.switchTo().window(tabs.get(0));
//		
//		RC_Global.clickButton(driver, "Next", true);
//		RC_Global.waitUntilPanelVisibility(driver, "Title Information", "TV", true);
//		
//		RC_Global.enterInput(driver, "29500.00", driver.findElement(By.xpath("//input[@placeholder = 'Purchase Price']")), true);
//		Thread.sleep(3000);
//		RC_Remarketing.enterBuyerInformation(driver, buyerInfoLabel, buyerInfo, false);
//		Thread.sleep(3000);
//		RC_Global.clickUsingXpath(driver, "//label[@name = 'buttonLienHolderIndicatorNo' and text()='No']", "No for Lienholder Information", false);
//		RC_Global.radioButton(driver, "Mailing Information", "Same as Buyer", true);
//		
//		RC_Global.clickUsingXpath(driver, "//label[@name = 'buttonEmployeeActiveWithCompanyIndicatorNo' and text()='No']", "Selected No for Active Employee", false);
//		
//		//Open, Email, Print]
//		RC_Global.clickUsingXpath(driver, "//button[text()='Open']", "Open button", false);
//		Thread.sleep(5000);
//		ArrayList<String> getWindows = new ArrayList<String>(driver.getWindowHandles());
//		driver.switchTo().window(getWindows.get(1)).close();
//		driver.switchTo().window(getWindows.get(0));
//		RC_Global.buttonStatusValidation(driver, "Print", "Enable", true);
//		RC_Global.clickUsingXpath(driver, "//button[text()='Email']", "Email button", false);
//		RC_Global.clickButton(driver, "Cancel", false);
//
//		RC_Global.clickUsingXpath(driver, "(//button[text()='Next'])[2]", "Next button", true);
//
//		Thread.sleep(2000);
//		if(driver.findElements(By.xpath("//p[contains(text(),'Entered Price is less than Current Book Value. Additional fees may apply')]")).size()>0)
//			RC_Global.clickButton(driver, "OK", true);
//		else if(driver.findElements(By.xpath("//p[contains(text(),'Entered Purchase Price is less than Current Book Value. Additional Fees may apply.')]")).size()>0)
////		else if(driver.findElements(By.xpath("//p[text()='Entered Purchase Price is less than Current Book Value. Additional Fees may apply.']")).size()>0)
//			RC_Global.clickButton(driver, "OK", true);
//		
//		RC_Global.waitUntilPanelVisibility(driver, "Disclosure Agreement", "TV", true);
//		RC_Remarketing.damageDisclosure(driver, "Yes", "No", "No", "No", "No", "No", "30000", true);
//		
//		//Open, Email, Print]
//		RC_Global.clickUsingXpath(driver, "//button[text()='Open']", "Open button", false);
//		Thread.sleep(5000);
//		getWindows = new ArrayList<String>(driver.getWindowHandles());
//		driver.switchTo().window(getWindows.get(1)).close();
//		driver.switchTo().window(getWindows.get(0));
//		RC_Global.buttonStatusValidation(driver, "Print", "Enable", true);
//		RC_Global.clickUsingXpath(driver, "//button[text()='Email']", "Email button", false);
//		RC_Global.clickButton(driver, "Cancel", false);
//		
//		RC_Global.clickButton(driver, "Submit Vehicle Termination", true);
//		Thread.sleep(3000);
//		if(driver.findElements(By.xpath("//p[contains(text(),'Odometer reading entered is less than Latest Odometer for this vehicle.')]")).size()>0)
//			RC_Global.clickButton(driver, "OK", true);
//		
//		RC_Global.waitUntilPanelVisibility(driver, "Confirmation", "TV", true);
//		RC_Global.verifyDisplayedMessage(driver, "Successfully Submitted", false);
//		
//		//Open, Email, Print]
//		RC_Global.clickUsingXpath(driver, "//button[text()='Open']", "Open button", false);
//		Thread.sleep(5000);
//		getWindows = new ArrayList<String>(driver.getWindowHandles());
//		driver.switchTo().window(getWindows.get(1)).close();
//		driver.switchTo().window(getWindows.get(0));
//		RC_Global.buttonStatusValidation(driver, "Print", "Enable", true);
//		RC_Global.clickUsingXpath(driver, "//button[text()='Email']", "Email button", false);
//		RC_Global.clickButton(driver, "Cancel", false);
//		
//		RC_Global.clickButton(driver, "Terminate Another Vehicle", true);
//		RC_Global.waitUntilPanelVisibility(driver, "Terminate Vehicle", "TV", true);
//			}
		}
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
