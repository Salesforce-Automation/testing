package Remarketing.TerminateVehicle;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Remarketing;

public class TID_4_1_1_11 {
	public void TerminateVehicle_TitleInformationScreenForClientDirectedSale(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception {
		
		String[] BuyerInformation = {"Buyer Type", "Buyer Name", "Contact First Name", "Contact Last Name", "Address 1", "Address 2", "City", "State", "Zip Code", "Phone", "Ext", "Alternate Phone", "Ext", "Email"};
		String[] MailingInformation = {"Name", "Contact First Name", "Contact Last Name", "Address 1", "Address 2", "City", "State", "Zip Code", "Phone", "Ext", "Email"};
		String[] LienholderInformation = {"Lienholder Name", "Contact First Name", "Contact Last Name", "Address 1", "Address 2", "City", "State", "Zip Code", "Phone", "Ext", "Email"};
		String[] MailingInfoRadioOptions = {"Same as Buyer", "Same as Lienholder", "Other (Enter Information Below)"};
		
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Remarketing", "Terminate Vehicle", "");
		RC_Global.waitUntilPanelVisibility(driver, "Terminate Vehicle", "TV", true,false);
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		RC_Global.clickButton(driver, "Search", true,true);
		RC_Global.waitElementVisible(driver, 30, "//table/tbody/tr[1]", "First record ", true,false);
		
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//tr//span[text()='Agreement Type']")).click();
		if(driver.findElements(By.xpath("//tbody/tr[td[text()='Closed End']][1]")).size()>0) {
			driver.findElement(By.xpath("//tbody/tr[td[text()='Closed End']][1]")).click();
		}
		else { 
			driver.findElement(By.xpath("//tr//span[text()='Agreement Type']")).click();
			driver.findElement(By.xpath("//tbody/tr[td[text()='Closed End']][1]")).click();
		}
		
		RC_Global.clickUsingXpath(driver, "(//button[normalize-space(text())='Select Vehicle'])[1]", "Select Vehicle", true,true);
		RC_Global.waitElementVisible(driver, 30, "(//h5[span[text()='Terminate Vehicle']])[2]", "TermateVehicle Page", true,false);
		Thread.sleep(2000);
		RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='Terminate Vehicle']])[1]", false,false);
		RC_Global.panelAction(driver, "expand", "Terminate Vehicle", true,false);
		
		RC_Global.radioButton(driver, "Terminate Vehicle", "Client Directed Sale", true);
		
		RC_Global.clickButton(driver, "Next", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Title Information", "TV", true,false);
		
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Buyer Information", false);
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Mailing Information", false);
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Lienholder Information", false);
		
		RC_Remarketing.validateFormLabel(driver, "Buyer Information", BuyerInformation, false);
		
		RC_Global.clickUsingXpath(driver, "//label[@name='buttonLienHolderIndicatorYes']", "Lienholder Information - Yes", true,false);
		
		RC_Global.radioButton(driver, "Mailing Information", "Same as Lienholder", false);
		RC_Global.radioButton(driver, "Mailing Information", "Other (Enter Information Below)", false);
		RC_Global.radioButton(driver, "Mailing Information", "Same as Buyer", false);
		
		RC_Remarketing.validateFormLabel(driver, "Mailing Information", MailingInformation, false);
		
		RC_Global.clickUsingXpath(driver, "//label[@name='buttonLienHolderIndicatorNo']", "Lienholder Information - No", false,false);
		RC_Global.clickUsingXpath(driver, "//label[@name='buttonLienHolderIndicatorYes']", "Lienholder Information - Yes", true,false);
		
		RC_Remarketing.validateFormLabel(driver, "Lienholder Information", LienholderInformation, false);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
