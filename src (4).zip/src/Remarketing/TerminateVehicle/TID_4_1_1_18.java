package Remarketing.TerminateVehicle;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;
import tools.TotalView.RC_Remarketing;

public class TID_4_1_1_18 {
public void TerminateVehicle_ValidateVehicleProgramTerminationFunctionality (WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
		
		ArrayList<String> getWindows = new ArrayList<String>(driver.getWindowHandles());
		String custNum = "LS010143";
		String Driver="";
		String Fuel="";
		String Personaluse= "";
//		String Driver="";
//		String Fuel="";
//		String Personaluse= "";
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
		RC_Global.validateHeaderName(driver, "Customer Administration", false);
		RC_Global.enterCustomerNumber(driver, custNum, "", "", false);
		RC_Global.clickUsingXpath(driver, "//a[text()='Fuel']", "Fuel Tab", false,true);
		RC_Global.waitElementVisible(driver, 60, "//label[text()='Enrolled in Fuel']", "Fuel",true,false);
		if(driver.findElements(By.xpath("//label[text()='Enrolled in Fuel']/../div//button[text()='Yes']")).size()>0) {
			String FuelEnrollment= "";
			FuelEnrollment= driver.findElement(By.xpath("//label[text()='Enrolled in Fuel']/../div//button[contains(@class,'disabled-active-button') and normalize-space(text())='Yes']")).getText();
			queryObjects.logStatus(driver, Status.INFO, "Enrollment in Fuel as ", FuelEnrollment, null);
		}
		
		RC_Global.clickUsingXpath(driver, "//a[text()='Personal Use']", "Personal Use Tab", false,true);
		RC_Global.waitElementVisible(driver, 60, "//legend[text()='Personal Use']", "Personal Use",true,false);
		if(driver.findElements(By.xpath("//label[contains(text(),'Enrolled In Personal Use')]/../div//button[contains(@class,'disabled-active-button') and normalize-space(text())='Yes']")).size()>0) {
			String PersonalUseEnrollment= "";
			PersonalUseEnrollment= driver.findElement(By.xpath("//label[contains(text(),'Enrolled In Personal Use')]/../div//button[normalize-space(text())='Yes']")).getText();
			queryObjects.logStatus(driver, Status.INFO, "Enrollment in Fuel as ", PersonalUseEnrollment, null);
		}
		RC_Global.panelAction(driver, "close", "Customer Administration",false,false);
	
		RC_Global.navigateTo(driver, "Remarketing", "Terminate Vehicle", "");
		RC_Global.validateHeaderName(driver, "Terminate Vehicle", true);
		RC_Global.enterCustomerNumber(driver, custNum, "", "", false);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.waitElementVisible(driver,30,"//tbody//tr[1]","Grid Row",true,false);
		RC_Remarketing.selectRowWithAgreementTypeFromGrid(driver, "Closed End", true);
		RC_Global.clickButton(driver, "Select Vehicle", false,true);
		RC_Manage.waitUntilMethods(driver, "(//button[text()='Select Vehicle '])[1]/div[@ng-show='vm.isSelectingVehicle']","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 60, "(//h5/span[contains(text(), 'Terminate Vehicle')])[2]", "Terminate Vehicle Header", false,false);
//		RC_Global.waitElementVisible(driver, 60, "//h5/span[contains(text(), 'Title Information')]", "Title Information", false);
		RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='Terminate Vehicle']])[1]", false,false);
		RC_Global.panelAction(driver, "expand", "Terminate Vehicle", false,false);
		
//		RC_Global.createNode(driver, "Validate the Vehicle termination method");
//		String MTS = "";
//		MTS = driver.findElement(By.xpath("//input[contains(@ng-value,'termMethodLabelMerchantsToSellTypeId')]/../label")).getText();
//		String CDS = "";
//		CDS = driver.findElement(By.xpath("//input[contains(@ng-value,'termMethodLabelClientDirectedSaleTypeId')]/../label")).getText();
//		queryObjects.logStatus(driver, Status.INFO, "Vehicle termination method Request type as "+MTS+" "+CDS+" ", "", null);
		
		RC_Global.radioButton(driver, "Terminate Vehicle", "Client Directed Sale", false);
//		RC_Global.clickUsingXpath(driver, "//div[2]/div/input[@type='radio']", "Client Directed Sale", true);
		RC_Global.clickButton(driver, "Next", false,true);
		
		RC_Global.scrollById(driver, "//legend[text()='Lienholder Information']");
		
		RC_Global.createNode(driver, "Validate the Message displayed under Vehicle Program termination Section");
		
		Driver = driver.findElement(By.xpath("//div[1][label[normalize-space(text())='Driver Status:']]/../div[2]/div[1]")).getText();
		Fuel = driver.findElement(By.xpath("//div[1][label[normalize-space(text())='Fuel:']]/../div[2]/div[1]")).getText();
		Personaluse = driver.findElement(By.xpath("//div[1][label[normalize-space(text())='Personal Use:']]/../div[2]/div[1]")).getText();
		
		queryObjects.logStatus(driver, Status.INFO, "Driver Status: ", Driver, null);
		queryObjects.logStatus(driver, Status.INFO, "Fuel: ", Fuel, null);
		queryObjects.logStatus(driver, Status.INFO, "Personal Use: ", Personaluse, null);
		
		RC_Global.createNode(driver, "Vehicle Program termination funationality for Driver Status 'NO'");
		List<WebElement> programFuel = driver.findElements(By.xpath("//label[contains(@ng-model,'DriverInFuelIndicator') and @disabled='disabled']"));
		List<WebElement> programPersonaluse = driver.findElements(By.xpath("//label[contains(@ng-model,'DriverInPersonalUseIndicator') and @disabled='disabled']"));
		Thread.sleep(2000);
		driver.findElement(By.xpath("//label[contains(@name,'EmployeeActiveWithCompanyIndicatorNo')]")).click();
		if(driver.findElements(By.xpath("//label[contains(@class,'disabled-active-button') and contains(@name,'EmployeeActiveWithCompanyIndicatorNo')]")).size()>0)
		{
			if(!(programFuel.size()<0))
			{
				queryObjects.logStatus(driver, Status.INFO, "Fuel Vehicle Program Termination is ", "Disabled", null);
			}
			if(!(programPersonaluse.size()<0))
			{
				queryObjects.logStatus(driver, Status.INFO, "Personal Use Vehicle Program Termination is ", "Disabled", null);
			}
			
			
		}
		
		RC_Global.createNode(driver, "Vehicle Program termination funationality for Driver Status 'YES'");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//label[contains(@name,'EmployeeActiveWithCompanyIndicatorYes')]")).click();
		if(driver.findElements(By.xpath("//label[contains(@class,'disabled-active-button') and contains(@name,'EmployeeActiveWithCompanyIndicatorYes')]")).size()>0)
		{
			if((!(programFuel.size()>0)))
			{
				queryObjects.logStatus(driver, Status.INFO, "Fuel Vehicle Program Termination is ", "Enabled", null);
			}
			if((!(programPersonaluse.size()>0)))
			{
				queryObjects.logStatus(driver, Status.INFO, "Personal Use Vehicle Program Termination is ", "Enabled", null);
			}
			
			
		}
		
		RC_Global.scrollById(driver, "//h5/span[contains(text(), 'Title Information')]");
		RC_Global.panelAction(driver, "close", "Title Information", false,true);
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}
}
