package Remarketing.TerminateVehicle;

import java.util.ArrayList;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;
import tools.TotalView.RC_Remarketing;

public class TID_4_1_1_04 {

	public void TerminateVehicle_VerifyCVT_ClientDirectedSale(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		ArrayList<String> getWindows = new ArrayList<String>(driver.getWindowHandles());
		String displaymessage = "Please see the attached, the Odometer and Damage Disclosure for 3777777 - Unit #772801.";
		String displayedmessage = "Please see the attached Remarketing Request Confirmation for 3777777 - Unit # 772801.";
		String alertmessage = "Entered Purchase Price is less than Current Book Value. Additional Fees may apply. Click OK to continue to the next screen or Cancel to change the entered value.";
		String alertodomessage = "Odometer reading entered is less than Latest Odometer for this vehicle.  Click �OK� to submit termination or click �Cancel� to change the entered Odometer reading.";
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		
		RC_Global.login(driver);
	    RC_Global.navigateTo(driver, "Remarketing", "Terminate Vehicle", "");
		RC_Global.enterCustomerNumber(driver, "LS008737", "", "", true);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.waitElementVisible(driver,30,"//tbody//tr[1]","Grid Row",true,false);
		RC_Remarketing.selectRowWithAgreementTypeFromGrid(driver,"Open End",true);
		RC_Global.clickButton(driver, "Select Vehicle",true,true);
		RC_Manage.waitUntilMethods(driver, "(//button[text()='Select Vehicle '])[1]/div[@ng-show='vm.isSelectingVehicle']","class","ng-hide", "attribute visible");
	    RC_Global.panelAction(driver, "close", "Terminate Vehicle",true,false);
	    RC_Global.waitUntilPanelVisibility(driver, "Terminate Vehicle", "TV", false,false);
	    RC_Global.panelAction(driver, "expand", "Terminate Vehicle",true,false);
	    
	    RC_Global.createNode(driver, "Vehicle Termination method selection");
	    RC_Global.clickUsingXpath(driver, "//div[4]/div/input[@type='radio']", "Client Directed Sale",true,false);
		
		RC_Global.clickButton(driver, "Next", false,true);
	    RC_Global.waitUntilPanelVisibility(driver, "Title Information", "TV", false,false);
	    
	    RC_Global.createNode(driver, "Enter Purchase Price Input Value");
	    WebElement PurchasePrice = driver.findElement(By.xpath("//input[@placeholder='Purchase Price']"));
		RC_Global.enterInput(driver, "350", PurchasePrice, false,true);
		RC_Global.waitElementVisible(driver, 60, "(//div[1]/div/legend)[2]", "Buyer Information", false,false);
	
		String[] buyerInfoLabel = {"Buyer Type","Buyer Name","Contact First Name","Contact Last Name","Address 1","City","State","Zip Code","Phone"};
		String[] buyerInformation= {"Client","Sample","Demo","Test","2909 RING RD","ELIZABETHTOWN","KY","42701-9119","(645) 334-7658"};
	
		RC_Global.createNode(driver, "Enter Buyer Information Details");
		RC_Remarketing.enterBuyerInformation(driver,buyerInfoLabel,buyerInformation,true);
		
		RC_Global.clickUsingXpath(driver, "(//div[2]/div/label[1]/input[@type='radio'])[1]", "Same as Buyer ",true,false);
		RC_Global.clickUsingXpath(driver, "//div[2]/div/label[2][contains(@name,'buttonLienHolderIndicatorNo')]", "Lineholder ",true,false);
		
	    RC_Remarketing.vehicleProgramTermination(driver, "Yes", "No", "No", true);
	    
	    RC_Global.clickUsingXpath(driver, "(//button[text()='Next'])[1]", "Next", true,true);
	    Thread.sleep(1000);
	    if(driver.findElements(By.xpath("//h3[text()='Confirm']")).size()>0){
	    	 RC_Global.verifyDisplayedMessage(driver,alertmessage,true);
	    	 RC_Global.clickUsingXpath(driver, "(//button[normalize-space(text()='OK')])[1]", "Ok button", true,false);
	    	 Thread.sleep(2000);
	        }
	    RC_Global.waitUntilPanelVisibility(driver, "Disclosure Agreement", "TV", false,false);
	    RC_Global.validateHeaderName(driver, "Disclosure Agreement",false);
	    
	    RC_Global.createNode(driver, "Enter Odometer value");
	    WebElement nameElement = driver.findElement(By.xpath("//input[@placeholder='Odometer']"));
    	RC_Global.enterInput(driver, RandomStringUtils.randomNumeric(4), nameElement,true,false);
		
    	RC_Remarketing.damageDisclosure(driver,"Yes", "No", "No", "No", "No", "No","", true);
	    Thread.sleep(1000);
	    RC_Global.clickButton(driver, "Open", false,true);
	    Thread.sleep(2000);
	    driver.switchTo().window(getWindows.get(0));
	    Thread.sleep(1000);
	    RC_Global.clickButton(driver, "Email",true,true);
	    Thread.sleep(3000);
	    RC_Global.waitElementVisible(driver, 60, "//h3[text()='Disclosure Agreement Message']", "Email Documents",false,false);
	    RC_Global.verifyDisplayedMessage(driver,displaymessage,true);
	    Thread.sleep(1000);
	    RC_Global.clickButton(driver, "Cancel",true,false);
	    RC_Global.clickButton(driver, "Submit Vehicle Termination", true,true);
	    RC_Manage.waitUntilMethods(driver, "//div[@ng-show='vm.isSubmitting']","class","ng-hide", "attribute visible");
	    Thread.sleep(1000);
	    if(driver.findElements(By.xpath("//h3[text()='Confirm']")).size()>0){
	    	 RC_Global.verifyDisplayedMessage(driver,alertodomessage,true);
	    	 RC_Global.clickUsingXpath(driver, "(//button[normalize-space(text()='OK')])[1]", "Ok button", true,false);
	    	 Thread.sleep(2000);
	        }
	    
	    RC_Global.waitUntilPanelVisibility(driver, "Confirmation", "TV", false,false);
	    RC_Global.validateHeaderName(driver, "Confirmation",false);
	    RC_Global.clickButton(driver, "Open", false,true);
	    Thread.sleep(3000);
	    driver.switchTo().window(getWindows.get(0));
	    RC_Global.clickButton(driver, "Email",true,true);
	    Thread.sleep(3000);
	    RC_Global.waitElementVisible(driver, 60, "//h3[text()='Request Summary Message']", "Email Documents",false,false);
	    RC_Global.verifyDisplayedMessage(driver,displayedmessage,true);
	    
	    Thread.sleep(1000);
	    RC_Global.clickButton(driver, "Cancel",true,false);
	    RC_Global.clickButton(driver, "Terminate Another Vehicle",true,true);
	    RC_Global.waitUntilPanelVisibility(driver, "Terminate Vehicle", "TV", false,false);
	    RC_Global.panelAction(driver, "close", "Terminate Vehicle",false,false);
	    
	    RC_Global.logout(driver, false);
	     	 
	     queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

}
}