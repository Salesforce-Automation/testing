package Remarketing.TerminateVehicle;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;
import tools.TotalView.RC_Remarketing;

public class TID_4_1_1_09 {

public void TerminateVehicle_ValidateFieldsAndHyperlinksInServicesTerminationRequestScreen (WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Remarketing", "Terminate Vehicle", "");
		RC_Global.validateHeaderName(driver, "Terminate Vehicle", true);
		RC_Global.enterCustomerNumber(driver, "LS010143", "", "", true);
		Thread.sleep(2000);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.waitElementVisible(driver,30,"//tbody//tr[1]","Grid Row",true,false);
		RC_Global.clickUsingXpath(driver, "//div/span[text()='Agreement Type']", "Sort Agreement Type", false,false);
		RC_Global.clickUsingXpath(driver, "//div/span[text()='Agreement Type']", "Sort Agreement Type", false,false);
		
		RC_Remarketing.selectRowWithAgreementTypeFromGrid(driver, "Services Only", true);
		RC_Global.clickButton(driver, "Select Vehicle", false,true);
		RC_Manage.waitUntilMethods(driver, "(//button[text()='Select Vehicle '])[1]/div[@ng-show='vm.isSelectingVehicle']","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 60, "(//h5/span[contains(text(), 'Terminate Vehicle')])[2]", "Terminate Vehicle Header", false,false);
		RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='Terminate Vehicle']])[1]", false,false);
		RC_Global.panelAction(driver, "expand", "Terminate Vehicle", false,false);
		
		RC_Global.createNode(driver, "Vehicle Termination method selection");
		RC_Global.radioButton(driver, "Terminate Vehicle", "Terminate Services Only", false);
		RC_Global.clickButton(driver, "Next", false,true);
		
		RC_Global.createNode(driver, "Label validation");
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Name", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Unit Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Vehicle Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Year / Make / Model", false);
		RC_Global.verifyScreenComponents(driver, "lable", "VIN", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Vehicle Status", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Driver/Pool Name", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Odometer Reading", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Replacement Vehicle", false);
		RC_Global.verifyScreenComponents(driver, "lable", "New Unit Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Agreement Type", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Title Management", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Government Lease", false);
		RC_Global.verifyScreenComponents(driver, "lable", "GM GDP", false);
		RC_Global.verifyScreenComponents(driver, "lable", "3rd Party Inspection Required", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Current Sale Status", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Sale Status Last Updated", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Confirmation Number", false);
		
		
		String UnitNumberLink = driver.findElement(By.xpath("//div//label[text()='Unit Number']/../following-sibling::div/a")).getText();
		Thread.sleep(2000);
		if(!UnitNumberLink.isEmpty()) {
		RC_Global.clickUsingXpath(driver, "//div//label[text()='Unit Number']/../following-sibling::div/a", "Unit Number Link", false,true);
		//RC_Global.clickLink(driver, "Unit Number", true);
		RC_Global.waitUntilPanelVisibility(driver, "Vehicle Details", "TV", false,false);
		RC_Global.panelAction(driver, "close", "Vehicle Details", false,false);}
		
		String CVNLink = driver.findElement(By.xpath("//div//label[text()='Customer Vehicle Number']/../following-sibling::div/a")).getText();
		Thread.sleep(2000);
		if(!CVNLink.isEmpty()) {
		RC_Global.clickUsingXpath(driver, "//div//label[text()='Customer Vehicle Number']/../following-sibling::div/a", "Customer Vehicle Number Link", false,true);
		RC_Global.waitUntilPanelVisibility(driver, "Vehicle Details", "TV", false,false);
		RC_Global.panelAction(driver, "close", "Vehicle Details", false,false);}
		
		String DriverPoolLink = driver.findElement(By.xpath("//div//label[text()='Customer Vehicle Number']/../following-sibling::div/a")).getText();
		Thread.sleep(2000);
		if(!DriverPoolLink.isEmpty()) {
		RC_Global.clickUsingXpath(driver, "//div//label[text()='Driver/Pool Name']/../following-sibling::div/a", "Driver/Pool Name Link", false,true);
		RC_Global.panelAction(driver, "close", "Driver Details", false,false);
		RC_Global.panelAction(driver, "xpathclose", "//h5[span[text()='Services Termination Request']]", false,false);}
		RC_Global.logout(driver, false);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
		
		
	}
}
