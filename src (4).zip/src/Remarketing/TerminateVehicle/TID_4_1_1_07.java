package Remarketing.TerminateVehicle;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_4_1_1_07 {
	public void TerminateVehicle_ValidateSearchFilters(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		WebDriverWait wait = new WebDriverWait(driver,90);
		String SearchFilters = "Customer Number;Unit Number;Customer Vehicle Number;VIN;Plate Number;Driver Last Name;Driver First Name;Pool Name;Vehicle Status;Client Data Value;Client Data Field 1-7;Plate State";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Remarketing", "Terminate Vehicle", "");
		RC_Global.validateSpecifiedSearchFilters(driver, SearchFilters, false);
		RC_Global.validateMultipleSelectionFilter(driver, "Active lease;Active services only;Pending Activation;Pending termination", false);
		RC_Global.enterCustomerNumber(driver, "LS010143", "", "", true);
		RC_Global.clickButton(driver, "Search", false,true);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tbody/tr")));
		String UnitNumber = driver.findElement(By.xpath("(//td[contains(@ng-click,'unitNumberSelected')])[1]")).getText();
		RC_Global.clickUsingXpath(driver, "//span[1][text()='CVN']", "customer vehicle number", true,false);
		String CVN = driver.findElement(By.xpath("(//td[contains(@ng-click,'NumberSelected')])[2]")).getText();
		String VIN = driver.findElement(By.xpath("(//tr[contains(@ng-click,'onRowSelect')]/td[8])[1]")).getText();
		String DriverName = driver.findElement(By.xpath("(//tr[contains(@ng-click,'onRowSelect')]/td[9])[1]")).getText();
		if(DriverName.contains("Pool")) {
			for (int i=2;i<=25; i++) {
			 DriverName = driver.findElement(By.xpath("(//tr[contains(@ng-click,'onRowSelect')]/td[9])["+i+"]")).getText();
			 if(!(DriverName.contains("Pool"))) {
				 break;
			 }
			}
				 
		}
		String[] Driver = DriverName.split(" ");
		RC_Global.clickButton(driver, "Reset", false,false);
		
		queryObjects.logStatus(driver, Status.INFO, "Unit Number data---->", UnitNumber, null);
		queryObjects.logStatus(driver, Status.INFO, "CVN data---->", CVN, null);
		queryObjects.logStatus(driver, Status.INFO, "VIN data---->", VIN, null);
		queryObjects.logStatus(driver, Status.INFO, "DriverName data---->", DriverName, null);
		
		RC_Global.createNode(driver, "Terminate Vehicle -- Unit Number Search Filter Functionality Validation");
		WebElement element = driver.findElement(By.xpath("//input[@placeholder='Unit Number']"));
		RC_Global.enterInput(driver,UnitNumber , element, false,false);
		RC_Global.clickUsingXpath(driver, "//button[text()='Search']", "Search", false,false);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tbody/tr")));
		RC_Global.clickUsingXpath(driver, "//button[text()='Reset']", "Reset", false,false);
		
		RC_Global.createNode(driver, "Terminate Vehicle -- Customer Vehicle Number Search Filter Functionality Validation");
		WebElement element1 = driver.findElement(By.xpath("//input[@placeholder='Vehicle Number']"));
		RC_Global.enterInput(driver,CVN , element1, false,false);
		RC_Global.clickUsingXpath(driver, "//button[text()='Search']", "Search", false,false);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tbody/tr")));
		RC_Global.clickUsingXpath(driver, "//button[text()='Reset']", "Reset", false,false);
		
		RC_Global.createNode(driver, "Terminate Vehicle -- VIN Search Filter Functionality Validation");
		WebElement element2 = driver.findElement(By.xpath("//input[@placeholder='VIN']"));
		RC_Global.enterCustomerNumber(driver, "LS010143", "", "", true);
		RC_Global.enterInput(driver,VIN , element2, false,false);
		RC_Global.clickUsingXpath(driver, "//button[text()='Search']", "Search", false,false);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tbody/tr")));
		RC_Global.clickUsingXpath(driver, "//button[text()='Reset']", "Reset", false,false);
		
		RC_Global.createNode(driver, "Terminate Vehicle -- Driver First Name Search Filter Functionality Validation");
		WebElement element3 = driver.findElement(By.xpath("//input[@placeholder='Driver First Name']"));
		RC_Global.enterInput(driver,Driver[0] , element3, false,false);
		RC_Global.clickUsingXpath(driver, "//button[text()='Search']", "Search", false,false);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tbody/tr")));
		RC_Global.clickUsingXpath(driver, "//button[text()='Reset']", "Reset", false,false);
		
		RC_Global.createNode(driver, "Terminate Vehicle -- Driver Last Name Search Filter Functionality Validation");
		WebElement element4 = driver.findElement(By.xpath("//input[@placeholder='Driver Last Name']"));
		RC_Global.enterInput(driver,Driver[1] , element4, false,false);
		RC_Global.clickUsingXpath(driver, "//button[text()='Search']", "Search", false,false);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tbody/tr")));
		RC_Global.clickUsingXpath(driver, "//button[text()='Reset']", "Reset", false,false);
		
		RC_Global.panelAction(driver, "close", "Terminate Vehicle", false,false);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
