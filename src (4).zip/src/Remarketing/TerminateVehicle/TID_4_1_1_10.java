package Remarketing.TerminateVehicle;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;
import tools.TotalView.RC_Remarketing;

public class TID_4_1_1_10 {
	public void TerminateVehicle_ValidateConfirmationScreenSections_OpenEnd_MerchantsToSell(WebDriver driver, BFrameworkQueryObjects queryObjects)throws Exception
	{
		String menu = "Remarketing";
		String firstSubMenu = "Terminate Vehicle";
		String AgreementType = "Open End";
		WebDriverWait wait = new WebDriverWait(driver,30);
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,"");
		RC_Global.enterCustomerNumber(driver, "LS008737", "", "", true);
		RC_Global.clickButton(driver, "Search", true, true);
		RC_Global.waitElementVisible(driver,30,"//tbody//tr[1]","Grid Row",true,false);
		RC_Remarketing.selectRowWithAgreementTypeFromGrid(driver,AgreementType,true);
		RC_Global.clickUsingXpath(driver, "(//button[text()='Select Vehicle '])[1]", "Select Vehicle", true,true);
		RC_Manage.waitUntilMethods(driver, "(//button[text()='Select Vehicle '])[1]/div[@ng-show='vm.isSelectingVehicle']","class","ng-hide", "attribute visible");
		RC_Global.waitUntilPanelVisibility(driver, "Terminate Vehicle", "TV", true,false);
		Thread.sleep(1000);
		RC_Global.clickUsingXpath(driver, "(//h5[span[text()='Terminate Vehicle']]/i[@ng-click='closePanel()'])[1]", "Close Terminate Vahicle", true,false);
		RC_Global.panelAction(driver, "expand", "Terminate Vehicle", true,false);
		RC_Remarketing.validateAgreementType(driver, AgreementType);
		RC_Global.radioButton(driver, "Terminate Vehicle", "Merchants to Sell", true);
		RC_Global.clickButton(driver, "Next", true,true);
		RC_Global.waitUntilPanelVisibility(driver, "Vehicle Pickup Information", "TV", true,false);
		RC_Global.clickUsingXpath(driver, "(//label[@name='isDriverOrPoolSelectedYes'])[1]","Driver/Pool Toggle button", true,false);
		WebElement ContactPhone = driver.findElement(By.xpath("(//input[@name='phone' and (contains(@ng-model,'vm.remarketingRequest'))])[3]"));
    	RC_Global.enterInput(driver,"(323) 232-3342" , ContactPhone,true,false);//
    	String[] TerminationOption = RC_Remarketing.vehicleProgramTermination(driver,"Yes","Yes","Yes",false);
    	
    	RC_Global.clickUsingXpath(driver, "(//button[text()='Next'])[2]","Next Button", true,true);
    	Thread.sleep(2000);
    	 if(driver.findElements(By.xpath("//span[text()=' address entered.']")).size()>0){
	            RC_Global.clickButton(driver, "Save As Entered", false,false);
	            Thread.sleep(2000);
	        }
    	RC_Remarketing.damageDisclosure(driver, "Yes", "No", "No", "No", "No", "No","10,000",true);
		RC_Global.clickButton(driver, "Submit Vehicle Termination", true,true);
		RC_Manage.waitUntilMethods(driver, "//div[@ng-show='vm.isSubmitting']","class","ng-hide", "attribute visible");
	    Thread.sleep(1000);
		List <WebElement> Confirm_pop = driver.findElements(By.xpath("//h3[text()='Confirm']"));
		if(Confirm_pop.size()>0) {
		//RC_Global.waitElementVisible(driver, 30,"//h3[text()='Confirm']" , "Confirm Popup", true);
		List<WebElement> PopupHeader = driver.findElements(By.xpath("//h3[text()='Confirm']"));
		List<WebElement> PopupMessage = driver.findElements(By.xpath("//p[contains(text(),'Odometer reading entered is less than Latest Odometer for this vehicle')]"));
		if(PopupHeader.size()==1 && PopupMessage.size()==1 )
			queryObjects.logStatus(driver, Status.PASS, "Confirm POPup Message is ", "Displayed", null);
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Confirm POPup Message is ", "Not Displayed", null);
			RC_Global.endTestRun(driver);
		}RC_Global.clickButton(driver, "OK", true,false);
}
		try {   
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(), 'Confirmation')]")));
		}
		catch(Exception e) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(), 'Driver Message')]")));
		}
		//RC_Global.waitUntilPanelVisibility(driver, "Driver Message", "TV", true,false);
		RC_Global.verifyDisplayedMessage(driver, "Successfully Submitted", true);
		if(driver.findElements(By.xpath("//button[text()='Next']")).size()>0)
		RC_Global.clickButton(driver, "Next", true,true);
		//RC_Global.waitUntilPanelVisibility(driver, "Confirmation", "TV", true,false);
		String[]SectionsToValidate = {"TitleAddress","VehicleProgramTermination","VehicleConDetails","DisclosureAgreement"};
		RC_Remarketing.terminateConfirmationSectionValidation(driver,TerminationOption,SectionsToValidate,true);
		
		RC_Global.clickButton(driver, "Terminate Another Vehicle", true,true);
		RC_Global.waitUntilPanelVisibility(driver, "Terminate Vehicle", "TV", true,false);
		RC_Global.panelAction(driver, "close", "Terminate Vehicle", true,false);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}
}








