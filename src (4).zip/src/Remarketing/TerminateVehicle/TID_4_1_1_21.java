package Remarketing.TerminateVehicle;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;
import tools.TotalView.RC_Remarketing;

public class TID_4_1_1_21 {
	public void TerminateVehicle_Verify_CVT_Merchants_To_Sell_And_TerminateServicesOnly_Using_ExternalUser(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		
		WebDriverWait wait = new WebDriverWait(driver,30);
		String displaymessage = "Please see the attached, the Odometer and Damage Disclosure for ";
		String alertmessage = "Odometer reading entered is less than Latest Odometer for this vehicle.  Click �OK� to submit termination or click �Cancel� to change the entered Odometer reading.";
		
		
//		RC_Global.login(driver);
		RC_Global.externalUserLogin(driver, "tuffQAtestDontChange", "Yes");
	    RC_Global.createNode(driver,"Terminate Vehicle");
		RC_Global.navigateTo(driver, "Remarketing", "Terminate Vehicle", "");
//		RC_Global.waitElementVisible(driver, 10, "//input[@name='customerInput']", "Input CustomerNumber",true);
//		RC_Global.enterCustomerNumber(driver, "LS008742", "", "",true);
		RC_Global.clickButton(driver, "Search",true,true);
		
		RC_Global.waitElementVisible(driver,30,"//tbody//tr[1]","Grid Row",true,false);
		RC_Global.clickUsingXpath(driver, "//div/span[text()='Agreement Type']", "Sort Agreement Type", false,false);
		RC_Global.clickUsingXpath(driver, "//div/span[text()='Agreement Type']", "Sort Agreement Type", false,false);
		
		RC_Remarketing.selectRowWithAgreementTypeFromGrid(driver,"Services Only",true);
		RC_Global.clickButton(driver, "Select Vehicle", true,true);
		RC_Manage.waitUntilMethods(driver, "(//button[text()='Select Vehicle '])[1]/div[@ng-show='vm.isSelectingVehicle']","class","ng-hide", "attribute visible");
		RC_Global.panelAction(driver, "close", "Terminate Vehicle", true,false);
	    RC_Global.waitUntilPanelVisibility(driver, "Terminate Vehicle", "TV", false,false);
	    RC_Global.panelAction(driver, "expand", "Terminate Vehicle", true,false);
		
		
		RC_Global.clickUsingXpath(driver, "(//label[contains(text(),'Merchants to Sell and Terminate Services Only')]/../input[contains(@type,'radio')])[1]", "Check Box", true,true);
		String winHandleBefore = driver.getWindowHandle();
		Thread.sleep(2000);
		RC_Global.clickButton(driver, "Next", true,true);
		RC_Global.createNode(driver,"Vehicle Pickup Information");
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Pickup Information","TV",true,false);
		RC_Global.clickUsingXpath(driver, "(//label[text()=' Driver/Pool '])[1]", "Driver/Pool", true,true);
	    RC_Remarketing.vehicleProgramTermination(driver, "Yes", "No", "No", true);
	    WebElement phonenumber = driver.findElement(By.xpath("(//input[@placeholder='Phone'])[4]"));
    	RC_Global.enterInput(driver, RandomStringUtils.randomNumeric(10), phonenumber,true,false);
		
		Thread.sleep(2000);
		
		 RC_Global.clickUsingXpath(driver, "(//button[text()='Next'])[1]", "Next", true,true);
		  Thread.sleep(3000);
	     if(driver.findElements(By.xpath("//span[text()=' address entered.']")).size()>0){
	            RC_Global.clickButton(driver, "Save As Entered", false,false);
	            Thread.sleep(2000);
	        }
	     RC_Global.waitUntilPanelVisibility(driver, "Disclosure Agreement", "TV", false,false);
	     RC_Global.validateHeaderName(driver, "Disclosure Agreement",false);
	     
	     WebElement nameElement = driver.findElement(By.xpath("//input[@placeholder='Odometer']"));
     	 RC_Global.enterInput(driver, RandomStringUtils.randomNumeric(4), nameElement,true,false);
     	
	    RC_Remarketing.damageDisclosure(driver,"Yes", "No", "No", "No", "No", "No","", true);
		winHandleBefore = driver.getWindowHandle();
		RC_Global.clickButton(driver, "Open", true,true);
		driver.switchTo().window(winHandleBefore);
		Thread.sleep(2000);
		winHandleBefore = driver.getWindowHandle();
		RC_Global.clickButton(driver, "Email", true,true);
		Thread.sleep(4000);
		RC_Global.waitElementVisible(driver, 110, "//h3[text()='Disclosure Agreement Message']", "Email Documents",false,false);
		if (driver.findElement(By.xpath("//div[contains(text(),'Please see the attached, the Odometer and Damage Disclosure for')]")).isDisplayed()) {
			queryObjects.logStatus(driver, Status.PASS, "Message to be verified -"+displaymessage, "Message is displayed on the screen", null);
		} else {
			queryObjects.logStatus(driver, Status.FAIL, "Message to be verified -"+displaymessage, "Message is not displayed on the screen", null);
		}
	    RC_Global.clickButton(driver, "Cancel",true,false);
		Thread.sleep(1000);
		RC_Global.clickButton(driver, "Submit Vehicle Termination", true,true);
		RC_Manage.waitUntilMethods(driver, "//div[@ng-show='vm.isSubmitting']","class","ng-hide", "attribute visible");
	    Thread.sleep(1000);
		 if(driver.findElements(By.xpath("//h3[text()='Confirm']")).size()>0){
	    	 RC_Global.verifyDisplayedMessage(driver,alertmessage,true);
	    	 RC_Global.clickUsingXpath(driver, "(//button[normalize-space(text()='OK')])[1]", "Ok button", true,false);
	    	 Thread.sleep(2000);
	        }
        
//		while(((WebElement)(driver.findElement(By.xpath("//fieldset//h4")))).getText().length()>0)
//		{
//	        try {
//	        	
//		          Thread.sleep(100);
//		        } catch(InterruptedException e) 
//	        		{
//			          
//			        }
//		}
//		winHandleBefore = driver.getWindowHandle();
//		RC_Global.clickButton(driver, "Email", true);
//		RC_Global.clickUsingXpath(driver,"//button[contains(text(),'Send')]","Mail Send Button Click",true);
//		driver.switchTo().window(winHandleBefore);
		
		if(driver.findElements(By.xpath("//button[contains(text(),'Terminate Another Vehicle')]")).size()>0)
		{
			RC_Global.clickUsingXpath(driver,"//button[contains(text(),',false Another Vehicle')]","Button",true,true);
		}
		else
		{
			RC_Global.waitUntilPanelVisibility(driver, "Driver Message", "TV", false, false);
			RC_Global.clickButton(driver, "Next", true,true);
			RC_Global.waitUntilPanelVisibility(driver, "Confirmation", "TV", false, false);
			winHandleBefore = driver.getWindowHandle();
			RC_Global.clickButton(driver, "Open", true,true);
			driver.switchTo().window(winHandleBefore);
			winHandleBefore = driver.getWindowHandle();
			Thread.sleep(2000);
			RC_Global.clickButton(driver, "Email", true,true);
			RC_Global.clickButton(driver, "Cancel",true,false);
			
			Thread.sleep(2000);
			RC_Global.clickButton(driver, "Terminate Another Vehicle", true,true);
			RC_Global.waitUntilPanelVisibility(driver,"Terminate Vehicle","TV",true, false);
		}
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
