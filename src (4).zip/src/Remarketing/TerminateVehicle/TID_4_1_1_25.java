package Remarketing.TerminateVehicle;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;
import tools.TotalView.RC_Remarketing;

public class TID_4_1_1_25 {
	public void  TerminateVehicle_TerminateServiceOnlyNotOnTitleManagementUsingExternalUser(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		//RC_Global.login(driver);
		RC_Global.externalUserLogin(driver,"tuffQAtestDontChange","");
		RC_Global.navigateTo(driver, "Remarketing", "Terminate Vehicle", "");
		//RC_Global.enterCustomerNumber(driver, "LS008742", "", "",true);
		RC_Global.clickButton(driver, "Search",true,true);
		RC_Global.waitElementVisible(driver,30,"//tbody//tr[1]","Grid Row",true, false);
		
		RC_Global.clickUsingXpath(driver, "//div/span[text()='Agreement Type']", "Sort Agreement Type", false, false);
		RC_Global.clickUsingXpath(driver, "//div/span[text()='Agreement Type']", "Sort Agreement Type", false, false);
		RC_Remarketing.selectRowWithAgreementTypeFromGrid(driver,"Services Only",true);
		RC_Global.clickButton(driver, "Select Vehicle", true,true);
		RC_Manage.waitUntilMethods(driver, "(//button[text()='Select Vehicle '])[1]/div[@ng-show='vm.isSelectingVehicle']","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 30, "(//h5[span[text()='Terminate Vehicle']])[2]", "TermateVehicle Page", true, false);
		Thread.sleep(2000);
		RC_Global.panelAction(driver,"xpathclose","(//h5[span[text()='Terminate Vehicle']])[1]",false, false);
		Thread.sleep(3000);
		RC_Global.panelAction(driver,"expand","Terminate Vehicle",true, false);
	//	RC_Global.panelAction(driver,"expand","Terminate Vehicle",true);
		
		Thread.sleep(2000);
		RC_Global.waitElementVisible(driver,30,"(//label[contains(text(),'Terminate Services Only')]/../input[contains(@type,'radio')])[1]","Radio Button",true,true);
		boolean TerminateService= RC_Global.waitElementVisible(driver,5,"(//label[contains(text(),'Terminate Services Only')]/../input[contains(@type,'radio')])[1]","Radio Button",true,true);
		if(TerminateService==true)
		{
			queryObjects.logStatus(driver, Status.PASS, "Terminate Service only Radio Button", "Present", null);
		}
		boolean MerchantsSellAndTerminate =  RC_Global.waitElementVisible(driver,5,"(//label[contains(text(),'Merchants to Sell and Terminate Services Only')]/../input[contains(@type,'radio')])[1]","Radio Button",true, false);
		if(MerchantsSellAndTerminate=true)
		{
			queryObjects.logStatus(driver, Status.PASS, "Merchants to Sell and Terminate Services Only Radio Button", "Present", null);
		}
		RC_Global.clickUsingXpath(driver, "(//label[contains(text(),'Terminate Services Only')]/../input[contains(@type,'radio')])[1]", "Radio Button", true,true);
		RC_Global.clickButton(driver, "Next", true,true);
		RC_Global.waitUntilPanelVisibility(driver,"Services Termination Request","TV",true, false);
		
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Billing Details", false);
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Vehicle Program Termination", false);
		
		RC_Global.createNode(driver,"Customer and Vehicle Information Section");
		String CustName = driver.findElement(By.xpath("(//div//label[contains(text(),'Customer Name')]/../following::div//span)[1]")).getText();
		String VehiModel = driver.findElement(By.xpath("(//div//label[contains(text(),'Year / Make / Model')]/../following::div//span)[1]")).getText();
		String DriverName = driver.findElement(By.xpath("//div//label[contains(text(),'Driver/Pool Name')][1]/../following::div[1]//a")).getText();
		RC_Global.createNode(driver,"Billing Details Section");
		 String BillDetail1 = driver.findElement(By.xpath("(//fieldset//legend[contains(text(),'Billing Details')]/../following::label[contains(text(),'In Service Date:')][1]/../following::div//span)[1]")).getText();
		 String BillDetail2 = driver.findElement(By.xpath("(//fieldset//legend[contains(text(),'Billing Details')]/../following::label[contains(text(),'Months in Service:')][1]/../following::div//span)[1]")).getText();
		 queryObjects.logStatus(driver, Status.PASS, "Billing Details - In Service Date", ""+BillDetail1,null );
		 queryObjects.logStatus(driver, Status.PASS, "Billing Details - Months in Service:", ""+BillDetail2,null );
		 RC_Global.createNode(driver,"Vehicle Program Termination");
		 RC_Remarketing.vehicleProgramTermination(driver,"Yes","Yes","Yes",true);
		 RC_Global.clickButton(driver, "Back",true,true);
		 RC_Global.clickButton(driver, "Next",true,true);
		 RC_Global.clickButton(driver, "Submit Vehicle Termination",true,true);
		 RC_Manage.waitUntilMethods(driver, "//div[@ng-show='vm.isSubmitting']","class","ng-hide", "attribute visible");
		 Thread.sleep(1000);
		 RC_Global.waitUntilPanelVisibility(driver,"Confirmation","TV",true,false);
		 while(((WebElement)(driver.findElement(By.xpath("//div//h4")))).getText().length()>0)//Might become an infinite loop in case of a bug at this point
			{
		        try {
		        	
			          Thread.sleep(100);
			        } catch(InterruptedException e) 
		        		{
				          
				        }
			}
		 String SaleStatus = driver.findElement(By.xpath("//label[contains(text(),'Current Sale Status')]/following::span[1]")).getText();
		 if(SaleStatus.length()>0)
		 {
			 if(SaleStatus.equalsIgnoreCase("Sold"))
				 queryObjects.logStatus(driver, Status.PASS, "Current Sale Status", SaleStatus,null );
		 }
		 RC_Global.createNode(driver,"Termination Request Summary - Section");
		 
		 if(driver.findElements(By.xpath("//label[contains(text(),'Request Submitted On:')]/following::span[1]")).size()>0) {
			 String RequestSubmittedDate = driver.findElement(By.xpath("//label[contains(text(),'Request Submitted On:')]/following::span[1]")).getText();
			 queryObjects.logStatus(driver, Status.PASS, "Request Submitted On: ", RequestSubmittedDate,null );
		 }
		 if(driver.findElements(By.xpath("//label[contains(text(),'Confirmation Number:')]/following::span[1]")).size()>0){
			 String ConfirmationNumber = driver.findElement(By.xpath("//label[contains(text(),'Confirmation Number:')]/following::span[1]")).getText();
			 queryObjects.logStatus(driver, Status.PASS, "Confirmation Number: ", ConfirmationNumber,null );
		 }
		 
		 if(driver.findElements(By.xpath("//label[contains(text(),'Request Submitted By:')]/following::span[1]")).size()>0){
			 String RequestSubmittedBy = driver.findElement(By.xpath("//label[contains(text(),'Request Submitted By:')]/following::span[1]")).getText();
			 queryObjects.logStatus(driver, Status.PASS, "Request Submitted By: ", RequestSubmittedBy,null );
		 }
		 if(driver.findElements(By.xpath("//label[contains(text(),'Driver/Pool Name:')]/following::span[1]")).size()>0){
			 String DriverPoolName = driver.findElement(By.xpath("//label[contains(text(),'Driver/Pool Name:')]/following::span[1]")).getText();
			 queryObjects.logStatus(driver, Status.PASS, "Driver/Pool Name: ", DriverPoolName,null );
		 }
		 RC_Global.createNode(driver,"Vehicle Program Termination - Section");
		 String VehicleTerminationLabel1= driver.findElement(By.xpath("//legend[contains(text(),'Vehicle Program Termination')]/following::label[1]")).getText();
		 String VehicleTerminationLabel2= driver.findElement(By.xpath("//legend[contains(text(),'Vehicle Program Termination')]/following::label[2]")).getText();
		 String VehicleTerminationLabel3= driver.findElement(By.xpath("//legend[contains(text(),'Vehicle Program Termination')]/following::label[3]")).getText();
		 
		 String VehicleTerminationData1= driver.findElement(By.xpath("//legend[contains(text(),'Vehicle Program Termination')]/following::label[1]/following::span[1]")).getText();
		 String VehicleTerminationData2= driver.findElement(By.xpath("//legend[contains(text(),'Vehicle Program Termination')]/following::label[2]/following::span[2]")).getText();
		 String VehicleTerminationData3= driver.findElement(By.xpath("//legend[contains(text(),'Vehicle Program Termination')]/following::label[3]/following::span[3]")).getText();
		 
		 queryObjects.logStatus(driver, Status.PASS, VehicleTerminationLabel1, VehicleTerminationData1,null );
		 queryObjects.logStatus(driver, Status.PASS, VehicleTerminationLabel2, VehicleTerminationData2,null );
		 queryObjects.logStatus(driver, Status.PASS, VehicleTerminationLabel3, VehicleTerminationData3,null );
		 
		 queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
