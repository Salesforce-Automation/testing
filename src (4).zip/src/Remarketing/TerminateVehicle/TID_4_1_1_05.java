package Remarketing.TerminateVehicle;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;
import tools.TotalView.RC_Remarketing;

public class TID_4_1_1_05 {
	public void TerminateVehicle_VerifyCVT_LeaseTurnIn(WebDriver driver, BFrameworkQueryObjects queryObjects)throws Exception
	{
		String menu = "Remarketing";
		String firstSubMenu = "Terminate Vehicle";
		String AgreementType = "Closed End";
		String [] contactInfoLabel = {"Pickup Location Type","Address 1","City","State","Zip Code","Pickup Contact First Name","Pickup Contact Last Name","Pickup Contact Email","Pickup Contact Phone"};
		String [] contactInfo = {"Residence","1461 Bluejay Rd","Abington","PA","19001-2207","GAIL","BOYD","","(585) 472-4488"};
		
		for(int iterator=0;iterator<2;iterator++) {
			if(iterator==0)
				RC_Global.login(driver);
			else if(iterator==1)
				RC_Global.externalUserLogin(driver,"Remuser01", "No");
		RC_Global.navigateTo(driver,menu,firstSubMenu,"");
		
		if(iterator==0) {
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		}
		RC_Global.clickButton(driver, "Search", true,true);
		RC_Global.waitElementVisible(driver,30,"//tbody//tr[1]","Grid Row",true,false);
		RC_Remarketing.selectRowWithAgreementTypeFromGrid(driver,AgreementType,true);
		RC_Global.clickUsingXpath(driver, "(//button[text()='Select Vehicle '])[1]", "Select Vehicle", true,true);
		RC_Manage.waitUntilMethods(driver, "(//button[text()='Select Vehicle '])[1]/div[@ng-show='vm.isSelectingVehicle']","class","ng-hide", "attribute visible");
		RC_Global.waitUntilPanelVisibility(driver, "Terminate Vehicle", "TV", true,false);
		Thread.sleep(2000);
		RC_Global.clickUsingXpath(driver, "(//h5[span[text()='Terminate Vehicle']]/i[@ng-click='closePanel()'])[1]", "Close Terminate Vahicle", true,false);
		RC_Global.panelAction(driver, "expand", "Terminate Vehicle", true,false);
		RC_Remarketing.validateAgreementType(driver, AgreementType);
		RC_Global.radioButton(driver, "Terminate Vehicle", "Lease Turn In", true);
		RC_Global.clickButton(driver, "Next", true,true);
		RC_Global.waitUntilPanelVisibility(driver, "Vehicle Pickup Information", "TV", true,false);
		RC_Global.clickUsingXpath(driver, "(//label[@name='isDriverOrPoolSelectedYes'])[1]","Driver/Pool Toggle button", true,false);
	    RC_Remarketing.enterVehiclePickupLocationAndContactInformation(driver, contactInfoLabel, contactInfo, true);

    	RC_Remarketing.vehicleProgramTermination(driver,"Yes","Yes","Yes",false);
    	RC_Global.clickUsingXpath(driver, "(//button[text()='Next'])[2]","Next Button", true,true);
    	 Thread.sleep(3000);
 	    if(driver.findElements(By.xpath("//span[text()=' address entered.']")).size()>0){
 	           RC_Global.clickButton(driver, "Save As Entered", false,false);
 	           Thread.sleep(2000);
 	       }
    	RC_Remarketing.damageDisclosure(driver, "Yes", "No", "No", "No", "No", "No","1000", true);
		RC_Global.clickButton(driver, "Submit Vehicle Termination", true,true);	
		RC_Manage.waitUntilMethods(driver, "//div[@ng-show='vm.isSubmitting']","class","ng-hide", "attribute visible");
	    Thread.sleep(1000);
		List <WebElement> Confirm_pop = driver.findElements(By.xpath("//h3[text()='Confirm']"));
		if(Confirm_pop.size()>0) {
		List<WebElement> PopupHeader = driver.findElements(By.xpath("//h3[text()='Confirm']"));
		List<WebElement> PopupMessage = driver.findElements(By.xpath("//p[contains(text(),'Odometer reading entered is less than Latest Odometer for this vehicle')]"));
		if(PopupHeader.size()==1 && PopupMessage.size()==1 )
			queryObjects.logStatus(driver, Status.PASS, "Confirm POPup Message is ", "Displayed", null);
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Confirm POPup Message is ", "Not Displayed", null);
			RC_Global.endTestRun(driver);
		}RC_Global.clickButton(driver, "OK", true,false);
}
		RC_Global.waitUntilPanelVisibility(driver, "Driver Message", "TV", true,false);
		RC_Global.verifyDisplayedMessage(driver, "Successfully Submitted", true);
		RC_Global.clickButton(driver, "Next", true,true);
		
		RC_Global.clickUsingXpath(driver, "//button[text()='Open']", "Open button", false,true);
        Thread.sleep(5000);
        ArrayList<String> getWindows = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(getWindows.get(1)).close();
         
        
        driver.switchTo().window(getWindows.get(0));
        RC_Global.buttonStatusValidation(driver, "Print", "Enable", true);
        RC_Global.clickUsingXpath(driver, "//button[text()='Email']", "Email button", false,true);
        RC_Global.clickButton(driver, "Cancel", false,false);
		RC_Global.clickButton(driver, "Terminate Another Vehicle", true,false);
		RC_Global.waitUntilPanelVisibility(driver, "Terminate Vehicle", "TV", true,false);
		RC_Global.panelAction(driver, "close", "Terminate Vehicle", true,false);
		RC_Global.logout(driver, false);
	}
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

		
	}
}
