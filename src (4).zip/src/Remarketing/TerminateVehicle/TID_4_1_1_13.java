package Remarketing.TerminateVehicle;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;
import tools.TotalView.RC_Remarketing;

public class TID_4_1_1_13 {
	public void TerminateVehicle_ValidateVehiclePickupInformationSectionForOpenEnd(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Remarketing", "Terminate Vehicle", "");
		RC_Global.enterCustomerNumber(driver, "LS008737", "", "",true);
		RC_Global.clickButton(driver, "Search",true,true);
		RC_Global.waitElementVisible(driver,30,"//tbody//tr[1]","Grid Row",true,false);
		RC_Remarketing.selectRowWithAgreementTypeFromGrid(driver,"Open End",true);
		RC_Global.clickButton(driver, "Select Vehicle", true,true);
		RC_Manage.waitUntilMethods(driver, "(//button[text()='Select Vehicle '])[1]/div[@ng-show='vm.isSelectingVehicle']","class","ng-hide", "attribute visible");
		boolean spinner=true;
		WebElement element; 
//		while(spinner==true)
//		{
//			element = driver.findElement(By.xpath("//button[contains(@id,'terminationSelectVehicleTop')]//div"));
//			if(element.getAttribute("class")=="spinner ng-scope ng-hide")
//			{
//	        try {
//	        	spinner=true;
//		          Thread.sleep(100);
//		        } catch(InterruptedException e) 
//	        		{
//			          
//			        }
//			}
//			else
//			{
//				spinner=false;
//				
//			}
//			
//		}
		RC_Global.panelAction(driver,"xpathclose","(//h5[span[text()='Terminate Vehicle']])[1]",false,false);
		RC_Global.panelAction(driver,"expand","Terminate Vehicle",false,false);
		RC_Global.clickUsingXpath(driver, "(//label[contains(text(),'Merchants to Sell')]/../input[contains(@type,'radio')])[1]", "Merchants to Sell Check Box", true,true);
		RC_Global.clickButton(driver, "Next", true,true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Pickup Information","TV",true,false);
		
		RC_Global.createNode(driver, "Vehicle Pickup Information section validation");
		if(driver.findElements(By.xpath("//div//fieldset/legend[contains(text(),'Billing Details')]")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Vehicle pickup information has","Billing Details section", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Vehicle pickup information does not have","Billing Details section", null);
		
		if(driver.findElements(By.xpath("//div//fieldset/legend[contains(text(),'Vehicle Pickup Location and Contact')]")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Vehicle pickup information has ","Vehicle Pickup Location and Contact section", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Vehicle pickup information does not have ","Vehicle Pickup Location and Contact section", null);
		
		RC_Global.createNode(driver, "Billing Details Section Validation");
        String BillingSec1 = driver.findElement(By.xpath("(//legend[text()='Billing Details'])[1]/following::label[1]")).getText();
        String BillingSec1Data = driver.findElement(By.xpath("(//legend[text()='Billing Details'])[1]/following::label[1]/following::span[1]")).getText();
        Thread.sleep(1000);
        
        String BillingSec2 = driver.findElement(By.xpath("(//legend[text()='Billing Details'])[1]/following::label[2]")).getText();
        String BillingSec2Data = driver.findElement(By.xpath("(//legend[text()='Billing Details'])[1]/following::label[1]/following::span[2]")).getText();
        Thread.sleep(1000);
        
        String BillingSec3 = driver.findElement(By.xpath("(//legend[text()='Billing Details'])[1]/following::label[3]")).getText();
        String BillingSec3Data = driver.findElement(By.xpath("(//legend[text()='Billing Details'])[1]/following::label[1]/following::span[3]")).getText();
        Thread.sleep(1000);
        
        String BillingSec4 = driver.findElement(By.xpath("(//legend[text()='Billing Details'])[1]/following::label[4]")).getText();
        String BillingSec4Data = driver.findElement(By.xpath("(//legend[text()='Billing Details'])[1]/following::label[1]/following::span[4]")).getText();
        Thread.sleep(1000);
        
        String BillingSec5 = driver.findElement(By.xpath("(//legend[text()='Billing Details'])[1]/following::label[5]")).getText();
        String BillingSec5Data = driver.findElement(By.xpath("(//legend[text()='Billing Details'])[1]/following::label[1]/following::span[5]")).getText();
        Thread.sleep(1000);
        
        queryObjects.logStatus(driver, Status.PASS, BillingSec1+"", ""+BillingSec1Data,null );
        queryObjects.logStatus(driver, Status.PASS, BillingSec2+"", ""+BillingSec2Data,null );
        queryObjects.logStatus(driver, Status.PASS, BillingSec3+"", ""+BillingSec3Data,null );
        queryObjects.logStatus(driver, Status.PASS, BillingSec4+"", ""+BillingSec4Data,null );
        queryObjects.logStatus(driver, Status.PASS, BillingSec5+"", ""+BillingSec5Data,null );
        
        RC_Global.createNode(driver, "Fields in Vehicle Pickup Location and Contact Section");
        

        
        String VehiclePickUpLocSecLbl4 = driver.findElement(By.xpath("(//legend[text()='Vehicle Pickup Location and Contact'])[1]/following::label[4]")).getText()
        		+""+driver.findElement(By.xpath("(//legend[text()='Vehicle Pickup Location and Contact'])[1]/following::label[4]/../span")).getText();
        
        String VehiclePickUpLocSecLbl6 = driver.findElement(By.xpath("(//legend[text()='Vehicle Pickup Location and Contact'])[1]/following::label[6]")).getText()
        		+""+driver.findElement(By.xpath("(//legend[text()='Vehicle Pickup Location and Contact'])[1]/following::label[6]/../span")).getText();
        
        String VehiclePickUpLocSecLbl7 = driver.findElement(By.xpath("(//legend[text()='Vehicle Pickup Location and Contact'])[1]/following::label[7]")).getText();
        
        String VehiclePickUpLocSecLbl8 = driver.findElement(By.xpath("(//legend[text()='Vehicle Pickup Location and Contact'])[1]/following::label[8]")).getText()
        		+""+driver.findElement(By.xpath("(//legend[text()='Vehicle Pickup Location and Contact'])[1]/following::label[8]/../span")).getText();
        
        String VehiclePickUpLocSecLbl9 = driver.findElement(By.xpath("(//legend[text()='Vehicle Pickup Location and Contact'])[1]/following::label[9]")).getText()
        		+""+driver.findElement(By.xpath("(//legend[text()='Vehicle Pickup Location and Contact'])[1]/following::label[9]/../span")).getText();
        
        String VehiclePickUpLocSecLbl10 = driver.findElement(By.xpath("(//legend[text()='Vehicle Pickup Location and Contact'])[1]/following::label[10]")).getText()
        		+""+driver.findElement(By.xpath("(//legend[text()='Vehicle Pickup Location and Contact'])[1]/following::label[10]/../span")).getText();
        
        String VehiclePickUpLocSecLbl11 = driver.findElement(By.xpath("(//legend[text()='Vehicle Pickup Location and Contact'])[1]/following::label[11]")).getText();
        
        String VehiclePickUpLocSecLbl12 = driver.findElement(By.xpath("(//legend[text()='Vehicle Pickup Location and Contact'])[1]/following::label[12]")).getText()
        		+""+driver.findElement(By.xpath("(//legend[text()='Vehicle Pickup Location and Contact'])[1]/following::label[12]/../span")).getText();
        
        String VehiclePickUpLocSecLbl13 = driver.findElement(By.xpath("(//legend[text()='Vehicle Pickup Location and Contact'])[1]/following::label[13]")).getText()
        		+""+driver.findElement(By.xpath("(//legend[text()='Vehicle Pickup Location and Contact'])[1]/following::label[13]/../span")).getText();
        
        String VehiclePickUpLocSecLbl14 = driver.findElement(By.xpath("(//legend[text()='Vehicle Pickup Location and Contact'])[1]/following::label[14]")).getText();
        
        String VehiclePickUpLocSecLbl15 = driver.findElement(By.xpath("(//legend[text()='Vehicle Pickup Location and Contact'])[1]/following::label[15]")).getText()
        		+""+driver.findElement(By.xpath("(//legend[text()='Vehicle Pickup Location and Contact'])[1]/following::label[15]/../span")).getText();
        
        String VehiclePickUpLocSecLbl16 = driver.findElement(By.xpath("(//legend[text()='Vehicle Pickup Location and Contact'])[1]/following::label[16]")).getText();
        
        String VehiclePickUpLocSecLbl17 = driver.findElement(By.xpath("(//legend[text()='Vehicle Pickup Location and Contact'])[1]/following::label[17]")).getText();
        
        String VehiclePickUpLocSecLbl18 = driver.findElement(By.xpath("(//legend[text()='Vehicle Pickup Location and Contact'])[1]/following::label[18]")).getText();
        
        String VehiclePickUpLocSecLbl19 = driver.findElement(By.xpath("(//legend[text()='Vehicle Pickup Location and Contact'])[1]/following::label[19]")).getText()
        		+""+driver.findElement(By.xpath("(//legend[text()='Vehicle Pickup Location and Contact'])[1]/following::label[19]/../span")).getText();
        		
        
        String VehiclePickUpLocSecLbl19Data =driver.findElement(By.xpath("(//legend[text()='Vehicle Pickup Location and Contact'])[1]/following::label[19]/following::div[1]//div//label[1]")).getText()
        		+"/"+driver.findElement(By.xpath("(//legend[text()='Vehicle Pickup Location and Contact'])[1]/following::label[19]/following::div[1]//div//label[2]")).getText();
        
        
      String VehiclePickUpLocSecLbl1 = driver.findElement(By.xpath("(//legend[text()='Vehicle Pickup Location and Contact'])[1]/following::label[1]")).getText();
      
      String VehiclePickUpLocSecLbl1Data =driver.findElement(By.xpath("(//legend[text()='Vehicle Pickup Location and Contact'])[1]/following::label[1]/following::div[1]//div//label[1]")).getText()
      		+" and "+driver.findElement(By.xpath("(//legend[text()='Vehicle Pickup Location and Contact'])[1]/following::label[1]/following::div[1]//div//label[2]")).getText();
        
        queryObjects.logStatus(driver, Status.PASS, VehiclePickUpLocSecLbl1+"", VehiclePickUpLocSecLbl1Data,null );
        queryObjects.logStatus(driver, Status.PASS, VehiclePickUpLocSecLbl4+"", "Field present",null );
        queryObjects.logStatus(driver, Status.PASS, VehiclePickUpLocSecLbl6+"", "Field present",null );
        queryObjects.logStatus(driver, Status.PASS, VehiclePickUpLocSecLbl7+"", "Field present",null );
        queryObjects.logStatus(driver, Status.PASS, VehiclePickUpLocSecLbl8+"", "Field present",null );
        queryObjects.logStatus(driver, Status.PASS, VehiclePickUpLocSecLbl9+"", "Field present",null );
        queryObjects.logStatus(driver, Status.PASS, VehiclePickUpLocSecLbl10+"", "Field present",null );
        queryObjects.logStatus(driver, Status.PASS, VehiclePickUpLocSecLbl11+"", "Field present",null );
        queryObjects.logStatus(driver, Status.PASS, VehiclePickUpLocSecLbl12+"", "Field present",null );
        queryObjects.logStatus(driver, Status.PASS, VehiclePickUpLocSecLbl13+"", "Field present",null );
        queryObjects.logStatus(driver, Status.PASS, VehiclePickUpLocSecLbl14+"", "Field present",null );
        queryObjects.logStatus(driver, Status.PASS, VehiclePickUpLocSecLbl15+"", "Field present",null );
        queryObjects.logStatus(driver, Status.PASS, VehiclePickUpLocSecLbl16+"", "Field present",null );
        queryObjects.logStatus(driver, Status.PASS, VehiclePickUpLocSecLbl17+"", "Field present",null );
        queryObjects.logStatus(driver, Status.PASS, VehiclePickUpLocSecLbl18+"", "Field present",null );
        queryObjects.logStatus(driver, Status.PASS, VehiclePickUpLocSecLbl19+"", VehiclePickUpLocSecLbl19Data,null );
        
        if(driver.findElements(By.xpath("(//div//label[contains(text(),'Secondary Vehicle Pickup Contact?')]/../following::label[contains(@uib-btn-radio,'true')])[1]")).size()>0)
        {
        	queryObjects.logStatus(driver, Status.PASS, "Secondary Vehicle Pickup Contact options selected" , "Yes",null );
        }
        else
        {
        	queryObjects.logStatus(driver, Status.PASS, "Secondary Vehicle Pickup Contact options selected" , "No",null );
        }
        
        if(driver.findElements(By.xpath("(//div//label[contains(text(),'Default Contact & Location')]/../following::label[contains(@uib-btn-radio,'true')])[1]")).size()>0)
        {
        	queryObjects.logStatus(driver, Status.PASS, "Default Contact & Location options selected" , "Driver/Pool",null );
        }
        else
        {
        	queryObjects.logStatus(driver, Status.PASS, "Default Contact & Location options selected" , "Other",null );
        }
        
        queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
    }

}
