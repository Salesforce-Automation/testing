package Remarketing.TerminateVehicle;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;
import tools.TotalView.RC_Remarketing;

public class TID_4_1_1_14 {
	public void TerminateVehicle_VerifyOpenPrintAndEmailButtons(WebDriver driver, BFrameworkQueryObjects queryObjects)throws Exception
	{
		String menu = "Remarketing";
		String firstSubMenu = "Terminate Vehicle";
		String AgreementType = "Services Only";  
		String CustomerNumber = "LS010143";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,"");
		RC_Global.enterCustomerNumber(driver,CustomerNumber, "", "", true);
		RC_Global.clickButton(driver, "Search", true,true);
		RC_Global.waitElementVisible(driver,30,"//tbody//tr[1]","Grid Row",true,false);
		RC_Global.clickUsingXpath(driver, "//div/span[text()='Agreement Type']", "Sort Agreement Type", false,false);
		RC_Global.clickUsingXpath(driver, "//div/span[text()='Agreement Type']", "Sort Agreement Type", false,false);
		
		RC_Remarketing.selectRowWithAgreementTypeFromGrid(driver,AgreementType,true);
		RC_Global.clickUsingXpath(driver, "(//button[text()='Select Vehicle '])[1]", "Select Vehicle", true,true);
		RC_Manage.waitUntilMethods(driver, "(//button[text()='Select Vehicle '])[1]/div[@ng-show='vm.isSelectingVehicle']","class","ng-hide", "attribute visible");
		RC_Global.waitUntilPanelVisibility(driver, "Terminate Vehicle", "TV", true,false);
		Thread.sleep(1000);
		RC_Global.clickUsingXpath(driver, "(//h5[span[text()='Terminate Vehicle']]/i[@ng-click='closePanel()'])[1]", "Close Terminate Vahicle", true,false);
		RC_Global.panelAction(driver, "expand", "Terminate Vehicle", true,false);
		RC_Remarketing.validateAgreementType(driver, AgreementType);
		RC_Global.radioButton(driver, "Terminate Vehicle", "Terminate Services Only", true);
		RC_Global.clickButton(driver, "Next", true,true);
		RC_Global.waitUntilPanelVisibility(driver, "Services Termination Request", "TV", true,false);
    	RC_Remarketing.vehicleProgramTermination(driver,"Yes","Yes","Yes",false);
		RC_Global.clickUsingXpath(driver, "(//button[text()='Submit Vehicle Termination'])[1]","Submit Vehicle Termination button in Services Termination Request page", true,true);
		RC_Manage.waitUntilMethods(driver, "//div[@ng-show='vm.isSubmitting']","class","ng-hide", "attribute visible");
	    Thread.sleep(1000);
		RC_Global.waitUntilPanelVisibility(driver, "Confirmation", "TV", true,false);
		RC_Global.verifyDisplayedMessage(driver, "Successfully Submitted", true);
		
		RC_Global.clickUsingXpath(driver, "//button[text()='Open']", "Open button", false,true);
        Thread.sleep(5000);
        ArrayList<String> getWindows = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(getWindows.get(1)).close();
        driver.switchTo().window(getWindows.get(0));
        RC_Global.buttonStatusValidation(driver, "Print", "Enable", true);
        RC_Global.clickUsingXpath(driver, "//button[text()='Email']", "Email button", false,true);
        RC_Global.clickButton(driver, "Cancel", false,false);
        
		RC_Global.panelAction(driver, "close", "Confirmation", true,true);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);	
	
}
	}
