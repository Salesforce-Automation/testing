package Remarketing.TerminateVehicle;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;
import tools.TotalView.RC_Remarketing;

public class TID_4_1_1_15 {
		public void TerminateVehicle_TerminateServicesOnlyNotOnTitleManagement(WebDriver driver, BFrameworkQueryObjects queryObjects)throws Exception
		{
			String menu = "Remarketing";
			String firstSubMenu = "Terminate Vehicle";
			String AgreementType = "Services Only";  
			String CustomerNumber = "LS010143";
			WebDriverWait wait = new WebDriverWait(driver,30);
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			
			RC_Global.login(driver);
			RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
			RC_Global.waitUntilPanelVisibility(driver, "Customer Administration", "TV", true,false);
			RC_Global.enterCustomerNumber(driver,CustomerNumber, "", "", true);
			RC_Global.waitElementVisible(driver, 30, "//a[text()='Customer Summary']", "Customer Summary Tab", true,false);
			RC_Global.clickUsingXpath(driver, "//a[text()='Remarketing']", "Remarketing Tab", true,true);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//legend[text()='Remarketing Enrollment']")));
			if(!(driver.findElements(By.xpath("//label[contains(@class,'disabled-active-button') and @name='buttonCoutesySalePermittedNo']")).size()==0)) {
				RC_Global.clickUsingXpath(driver, "//label[@name='buttonCoutesySalePermittedYes']", "CoutesySale Permitted Yes", true,false);
				RC_Global.selectDropdownOption(driver, "paymentType", "Invoiced Credit", true,true);
				WebElement savebutton = driver.findElement(By.xpath("//button[text()='Save']"));
				executor.executeScript("arguments[0].click();", savebutton);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h4[text()='Update successful']")));
				RC_Global.verifyDisplayedMessage(driver, "Update successful", true);
				queryObjects.logStatus(driver, Status.PASS,"CoutesySale Permitted field is set to", "Yes",null );
			}
			RC_Global.panelAction(driver, "close", "Customer Administration", true,false);

			RC_Global.navigateTo(driver,menu,firstSubMenu,"");
			RC_Global.enterCustomerNumber(driver,CustomerNumber, "", "", true);
			RC_Global.clickButton(driver, "Search", true,true);
			RC_Global.waitElementVisible(driver,30,"//tbody//tr[1]","Grid Row",true,false);
			RC_Global.clickUsingXpath(driver, "//div/span[text()='Agreement Type']", "Sort Agreement Type", false,false);
			RC_Global.clickUsingXpath(driver, "//div/span[text()='Agreement Type']", "Sort Agreement Type", false,false);
			
			RC_Remarketing.selectRowWithAgreementTypeFromGrid(driver,AgreementType,true);
			RC_Global.clickUsingXpath(driver, "(//button[text()='Select Vehicle '])[1]", "Select Vehicle", true,true);
			RC_Manage.waitUntilMethods(driver, "(//button[text()='Select Vehicle '])[1]/div[@ng-show='vm.isSelectingVehicle']","class","ng-hide", "attribute visible");
			RC_Global.waitElementVisible(driver, 30,"//legend[text()='Specify Vehicle Termination Method']", "Termination Method Selection Page", true,false);
			//RC_Global.waitUntilPanelVisibility(driver, "Terminate Vehicle", "TV", true);
			Thread.sleep(1000);
			RC_Global.clickUsingXpath(driver, "(//h5[span[text()='Terminate Vehicle']]/i[@ng-click='closePanel()'])[1]", "Close Terminate Vahicle", true,false);
			RC_Global.panelAction(driver, "expand", "Terminate Vehicle", true,false);
			RC_Remarketing.validateAgreementType(driver, AgreementType);
			RC_Global.radioButton(driver, "Terminate Vehicle", "Terminate Services Only", true);
			RC_Global.clickButton(driver, "Next", true,true);
			RC_Global.waitUntilPanelVisibility(driver, "Services Termination Request", "TV", true,false);
			RC_Global.createNode(driver, "Billing Details - Section Validation");
			String BillingSec1 = driver.findElement(By.xpath("(//legend[text()='Billing Details'])[1]/following::label[1]")).getText();
			String BillingSec1Data = driver.findElement(By.xpath("(//legend[text()='Billing Details'])[1]/following::label[1]/following::span[1]")).getText();
			Thread.sleep(1000);
			String BillingSec2 = driver.findElement(By.xpath("(//legend[text()='Billing Details'])[1]/following::label[2]")).getText();
			String BillingSec2Data = driver.findElement(By.xpath("(//legend[text()='Billing Details'])[1]/following::label[1]/following::span[2]")).getText();
            queryObjects.logStatus(driver, Status.PASS, BillingSec1+"", ""+BillingSec1Data,null );
            queryObjects.logStatus(driver, Status.PASS, BillingSec2+"", ""+BillingSec2Data,null );
            Thread.sleep(2000);
			RC_Global.createNode(driver, "Vehicle Program Termination-Section Validation");
			//section validation
			String driverName = driver.findElement(By.xpath("//a[@ng-click='vm.driverNameSelected();']")).getText();
			List<WebElement> programDriver = driver.findElements(By.xpath("//div[text()=' Is "+driverName+" still an active Employee with the Company? ']"));
	        List<WebElement> programFuel = driver.findElements(By.xpath("//div[text()=' Is "+driverName+" remaining enrolled in Fuel? ']"));
	        List<WebElement> programPersonaluse = driver.findElements(By.xpath("//div[text()=' Is "+driverName+" remaining enrolled in Personal Use? ']"));
	        if(programDriver.size()>0 && programFuel.size()>0 && programPersonaluse.size()>0) {
	            queryObjects.logStatus(driver, Status.PASS, "Driver Status:", programDriver.get(0).getText()+"",null );
	            queryObjects.logStatus(driver, Status.PASS, "Fuel:", programFuel.get(0).getText()+"",null );
	            queryObjects.logStatus(driver, Status.PASS, "Personal Use:", programPersonaluse.get(0).getText()+"",null );
	        }
	    	String[] TerminationOption = RC_Remarketing.vehicleProgramTermination(driver,"Yes","Yes","Yes",false);
			RC_Global.clickUsingXpath(driver, "(//button[text()='Back'])[1]","Back button in Services Termination Request page", true,false);
			RC_Global.waitUntilPanelVisibility(driver, "Terminate Vehicle", "TV", true,false);
			RC_Global.clickButton(driver, "Next", true,true);
			RC_Global.waitUntilPanelVisibility(driver, "Services Termination Request", "TV", true,false);
			//data validation
			String BillingSecData1 = driver.findElement(By.xpath("(//legend[text()='Billing Details'])[1]/following::label[1]/following::span[1]")).getText();
			String BillingSecData2 = driver.findElement(By.xpath("(//legend[text()='Billing Details'])[1]/following::label[1]/following::span[2]")).getText();
			if(BillingSec1Data.contains(BillingSecData1) && BillingSec2Data.contains(BillingSecData2))
		        queryObjects.logStatus(driver, Status.PASS, "Servce Termination Data's are displaying correctly", "",null );	
			else
	            queryObjects.logStatus(driver, Status.FAIL, "Servce Termination Data's are displayed are incorrect", "",null );

			
			RC_Global.clickUsingXpath(driver, "(//button[text()='Submit Vehicle Termination'])[1]","Submit Vehicle Termination button in Services Termination Request page", true,false);
			RC_Manage.waitUntilMethods(driver, "//div[@ng-show='vm.isSubmitting']","class","ng-hide", "attribute visible");
		    Thread.sleep(1000);
			RC_Global.waitUntilPanelVisibility(driver, "Confirmation", "TV", true,false);
			RC_Global.verifyDisplayedMessage(driver, "Successfully Submitted", true);
			String[]SectionsToValidate = {"TitleAddress","VehicleProgramTermination",null,null};
			RC_Remarketing.terminateConfirmationSectionValidation(driver,TerminationOption,SectionsToValidate ,true);
			String SaleStatus = driver.findElement(By.xpath("//label[text()='Current Sale Status']/following::div[1]/span")).getText();
			if(SaleStatus.equalsIgnoreCase("Sold"))
				queryObjects.logStatus(driver, Status.PASS,"Sale status is successfully update to", ""+SaleStatus,null );
			else
	            queryObjects.logStatus(driver, Status.FAIL, "Sale status failed to update to", ""+SaleStatus,null );
			RC_Global.panelAction(driver, "close", "Confirmation", true,true);
			
			queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);	
		}

}
