package Remarketing.TerminateVehicle;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;
import tools.TotalView.RC_Remarketing;

public class TID_4_1_1_02 {
	public void TerminateVehicle_Verify_CVT_Merchants_To_Sell_And_TerminateServicesOnly(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		WebDriverWait wait = new WebDriverWait(driver,30);
		RC_Global.login(driver);
		String PickUpContacNo = "(308) 325-2910";
		String Phone="";
		String Address1="";
		String City="";
		String EmployeeActiveIndicator="";
		String FuelIndicator="";
		String PersonalUseIndicator="";
		
		RC_Global.navigateTo(driver, "Remarketing", "Terminate Vehicle", "");
		RC_Global.waitElementVisible(driver, 30, "//input[@name='customerInput']", "Input CustomerNumber",true, false);
		RC_Global.enterCustomerNumber(driver, "LS010143", "", "",true);
		RC_Global.clickButton(driver, "Search",true,true);
		
		RC_Global.waitElementVisible(driver,30,"//tbody//tr[1]","Grid load",true,false);
		RC_Global.clickUsingXpath(driver, "//div/span[text()='Agreement Type']", "Sort Agreement Type", false, false);
		RC_Global.clickUsingXpath(driver, "//div/span[text()='Agreement Type']", "Sort Agreement Type", false, false);
		
		RC_Remarketing.selectRowWithAgreementTypeFromGrid(driver,"Services Only",true);
		RC_Global.clickButton(driver, "Select Vehicle", true, true);
		RC_Manage.waitUntilMethods(driver, "(//button[text()='Select Vehicle '])[1]/div[@ng-show='vm.isSelectingVehicle']","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 30, "(//h5[span[text()='Terminate Vehicle']])[2]", "TermateVehicle Page", true, false);
		Thread.sleep(2000);
		RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='Terminate Vehicle']])[1]", false, false);
		RC_Global.panelAction(driver, "expand", "Terminate Vehicle", false, false);
		
		RC_Global.clickUsingXpath(driver, "(//label[contains(text(),'Merchants to Sell and Terminate Services Only')]/../input[contains(@type,'radio')])[1]", "Check Box", true, true);
		String winHandleBefore = driver.getWindowHandle();
		RC_Global.clickButton(driver, "Next", true, true);
		RC_Global.createNode(driver,"Vehicle Pickup Information");
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Pickup Information","TV",true,false);
		RC_Global.clickUsingXpath(driver,"(//div//label[contains(@name,'isDriverOrPoolSelectedYes')])[1]","Driver/Pool",true,true);
		Thread.sleep(2000);
		EmployeeActiveIndicator = ((WebElement)(driver.findElement(By.xpath("//div//label[contains(@name,'buttonEmployeeActiveWithCompanyIndicatorYes')]")))).getAttribute("disabled");
		if (EmployeeActiveIndicator==null)
			RC_Global.clickUsingXpath(driver,"//div//label[contains(@name,'buttonEmployeeActiveWithCompanyIndicatorYes')]","Employee Active Indicator", true, true);
		FuelIndicator = 	((WebElement)(driver.findElement(By.xpath("//div//label[contains(@name,'buttonFuelIndicatorYes')]")))).getAttribute("disabled");
		if (FuelIndicator==null)
			RC_Global.clickUsingXpath(driver,"//div//label[contains(@name,'buttonFuelIndicatorYes')]","Fuel Indicator", true, true);
		PersonalUseIndicator = ((WebElement)(driver.findElement(By.xpath("//div//label[contains(@name,'buttonPersonalUseIndicatorYes')]")))).getAttribute("disabled");
		if (PersonalUseIndicator==null)
			RC_Global.clickUsingXpath(driver,"//div//label[contains(@name,'buttonPersonalUseIndicatorYes')]","Personal Use Indicator", true, true);
		
		Address1= driver.findElement(By.xpath("(//div//label[contains(text(),'Address 1')]/../following-sibling::div//input)[4]")).getText();
		if(Address1.length()==0)
		{
			RC_Global.enterInput(driver,"4503 Glassyrock Dr", ((WebElement)(driver.findElement(By.xpath("(//div//label[contains(text(),'Address 1')]/../following-sibling::div//input)[4]")))), true,false);
		}
		City = driver.findElement(By.xpath("(//div//label[contains(text(),'City')]/../following-sibling::div//input)[4]")).getText();
		if(City.length()==0)
		{
			RC_Global.enterInput(driver,"Valrico", ((WebElement)(driver.findElement(By.xpath("(//div//label[contains(text(),'City')]/../following-sibling::div//input)[4]")))), true,false);
			driver.findElement(By.xpath("(//select[@id='state'])[4]")).click();
			driver.findElement(By.xpath("(//select[@id='state'])[4]/option[text()='FL']")).click();
			//RC_Global.selectDropdownOption(driver, "state", "FL", true);
		}
		String Zip = driver.findElement(By.xpath("(//div//label[contains(text(),'Zip Code')]/../following-sibling::div//input)[4]")).getText();
		if(Zip.length()==0)
		{
			RC_Global.enterInput(driver,"33594-0029", ((WebElement)(driver.findElement(By.xpath("(//div//label[contains(text(),'Zip Code')]/../following-sibling::div//input)[4]")))), true,false);
		}
		
		String PickUpFirstName = driver.findElement(By.xpath("(//div//label[contains(text(),'Pickup Contact First Name')]/../following-sibling::div//input)[1]")).getText();
		if(PickUpFirstName.length()==0)
		{
			RC_Global.enterInput(driver,"Nathan", ((WebElement)(driver.findElement(By.xpath("(//div//label[contains(text(),'Pickup Contact First Name')]/../following-sibling::div//input)[1]")))), true,false);
		}
		
		String PickUpLastName = driver.findElement(By.xpath("(//div//label[contains(text(),'Pickup Contact Last Name ')]/../following-sibling::div//input)[1]")).getText();
		if(PickUpLastName.length()==0)
		{
			RC_Global.enterInput(driver,"Walden", ((WebElement)(driver.findElement(By.xpath("(//div//label[contains(text(),'Pickup Contact Last Name ')]/../following-sibling::div//input)[1]")))), true,false);
		}
		
		String PickUpEmail = driver.findElement(By.xpath("(//div//label[contains(text(),'Pickup Contact Email')]/../following-sibling::div//input)[1]")).getText();
		if(PickUpEmail.length()==0)
		{
			RC_Global.enterInput(driver,"FACILITIESINTERNALTECHS@WAWA.COM", ((WebElement)(driver.findElement(By.xpath("(//div//label[contains(text(),'Pickup Contact Email')]/../following-sibling::div//input)[1]")))), true,false);
		}
		
		Phone = driver.findElement(By.xpath("(//div//label[contains(text(),'Pickup Contact Phone')]/../following-sibling::div//input)[1]")).getText();
		if(Phone.trim().length()==0)
		{
			RC_Global.enterInput(driver,PickUpContacNo, ((WebElement)(driver.findElement(By.xpath("(//div//label[contains(text(),'Pickup Contact Phone')]/../following-sibling::div//input)[1]")))), true,false);
		}
		RC_Global.clickButton(driver, "Next", true,true);
		Thread.sleep(2000);
		
		if(driver.findElements(By.xpath("//button[contains(text(),'Select Recommended Address')]")).size()>0)
			RC_Global.clickButton(driver, "Select Recommended Address", true,false);
			
		if(driver.findElements(By.xpath("//button[contains(text(),'Save As Entered')]")).size()>0)
			RC_Global.clickButton(driver, "Save As Entered", true,false);
		//RC_Global.createNode(driver,"Disclosure Agreement");
		RC_Global.waitUntilPanelVisibility(driver,"Disclosure Agreement","TV",true,false);
		RC_Global.enterInput(driver,"300", ((WebElement)(driver.findElement(By.xpath("//input[contains(@id,'odometer')]")))), true,false);
		RC_Global.clickUsingXpath(driver,"//label[contains(@name,'buttonVehicleDrivableIndicatorYes')]","Vehicle drivble",true,false);
		RC_Global.clickUsingXpath(driver,"//label[contains(@name,'buttonHasHeavyDamageIndicatorNo')]","Damage Indicator",true,false);
		RC_Global.clickUsingXpath(driver,"//label[contains(@name,'buttonHasBeenStolenIndicatorNo')]","Stolen Indicator",true,false);
		RC_Global.clickUsingXpath(driver,"//label[contains(@name,'buttonHasFloodDamageIndicatorNo')]","Damage Indicator",true,false);
		RC_Global.clickUsingXpath(driver,"//label[contains(@name,'buttonHasBeenSalvagedIndicatorNo')]","Salvaged Indicator",true,false);
		RC_Global.clickUsingXpath(driver,"//label[contains(@name,'buttonHasAirbagAlterationsIndicatorNo')]","Airbag",true,false);
		winHandleBefore = driver.getWindowHandle();
		RC_Global.clickButton(driver, "Open", true,true);
		Thread.sleep(3000);
		driver.switchTo().window(winHandleBefore);
		Thread.sleep(1000);
		winHandleBefore = driver.getWindowHandle();
		RC_Global.clickButton(driver, "Email", true,true);
		Thread.sleep(2000);
		RC_Global.clickButton(driver, "Cancel", false,false);
		driver.switchTo().window(winHandleBefore);
		Thread.sleep(2000);
		RC_Global.clickButton(driver, "Submit Vehicle Termination", true,true);
		RC_Manage.waitUntilMethods(driver, "//div[@ng-show='vm.isSubmitting']","class","ng-hide", "attribute visible");
	    Thread.sleep(1000);
		try {
		driver.findElement(By.xpath("//button[contains(text(),'OK')]")).click();
		Thread.sleep(2000);}
		catch (Exception e){
		}
		RC_Global.waitUntilPanelVisibility(driver, "Driver Message", "TV", false,false);
		if(driver.findElements(By.xpath("//button[contains(text(),'Terminate Another Vehicle')]")).size()>0)
			RC_Global.clickUsingXpath(driver,"//button[contains(text(),'Terminate Another Vehicle')]","Terminate Another Vehicle Button",true,true);
		
		else
		{
			RC_Global.clickButton(driver, "Next", true,true);
			RC_Global.waitUntilPanelVisibility(driver,"Confirmation","TV",true,true);
			winHandleBefore = driver.getWindowHandle();
			RC_Global.clickButton(driver, "Open", true,true);
			Thread.sleep(3000);
			driver.switchTo().window(winHandleBefore);
			Thread.sleep(1000);
			winHandleBefore = driver.getWindowHandle();
			RC_Global.clickButton(driver, "Email", true, true);
			Thread.sleep(2000);
			RC_Global.clickButton(driver, "Cancel", true,false);
			driver.switchTo().window(winHandleBefore);
			Thread.sleep(1000);
			RC_Global.clickButton(driver, "Terminate Another Vehicle", true, true);
			RC_Global.waitUntilPanelVisibility(driver,"Terminate Vehicle","TV",true,false);
		}
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}

}
