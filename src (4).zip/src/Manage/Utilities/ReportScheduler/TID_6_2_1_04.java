package Manage.Utilities.ReportScheduler;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_2_1_04 {
	public static void ReportScheduler_SkipBlankReports(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		RC_Global.login(driver);
//		RC_Global.enterCustomerFocus(driver, "LS008737", true);
		RC_Global.navigateTo(driver, "Manage", "Utilities", "Report Scheduler");
		RC_Global.enterCustomerNumber(driver, "LS008737", "", "", true);
		
		RC_Global.waitElementVisible(driver, 30, "(//table/tbody/tr)[1]", "Grid record load", true, false);
		Thread.sleep(1000);
		RC_Global.clickUsingXpath(driver, "//table//tr[td[text()='Business and Personal Use'] and td[a[text()=' Deactivate ']]][1]/td/a[text()='Edit']", "Edit link", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Edit Report Schedule", "TV", true, true);
		
		RC_Global.panelAction(driver, "close", "Report Scheduler", true, false);
		RC_Global.panelAction(driver, "expand", "Edit Report Schedule", true, false);
		Thread.sleep(1000);
		RC_Manage.waitUntilMethods(driver, "//div[text()=' Loading Report Schedule... ']/div[contains(@class,'spinner')]","class","ng-hide", "attribute visible");
		Thread.sleep(2000);		
		if(driver.findElement(By.xpath("//div[label[text()='Skip Blank Reports:']]/div/input")).getAttribute("class").contains("ng-not-empty"))
			queryObjects.logStatus(driver, Status.PASS, "Verify 'Skip Blank Reports' checkbox is checked", "'Skip Blank Reports' checkbox is checked", null);
		else if(driver.findElement(By.xpath("//div[label[text()='Skip Blank Reports:']]/div/input")).getAttribute("class").contains("ng-empty"))
			RC_Global.clickUsingXpath(driver, "//div[label[text()='Skip Blank Reports:']]/div/input", "'Skip Blank Reports' checkbox", true, true);
		
		if(driver.findElements(By.xpath("(//i[contains(@ng-click,'removeGroupOrEmail')])[1]")).size()>0)
			
			RC_Global.clickUsingXpath(driver, "(//i[contains(@ng-click,'removeGroupOrEmail')])[1]", "Remove Email", false, false);
		if(driver.findElements(By.xpath("(//i[contains(@ng-click,'removeGroupOrEmail')])[2]")).size()>0)
			RC_Global.clickUsingXpath(driver, "(//i[contains(@ng-click,'removeGroupOrEmail')])[2]", "Remove Email", false, false);
		
		RC_Global.clickUsingXpath(driver, "//div[label[text()='Distribution Group:']]/div/select", "Distribution Group dropdown", true, false);
		if(driver.findElements(By.xpath("//div[label[text()='Distribution Group:']]/div/select/option[2]")).size()>0)
			RC_Global.clickUsingXpath(driver, "//div[label[text()='Distribution Group:']]/div/select/option[2]", "Distribution Group dropdown selection", true, true);
		else {
			RC_Global.clickUsingXpath(driver, "//div[label[text()='Distribution Group:']]/div/select", "Distribution Group dropdown", true, false);
			WebElement individuals = driver.findElement(By.xpath("//div[label[text()='Individual(s):']]/div/input"));
			RC_Global.enterInput(driver, RandomStringUtils.randomAlphanumeric(4)+"@merchantsfleet.com", individuals, true, false);
		}
		RC_Global.clickButton(driver, "Add Selected to To", true, true);
		if(driver.findElement(By.xpath("//label[text()='Email Receipt of Changes ']/input")).getAttribute("class").contains("ng-not-empty"))
			RC_Global.clickUsingXpath(driver, "//label[text()='Email Receipt of Changes ']/input", "Email Receipt of Changes checkbox", true, true);
			
		RC_Global.clickUsingXpath(driver, "(//button[text()='Save'])[2]", "Save button", true, true);
		
		try {
			RC_Global.waitElementVisible(driver, 30, "(//h4[text()='Successfully Scheduled Report'])[2]", "Successful Save Message", true, true);
			queryObjects.logStatus(driver, Status.PASS, "Verify Success Message", "The expected message appeared", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify Success Message", "The expected message did not appear", null);
		}
		
		RC_Global.logout(driver, false);
	}

}
