package Manage.Utilities.ReportScheduler;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_2_1_01 {
	public static void ReportScheduler_ModifyReport(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		String ColumnNames = "Report Name;Report;Group Name;Customer #;Customer Name;Frequency;Next Run;Last Run;Date Created;Expiration Date;Created By;Active;Fleet #;Fleet Name;Account #;Account Name;Sub-Account #;Sub-Account Name";
		boolean isSelect = false;
		RC_Global.login(driver);
		RC_Global.enterCustomerFocus(driver, "LS008737", true);
		Thread.sleep(2000);
		RC_Global.navigateTo(driver, "Manage", "Utilities", "Report Scheduler");
		RC_Global.waitUntilPanelVisibility(driver, "Report Scheduler", "TV", true, false);
		
//		RC_Global.enterCustomerNumber(driver, "LS008737", "", "", true);
		
		RC_Global.createNode(driver, "Verify Customer Info");
		if(driver.findElement(By.xpath("//div[label[text()=' Customer Number ']]/div/input")).getAttribute("disabled").equalsIgnoreCase("true"))
			queryObjects.logStatus(driver, Status.PASS, "Verify Customer Number input is disabled", "Customer Number input box is disabled", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Customer Number input is disabled", "Customer Number input box is not disabled", null);
		
		String customerName = driver.findElement(By.xpath("//div[label[text()='Customer Name:']]/div")).getText();
		String customerNumber = driver.findElement(By.xpath("//div[label[text()='Customer Number:']]/div")).getText();
		String type = driver.findElement(By.xpath("//div[label[text()='Type:']]/div")).getText();
		String customerSince = driver.findElement(By.xpath("//div[label[text()='Customer Since:']]/div")).getText();
		//div[label[text()='Status:']]/div
		
		if(driver.findElements(By.xpath("//div[label[text()='Customer Name:']]/div")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify Customer Name is available", "Customer Name is "+customerName, null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Customer Name is available", "Customer Name is not available", null);
		
		if(driver.findElements(By.xpath("//div[label[text()='Customer Number:']]/div")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify Customer Number is available", "Customer Number is "+customerNumber, null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Customer Number is available", "Customer Number is not available", null);
		
		if(driver.findElements(By.xpath("//div[label[text()='Type:']]/div")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify Type is available", "Type is "+type, null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Type is available", "Type is not available", null);
		
		if(driver.findElements(By.xpath("//div[label[text()='Customer Since:']]/div")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify Customer Since is available", "Customer Since is "+customerSince, null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Customer Since is available", "Customer Since is not available", null);
		
		if(driver.findElement(By.xpath("//div[label[text()='Status:']]/div")).getText().equalsIgnoreCase("Active"))
			queryObjects.logStatus(driver, Status.PASS, "Verify Status is 'Active", "Status is 'Active'", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Status is 'Active", "Status is not 'Active'", null);
		
		RC_Global.createNode(driver, "Verify 'Report Summary' tab is selected by default");
		if(driver.findElement(By.xpath("//li[a[text()='Report Summary']]")).getAttribute("class").contains("active"))
			queryObjects.logStatus(driver, Status.PASS, "Verify 'Report Summary' tab is selected by default", "'Report Summary' tab is selected by default", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify 'Report Summary' tab is selected by default", "'Report Summary' tab is not selected by default", null);

		RC_Global.createNode(driver, "Verify Report Summary Grid Column Names");
		String [] expColName = ColumnNames.split(";");

		for(int i=0; i<expColName.length; i++) {
			try {
				driver.findElement(By.xpath("//table/thead/tr/th/div/span[text()='"+expColName[i]+"']"));				
			}
			catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Validate Report Column Names--->Column: " + expColName[i] + "--->Was NOT Found", e.getLocalizedMessage(), e);
			}
		}
		
		try {
				driver.findElement(By.xpath("//table/thead/tr/th/div[text()='Edit']"));				
			}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Validate Report Column Names--->Column: Edit--->Was NOT Found", e.getLocalizedMessage(), e);
		}
		
		try {
			driver.findElement(By.xpath("//table/thead/tr/th[text()='Copy']"));				
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Validate Report Column Names--->Column: Copy--->Was NOT Found", e.getLocalizedMessage(), e);
		}
	
		try {
			driver.findElement(By.xpath("//table/thead/tr/th/div[text()='Deactivate']"));				
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Validate Report Column Names--->Column: Deactivate--->Was NOT Found", e.getLocalizedMessage(), e);
		}

		RC_Global.waitElementVisible(driver, 30, "(//table/tbody/tr)[1]", "Grid record load", true, false);
		Thread.sleep(1000);
		RC_Global.clickUsingXpath(driver, "//table//tr[td[text()='Business and Personal Use'] and td[a[text()=' Deactivate ']]][1]/td/a[text()='Edit']", "Edit link", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Edit Report Schedule", "TV", true, true);
		
		RC_Global.panelAction(driver, "close", "Report Scheduler", true, false);
		RC_Global.panelAction(driver, "expand", "Edit Report Schedule", true, false);
		Thread.sleep(1000);
		RC_Manage.waitUntilMethods(driver, "//div[text()=' Loading Report Schedule... ']/div[contains(@class,'spinner')]","class","ng-hide", "attribute visible");
		Thread.sleep(2000);
		
		RC_Global.buttonStatusValidation(driver, "Save", "Presence", true);
		RC_Global.buttonStatusValidation(driver, "Cancel", "Presence", true);
		
		RC_Global.createNode(driver, "Verify Edit Report Schedule Sections");
		if(driver.findElements(By.xpath("//legend[text()='Setup']")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify 'Setup' section is present", "'Setup' section is present", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify 'Setup' section is present", "'Setup' section is not present", null);
		
		if(driver.findElements(By.xpath("//legend[text()='Parameters']")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify 'Parameters' section is present", "'Parameters' section is present", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify 'Parameters' section is present", "'Parameters' section is not present", null);
		
		if(driver.findElements(By.xpath("//legend[text()='Output']")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify 'Output' section is present", "'Output' section is present", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify 'Output' section is present", "'Output' section is not present", null);
		
		if(driver.findElements(By.xpath("//legend[text()='Recipients']")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify 'Recipients' section is present", "'Recipients' section is present", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify 'Recipients' section is present", "'Recipients' section is not present", null);

		RC_Global.createNode(driver, "'Setup' section verification");
		if(driver.findElements(By.xpath("//div[label[text()='Scheduled Report Name:*']]/div/input")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify 'Scheduled Report Name' input is present", "'Scheduled Report Name' input is present", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify 'Scheduled Report Name' input is present", "'Scheduled Report Name' input is not present", null);

		if(driver.findElements(By.xpath("//div[label[text()='Scheduled Report Description:']]/div/input")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify 'Scheduled Report Description' input is present", "'Scheduled Report Description' input is present", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify 'Scheduled Report Description' input is present", "'Scheduled Report Description' input is not present", null);
		
		if(driver.findElements(By.xpath("//div[label[text()='Select Report:*']]/div/select")).size()>0) {
			queryObjects.logStatus(driver, Status.PASS, "Verify 'Select Report' dropdown is present", "'Select Report' dropdown is present", null);
			if(driver.findElement(By.xpath("//div[label[text()='Select Report:*']]/div/select")).getAttribute("disabled").equals("true"))
				queryObjects.logStatus(driver, Status.PASS, "Verify 'Select Report' dropdown is disabled", "'Select Report' dropdown is disabled", null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify 'Select Report' dropdown is disabled", "'Select Report' dropdown is not disabled", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify 'Select Report' dropdown is present", "'Select Report' dropdown is not present", null);
	
		if(driver.findElements(By.xpath("//div[label[text()='Customer #:*']]/div/div/div/input")).size()>0) {
			queryObjects.logStatus(driver, Status.PASS, "Verify 'Customer Number' input is present", "'Customer Number' input is present", null);
			if(driver.findElement(By.xpath("//div[label[text()='Customer #:*']]/div/div/div/input")).getAttribute("disabled").equals("true"))
				queryObjects.logStatus(driver, Status.PASS, "Verify 'Customer Number' input is disabled", "'Customer Number' input is disabled", null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify 'Customer Number' input is disabled", "'Customer Number' input is not disabled", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify 'Customer Number' input is present", "'Customer Number' input is not present", null);
		
		if(driver.findElements(By.xpath("(//i[contains(@ng-click,'removeGroupOrEmail')])[1]")).size()>0)
		
			RC_Global.clickUsingXpath(driver, "(//i[contains(@ng-click,'removeGroupOrEmail')])[1]", "Remove Email", false, false);
		if(driver.findElements(By.xpath("(//i[contains(@ng-click,'removeGroupOrEmail')])[2]")).size()>0)
			RC_Global.clickUsingXpath(driver, "(//i[contains(@ng-click,'removeGroupOrEmail')])[2]", "Remove Email", false, false);
		
		WebElement individuals = driver.findElement(By.xpath("//div[label[text()='Individual(s):']]/div/input"));
		RC_Global.clickUsingXpath(driver, "//div[label[text()='Distribution Group:']]/div/select", "Distribution Group dropdown", true, false);
		if(driver.findElements(By.xpath("//div[label[text()='Distribution Group:']]/div/select/option[2]")).size()>0) {
			RC_Global.clickUsingXpath(driver, "//div[label[text()='Distribution Group:']]/div/select/option[2]", "Distribution Group dropdown selection", true, true);
			isSelect = true;
		} else {
			RC_Global.clickUsingXpath(driver, "//div[label[text()='Distribution Group:']]/div/select", "Distribution Group dropdown", true, false);
			RC_Global.enterInput(driver, RandomStringUtils.randomAlphanumeric(4)+"@merchantsfleet.com", individuals, true, false);
		}
		RC_Global.clickButton(driver, "Add Selected to To", true, true);
		if (!isSelect) {
			RC_Global.enterInput(driver, RandomStringUtils.randomAlphanumeric(5)+"@merchantsfleet.com", individuals, true, false);
		}
		RC_Global.clickButton(driver, "Add Selected to CC", true, true);
		if (!isSelect) {
			RC_Global.enterInput(driver, RandomStringUtils.randomAlphanumeric(5)+"@merchantsfleet.com", individuals, true, false);
		}
		RC_Global.clickButton(driver, "Add Selected to BCC", true, true);
		
		if(driver.findElement(By.xpath("//label[text()='Email Receipt of Changes ']/input")).getAttribute("class").contains("ng-not-empty"))
		RC_Global.clickUsingXpath(driver, "//label[text()='Email Receipt of Changes ']/input", "Email Receipt of Changes checkbox", true, true);
		
		RC_Global.clickUsingXpath(driver, "(//button[text()='Save'])[2]", "Save button", true, true);
		
		try {
			RC_Global.waitElementVisible(driver, 30, "(//h4[text()='Successfully Scheduled Report'])[2]", "Successful Save Message", true, true);
			queryObjects.logStatus(driver, Status.PASS, "Verify Success Message", "The expected message appeared", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify Success Message", "The expected message did not appear", null);
		}
		RC_Global.logout(driver, false);
	}
}
