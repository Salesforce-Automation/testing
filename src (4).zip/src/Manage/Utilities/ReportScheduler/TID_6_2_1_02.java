package Manage.Utilities.ReportScheduler;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_2_1_02 {
	public static void ReportScheduler_CopyOrCloneReport(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		RC_Global.login(driver);
//		RC_Global.enterCustomerFocus(driver, "LS008737", true);
		RC_Global.navigateTo(driver, "Manage", "Utilities", "Report Scheduler");
		RC_Global.waitUntilPanelVisibility(driver, "Report Scheduler", "TV", true, false);
		//RC_Global.panelAction(driver, "expand", "Report Scheduler", true, false);
		
		RC_Global.enterCustomerNumber(driver, "LS008737", "", "", true);
		RC_Global.waitElementVisible(driver, 30, "(//table/tbody/tr)[1]", "Grid record load", true, false);
		Thread.sleep(1000);
		RC_Global.clickUsingXpath(driver, "//table//tr[td[a[text()=' Deactivate ']]][1]/td/a[text()='Copy']", "Copy link", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Create Report Schedule", "TV", true, true);
		RC_Global.panelAction(driver, "expand", "Create Report Schedule", true, false);
		RC_Manage.waitUntilMethods(driver, "//div[text()=' Loading Report Schedule... ']/div[contains(@class,'spinner')]","class","ng-hide", "attribute visible");
		Thread.sleep(2000);
		//Reopen the screen again - Suggested by Dmitry
		RC_Global.panelAction(driver, "close", "Create Report Schedule", true, true);
		RC_Global.clickUsingXpath(driver, "//table//tr[td[a[text()=' Deactivate ']]][1]/td/a[text()='Copy']", "Copy link", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Create Report Schedule", "TV", true, true);
		RC_Global.panelAction(driver, "close", "Report Scheduler", true, false);
		RC_Global.panelAction(driver, "expand", "Create Report Schedule", true, false);
		Thread.sleep(1000);
		RC_Manage.waitUntilMethods(driver, "//div[text()=' Loading Report Schedule... ']/div[contains(@class,'spinner')]","class","ng-hide", "attribute visible");
		Thread.sleep(2000);///--------------------------///		
		
		String schReportName = "Sample Report "+RandomStringUtils.randomNumeric(3);
		String schReportDescription = "Sample Report Description "+RandomStringUtils.randomNumeric(3);
		
		WebElement webReportName = driver.findElement(By.xpath("//div[label[text()='Scheduled Report Name:*']]/div/input"));
		WebElement webReportDescription = driver.findElement(By.xpath("//div[label[text()='Scheduled Report Description:']]/div/input"));
		
		RC_Global.enterInput(driver, schReportName, webReportName, true, true);
		RC_Global.enterInput(driver, schReportDescription, webReportDescription, true, true);
		Thread.sleep(4000);
		RC_Manage.waitUntilMethods(driver, "//select[@ng-model='reportForm.Report']","value","", "attribute available");
		RC_Global.selectDropdownOption(driver, "Select Report:*", "Business and Personal Use", true, true);
		
		driver.findElement(By.xpath("//select[@ng-model='reportForm.Report']")).getAttribute("value");

		RC_Global.clickUsingXpath(driver, "//div[label[text()='Reporting Year:']]/div/div/select", "Reporting Year dropdown", true, false);
		RC_Global.clickUsingXpath(driver, "//div[label[text()='Reporting Year:']]/div/div/select/option[3]", "Reporting Year dropdown", true, false);
		
		WebElement endDate = driver.findElement(By.xpath("//div[label[text()='End Date:']]/div/input"));
		RC_Global.enterInput(driver, RC_Global.getDateTime(driver, "MM/dd/yyyy", 2, true), endDate, true, true);
		
		RC_Global.clickUsingXpath(driver, "(//button[text()='Save'])[2]", "Save button", true, true);
		
		try {
			RC_Global.waitElementVisible(driver, 30, "(//h4[text()='Successfully Scheduled Report'])[2]", "Successful Save Message", true, true);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify Success Message", "The expected message did not appear", null);
		}
		
		RC_Global.panelAction(driver, "close", "Create Report Schedule", true, true);
		
		RC_Global.navigateTo(driver, "Manage", "Utilities", "Report Scheduler");
		RC_Global.waitUntilPanelVisibility(driver, "Report Scheduler", "TV", true, false);
		RC_Global.enterCustomerNumber(driver, "LS008737", "", "", true);
		
		RC_Global.waitElementVisible(driver, 30, "(//table/tbody/tr)[1]", "Grid record load", true, false);
		
		WebElement search = driver.findElement(By.xpath("//div[h3[text()='Report Summary']]//input"));
		RC_Global.enterInput(driver, "Business and Personal Use", search, true, true);
		try {
			RC_Global.clickUsingXpath(driver, "//tr[td[text()='"+RC_Global.getDateTime(driver, "MM/dd/yyyy", 0, true)+"']]/td/a[text()='"+schReportName+"']", "Verify the changed report name", true, true);
			queryObjects.logStatus(driver, Status.PASS, "Verify cloned report", "Clone Report "+schReportName+" is present", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify cloned report", "Clone Report "+schReportName+" is not present", null);
		}
		RC_Global.logout(driver, false);
	}
}
//