package Manage.Utilities.ReportScheduler;

import java.io.File;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_2_1_07 {
	public static void ReportScheduler_AddNewDistributionGroupsAndMatchingTheData(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		RC_Manage.deleteFile_Downloads(driver, "Export");
		RC_Manage.deleteFile_Downloads(driver, "Export (1)");
		RC_Manage.deleteAllFolder_Files(driver);
		RC_Global.login(driver);
		RC_Global.enterCustomerFocus(driver, "LS008737", true);
		RC_Global.navigateTo(driver, "Manage", "Utilities", "Report Scheduler");
		RC_Global.waitUntilPanelVisibility(driver, "Report Scheduler", "TV", true, true);
		
		RC_Global.clickUsingXpath(driver, "//li[a[text()='Distribution Groups']]", "Distribution Groups", true, true);

		Thread.sleep(2000);
		RC_Global.waitElementVisible(driver, 60, "(//table/tbody/tr)[1]", "Grid record load", true, false);
		Thread.sleep(1000);
		
		RC_Global.clickButton(driver, "Add New Group", true, true);
		
		RC_Global.panelAction(driver, "expand", "Create Distribution Group", true, false);
	
		WebElement groupNameEle = driver.findElement(By.xpath("//div[label[text()='Group Name:']]/div/input"));
		WebElement descriptionEle = driver.findElement(By.xpath("//div[label[text()='Description:']]/div/textarea"));
		
		String randomName = "Sample Test "+RandomStringUtils.randomNumeric(2);
		RC_Global.enterInput(driver, randomName, groupNameEle, true, true);
		RC_Global.enterInput(driver, randomName, descriptionEle, true, true);
		
		RC_Global.clickUsingXpath(driver, "//select[@name='groupTypes']/option[text()='User Defined']", "Select User Defined", true, true);
		
		RC_Global.clickUsingXpath(driver, "(//table/tbody/tr[td[a[span[contains(text(),'@merchantsfleet.com')]]]]/td[1])[1]", "Select Recipients", true, false);
		RC_Global.clickUsingXpath(driver, "(//table/tbody/tr[td[a[span[contains(text(),'@merchantsfleet.com')]]]]/td[1])[2]", "Select Recipients", true, true);
		
		WebElement nameEle = driver.findElement(By.xpath("//input[@placeholder='Name']"));
		WebElement emailEle = driver.findElement(By.xpath("//input[@placeholder='Email']"));
		
		RC_Global.enterInput(driver, "Sample Test Name "+RandomStringUtils.randomNumeric(2), nameEle, true, false);
		RC_Global.enterInput(driver, "navirasainath@merchantsfleet.com", emailEle, true, false);
		
		RC_Global.clickButton(driver, "Add Recipient", true, true);
		RC_Global.clickButton(driver, "Save", true, true);
		
		try {
			RC_Global.waitElementVisible(driver, 30, "(//h4[text()='Distribution Group Successfully Saved'])[1]", "Successful Save Message", true, true);
			queryObjects.logStatus(driver, Status.PASS, "Verify Success Message", "The expected message appeared", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify Success Message", "The expected message did not appear", null);
		}
		
		Thread.sleep(2000);
		RC_Global.clickUsingXpath(driver, "//tr[td[text()='"+randomName+"']]/td[2]/a", "# of Recipients", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Edit Distribution Group", "TV", true, true);
		
		RC_Global.panelAction(driver, "expand", "Edit Distribution Group", true, false);
	
		RC_Global.clickUsingXpath(driver, "//select[@name='groupTypes']/option[text()='Drivers']", "Select User Defined", true, true);
		
		RC_Global.clickButton(driver, "Save", true, true);
		
		try {
			RC_Global.waitElementVisible(driver, 30, "(//h4[text()='Distribution Group Successfully Saved'])[1]", "Successful Save Message", true, true);
			queryObjects.logStatus(driver, Status.PASS, "Verify Success Message", "The expected message appeared", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify Success Message", "The expected message did not appear", null);
		}
		
		RC_Global.panelAction(driver, "expand", "Report Scheduler", true, true);
		
		RC_Global.clickUsingXpath(driver, "//tr[td[text()='"+randomName+"']]/td[8]//span[text()='Delete']", "Deleted created report", true, true);
		
		Thread.sleep(3000);
//		RC_Global.clickButton(driver, "Add New Group", true, true);
		RC_Global.clickUsingXpath(driver, "//tr[td[text()='Fleet Managers']]/td[2]/a", "Fleet Managers", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Edit Distribution Group", "TV", true, false);
		
		
//		RC_Global.panelAction(driver, "close", "Report Scheduler", true, false);
		RC_Global.panelAction(driver, "expand", "Edit Distribution Group", true, false);
	
		boolean flag = false;
        String home = System.getProperty("user.home");
        File listofFiles= new File(home+"/Downloads/");
        if(driver.findElements(By.xpath("(//button[@ng-click='exportToExcel()'])[3]")).size()>0)
            driver.findElement(By.xpath("(//button[@ng-click='exportToExcel()'])[3]")).click();
        Thread.sleep(5000);
        //Check for the files available
        for (File file :listofFiles.listFiles() ) {
            String filename= file.getName();
            if(filename.contains("Export.xlsx")) {
                flag = true;
//                file.delete();
                break;
            }
        }
        if(!flag)
        	queryObjects.logStatus(driver, Status.FAIL, "Excel Export from Report Scheduler", "Failed", null);
            

//		RC_Global.downloadAndVerifyFileDownloaded(driver, "Export", "Excel Export from Report Scheduler", true);
		Thread.sleep(2000);
		
		RC_Global.panelAction(driver, "close", "Edit Distribution Group", true, true);
		Thread.sleep(3000);

		RC_Global.clickUsingXpath(driver, "//tr[td[text()='Drivers']]/td[2]/a", "Drivers", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Edit Distribution Group", "TV", true, false);
		
		
//		RC_Global.panelAction(driver, "close", "Report Scheduler", true, false);
		RC_Global.panelAction(driver, "expand", "Edit Distribution Group", true, false);
	
		flag = false;
        home = System.getProperty("user.home");
        listofFiles= new File(home+"/Downloads/");
        if(driver.findElements(By.xpath("(//button[@ng-click='exportToExcel()'])[3]")).size()>0)
            driver.findElement(By.xpath("(//button[@ng-click='exportToExcel()'])[3]")).click();
        Thread.sleep(5000);
        //Check for the files available
        for (File file :listofFiles.listFiles() ) {
            String filename= file.getName();
            if(filename.contains("Export (1).xlsx")) {
                flag = true;
//                file.delete();
                break;
            }
        }
        if(!flag)
        	queryObjects.logStatus(driver, Status.FAIL, "Excel Export from Report Scheduler", "Failed", null);
            

//		RC_Global.downloadAndVerifyFileDownloaded(driver, "Export", "Excel Export from Report Scheduler", true);
		Thread.sleep(2000);
		
		RC_Global.panelAction(driver, "close", "Edit Distribution Group", true, true);
		RC_Global.panelAction(driver, "close", "Report Scheduler", true, false);
		Thread.sleep(1000);

		
		RC_Global.navigateTo(driver, "Manage", "Utilities", "User Setup");
		RC_Global.waitUntilPanelVisibility(driver, "User Setup", "TV", true, false);
		
		RC_Global.waitElementVisible(driver, 60, "(//table/tbody/tr)[1]", "Grid", true, false);
		WebElement searchBox = driver.findElement(By.xpath("//div[span]/input"));
		RC_Global.enterInput(driver, "LS008737", searchBox, true, true);
		Thread.sleep(3000);
		
		RC_Global.panelAction(driver, "expand", "User Setup", true, false);
		
		home = System.getProperty("user.home");
		listofFiles= new File(home+"/Downloads/");
        if(driver.findElements(By.xpath("(//button[@ng-click='exportToExcel()'])[1]")).size()>0)
            driver.findElement(By.xpath("(//button[@ng-click='exportToExcel()'])[1]")).click();
        Thread.sleep(5000);
        //Check for the files available
        for (File file :listofFiles.listFiles() ) {
            String filename= file.getName();
            if(filename.contains("Export (2).xlsx")) {
                flag = true;
//                file.delete();
                break;
            }
        }
        if(!flag)
        	queryObjects.logStatus(driver, Status.FAIL, "Excel Export from User Setup", "Failed", null);
            
//		RC_Global.downloadAndVerifyFileDownloaded(driver, "Export(1)", "Excel Export from User Setup", true);
		Thread.sleep(2000);
		String[] sptVal = new String[3]; String curDir = ""; String newFileName = ""; String curFilePath = "";
		
		String downloadPath1 = RC_Manage.moveFileFromDownloads(driver, "Export.xlsx", "DownloadedFiles", true);
		if (downloadPath1.contains(";")) {
        	sptVal = downloadPath1.split(";");
        	curDir= sptVal[0];
        	newFileName = sptVal[1];
        	curFilePath = curDir+"\\"+newFileName;	
		}
		
		String returnValues = RC_Manage.getDriverFleetManager_ReportScheduler(driver, queryObjects, curFilePath);
		System.out.println(returnValues);
		String fmCountRS = returnValues;

		downloadPath1 = RC_Manage.moveFileFromDownloads(driver, "Export (1).xlsx", "DownloadedFiles", true);
		if (downloadPath1.contains(";")) {
        	sptVal = downloadPath1.split(";");
        	curDir= sptVal[0];
        	newFileName = sptVal[1];
        	curFilePath = curDir+"\\"+newFileName;	
		}
		
		returnValues = RC_Manage.getDriverFleetManager_ReportScheduler(driver, queryObjects, curFilePath);
		System.out.println(returnValues);
		String driverCountRS = returnValues;

		
		String downloadPath2 = RC_Manage.moveFileFromDownloads(driver, "Export (2).xlsx", "DownloadedFiles", true);
		if (downloadPath2.contains(";")) {
        	sptVal = downloadPath2.split(";");
        	curDir= sptVal[0];
        	newFileName = sptVal[1];
        	curFilePath = curDir+"\\"+newFileName;	
		}
		
		returnValues = RC_Manage.getDriverFleetManager_UserSetup(driver, queryObjects, curFilePath);
		System.out.println(returnValues);
		String fmCountUS = returnValues.split(";")[0];

		String driverCountUS = returnValues.split(";")[1];
		
		if(fmCountRS.equals(fmCountUS))
			queryObjects.logStatus(driver, Status.PASS, "Verify fleet manager count in Report Scheduler matches with that of User Setup", "The count of Fleet Managers in Report Scheduler matches with that of User Setup", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify fleet manager count in Report Scheduler matches with that of User Setup", "The count of Fleet Managers in Report Scheduler does not match with that of User Setup\nFleet Managers in Report Scheduler is "+fmCountRS+" and in User Setup is "+fmCountUS, null);
		if(driverCountRS.equals(driverCountUS))
			queryObjects.logStatus(driver, Status.PASS, "Verify driver count in Report Scheduler matches with that of User Setup", "The count of Fleet Managers in Report Scheduler matches with that of User Setup", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify driver count in Report Scheduler matches with that of User Setup", "The count of Fleet Managers in Report Scheduler does not match with that of User Setup\nFleet Managers in Report Scheduler is "+driverCountRS+" and in User Setup is "+driverCountUS, null);
		
		
		RC_Global.logout(driver, false);
	}
}
