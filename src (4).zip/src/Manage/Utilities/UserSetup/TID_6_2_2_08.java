package Manage.Utilities.UserSetup;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_2_2_08 {
	public void UserSetup_SetupUserAssociatedWithEmployee(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		String userName = "TestSelenium";
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Utilities", "User Setup");
		RC_Global.clickButton(driver, "Add New User", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "User Detail", "TV", true, true);
		RC_Global.panelAction(driver, "close", "User Setup", true, false);
		RC_Global.panelAction(driver, "expand", "User Detail", true, false);
		
		RC_Global.createNode(driver, "Entering Mandatory fields in User Information and Security Section");
		RC_Global.clickUsingXpath(driver, "(//label[@ng-model='user.IsEnabled' and @uib-btn-radio='true'])", "", true, false);
		RC_Global.clickUsingXpath(driver, "//label[@ng-model='user.IsAccountLocked' and @uib-btn-radio='false']", "", true, false);
		RC_Global.selectDropdownOption(driver, "departments", "External Customer", true, false);
		RC_Global.selectDropdownOption(driver, "roles", "Driver", true, false);
		driver.findElement(By.xpath("//input[@name='username']")).sendKeys("Test"+RandomStringUtils.randomAlphabetic(4));
        driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys("Sel"+RandomStringUtils.randomAlphabetic(4));
        driver.findElement(By.xpath("//input[@name='lastName']")).sendKeys("ABC"+RandomStringUtils.randomAlphabetic(4));
        driver.findElement(By.xpath("//input[@name='email']")).sendKeys(RandomStringUtils.randomAlphabetic(4)+"@gmail.com");
        
		RC_Global.enterCustomerNumber(driver, "LS007656", "", "", true);
		RC_Global.clickUsingXpath(driver, "(//input[@type='checkbox'])[1]", "Click on Customer Role checkbox", true, true);
		RC_Global.selectDropdownOption(driver, "enrolledInPersonalUseIndicator", "Yes", true, false);
		RC_Global.clickButton(driver, "Search", true, false);
		RC_Global.waitElementVisible(driver, 90, "(//table/tbody/tr)[1]", "All customers Grid record load", true, false);
		RC_Global.clickUsingXpath(driver, "(//tbody//tr)[1]", "Select the row to assign employee to Vehicle Driver Assignment", true, true);
		
		RC_Global.clickButton(driver, "Save", true, true);
		try {
			driver.switchTo().alert().accept();
		} catch (Exception e) {}
		
		RC_Manage.waitUntilMethods(driver, "//div[@class='spinner ng-scope']/../span[text()='Saving User']","","", "invisible");
		RC_Global.verifyDisplayedMessage(driver, "Save Successful", true);
		RC_Global.panelAction(driver, "close", "User Detail", true, false);
		RC_Global.logout(driver, true);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
