package Manage.Utilities.UserSetup;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_2_2_06 {
	public void UserSetup_OverrideTheUserAccess(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		String userName = "TestSelenium";
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Utilities", "User Setup");
		WebElement UserNamIn = driver.findElement(By.xpath("//input[@placeholder='Find User by Username']"));
		RC_Global.enterInput(driver, userName, UserNamIn, true, true);
		RC_Global.waitElementVisible(driver, 50,"//tbody//tr[1]", "User logins with "+userName+" in name are displayed in the grid", true, true);
		RC_Global.clickUsingXpath(driver,"//td[text()='"+userName+"']", "External Username created", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "User Detail", "TV", true, true);
		RC_Global.panelAction(driver, "close", "User Setup", true, false);
		RC_Global.panelAction(driver, "expand", "User Detail", true, false);
		RC_Global.clickButton(driver, "Advanced", true, true);
		RC_Global.clickUsingXpath(driver, "//span[text()=' Manage Menu ']", "Manage Menu Hyperlink", true, true);
		RC_Global.clickUsingXpath(driver, "//span[text()=' Utilities ']", "Utilities Submodule Hyperlink", true, true);
		RC_Global.clickUsingXpath(driver, "(//span[text()=' User Management ']/following::select[@name='featureAccess'])[1]", "Select Access permission from dropdown", true, true);
		RC_Global.clickUsingXpath(driver, "(//span[text()=' User Management ']/following::select[@name='featureAccess'])[1]//option[text()='Read / Write']", "", true, true);
		RC_Global.clickButton(driver, "Save", true,true);
		RC_Manage.waitUntilMethods(driver, "//div[@class='spinner ng-scope']/../span[text()='Saving User']","","", "invisible");
		RC_Global.verifyDisplayedMessage(driver, "Save Successful", true);
		RC_Global.logout(driver, true);
		
		RC_Global.externalUserLogin(driver, userName, "yes");
		RC_Global.navigateTo(driver, "Manage", "Utilities", "User Setup");
		RC_Global.waitElementVisible(driver, 60,"(//tbody//tr)[1]", "", true, true);
		if(driver.findElements(By.xpath("(//tbody//tr)[1]")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "External User", "External User logged in successfully", null);
		else {
			queryObjects.logStatus(driver, Status.FAIL, "External User","External User login failed", null);
			RC_Global.endTestRun(driver);}
		RC_Global.logout(driver, true);
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Utilities", "User Setup");
		UserNamIn = driver.findElement(By.xpath("//input[@placeholder='Find User by Username']"));
		RC_Global.enterInput(driver, userName, UserNamIn, true, true);
		RC_Global.waitElementVisible(driver, 60,"(//tbody//tr)[1]", "User logins with '"+userName+"' in name are displayed in the grid", true, true);
		RC_Global.clickUsingXpath(driver,"//td[text()='"+userName+"']", "External Username created", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "User Detail", "TV", true, true);
		RC_Global.panelAction(driver, "close", "User Setup", true, false);
		RC_Global.panelAction(driver, "expand", "User Detail", true, false);
		RC_Global.clickButton(driver, "Advanced", true, true);
		RC_Global.clickUsingXpath(driver, "//span[text()=' Manage Menu ']", "Manage Menu Hyperlink", true, true);
		RC_Global.clickUsingXpath(driver, "//span[text()=' Utilities ']", "Utilities Submodule Hyperlink", true, true);
		RC_Global.clickUsingXpath(driver, "(//span[text()=' User Management ']/following::select[@name='featureAccess'])[1]", "Select Access permission from dropdown", true, true);
		RC_Global.clickUsingXpath(driver, "(//span[text()=' User Management ']/following::select[@name='featureAccess'])[1]//option[text()='No Access']", "", true, true);
		RC_Global.clickButton(driver, "Save", true,true);
		RC_Manage.waitUntilMethods(driver, "//div[@class='spinner ng-scope']/../span[text()='Saving User']","","", "invisible");
		RC_Global.verifyDisplayedMessage(driver, "Save Successful", true);
		RC_Global.logout(driver, true);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
