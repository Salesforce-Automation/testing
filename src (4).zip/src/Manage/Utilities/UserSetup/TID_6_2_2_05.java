package Manage.Utilities.UserSetup;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_2_2_05 {
	public void UserSetup_AddNewExternalDriverUser(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Utilities", "User Setup");
		RC_Global.clickButton(driver, "Add New User", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "User Detail", "TV", true, true);
		RC_Global.panelAction(driver, "close", "User Setup", true, false);
		RC_Global.panelAction(driver, "expand", "User Detail", true, false);
		
		List<WebElement> InternalUserNo = driver.findElements(By.xpath("(//label[@ng-model='user.IsActiveDirectoryUser' and @uib-btn-radio='false'])[2]"));
		if(InternalUserNo.size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Internal User Toggle", "Internal User Field toggle selection auto-select as 'No'", null);
		else {
			queryObjects.logStatus(driver, Status.FAIL, "Internal User Toggle", "Internal User Field  toggle selection failed to auto-select as 'No'", null);
			RC_Global.endTestRun(driver);}
		RC_Global.createNode(driver, "User information displayed based on 'Internal User' Field toggle made as No");
		RC_Global.verifyScreenComponents(driver, "label", "Username ", true);
		RC_Global.verifyScreenComponents(driver, "label", "First Name ", true);
		RC_Global.verifyScreenComponents(driver, "label", "Last Name ", true);
		RC_Global.verifyScreenComponents(driver, "label", "Email  ", true);
		RC_Global.verifyScreenComponents(driver, "label", "Department ", true);
		RC_Global.verifyScreenComponents(driver, "label", "Role ", true);
		
		RC_Global.createNode(driver, "Entering Mandatory fields in User Information and Security Section");
		RC_Global.clickUsingXpath(driver, "(//label[@ng-model='user.IsEnabled' and @uib-btn-radio='true'])", "", true, false);
		RC_Global.clickUsingXpath(driver, "//label[@ng-model='user.IsAccountLocked' and @uib-btn-radio='false']", "", true, false);
		RC_Global.selectDropdownOption(driver, "departments", "External Customer", true, false);
		RC_Global.selectDropdownOption(driver, "roles", "Driver", true, false);
		driver.findElement(By.xpath("//input[@name='username']")).sendKeys("Test"+RandomStringUtils.randomAlphabetic(4));
        driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys("Sel"+RandomStringUtils.randomAlphabetic(4));
        driver.findElement(By.xpath("//input[@name='lastName']")).sendKeys("ABC"+RandomStringUtils.randomAlphabetic(4));
        driver.findElement(By.xpath("//input[@name='email']")).sendKeys(RandomStringUtils.randomAlphabetic(4)+"@gmail.com");
        
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		Thread.sleep(2000);
		RC_Global.clickUsingXpath(driver, "(//input[@type='checkbox'])[1]", "Click on Customer Role checkbox", true, true);
		Thread.sleep(5000);
		RC_Global.clickUsingXpath(driver, "(//tbody//tr)[1]", "Select the row for which employee need to assign", true, true);
		
		RC_Global.clickButton(driver, "Save", true, true);
		try {
			driver.switchTo().alert().accept();
		} catch (Exception e) {}
		
		RC_Manage.waitUntilMethods(driver, "//div[@class='spinner ng-scope']/../span[text()='Saving User']","","", "invisible");
		RC_Global.verifyDisplayedMessage(driver, "Save Successful", true);
		RC_Global.panelAction(driver, "close", "User Detail", true, false);
		RC_Global.logout(driver, true);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
