package Manage.Utilities.UserSetup;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_2_2_02 {
	public void UserSetup_TestAccounLocking(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		
		String userName = "TestSelenium";
		String ErrorMessage = "User account is locked. Please contact your administrator.";
				
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Utilities", "User Setup");
		RC_Manage.waitUntilMethods(driver, "//div[contains(@ng-show,'tableDataLoading') and contains(@class,'spinner')]","class","ng-hide", "attribute visible");
		WebElement UserNamIn = driver.findElement(By.xpath("//input[@placeholder='Find User by Username']"));
		RC_Global.enterInput(driver, userName, UserNamIn, true, true);
		driver.findElement(By.xpath("//input[@placeholder='Find User by Username']")).clear();
		RC_Global.enterInput(driver, userName, UserNamIn, true, true);		
		RC_Global.waitElementVisible(driver, 30,"//tbody//tr[1]", "User logins with '"+userName+"' in name are displayed in the grid", true, true);
		RC_Global.clickUsingXpath(driver,"//td[text()='"+userName+"']", "External Username created", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "User Detail", "TV", true, true);
		RC_Global.panelAction(driver, "close", "User Setup", true, false);
		RC_Global.panelAction(driver, "expand", "User Detail", true, false);
		if (!driver.findElement(By.xpath("//label[@ng-model='user.IsAccountLocked' and contains(text(),'Yes')]")).getAttribute("class").contains("ng-valid active")) {
			RC_Global.clickUsingXpath(driver,"//label[@ng-model='user.IsAccountLocked' and contains(text(),'Yes')]", "Account Locked -Yes", true, true);
		}
		RC_Global.clickButton(driver, "Save", true, true);
		RC_Manage.waitUntilMethods(driver, "//div[@class='spinner ng-scope']/../span[text()='Saving User']","","", "invisible");		
		RC_Global.verifyDisplayedMessage(driver, "Save Successful", true);
		RC_Global.logout(driver, true);
		
		RC_Global.externalUserLogin(driver, userName, "yes");
		String LoginErrorMessage = driver.findElement(By.xpath("//h4[text()='User account is locked.  Please contact your administrator.']")).getText();
		if(LoginErrorMessage.equalsIgnoreCase(ErrorMessage))
			queryObjects.logStatus(driver, Status.PASS, "Message to be verified", ErrorMessage+" Verified Successfully", null);
		else {
			queryObjects.logStatus(driver, Status.FAIL, "Message to be verified", ErrorMessage+" Varification Failed", null);
			RC_Global.endTestRun(driver);}

		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Utilities", "User Setup");
		RC_Global.waitElementVisible(driver, 30,"(//tbody//tr)[1]", "User logins with 'test' in name are displayed in the grid", true, true);
		Thread.sleep(3000);
		UserNamIn = driver.findElement(By.xpath("//input[@placeholder='Find User by Username']"));
		RC_Global.enterInput(driver, userName, UserNamIn, true, true);
		RC_Global.waitElementVisible(driver, 30,"(//tbody//tr)[1]", "User logins with '"+userName+"' in name are displayed in the grid", true, true);
		RC_Global.clickUsingXpath(driver,"//td[text()='"+userName+"']", "External Username created", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "User Detail", "TV", true, true);
		RC_Global.panelAction(driver, "close", "User Setup", true, false);
		RC_Global.panelAction(driver, "expand", "User Detail", true, false);
		RC_Global.clickUsingXpath(driver,"//label[@ng-model='user.IsAccountLocked' and @uib-btn-radio='false']", "Account Locked - No", true, true);
		RC_Global.clickButton(driver, "Save", true, true);
		RC_Manage.waitUntilMethods(driver, "//div[@class='spinner ng-scope']/../span[text()='Saving User']","","", "invisible");
		RC_Global.verifyDisplayedMessage(driver, "Save Successful", true);
		RC_Global.logout(driver, true);
		
		RC_Global.externalUserLogin(driver, userName, "yes");
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
