package Manage.Utilities.UserSetup;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_2_2_04 {
	public void UserSetup_ValidateInternalUserDepartments(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		String DepartmentDrpValue = "Accounting;Accounts Receivable;Acquisition;Administration;Credit;Customer Service;Human Resources;IT;L&T;Maintenance;Owners;Payoff;Products and Services;Remarketing;Sales;SCS;Short Term;Treasury";
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Utilities", "User Setup");
		RC_Global.clickButton(driver, "Add New User", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "User Detail", "TV", true, true);
		RC_Global.panelAction(driver, "close", "User Setup", true, false);
		RC_Global.panelAction(driver, "expand", "User Detail", true, false);
		RC_Global.clickUsingXpath(driver, "(//label[@ng-model='user.IsActiveDirectoryUser' and @uib-btn-radio='true'])[1]", "Merchants SSO user as 'Yes'", true, true);
		List<WebElement> InternalUserYes = driver.findElements(By.xpath("(//label[@ng-model='user.IsActiveDirectoryUser' and @uib-btn-radio='true'])[2]"));
		if(InternalUserYes.size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Internal User Toggle", "Internal User Field toggle selection auto-select as 'Yes'", null);
		else {
			queryObjects.logStatus(driver, Status.FAIL, "Internal User Toggle", "Internal User Field  toggle selection failed to auto-select as 'Yes'", null);
			RC_Global.endTestRun(driver);}
		
		RC_Global.createNode(driver, "User information displayed based on 'Merchants SSO' toggle made as Yes");
		RC_Global.verifyScreenComponents(driver, "label", "Internal User", true);
		RC_Global.verifyScreenComponents(driver, "label", "Username ", true);
		RC_Global.verifyScreenComponents(driver, "label", "Active User", true);
		RC_Global.verifyScreenComponents(driver, "label", "Account Locked", true);
		
		RC_Global.clickUsingXpath(driver, "(//label[@ng-model='user.IsActiveDirectoryUser' and @uib-btn-radio='false'])[1]", "Merchants SSO user as 'No'", true, true);
		List<WebElement> InternalUserNo = driver.findElements(By.xpath("(//label[@ng-model='user.IsActiveDirectoryUser' and @uib-btn-radio='false'])[2]"));
		if(InternalUserNo.size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Internal User Toggle", "Internal User Field toggle selection auto-select as 'No'", null);
		else {
			queryObjects.logStatus(driver, Status.FAIL, "Internal User Toggle", "Internal User Field  toggle selection failed to auto-select as 'No'", null);
			RC_Global.endTestRun(driver);}
		RC_Global.createNode(driver, "User information displayed based on 'Merchants SSO' toggle made as No");
		RC_Global.verifyScreenComponents(driver, "label", "Internal User", true);
		RC_Global.verifyScreenComponents(driver, "label", "Username ", true);
		RC_Global.verifyScreenComponents(driver, "label", "First Name ", true);
		RC_Global.verifyScreenComponents(driver, "label", "Last Name ", true);
		RC_Global.verifyScreenComponents(driver, "label", "Email  ", true);
		RC_Global.verifyScreenComponents(driver, "label", "Active User", true);
		RC_Global.verifyScreenComponents(driver, "label", "Account Locked", true);
		
		RC_Global.clickUsingXpath(driver, "(//label[@ng-model='user.IsActiveDirectoryUser' and @uib-btn-radio='true'])[1]", "Merchants SSO user as 'Yes'", true, true);
		RC_Global.dropdownValuesValidation(driver, DepartmentDrpValue, "//select[@name='departments']", true, true);
		RC_Global.panelAction(driver, "close", "User Detail", true, false);
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
