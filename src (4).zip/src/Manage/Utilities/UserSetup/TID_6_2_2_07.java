package Manage.Utilities.UserSetup;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import MF.Source.Cred;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_2_2_07 {
	public void UserSetup_OverrideTheUserAccess(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		String userName = Cred.UserName;
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Utilities", "User Setup");
		RC_Manage.waitUntilMethods(driver, "//div[contains(@ng-show,'tableDataLoading') and contains(@class,'spinner')]","class","ng-hide", "attribute visible");
		WebElement UserNamIn = driver.findElement(By.xpath("//input[@placeholder='Find User by Username']"));
		RC_Global.enterInput(driver, userName, UserNamIn, true, true);
		driver.findElement(By.xpath("//input[@placeholder='Find User by Username']")).clear();
		RC_Global.enterInput(driver, userName, UserNamIn, true, true);
		RC_Global.waitElementVisible(driver, 60,"(//tbody//tr)[1]", "User logins with "+userName+" in name are displayed in the grid", true, true);
		RC_Global.clickUsingXpath(driver,"//td[text()='"+userName+"']", "External Username created", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "User Detail", "TV", true, true);
		RC_Global.panelAction(driver, "close", "User Setup", true, false);
		RC_Global.panelAction(driver, "expand", "User Detail", true, false);
	
		String userNam = driver.findElement(By.xpath("//input[@id='usernameInput']")).getAttribute("value");
		String DateCreated = driver.findElement(By.xpath("(//label[text()='Date Created']/following::span)[1]")).getText();
		String DateLastUpdated = driver.findElement(By.xpath("(//label[text()='Date Last Updated']/following::span)[1]")).getText();
		String LastLoginDate = driver.findElement(By.xpath("(//label[text()='Last Login Date']/following::span)[1]")).getText();
		String Departments = driver.findElement(By.xpath("//select[@id='departments']//option[@selected='selected']")).getText();
		String Roles = driver.findElement(By.xpath("//select[@id='roles']//option[@selected='selected']")).getText();

		if(!(userNam.isEmpty() && DateCreated.isEmpty() && DateLastUpdated.isEmpty() && LastLoginDate.isEmpty()))
			queryObjects.logStatus(driver, Status.PASS, "Username Information fields", "Username Information fields have the data ", null);
		else {
			queryObjects.logStatus(driver, Status.FAIL, "Username Information fields","Username Information fields dont have the data ", null);
			RC_Global.endTestRun(driver);}
		
		if(!(Departments.isEmpty() && Roles.isEmpty()))
			queryObjects.logStatus(driver, Status.PASS, "Security fields","Security fields have the data ", null);
		else {
			queryObjects.logStatus(driver, Status.FAIL, "Security fields","Security fields dont have the data ", null);
			RC_Global.endTestRun(driver);}
		RC_Global.buttonStatusValidation(driver, "Advanced", "Enable", true);
		RC_Global.buttonStatusValidation(driver, "History", "Enable", true);
		RC_Global.panelAction(driver, "close", "User Detail", true, false);
		RC_Global.logout(driver, true);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
