package Manage.MassUpload;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_5_0_01 {
	public static void MassUploadPortal_UIValidations(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		
		int count = 0;
		for (int i = 1; i<=2;i++){
		if(i==1){
			RC_Global.login(driver);
			count =0;
		}
		else{
			RC_Global.externalUserLogin(driver, "Kentuckytest", "Yes");
		count =0;			
		}
		
		if(count==0){
		
		RC_Global.navigateTo(driver, "Manage", "Mass Upload Portal", "");
		RC_Global.waitUntilPanelVisibility(driver, "Mass Upload Portal", "TV", true,true);
		Thread.sleep(3000);
		RC_Global.validateSpecifiedSearchFilters(driver, "Customer Number;I want to", false);
		RC_Global.dropdownValuesValidation(driver, "Download Template;Upload Template", "//select[contains(@ng-model,'wantToOption')]", false, true);
		RC_Global.selectDropdownOption(driver, "I want to", "Download Template", false,false);
		if (driver.findElement(By.xpath("(//div[@role='presentation']/div[2]//div[contains(@ng-class,'focused')]//following::div[1]//div)[1]")).isDisplayed()) {
			queryObjects.logStatus(driver, Status.PASS, "The grid record appears for", "Download Template", null);
		} else {
			queryObjects.logStatus(driver, Status.FAIL, "The grid record are not displayed for", "Download Template", null);
		}
		RC_Global.selectDropdownOption(driver, "I want to", "Upload Template", false,false);
		if (driver.findElement(By.xpath("(//div[@role='presentation']/div[2]//div[contains(@ng-class,'focused')]//following::div[1]//div)[1]")).isDisplayed()) {
			queryObjects.logStatus(driver, Status.PASS, "The grid record appears for", "Upload Template", null);
		} else {
			queryObjects.logStatus(driver, Status.FAIL, "The grid record are not displayed for", "Upload Template", null);
		}
		
		RC_Global.selectDropdownOption(driver, "I want to", "Download Template", false,false);
		RC_Global.validateSpecifiedSearchFilters(driver, "Select Template", false);
		RC_Global.dropdownValuesValidation(driver, "Batch Order Upload;Client Data and CVN Upload;Driver/Pool Assignment Upload;Employee Upload;Fuel Card Order Upload;Pool Management Upload;Vehicle Movement Upload", "//select[contains(@ng-model,'templateId')]", false, true);
		RC_Global.buttonStatusValidation(driver, "Download Template", "Disable", false);
		
		RC_Global.selectDropdownOption(driver, "I want to", "Upload Template", false,false);
		RC_Global.validateSpecifiedSearchFilters(driver, "Select Template", false);
		RC_Global.dropdownValuesValidation(driver, "Batch Order Upload;Client Data and CVN Upload;Driver/Pool Assignment Upload;Employee Upload;Fuel Card Order Upload;Pool Management Upload;Vehicle Movement Upload", "//select[@ng-model='vm.templateType']", false, true);
		 List<WebElement> ButtonD = driver.findElements(By.xpath("//label[(text()='Select File') and (@disabled = 'disabled')]"));
		    if(ButtonD.size()>0) {
					queryObjects.logStatus(driver,Status.INFO,"Select File Button is", "Disabled", null);
					}
		    String xpath = "(//label[text()='Select Template']/following-sibling::select)[2]";
			driver.findElement(By.xpath(xpath)).click();
			RC_Global.waitElementVisible(driver, 10, xpath+"/option", "Client Data and CVN Upload"+" Options", true,true); //Wait Options are available in DropDown to select
			driver.findElement(By.xpath(xpath+"/option[text()='Client Data and CVN Upload']")).click();
			Thread.sleep(2000);	
			RC_Global.buttonStatusValidation(driver, "Select File", "Enable", true);
		RC_Global.clickButton(driver, "Select File", true,false);
		    Thread.sleep(2000);
		    Robot robot = null;
		     robot = new Robot();
			   robot.delay(1000);
		       robot.keyPress(KeyEvent.VK_ESCAPE);
		       robot.keyRelease(KeyEvent.VK_ESCAPE);
		       queryObjects.logStatus(driver,Status.INFO,"Select File Button navigate to the template stored location and", "select a template to upload", null);
		RC_Global.dropdownValuesValidation(driver, "Upload Now;Scheduled", "//select[contains(@ng-model,'uploadTimeOption')]", false, true);
		RC_Global.buttonStatusValidation(driver, "Upload Template", "Disable", false);
		RC_Global.selectDropdownOption(driver, "Upload Time", "Scheduled", false,false);
		RC_Global.validateSpecifiedSearchFilters(driver, "Select Date & Time;Timezone", false);
		
		 DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm");
		 Date date = new Date();
		 // Now format the date
		 String date1= dateFormat.format(date);
		 System.out.println(date1);
		 
		 RC_Global.dropdownValuesValidation(driver, "Eastern Standard Time (EST);Central Standard Time (CST);Mountain Standard Time (MST);Pacific Standard Time (PST);Alaska Standard Time (AKST);Hawaii-Aleutian Standard Time (HAST)", "//select[@ng-model='vm.scheduledTimeZone']", false, true);
		 RC_Global.createNode(driver, "Verify Mass Upload Column Names");
		 List<String> expectedColumn=new ArrayList<String>(Arrays.asList("Customer Number","Customer Name","Template Name","Status","Status","Completed/Failed","Time Submitted","Time Completed","User Uploaded","Actions"));  
		 
		 String custNumber = driver.findElement(By.xpath("(//cell-template/div[1]/div/span)[1]")).getText().trim();
		 String custName = driver.findElement(By.xpath("(//cell-template/div[1]/div/span)[2]")).getText().trim();
		 String temNa = driver.findElement(By.xpath("(//cell-template/div[1]/div/span)[3]")).getText().trim();
		 String prstatus = driver.findElement(By.xpath("(//cell-template/div)[4]")).getText().trim();
		 String statusdrop = driver.findElement(By.xpath("//cell-tem3plate/div/div[1]/span")).getText().trim();
		 String compfailed = driver.findElement(By.xpath("(//cell-template/div)[5]")).getText().trim();
		 String timeSubm = driver.findElement(By.xpath("(//cell-template/div)[6]")).getText().trim();
		 JavascriptExecutor executor1 = (JavascriptExecutor)driver;
		 Thread.sleep(2000);
			executor1.executeScript("document.body.style.zoom = '70%'");
			Thread.sleep(2000);
		 String timeCompl = driver.findElement(By.xpath("(//cell-template/div)[7]")).getText();
		 String userUpl = driver.findElement(By.xpath("(//cell-template/div[1]/div/span)[4]")).getText().trim();
		 String Actions = driver.findElement(By.xpath("(//cell-template/div)[9]")).getText().trim();
		 
		 List<String> actualColumn=new ArrayList<String>(Arrays.asList(custNumber,custName,temNa,prstatus,statusdrop,compfailed,timeSubm,timeCompl,userUpl,Actions));
		 if(expectedColumn.equals(actualColumn)) {
			  queryObjects.logStatus(driver, Status.PASS, "Mass Upload Column Names Validation", "Column Names are verified", null);
		 }
		 else {
			 queryObjects.logStatus(driver, Status.FAIL, "Mass Upload Column Names Validation", "Column Names Validation Failed", null);
		 }
		 Thread.sleep(2000);
			executor1.executeScript("document.body.style.zoom = '100%'");
			
		 RC_Global.buttonStatusValidation(driver, "Download Results", "Enable", true);
		 
		 String uploadof =driver.findElement(By.xpath("(//div[@role='presentation']/div[2]//div[contains(@ng-class,'focused')]//following::div[2]//div)[21]")).getText();
		 
		 if(uploadof.contains("of"))  {
             queryObjects.logStatus(driver, Status.PASS, "The  value displayed with","X of X format is "+uploadof+"", null);
             }
             else if(uploadof.length()==0)
             {
                    queryObjects.logStatus(driver, Status.FAIL, "The X of X format is", "Not displayed", null);
             }
		 String Data =driver.findElement(By.xpath("(//div[@role='presentation']/div[2]//div[contains(@ng-class,'focused')]//following::div[2]//div)[20]")).getText();
		 if(Data.endsWith("%"))  {
             queryObjects.logStatus(driver, Status.PASS, "The value displayed with completed","Percentage is "+Data+"", null);
             }
             else if(Data.length()==0)
             {
                    queryObjects.logStatus(driver, Status.FAIL, "The completed percentage value is", "Not displayed", null);
             }
             
     
		
		 JavascriptExecutor executor = (JavascriptExecutor)driver;
		   Thread.sleep(1000);
	executor.executeScript("document.body.style.zoom = '60%'");
		   Thread.sleep(2000);
	executor.executeScript("document.body.style.zoom = '100%'");
		 RC_Global.createNode(driver, "Validation of Type-ahead feature Customer Number input box values");	
			WebElement element = driver.findElement(By.xpath("(//cell-template/div/div[2]//input)[1]"));
			String input = "8742";
			RC_Global.enterInput(driver, input, element, false, false);
			Thread.sleep(3000);
			queryObjects.logStatus(driver, Status.INFO, "Type-ahead entered input: ", input, null);
			String cusNumber = driver.findElement(By.xpath("(//div[@role='presentation']/div[2]//div[contains(@ng-class,'focused')]//following::div[1]//div)[1]")).getText();
			Thread.sleep(2000);
		if (cusNumber.contains(input)) {
			queryObjects.logStatus(driver, Status.INFO, "The type ahead filter value : ", cusNumber, null);
			driver.findElement(By.xpath("(//i[@aria-label='Remove Filter'])[1]")).click();
		} else {
			queryObjects.logStatus(driver, Status.WARNING, "No type ahead value displays in grid for customer number", "", null);
		}

		RC_Global.createNode(driver, "Validation of Type-ahead feature Customer Name input box values");	
		WebElement element1 = driver.findElement(By.xpath("(//cell-template/div/div[2]//input)[2]"));
		String input1 = "Wawa";
		RC_Global.enterInput(driver, input1, element1, false, false);
		Thread.sleep(3000);
		queryObjects.logStatus(driver, Status.INFO, "Type-ahead entered input: ", input1, null);
		String cusName = driver.findElement(By.xpath("(//div[@role='presentation']/div[2]//div[contains(@ng-class,'focused')]//following::div[1]//div)[2]")).getText();
		Thread.sleep(2000);
		if (cusName.contains(input1)) {
			queryObjects.logStatus(driver, Status.INFO, "The type ahead filter value : ", cusName, null);
			driver.findElement(By.xpath("(//i[@aria-label='Remove Filter'])[2]")).click();
		} else {
			queryObjects.logStatus(driver, Status.WARNING, "No type ahead value displays in grid for customer name", "",
					null);
		}
		
		RC_Global.createNode(driver, "Validation of Type-ahead feature Template Name input box values");
		WebElement element2 = driver.findElement(By.xpath("(//cell-template/div/div[2]//input)[3]"));
		String input2 = "Client Data";
		RC_Global.enterInput(driver, input2, element2, false, false);
		Thread.sleep(3000);
		queryObjects.logStatus(driver, Status.INFO, "Type-ahead entered input: ", input2, null);
		String templateName = driver.findElement(By.xpath("(//div[@role='presentation']/div[2]//div[contains(@ng-class,'focused')]//following::div[1]//div)[3]")).getText();
		Thread.sleep(2000);
		if (templateName.contains(input2)) {
			queryObjects.logStatus(driver, Status.INFO, "The type ahead filter value : ", templateName, null);
			driver.findElement(By.xpath("(//i[@aria-label='Remove Filter'])[3]")).click();
		} else {
			queryObjects.logStatus(driver, Status.WARNING, "No type ahead value displays in grid for template name", "",null);
		}
		
	
		RC_Global.createNode(driver, "Validation of Type-ahead feature Status input box values");
		RC_Global.selectDropdownOption(driver, "Status", "Completed with Success", false,false);
		String status = driver.findElement(By.xpath("(//div[@role='presentation']/div[2]//div[contains(@ng-class,'focused')]//following::div[1]//div)[11]")).getText();
		Thread.sleep(2000);
		if (status.contains("Success")) {
			queryObjects.logStatus(driver, Status.INFO, "The type ahead filter value : ", status, null);
			driver.findElement(By.xpath("//select[contains(@ng-model,'Status')]//option[1]")).click();
		} else {
			queryObjects.logStatus(driver, Status.WARNING, "No type ahead value displays in grid for Status", "",null);
		}
		
		/*RC_Global.createNode(driver, "Validation of Type-ahead feature User Upload input box values");
		 Thread.sleep(1000);
			executor.executeScript("document.body.style.zoom = '75%'");
				  //(//cell-template/div/div[2]//input)[4]
			//(//div//span[text()='User Uploaded']/following::div//input)[1]
			Thread.sleep(3000);
		driver.findElement(By.xpath("(//div//span[text()='User Uploaded']/following::div//input)[1]")).click();
		driver.findElement(By.xpath("(//div//span[text()='User Uploaded']/following::div//input)[1]")).clear();
		String input3 = "Test";
		driver.findElement(By.xpath("(//div//span[text()='User Uploaded']/following::div//input)[1]")).sendKeys(input3);
		Thread.sleep(3000);
		queryObjects.logStatus(driver, Status.INFO, "Type-ahead entered input: ", input3, null);
		String userUpload = driver.findElement(By.xpath("(//div[@role='presentation']/div[2]//div[contains(@ng-class,'focused')]//following::div[1]//div)[15]")).getText();
		Thread.sleep(2000);
		if (userUpload.contains(input3)) {
			queryObjects.logStatus(driver, Status.INFO, "The type ahead filter value : ", userUpload, null);
			driver.findElement(By.xpath("(//i[@aria-label='Remove Filter'])[4]")).click();
		} else {
			queryObjects.logStatus(driver, Status.WARNING, "No type ahead value displays in grid for User Upload", "",null);
		}
		 Thread.sleep(2000);
			executor.executeScript("document.body.style.zoom = '100%'");*/
		
		
		RC_Global.logout(driver, false);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
		}
		}
	}

}
