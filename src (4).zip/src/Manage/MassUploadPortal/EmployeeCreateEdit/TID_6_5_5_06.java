package Manage.MassUploadPortal.EmployeeCreateEdit;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_5_5_06 {
	public void PicklistFieldsAndValuesOnEmployeeMassCreateEditTemplate(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String selType = "Employee Upload";String cusno= "LS007656";String Filename="";String downloadPath="";
		String sptVal[] = null;String curDir = "";String newFileName = "";String curFilePath = "";

		String defTimeZon = java.util.TimeZone.getDefault().getID();

		RC_Manage.deleteFile_Downloads(driver, "EmployeeCreateEdit");
		RC_Manage.deleteAllFolder_Files(driver);
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Mass Upload Portal", "");
		RC_Global.waitElementVisible(driver, 60, "//div//h3[text()='Mass Uploads']", "Mass Uploads",false,true);
		RC_Global.enterCustomerNumber(driver, cusno, "", "",true);
		WebElement custInputField = driver.findElement(By.xpath("//div[@ng-show='customerChosen']/input[@name='customerInput']"));

		Filename="EmployeeCreateEdit-"+custInputField.getAttribute("value").trim()+".xlsx";

		downloadPath = RC_Manage.fileDownload(driver, selType, Filename);
		if (downloadPath.contains(";")) {
			sptVal = downloadPath.split(";");
			curDir= sptVal[0];
			newFileName = sptVal[1];
			curFilePath = curDir+"\\"+newFileName;	
		}


		List<Integer> rowsDet2 = RC_Manage.Get_insertRow_Excel(driver, curFilePath, "", 1,"Employee Upload");

		RC_Manage.columnsFormatValidation_Employee_Pool(driver, curFilePath, "Status;Distribution Method;Preferred Contact Method;Enrolled in Fuel;Fuel PIN Pool;Enrolled in Personal Use;Enrolled in Driver Ordering;Selector Group;Create a New User Login ID", "Active-Inactive;Email-Text Message-Email & Text Message;Cell-Work-Email;Yes-No;RAMAC Corporation PIN Pool 1;Yes-No;Yes-No;2022 MY Builds;Yes-No", " ; ; ; ; ; ; ; ;No", rowsDet2);

		String rowData = RC_Manage.getColumnVals_SpecificRow(driver, curFilePath, "First Name;Last Name;Residential Address City;Residential Address State;Enrolled in Fuel;Enrolled in Personal Use;Enrolled in Driver Ordering", rowsDet2.get(0));
		String fName=rowData.split("__")[1].split(";")[0];
		String lName=rowData.split("__")[1].split(";")[1];
		String city=rowData.split("__")[1].split(";")[2];
		String state=rowData.split("__")[1].split(";")[3];
		String fuel=rowData.split("__")[1].split(";")[4];
		String pUse=rowData.split("__")[1].split(";")[5];
		String dOrdering=rowData.split("__")[1].split(";")[6];
		RC_Global.panelAction(driver, "close", "Mass Upload Portal", false, true);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Employee Management");

		RC_Global.enterCustomerNumber(driver, cusno, "", "", true);
		WebElement fNameField = driver.findElement(By.xpath("//input[@placeholder='Employee First Name']"));
		WebElement lNameField = driver.findElement(By.xpath("//input[@placeholder='Employee Last Name']"));
		WebElement cityField =driver.findElement(By.xpath("//input[@placeholder='City']"));
		RC_Global.selectDropdownOption(driver, "State", state, false, true);
		RC_Global.enterInput(driver, fName, fNameField, false, true);
		RC_Global.enterInput(driver, lName, lNameField, false, true);
		RC_Global.enterInput(driver, city, cityField, false, true);
		RC_Global.clickButton(driver, "Search", false, true);
		RC_Global.waitElementVisible(driver, 10, "//span[text()='Edit Employee']", "Edit Employee panel is displayed", false, true);
		RC_Global.panelAction(driver, "close", "Employee Management", false, true);
		RC_Global.panelAction(driver, "expand", "Edit Employee", false, true);
		RC_Global.scrollById(driver, "//legend[text()='Options']");

		RC_Global.createNode(driver, "Validate Enrolled In Fuel, Enrolled In Personal Use & Driver Ordering");
		if(fuel.equals("No"))
		{
			if(driver.findElement(By.xpath("//input[@id='isEnrolledInFuelCheckBox']")).getAttribute("class").contains("ng-empty"))
				queryObjects.logStatus(driver, Status.PASS, "Enrolled In Fuel CheckBox Is" , "Not Checked", null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Enrolled In Fuel CheckBox Is" , "Checked", null);
		}
		else
		{
			if(driver.findElement(By.xpath("//input[@id='isEnrolledInFuelCheckBox']")).getAttribute("class").contains("ng-not-empty"))
				queryObjects.logStatus(driver, Status.PASS, "Enrolled In Fuel CheckBox Is" , "Checked", null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Enrolled In Fuel CheckBox Is" , "Not Checked", null); 
		}

		if(pUse.equals("No"))
		{
			if(driver.findElement(By.xpath("//input[@id='isEnrolledInPUCheckBox']")).getAttribute("class").contains("ng-empty"))
				queryObjects.logStatus(driver, Status.PASS, "Enrolled In Personal Use CheckBox Is" , "Not Checked", null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Enrolled In Personal Use CheckBox Is" , "Checked", null);
		}
		else
		{
			if(driver.findElement(By.xpath("//input[@id='isEnrolledInPUCheckBox']")).getAttribute("class").contains("ng-not-empty"))
				queryObjects.logStatus(driver, Status.PASS, "Enrolled In Personal Use CheckBox Is" , "Checked", null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Enrolled In Personal Use CheckBox Is" , "Not Checked", null); 
		}

		if(dOrdering.equals("No"))
		{
			if(driver.findElement(By.xpath("//input[@id='isEnrolledInDOCheckBox']")).getAttribute("class").contains("ng-empty"))
				queryObjects.logStatus(driver, Status.PASS, "Enrolled In Driver Ordering CheckBox Is" , "Not Checked", null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Enrolled In Driver Ordering CheckBox Is" , "Checked", null);
		}
		else
		{
			if(driver.findElement(By.xpath("//input[@id='isEnrolledInDOCheckBox']")).getAttribute("class").contains("ng-not-empty"))
				queryObjects.logStatus(driver, Status.PASS, "Enrolled In Driver Ordering CheckBox Is" , "Checked", null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Enrolled In Driver Ordering CheckBox Is" , "Not Checked", null); 
		}

		RC_Global.scrollById(driver, "//span[text()='Edit Employee']");
		RC_Global.panelAction(driver, "close", "Edit Employee", false, true);

	    String delVals = RC_Manage.columnsValueEdit_Employee_Pool(driver, curFilePath, "Status;Distribution Method;Preferred Contact Method;Enrolled in Fuel;Enrolled in Personal Use;Enrolled in Driver Ordering;Create a New User Login ID", RandomStringUtils.randomNumeric(5)+";1234;567;ABCD;XYZ;AB11;45JK", rowsDet2);	
	    RC_Global.navigateTo(driver, "Manage", "Mass Upload Portal", "");
		RC_Global.waitElementVisible(driver, 60, "//div//h3[text()='Mass Uploads']", "Mass Uploads",false,true);
		RC_Global.enterCustomerNumber(driver, cusno, "", "",true);
	    
		//Employee Template is displayed with default values as expected
				List<Integer> rowsDet = RC_Manage.Get_insertRow_Excel(driver, curFilePath, "insert", 1,"Employee Upload");
				RC_Manage.columnsFormatValidation_Employee_Pool(driver, curFilePath, "Status;Distribution Method;Preferred Contact Method;Enrolled in Fuel;Fuel PIN Pool;Enrolled in Personal Use;Enrolled in Driver Ordering;Selector Group;Create a New User Login ID", "Active-Inactive;Email-Text Message-Email & Text Message;Cell-Work-Email;Yes-No;RAMAC Corporation PIN Pool 1;Yes-No;Yes-No;2022 MY Builds;Yes-No", " ; ; ; ; ; ; ; ; ", rowsDet);

		String userName = driver.findElement(By.xpath("//span[contains(@ng-show,'user.FullName') and @id='Span1']")).getText();
	    String submitTime = RC_Manage.fileUpload(driver, curDir, curFilePath, selType, "", defTimeZon, userName, "");
		String uploadedTime = RC_Manage.selectDownloadResults(driver, userName, submitTime, defTimeZon);
		
		String fileDownload = RC_Manage.moveFileFromDownloads(driver, Filename, "DownloadedFiles", true);
        if (fileDownload.contains(";")) {
        	String downDir = fileDownload.substring(0, fileDownload.indexOf(";"));
        	String downFilePath = fileDownload.replace(";", "\\"); 
		RC_Manage.validateResults_RowNumbers(driver, downFilePath, rowsDet2, "Error", "Missing value in required fields");
        }
        RC_Global.panelAction(driver, "close", "Mass Upload Portal", false, true);
        queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}


