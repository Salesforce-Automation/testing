package Manage.MassUploadPortal.EmployeeCreateEdit;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.LeaseWave.RC_LW_Global;
import tools.LeaseWave.RC_LW_Manage;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_5_5_05 {
	public void MandatoryFieldsMissingOnEmployeeManagement_Create_EditTemplate_UploadFails(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String sptVal[] = null;
		String retVal = ""; String fileDownload=""; String newFileName = ""; String curDir = ""; String curFilePath = "";
		String downDir = ""; String downFilePath = "";
		String userName = ""; String submitTime = ""; String defTimeZon = "";
		String uploadedTime = "";List<Integer> rowsDet =  new ArrayList<Integer>(); List<Integer> rowsDet2 =  new ArrayList<Integer>();
		
		String cusno= "LS010143"; String selType = "Employee Upload"; String Filename="EmployeeCreateEdit-"+cusno+".xlsx";
		try {
			defTimeZon = java.util.TimeZone.getDefault().getID();
			RC_Manage.deleteFile_Downloads(driver, "EmployeeCreateEdit");
			RC_Manage.deleteAllFolder_Files(driver);
			RC_Global.login(driver);
			RC_Global.navigateTo(driver,"Manage","Mass Upload Portal","");
			Thread.sleep(5000);
	        RC_Global.enterCustomerNumber(driver, cusno, "", "", true);        
	        retVal = RC_Manage.fileDownload(driver, selType, Filename);
	        if (retVal.contains(";")) {
	        	sptVal = retVal.split(";");
	        	curDir= sptVal[0];
	        	newFileName = sptVal[1];
	        	curFilePath = curDir+"\\"+newFileName;
	        	
	        	//Check the Mandatory Column background color
	        	RC_Manage.columnNames_BGColorValidation(driver, curFilePath, "First Name;Last Name;Address Validation Override;Residential Address 1;Residential Address City;Residential Address State;Residential Address Zip Code;Residential Address Country;Distribution Method;Enrolled in Fuel;Enrolled in Personal Use;Enrolled in Driver Ordering;Create a New User Login ID;Status");
	        	
	        	//Get Random rows
	        	rowsDet = RC_Manage.Get_insertRow_Excel(driver, curFilePath, "", 4, selType);
	        	
	        	//Update the Mandatory rows with blank/invalid values
	        	rowsDet2.add(rowsDet.get(0));	        	
	        	RC_Manage.columnsValueEdit_Employee_Pool(driver, curFilePath, "Address Validation Override;Residential Address 1;Residential Address City;Residential Address State;Residential Address Zip Code;Residential Address Country", "No; ; ; ;123456; ", rowsDet2);
	        	rowsDet2.remove(0); rowsDet2.add(rowsDet.get(1));
	        	RC_Manage.columnsValueEdit_Employee_Pool(driver, curFilePath, "Email;Distribution Method", "invalidemail;Email & Text Message", rowsDet2);
	        	rowsDet2.remove(0); rowsDet2.add(rowsDet.get(2));
	        	RC_Manage.columnsValueEdit_Employee_Pool(driver, curFilePath, "Enrolled in Fuel;Fuel Driver ID;Fuel PIN Pool", "Yes;"+RandomStringUtils.randomNumeric(4)+";selListVal", rowsDet2);
	        	rowsDet2.remove(0); rowsDet2.add(rowsDet.get(3));
	        	RC_Manage.columnsValueEdit_Employee_Pool(driver, curFilePath, "Status;", " ;", rowsDet2);
	        	
	        	userName = driver.findElement(By.xpath("//span[contains(@ng-show,'user.FullName') and @id='Span1']")).getText();
	        	submitTime = RC_Manage.fileUpload(driver, curDir, curFilePath, selType, "", defTimeZon, userName, "");	        	
	        	uploadedTime = RC_Manage.selectDownloadResults(driver, userName, submitTime, defTimeZon);//download file	        	
	        	fileDownload = RC_Manage.moveFileFromDownloads(driver, Filename, "DownloadedFiles", true);
	            if (fileDownload.contains(";")) {
	            	downDir = fileDownload.substring(0, fileDownload.indexOf(";"));
	            	downFilePath = fileDownload.replace(";", "\\");
	            	RC_Manage.validateResults_RowNumbers(driver, downFilePath, rowsDet, "Error", "Missing value in required fields");
	            	RC_Manage.deleteFolder(driver, downDir);
	            	queryObjects.logStatus(driver, Status.PASS, "EmployeeCreateEdit Template - Invaid or Missing Mandatory Fields update changes upload", "Verification successful", null);	
	            	
	            }
			}
		} catch (Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "EmployeeCreateEdit Template - Invaid or Missing Mandatory Fields update changes upload - Test run failed", e.getLocalizedMessage(), e);
		}
		      
	}
	
}
