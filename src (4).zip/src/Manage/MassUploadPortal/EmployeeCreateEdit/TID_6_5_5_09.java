package Manage.MassUploadPortal.EmployeeCreateEdit;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_5_5_09 {
	
	public void fuelDriverIDGenerationthroughMassEmployeeCreate_Edit(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		{
			
			String sptVal[] = null;
			String retVal = "";
			String curDir = "";
			String newFileName = "";
			String curFilePath = "";
			String rowVals = "";
			String UpdateVals= "";
			String delUnitNos= "";
			String defTimeZon = "";
			String userName = "";
			
			String selTemplate= "Employee Upload";String cusno= "LS010116"; String selType = "Employee Upload"; String Filename="EmployeeCreateEdit-"+cusno+".xlsx";
			RC_Manage.deleteFile_Downloads(driver, "EmployeeCreateEdit");
			
			RC_Manage.deleteAllFolder_Files(driver);
				RC_Global.login(driver);
				RC_Global.navigateTo(driver,"Manage","Mass Upload Portal","");
				
				Thread.sleep(5000);
		        RC_Global.enterCustomerNumber(driver, "LS010116", "", "", true); 
		        
				
			Thread.sleep(5000);
			
			retVal = RC_Manage.fileDownload(driver, selType, Filename);
	
				   if (retVal.contains(";")) {
			        	sptVal = retVal.split(";");
		        	curDir= sptVal[0];
		        	newFileName = sptVal[1];
		        	curFilePath = curDir+"\\"+newFileName;
					Thread.sleep(5000);
					String excelpath= curFilePath;
				
					File file1 =new File (curFilePath);
						
						FileInputStream fis= new FileInputStream(file1);
					
					
					//FileOutputStream fos= new FileOutputStream(curFilePath);
					
					XSSFWorkbook wb= new XSSFWorkbook(fis);
						
						XSSFSheet Sheet =wb.getSheetAt(1);
						
					Sheet.getRow(5).createCell(26).setCellValue("YES");
				
					Sheet.getRow(6).createCell(26).setCellValue("YES");
					
						Sheet.getRow(7).createCell(26).setCellValue("YES");
						Sheet.getRow(8).createCell(26).setCellValue("YES");
						Sheet.getRow(9).createCell(26).setCellValue("YES");
						
						FileOutputStream fos= new FileOutputStream(file1);
					
					wb.write(fos);
					wb.close();
						
						Thread.sleep(5000);
						
						
				
					 RC_Manage.fileUpload(driver, curDir, curFilePath, selType, "", defTimeZon, userName, "");
						Thread.sleep(5000);
						
						RC_Global.navigateTo(driver,"Manage","Administration","Employee Management");
						
						RC_Global.panelAction(driver, "expand", "Employee Management",false, false);
						
						
						 
						 
						
						Thread.sleep(5000);
						 //RC_Global.clickUsingXpath(driver, "//*[@id=\"searchInput\"]//fieldset/div[1]/div/input", "click Customer Number fild", false, false);
						WebElement webelement = driver.findElement(By.xpath("//*[@id=\"searchInput\"]//fieldset/div[1]/div/input"));
						
						
						 Thread.sleep(5000);
						 RC_Global.enterInput(driver, "LS010116", webelement, false, false);
						
						 
						RC_Global.clickUsingXpath(driver, "//label[normalize-space(text())='Customer Number']/following-sibling::ul//a", "select customer", false, false);
						 
						 Thread.sleep(5000);
						 
						 RC_Global.clickButton(driver, "Search", false, false);
						 
						 Thread.sleep(10000);
						 
						 RC_Global.createNode(driver, "select customer for edit table");
						 
							RC_Global.clickUsingXpath(driver,"//table[@class='fixed-table-body table table-bordered table-hover table-striped table-layout-static']//td[1]/..","select customer for editPage",false, false);
						 
							 Thread.sleep(5000);
							 RC_Global.panelAction(driver, "expand", "Edit Employee",false, false);
							 
							 Thread.sleep(3000);
							 RC_Global.verifyScreenComponents(driver, "label", "Fuel Driver ID ", false);
							 
							 RC_Global.navigateTo(driver,"Manage","Administration","Customer Administration");
							 
							 Thread.sleep(5000);
							 RC_Global.enterCustomerNumber(driver, "LS010116", "", "", true); 
							 
							 Thread.sleep(5000);
							 
							 RC_Global.clickUsingXpath(driver, "//a[text()='Fuel']", "select fuleTab", false, false);
							 
							 Thread.sleep(3000);
							 RC_Global.clickUsingXpath(driver, "//*[@id=\"FuelDriverID\"]", "select fuleDriverID", false, false);
							 
							 RC_Global.selectDropdownOption(driver, "Fuel Driver ID", "VIN", false, false);
							 RC_Global.clickButton(driver, "save", false, false);
							 RC_Global.verifyDisplayedMessage(driver, "Update Successful", false);
							 
							 Thread.sleep(3000);
							 
							 RC_Global.navigateTo(driver,"Manage","Mass Upload Portal","");
							 
							 RC_Global.panelAction(driver, "expand", "Mass Upload Portal",false, false);
							 
							 RC_Manage.fileUpload(driver, curDir, curFilePath, selType, "", defTimeZon, userName, "");
							 
								
								RC_Global.navigateTo(driver,"Manage","Administration","Employee Management");
								
								RC_Global.panelAction(driver, "expand", "Employee Management",false, false);
								
								Thread.sleep(5000);
								 //RC_Global.clickUsingXpath(driver, "//*[@id=\"searchInput\"]//fieldset/div[1]/div/input", "click Customer Number fild", false, false);
								WebElement Webelement = driver.findElement(By.xpath("//*[@id=\"searchInput\"]//fieldset/div[1]/div/input"));
								
								
								 Thread.sleep(5000);
								 RC_Global.enterInput(driver, "LS010116", Webelement, false, false);
							 
								 
								 RC_Global.clickUsingXpath(driver, "//label[normalize-space(text())='Customer Number']/following-sibling::ul//a", "select customer", false, false);
								 
								 Thread.sleep(5000);
								 
								 RC_Global.clickButton(driver, "Search", false, false);
								 
								 Thread.sleep(10000);
								 
								 RC_Global.createNode(driver, "select customer for edit table");
								 
									RC_Global.clickUsingXpath(driver,"//table[@class='fixed-table-body table table-bordered table-hover table-striped table-layout-static']//td[1]/..","select customer for editPage",false, false);
								 
									 Thread.sleep(5000);
									 RC_Global.panelAction(driver, "expand", "Edit Employee",false, false);
									 
									 Thread.sleep(3000);
									 RC_Global.verifyScreenComponents(driver, "label", "Fuel Driver ID ", false);
							 
							 
							 
						
							 
							 Thread.sleep(50000);
							 
					
}
}
}
}
