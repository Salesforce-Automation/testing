package Manage.MassUploadPortal.EmployeeCreateEdit;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_5_5_08 {
	public void FuelPINPoolValidationThroughEmployeeMassCreate_Edit(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		String menu = "Manage";
		String firstSubMenu = "Mass Upload Portal";
		String CustomerNumber = "LS010108"; 
		String selType = "Employee Upload"; String downDir = ""; String downFilePath= "";
		String Filename="EmployeeCreateEdit-"+CustomerNumber+".xlsx"; String curFilePath = "";String sptVal[] = null;	String retVal = "";String newFileName = ""; String curDir = "";
		List<Integer> rowChange = null; List<Integer> rowUpdate = new ArrayList<Integer>(); String defTimeZone = "";String userName = "";String submitTime = "";String fileDownload = "";
		defTimeZone = java.util.TimeZone.getDefault().getID(); String uploadedTime = ""; String valDate = null; String currentVal = null;
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,"");
		RC_Global.waitElementVisible(driver, 30,"//h3[text()='Mass Uploads']", "Mass Upload Portal", true, true);
		RC_Global.enterCustomerNumber(driver,CustomerNumber, "", "", true);
		retVal = RC_Manage.fileDownload(driver, selType, Filename);
		RC_Global.createNode(driver, "");
		 if (retVal.contains(";")) {
	        	sptVal = retVal.split(";");
	        	curDir= sptVal[0];
	        	newFileName = sptVal[1];
	        	curFilePath = curDir+"\\"+newFileName;
		 }
		 rowChange = RC_Manage.Get_insertRow_Excel(driver, curFilePath, "insert",1, selType);
		 RC_Manage.updateAllColumns_Employee_PoolUpload(driver, curFilePath, rowChange);
		 
		 FileInputStream fis = new FileInputStream(curFilePath);
	        XSSFWorkbook wb = new XSSFWorkbook(fis);
	        XSSFSheet sh = wb.getSheetAt(1);
	        int rows = sh.getLastRowNum();
	        XSSFRow  row = sh.getRow(rows);
	        int rr = 5;
	        rowUpdate.add(new Integer(rr));
	        XSSFCell cell = sh.getRow(rr).getCell(28);   
	    	currentVal = cell.getStringCellValue();
	    	if(currentVal.contains("Momentive Performance Mat PIN Pool 1"))
	    		cell.setCellValue("MPM Silicones PIN Pool 1");
	    	else if(currentVal.contains("MPM Silicones PIN Pool 1"))
	    		cell.setCellValue("Momentive Performance Mat PIN Pool 1");
	    	else if(currentVal.contains("Momentive Performance Qua PIN Pool 1"))
	    		cell.setCellValue("MPM Silicones PIN Pool 1");	
	    
	    fis.close();
        FileOutputStream fos = new FileOutputStream(curFilePath);
        wb.write(fos);
        wb.close();
        fos.close(); 	
        
		
		  
		userName = driver.findElement(By.xpath("//span[contains(@ng-show,'user.FullName') and @id='Span1']")).getText();
		submitTime = RC_Manage.fileUpload(driver, curDir, curFilePath, selType, "", defTimeZone, userName, "");
		 
		uploadedTime = RC_Manage.selectDownloadResults(driver, userName, submitTime, defTimeZone);//download the results file
	    	if (defTimeZone.equalsIgnoreCase("CST") || defTimeZone.equalsIgnoreCase("America/Chicago")) {
	    		valDate = RC_Manage.driverHistory_DateFormat(driver, queryObjects, uploadedTime, "No");
			} else {
				valDate = RC_Manage.driverHistory_DateFormat(driver, queryObjects, uploadedTime, "Yes");
			}
	    
	    fileDownload = RC_Manage.moveFileFromDownloads(driver, Filename, "DownloadedFiles", true);
	        if (fileDownload.contains(";")) {
	        	downDir = fileDownload.substring(0, fileDownload.indexOf(";"));
	        	downFilePath = fileDownload.replace(";", "\\");
	        }
	     
		 RC_Manage.validateResults_RowNumbers(driver, downFilePath, rowUpdate, "Error", "PIN Pool is not associated with the Employee assignment node of structure."); 
         RC_Global.panelAction(driver, "close", "Mass Upload Portal", true,false);
		 RC_Global.logout(driver, false);
		 queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
