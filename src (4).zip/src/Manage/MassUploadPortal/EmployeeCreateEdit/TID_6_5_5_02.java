package Manage.MassUploadPortal.EmployeeCreateEdit;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.LeaseWave.RC_LW_Global;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_5_5_02 {

	public static void CreateNewUserLoginThroughEmployeeMassCreate_Edit(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		String cusNo = "LS008742";
		String fileName = "EmployeeCreateEdit-"+cusNo+".xlsx";
		String defTimeZon = "";String sptVal[] = null; String newFileName = ""; String curDir = "";
		String curFilePath = ""; String selType = "Employee Upload";
		 String UpdateVals= ""; String delVals= "";String delUnitNos1= "";String delUnitNos2= "";String delUnitNos3= "";
		 String delValsEd1= ""; String delValsEd2= ""; String delValsEd3= "";
		 String rowData_oldEd[] = null; String rowData_newEd[] = null;String sptRows1[] = null;String sptRows2[] = null;String sptRows3[] = null;
		 String rowData_oldEd1[] = null; String rowData_oldEd2[] = null; String rowData_newEd1[] = null; String rowData_newEd2[] = null;
		String RowValsN = ""; String RowValsU = ""; String rowData_old[] = null; String rowData_new[] = null;
		String retRowVal = ""; String sptCell_old[] = null; 
		String fileDownload="";String downFilePath = ""; String downDir = "";
		String sptRows[] = null;String delUnitNos= ""; String userName = ""; String submitTime = ""; String UnitNums = "";
		String defTimeZone = ""; String uploadedTime = ""; 	
		defTimeZone = java.util.TimeZone.getDefault().getID();
		String colNames[] = null; String sptCell_new[] = null; String sptCell_new1[] = null; String sptCell_new2[] = null; String sptCell_new3[] = null; 
		String newColName = ""; String newCol = ""; int colNo = 0;String valDate = null;
		List<Integer> rowsDet = null; List<Integer> rowsDet2 = new ArrayList<Integer>();
		List<String> addressLists = (List<String>) RC_Manage.RandomSelection(driver);
		List<Integer> newRows = new ArrayList<Integer>();
		String Fname = "Jessica"+RandomStringUtils.randomAlphanumeric(3).toLowerCase()+RandomStringUtils.randomNumeric(3);
    	String Lname = "TestData"+RandomStringUtils.randomAlphanumeric(3);
    	String addressset = addressLists.get(0);
    	String email = ""+RandomStringUtils.randomAlphabetic(7).toUpperCase()+RandomStringUtils.randomNumeric(3)+"@merchants.com";
    	String zipcode = addressLists.get(3);
    	String cellphone = RandomStringUtils.randomNumeric(10);
    	String fuelDriverID = RandomStringUtils.randomNumeric(6);
		
		ArrayList<String> UnitNumList=new ArrayList<String>();
		String colName = ""; 
		
		defTimeZon = java.util.TimeZone.getDefault().getID();
		RC_Manage.deleteFile_Downloads(driver, "EmployeeCreateEdit");
		RC_Manage.deleteAllFolder_Files(driver);
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Mass Upload Portal", "");
		RC_Global.waitUntilPanelVisibility(driver, "Mass Upload Portal", "TV", true,true);
		Thread.sleep(3000);
		RC_Global.enterCustomerNumber(driver, cusNo, "", "", true);
		String downloadPath = RC_Manage.fileDownload(driver, selType, fileName);
		if (downloadPath.contains(";")) {
        	sptVal = downloadPath.split(";");
        	curDir= sptVal[0];
        	newFileName = sptVal[1];
        	curFilePath = curDir+"\\"+newFileName;
        	rowsDet = RC_Manage.Get_insertRow_Excel(driver, curFilePath, "insert", 1,selType);
        	
        	delVals = RC_Manage.updateAllColumns_Employee_PoolUpload(driver, curFilePath, rowsDet);
        	rowsDet2 = RC_Manage.Get_insertRow_Excel(driver, curFilePath, "", 1,selType);
        	//Edit cells
        	delValsEd1 = RC_Manage.columnsValueEdit_Employee_Pool(driver, curFilePath, "First Name;Last Name;Residential Address 1;Residential Address City;Residential Address State;Residential Address Zip Code;Residential Address Country;Cell Phone;Email;Distribution Method;Employee Assignment;Enrolled in Fuel;Fuel Driver ID;Fuel PIN Pool;Create a New User Login ID;Status", 
        			Fname+";"+Lname+";"+addressset+";"+addressLists.get(1)+";"+addressLists.get(2)+";"+zipcode+";selListVal;"+cellphone+";"+email+";Email & Text Message;selListVal;Yes;"+fuelDriverID+";selListVal;Yes;Active", rowsDet2);
        	
        	sptRows = delVals.split("~~");
        	sptRows1 = delValsEd1.split("~~");        	
        	colNames = sptRows[0].split(";");
        	rowData_old = sptRows[1].split(";");        	
        	rowData_new = sptRows[2].split(";");
        	rowData_newEd = sptRows1[2].split(";");
        	String NewENameF = rowData_new[1];
        	String NewENameL = rowData_new[2];
        	System.out.println(""+NewENameF+", "+NewENameL+"");
 		
		}
     	queryObjects.logStatus(driver, Status.INFO, "Edited Row values - "+delUnitNos+" & "+delUnitNos1+ " & "+delUnitNos2+" & "+delUnitNos3+"", "Verification successful", null);
    	userName = driver.findElement(By.xpath("//span[contains(@ng-show,'user.FullName') and @id='Span1']")).getText();
    	submitTime = RC_Manage.fileUpload(driver, curDir, curFilePath, selType, "", defTimeZon, userName, "");
    	boolean flag = false;
    	uploadedTime = RC_Manage.selectDownloadResults(driver, userName, submitTime, defTimeZon);//download file
    	if (defTimeZon.equalsIgnoreCase("CST") || defTimeZon.equalsIgnoreCase("America/Chicago")) {
    		valDate = RC_Manage.driverHistory_DateFormat(driver, queryObjects, uploadedTime, "No");
		} else {
			valDate = RC_Manage.driverHistory_DateFormat(driver, queryObjects, uploadedTime, "Yes");
		}
    	fileDownload = RC_Manage.moveFileFromDownloads(driver, fileName, "DownloadedFiles", true);
        if (fileDownload.contains(";")) {
        	downDir = fileDownload.substring(0, fileDownload.indexOf(";"));
        	downFilePath = fileDownload.replace(";", "\\");
        	RC_Manage.validateResults_RowNumbers(driver, downFilePath, rowsDet, "Error", "");
        	RC_Manage.deleteFolder(driver, downDir);
        	RC_Global.panelAction(driver, "close", "Mass Upload Portal", false,true);
        	flag = true;	
        }
        if(!flag == true) {
        	queryObjects.logStatus(driver, Status.FAIL, "EmployeeCreateEdit Template - Invaid or Missing Mandatory Fields update changes upload - Test run failed","Verification Unsuccessful", null);
        }
        
        RC_Global.createNode(driver, "Validate the created columns in Total View - Employee History for the given First & Last Name -"+rowData_new[1]+rowData_new[2] );
        RC_Manage.viewHistory_Employee(driver, queryObjects, cusNo, rowData_new[1], rowData_new[2], userName, valDate);
    	queryObjects.logStatus(driver, Status.PASS, "Verified updated employee displays in History", "Successfully", null);
    	RC_Global.createNode(driver, "Validate the updated columns in Total View - Employee History for the given First & Last Name -"+rowData_newEd[1]+rowData_newEd[2] );
    	RC_Manage.viewHistory_Employee(driver, queryObjects, cusNo, rowData_newEd[1], rowData_newEd[2], userName, valDate);    	
    	queryObjects.logStatus(driver, Status.PASS, "Verified updated employee displays in History", "Successfully", null);
    	RC_Global.panelAction(driver, "close", "Employee History", true, false);
        
    	 RC_Global.logout(driver, false);
   		 RC_LW_Global.leaseWaveLogin(driver, false);
   		
   		 RC_Global.createNode(driver, "Verify the Newly Created and Updated employee");
   		driver.findElement(By.xpath("//a[contains(text(),'Fleet Management')]")).click();
		   	 RC_Global.waitElementVisible(driver, 50, "//span[text()='Fleet Management Menu']", "Fleet Management Menu",false, false);
        String home =  driver.findElement(By.xpath("//span[text()='Fleet Management Menu']")).getText();
        if(home.contains("FLEET MANAGEMENT MENU")) {
            BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Navigation to Fleet Management Menu", "Successfully", null);   
        }
        RC_Global.clickUsingXpath(driver,"//td[@accesskey='1' and text()='. Profiles']","Profiles",false, false);
        RC_Global.clickUsingXpath(driver,"//td[@accesskey='D']","Driver",false, false);
        RC_Global.clickUsingXpath(driver,"//tr[contains(@igurl,'DriverProfile')]/td[@accesskey='P']","Driver Profile",true, false);
		RC_Global.waitElementVisible(driver, 60, "//span[text()='Driver Profile List' and @id='ctl00_PageTitle']", "Asset List",true, true);
	    driver.findElement(By.xpath("//td[@lw_friendlyname='Account Number']//input")).sendKeys(cusNo);
	    driver.findElement(By.xpath("//td[@lw_friendlyname='First Name']//input")).sendKeys(Fname);
	    driver.findElement(By.xpath("//td[@lw_friendlyname='Last Name']//input")).sendKeys(Lname);
		RC_Global.clickUsingXpath(driver,"//button[text()='Searc']","Search button",false, true);
	    RC_Global.clickUsingXpath(driver,"//button[text()='dit']","Edit button",false, true);
        RC_Global.waitElementVisible(driver, 60, "//span[text()='Driver Profile' and @id='ctl00_PageTitle']", "Driver Profile Page",false, false);
        RC_Global.clickUsingXpath(driver,"//li/a[text()='Driver Profile']","Driver Profile",false, true);
        Thread.sleep(2000);
        WebDriverWait wait = new WebDriverWait(driver,60);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Contact Person Details']")));
        String firstName = driver.findElement(By.xpath("(//input[contains(@name,'FirstName')])[1]")).getText();
        String lastName = driver.findElement(By.xpath("(//input[contains(@name,'txtFilterText')])[1]")).getText();
        String address=  driver.findElement(By.xpath("(//textarea[contains(@name,'ContactAddressUC1')])[1]")).getText();
        String city = driver.findElement(By.xpath("(//input[contains(@name,'txtCity')])[1]")).getText();
        
        if (Fname.equals(firstName)) {
        	queryObjects.logStatus(driver, Status.PASS, "Edited First Name and Driver Profile First Name", "Are Same as Expected", null);
		} else {
			queryObjects.logStatus(driver, Status.FAIL, "Edited First Name and Driver Profile First Name", "Are Not Same as Expected", null);
		}
        
        if (Lname.equals(lastName)) {
        	queryObjects.logStatus(driver, Status.PASS, "Edited Last Name and Driver Profile Last Name", "Are Same as Expected", null);
		} else {
			queryObjects.logStatus(driver, Status.FAIL, "Edited Last Name and Driver Profile Last Name", "Are Not Same as Expected", null);
		}
        
        if (addressset.equals(address)) {
        	queryObjects.logStatus(driver, Status.PASS, "Edited Address and Driver Profile Address", "Are Same as Expected", null);
		} else {
			queryObjects.logStatus(driver, Status.FAIL, "Edited Address and Driver Profile Address", "Are Not Same as Expected", null);
		}
        
        RC_LW_Global.leaseWaveLogOut(driver, false);
        queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
		
    }
    
}
