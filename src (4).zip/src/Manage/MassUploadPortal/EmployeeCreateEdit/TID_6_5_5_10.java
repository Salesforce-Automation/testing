package Manage.MassUploadPortal.EmployeeCreateEdit;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.LeaseWave.RC_LW_Global;
import tools.LeaseWave.RC_LW_Manage;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_5_5_10 {
	public void WebServicesInteraction_MerchantsAndComdata_New_RemoveFuelEnrollment_EmployeeMassCreate_Edit(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String editVals= ""; String editVals2= "";  String editVals3= "";String addedVals= "";
		String sptVal[] = null;
		String retVal = ""; String fileDownload=""; String newFileName = ""; String curDir = ""; String curFilePath = "";
		String downDir = ""; String downFilePath = "";  String delUnitNos= ""; String UpdateUnitNos= "";
		String sptRows[] = null; String sptRows2[] = null; String rowData_old[] = null; 
		String colNames[] = null; String rowData2_old[] = null; String colNames2[] = null;
		String rowData_new[] = null; String rowData2_new[] = null; String sptCell_old[] = null; 
		String sptCell2_old[] = null; String sptCell_new[] = null; String sptCell2_new[] = null;
		String userName = ""; String newColName = ""; int colNo = 0; String newCol = "";
		String leaseStatus = ""; String submitTime = ""; String defTimeZon = "";
		String uploadedTime = ""; String valDate = null; List<Integer> rowsDet = null; List<Integer> rowsDet2 = new ArrayList<Integer>();
		List<Integer> newRows = new ArrayList<Integer>();

		String cusno= "LS008742"; String selType = "Employee Upload"; String Filename="EmployeeCreateEdit-"+cusno+".xlsx";
		try {
			defTimeZon = java.util.TimeZone.getDefault().getID();
			RC_Manage.deleteFile_Downloads(driver, "EmployeeCreateEdit");
			RC_Manage.deleteAllFolder_Files(driver);
			RC_Global.login(driver);
			RC_Global.navigateTo(driver,"Manage","Mass Upload Portal","");
			Thread.sleep(5000);
	        RC_Global.enterCustomerNumber(driver, cusno, "", "", true);        
	        retVal = RC_Manage.fileDownload(driver, selType, Filename);
	        if (retVal.contains(";")) {
	        	sptVal = retVal.split(";");
	        	curDir= sptVal[0];
	        	newFileName = sptVal[1];
	        	curFilePath = curDir+"\\"+newFileName;
	        	
	        	//Insert a row
	        	rowsDet = RC_Manage.Get_insertRow_Excel(driver, curFilePath, "insert", 1, selType);
	        	//Update Mandatory field values in the inserted row
	        	addedVals = RC_Manage.updateAllColumns_Employee_PoolUpload(driver, curFilePath, rowsDet);
	        	//Update the column values for newly created row
	        	editVals = RC_Manage.columnsValueEdit_Employee_Pool(driver, curFilePath, "Enrolled in Fuel;Fuel Driver ID;Fuel PIN Pool", "Yes;"+RandomStringUtils.randomNumeric(6)+";selListVal", rowsDet);	        	
	        	editVals2 = RC_Manage.getValidDataRows(driver, curFilePath, "Fuel Driver ID;Fuel PIN Pool");
	        	sptRows = editVals3.split("__");
	        	newRows.remove(0); newRows.add(Integer.parseInt(sptRows[0]));
	        	RC_Manage.columnsValueEdit_Employee_Pool(driver, curFilePath, "'Enrolled in Fuel", "No", newRows);
	        	
	        	userName = driver.findElement(By.xpath("//span[contains(@ng-show,'user.FullName') and @id='Span1']")).getText();
	        	submitTime = RC_Manage.fileUpload(driver, curDir, curFilePath, selType, "", defTimeZon, userName, "");
	        	
	        	uploadedTime = RC_Manage.selectDownloadResults(driver, userName, submitTime, defTimeZon);//download file
	        	
	        	fileDownload = RC_Manage.moveFileFromDownloads(driver, Filename, "DownloadedFiles", true);
	            if (fileDownload.contains(";")) {
	            	downDir = fileDownload.substring(0, fileDownload.indexOf(";"));
	            	downFilePath = fileDownload.replace(";", "\\");
	            	RC_Manage.validateResults_RowNumbers(driver, downFilePath, rowsDet, "Error", "");
	            	RC_Manage.deleteFolder(driver, downDir);
	            	//TV Application validate
	            	RC_Global.panelAction(driver, "close", "Mass Upload Portal", false,true);
	            	
	            	//Validate the Employee in the Fuel Pin Pool	            	
	            	RC_Global.navigateTo(driver, "Fleet Services", "Fuel", "Manage Fuel PIN Pool");
	                RC_Global.enterCustomerNumber(driver, cusno, "", "", true);
	               /* Select Pool
	                Filter employee_Pool
	                
	                //Validate the Employee in the Employee Management	            	
	                SearchEmployee_EmployeeManagement(driver, fName, lName, empID, emailID, resAddr);
	            	(//label[text()='Enrolled in Fuel ']/input)[2]
	            			ng-not-empty
	            			(//input[@placeholder='Fuel Driver ID'])[2]
	            					getattribute value
	            					
	            					(//select[@name='fuelPinPool'])[2]
	            	//SearchFuelPINPool(driver, fName, lName, empID, emailID, resAddr);
	            	RC_Manage.getColumnVals_SpecificRow(driver, Filename, "DownloadedFiles", newRows.get(0));*/
	            	
	            }
			}
		} catch (Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Download CVN Data and Mandatory field changes upload - Test run failed", e.getLocalizedMessage(), e);
		}
		      
	}
	
}
