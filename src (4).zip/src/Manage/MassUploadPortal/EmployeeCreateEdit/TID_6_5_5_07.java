package Manage.MassUploadPortal.EmployeeCreateEdit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_5_5_07 {
	public static void StatusOfEmployeesInEmployeeMassCreate_EditDownloadTemplate(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		String newFileName = ""; String curDir = "";
		String curFilePath = ""; String sptVal[] = null;
		String userName = ""; String defTimeZon = ""; String submitTime = ""; String uploadedTime = ""; 
		String fileName = "EmployeeCreateEdit-LS007656.xlsx";
		String fileDownload = ""; String downDir = ""; String downFilePath= "";
		String unitNumber = ""; String sptUnits[] = null; String errUnitNos = "";String updUnitNos = ""; String valDate = null;
		String[] fleetName = new String[10];
		String nodeStructure = "2000 - Terminix - Corporate";
		
		RC_Manage.deleteFile_Downloads(driver, "EmployeeCreateEdit");
		RC_Manage.deleteAllFolder_Files(driver);
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Mass Upload Portal", "");
		RC_Global.waitElementVisible(driver, 30, "//div[label[normalize-space(text())='Customer Number']]/input", "Customer Number Search Filter", true, false);
		RC_Global.enterCustomerNumber(driver, "LS007656", "", "", true);
		
		String downloadPath = RC_Manage.fileDownload(driver, "Employee Upload", "EmployeeCreateEdit-LS007656.xlsx");
		Thread.sleep(3000);
		if (downloadPath.contains(";")) {
        	sptVal = downloadPath.split(";");
        	curDir= sptVal[0];
        	newFileName = sptVal[1];
        	curFilePath = curDir+"\\"+newFileName;	
		}
		userName = driver.findElement(By.xpath("//span[contains(@ng-show,'user.FullName') and @id='Span1']")).getText();
		
		RC_Global.createNode(driver, "Verify downloaded template contains both Active as well as Inactive Status");
		RC_Manage.verifyExcelData(driver, curFilePath, "Status", "");
		
		RC_Global.createNode(driver, "Verify Employee Assignment is blank only at customer level");
		RC_Manage.verifyExcelData(driver, curFilePath, "Employee Assignment", "");
		
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[@class='input-group' and @ng-show='customerChosen']//input[@name='customerInput']")).clear();
		Thread.sleep(500);
		RC_Global.enterCustomerNumber(driver, "Terminix - Corporate", "", "", true);
		
		downloadPath = RC_Manage.fileDownload(driver, "Employee Upload", "EmployeeCreateEdit-2000.xlsx");
		Thread.sleep(3000);
		if (downloadPath.contains(";")) {
        	sptVal = downloadPath.split(";");
        	curDir= sptVal[0];
        	newFileName = sptVal[1];
        	curFilePath = curDir+"\\"+newFileName;	
		}
		userName = driver.findElement(By.xpath("//span[contains(@ng-show,'user.FullName') and @id='Span1']")).getText();
		
		RC_Global.createNode(driver, "Verify Employee Assignment contains the respective node structure only at node structure");
		String empName = RC_Manage.verifyExcelData(driver, curFilePath, "Employee Assignment", nodeStructure);
		String fName = empName.split(" ")[0];
		String lName = empName.split(" ")[1];

		RC_Global.panelAction(driver, "close", "Mass Upload Portal", true, false);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Employee Management");
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Employee First Name']]/input", "First Name", true, false);
		
		WebElement frstName = driver.findElement(By.xpath("//div[label[text()='Employee First Name']]/input"));
		WebElement lastName = driver.findElement(By.xpath("//div[label[text()='Employee Last Name']]/input"));
		
		RC_Global.enterInput(driver, fName, frstName, true, true);
		RC_Global.enterInput(driver, lName, lastName, true, true);
		
		RC_Global.clickButton(driver, "Search", true, false);
		
		if(driver.findElements(By.xpath("//td[text()='"+fName+"']")).size()>1)
			RC_Global.clickUsingXpath(driver, "//tr[td[text()='"+fName+"']]", "Grid first row", true, false);
		
		RC_Global.waitUntilPanelVisibility(driver, "Edit Employee", "TV", true, false);
		RC_Global.panelAction(driver, "close", "Employee Management", true, false);
		RC_Global.panelAction(driver, "expand", "Edit Employee", true, false);
		
		RC_Global.createNode(driver, "Verify Employee Assignment selected and obtained from the Download template are same");
		String currentAssignment = driver.findElement(By.xpath("//span[@ng-if='originalCustomerId === node.CustomerId']")).getText();
		if(currentAssignment.equalsIgnoreCase(nodeStructure+" (Currently Assigned)"))
			queryObjects.logStatus(driver, Status.PASS, "Verify Selected current assignment is the same as the one obtaines from the template", "Selected and obtained current assignment are the same", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Selected current assignment is the same as the one obtaines from the template", "Selected and obtained current assignment are not the same", null);
		
//		
		RC_Global.panelAction(driver, "close", "Edit Employee", true, false);
		RC_Global.logout(driver, true);
	}
}
