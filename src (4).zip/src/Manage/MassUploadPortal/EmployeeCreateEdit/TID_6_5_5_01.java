package Manage.MassUploadPortal.EmployeeCreateEdit;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.SpreadsheetVersion;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DataValidation;
import org.apache.poi.ss.usermodel.DataValidationConstraint;
import org.apache.poi.ss.usermodel.Name;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.AreaReference;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.CellRangeAddressList;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.LeaseWave.RC_LW_Global;
import tools.LeaseWave.RC_LW_Manage;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_5_5_01 {
	
	public void CreateNewAndEditExistingEmployees(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception,IOException
	{
//		String menu = "Manage";
//		String firstSubMenu = "Mass Upload Portal";
		String CustomerNumber = "LS007656"; 
		String selType = "Employee Upload"; 
		String Filename="EmployeeCreateEdit-"+CustomerNumber+".xlsx"; String curFilePath = "";
		String sptVal[] = null;	String retVal = "";String newFileName = ""; String curDir = "";
		String fileDownload="";String downFilePath = ""; String downDir = "";String uploadedTime = ""; 		
		String userName = "";String submitTime = ""; String defTimeZon = "";
		String RowValsN = ""; String RowValsU = ""; String rowData_old[] = null; String rowData_new[] = null;
    	String sptRows[] = null; String sptCell_old[] = null; String sptCell_new[] = null; 
		String colNames[] = null; String delUnitNos = null;
		String newColName = ""; String newCol = ""; int colNo = 0;String valDate = null;
		String ColGrey = "TotalView Person ID;Employee Type;User Name";
		String ColRed = "First Name;Last Name;Address Validation Override;Residential Address 1;Residential Address City ;Residential Address State;Residential Address Zip Code;Residential Address Country;Distribution Method;Enrolled in Fuel;Enrolled in Personal Use;Enrolled in Driver Ordering;Create a New User Login ID;Status";
		String ColBlue = "Residential Address 2;Residential Address County;Cell Phone;Work Phone;Extension;Home Phone;Email;Employee ID;Preferred Contact Method;Employee Data Field 1;Employee Data Field 2;Employee Data Field 3;Employee Assignment;Fuel Driver ID;Fuel PIN Pool;Selector Group";
		
		String ResultcolNames = "Results;Reason;TotalView Person ID;First Name;Last Name;Address Validation Override; Residential Address 1;Residential Address 2; Residential Address City; Residential Address State; Residential Address Zip Code; Residential Address County;Residential Address Country;Cell Phone;Work Phone;Extension;Home Phone;Email;Employee ID;Employee Type;Distribution Method;Preferred Contact Method;Employee Data Field 1;Employee Data Field 2;Employee Data Field 3;Employee Assignment+;Enrolled in Fuel;Fuel Driver ID;Fuel PIN Pool;Enrolled in Personal Use;Enrolled in Driver Ordering;Selector Group;Create a New User Login ID;User Name;Status";
		String colNamesCol = "TotalView Person ID;First Name;Last Name;Address Validation Override; Residential Address 1;Residential Address 2; Residential Address City; Residential Address State; Residential Address Zip Code; Residential Address County;Residential Address Country;Cell Phone;Work Phone;Extension;Home Phone;Email;Employee ID;Employee Type;Distribution Method;Preferred Contact Method;Employee Data Field 1;Employee Data Field 2;Employee Data Field 3;Employee Assignment+;Enrolled in Fuel;Fuel Driver ID;Fuel PIN Pool;Enrolled in Personal Use;Enrolled in Driver Ordering;Selector Group;Create a New User Login ID;User Name;Status";

		ArrayList<String> UnitNumList=new ArrayList<String>();
		String colName = ""; 
		
		defTimeZon = java.util.TimeZone.getDefault().getID();
		RC_Manage.deleteFile_Downloads(driver, "EmployeeCreateEdit");
		RC_Manage.deleteAllFolder_Files(driver);
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,"Manage","Mass Upload Portal","");
		RC_Global.waitElementVisible(driver, 30,"//h3[text()='Mass Uploads']", "Mass Upload Portal", true, true);
		RC_Global.enterCustomerNumber(driver,CustomerNumber, "", "", true);
		retVal = RC_Manage.fileDownload(driver, selType, Filename);
		Thread.sleep(2000);
		if (retVal.contains(";")) {
        	sptVal = retVal.split(";");
        	curDir= sptVal[0];
        	newFileName = sptVal[1];
        	curFilePath = curDir+"\\"+newFileName;
//		}
        	
        	List<Integer> NewRow=null;
        	List<Integer> NewRow2=new ArrayList<Integer>();
        	NewRow = RC_Manage.Get_insertRow_Excel(driver, curDir+"\\"+newFileName, "insert", 2, selType);
        	NewRow2.add(NewRow.get(0));
        	RowValsN = RC_Manage.updateAllColumns_Employee_PoolUpload(driver, curFilePath, NewRow2);
        	String Fname = "Test"+RandomStringUtils.randomAlphabetic(3).toLowerCase()+RandomStringUtils.randomNumeric(2);
        	String Lname = "Data"+RandomStringUtils.randomAlphanumeric(4);
        	String mail = RandomStringUtils.randomAlphabetic(7).toLowerCase()+"merchants.com";
        	RowValsN = RC_Manage.columnsValueEdit_Employee_Pool(driver, curFilePath, "TotalView Person ID;First Name;Last Name;Email;", ";"+Fname+";"+Lname+";"+mail+"", NewRow2);
        	NewRow2.remove(0); NewRow2.add(NewRow.get(1));
        	sptRows = RowValsN.split("~~");
        	colNames = sptRows[0].split(";");
        	rowData_old = sptRows[1].split("__");
        	rowData_new = sptRows[2].split("__");
        	
        	for (int i = 0; i < rowData_old.length; i++) {
        		sptCell_old = rowData_old[i].split(";");
        		if (delUnitNos=="") {
        			delUnitNos = sptCell_old[0];
				} else {
						delUnitNos = delUnitNos+";"+sptCell_old[0];
				}sptCell_old = null;       		
			}	        	
        	
        	userName = driver.findElement(By.xpath("//span[contains(@ng-show,'user.FullName') and @id='Span1']")).getText();
        	submitTime = RC_Manage.fileUpload(driver, curDir, curFilePath, selType, "", defTimeZon, userName, "");
        	
        	uploadedTime = RC_Manage.selectDownloadResults(driver, userName, submitTime, defTimeZon);//download file
        	if (defTimeZon.equalsIgnoreCase("CST") || defTimeZon.equalsIgnoreCase("America/Chicago")) {
        		valDate = RC_Manage.driverHistory_DateFormat(driver, queryObjects, uploadedTime, "No");
			} else {
				valDate = RC_Manage.driverHistory_DateFormat(driver, queryObjects, uploadedTime, "Yes");
			}
        	
        	fileDownload = RC_Manage.moveFileFromDownloads(driver, Filename, "DownloadedFiles", true);
            if (fileDownload.contains(";")) {
            	downDir = fileDownload.substring(0, fileDownload.indexOf(";"));
            	downFilePath = fileDownload.replace(";", "\\");
            	RC_Manage.validateResults_RowNumbers(driver, downFilePath, NewRow, "Error", "");
            	RC_Manage.deleteFolder(driver, downDir);	
            	RC_Global.panelAction(driver, "close", "Mass Upload Portal", false,true);
            }
            	
            	
        /*	UpdateRow = RC_Manage.Get_insertRow_Excel(driver, curFilePath, "");
    		    		
        	List<Integer> rowsChngN = new ArrayList<Integer>(NewRow);
        	RowValsN = RC_Manage.updateAllColumns_EmployeeUpload(driver, curFilePath, rowsChngN);
        	System.out.print(RowValsN);
        	sptRows = RowValsN.split("~~");
        	colNames = sptRows[0].split(";");
        	rowData_old = sptRows[1].split("__");
        	rowData_new = sptRows[2].split("__");
        	
        	for (int i = 0; i < rowData_new.length; i++) {
        		sptCell_new = rowData_new[i].split(";");
        		if (delUnitNos=="") {
        			delUnitNos = sptCell_new[0];
				} else {
						delUnitNos = delUnitNos+";"+sptCell_new[0];
				}sptCell_new = null;       		
			}
        	String Fname = "Test"+RandomStringUtils.randomNumeric(2);
        	String Lname = "Data"+RandomStringUtils.randomAlphanumeric(2);
        	String mail = RandomStringUtils.randomAlphabetic(3).toLowerCase()+"merchants.com";
        	List<Integer> rowsChngU = new ArrayList<Integer>(UpdateRow);        	
        	RowValsU = RC_Manage.columnsValueEdit_EmployeeUpload(driver, curFilePath, "TotalView Person ID;First Name;Last Name;Email;", ";"+Fname+";"+Lname+";"+mail+"", rowsChngU);
        	sptRows = RowValsU.split("~~");
        	colNames = sptRows[0].split(";");
        	rowData_old = sptRows[1].split("__");
        	rowData_new = sptRows[2].split("__");
        	
        	for (int i = 0; i < rowData_new.length; i++) {
        		sptCell_new = rowData_new[i].split(";");
        		if (delUnitNos=="") {
        			delUnitNos = sptCell_new[0];
				} else {
						delUnitNos = delUnitNos+";"+sptCell_new[0];
				}sptCell_new = null;       		
			}
        	
        	
        	
         	userName = driver.findElement(By.xpath("//span[contains(@ng-show,'user.FullName') and @id='Span1']")).getText();
    		submitTime = RC_Manage.fileUpload(driver, curDir, curFilePath, selType, "", defTimeZon, userName, "");
        	
        	RC_Manage.selectDownloadResults(driver, userName, submitTime, defTimeZon);//download file
        	
            	
            	
        	fileDownload = RC_Manage.moveFileFromDownloads(driver, Filename, "DownloadedFiles", true);
            if (fileDownload.contains(";")) {
            	downDir = fileDownload.substring(0, fileDownload.indexOf(";"));
            	downFilePath = fileDownload.replace(";", "\\");                       
            	RC_Manage.validateUploadChanges(driver, downFilePath,delUnitNos, "Success");
//            	RC_Manage.deleteFolder(driver, downDir);
         
            	RC_Global.panelAction(driver, "close", "Mass Upload Portal", false,true);
            	Thread.sleep(2000);
    		}
 */           
            
            for (int r = 0; r < rowData_old.length; r++) {
        		sptCell_old = rowData_old[r].split(";");
        		sptCell_new = rowData_new[r].split(";");
        		newColName = "";
        		RC_Manage.viewHistory_Employee(driver, queryObjects, CustomerNumber, sptCell_new[1], sptCell_new[2], userName, valDate);
        		RC_Global.createNode(driver, "Validate the updated columns in Total View - Employee History for the given First & Last Name -"+sptCell_new[1]+sptCell_new[2] );
        		queryObjects.logStatus(driver, Status.PASS, "Verified updated employee displays in History", "Successfully", null);
        		/*for (int c = 1; c < colNames.length; c++) {
        			newCol = "";
        			if (!("FleetNumber;FleetName;AccountNumber;AccountName;Sub-AccountNumber;Sub-AccountName".contains(StringUtils.deleteWhitespace(colNames[c])))) {
        				if (colNames[c].contains("-")) {
            				newColName = colNames[c].substring(0, colNames[c].indexOf("-"));
            				try {
            					colNo = Integer.parseInt(newColName);
            					newCol = "Client Data "+colNo;
							} catch (Exception e) {}
						}   else {
							newCol = colNames[c];
						}
        				RC_Manage.compareExpected_Actual(driver, sptCell_old[c], sptCell_new[c], newCol);
					}           			
                	
				}*/
        		RC_Global.panelAction(driver, "close", "Employee History", true, false);
        		sptCell_old = null;
        		sptCell_new = null;
			}
            
            RC_Global.logout(driver, false);
   		 RC_LW_Global.leaseWaveLogin(driver, false);
   		
   		 RC_Global.createNode(driver, "Verify the Newly Created and Updated employee");
   		driver.findElement(By.xpath("//a[contains(text(),'Fleet Management')]")).click();
		   	 RC_Global.waitElementVisible(driver, 50, "//span[text()='Fleet Management Menu']", "Fleet Management Menu",false, false);
        String home =  driver.findElement(By.xpath("//span[text()='Fleet Management Menu']")).getText();
        if(home.contains("FLEET MANAGEMENT MENU")) {
            BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Navigation to Fleet Management Menu", "Successfully", null);   
        }
        RC_Global.clickUsingXpath(driver,"//td[@accesskey='1' and text()='. Profiles']","Profiles",false, false);
        RC_Global.clickUsingXpath(driver,"//td[@accesskey='D']","Driver",false, false);
        RC_Global.clickUsingXpath(driver,"//tr[contains(@igurl,'DriverProfile')]/td[@accesskey='P']","Driver Profile",true, false);
		RC_Global.waitElementVisible(driver, 50, "//span[text()='Driver Profile List' and @id='ctl00_PageTitle']", "Asset List",true, true);
	    driver.findElement(By.xpath("//td[@lw_friendlyname='Account Number']//input")).sendKeys(CustomerNumber);
	    driver.findElement(By.xpath("//td[@lw_friendlyname='First Name']//input")).sendKeys(Fname);
	    driver.findElement(By.xpath("//td[@lw_friendlyname='Last Name']//input")).sendKeys(Lname);
		RC_Global.clickUsingXpath(driver,"//button[text()='Searc']","Search button",false, true);
	    RC_Global.clickUsingXpath(driver,"//button[text()='dit']","Edit button",false, true);
        RC_Global.waitElementVisible(driver, 50, "//span[text()='Driver Profile' and @id='ctl00_PageTitle']", "Driver Profile Page",false, false);
        RC_Global.clickUsingXpath(driver,"//li/a[text()='Driver Profile']","Driver Profile",false, true);
        Thread.sleep(2000);
        queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
   		}
   			
		}
   	}
		