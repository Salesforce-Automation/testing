package Manage.MassUploadPortal.EmployeeCreateEdit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_5_5_04 {
	public void EmployeeTemplateDownloadForLowerCustomerNodes(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String selType = "Employee Upload";String cusno= "LS007656";String Filename="";String downloadPath="";
		String sptVal[] = null;String curDir = "";String newFileName = "";String curFilePath = "";
		
		RC_Manage.deleteFile_Downloads(driver, "EmployeeCreateEdit");
		RC_Manage.deleteAllFolder_Files(driver);
		RC_Global.login(driver);
        RC_Global.navigateTo(driver, "Manage", "Mass Upload Portal", "");
        RC_Global.waitElementVisible(driver, 60, "//div//h3[text()='Mass Uploads']", "Mass Uploads",false,true);
		RC_Global.enterCustomerNumber(driver, cusno, "", "",true);
		WebElement custInputField = driver.findElement(By.xpath("//div[@ng-show='customerChosen']/input[@name='customerInput']"));
		
		Filename="EmployeeCreateEdit-"+custInputField.getAttribute("value")+".xlsx";
		
		downloadPath = RC_Manage.fileDownload(driver, selType, Filename);
		if (downloadPath.contains(";")) {
        	sptVal = downloadPath.split(";");
        	curDir= sptVal[0];
        	newFileName = sptVal[1];
        	curFilePath = curDir+"\\"+newFileName;	
		}
		RC_Global.clickUsingXpath(driver, "//div[@class='input-group'][1]/div/button", "Expand customer structure", false, false);
		RC_Global.clickUsingXpath(driver, "(//ul[@class='ng-scope'])[2]/li[4]/div/span", "Fleet Level", false, true);
		
		Filename="EmployeeCreateEdit-"+custInputField.getAttribute("value")+".xlsx";
		
		downloadPath = RC_Manage.fileDownload(driver, selType, Filename);
		if (downloadPath.contains(";")) {
        	sptVal = downloadPath.split(";");
        	curDir= sptVal[0];
        	newFileName = sptVal[1];
        	curFilePath = curDir+"\\"+newFileName;	
		}
		
		RC_Global.clickUsingXpath(driver, "//div[@class='input-group'][1]/div/button", "Expand customer structure", false, false);
		RC_Global.clickUsingXpath(driver, "(//ul[@class='ng-scope'])[2]/li[4]/i[1]", "Expand fleet level", false, false);
		RC_Global.clickUsingXpath(driver, "(//ul[@class='ng-scope'])[2]/li[4]/treeitem/ul/li[1]/div/span", "Account Level", false, true);
		Filename="EmployeeCreateEdit-"+custInputField.getAttribute("value")+".xlsx";
		
		downloadPath = RC_Manage.fileDownload(driver, selType, Filename);
		if (downloadPath.contains(";")) {
        	sptVal = downloadPath.split(";");
        	curDir= sptVal[0];
        	newFileName = sptVal[1];
        	curFilePath = curDir+"\\"+newFileName;	
		}
		
		RC_Global.clickUsingXpath(driver, "//div[@class='input-group'][1]/div/button", "Expand customer structure", false, false);
		RC_Global.clickUsingXpath(driver, "(//ul[@class='ng-scope'])[2]/li[4]/treeitem/ul/li[1]/i[1]", "Expand account level", false, false);
		RC_Global.clickUsingXpath(driver, "(//ul[@class='ng-scope'])[2]/li[4]/treeitem/ul/li[1]/treeitem/ul/li[1]/div/span", "Sub-account Level", false, true);
		Filename="EmployeeCreateEdit-"+custInputField.getAttribute("value")+".xlsx";
		
		downloadPath = RC_Manage.fileDownload(driver, selType, Filename);
		if (downloadPath.contains(";")) {
        	sptVal = downloadPath.split(";");
        	curDir= sptVal[0];
        	newFileName = sptVal[1];
        	curFilePath = curDir+"\\"+newFileName;	
		}
		Thread.sleep(2000);
		RC_Manage.deleteAllFolder_Files(driver);	
			queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
		
	}
}
