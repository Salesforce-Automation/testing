package Manage.MassUploadPortal.ClientDataAndCVN;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_5_2_04 {

	public void ClientFieldTypeAndFormatMismatchOnClientDataAndCVN_Add_UpdateTemplate(WebDriver driver, BFrameworkQueryObjects queryObjects)throws Exception {
		
		String retVal = ""; String ClientUnitNos= ""; String curFilePath = ""; String UnitNums = ""; String cusno= "LS010140";
		String delUnitNos= ""; String UpdateUnitNos= ""; String curDir = ""; String submitTime = ""; String userName = "";
		String selType = "Client Data and CVN Upload"; String fileDownload=""; String downFilePath = "";String UpdateVals= "";
		String sptVal[] = null;String newFileName = "";
		String Filename="ClientDataAndCVNUpload-"+cusno+".xlsx"; String defTimeZon = ""; String downDir = "";
		
		String sptRows[] = null; String sptRows2[] = null; String rowData_old[] = null; 
		String colNames[] = null; String rowData_new[] = null; String rowData2_old[] = null;
		String colNames2[] = null; String rowData2_new[] = null; String sptCell_old[] = null; 
		String sptCell2_old[] = null; String sptCell_new[] = null; String sptCell2_new[] = null;
		String rowData3_new[] = null; String rowData3_old[] = null; String colNames3[] = null;
		String sptRows3[] = null; String sptCell3_old[] = null; String sptCell3_new[] = null;
		
		String retRowVal = ""; String retRowVal2 = ""; String retRowVal3 = "";
		
		defTimeZon = java.util.TimeZone.getDefault().getID();
		
		RC_Manage.deleteFile_Downloads(driver, "ClientDataAndCVNUpload");
		RC_Manage.deleteAllFolder_Files(driver);
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Client Data Setup");
		RC_Global.enterCustomerNumber(driver, cusno, "", "",true);
		RC_Global.waitElementVisible(driver, 90, "(//table//tbody//tr)[1]", "Grid Row", false,true);
		RC_Global.clickButton(driver, "Add New Client Data",true,true);
		RC_Global.waitElementVisible(driver, 90, "//span[text()='Client Data Values']", "Client Data Values",false,true);
		WebElement element = driver.findElement(By.xpath("//input[@placeholder='Name']"));
		RC_Global.enterInput(driver, "Text", element  , false,true);
		RC_Global.clickUsingXpath(driver, "//input[contains(@ng-model,'IsActive')]", "InActive", false,true);
	    RC_Global.clickButton(driver, "Save ",true,true);
	    RC_Global.waitElementVisible(driver, 90, "(//span[text()='Client Data Setup'])[2]", "Client Data Setup",false,true);
	    RC_Global.waitElementVisible(driver, 90, "(//table//tbody//tr)[1]", "Grid Row", false,true);
		
	    RC_Global.clickButton(driver, "Add New Client Data",true,true);
	    RC_Global.waitElementVisible(driver, 90, "//span[text()='Client Data Values']", "Client Data Values",false,true);
	    WebElement element2 = driver.findElement(By.xpath("//input[@placeholder='Name']"));
		RC_Global.enterInput(driver, "Picklist", element2  , false,true);
		RC_Global.clickUsingXpath(driver, "//div[text()='Picklist ']//child::input[@type='radio']", "Picklist Data types", false,true);
		WebElement addPicklist = driver.findElement(By.xpath("//input[@ng-model='addOptionText']"));
        RC_Global.enterInput(driver, "Sample_Picklist", addPicklist  , false,true);
        RC_Global.clickButton(driver, "Add",true,true);
        RC_Global.enterInput(driver, "Test_Picklist", addPicklist  , false,true);
        RC_Global.clickButton(driver, "Add",true,true);
        RC_Global.enterInput(driver, "Add_Picklist", addPicklist  , false,true);
        RC_Global.clickButton(driver, "Add",true,true);
		RC_Global.clickUsingXpath(driver, "//input[contains(@ng-model,'IsActive')]", "InActive", false,true);
		RC_Global.clickButton(driver, "Save ",true,true);
		RC_Global.waitElementVisible(driver, 90, "(//span[text()='Client Data Setup'])[2]", "Client Data Setup",false,true);
		RC_Global.waitElementVisible(driver, 90, "(//table//tbody//tr)[1]", "Grid Row", false,true);
		
		RC_Global.clickButton(driver, "Add New Client Data",true,true);
		RC_Global.waitElementVisible(driver, 90, "//span[text()='Client Data Values']", "Client Data Values",false,true);
		WebElement element3 = driver.findElement(By.xpath("//input[@placeholder='Name']"));
	    RC_Global.enterInput(driver, "Decimal", element3  , false,true);
	    RC_Global.clickUsingXpath(driver, "//div[text()='Decimal ']//child::input[@type='radio']", "Decimal Data types", false,true);
		RC_Global.clickUsingXpath(driver, "//input[contains(@ng-model,'IsActive')]", "InActive", false,true);
		RC_Global.clickButton(driver, "Save ",true,true);
		RC_Global.waitElementVisible(driver, 90, "(//span[text()='Client Data Setup'])[2]", "Client Data Setup",false,true);
		RC_Global.waitElementVisible(driver, 90, "(//table//tbody//tr)[1]", "Grid Row", false,true);
		
		RC_Global.clickButton(driver, "Add New Client Data",true,true);
		RC_Global.waitElementVisible(driver, 90, "//span[text()='Client Data Values']", "Client Data Values",false,true);
		WebElement element4 = driver.findElement(By.xpath("//input[@placeholder='Name']"));
	    RC_Global.enterInput(driver, "Integer", element4  , false,true);
	    RC_Global.clickUsingXpath(driver, "//div[text()='Integer ']//child::input[@type='radio']", "Integer Data types", false,true);
		RC_Global.clickUsingXpath(driver, "//input[contains(@ng-model,'IsActive')]", "InActive", false,true);
		RC_Global.clickButton(driver, "Save ",true,true);
		RC_Global.waitElementVisible(driver, 90, "(//span[text()='Client Data Setup'])[2]", "Client Data Setup",false,true);
		RC_Global.waitElementVisible(driver, 90, "(//table//tbody//tr)[1]", "Grid Row", false,true);
		
		RC_Global.clickButton(driver, "Add New Client Data",true,true);
		RC_Global.waitElementVisible(driver, 90, "//span[text()='Client Data Values']", "Client Data Values",false,true);
		WebElement element5 = driver.findElement(By.xpath("//input[@placeholder='Name']"));
	    RC_Global.enterInput(driver, "Currency", element5  , false,true);
	    RC_Global.clickUsingXpath(driver, "//div[text()='Currency ']//child::input[@type='radio']", "Currency Data types", false,true);
		RC_Global.clickUsingXpath(driver, "//input[contains(@ng-model,'IsActive')]", "InActive", false,true);
		RC_Global.clickButton(driver, "Save ",true,true);
		RC_Global.waitElementVisible(driver, 90, "(//span[text()='Client Data Setup'])[2]", "Client Data Setup",false,true);
		RC_Global.waitElementVisible(driver, 90, "(//table//tbody//tr)[1]", "Grid Row", false,true);
		
		RC_Global.clickButton(driver, "Add New Client Data",true,true);
		RC_Global.waitElementVisible(driver, 90, "//span[text()='Client Data Values']", "Client Data Values",false,true);
		WebElement element6 = driver.findElement(By.xpath("//input[@placeholder='Name']"));
	    RC_Global.enterInput(driver, "Date", element6  , false,true);
	    RC_Global.clickUsingXpath(driver, "//div[text()='Date ']//child::input[@type='radio']", "Date Data types", false,true);
		RC_Global.clickUsingXpath(driver, "//input[contains(@ng-model,'IsActive')]", "InActive", false,true);
		RC_Global.clickButton(driver, "Save ",true,true);
		RC_Global.waitElementVisible(driver, 90, "(//span[text()='Client Data Setup'])[2]", "Client Data Setup",false,true);
		RC_Global.waitElementVisible(driver, 90, "(//table//tbody//tr)[1]", "Grid Row", false,true);
		
		RC_Global.clickButton(driver, "Add New Client Data",true,true);
		RC_Global.waitElementVisible(driver, 90, "//span[text()='Client Data Values']", "Client Data Values",false,true);
		WebElement element7 = driver.findElement(By.xpath("//input[@placeholder='Name']"));
	    RC_Global.enterInput(driver, "Date/time", element7, false,true);
	    RC_Global.clickUsingXpath(driver, "//div[text()='Date/time ']//child::input[@type='radio']", "Date/time Data types", false,true);
		RC_Global.clickUsingXpath(driver, "//input[contains(@ng-model,'IsActive')]", "InActive", false,true);
		RC_Global.clickButton(driver, "Save ",true,true);
		RC_Global.waitElementVisible(driver, 90, "(//span[text()='Client Data Setup'])[2]", "Client Data Setup",false,true);
		RC_Global.waitElementVisible(driver, 90, "(//table//tbody//tr)[1]", "Grid Row", false,true);
		
		RC_Global.clickButton(driver, "Add New Client Data",true,true);
		RC_Global.waitElementVisible(driver, 90, "//span[text()='Client Data Values']", "Client Data Values",false,true);
		WebElement element8 = driver.findElement(By.xpath("//input[@placeholder='Name']"));
	    RC_Global.enterInput(driver, "Time", element8, false,true);
	    RC_Global.clickUsingXpath(driver, "//div[text()='Time ']//child::input[@type='radio']", "Time Data types", false,true);
		RC_Global.clickUsingXpath(driver, "//input[contains(@ng-model,'IsActive')]", "InActive", false,true);
		RC_Global.clickButton(driver, "Save ",true,true);
		RC_Global.waitElementVisible(driver, 90, "(//span[text()='Client Data Setup'])[2]", "Client Data Setup",false,true);
		RC_Global.waitElementVisible(driver, 90, "(//table//tbody//tr)[1]", "Grid Row", false,true);
		
		RC_Global.clickButton(driver, "Add New Client Data",true,true);
		RC_Global.waitElementVisible(driver, 90, "//span[text()='Client Data Values']", "Client Data Values",false,true);
		WebElement element9 = driver.findElement(By.xpath("//input[@placeholder='Name']"));
	    RC_Global.enterInput(driver, "Boolean", element9, false,true);
	    RC_Global.clickUsingXpath(driver, "//div[text()='Boolean ']//child::input[@type='radio']", "Boolean Data types", false,true);
		RC_Global.clickUsingXpath(driver, "//input[contains(@ng-model,'IsActive')]", "InActive", false,true);
		RC_Global.clickButton(driver, "Save ",true,true);
		RC_Global.waitElementVisible(driver, 90, "(//span[text()='Client Data Setup'])[2]", "Client Data Setup",false,true);
		RC_Global.waitElementVisible(driver, 90, "(//table//tbody//tr)[1]", "Grid Row", false,true);
		RC_Global.panelAction(driver, "close", "Client Data Setup", false,true);
		
		RC_Global.navigateTo(driver, "Manage", "Mass Upload Portal", "");
		RC_Global.waitElementVisible(driver, 90, "//div//h3[text()='Mass Uploads']", "Mass Uploads",false,true);
		RC_Global.enterCustomerNumber(driver, cusno, "", "",true);
		retVal = RC_Manage.fileDownload(driver, selType, Filename);
		 if (retVal.contains(";")) {
	        	sptVal = retVal.split(";");
	        	curDir= sptVal[0];
	        	newFileName = sptVal[1];
	        	curFilePath = curDir+"\\"+newFileName;
		 }
		RC_Manage.fillBlankCellValues(driver, curFilePath, "red");
		retRowVal = RC_Manage.modifyCells_MandatoryColumns(driver, curFilePath, "blue", 2, "", "Update");
		sptRows = retRowVal.split("~~");
    	colNames = sptRows[0].split(";");
    	rowData_old = sptRows[1].split("__");
    	rowData_new = sptRows[2].split("__");
    	
    	for (int i = 0; i < rowData_old.length; i++) {
    		sptCell_old = rowData_old[i].split(";");
    		if (delUnitNos=="") {
    			delUnitNos = sptCell_old[0];
			} else {
				delUnitNos = delUnitNos+";"+sptCell_old[0];
			}sptCell_old = null;       		
		}
    	retRowVal2 = RC_Manage.modifyCells_ColumnName(driver, curFilePath, "Text", 2, delUnitNos, "Update");
		sptRows2 = retRowVal2.split("~~");
    	colNames2 = sptRows2[0].split(";");
    	rowData2_old = sptRows2[1].split("__");
    	rowData2_new = sptRows2[2].split("__");
    	
    	for (int j = 0; j < rowData2_old.length; j++) {
    		
    		sptCell2_old = rowData2_old[j].split(";");
    		if (UpdateUnitNos=="") {
    			UpdateUnitNos = sptCell2_old[0];
			} else {
				UpdateUnitNos = UpdateUnitNos+";"+sptCell2_old[0];
			}sptCell2_old = null;
		}
    	
    	retRowVal3 = RC_Manage.modifyCells_ColumnName(driver, curFilePath, "Currency", 2, delUnitNos+";"+UpdateUnitNos, "Update");
		sptRows3 = retRowVal3.split("~~");
    	colNames3 = sptRows3[0].split(";");
    	rowData3_old = sptRows3[1].split("__");
    	rowData3_new = sptRows3[2].split("__");
    	
    	for (int j = 0; j < rowData2_old.length; j++) {
    		
    		sptCell3_old = rowData3_old[j].split(";");
    		if (ClientUnitNos=="") {
    			ClientUnitNos = sptCell3_old[0];
			} else {
				ClientUnitNos = ClientUnitNos+";"+sptCell3_old[0];
			}sptCell3_old = null;
		}
    	
    	
    	userName = driver.findElement(By.xpath(" //span[contains(@ng-show,'user.FullName') and @id='Span1']")).getText();
		submitTime = RC_Manage.fileUpload(driver, curDir, curFilePath, selType, "", defTimeZon, userName, "");
    	
    	RC_Manage.selectDownloadResults(driver, userName, submitTime, defTimeZon);//download file
    	
    	fileDownload = RC_Manage.moveFileFromDownloads(driver, Filename, "DownloadedFiles", true);
        if (fileDownload.contains(";")) {
        	downDir = fileDownload.substring(0, fileDownload.indexOf(";"));
        	downFilePath = fileDownload.replace(";", "\\");
        	RC_Manage.validateUploadChanges(driver, downFilePath, delUnitNos, "Error");        	
        	RC_Manage.validateUploadChanges(driver, downFilePath, UpdateUnitNos, "Success");
        	RC_Manage.validateUploadChanges(driver, downFilePath, ClientUnitNos, "Error");
        	RC_Manage.deleteFolder(driver, downDir);
        	RC_Global.panelAction(driver, "close", "Mass Upload Portal", false,true);
		}
        RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
