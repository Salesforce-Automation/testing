package Manage.MassUploadPortal.ClientDataAndCVN;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_5_2_02 {
	public static void AddressValidationNotCompleted_Add_UpdateTemplateAndIndividualModuleHistory_CVN(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		String newFileName = ""; String curDir = "";
		String curFilePath = ""; String sptVal[] = null;
		String cusNo = "LS008742";
		String fileName = "ClientDataAndCVNUpload-"+cusNo+".xlsx";
		String userName = ""; String defTimeZon = ""; String submitTime = "";
		String fileDownload = ""; String downDir = ""; String downFilePath= "";
		
		defTimeZon = java.util.TimeZone.getDefault().getID();
		RC_Manage.deleteFile_Downloads(driver, "ClientDataAndCVNUpload");
		RC_Manage.deleteAllFolder_Files(driver);
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Driver Data Change");
		RC_Global.enterCustomerNumber(driver, cusNo, "", "", true);
		
		RC_Global.clickButton(driver, "Search", true,true);
		Thread.sleep(1000);
		RC_Global.waitElementVisible(driver, 30, "//table/tbody/tr/td[5]", "Grid Load completion", true,true);
		Thread.sleep(2000);
		RC_Manage.driverNameSelection(driver, "Yes", true);
		String driverName = RC_Manage.drivername;
		String unitNumber = driver.findElement(By.xpath("(//table/tbody/tr[td[text()=' "+driverName+" ']])[1]/td[3]")).getText();
		
		RC_Global.waitUntilPanelVisibility(driver, "Driver Details", "TV", true,true);
		RC_Global.panelAction(driver, "close", "Driver Data Change", true,true);
		RC_Global.panelAction(driver, "expand", "Driver Details", true,true);
		
		WebElement eleAddress1 = driver.findElement(By.xpath("//div[label[text()='Address 1 *']]/div//input"));
//		WebElement textInputBox = driver.findElement(By.xpath("//div[label[text()='Text']]/div//input"));
//		WebElement eleDate = driver.findElement(By.xpath("(//div[label[text()='Date']]/div//input)[3]"));
//		WebElement dateTime = driver.findElement(By.xpath("//div[label[text()='date/time']]/div//input"));
		
		String oldAddressVal = eleAddress1.getAttribute("value");
		String address1 = "123 S 4th St "+RandomStringUtils.randomNumeric(4);
		RC_Global.enterInput(driver, address1, eleAddress1, true,true);
        
		
		RC_Global.clickUsingXpath(driver, "(//button[text()=' Save '])[1]", "Save Button", true,true);
		Thread.sleep(6000);
		
		if(driver.findElements(By.xpath("//span[text()=' address entered.']")).size()>0) {
			driver.findElement(By.xpath("//button[text()='Save As Entered']")).click();
			Thread.sleep(5000);
		}
		Thread.sleep(2000);
		
		RC_Global.panelAction(driver, "close", "Driver Details", true,true);
		
		RC_Global.navigateTo(driver, "Manage", "Mass Upload Portal", "");
		Thread.sleep(3000);
		RC_Global.enterCustomerNumber(driver, cusNo, "", "", true);
		
		String downloadPath = RC_Manage.fileDownload(driver, "Client Data and CVN Upload", fileName);
		Thread.sleep(3000);
		if (downloadPath.contains(";")) {
        	sptVal = downloadPath.split(";");
        	curDir= sptVal[0];
        	newFileName = sptVal[1];
        	curFilePath = curDir+"\\"+newFileName;	
		}
		userName = driver.findElement(By.xpath("//span[contains(@ng-show,'user.FullName') and @id='Span1']")).getText();
//		RC_Manage.fileUpload(driver, curDir, curFilePath, "Client Data and CVN Upload", "", "", userName);
		
		
//		RC_Global.panelAction(driver, "close", "Driver Details", true);
		
		
		
		submitTime = RC_Manage.fileUpload(driver, curDir, curFilePath, "Client Data and CVN Upload", "", defTimeZon, userName, "");    	
    	RC_Manage.selectDownloadResults(driver, userName, submitTime, defTimeZon);//download file
    	
    	fileDownload = RC_Manage.moveFileFromDownloads(driver, fileName, "DownloadedFiles", true);
        if (fileDownload.contains(";")) {
        	downDir = fileDownload.substring(0, fileDownload.indexOf(";"));
        	downFilePath = fileDownload.replace(";", "\\");
        	RC_Manage.validateUploadChanges(driver, downFilePath, unitNumber, "No changes");
        	RC_Manage.deleteFolder(driver, downDir);
        }
		
        RC_Global.panelAction(driver, "close", "Mass Upload Portal", true,true);
		
		RC_Global.navigateTo(driver, "Manage", "Administration", "Driver Data Change");
		
		WebElement unitNumberSearchBox = driver.findElement(By.xpath("//div[label[text()='Unit Number']]/input"));
		RC_Global.enterInput(driver, unitNumber, unitNumberSearchBox, true,true);
		RC_Global.clickButton(driver, "Search", true,true);
		RC_Global.waitUntilPanelVisibility(driver, "Driver Details", "TV", true,true);
		
		RC_Global.clickButton(driver, "History", true,true);
		RC_Global.waitUntilPanelVisibility(driver, "Driver Change - History", "TV", true,true);
		RC_Global.panelAction(driver, "close", "Driver Details", true,true);
		RC_Global.panelAction(driver, "expand", "Driver Change - History", true,true);
		
		RC_Global.verifyColumnNames(driver, "Changes;Date;Driver or Pool Name;CRM Service Request # (if any);Modified By;Change Details", true);
//		clickUsingXpath(driver, "(//tr[1]/td[1])[1]", "Latest Change in History", false);
//		if(driver.findElement(By.xpath("(//tr[2]/td[2]/table/tbody/tr[1]/td[2])[1]")).getText().equalsIgnoreCase("Vehicle Location Street Line 1"))
//			queryObjects.logStatus(driver, Status.PASS, "Verify latest change update", "Verified successfully", null);
//		else
//			queryObjects.logStatus(driver, Status.FAIL, "Verify latest change update", "Expected Change is not displayed", null);
//		
//		if(driver.findElement(By.xpath("(//tr[2]/td[2]/table/tbody/tr[1]/td[4])[1]")).getText().equalsIgnoreCase(address1))
//			queryObjects.logStatus(driver, Status.PASS, "Verify latest change update", "Verified successfully", null);
//		else
//			queryObjects.logStatus(driver, Status.FAIL, "Verify latest change update", "Expected Change is not displayed", null);
//		
		RC_Global.waitElementVisible(driver, 30, "(//tr[1]/td[1])[1]", "Grid Element", true,true);
		
		RC_Global.clickUsingXpath(driver, "(//td/a[text()='View'])[1]", "View link", true,true);
		Thread.sleep(1000);

		if(driver.findElement(By.xpath("(//div[div[text()='Address 1:']]/div[2])[1]")).getText().toLowerCase().equalsIgnoreCase(oldAddressVal.toLowerCase())&&driver.findElement(By.xpath("(//div[div[text()='Address 1:']]/div[2])[2]")).getText().toLowerCase().equalsIgnoreCase(address1.toLowerCase()))
			queryObjects.logStatus(driver, Status.PASS, "Validate Address change in Driver History panel", "Address changed as expected", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Validate Address change in Driver History panel", "Address not changed as expected", null);
		
			//(//div[div[text()='Address 1:']]/div[2])[1]
//		RC_Manage.compareExpected_Actual(driver, oldAddressVal, address1, "address1");
		RC_Global.logout(driver, false);
	}
}