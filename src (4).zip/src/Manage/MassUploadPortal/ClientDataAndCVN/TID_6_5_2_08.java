package Manage.MassUploadPortal.ClientDataAndCVN;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import MF.Source.Cred;
import tools.LeaseWave.RC_LW_Global;
import tools.LeaseWave.RC_LW_Manage;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_5_2_08 {
	public void DownloadandUploadCVNTemplatewithMultipleValidations_Driver_ClientDataFields_Modify(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String rowVals = ""; String UnitNos= ""; String DpRowVals = ""; String dPUnitNos= "";		
		String retVal = ""; String fileDownload=""; String newFileName = ""; String curDir = "";
		String curFilePath = ""; String downDir = ""; String downFilePath = ""; String sptVal[] = null;		
		String uploadedTime = "";
		
		String sptRows[] = null; String sptRows2[] = null; String rowData_old[] = null; 
		String colNames[] = null; String rowData2_old[] = null; String colNames2[] = null;
		String rowData_new[] = null; String rowData2_new[] = null; String sptCell_old[] = null; 
		String sptCell2_old[] = null; String sptCell_new[] = null; String sptCell2_new[] = null;
		String newColName = ""; int colNo = 0; String newCol = "";
		String leaseStatus = ""; String submitTime = ""; String defTimeZon = ""; String userName = "";
		String valDate = null; boolean isLeasePg = false; boolean isAssetPg = false;
		 
		String cusno= "LS010143"; String selType = "Client Data and CVN Upload"; String Filename="ClientDataAndCVNUpload-"+cusno+".xlsx"; 
		defTimeZon = java.util.TimeZone.getDefault().getID();
		try {
			RC_Manage.deleteFile_Downloads(driver, "ClientDataAndCVNUpload");
			RC_Manage.deleteAllFolder_Files(driver);
			RC_Global.login(driver);
			RC_Global.navigateTo(driver,"Manage","Mass Upload Portal","");
	        RC_Global.enterCustomerNumber(driver, "LS010143", "", "", false);        
	        retVal = RC_Manage.fileDownload(driver, selType, Filename);
	        if (retVal.contains(";")) {
	        	sptVal = retVal.split(";");
	        	curDir= sptVal[0];
	        	newFileName = sptVal[1];
	        	curFilePath = curDir+"\\"+newFileName;
	        	
	        	//Updated Selected Rows
	        	rowVals = RC_Manage.updateSelectedRows(driver, curFilePath, Filename, 2);
	        	sptRows = rowVals.split("~~");
	        	colNames = sptRows[0].split(";");
	        	rowData_old = sptRows[1].split("__");
	        	rowData_new = sptRows[2].split("__");
	        	
	        	for (int i = 0; i < rowData_old.length; i++) {
	        		sptCell_old = rowData_old[i].split(";");
	        		if (UnitNos=="") {
	        			UnitNos = sptCell_old[0];
					} else {
						UnitNos = UnitNos+";"+sptCell_old[0];
					}sptCell_old = null;       		
				}
	        	
	        	//Delete the Driver/Pool name for few columns
	        	DpRowVals = RC_Manage.modifyCells_ColumnName(driver, curFilePath, "Driver/Pool Name", 2, UnitNos, "Delete");
	        	sptRows2 = DpRowVals.split("~~");
	        	colNames2 = sptRows2[0].split(";");
	        	rowData2_old = sptRows2[1].split("__");
	        	rowData2_new = sptRows2[2].split("__");
	        	
	        	for (int j = 0; j < rowData2_old.length; j++) {
	        		
	        		sptCell2_old = rowData2_old[j].split(";");
	        		if (dPUnitNos=="") {
	        			dPUnitNos = sptCell2_old[0];
					} else {
						dPUnitNos = dPUnitNos+";"+sptCell2_old[0];
					}sptCell2_old = null;
				}
	        	
	        	userName = driver.findElement(By.xpath("//span[contains(@ng-show,'user.FullName') and @id='Span1']")).getText();
	        	submitTime = RC_Manage.fileUpload(driver, curDir, curFilePath, selType, "", defTimeZon, userName, "");
	        	
	        	uploadedTime = RC_Manage.selectDownloadResults(driver, userName, submitTime, defTimeZon);//download file
	        	if (defTimeZon.equalsIgnoreCase("CST") || defTimeZon.equalsIgnoreCase("America/Chicago")) {
	        		valDate = RC_Manage.driverHistory_DateFormat(driver, queryObjects, uploadedTime, "No");
				} else {
					valDate = RC_Manage.driverHistory_DateFormat(driver, queryObjects, uploadedTime, "Yes");
				}
	        	fileDownload = RC_Manage.moveFileFromDownloads(driver, Filename, "DownloadedFiles", true);
	            if (fileDownload.contains(";")) {
	            	downDir = fileDownload.substring(0, fileDownload.indexOf(";"));
	            	downFilePath = fileDownload.replace(";", "\\");
	            	RC_Manage.validateUploadChanges(driver, downFilePath, dPUnitNos, "No changes");
	            	RC_Manage.validateUploadChanges(driver, downFilePath, UnitNos, "Success");
	            	RC_Manage.deleteFolder(driver, downDir);
	            	//TV Application validate
	            	RC_Global.panelAction(driver, "close", "Mass Upload Portal", false,true); 
	            	
	            	//Totalview - //Update Client Data fields Validation
	            	for (int r = 0; r < rowData_old.length; r++) {
	            		sptCell_old = rowData_old[r].split(";");
	            		sptCell_new = rowData_new[r].split(";");
	            		newColName = "";
	            		RC_Manage.viewHistory_DriverChange(driver, queryObjects, cusno, sptCell_old[0], userName, valDate);
	            		RC_Global.createNode(driver, "Validate the updated columns in Total View - Driver History for the given Unit Number -"+sptCell_old[0]);
	            		for (int c = 1; c < colNames.length; c++) {
	            			newCol = "";
	            			if (!("FleetNumber;FleetName;AccountNumber;AccountName;Sub-AccountNumber;Sub-AccountName".contains(StringUtils.deleteWhitespace(colNames[c])))) {
	            				if (colNames[c].contains("-")) {
		            				newColName = colNames[c].substring(0, colNames[c].indexOf("-"));
		            				try {
		            					colNo = Integer.parseInt(newColName);
		            					newCol = "Client Data "+colNo;
									} catch (Exception e) {}
								}   else {
									newCol = colNames[c];
								}
	            				RC_Manage.compareExpected_Actual(driver, sptCell_old[c], sptCell_new[c], newCol);
							}           			
	                    	
	    				}
	            		driver.findElement(By.xpath("//h5[span[contains(text(),'Driver Change')]]/i[@ng-click='closePanel()']")).click();
	            		sptCell_old = null;
	            		sptCell_new = null;
					}
	            	
	            	//Totalview - //Deleted Driver/Pool name cells Validation
	            	for (int r1 = 0; r1 < rowData2_old.length; r1++) {
	            		sptCell2_old = rowData2_old[r1].split(";");
	            		sptCell2_new = rowData2_new[r1].split(";");
	            		newColName = "";
	            		for (int c1 = 1; c1 < colNames2.length; c1++) {
	            			newCol = "";
	            			if (colNames2[c1].contains("-")) {
	            				newColName = colNames2[c1].substring(0, colNames2[c1].indexOf("-"));
	            				try {
	            					colNo = Integer.parseInt(newColName);
	            					newCol = "Client Data "+colNo;
								} catch (Exception e) {}
							}  else {
								newCol = colNames2[c1];
							}
	            			RC_Manage.viewHistory_DriverChange(driver, queryObjects, cusno, sptCell2_old[0], userName, valDate);
	                    	if (driver.findElements(By.xpath("//div[contains(@class,'ng-hide')]//h4[text()='Old ']")).size()>0) {
								BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Check the Unit Number with Driver /Pool values deleted changes in the Driver History", "Changes are not reflected in the application when Driver/Pool data is deleted", null);
							} else {
								BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Check the Unit Number with Driver /Pool values deleted changes in the Driver History", "Changes are reflected in the application", null);
							}
	                    	driver.findElement(By.xpath("//h5[span[contains(text(),'Driver Change')]]/i[@ng-click='closePanel()']")).click();
	    				}
	            		sptCell2_old = null;
	            		sptCell2_new = null;
					}
	            	
	            	//LeaseWave - //Updated Client Data and Driver field values Mandatory cells Validation
	            	RC_LW_Global.leaseWaveLogin(driver,true);
	            	leaseStatus = "Commenced"; boolean isAvailable = false;
	            	
	            	for (int r = 0; r < rowData_old.length; r++) {
	            			sptCell_old = rowData_old[r].split(";");
	                		sptCell_new = rowData_new[r].split(";");
	                		newColName = "0"; colNo = 0;
	                		for (int c = 1; c < colNames.length; c++) {
	                			newCol = "";
	                			if (!("Fleet Number;Fleet Name;Account Number;Account Name;Sub-Account Number;Sub-Account Name".contains(colNames[c]))) {
		                			if (colNames[c].contains("-")) {
		                				newColName = colNames[c].substring(0, colNames[c].indexOf("-"));
		                				try {
		                					colNo = Integer.parseInt(newColName);
		                					newCol = "Data Field"+colNo;
		    							} catch (Exception e) {}
									}  else {
										newCol = colNames[c];
									}
		                			if (!newCol.contains("Data Field")) {//Navigate to Lease Profile to validate Driver Details
		                				if (c==1) {
		                					RC_LW_Manage.navigateLeaseList_Leasewave(driver, false);
											RC_LW_Manage.unitNoSearchLeaseProfile_Leasewave(driver, sptCell_old[0], leaseStatus, false);
										}
		                				if (driver.findElements(By.xpath("//span[text()='Lease Profile']")).size()==0 && driver.findElements(By.xpath("//td[contains(@id,'ListxgrdList')]//tbody/tr")).size()==0) {
		                					queryObjects.logStatus(driver, Status.WARNING, "No data displayed for the searched Unit Number - "+sptCell_old[0]+" in the Lease Profile page", "", null);
										} else {
											isAvailable = true;
											if (newCol.equalsIgnoreCase("cvn") || newCol.equalsIgnoreCase("customer vehicle number")) {
			                					RC_LW_Manage.validateDriverDetails_Leasewave(driver, newCol, sptCell_new[c]);
			                				} else {
			                					RC_LW_Manage.validateDriverDetails_Leasewave(driver, newCol, sptCell_old[c]);
											}
										}
		                				
		                				
									} else {
										if (colNo==1) {
											if (isAvailable) {
					                			driver.findElement(By.xpath("(//button[text()='lose'])")).click();
						            			RC_Global.waitElementVisible(driver, 50, "//span[text()='Lease Entry Home']", "Lease Entry Home",false,true);
						            			driver.findElement(By.xpath("//button[text()='cel']")).click();
						            			try {
						                            Thread.sleep(1000);
						                            driver.switchTo().alert().accept();
						                            Thread.sleep(1000);
						                          }catch(Exception e){
						                          }
											}
											RC_LW_Manage.navigateAssetList_Leasewave(driver, false);//Navigate to Asset Profile to validate Client Data fields
											RC_LW_Manage.unitNoSearchAssetList_Leasewave(driver, sptCell_old[0], false);
											isAvailable = true;
										}
										if (colNo<=25) {
											RC_LW_Manage.validateClientDatas_Leasewave(driver, newCol, sptCell_new[c], false);
										}
									}
	                			}
	                			if (colNo>=25) {
	                				break;
	                			}
	        				}
	                			colNo=1;
		                		sptCell_old = null;
		                		sptCell_new = null;
		                		driver.findElement(By.xpath("(//button[text()='lose'])[2]")).click();
		            			RC_Global.waitElementVisible(driver, 50, "//span[text()='Asset Profile Home']", "Asset Profile Home",false,true);
		            			driver.findElement(By.xpath("//button[text()='lose']")).click();
		                		

					}
	            	
	            	//LeaseWave - //Deleted Driver/PoolName cells Validation
	            	leaseStatus = "Commenced"; boolean isLists = false;
	            	RC_LW_Manage.navigateLeaseList_Leasewave(driver, false);
            		for (int r1 = 0; r1 < rowData2_old.length; r1++) {
            			sptCell2_old = rowData2_old[r1].split(";");
                		sptCell2_new = rowData2_new[r1].split(";");
                		colNo = 0;
            			driver.findElement(By.xpath("//td//input[contains(@name,'UnitNumber')]")).clear();
                        driver.findElement(By.xpath("//td//input[contains(@name,'UnitNumber')]")).sendKeys(sptCell2_old[0]);
                        try {
                        	driver.findElement(By.xpath("(//td//input[contains(@name,'ContractNumber')])[2]")).sendKeys(Keys.TAB);
						} catch (Exception e) {}                        
                        RC_Global.clickUsingXpath(driver,"//button[text()='Searc']","Search button",false,true);
            			Thread.sleep(2000);
                		newColName = "";
                		for (int c1 = 1; c1 < colNames2.length-1; c1++) {
                			newCol = "";
                			if (colNames2[c1].contains("-")) {
                				newColName = colNames2[c1].substring(0, colNames2[c1].indexOf("-"));
                				try {
                					colNo = Integer.parseInt(newColName);
                					newCol = "Data Field"+colNo;
    							} catch (Exception e) {}
							} else {
								newCol = colNames2[c1];
							}
                			RC_Global.createNode(driver, "Driver or Pool Name deleted in the sheet validation in Leasewave");
                			if (driver.findElements(By.xpath("(//td[contains(@id,'ListxgrdList')]//tbody/tr)")).size()>0) {
                				isLists = true;
                				if (driver.findElement(By.xpath("(//td[contains(@id,'ListxgrdList')]//tbody/tr)[1]//td[10]/nobr")).getText().contains("-")) {
                    				if (sptCell2_old[c1].contains(driver.findElement(By.xpath("(//td[contains(@id,'ListxgrdList')]//tbody/tr)[1]//td[9]/nobr")).getText())) {
                    					BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Download and upload CVN by modifying Driver / Pool Name and verify the changes in Leasewave", "Name is not changed, Verification successful", null);
                    				} else {
                    					BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Download and upload CVN by modifying Driver / Pool Name and verify the changes in Leasewave", "Name is changed, Verification failed. Expected -"+sptCell2_old[c1], null);
                    				}	                					
    							} else {
    								String drivername[] = sptCell2_old[c1].split(" ");
    	                			RC_Manage.expected_actual(driver, "(//td[contains(@id,'ListxgrdList')]//tbody/tr)[1]//td[10]/nobr", drivername[0], "", "Verify the driver/pool name in the column remains the same");
    	        					RC_Manage.expected_actual(driver, "(//td[contains(@id,'ListxgrdList')]//tbody/tr)[1]//td[9]/nobr", drivername[1], "", "Verify the driver/pool name in the column remains the same");
    							}
                				
                			} else {
                				BFrameworkQueryObjects.logStatus(driver, Status.INFO, "Download and upload CVN by deleting Driver / Pool Name and verify the changes in Leasewave", "No data displayed in the Lease List grid for the unit number -"+sptCell2_old[0], null);
                				RC_LW_Manage.navigateAssetList_Leasewave(driver, false);
                				driver.findElement(By.xpath("//td//input[contains(@name,'UnitNumber')]")).clear();
                                driver.findElement(By.xpath("//td//input[contains(@name,'UnitNumber')]")).sendKeys(sptCell2_old[0]);
                                RC_Global.clickUsingXpath(driver,"//button[text()='Searc']","Search button",false,true);
                                Thread.sleep(2000);
                                if (driver.findElements(By.xpath("(//td[contains(@id,'ListxgrdList')]//tbody/tr)")).size()>0) {
                    				isLists = true; 
                    				if (driver.findElement(By.xpath("(//td[contains(@id,'ListxgrdList')]//tbody/tr)[1]//td[10]/nobr")).getText().contains("-")) {
                        				if (sptCell2_old[c1].contains(driver.findElement(By.xpath("(//td[contains(@id,'ListxgrdList')]//tbody/tr)[1]//td[10]/nobr")).getText())) {
                        					BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Download and upload CVN by modifying Driver / Pool Name and verify the changes in Leasewave", "Name is not changed, Verification successful", null);
                        				} else {
                        					BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Download and upload CVN by modifying Driver / Pool Name and verify the changes in Leasewave", "Name is changed, Verification failed. Expected -"+sptCell2_old[c1], null);
                        				}	                					
        							} else {
        								String drivername[] = sptCell2_old[c1].split(" ");
        								RC_Manage.expected_actual(driver, "(//td[contains(@id,'ListxgrdList')]//tbody/tr)[1]//td[10]/nobr", drivername[1]+"/"+drivername[0], "", "Verify the driver/pool name in the column remains the same");
        							}
                    			}
							}
                			if (!isLists) {
                				BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Download and upload CVN by deleting Driver / Pool Name and verify the changes in Leasewave", "No data displayed in both the Lease List/Asset List grid for the unit number -"+sptCell2_old[0], null);								
							}	                			
        				}
                		sptCell2_old = null;
                		sptCell2_new = null;
    				}
	            	RC_LW_Global.leaseWaveLogOut(driver, false);
	            	BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Download and upload CVN by modifying Driver and ClientData cell values and verify the changes in download result file, TV and leasewave", "Verification successful", null);
	            }
			}
		} catch (Exception e) {
			BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Download CVN Data and modifying Driver and ClientData field value changes upload - Test run failed", e.getLocalizedMessage(), e);
		}
		      
	}
	
}
