package Manage.MassUploadPortal.ClientDataAndCVN;



import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_5_2_05 {
	public void DownloadClientDataAndCVNTemplate_ValidateColumnNames(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		
		String retVal = ""; String newFileName = ""; String curDir = ""; String curFilePath = "";
		String colsClientData = "";  String sptVal[] = null;
		
		String cusno= "LS010143"; String selType = "Client Data and CVN Upload"; String Filename="ClientDataAndCVNUpload-"+cusno+".xlsx"; 
		String colNames = "Results;Reasons;Unit Number;CVN;VIN;Year;Make;Model;Driver/Pool Name;Fleet Number;Fleet Name;Account Number;Account Name;Sub-Account Number;Sub-Account Name";
		try {
			RC_Manage.deleteFile_Downloads(driver, "ClientDataAndCVNUpload");
			RC_Manage.deleteAllFolder_Files(driver);
			RC_Global.login(driver);
			RC_Global.navigateTo(driver,"Manage","Administration","Client Data Setup");
			Thread.sleep(5000);
			RC_Global.enterCustomerNumber(driver, "LS010143", "", "", false);
			colsClientData = RC_Manage.getClientDataCols(driver);
			RC_Global.panelAction(driver, "close", "Client Data Setup", false,true);
			RC_Global.navigateTo(driver,"Manage","Mass Upload Portal","");
			Thread.sleep(5000);
	        RC_Global.enterCustomerNumber(driver, "LS010143", "", "", false);
	        RC_Global.selectDropdownOption(driver, "I want to", "Download Template", false,true);
	        RC_Global.selectDropdownOption(driver, "Select Template", selType, false,true);
	        RC_Global.clickButton(driver, "Download Template", true,true);
	        RC_Manage.waitUntilDownloadingDisappears(driver);
	        Thread.sleep(3000);
	        retVal = RC_Manage.moveFileFromDownloads(driver, Filename, "MassDownload", true);
	        if (retVal.contains(";")) {
	        	sptVal = retVal.split(";");
	        	curDir= sptVal[0];
	        	newFileName = sptVal[1];
	        	curFilePath = curDir+"\\"+newFileName;
	        	//Column names validation in excel
	        	RC_Manage.validateColumnNames(driver, curFilePath, Filename, colNames+colsClientData);
	        	queryObjects.logStatus(driver, Status.PASS, "Verify all the column names displayed in the excel", "Verification successful", null);
	        }
	        RC_Global.logout(driver, false);
		} catch (Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Test run failed", e.getLocalizedMessage(), e);
		}
		      
	}
}
