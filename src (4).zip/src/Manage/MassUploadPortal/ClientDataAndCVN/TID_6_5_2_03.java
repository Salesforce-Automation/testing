package Manage.MassUploadPortal.ClientDataAndCVN;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_5_2_03 {
	public static String Name = "Client Data";
	public void ClientDataAndCVN_ColumnHeaders_NameChange_AddUpdateTemplate(WebDriver driver, BFrameworkQueryObjects queryObjects)throws Exception {
		
		
		String newFileName = ""; String submitTime = "";
		String curDir = ""; String manUnitNums = ""; String fileDownload=""; String downFilePath = "";
		String cusno= "LS008320"; String sptVal[] = null; String defTimeZon = ""; String sptCell_old[] = null;
		String sptRows[] = null; String rowData_old[] = null; String rowData_new[] =null;  
		String retVal = ""; String colsClientData = ""; String rowVals = ""; String delUnitNos= ""; String UpdateUnitNos= ""; String downDir = "";
		String ClientUnitNos= ""; String curFilePath = ""; String UnitNums = ""; String splitVals[]= null; String userName = "";
		String selType = "Client Data and CVN Upload";
		String Filename="ClientDataAndCVNUpload-"+cusno+".xlsx";
		
		defTimeZon = java.util.TimeZone.getDefault().getID();
		String colNames = "Results;Reasons;Unit Number;CVN;VIN;Year;Make;Model;Driver/Pool Name;Fleet Number;Fleet Name;Account Number;Account Name;Sub-Account Number;Sub-Account Name";
		
		RC_Manage.deleteFile_Downloads(driver, "ClientDataAndCVNUpload");
		RC_Manage.deleteAllFolder_Files(driver);
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Client Data Setup");
		RC_Global.enterCustomerNumber(driver, cusno, "", "",true);
		colsClientData = RC_Manage.getClientDataCols(driver);
		RC_Global.waitElementVisible(driver, 60, "//table//thead//tr", "Grid Row", false,true);
		
		RC_Global.clickButton(driver, "Add New Client Data",true,true);
		RC_Global.waitElementVisible(driver, 60, "//span[text()='Client Data Values']", "Client Data Values",false,true);
		WebElement element = driver.findElement(By.xpath("//input[@placeholder='Name']"));
		RC_Global.enterInput(driver, Name, element  , false,true);
		RC_Manage.checkBoxValidation(driver, "Is Active", false);
	    RC_Global.clickButton(driver, "Save ",true,true);
	    RC_Global.waitElementVisible(driver, 60, "(//span[text()='Client Data Setup'])[2]", "Client Data Setup",false,true);
	    
	    RC_Global.clickButton(driver, "Add New Client Data",true,true);
	    RC_Global.waitElementVisible(driver, 60, "//span[text()='Client Data Values']", "Client Data Values",false,true);
	    WebElement element1 = driver.findElement(By.xpath("//input[@placeholder='Name']"));
		RC_Global.enterInput(driver, Name, element1  , false,true);
		RC_Global.clickUsingXpath(driver, "//input[contains(@ng-model,'IsActive')]", "InActive", false,true);
		RC_Global.clickButton(driver, "Save ",true,true);
		RC_Global.waitElementVisible(driver, 60, "(//span[text()='Client Data Setup'])[2]", "Client Data Setup",false,true);
		
		RC_Global.clickButton(driver, "Add New Client Data",true,true);
	    RC_Global.waitElementVisible(driver, 60, "//span[text()='Client Data Values']", "Client Data Values",false,true);
	     WebElement element2 = driver.findElement(By.xpath("//input[@placeholder='Name']"));
		RC_Global.enterInput(driver, "Test Number", element2  , false,true);
		RC_Global.clickUsingXpath(driver, "//input[contains(@ng-model,'IsActive')]", "InActive", false,true);
		RC_Global.clickButton(driver, "Save ",true,true);
		RC_Global.waitElementVisible(driver, 60, "(//span[text()='Client Data Setup'])[2]", "Client Data Setup",false,true);
		
		RC_Global.panelAction(driver, "close", "Client Data Setup", false,true);
		RC_Global.navigateTo(driver, "Manage", "Mass Upload Portal", "");
		
		RC_Global.waitElementVisible(driver, 60, "//div//h3[text()='Mass Uploads']", "Mass Uploads",false,true);
		RC_Global.enterCustomerNumber(driver, cusno, "", "",true);
		retVal = RC_Manage.fileDownload(driver, selType, Filename);
		 if (retVal.contains(";")) {
	        	sptVal = retVal.split(";");
	        	curDir= sptVal[0];
	        	newFileName = sptVal[1];
	        	curFilePath = curDir+"\\"+newFileName;
	        
		RC_Manage.validateColumnNames(driver, curDir+"\\"+newFileName, Filename, colNames+colsClientData);
		 }
		RC_Global.panelAction(driver, "close", "Mass Upload Portal", false,true);
		
		RC_Global.navigateTo(driver, "Manage", "Administration", "Client Data Setup");
		RC_Global.enterCustomerNumber(driver, cusno, "", "",true);
		try {
			Thread.sleep(1000);
			List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("//table//tbody//tr"));  
			int rowcnt=Getgridrowcnt.size();
			Boolean	firstpage=false;
			
			for(int i=1; i<=rowcnt;i++) {
				WebElement sub = driver.findElement(By.xpath("//tr["+i+"]//td[2]"));
				String Cname = sub.getText();
				if(!Cname.isEmpty()) {
					WebElement Username = driver.findElement(By.xpath("//tbody//tr["+i+"]//td[6]//span"));
					WebElement clmn = driver.findElement(By.xpath("//tbody//tr["+i+"]//td[2]"));
				String	Name = clmn.getText();
					if((Name.equals("Test Number"))) {
					Thread.sleep(2000);
					Username.click();
					firstpage = false;
					RC_Global.waitElementVisible(driver, 60, "//span[text()='Client Data Values']", "Client Data Values",false,true);
					WebElement Rename = driver.findElement(By.xpath("//input[@placeholder='Name']"));
					RC_Global.enterInput(driver, "ClientDataField_R", Rename  , false,true);
					RC_Manage.checkBoxValidation(driver, "Is Active", false);
				    RC_Global.clickButton(driver, "Save ",true,true);
				    RC_Global.waitElementVisible(driver, 60, "(//span[text()='Client Data Setup'])[2]", "Client Data Setup",false,true);
				    RC_Global.panelAction(driver, "close", "Client Data Setup", false,true);
					break;}
				}
			}
	}
		catch (Exception e){
			queryObjects.logStatus(driver, Status.FAIL, "User Name hyperlink clicking unsuccesful", e.getLocalizedMessage(), e);	
			}
        RC_Global.navigateTo(driver, "Manage", "Mass Upload Portal", "");
		RC_Global.waitElementVisible(driver, 60, "//div//h3[text()='Mass Uploads']", "Mass Uploads",false,true);
		RC_Global.enterCustomerNumber(driver, cusno, "", "",true);

    	delUnitNos = RC_Manage.modifyCells_MandatoryColumns(driver, curFilePath, "red", 2, UnitNums, "Update");        	
    	UpdateUnitNos = RC_Manage.modifyCells_MandatoryColumns(driver, curFilePath, "red", 2, UnitNums+";"+delUnitNos, "Update");
		ClientUnitNos = RC_Manage.modifyCells_ColumnName(driver, curFilePath, "Test Number", 2, UnitNums+";"+delUnitNos+";"+UpdateUnitNos, "Update");
		
		userName = driver.findElement(By.xpath("//span[contains(@ng-show,'user.FullName') and @id='Span1']")).getText();
		submitTime = RC_Manage.fileUpload(driver, curDir, curFilePath, selType, "", defTimeZon, userName, "");
    	
    	RC_Manage.selectDownloadResults(driver, userName, submitTime, defTimeZon);//download file
    	
    	fileDownload = RC_Manage.moveFileFromDownloads(driver, Filename, "DownloadedFiles", true);
        if (fileDownload.contains(";")) {
        	downDir = fileDownload.substring(0, fileDownload.indexOf(";"));
        	downFilePath = fileDownload.replace(";", "\\");
        	RC_Manage.validateUploadChanges(driver, downFilePath, UpdateUnitNos, "Success");
        	RC_Manage.deleteFolder(driver, downDir);
        	RC_Global.panelAction(driver, "close", "Mass Upload Portal", false,true);
		}
        RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}

}