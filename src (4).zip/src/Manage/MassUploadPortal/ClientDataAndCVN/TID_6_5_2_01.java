package Manage.MassUploadPortal.ClientDataAndCVN;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import MF.Source.Cred;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_5_2_01 {
	public static void UIValidationOnMassUploadPortalScreen(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		String newFileName = ""; String curDir = "";
		String curFilePath = ""; String sptVal[] = null;
		String defTimeZon = "";
		
		String cusno= "LS010143"; String selType = "Client Data and CVN Upload"; String Filename="ClientDataAndCVNUpload-"+cusno+".xlsx"; 
		defTimeZon = java.util.TimeZone.getDefault().getID();
		RC_Manage.deleteFile_Downloads(driver, "ClientDataAndCVNUpload");
		RC_Manage.deleteAllFolder_Files(driver);
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Mass Upload Portal", "");
		RC_Global.waitUntilPanelVisibility(driver, "Mass Upload Portal", "TV", true,true);
		Thread.sleep(3000);
		RC_Global.enterCustomerNumber(driver, cusno, "", "", true);
		String downloadPath = RC_Manage.fileDownload(driver, selType, Filename);
		if (downloadPath.contains(";")) {
        	sptVal = downloadPath.split(";");
        	curDir= sptVal[0];
        	newFileName = sptVal[1];
        	curFilePath = curDir+"\\"+newFileName;	
		}
		
		driver.findElement(By.xpath("//div[@class='input-group']/input[@name='customerInput']")).clear();
		RC_Global.enterCustomerNumber(driver, "LS007125", "", "", true);
		RC_Global.selectDropdownOption(driver, "I want to", "Upload Template", true,true);
		
		String xpath = "(//label[text()='Select Template']/following-sibling::select)[2]";
		driver.findElement(By.xpath(xpath)).click();
		RC_Global.waitElementVisible(driver, 10, xpath+"/option", "Client Data and CVN Upload"+" Options", true,true); //Wait Options are available in DropDown to select
		driver.findElement(By.xpath(xpath+"/option[text()='Client Data and CVN Upload']")).click();
		Thread.sleep(2000);	
		RC_Global.buttonStatusValidation(driver, "Select File", "Enable", true);
		
		Select select = new Select(driver.findElement(By.xpath("//label[text()='Upload Time']/following-sibling::select")));
		WebElement option = select.getFirstSelectedOption();
		String defaultItem = option.getText();
		
		if(defaultItem.equalsIgnoreCase("Upload Now"))
			queryObjects.logStatus(driver, Status.PASS, "Verifying 'Upload Now' is selected by default", "Verification Successful", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verifying 'Upload Now' is selected by default", "'Upload Now' is not selected by default", null);

		RC_Global.buttonStatusValidation(driver, "Upload Template", "Disable", true);
		
		RC_Manage.fileUpload(driver, curDir, curFilePath, selType, "", defTimeZon, "", "");
		String errorMsg1 = "//h4[text()='Customer number selected does not match the customer number within the template. Please download a new template or change the selected customer.']";
		if(driver.findElements(By.xpath(errorMsg1)).size()>0) {
			queryObjects.logStatus(driver, Status.PASS, "Validate error message", errorMsg1+" error message displayed", null);
		}
		else {
			queryObjects.logStatus(driver, Status.FAIL, "Validate error message", errorMsg1+" error message not displayed", null);
		}
		
		driver.findElement(By.xpath("//div[@class='input-group']/input[@name='customerInput']")).clear();
		RC_Global.enterCustomerNumber(driver, "LS010143", "", "", true);
		
		String downloadPath1 = RC_Manage.fileDownload(driver, selType, Filename);
		if (downloadPath1.contains(";")) {
        	sptVal = downloadPath1.split(";");
        	curDir= sptVal[0];
        	newFileName = sptVal[1];
        	curFilePath = curDir+"\\"+newFileName;
		}
		
		RC_Manage.fileUpload(driver, curDir, curFilePath, "Employee Upload", "", defTimeZon, "","");
		
		String errorMsg2 = "//h4[text()='The template selected does not match the file being uploaded. Please choose the appropriate template via the Select Template Module or select a new file.']";
		if(driver.findElements(By.xpath(errorMsg2)).size()>0) {
			queryObjects.logStatus(driver, Status.PASS, "Validate error message", errorMsg2+" error message displayed", null);
		}
		else {
			queryObjects.logStatus(driver, Status.FAIL, "Validate error message", errorMsg2+" error message not displayed", null);
		}
		
		driver.findElement(By.xpath("//i[contains(@ng-click,'vm.removeFile')]")).click();
		driver.findElement(By.xpath("//div[@class='input-group']/input[@name='customerInput']")).clear();
		RC_Global.enterCustomerNumber(driver, "LS010143", "", "", true);
		
		String downloadPath2 = RC_Manage.fileDownload(driver, "Vehicle Movement Upload", "VehicleMovement-"+cusno+".xlsx");
		if (downloadPath2.contains(";")) {
        	sptVal = downloadPath2.split(";");
        	curDir= sptVal[0];
        	newFileName = sptVal[1];
        	curFilePath = curDir+"\\"+newFileName;	
		}
		
		driver.findElement(By.xpath("//div[@class='input-group']/input[@name='customerInput']")).clear();
		RC_Global.enterCustomerNumber(driver, "LS007125", "", "", true);
		
		RC_Manage.fileUpload(driver, curDir, curFilePath, "Vehicle Movement Upload", "", defTimeZon, "","");
		
		if(driver.findElements(By.xpath(errorMsg1)).size()>0) {
			queryObjects.logStatus(driver, Status.PASS, "Validate error message", errorMsg1+" error message displayed", null);
		}
		else {
			queryObjects.logStatus(driver, Status.FAIL, "Validate error message", errorMsg1+" error message not displayed", null);
		}
		
		driver.findElement(By.xpath("//i[contains(@ng-click,'vm.removeFile')]")).click();
		driver.findElement(By.xpath("//div[@class='input-group']/input[@name='customerInput']")).clear();
		RC_Global.enterCustomerNumber(driver, "LS010143", "", "", true);
		
		String downloadPath3 = RC_Manage.fileDownload(driver, "Vehicle Movement Upload", "VehicleMovement-"+cusno+".xlsx");
		if (downloadPath3.contains(";")) {
        	sptVal = downloadPath3.split(";");
        	curDir= sptVal[0];
        	newFileName = sptVal[1];
        	curFilePath = curDir+"\\"+newFileName;	
		}
		
		driver.findElement(By.xpath("//div[@class='input-group']/input[@name='customerInput']")).clear();
		RC_Global.enterCustomerNumber(driver, "LS010143", "", "", true);

		RC_Manage.fileUpload(driver, curDir, curFilePath, selType, "", defTimeZon, "","");
		if(driver.findElements(By.xpath(errorMsg2)).size()>0) {
			queryObjects.logStatus(driver, Status.PASS, "Validate error message", errorMsg2+" error message displayed", null);
		}
		else {
			queryObjects.logStatus(driver, Status.FAIL, "Validate error message", errorMsg2+" error message not displayed", null);
		}
		
		RC_Global.panelAction(driver, "close", "Mass Upload Portal", true,true);
		
		if (!(Cred.ENV.equalsIgnoreCase("PROD"))) {
			
			RC_Global.navigateTo(driver, "Manage", "Mass Upload Portal", "");
			RC_Global.waitUntilPanelVisibility(driver, "Mass Upload Portal", "TV", true,true);
			Thread.sleep(3000);
			RC_Global.enterCustomerNumber(driver, "LS010143", "", "", true);
			
			downloadPath3 = RC_Manage.fileDownload(driver, selType, Filename);
			if (downloadPath3.contains(";")) {
	        	sptVal = downloadPath3.split(";");
	        	curDir= sptVal[0];
	        	newFileName = sptVal[1];
	        	curFilePath = curDir+"\\"+newFileName;	
			}
			
			driver.findElement(By.xpath("//div[@class='input-group']/input[@name='customerInput']")).clear();
			RC_Global.enterCustomerNumber(driver, "LS010143", "", "", true);
					
			RC_Global.selectDropdownOption(driver, "I want to", "Upload Template", false,true);
			RC_Manage.selectFromDropdown(driver, selType, driver.findElement(By.xpath("//div[contains(@class,'upload')]/div/label[text()='Select Template']/following-sibling::Select")));
			String currentWindow = driver.getWindowHandle();
		    driver.switchTo().window(currentWindow);
		    driver.manage().window().maximize();
			RC_Global.clickButton(driver, "Select File", true,true);
			Thread.sleep(1000);
	        RC_Manage.uploadFileWithRobot(driver, curFilePath);
	        Thread.sleep(5000);
	        RC_Global.clickButton(driver, "Upload Template", true,true);
			Thread.sleep(3000);
			
			driver.findElement(By.xpath("//div[@class='input-group']/input[@name='customerInput']")).clear();
	        RC_Global.enterCustomerNumber(driver, "LS010143", "", "", true);
	        RC_Global.selectDropdownOption(driver, "I want to", "Upload Template", false,true);
			RC_Manage.selectFromDropdown(driver, selType, driver.findElement(By.xpath("//div[contains(@class,'upload')]/div/label[text()='Select Template']/following-sibling::Select")));
			RC_Global.clickButton(driver, "Select File", true,true);
			Thread.sleep(1000);
	        RC_Manage.uploadFileWithRobot(driver, curFilePath);
	        Thread.sleep(5000);

			RC_Global.clickButton(driver, "Upload Template", false,true);
			Thread.sleep(10000);
			String errorMsg3 = "//h4[text()='This file has already been uploaded. Please select a different file or download a new template.']";
			if(driver.findElements(By.xpath(errorMsg3)).size()>0) {
				queryObjects.logStatus(driver, Status.PASS, "Validate error message", errorMsg3+" error message displayed", null);
			}
			else {
				queryObjects.logStatus(driver, Status.FAIL, "Validate error message", errorMsg3+" error message not displayed", null);
			}
		}
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Validate multiple error message with Client Data and CVN template", "Successfully completed", null);
	}
}
