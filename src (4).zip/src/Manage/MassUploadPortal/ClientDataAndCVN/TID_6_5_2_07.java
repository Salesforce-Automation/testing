package Manage.MassUploadPortal.ClientDataAndCVN;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.LeaseWave.RC_LW_Global;
import tools.LeaseWave.RC_LW_Manage;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_5_2_07 {
	public void DownloadandUploadCVNTemplatewithMultipleValidations_MandatoryFields_Modify(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String delVals= ""; String UpdateVals= "";
		String sptVal[] = null;
		String retVal = ""; String fileDownload=""; String newFileName = ""; String curDir = ""; String curFilePath = "";
		String downDir = ""; String downFilePath = "";  String delUnitNos= ""; String UpdateUnitNos= "";
		String sptRows[] = null; String sptRows2[] = null; String rowData_old[] = null; 
		String colNames[] = null; String rowData2_old[] = null; String colNames2[] = null;
		String rowData_new[] = null; String rowData2_new[] = null; String sptCell_old[] = null; 
		String sptCell2_old[] = null; String sptCell_new[] = null; String sptCell2_new[] = null;
		String userName = ""; String newColName = ""; int colNo = 0; String newCol = "";
		String leaseStatus = ""; String submitTime = ""; String defTimeZon = "";
		String uploadedTime = ""; String valDate = null;
		
		String cusno= "LS010143"; String selType = "Client Data and CVN Upload"; String Filename="ClientDataAndCVNUpload-"+cusno+".xlsx";
		try {
			defTimeZon = java.util.TimeZone.getDefault().getID();
			RC_Manage.deleteFile_Downloads(driver, "ClientDataAndCVNUpload");
			RC_Manage.deleteAllFolder_Files(driver);
			RC_Global.login(driver);
			RC_Global.navigateTo(driver,"Manage","Mass Upload Portal","");
			Thread.sleep(5000);
	        RC_Global.enterCustomerNumber(driver, "LS010143", "", "", true);        
	        retVal = RC_Manage.fileDownload(driver, selType, Filename);
	        if (retVal.contains(";")) {
	        	sptVal = retVal.split(";");
	        	curDir= sptVal[0];
	        	newFileName = sptVal[1];
	        	curFilePath = curDir+"\\"+newFileName;
	        	
	        	//Deleted Mandatory cells
	        	delVals = RC_Manage.modifyCells_MandatoryColumns(driver, curFilePath, "red", 2, "", "Delete");
	        	sptRows = delVals.split("~~");
	        	colNames = sptRows[0].split(";");
	        	rowData_old = sptRows[1].split("__");
	        	rowData_new = sptRows[2].split("__");
	        	
	        	for (int i = 0; i < rowData_old.length; i++) {
	        		sptCell_old = rowData_old[i].split(";");
	        		if (delUnitNos=="") {
	        			delUnitNos = sptCell_old[0];
					} else {
							delUnitNos = delUnitNos+";"+sptCell_old[0];
					}sptCell_old = null;       		
				}
	        	
	        	//Updated Mandatory cells
	        	UpdateVals = RC_Manage.modifyCells_MandatoryColumns(driver, curFilePath, "red", 2, delUnitNos, "Update");        	
	        	sptRows2 = UpdateVals.split("~~");
	        	colNames2 = sptRows2[0].split(";");
	        	rowData2_old = sptRows2[1].split("__");
	        	rowData2_new = sptRows2[2].split("__");
	        	
	        	for (int j = 0; j < rowData2_old.length; j++) {
	        		
	        		sptCell2_old = rowData2_old[j].split(";");
	        		if (UpdateUnitNos=="") {
	        			UpdateUnitNos = sptCell2_old[0];
					} else {
						UpdateUnitNos = UpdateUnitNos+";"+sptCell2_old[0];
					}sptCell2_old = null;
				}
	        	
	        	userName = driver.findElement(By.xpath("//span[contains(@ng-show,'user.FullName') and @id='Span1']")).getText();
	        	submitTime = RC_Manage.fileUpload(driver, curDir, curFilePath, selType, "", defTimeZon, userName, "");
	        	
	        	uploadedTime = RC_Manage.selectDownloadResults(driver, userName, submitTime, defTimeZon);//download file
	        	if (defTimeZon.equalsIgnoreCase("CST") || defTimeZon.equalsIgnoreCase("America/Chicago")) {
	        		valDate = RC_Manage.driverHistory_DateFormat(driver, queryObjects, uploadedTime, "No");
				} else {
					valDate = RC_Manage.driverHistory_DateFormat(driver, queryObjects, uploadedTime, "Yes");
				}
	        	
	        	fileDownload = RC_Manage.moveFileFromDownloads(driver, Filename, "DownloadedFiles", true);
	            if (fileDownload.contains(";")) {
	            	downDir = fileDownload.substring(0, fileDownload.indexOf(";"));
	            	downFilePath = fileDownload.replace(";", "\\");
	            	RC_Manage.validateUploadChanges(driver, downFilePath, delUnitNos, "Error");
	            	RC_Manage.validateUploadChanges(driver, downFilePath, UpdateUnitNos, "Success");
	            	RC_Manage.deleteFolder(driver, downDir);
	            	//TV Application validate
	            	RC_Global.panelAction(driver, "close", "Mass Upload Portal", false,true); 
	            	
	            	//Totalview - //Deleted Mandatory cells Validation
	            	for (int r = 0; r < rowData_old.length; r++) {
	            		sptCell_old = rowData_old[r].split(";");
	            		sptCell_new = rowData_new[r].split(";");
	            		newColName = "";
	            		for (int c = 1; c < colNames.length; c++) {
	            			newCol = "";
	            			if (colNames[c].contains("-")) {
	            				newColName = colNames[c].substring(0, colNames[c].indexOf("-"));
	            				try {
	            					colNo = Integer.parseInt(newColName);
	            					newCol = "Client Data "+colNo;
								} catch (Exception e) {}
							}   else {
								newCol = colNames[c];
							}
	            			RC_Manage.viewHistory_DriverChange(driver, queryObjects, cusno, sptCell_old[0], userName, valDate);
	                    	if (driver.findElements(By.xpath("//div[contains(@class,'ng-hide')]//h4[text()='Old ']")).size()>0) {
								queryObjects.logStatus(driver, Status.PASS, "Check the Unit Number Row values changes with Error status in the Driver History", "Changes are not reflected in the application", null);
							} else {
								queryObjects.logStatus(driver, Status.FAIL, "Check the Unit Number Row values changes with Error status in the Driver History", "Changes are reflected in the application", null);
							}
	                    	driver.findElement(By.xpath("//h5[span[contains(text(),'Driver Change')]]/i[@ng-click='closePanel()']")).click();
	    				}
	            		sptCell_old = null;
	            		sptCell_new = null;
					}
	            	
	            	//Totalview - //Updated Mandatory cells Validation
	            	for (int r1 = 0; r1 < rowData2_old.length; r1++) {
	            		sptCell2_old = rowData2_old[r1].split(";");
	            		sptCell2_new = rowData2_new[r1].split(";");
	            		newColName = "";
	            		for (int c1 = 1; c1 < colNames2.length; c1++) {
	            			newCol = "";
	            			if (colNames2[c1].contains("-")) {
	            				newColName = colNames2[c1].substring(0, colNames2[c1].indexOf("-"));
	            				try {
	            					colNo = Integer.parseInt(newColName);
	            					newCol = "Client Data "+colNo;
								} catch (Exception e) {}
							}  else {
								newCol = colNames2[c1];
							}
	            			RC_Manage.viewHistory_DriverChange(driver, queryObjects, cusno, sptCell2_old[0], userName, valDate);
	                    	RC_Manage.compareExpected_Actual(driver, sptCell2_old[c1], sptCell2_new[c1], newCol);
	                    	driver.findElement(By.xpath("//h5[span[contains(text(),'Driver Change')]]/i[@ng-click='closePanel()']")).click();
	    				}
	            		sptCell2_old = null;
	            		sptCell2_new = null;
					}
	            	
	            	boolean isDriver = false;
	            	//LeaseWave - //Deleted Mandatory cells Validation
	            	RC_LW_Global.leaseWaveLogin(driver,true);
	            	leaseStatus = "Commenced";
	            	for (int r = 0; r < rowData_old.length; r++) {
                		sptCell_old = rowData_old[r].split(";");
                		sptCell_new = rowData_new[r].split(";");
                		newColName = "";
                		for (int c = 1; c < colNames.length; c++) {
                			newCol = "";
                			if (colNames[c].contains("-")) {
                				newColName = colNames[c].substring(0, colNames[c].indexOf("-"));
                				try {
                					colNo = Integer.parseInt(newColName);
                					newCol = "Data Field"+colNo;
    							} catch (Exception e) {}
							}  else {
								newCol = colNames[c];
							}
                			if (!newCol.contains("Data Field")) {//Navigate to Lease Profile to validate Driver Details
                				if (c==1) {
                					RC_LW_Manage.navigateLeaseList_Leasewave(driver, false);
                					RC_LW_Manage.unitNoSearchLeaseProfile_Leasewave(driver, sptCell_old[0], leaseStatus, false);
								}
                				RC_LW_Manage.validateDriverDetails_Leasewave(driver, newCol, sptCell_old[c]);
                				isDriver = true;
                				
							} else {
								if (isDriver) {
									if (driver.findElements(By.xpath("//button[text()='lose']")).size()>0) {
										driver.findElement(By.xpath("//button[text()='lose']")).click();
				                        RC_Global.waitElementVisible(driver, 50, "//span[text()='Lease Entry Home']", "Lease Entry Home",false,true);
				                        driver.findElement(By.xpath("//button[text()='cel']")).click();
				                        try {
				                            Thread.sleep(1000);
				                            
				                            driver.switchTo().alert().accept();
				                            Thread.sleep(1000);
				                          }catch(Exception e){
				                          }
									}
								}
								if (driver.findElements(By.xpath("//span[text()='Asset Client Data Fields']")).size()==0) {
									RC_LW_Manage.navigateAssetList_Leasewave(driver, false);//Navigate to Asset Profile to validate Client Data fields
									RC_LW_Manage.unitNoSearchAssetList_Leasewave(driver, sptCell_old[0], false);
								}
								RC_LW_Manage.validateClientDatas_Leasewave(driver, newCol, sptCell_old[c], false);
							}
                			if (colNo==25) {
                				break;
                			}
        				}
                			colNo=1;
	                		sptCell_old = null;
	                		sptCell_new = null;
	                		driver.findElement(By.xpath("(//button[text()='lose'])[2]")).click();
	            			RC_Global.waitElementVisible(driver, 50, "//span[text()='Asset Profile Home']", "Asset Profile Home",false,true);
	            			driver.findElement(By.xpath("//button[text()='lose']")).click();

				}
	            	isDriver = false;
	            	//LeaseWave - //Updated Mandatory cells Validation
	            	leaseStatus = "Commenced";
	            	for (int r1 = 0; r1 < rowData2_old.length; r1++) {
                		sptCell2_old = rowData2_old[r1].split(";");
                		sptCell2_new = rowData2_new[r1].split(";");
                		newColName = "";
                		for (int c1 = 1; c1 < colNames2.length; c1++) {
                			newCol = "";
                			if (!("Fleet Number;Fleet Name;Account Number;Account Name;Sub-Account Number;Sub-Account Name".contains(colNames2[c1]))) {
	                			if (colNames2[c1].contains("-")) {
	                				newColName = colNames2[c1].substring(0, colNames2[c1].indexOf("-"));
	                				try {
	                					colNo = Integer.parseInt(newColName);
	                					newCol = "Data Field"+colNo;
	    							} catch (Exception e) {}
								}  else {
									newCol = colNames2[c1];
								}
	                			if (!newCol.contains("Data Field")) {//Navigate to Lease Profile to validate Driver Details
	                				if (c1==1) {
	                					RC_LW_Manage.navigateLeaseList_Leasewave(driver, false);
										RC_LW_Manage.unitNoSearchLeaseProfile_Leasewave(driver, sptCell2_old[0], leaseStatus, false);
									}
	                				if (newCol.equalsIgnoreCase("cvn") || newCol.equalsIgnoreCase("customer vehicle number")) {
	                					RC_LW_Manage.validateDriverDetails_Leasewave(driver, newCol, sptCell2_new[c1]);
	                				} else {
	                					RC_LW_Manage.validateDriverDetails_Leasewave(driver, newCol, sptCell2_old[c1]);
									}
	                				isDriver = true;
	                				
								} else {
									if (isDriver) {
										driver.findElement(By.xpath("//button[text()='lose']")).click();
				                        RC_Global.waitElementVisible(driver, 50, "//span[text()='Lease Entry Home']", "Lease Entry Home",false,true);
				                        driver.findElement(By.xpath("//button[text()='cel']")).click();
				                        try {
				                            Thread.sleep(1000);
				                            driver.switchTo().alert().accept();
				                            Thread.sleep(1000);
				                          }catch(Exception e){
				                          }
									}
									if (driver.findElements(By.xpath("//span[text()='Asset Client Data Fields']")).size()==0) {
										RC_LW_Manage.navigateAssetList_Leasewave(driver, false);//Navigate to Asset Profile to validate Client Data fields
										RC_LW_Manage.unitNoSearchAssetList_Leasewave(driver, sptCell2_old[0], false);
									}
									if (colNo<=25) {
										RC_LW_Manage.validateClientDatas_Leasewave(driver, newCol, sptCell2_new[c1], false);
									}
								}
                			}
                			if (colNo>=25) {
                				break;
                			}
        				}
                			colNo=1;
	                		sptCell2_old = null;
	                		sptCell2_new = null;
	                		driver.findElement(By.xpath("(//button[text()='lose'])[2]")).click();
	            			RC_Global.waitElementVisible(driver, 50, "//span[text()='Asset Profile Home']", "Asset Profile Home",false,true);
	            			driver.findElement(By.xpath("//button[text()='lose']")).click();

				}
	            	RC_LW_Global.leaseWaveLogOut(driver, false);
	            	queryObjects.logStatus(driver, Status.PASS, "Download and upload CVN by modifying Mandatory cell values and verify the changes in download result file, TV and leasewave", "Verification successful", null);	
	            	
	            }
			}
		} catch (Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Download CVN Data and Mandatory field changes upload - Test run failed", e.getLocalizedMessage(), e);
		}
		      
	}
	
}
