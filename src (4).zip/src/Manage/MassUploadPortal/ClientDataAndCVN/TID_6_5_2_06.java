package Manage.MassUploadPortal.ClientDataAndCVN;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_5_2_06 {
	public void DownloadandUploadCVNTemplatewithMultipleValidations_ScheduleUpload(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		
		String retVal = ""; String sptVal[] = null; String fileDownload=""; String newFileName = "";
		String curDir = ""; String curFilePath = ""; String downDir = "";
		String userName = ""; String submittedTime = ""; String defTimeZon = "";
		
		defTimeZon = java.util.TimeZone.getDefault().getID();
		List<String> timeZones = new ArrayList<String>(Arrays.asList("America/New_York",	"CST",	"America/Denver",	"PST",	"HST")); 
		String cusno= "LS010143"; String selType = "Client Data and CVN Upload"; String Filename="ClientDataAndCVNUpload-"+cusno+".xlsx";
		try {
			RC_Manage.deleteFile_Downloads(driver, "ClientDataAndCVNUpload");
			RC_Manage.deleteAllFolder_Files(driver);
			RC_Global.login(driver);Thread.sleep(5000);
			RC_Global.navigateTo(driver,"Manage","Mass Upload Portal","");
			Thread.sleep(5000);
	        RC_Global.enterCustomerNumber(driver, "LS010143", "", "", false);
	        for (String timezn : timeZones) {
	        	retVal = "";sptVal = null; curDir = ""; newFileName= ""; curFilePath = ""; fileDownload= ""; downDir = ""; submittedTime = "";
	        	retVal = RC_Manage.fileDownload(driver, selType, Filename);
	            if (retVal.contains(";")) {
	            	sptVal = retVal.split(";");
	            	curDir= sptVal[0];
	            	newFileName = sptVal[1];
	            	curFilePath = curDir+"\\"+newFileName;
	            	userName = driver.findElement(By.xpath("//span[contains(@ng-show,'user.FullName') and @id='Span1']")).getText();
	            	submittedTime = RC_Manage.fileUpload(driver, curDir, curFilePath, selType, timezn, defTimeZon, userName, "schedule");
	            	RC_Manage.selectDownloadResults(driver, userName, submittedTime, defTimeZon);//download file
	            	fileDownload = RC_Manage.moveFileFromDownloads(driver, Filename, "DownloadedFiles", true);
	            	downDir = fileDownload.substring(0, fileDownload.indexOf(";"));
	            	RC_Manage.deleteFolder(driver, downDir);
	            	RC_Manage.deleteFile_Downloads(driver, "ClientDataAndCVNUpload");
	        		RC_Manage.deleteAllFolder_Files(driver);
	            	queryObjects.logStatus(driver, Status.PASS, "Verify the Schedule Upload with Timezone -"+timezn, "Verification successful", null);
	    		}
			}
	        RC_Global.logout(driver, false);
	        queryObjects.logStatus(driver, Status.PASS, "Schedule Upload with Multiple Timezones ", "Successfully completed", null);
		} catch (Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Schedule Upload - Test run failed", e.getLocalizedMessage(), e);
		}
	}
	
	
	
	

}
