package Manage.MassUploadPortal.PoolManagementUpload;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_5_6_03 {
	public void CreateNewAndEditExistingPools(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception,IOException
	{
		String CustomerNumber = "LS008742"; 
		String selType = "Pool Management Upload"; 
		String curFilePath = "";
		String defTimeZon = ""; String retVal = "";String sptVal[] = null;String newFileName = ""; String curDir = "";
		String RowValsN1 ="";String RowValsN2 ="";String RowValsE1 ="";String RowValsE2 ="";String RowValsedit1 ="";String RowValsedit2 ="";
    	List<Integer> NewRow1=null;List<Integer> EditRow1=null;;List<Integer> EditRow2=null;int UpdateRow; int rowNum = 5;
    	String userName = ""; String submitTime = ""; String uploadedTime = ""; String valDate = null;
    	String fileDownload=""; String downDir = ""; String downFilePath = "";
    	String delUnitNos= ""; String UpdateUnitNos= "";String sptCell_new[] = null; 
		String sptRows[] = null; String sptRows2[] = null; String rowData_old[] = null;String rowData_new[] = null;String colNames[] = null;
		
    	String colName = "TotalView Pool ID;Pool Name;Pool Contact First Name;Pool Contact Last Name;Email;Cell Phone;Work Phone;Extension;Home Phone;Alert Distribution Method;Address Validation Override;Address 1;Address 2;City;State;Zip Code;County;Country;Status;-Email-Text Message-Email & Text Message-Yes-No-Active-InActive";
 //   	String colName = "Home Phone;Alert Distribution Method;Address Validation Override;Address 1;Address 2;City;State;Zip Code;County;Country;Status,Email-Text Message-Email & Text Message,Yes-No,Active-InActive";
		
		
		defTimeZon = java.util.TimeZone.getDefault().getID();
		RC_Manage.deleteFile_Downloads(driver, "EmployeeCreateEdit");
		RC_Manage.deleteAllFolder_Files(driver);
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,"Manage","Mass Upload Portal","");
		RC_Global.waitElementVisible(driver, 30,"//h3[text()='Mass Uploads']", "Mass Upload Portal", true, true);
		RC_Global.enterCustomerNumber(driver,CustomerNumber,"Customer", "Fleet level", true);
		String FL = driver.findElement(By.xpath("//div[@ng-show='customerChosen']/input[contains(@class,'ng-not-empty')]")).getAttribute("value");
		String Filename="PoolCreateEdit-"+FL+".xlsx"; 
		retVal = RC_Manage.fileDownload(driver, selType, Filename);
		Thread.sleep(2000);
		if (retVal.contains(";")) {
        	sptVal = retVal.split(";");
        	curDir= sptVal[0];
        	newFileName = sptVal[1];
        	curFilePath = curDir+"\\"+newFileName;
        	
        	FileInputStream fs = new FileInputStream(curFilePath);
        	XSSFWorkbook wb = new XSSFWorkbook(fs);
        	XSSFSheet worksheet = wb.getSheetAt(1);
        	
        	RC_Manage.sorting_ColumnNames(driver, curFilePath, "Pool Name");
        	RC_Manage.ColumnValidationAndPicklistValue(driver, curFilePath, "yes", "yes", colName);
    //  	RC_Manage.poolColumnValidation(driver, curFilePath, "Pool Create Edit", "yes", "yes", colName, rowNum);
        	List<Integer> addedNewRow1=new ArrayList<Integer>();
        	List<Integer> addedNewRow2=new ArrayList<Integer>();
        	List<Integer> editedRow1=new ArrayList<Integer>();
        	List<Integer> editedRow2=new ArrayList<Integer>();
        	List<Integer> editSRow1=new ArrayList<Integer>();
        	List<Integer> editSRow2=new ArrayList<Integer>();
        	
        
        	NewRow1 = RC_Manage.Get_insertRow_Excel(driver, curFilePath, "insert", 2, selType);
        	addedNewRow1.add(NewRow1.get(0));
        	addedNewRow2.add(NewRow1.get(1));
        	Thread.sleep(3000);
        	RowValsN1 = RC_Manage.updateAllColumns_Employee_PoolUpload(driver, curFilePath, addedNewRow1);
        	RowValsN2 = RC_Manage.updateAllColumns_Employee_PoolUpload(driver, curFilePath, addedNewRow2);
        	
        	sptRows = RowValsN1.split("~~");
        	colNames = sptRows[0].split(";");
        	rowData_old = sptRows[1].split("__");
        	rowData_new = sptRows[2].split("__");
        	
        	for (int i = 0; i < rowData_new.length; i++) {
        		sptCell_new = rowData_new[i].split(";");
        		if (delUnitNos=="") {
        			delUnitNos = sptCell_new[0];
				} else {
						delUnitNos = delUnitNos+";"+sptCell_new[0];
				}sptCell_new = null;       		
			}	        
        	
        	queryObjects.logStatus(driver, Status.INFO, "Newly Inserted Row values - "+delUnitNos+"", "Verification successful", null);	
        	
        	EditRow1 = RC_Manage.Get_insertRow_Excel(driver, curFilePath, "", 2, selType);
        	editedRow1.remove(0);
        	editedRow1.add(EditRow1.get(0));
        	editedRow2.remove(0);
        	editedRow2.add(EditRow1.get(1));
        	String Fname1 = "Allen"+RandomStringUtils.randomAlphanumeric(2);
        	String Lname1 = "Fad"+RandomStringUtils.randomAlphanumeric(2);
        	String Address1 = "42"+RandomStringUtils.randomNumeric(3)+ "Park Avenue st";
        	String PoolName1 = "Allen Media - PA Pool";
        	String Fname2 = "Alex"+RandomStringUtils.randomAlphanumeric(2);
        	String Lname2 = "Fred"+RandomStringUtils.randomAlphanumeric(2);
        	String Address2 = "24"+RandomStringUtils.randomNumeric(3)+ "cross st";
        	String PoolName2 = "Media Far - PA Pool";
        	
        	RowValsE1 = RC_Manage.columnsValueEdit_Employee_Pool(driver, curFilePath, "Pool Name;Pool Contact First Name;Pool Contact Last Name;Address 1", ""+PoolName1+";"+Fname1+";"+Lname1+";"+Address1+"", editedRow1);;
        	RowValsE2 = RC_Manage.columnsValueEdit_Employee_Pool(driver, curFilePath, "Pool Name;Pool Contact First Name;Pool Contact Last Name;Address 1", ""+PoolName2+";"+Fname2+";"+Lname2+";"+Address2+"", editedRow2);
 
        	EditRow2 = RC_Manage.Get_insertRow_Excel(driver, curFilePath, "", 2,selType);
        	editSRow1.remove(0);
        	editSRow1.add(EditRow2.get(0));
        	editSRow2.remove(0);
        	editSRow2.add(EditRow2.get(1));
        	RowValsedit1 = RC_Manage.columnsValueEdit_Employee_Pool(driver, curFilePath, "Status;", "Active;", editSRow1);
        	RowValsedit2 = RC_Manage.columnsValueEdit_Employee_Pool(driver, curFilePath, "Status;", "InActive;", editSRow2);

        	userName = driver.findElement(By.xpath("//span[contains(@ng-show,'user.FullName') and @id='Span1']")).getText();
        	submitTime = RC_Manage.fileUpload(driver, curDir, curFilePath, selType, "", defTimeZon, userName, "");
        	
        	uploadedTime = RC_Manage.selectDownloadResults(driver, userName, submitTime, defTimeZon);
        	if (defTimeZon.equalsIgnoreCase("CST") || defTimeZon.equalsIgnoreCase("America/Chicago")) {
        		valDate = RC_Manage.driverHistory_DateFormat(driver, queryObjects, uploadedTime, "No");
    		} else {
    			valDate = RC_Manage.driverHistory_DateFormat(driver, queryObjects, uploadedTime, "Yes");
    		}
        	
        	fileDownload = RC_Manage.moveFileFromDownloads(driver, Filename, "DownloadedFiles", true);
            if (fileDownload.contains(";")) {
            	downDir = fileDownload.substring(0, fileDownload.indexOf(";"));
            	downFilePath = fileDownload.replace(";", "\\");
            	RC_Manage.validateResults_RowNumbers(driver, downFilePath, NewRow1, "Error", "");
            	RC_Manage.deleteFolder(driver, downDir);	
            	RC_Global.panelAction(driver, "close", "Mass Upload Portal", false,true);
            	Thread.sleep(2000);
            }
            
            RC_Global.navigateTo(driver, "Manage", "Administration", "Pool Management");
            RC_Global.waitUntilPanelVisibility(driver,"Pool Management","TV", true,false);
    		RC_Global.enterCustomerNumber(driver, CustomerNumber, "", "", true);
    		RC_Global.selectDropdownOption(driver, "poolManagementChangePool", "Pending New Driver - Storage", false, true);
    		RC_Global.scrollById(driver, "//label[text()='Address 2']");
    		RC_Global.clickUsingXpath(driver, "(//table/tbody/tr[1]/td)[7]", "Associated Units", false, true);
    		RC_Global.panelAction(driver, "close", "Pool Management", false,true);
    		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details","TV", true,false);
    		String address = driver.findElement(By.xpath("//div[text()='Address:']//following-sibling::div")).getText();
    		queryObjects.logStatus(driver, Status.PASS, "The address shown for the respective associated units ---->",address, null);
    		String addressinexcel = Address1;
    		if(address.contains(addressinexcel)) {
    			queryObjects.logStatus(driver, Status.PASS, "The address shown for the respective associated unit is","Same as Address present in Excel", null);
    		}
    		else {
    			queryObjects.logStatus(driver, Status.FAIL, "The address shown for the respective associated units is","Not Same as Address present in Excel", null);
    		}
    	
    		RC_Global.clickUsingXpath(driver, "//div[text()='Driver:']//following-sibling::div", "Driver-Pool Name", false, true);
    		RC_Global.panelAction(driver, "close", "Vehicle Details", false,true);
    		RC_Global.waitUntilPanelVisibility(driver,"Driver Details","TV", true,false);
    		RC_Global.clickButton(driver, "History", true,true);
    		RC_Global.panelAction(driver, "close", "Driver Details", false,true);
    		RC_Global.panelAction(driver, "expand", "Driver Change - History", false,true);
    		String Modifiedby = driver.findElement(By.xpath("(//table/tbody/tr[1]/td[5])[2]")).getText().toUpperCase();
    		if(Modifiedby.contains(RC_Global.userLogged))
    		{
    			RC_Global.clickUsingXpath(driver, "(//table/tbody/tr[1]/td[1])[2]", "Changes", false,true);
    			String Oldaddress = driver.findElement(By.xpath("(//table/tbody/tr[3]/td[2][text()='Vehicle Location Street Line 1'])[1]/../td[3]")).getText();
                String Newaddress = driver.findElement(By.xpath("(//table/tbody/tr[3]/td[2][text()='Vehicle Location Street Line 1'])[1]/../td[4]")).getText();
    		
    			queryObjects.logStatus(driver, Status.INFO, "Old Pool Address", Oldaddress, null);
    			queryObjects.logStatus(driver, Status.INFO, "New Pool Address", Newaddress, null);
    			queryObjects.logStatus(driver, Status.INFO, "New Pool Address Modified By", Modifiedby, null);
    			if(Newaddress.toUpperCase().contains(Address1.toUpperCase()))
    			{
    				queryObjects.logStatus(driver, Status.PASS, "Changed Pool Address "+Newaddress+" is displayed in history", "Successfully", null);
    			} else {
    				queryObjects.logStatus(driver, Status.FAIL, "Changed vehicle Address "+Newaddress+" is not displayed in history", "Failed", null);
    			}
    		}
		}
	}

}
