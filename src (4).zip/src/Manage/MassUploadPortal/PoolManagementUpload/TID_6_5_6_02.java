package Manage.MassUploadPortal.PoolManagementUpload;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_5_6_02 {

	public static void RegressionTestCaseForPoolTemplate(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		String cusNo = "LS150394";
		String fileName = "PoolCreateEdit-"+cusNo+".xlsx";
		String defTimeZon = "";String sptVal[] = null; String newFileName = ""; String curDir = "";
		String curFilePath = ""; String selType = "Pool Management Upload";
		String retRowVal = ""; String sptCell_old[] = null;
		String fileDownload="";String downFilePath = ""; String downDir = "";
		String sptRows[] = null;String delUnitNos= ""; String userName = ""; String submitTime = ""; String UnitNums = "";
		String defTimeZone = "";
		defTimeZone = java.util.TimeZone.getDefault().getID();
		String colName = ""; String uploadedTime = ""; String valDate = null;
		List<Integer> rowsDet = null; String RowValsN = ""; String RowValsU = ""; String rowData_old[] = null;
		String rowData_new[] = null;String colNames[] = null;
		String delVals= ""; List<Integer> rowsDet2 = new ArrayList<Integer>();
		String ColGrey = "TotalView Pool ID";
		String ColRed = "Pool Name;Pool Contact First Name;Pool Contact Last Name;Email;Alert Distribution Method;Address Validation Override;Address 1;City;State;Zip Code;Country;Status";
		String ColBlue = "Cell Phone;Work Phone;Extension;Home Phone;Address 2;County";
		
		String ResultcolNames = "Results;Reason;TotalView Pool ID;Pool Name;Pool Contact First Name;Pool Contact Last Name;Email;Cell Phone;Work Phone;Extension;Home Phone;Alert Distribution Method;Address Validation Override;Address 1;Address 2;City;State;Zip Code;County;Country;Status";
		String colNamesCol = "TotalView Pool ID;Pool Name;Pool Contact First Name;Pool Contact Last Name;Email;Cell Phone;Work Phone;Extension;Home Phone;Alert Distribution Method;Address Validation Override;Address 1;Address 2;City;State;Zip Code;County;Country;Status";

		
		defTimeZon = java.util.TimeZone.getDefault().getID();
		RC_Manage.deleteFile_Downloads(driver, "PoolCreateEdit");
		RC_Manage.deleteAllFolder_Files(driver);
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Vehicle Details");
		RC_Global.waitUntilPanelVisibility(driver, "Vehicle Details", "TV", true,true);
		Thread.sleep(3000);
		RC_Global.enterCustomerNumber(driver, cusNo, "", "", true);
		WebElement element = driver.findElement(By.xpath("//input[@placeholder='Pool Name']"));
		RC_Global.enterInput(driver, "Pending", element, false, true);
		RC_Global.clickButton(driver, "Search", false, true);
		RC_Global.waitElementVisible(driver, 60, "//tbody//tr[1]//td[1]", "Pool search Results", true, true);
		queryObjects.logStatus(driver,Status.INFO,"Related pool results are returning and", "No Driver assigned units were returned", null);
		RC_Global.panelAction(driver, "close", "Vehicle Details", false,true);
		
		RC_Global.navigateTo(driver, "Manage", "Administration", "Driver Data Change");
		RC_Global.enterCustomerNumber(driver, cusNo, "", "", true);
		WebElement element1 = driver.findElement(By.xpath("//input[@placeholder='Pool Name']"));
		RC_Global.enterInput(driver, "Pending", element1, false, true);
		RC_Global.clickButton(driver, "Search", false, true);
		RC_Global.waitElementVisible(driver, 60, "//tbody//tr[1]//td[1]", "Pool search Results", true, true);
		queryObjects.logStatus(driver,Status.INFO,"Related pool results are returning and", "No Driver assigned units were returned", null);
		RC_Global.panelAction(driver, "close", "Driver Data Change", false,false);
		
		
		RC_Global.navigateTo(driver, "Manage", "Mass Upload Portal", "");
		RC_Global.waitUntilPanelVisibility(driver, "Mass Upload Portal", "TV", true,true);
		Thread.sleep(3000);
		RC_Global.enterCustomerNumber(driver, cusNo, "", "", true);
		String downloadPath = RC_Manage.fileDownload(driver, selType, fileName);
		if (downloadPath.contains(";")) {
        	sptVal = downloadPath.split(";");
        	curDir= sptVal[0];
        	newFileName = sptVal[1];
        	curFilePath = curDir+"\\"+newFileName;	
		
		//Select few records in the template and enter a valid address and select 'Yes' or leave it NO in Address Validation Override and save ,upload template
//        	delVals = RC_Manage.columnsValueEdit_PoolManagement(driver, curFilePath, "Email;Distribution Method", RandomStringUtils.randomAlphabetic(7).toUpperCase()+RandomStringUtils.randomNumeric(3)+"@merchants.com;Email & Text Message", rowsDet2);
//        	rowsDet2.remove(0); rowsDet2.add(rowsDet.get(1));
        	String Fname = "Jessica"+RandomStringUtils.randomNumeric(2);
        	String Lname = "Sampletest"+RandomStringUtils.randomAlphanumeric(2);
        	String city = "West Sacramento";
        	String state = "CA";
        	String Zipcode = "95693"+RandomStringUtils.randomNumeric(4);
        	delVals = RC_Manage.columnsValueEdit_Employee_Pool(driver, curFilePath, "Pool Name;Pool Contact First Name;Pool Contact Last Name;Address Validation Override;Address 1;City;State;Zip Code;Country;Status", "Pending New Driver - Storage;"+Fname+";"+Lname+";selListVal;Yes;"+RandomStringUtils.randomNumeric(10)+";Yes;3306 Bermuda Ct;"+city+";"+state+";"+Zipcode+";selListVal;Active", rowsDet2);
//        	rowsDet2.remove(0); rowsDet2.add(rowsDet.get(2));
//        	delVals = RC_Manage.columnsValueEdit_PoolManagement(driver, curFilePath, "Status;", "Active;", rowsDet2);
        	sptRows = RowValsN.split("~~");
        	colNames = sptRows[0].split(";");
//        	rowData_old = sptRows[1].split("__");
//        	rowData_new = sptRows[2].split("__");
        	
        /*	for (int i = 0; i < rowData_old.length; i++) {
        		sptCell_old = rowData_old[i].split(";");
        		if (delUnitNos=="") {
        			delUnitNos = sptCell_old[0];
				} else {
						delUnitNos = delUnitNos+";"+sptCell_old[0];
				}sptCell_old = null;       		
			}*/	        	
    	
   
    	userName = driver.findElement(By.xpath("//span[contains(@ng-show,'user.FullName') and @id='Span1']")).getText();
    	submitTime = RC_Manage.fileUpload(driver, curDir, curFilePath, selType, "", defTimeZon, userName, "");
    	
    	uploadedTime = RC_Manage.selectDownloadResults(driver, userName, submitTime, defTimeZon);
    	if (defTimeZon.equalsIgnoreCase("CST") || defTimeZon.equalsIgnoreCase("America/Chicago")) {
    		valDate = RC_Manage.driverHistory_DateFormat(driver, queryObjects, uploadedTime, "No");
		} else {
			valDate = RC_Manage.driverHistory_DateFormat(driver, queryObjects, uploadedTime, "Yes");
		}
    	
    	fileDownload = RC_Manage.moveFileFromDownloads(driver, fileName, "DownloadedFiles", true);
        if (fileDownload.contains(";")) {
        	downDir = fileDownload.substring(0, fileDownload.indexOf(";"));
        	downFilePath = fileDownload.replace(";", "\\");
        	RC_Manage.validateResults_RowNumbers(driver, downFilePath, rowsDet, "Error", "");
        	RC_Manage.deleteFolder(driver, downDir);	
        	RC_Global.panelAction(driver, "close", "Mass Upload Portal", false,true);
        	Thread.sleep(2000);
        }
        
        RC_Global.navigateTo(driver, "Manage", "Administration", "Pool Management");
        RC_Global.waitUntilPanelVisibility(driver,"Pool Management","TV", true,false);
		RC_Global.enterCustomerNumber(driver, cusNo, "", "", true);
		RC_Global.selectDropdownOption(driver, "poolManagementChangePool", "Pending New Driver - Storage", false, true);
		RC_Global.scrollById(driver, "//label[text()='Address 2']");
		List<WebElement> associateUnits = 	driver.findElements(By.xpath("//table/tbody/tr/td"));
		int assunitscount =associateUnits.size();
		queryObjects.logStatus(driver, Status.PASS, "Associated Units count of pool is",""+assunitscount+"", null);
			for (int i = 0; i < 8; i++) {
				WebElement assounits = driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td"));
				String assounitnum = assounits.getText();
				queryObjects.logStatus(driver, Status.PASS, "Associated Unit of pool is",assounitnum, null);
				assounits.click();
				
//		RC_Global.clickUsingXpath(driver, "//table/tbody/tr[1]/td", "Associated Units", false, true);/
		RC_Global.panelAction(driver, "close", "Pool Management", false,true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details","TV", true,false);
		String associatenum = driver.findElement(By.xpath("//div[text()='Unit #:']//following-sibling::div")).getText();
		String address = driver.findElement(By.xpath("//div[text()='Address:']//following-sibling::div")).getText();
		queryObjects.logStatus(driver, Status.PASS, "The address shown for the respective associated units ---->",address, null);
			
		String addressinexcel = "3306 Bermuda Ct West Sacramento CA 95691-5907";
		if(address.contains(addressinexcel)) {
			queryObjects.logStatus(driver, Status.PASS, "The address shown for the respective associated unit is","Same as Address present in Excel", null);
		}
		else {
			queryObjects.logStatus(driver, Status.FAIL, "The address shown for the respective associated units is","Not Same as Address present in Excel", null);
		}
			}		
		String Address1 = "3306 Bermuda Ct";
		RC_Global.clickUsingXpath(driver, "//div[text()='Driver:']//following-sibling::div", "Driver-Pool Name", false, true);
		RC_Global.panelAction(driver, "close", "Vehicle Details", false,true);
		RC_Global.waitUntilPanelVisibility(driver,"Driver Details","TV", true,false);
		RC_Global.clickButton(driver, "History", true,true);
		RC_Global.panelAction(driver, "close", "Driver Details", false,true);
		RC_Global.panelAction(driver, "expand", "Driver Change - History", false,true);
		String Modifiedby = driver.findElement(By.xpath("(//table/tbody/tr[1]/td[5])[2]")).getText().toUpperCase();
		if(Modifiedby.contains(RC_Global.userLogged))
		{
			RC_Global.clickUsingXpath(driver, "(//table/tbody/tr[1]/td[1])[2]", "Changes", false,true);
			//Address
			String Oldaddress = driver.findElement(By.xpath("(//table/tbody/tr[3]/td[2][text()='Vehicle Location Street Line 1'])[1]/../td[3]")).getText();
            String Newaddress = driver.findElement(By.xpath("(//table/tbody/tr[3]/td[2][text()='Vehicle Location Street Line 1'])[1]/../td[4]")).getText();
			//city
           /* String Oldcity = driver.findElement(By.xpath("")).getText();
            String Newcity = driver.findElement(By.xpath("")).getText();
            //state
            String Oldstate = driver.findElement(By.xpath("")).getText();
            String Newstate = driver.findElement(By.xpath("")).getText();
            //ZipCode
            String Oldzipcode = driver.findElement(By.xpath("")).getText();
            String Newzipcode = driver.findElement(By.xpath("")).getText();*/
			queryObjects.logStatus(driver, Status.INFO, "Old Pool Address", Oldaddress, null);
			queryObjects.logStatus(driver, Status.INFO, "New Pool Address", Newaddress, null);
			/*queryObjects.logStatus(driver, Status.INFO, "Old Pool City", Oldcity, null);
			queryObjects.logStatus(driver, Status.INFO, "New Pool City", Newcity, null);
			queryObjects.logStatus(driver, Status.INFO, "Old Pool City", Oldstate, null);
			queryObjects.logStatus(driver, Status.INFO, "New Pool City", Newstate, null);
			queryObjects.logStatus(driver, Status.INFO, "Old Pool City", Oldzipcode, null);
			queryObjects.logStatus(driver, Status.INFO, "New Pool City", Newzipcode, null);
			queryObjects.logStatus(driver, Status.INFO, "New Pool Address Modified By", Modifiedby, null);*/
			if(Newaddress.toUpperCase().contains(Address1.toUpperCase()))
			{
				queryObjects.logStatus(driver, Status.PASS, "Changed Pool Address "+Newaddress+" is displayed in history", "Successfully", null);
			} else {
				queryObjects.logStatus(driver, Status.FAIL, "Changed vehicle Address "+Newaddress+" is not displayed in history", "Failed", null);
			}
			
			/*if(Newcity.toUpperCase().contains(city.toUpperCase()))
			{
				queryObjects.logStatus(driver, Status.PASS, "Changed Pool City "+Newcity+" is displayed in history", "Successfully", null);
			} else {
				queryObjects.logStatus(driver, Status.FAIL, "Changed Pool City "+Newcity+" is not displayed in history", "Failed", null);
			}
			if(Newstate.toUpperCase().contains(state.toUpperCase()))
			{
				queryObjects.logStatus(driver, Status.PASS, "Changed Pool State "+Newstate+" is displayed in history", "Successfully", null);
			} else {
				queryObjects.logStatus(driver, Status.FAIL, "Changed Pool State "+Newstate+" is not displayed in history", "Failed", null);
			}
			if(Newzipcode.contains(Zipcode))
			{
				queryObjects.logStatus(driver, Status.PASS, "Changed Pool Zip Code "+Newzipcode+" is displayed in history", "Successfully", null);
			} else {
				queryObjects.logStatus(driver, Status.FAIL, "Changed Pool Zip Code "+Newzipcode+" is not displayed in history", "Failed", null);
			}*/
			
		}
		//Associated units
	List<WebElement> associateUnits1 = 	driver.findElements(By.xpath("//table/tbody/tr/td"));
	int assunitscount1 =associateUnits.size();
	queryObjects.logStatus(driver, Status.PASS, "Associated Units count of pool is",""+assunitscount1+"", null);
		for (int j = 0; j < 10; j++) {
			WebElement assounits1 = driver.findElement(By.xpath("//table/tbody/tr["+j+"]/td"));
			String assounitnum1 = assounits1.getText();
			queryObjects.logStatus(driver, Status.PASS, "Associated Unit of pool is",assounitnum1, null);
			assounits1.click();
			RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details","TV", true,false);
			RC_Global.validateHeaderName(driver, "Vehicle Details", false);
			Thread.sleep(2000);
			String associatenum1 = driver.findElement(By.xpath("//div[text()='Unit #:']//following-sibling::div")).getText();
			String address1 = driver.findElement(By.xpath("//div[text()='Address:']//following-sibling::div")).getText();
			queryObjects.logStatus(driver, Status.PASS, "The address shown for the respective associated units ---->",address1, null);
				
			String addressinexcel1 = "3306 Bermuda Ct West Sacramento CA 95691-5907";
			if(!(address1.contains(addressinexcel1))) {
				queryObjects.logStatus(driver, Status.PASS, "Address was changed for","Pool Assigned units ONLY", null);
			}
			else {
				queryObjects.logStatus(driver, Status.FAIL, "Address was changed for Pool Assigned units","also reflecting in driver unit - "+associatenum1+"", null);
				}
			}
		}
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
