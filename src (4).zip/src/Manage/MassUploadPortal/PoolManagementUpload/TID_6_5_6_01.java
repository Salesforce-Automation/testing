package Manage.MassUploadPortal.PoolManagementUpload;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.LeaseWave.RC_LW_Global;
import tools.LeaseWave.RC_LW_Manage;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_5_6_01 {	
	public void ValidateMandatoryFields_AddressColumnPoolManagementUploadTemplate_RemoveFuelEnrollmentInEmployeeMassCreate_Edit (WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		String menu = "Manage";
		String firstSubMenu = "Mass Upload Portal";
		String CustomerNumber = "LS010108"; 
		String selType = "Pool Management Upload"; 
		String Filename="PoolCreateEdit-"+CustomerNumber+".xlsx"; String curFilePath = "";
		String sptVal[] = null;	String retVal = "";String newFileName = ""; String curDir = "";
		String colNames = "Pool Name;Pool Contact First name;Pool Contact Last Name;Email;Alert Distribution Method;Address Validation Override;Address 1;City;State;Zip Code;Country;Work Phone;Cell Phone and / or Email depending on Distribution Method selected;Status";
		String colNamesCol = "";String defTimeZone = "";String userName = "";String fileDownload="";
		defTimeZone = java.util.TimeZone.getDefault().getID();String submitTime = "";String uploadedTime = ""; String valDate = null;
		List<Integer> rowChange = new ArrayList<Integer>(); List<Integer> rowUpdate = new ArrayList<Integer>(); 
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,"");
		RC_Global.waitElementVisible(driver, 30,"//h3[text()='Mass Uploads']", "Mass Upload Portal", true, true);
		RC_Global.enterCustomerNumber(driver,CustomerNumber, "", "", true);
		retVal = RC_Manage.fileDownload(driver, selType, Filename);
		if (retVal.contains(";")) {
	        	sptVal = retVal.split(";");
	        	curDir= sptVal[0];
	        	newFileName = sptVal[1];
	        	curFilePath = curDir+"\\"+newFileName;
		RC_Manage.validateColumnNames(driver, curFilePath, Filename, colNamesCol);
		 }
		
		rowUpdate = RC_Manage.updateRowData(driver, curFilePath, 6, 2, "Update", "Yes", "");
		rowChange.add(0, rowUpdate.get(0));
		rowChange.add(1, rowUpdate.get(1));
		rowUpdate = RC_Manage.updateRowData(driver, curFilePath, 8, 2, "Update", "No", "");
		rowChange.add(2, rowUpdate.get(0));
		rowChange.add(3, rowUpdate.get(1));
		rowUpdate = RC_Manage.updateRowData(driver, curFilePath, 10, 2, "Update", "Yes", "Yes");
		rowChange.add(4, rowUpdate.get(0));
		rowChange.add(5, rowUpdate.get(1));
		rowUpdate = RC_Manage.updateRowData(driver, curFilePath, 12, 2, "Update", "No", "Yes");
		rowChange.add(6, rowUpdate.get(0));
		rowChange.add(7, rowUpdate.get(1));
		
		//update row
		FileInputStream fis = new FileInputStream(curFilePath);
        XSSFWorkbook wb = new XSSFWorkbook(fis);
        XSSFSheet sh = wb.getSheetAt(1);
        int rows = sh.getLastRowNum();
        int cols= sh.getRow(2).getLastCellNum();  
        
        XSSFCell cell = sh.getRow(5).getCell(11);   
        cell.setCellValue(" ");
        rowChange.add(new Integer(5));

		fis.close();
        FileOutputStream fos = new FileOutputStream(curFilePath);
        wb.write(fos);
        wb.close();
        fos.close();
        
		userName = driver.findElement(By.xpath("//span[contains(@ng-show,'user.FullName') and @id='Span1']")).getText();
		submitTime = RC_Manage.fileUpload(driver, curDir, curFilePath, selType, "", defTimeZone, userName, "");
		uploadedTime = RC_Manage.selectDownloadResults(driver, userName, submitTime, defTimeZone);//download file
    	if (defTimeZone.equalsIgnoreCase("CST") || defTimeZone.equalsIgnoreCase("America/Chicago")) {
    		valDate = RC_Manage.driverHistory_DateFormat(driver, queryObjects, uploadedTime, "No");
		} else {
			valDate = RC_Manage.driverHistory_DateFormat(driver, queryObjects, uploadedTime, "Yes");
		}
    	
    	fileDownload = RC_Manage.moveFileFromDownloads(driver, Filename, "DownloadedFiles", true);
         if (fileDownload.contains(";")) {
        	 curDir = fileDownload.substring(0, fileDownload.indexOf(";"));
        	 curFilePath = fileDownload.replace(";", "\\");}
 		
         Integer[] rowChanged = {rowChange.get(0),rowChange.get(1),rowChange.get(2),rowChange.get(3),rowChange.get(4),rowChange.get(5),rowChange.get(6),rowChange.get(7),rowChange.get(8)};
         String[] Reasons = {"","","","","","","Entered Address is not valid. Recommended Address Found","Entered Address is not valid. Recommended Address Found","Missing value in required fields: Alert Distribution Method"};
		RC_Manage.validateResultsOfRowNumbers(driver, curFilePath, rowChanged, "Success;Success;Success;Success;Success;Success;Error;Error;Error", Reasons); 
		
		retVal = RC_Manage.fileDownload(driver, selType, Filename);
		RC_Global.createNode(driver, "Customer level Validations in downloaded DriverPoolAssignment excel file");
		if (retVal.contains(";")) {
	        	sptVal = retVal.split(";");
	        	curDir= sptVal[0];
	        	newFileName = sptVal[1];
	        	curFilePath = curDir+"\\"+newFileName;}	
		
		
		RC_Global.navigateTo(driver,menu,"Administration","Pool Management");
		RC_Global.waitElementVisible(driver, 30,"//h5//span[text()='Pool Management']", "Pool Management", true, true);
		RC_Global.panelAction(driver, "close", "Mass Upload Portal", false, true);
		RC_Global.enterCustomerNumber(driver,CustomerNumber, "", "", true);
		RC_Global.clickButton(driver, "Edit", true, true);
		RC_Global.selectDropdownOption(driver, "poolManagementChangePool", "Friendly Pool", true, true);
		driver.findElement(By.xpath("//input[@id='poolManagementGaragingLocation']")).sendKeys("10851 Energy Highway");
		Thread.sleep(2000);
		String emailId = RandomStringUtils.randomAlphabetic(10).toUpperCase()+RandomStringUtils.randomNumeric(3)+"@merchants.com";
		driver.findElement(By.xpath("//input[@id='poolManagementEmail']")).clear();
		driver.findElement(By.xpath("//input[@id='poolManagementEmail']")).sendKeys(emailId);
		Thread.sleep(2000);
		String UnitNumber = driver.findElement(By.xpath("//tbody//tr[1]//td")).getText();
		RC_Global.clickButton(driver, "Save", true, true);
		RC_Global.verifyDisplayedMessage(driver, "Save Successful", true);
		RC_Global.panelAction(driver, "close", "Pool Management", false, true);
		
		 fis = new FileInputStream(curFilePath);
         wb = new XSSFWorkbook(fis);
         sh = wb.getSheetAt(1); 
         
         cell = sh.getRow(5).getCell(6);   
         cell.setCellValue(emailId);
         cell = sh.getRow(5).getCell(13);   
         cell.setCellValue("10851 Energy Highway");
         rowUpdate.add(0, 5);
         fis.close();
         fos = new FileOutputStream(curFilePath);
         wb.write(fos);
         wb.close();
         fos.close();
         
        submitTime = RC_Manage.fileUpload(driver, curDir, curFilePath, selType, "", defTimeZone, userName, "");
 		uploadedTime = RC_Manage.selectDownloadResults(driver, userName, submitTime, defTimeZone);//download file
     	if (defTimeZone.equalsIgnoreCase("CST") || defTimeZone.equalsIgnoreCase("America/Chicago")) {
     		valDate = RC_Manage.driverHistory_DateFormat(driver, queryObjects, uploadedTime, "No");
 		} else {
 			valDate = RC_Manage.driverHistory_DateFormat(driver, queryObjects, uploadedTime, "Yes");
 		}
     	
     	fileDownload = RC_Manage.moveFileFromDownloads(driver, Filename, "DownloadedFiles", true);
          if (fileDownload.contains(";")) {
         	 curDir = fileDownload.substring(0, fileDownload.indexOf(";"));
         	 curFilePath = fileDownload.replace(";", "\\");}     
  		RC_Manage.validateResults_RowNumbers(driver, curFilePath, rowUpdate, "Success", ""); 
  		RC_Global.logout(driver, false);
  		
		RC_LW_Global.leaseWaveLogin(driver, true);
		RC_LW_Manage.employeeUploadUpdate(driver, UnitNumber, "10851 Energy Highway", true);
		RC_LW_Global.leaseWaveLogOut(driver, true);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}

}
