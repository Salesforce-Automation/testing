package Manage.MassUploadPortal.FuelCardOrderUpload;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_5_7_04 {
	public void PreventTheDownloadOrUploadOfTheFuelCardOrderTemplateForNonFuelEnrolledClients(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String cusno= "152172";String selType = "Fuel Card Order Upload";String Filename="";String downloadPath="";
		String sptVal[] = null;String curDir = "";String newFileName = "";String curFilePath = "";String defTimeZon = ""; 
		String userName = "";String curDirAc = "";String curDirSub = "";String curFilePathAc = "";String curFilePathSub = "";
		String curDirFl = "";String curFilePathFl = ""; String fleetNum = "";String acctNum = "";String subAcctNum = "";

		RC_Manage.deleteFile_Downloads(driver, "Fuel Card Order Upload");
		RC_Manage.deleteAllFolder_Files(driver);
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,"Manage","Administration","Customer Administration");
		RC_Global.enterCustomerNumber(driver, cusno, "", "", true);
		RC_Global.clickUsingXpath(driver, "//a[text()='Fuel']", "Fuel Tab", true, true);
		RC_Global.waitElementVisible(driver, 15, "//label[text()='Enrolled in Fuel']", "Fuel Attributes are displayed", false, false);
		RC_Global.createNode(driver, "Validate "+cusno+" Enrolled in Fuel");
		if(driver.findElement(By.xpath("//label[text()='Enrolled in Fuel']/../div/div/button[text()='Yes']")).getAttribute("class").contains("active"))
		{
			queryObjects.logStatus(driver, Status.PASS, "Enrolled in Fuel", "Yes", null);
			RC_Global.clickUsingXpath(driver, "//label[text()='Enrolled in Fuel']/../div/div/button[text()='No']", "Enrolled in Fuel-> No", false, false);
			RC_Global.clickUsingXpath(driver, "(//button[@id='save'])[1]", "Save", false, false);
			RC_Global.waitElementVisible(driver, 10, "(//h4[text()='Update Successful'])[1]", "Update Successful", false, false);
		}
		else
			queryObjects.logStatus(driver, Status.PASS, "Enrolled in Fuel", "No", null);
		fleetNum = driver.findElement(By.xpath("(//ul/li[contains(@ng-class,'headClass') and @class='ng-scope tree-collapsed']/i[contains(@ng-class,'iBranchClass')])[1]/following-sibling::div/span")).getText().trim();
		driver.findElement(By.xpath("(//ul/li[contains(@ng-class,'headClass') and @class='ng-scope tree-collapsed']/i[contains(@ng-class,'iBranchClass')])[1]")).click();
		Thread.sleep(1000);
		acctNum = driver.findElement(By.xpath("(//ul/li[contains(@ng-class,'headClass') and @class='ng-scope tree-collapsed']/i[contains(@ng-class,'iBranchClass')])[1]/following-sibling::div/span")).getText().trim();
		driver.findElement(By.xpath("(//ul/li[contains(@ng-class,'headClass') and @class='ng-scope tree-collapsed']/i[contains(@ng-class,'iBranchClass')])[1]")).click();
		Thread.sleep(1000);
		subAcctNum = driver.findElement(By.xpath("(//li[@class='ng-scope tree-leaf'])[1]/div/span")).getText().trim();
		
		RC_Global.panelAction(driver, "close", "Customer Administration", false, true);
		
		RC_Global.navigateTo(driver, "Manage", "Mass Upload Portal", "");
        RC_Global.waitElementVisible(driver, 60, "//div//h3[text()='Mass Uploads']", "Mass Uploads",false,true);
		RC_Global.enterCustomerNumber(driver, cusno, "", "",true);
		WebElement custInputField = driver.findElement(By.xpath("//div[@ng-show='customerChosen']/input[@name='customerInput']"));
		
		RC_Global.selectDropdownOption(driver, "I want to", "Download Template", false,true);
        RC_Global.selectDropdownOption(driver, "Select Template", selType, false,true);
        RC_Global.clickButton(driver, "Download Template", true,true);
        RC_Global.waitElementVisible(driver, 15, "//h4[contains(text(),'Validation request failed')]", "Validation request failed! Details. Customer selected is not enrolled in the Fuel Program, please review Customer�s Fuel Attributes.", false, true);
        
        RC_Global.clickUsingXpath(driver, "//div[@class='input-group'][1]/div/button", "Expand customer structure", false, false);
		RC_Global.clickUsingXpath(driver, "//span[text()='"+fleetNum+"']", "Fleet Level -> "+fleetNum+"", false, true);
		Filename="Fuel Card Order Upload-"+custInputField.getAttribute("value")+".xlsx";
		downloadPath = RC_Manage.fileDownload(driver, selType, Filename);
		if (downloadPath.contains(";")) {
        	sptVal = downloadPath.split(";");
        	curDirFl= sptVal[0];
        	newFileName = sptVal[1];
        	curFilePathFl = curDirFl+"\\"+newFileName;	
		}
		
		RC_Global.clickUsingXpath(driver, "//div[@class='input-group'][1]/div/button", "Expand customer structure", false, false);
		RC_Global.clickUsingXpath(driver, "//span[text()='"+fleetNum+"']/../../i[1]", "Expand Fleet Level -> "+fleetNum+"", false, false);
		RC_Global.clickUsingXpath(driver, "//span[text()='"+acctNum+"']", "Account Level -> "+acctNum+"", false, true);
		Filename="Fuel Card Order Upload-"+custInputField.getAttribute("value")+".xlsx";
		downloadPath = RC_Manage.fileDownload(driver, selType, Filename);
		if (downloadPath.contains(";")) {
			sptVal = downloadPath.split(";");
			curDirAc= sptVal[0];
			newFileName = sptVal[1];
			curFilePathAc = curDirAc+"\\"+newFileName;	
		}
		
		RC_Global.clickUsingXpath(driver, "//div[@class='input-group'][1]/div/button", "Expand customer structure", false, false);
		RC_Global.clickUsingXpath(driver, "//span[text()='"+acctNum+"']/../../i[1]", "Expand Accont Level -> "+acctNum+"", false, false);
		RC_Global.clickUsingXpath(driver, "//span[text()='"+subAcctNum+"']", "Sub Account Level -> "+subAcctNum+"", false, true);
		Filename="Fuel Card Order Upload-"+custInputField.getAttribute("value")+".xlsx";
		downloadPath = RC_Manage.fileDownload(driver, selType, Filename);
		if (downloadPath.contains(";")) {
			sptVal = downloadPath.split(";");
			curDirSub= sptVal[0];
			newFileName = sptVal[1];
			curFilePathSub = curDirSub+"\\"+newFileName;	
		}
		RC_Global.panelAction(driver, "close", "Mass Upload Portal", false, true);
		
		RC_Global.navigateTo(driver,"Manage","Administration","Customer Administration");
		RC_Global.enterCustomerNumber(driver, cusno, "", "", true);
		RC_Global.clickUsingXpath(driver, "//a[text()='Fuel']", "Fuel Tab", true, true);
		RC_Global.waitElementVisible(driver, 15, "//label[text()='Enrolled in Fuel']", "Fuel Attributes are displayed", false, false);
		RC_Global.clickUsingXpath(driver, "//label[text()='Enrolled in Fuel']/../div/div/button[text()='Yes']", "Enrolled in Fuel-> yes", false, false);

		RC_Global.scrollById(driver, "//legend[text()='Rush Fuel Card Ordering']");
		RC_Global.clickUsingXpath(driver, "//label[text()='Rush Admin Fee *']/../div/div/button[text()='No']", "Rush Admin Fee * -> No", false, true);
		RC_Global.clickUsingXpath(driver, "//label[text()='Express Shipping Fee *']/../div/div/button[text()='No']", "Express Shipping Fee * -> No", false, true);
		RC_Global.clickUsingXpath(driver, "//label[text()='Rebate Extended *']/../div/div/button[text()='No']", "Rebate Extended * -> No", false, true);
		RC_Global.clickUsingXpath(driver, "//label[text()='Late Fee Applied *']/../div/div/button[text()='No']", "Late Fee Applied * -> No", false, true);
		RC_Global.clickUsingXpath(driver, "//label[text()='Rebate Extended *']/../div/div/button[text()='No']", "Rebate Extended * -> No", false, true);
		RC_Global.clickUsingXpath(driver, "//label[text()='Rebate Extended *']/../div/div/button[text()='No']", "Rebate Extended * -> No", false, true);
		RC_Global.scrollById(driver, "//legend[text()='Card Type']");
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Card Type *", "Fuel Only", false);
		RC_Global.clickUsingXpath(driver, "//label[text()='Restrict User at Level 3 *']/../div/div/button[text()='No']", "Restrict User at Level 3 * -> No", false, true);
		RC_Global.selectDropdownOption(driver, "Point of Sale Prompt Choices *", "Cardholder ID & Odometer", false, true);
		RC_Global.clickUsingXpath(driver, "//label[text()='Display Customer Card Data *']/../div/div/button[text()='No']", "Display Customer Card Data * -> No", false, true);
		RC_Global.scrollById(driver, "//legend[text()='Fuel Driver ID']");
		RC_Global.selectDropdownOption(driver, "Driver ID Type *", "VIN", false, true);
		RC_Global.selectDropdownOption(driver, "Driver ID Length *", "6", false, true);
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Acceptable Transaction Location(s) *", "Car Wash", false);
		Thread.sleep(5000);
		RC_Global.scrollById(driver, "(//button[@id='save'])[1]");
		RC_Global.clickUsingXpath(driver, "(//button[@id='save'])[1]", "Save", false, true);
		RC_Global.waitElementVisible(driver, 10, "(//h4[text()='Update Successful'])[1]", "Update Successful", false, true);
		RC_Global.scrollById(driver, "(//span[text()='Customer Administration'])[2]");
		RC_Global.panelAction(driver, "close", "Customer Administration", false, true);
		
		RC_Global.navigateTo(driver, "Manage", "Mass Upload Portal", "");
		RC_Global.waitElementVisible(driver, 60, "//div//h3[text()='Mass Uploads']", "Mass Uploads",false,true);
		RC_Global.enterCustomerNumber(driver, cusno, "", "",true);
		Filename="Fuel Card Order Upload-"+custInputField.getAttribute("value")+".xlsx";
		downloadPath = RC_Manage.fileDownload(driver, selType, Filename);
		if (downloadPath.contains(";")) {
			sptVal = downloadPath.split(";");
			curDir= sptVal[0];
			newFileName = sptVal[1];
			curFilePath = curDir+"\\"+newFileName;	
		}
		RC_Global.panelAction(driver, "close", "Mass Upload Portal", false, true);
		
		RC_Global.navigateTo(driver,"Manage","Administration","Customer Administration");
		RC_Global.enterCustomerNumber(driver, cusno, "", "", true);
		RC_Global.clickUsingXpath(driver, "//a[text()='Fuel']", "Fuel Tab", true, true);
		RC_Global.waitElementVisible(driver, 15, "//label[text()='Enrolled in Fuel']", "Fuel Attributes are displayed", false, true);
		RC_Global.clickUsingXpath(driver, "//label[text()='Enrolled in Fuel']/../div/div/button[text()='No']", "Enrolled in Fuel-> No", false, true);
		RC_Global.clickUsingXpath(driver, "(//button[@id='save'])[1]", "Save", false, true);
		RC_Global.waitElementVisible(driver, 10, "(//h4[text()='Update Successful'])[1]", "Update Successful", false, true);
		RC_Global.panelAction(driver, "close", "Customer Administration", false, true);
		
		defTimeZon = java.util.TimeZone.getDefault().getID();
		userName = driver.findElement(By.xpath("//span[contains(@ng-show,'user.FullName') and @id='Span1']")).getText();
		
		RC_Global.navigateTo(driver, "Manage", "Mass Upload Portal", "");
        RC_Global.waitElementVisible(driver, 60, "//div//h3[text()='Mass Uploads']", "Mass Uploads",false,true);
		RC_Global.enterCustomerNumber(driver, cusno, "", "",true);
		RC_Manage.fileUpload(driver, curDir, curFilePath, selType, "", defTimeZon, userName, "");
		RC_Global.waitElementVisible(driver, 10, "//h4[contains(text(),'is not enrolled')]", " Customer selected is not enrolled in the Fuel Program, please review Customer�s Fuel Attributes.", false, true);
		
		RC_Global.clickUsingXpath(driver, "//div[@class='input-group'][1]/div/button", "Expand customer structure", false, false);
		RC_Global.clickUsingXpath(driver, "//span[text()='"+fleetNum+"']", "Fleet Level -> "+fleetNum+"", false, true);
		RC_Manage.fileUpload(driver, curDirFl, curFilePathFl, selType, "", defTimeZon, userName, "");
		
		RC_Global.clickUsingXpath(driver, "//div[@class='input-group'][1]/div/button", "Expand customer structure", false, false);
		RC_Global.clickUsingXpath(driver, "//span[text()='"+fleetNum+"']/../../i[1]", "Expand Fleet Level -> "+fleetNum+"", false, false);
		RC_Global.clickUsingXpath(driver, "//span[text()='"+acctNum+"']", "Account Level -> "+acctNum+"", false, true);
		RC_Manage.fileUpload(driver, curDirAc, curFilePathAc, selType, "", defTimeZon, userName, "");
		
		RC_Global.clickUsingXpath(driver, "//div[@class='input-group'][1]/div/button", "Expand customer structure", false, false);
		RC_Global.clickUsingXpath(driver, "//span[text()='"+acctNum+"']/../../i[1]", "Expand Accont Level -> "+acctNum+"", false, false);
		RC_Global.clickUsingXpath(driver, "//span[text()='"+subAcctNum+"']", "Sub Account Level -> "+subAcctNum+"", false, true);
		RC_Manage.fileUpload(driver, curDirSub, curFilePathSub, selType, "", defTimeZon, userName, "");
		
		RC_Manage.deleteAllFolder_Files(driver);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
