package Manage.MassUploadPortal.VehicleMovement;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.LeaseWave.RC_LW_Global;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_5_4_01 {
	public static void FieldsNotValidatedDuringUploadAndVehicleMovementToFleet_AccountAndSub_Account(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		String newFileName = ""; String curDir = "";
		String curFilePath = ""; String sptVal[] = null;
		String userName = ""; String defTimeZon = ""; String submitTime = "";		
		String fileDownload = ""; String downDir = ""; String downFilePath= "";
		String unitNumber = ""; String custNum = "LS007656";
		String fileName = "VehicleMovement-"+custNum+".xlsx";
			
		String[] fleetName = new String[10];
		String[] accountName = new String[10];
		String[] subAccountName = new String[10];
		RC_Manage.deleteFile_Downloads(driver, "VehicleMovement");
		RC_Manage.deleteAllFolder_Files(driver);
		RC_Global.login(driver);
		
		RC_Global.navigateTo(driver, "Manage", "Adminstration", "Customer Administration");
		RC_Global.waitUntilPanelVisibility(driver, "Customer Administration", "TV", true, true);
		RC_Global.waitElementVisible(driver, 30, "(//div[label[normalize-space(text())='Customer #']]/input)[1]", "Customer Number", true, false);
		
		RC_Global.enterCustomerNumber(driver, "LS007656", "", "", true);
		RC_Global.waitElementVisible(driver, 30, "//a[normalize-space(text())='Fuel']", "", true, false);
		RC_Global.clickUsingXpath(driver, "//a[normalize-space(text())='Fuel']", "", true, false);
		
		RC_Global.waitElementVisible(driver, 30, "//fieldset[@id='enrollment']/legend[text()='Enrollment']", "", true, false);
		String enrolledInFuel = driver.findElement(By.xpath("(//div[@id='fuelCustomer'])[2]/button[contains(@class,'active')]")).getText();
		
		if(enrolledInFuel.equalsIgnoreCase("Yes")) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify Customer is not enrolled in Fuel", "Customer is enrolled in Fuel", null);
		}
		else {
			queryObjects.logStatus(driver, Status.PASS, "Customer Administration - Fuel Verify Customer is not enrolled in Fuel", "Customer is not enrolled in Fuel", null);
		}	
		RC_Global.panelAction(driver, "close", "Customer Administration", true, false);
		
		RC_Global.navigateTo(driver, "Manage", "Administration", "Driver Data Change");
		RC_Global.waitUntilPanelVisibility(driver, "Driver Data Change", "TV", true, false);
		RC_Global.waitElementVisible(driver, 30, "//div[label[normalize-space(text())='Customer Number']]/input", "Customer Number", true, false);
		
		RC_Global.enterCustomerNumber(driver, custNum, "", "", true);
		RC_Global.clickButton(driver, "Search", true, true);
		
		RC_Global.waitElementVisible(driver, 60, "//table//tr[1]/td[1]", "Grid Load", true, false);
		List<WebElement> unitNumbers = driver.findElements(By.xpath("//table//tr[td[text()=' Active lease ']]/td[3]"));
		String selectedUnitNumbers = "";
		
		for(int i=0;i<5;i++) {
			if(i==0)
				selectedUnitNumbers = unitNumbers.get(i).getText();
			else
				selectedUnitNumbers = selectedUnitNumbers +";"+ unitNumbers.get(i).getText();
		}
		
		String rowChangeUnitNumbers = "";
		for(int i=5;i<7;i++) {
			if(i==5)
				rowChangeUnitNumbers = unitNumbers.get(i).getText();
			else
				rowChangeUnitNumbers = rowChangeUnitNumbers +";"+ unitNumbers.get(i).getText();
		}
		String[] rowChangeUnits = rowChangeUnitNumbers.split(";");
		
		RC_Global.panelAction(driver, "close", "Driver Data Change", true, false);
		
		RC_Global.navigateTo(driver, "Manage", "Mass Upload Portal", "");
		RC_Global.waitUntilPanelVisibility(driver, "Mass Upload Portal", "TV", true, false);
		RC_Global.waitElementVisible(driver, 30, "//div[label[normalize-space(text())='Customer Number']]/input", "Customer Number", true, false);
		
		RC_Global.enterCustomerNumber(driver, custNum, "", "", true);
		String downloadPath = RC_Manage.fileDownload(driver, "Vehicle Movement Upload", fileName);
		Thread.sleep(3000);
		if (downloadPath.contains(";")) {
        	sptVal = downloadPath.split(";");
        	curDir= sptVal[0];
        	newFileName = sptVal[1];
        	curFilePath = curDir+"\\"+newFileName;	
		}
		userName = driver.findElement(By.xpath("//span[contains(@ng-show,'user.FullName') and @id='Span1']")).getText();
		
		fleetName[0] = "2000";
		fleetName[1] = "2932";
		fleetName[2] = "2933";
		fleetName[3]= "10000";
		
		accountName[0] = "";
		accountName[1] = "2901";
		accountName[2] = "2903";
		accountName[3] = "1934";
		
		subAccountName[0] = "";
		subAccountName[1] = "";
		subAccountName[2] = "2493";
		subAccountName[3] = "2854";
		String fleetChange = RC_Manage.modifyCells_ColumnName_UnitNum(driver, curFilePath, "Moved to Fleet Number", 5, selectedUnitNumbers, "Update", fleetName[0]+";"+fleetName[1]+";"+fleetName[2]+";"+fleetName[3]+"; ");
		String accountChange = RC_Manage.modifyCells_ColumnName_UnitNum(driver, curFilePath, "Moved to Account Number", 5, selectedUnitNumbers, "Update"," ;"+accountName[1]+";"+accountName[2]+"; ;"+accountName[3]);
		String subAccountChange = RC_Manage.modifyCells_ColumnName_UnitNum(driver, curFilePath, "Moved to Sub-Account Number", 5, selectedUnitNumbers, "Update"," ; ;"+subAccountName[2]+"; ;"+subAccountName[3]);		
		RC_Manage.addValuesToAllColumnsExcept(driver, curFilePath, rowChangeUnits[0], "", "Moved to Fleet Number");
		RC_Manage.addValuesToAllColumnsExcept(driver, curFilePath, rowChangeUnits[1], "Random", "Moved to Fleet Number;Moved to Account Number;Moved to Sub-Account Number");
		RC_Manage.modifyCells_ColumnName_UnitNum(driver, curFilePath, "Moved to Fleet Number", 2, rowChangeUnitNumbers, "Update", fleetName[0]+";"+fleetName[1]);
		
		fleetChange = fleetChange.split(" ~~")[1];
		fleetChange = fleetChange+"__"+rowChangeUnits[0]+";"+fleetName[0]+"__"+rowChangeUnits[1]+";"+fleetName[1];
		String[] changedItem = fleetChange.split("__");
		String[] changedUnitNum = new String[10];
		String[] changedFleet = new String[10];
		
		for(int iter=0;iter<changedItem.length;iter++) {
			changedUnitNum[iter] = changedItem[iter].split(";")[0];
			changedFleet[iter] = changedItem[iter].split(";")[1];
			if(iter==0)
				unitNumber = changedUnitNum[0];
			else
				unitNumber = unitNumber+";"+changedUnitNum[iter];
		}
		submitTime = RC_Manage.fileUpload(driver, curDir, curFilePath, "Vehicle Movement Upload", "", defTimeZon, userName, "");    	
		Thread.sleep(3000);
		RC_Global.waitElementVisible(driver, 120, "(//div[@class='ui-grid-canvas'])[1]/div[1]//div[text()='100%']", "Upload Complete", true, false);
		RC_Manage.selectDownloadResults(driver, userName, submitTime, defTimeZon);//download the results file
    	
    	String[] unitSplit = selectedUnitNumbers.split(";");
    	String successUnits = unitSplit[0]+";"+unitSplit[1]+";"+unitSplit[2];
    	String errorUnits = unitSplit[3]+";"+unitSplit[4];
    	
    	fileDownload = RC_Manage.moveFileFromDownloads(driver, fileName, "DownloadedFiles", true);
        if (fileDownload.contains(";")) {
        	downDir = fileDownload.substring(0, fileDownload.indexOf(";"));
        	downFilePath = fileDownload.replace(";", "\\");
        }
		
        RC_Global.navigateTo(driver, "Manage", "Mass Upload Portal", "");
        RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='Mass Upload Portal']])[1]", true, true);
        RC_Global.panelAction(driver, "close", "Mass Upload Portal", true, true);
        
        WebElement unitNumber1 = null;
        String[] uNumber = unitNumber.split(";");
        
        for(int it=0;it<uNumber.length;it++) {
        	if (it==0) {
        		RC_Global.navigateTo(driver, "Manage", "Administration", "Vehicle Details");
            	Thread.sleep(2000);
        	}
            	unitNumber1 = driver.findElement(By.xpath("//div[label[text()='Unit Number']]/input"));
            	RC_Global.enterInput(driver, uNumber[it], unitNumber1, true, false);
            	RC_Global.clickButton(driver, "Search", true, true);
            	RC_Global.waitElementVisible(driver, 60, "//h5/span[text()='Vehicle Details']", "Vehicle Details", true, false);
            	
        	RC_Global.waitElementVisible(driver, 60, "//div[div[text()='Fleet:']]/div[2]", "Fleet Details", true, false);
        	String fleet = driver.findElement(By.xpath("//div[div[text()='Fleet:']]/div[2]")).getText().trim();
        	if(fleet.contains(changedFleet[it]))
        		queryObjects.logStatus(driver, Status.PASS, "Verify the change in Fleet Name", "Change in Fleet Name successful", null);
        	else {
        		if(it==3)
        			queryObjects.logStatus(driver, Status.PASS, "Verify the change in Fleet Name", "Change in Fleet Name is not successful --- Due to error while uploading", null);
            	
        		else
        			queryObjects.logStatus(driver, Status.FAIL, "Verify the change in Fleet Name", "Change in Fleet Name is not successful", null);
        	}
        	driver.findElement(By.id("vehicle-details-main-search")).click();
        	RC_Global.waitElementVisible(driver, 60, "(//h5/span[text()='Vehicle Details'])[2]", "Vehicle Details", true, false);
        	((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", driver.findElement(By.xpath("(//h5/span[text()='Vehicle Details'])[1]")));
        	 RC_Global.clickUsingXpath(driver, "(//h5/span[text()='Vehicle Details'])[1]/..//i[@ng-click='closePanel()']", "Close Vehicle Details", true, false);
        }
	        RC_Global.panelAction(driver, "close", "Vehicle Details", true, false);
	    for(int itn=0;itn<uNumber.length;itn++) {
	    	if (itn==0) {
	    		RC_Global.navigateTo(driver, "Billing", "Vehicle Movement", "");
		        Thread.sleep(2000);
		        unitNumber1 = driver.findElement(By.xpath("//div[label[text()='Unit Number']]/input"));
			}
	    	unitNumber1.clear();
	        RC_Global.enterInput(driver, uNumber[itn], unitNumber1, true, false);
	        RC_Global.clickButton(driver, "Search", true, true);
	        RC_Global.waitElementVisible(driver, 60, "(//table//tbody/tr[1])[1]", "Grid row", true, false);
	        RC_Global.clickUsingXpath(driver, "(//table//tbody/tr[1])[1]", "Grid row", true, false);	        
	        RC_Global.clickUsingXpath(driver, "//label[text()=' History ']", "History link", true, true);	        
	        RC_Global.panelAction(driver, "expand", "Vehicle Movement History", true, false);
	        String userFullName = driver.findElement(By.xpath("//span[span[@id='user-menu-name']]/span[1]")).getText();
	        if(driver.findElement(By.xpath("(//table//tr[td[text()='Vehicle Moved']])[1]/td[1]")).getText().contains(RC_Global.getDateTime(driver, "MMM dd, yyyy", 0, false))) {
	        	if(driver.findElement(By.xpath("(//table//tr[td[text()='Vehicle Moved']])[1]/td[3]")).getText().equalsIgnoreCase(userFullName)) {
			        
	        RC_Global.clickUsingXpath(driver, "(//td[text()='Vehicle Moved'])[1]", "Vehicle Moved", true, false);
	        String fleetNm = driver.findElement(By.xpath("(//table//tr//tbody/tr[2])[1]/td[3]")).getText();
	        if(changedFleet[itn].equalsIgnoreCase(fleetNm))
        		queryObjects.logStatus(driver, Status.PASS, "Verify the change in Fleet Name", "Change in Fleet Name successful", null);
        	else
        	{
        		if(itn==3)
        			queryObjects.logStatus(driver, Status.PASS, "Verify the change in Fleet Name", "Change in Fleet Name is not successful --- Due to error while uploading", null);
        		else
        			queryObjects.logStatus(driver, Status.FAIL, "Verify the change in Fleet Name", "Change in Fleet Name is not successful", null);
        	}
        }
    	else
    		queryObjects.logStatus(driver, Status.FAIL, "Verify the Username on the History screen", "Correct username is not present against the required change in the History screen", null);
    }
    else
		queryObjects.logStatus(driver, Status.FAIL, "Verify Todays' Date on the History screen", "Todays' Date is not present against the required change in the History screen", null);

	        RC_Global.panelAction(driver, "close", "Vehicle Movement History", true, false);
        }
	    RC_Global.panelAction(driver, "close", "Vehicle Movement", true, false);
        RC_Global.logout(driver, false);
        
        RC_LW_Global.leaseWaveLogin(driver, true);		
		for(int i=0;i<uNumber.length;i++) {
			
			if (i==0) {
				RC_Global.createNode(driver, "Driver Data Changes upload validations in LeaseWave - Portfolio Management_Asset Lists for UnitNumber - "+uNumber[i]);
				try {
		        	RC_Global.clickUsingXpath(driver,"//a[contains(text(),'Portfolio Management')]","Portfolio Management",true, true);
		            RC_Global.waitElementVisible(driver, 50, "//a[contains(text(),'Portfolio Management')]", "Portfolio Management",true, true);
		            RC_Global.clickUsingXpath(driver,"//td[@accesskey='3' and text()='.Asset']","Asset option",true, true);
		            RC_Global.clickUsingXpath(driver,"(//td[@accesskey='P']/div[text()='rofile'])[2]","Drivers",true, true);            
		            
		        } catch(Exception e) {
		    			queryObjects.logStatus(driver, Status.FAIL, "Navigate to Asset List page Failed", e.getLocalizedMessage(), e);	
		    			RC_Global.endTestRun(driver);
		        }
			}
			WebElement eleUnitNumber = driver.findElement(By.xpath("//tr[td[text()='Unit Number']]/td/input"));
			eleUnitNumber.clear();
	        RC_Global.enterInput(driver, uNumber[i], eleUnitNumber, true, true);
	        RC_Global.clickUsingXpath(driver, "//button[text()='Searc' and @accesskey='H']", "Search Button", true, true);
			Thread.sleep(3000);
			String fleetLW = driver.findElement(By.xpath("(//table[tbody[tr[td[div[table]]]]])[2]//td[19]")).getText();
	        
		if(changedFleet[i].equalsIgnoreCase(fleetLW))
			queryObjects.logStatus(driver, Status.PASS, "Verify the change in Fleet Name", "Change in Fleet Name successful", null);
		else
    	{
    		if(i==3)
    			queryObjects.logStatus(driver, Status.PASS, "Verify the change in Fleet Name", "Change in Fleet Name is not successful --- Due to error while uploading", null);
    		else
    			queryObjects.logStatus(driver, Status.FAIL, "Verify the change in Fleet Name", "Change in Fleet Name is not successful", null);
    	}		        
			 	
		}
		
		RC_LW_Global.leaseWaveLogOut(driver, true);		
        RC_Global.login(driver);
        RC_Global.navigateTo(driver, "Manage", "Mass Upload Portal", "");
        RC_Global.waitUntilPanelVisibility(driver, "Mass Upload Portal", "TV", true, false);
		RC_Global.waitElementVisible(driver, 30, "//div[label[normalize-space(text())='Customer Number']]/input", "Customer Number", true, false);
		
		RC_Global.enterCustomerNumber(driver, custNum, "", "", true);
        downloadPath = RC_Manage.fileDownload(driver, "Vehicle Movement Upload", fileName);
		Thread.sleep(3000);
		if (downloadPath.contains(";")) {
        	sptVal = downloadPath.split(";");
        	curDir= sptVal[0];
        	newFileName = sptVal[1];
        	curFilePath = curDir+"\\"+newFileName;	
		}
		fleetChange = RC_Manage.modifyCells_ColumnName_UnitNum(driver, curFilePath, "Moved to Fleet Number", 5, selectedUnitNumbers, "Update", fleetName[1]+";"+fleetName[2]+";"+fleetName[0]+";"+fleetName[1]+"; ");
		accountChange = RC_Manage.modifyCells_ColumnName_UnitNum(driver, curFilePath, "Moved to Account Number", 5, selectedUnitNumbers, "Update"," ; ; ; ; ");
		subAccountChange = RC_Manage.modifyCells_ColumnName_UnitNum(driver, curFilePath, "Moved to Sub-Account Number", 5, selectedUnitNumbers, "Update"," ; ; ; ; ");
			
		RC_Manage.modifyCells_ColumnName_UnitNum(driver, curFilePath, "Moved to Fleet Number", 2, rowChangeUnitNumbers, "Update", fleetName[1]+";"+fleetName[0]);
		
		Thread.sleep(2000);
		submitTime = RC_Manage.fileUpload(driver, curDir, curFilePath, "Vehicle Movement Upload", "", defTimeZon, userName, "");    	
		Thread.sleep(3000);
		RC_Global.waitElementVisible(driver, 120, "(//div[@class='ui-grid-canvas'])[1]/div[1]//div[text()='100%']", "Upload Complete", true, false);
		
		RC_Global.panelAction(driver, "close", "Mass Upload Portal", true, false);
        
	}
}
