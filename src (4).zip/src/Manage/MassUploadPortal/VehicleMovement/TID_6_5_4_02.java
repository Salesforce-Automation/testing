package Manage.MassUploadPortal.VehicleMovement;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.LeaseWave.RC_LW_Global;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_5_4_02 {
	public static void CurrentVehicleAssignedToNodeOfStructure_UniqueIdentifierValidation_MandatoryClientDataIsNotAssigned(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		String newFileName = ""; String curDir = "";
		String curFilePath = ""; String sptVal[] = null;
		String userName = ""; String defTimeZon = ""; String submitTime = ""; String uploadedTime = ""; 
		String custNum = "LS007656";
		String fileName = "VehicleMovement-"+custNum+".xlsx";
		String fileDownload = ""; String downDir = ""; String downFilePath= "";
		String unitNumber = ""; String sptUnits[] = null; String errUnitNos = "";String updUnitNos = ""; String valDate = null;
			
		String[] fleetName = new String[10];
		String[] accountName = new String[10];
		String[] subAccountName = new String[10];
		RC_Manage.deleteFile_Downloads(driver, "VehicleMovement");
		RC_Manage.deleteAllFolder_Files(driver);
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Mass Upload Portal", "");
		RC_Global.waitUntilPanelVisibility(driver, "Mass Upload Portal", "TV", true, false);
		RC_Global.waitElementVisible(driver, 30, "//div[label[normalize-space(text())='Customer Number']]/input", "Customer Number", true, false);
		
		RC_Global.enterCustomerNumber(driver, custNum, "", "", true);
		
		String downloadPath = RC_Manage.fileDownload(driver, "Vehicle Movement Upload", fileName);
		Thread.sleep(3000);
		if (downloadPath.contains(";")) {
        	sptVal = downloadPath.split(";");
        	curDir= sptVal[0];
        	newFileName = sptVal[1];
        	curFilePath = curDir+"\\"+newFileName;	
		}
		userName = driver.findElement(By.xpath("//span[contains(@ng-show,'user.FullName') and @id='Span1']")).getText();
		
		RC_Global.panelAction(driver, "close", "Mass Upload Portal", true, true);
		
		RC_Global.navigateTo(driver, "Manage", "Administration", "Client Data Setup");
		RC_Global.waitElementVisible(driver, 30, "//div[label[normalize-space(text())='Customer Number']]/input", "Customer Number", true, false);
		RC_Global.enterCustomerNumber(driver, custNum, "", "", true);
		RC_Global.clickButton(driver, "Add New Client Data", true, true);
		
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Name *']]//input", "Name Input", true, false);
		
		WebElement element = driver.findElement(By.xpath("//div[label[text()='Name *']]//input"));
		RC_Global.enterInput(driver, "Test AutoData "+RandomStringUtils.randomNumeric(2), element, true, true);
		
		RC_Global.clickUsingXpath(driver, "//div[label[text()='Mandatory']]//input", "Mandatory checkbox", true, false);
		
		RC_Global.clickButton(driver, "Save", true, true);
		RC_Global.waitElementVisible(driver, 30, "//h4[text()='Update Successful']", "Save Successful", true, true);

		RC_Global.panelAction(driver, "close", "Client Data Setup", true, true);
		
		RC_Global.navigateTo(driver, "Billing", "Vehicle Movement", "");
		RC_Global.waitElementVisible(driver, 30, "//div[label[normalize-space(text())='Customer Number']]/input", "Customer Number", true, false);
		RC_Global.enterCustomerNumber(driver, custNum, "", "", true);
		
		WebElement driverName = driver.findElement(By.xpath("//div[label[text()='Driver First Name']]/input"));
		RC_Global.enterInput(driver, "Unassigned", driverName, true, false);
		
		RC_Global.clickButton(driver, "Search", true, true);
		Thread.sleep(1000);
		
		RC_Global.waitElementVisible(driver, 30, "(//table/tbody/tr)[1]", "Result Grid", true, false);
		String unassignedUnitNumber = driver.findElement(By.xpath("(//tr[td[text()=' Unassigned ']]/td[3])[6]")).getText().trim();

		RC_Global.clickButton(driver, "Reset", true, false);
		
		RC_Global.enterCustomerNumber(driver, custNum, "", "", true);
		
		RC_Global.clickButton(driver, "Search", true, true);
		Thread.sleep(1000);
		
		RC_Global.waitElementVisible(driver, 30, "(//table/tbody/tr)[1]", "Result Grid", true, false);
		List<WebElement> unitNumbers = driver.findElements(By.xpath("//table//tr/td[3]"));
		for(int itn=0;itn<unitNumbers.size();itn++) {
			if(!unitNumbers.get(itn).getText().equalsIgnoreCase(unassignedUnitNumber)) {
				RC_Global.clickUsingXpath(driver, "(//table/tbody/tr)["+itn+"]", "First Grid Result", true, true);
				break;
			}
		}
		Thread.sleep(2000);
		RC_Global.panelAction(driver, "close", "Driver Details", true, false);
		RC_Global.panelAction(driver, "expand", "Vehicle Movement", true, false);
		
		RC_Global.clickButton(driver, "Initiate Vehicle Movement", true, true);
		
		RC_Global.waitElementVisible(driver, 30, "//legend[text()='New Customer Structure Assignment']", "New Customer Structure Assignement", true, false);
		Thread.sleep(3000);
		
		String changedFleet = driver.findElement(By.xpath("(//div[@class='tree-label ']/span)[1]")).getText();
		String changedFleetNum = changedFleet.split(" - ")[0];
		RC_Global.clickUsingXpath(driver, "(//div[@class='tree-label ']/span)[1]", "New Employee Assignment", true, false);
		String toChangeToFleet = driver.findElement(By.xpath("(//div[@class='tree-label ' ]/span)[3]")).getText();
		String toChangeToFleetNum = toChangeToFleet.split(" - ")[0];
		RC_Global.clickUsingXpath(driver, "(//div[@class='tree-label ' ]/span)[3]/ancestor::li[1]/i[1]", "Arrow", true, false);
		Thread.sleep(2000);
		String toChangeToAccount = driver.findElement(By.xpath("(//li[div[@class='tree-label ']])[3]//li[1]//span")).getText();
		String toChangeToAccountNum = toChangeToAccount.split(" - ")[0];
		Thread.sleep(2000);
		
		RC_Global.clickUsingXpath(driver, "(//li[div[@class='tree-label ' ]])[3]//li[1]/i[1]", "Arrow", true, false);
		String toChangeToSubAccount = driver.findElement(By.xpath("(//li[div[@class='tree-label ' ]])[3]//li[1]//li//span")).getText();
		String toChangeToSubAccountNum = toChangeToSubAccount.split(" - ")[0];
		
		RC_Global.clickUsingXpath(driver, "(//button[text()='Next'])[2]", "Next button", true, true);
		Thread.sleep(2000);
		
		RC_Global.clickUsingXpath(driver, "(//button[text()='Submit '])[1]", "Submit button", true, true);
		RC_Global.waitElementVisible(driver, 30, "//h2[text()='Your vehicle move is complete!']", "Vehicle Movement Complete", true, true);
		
		String iUnitNumber = driver.findElement(By.xpath("//p/a[@ng-click='openVehicleDetails()']")).getText().trim();
		RC_Global.panelAction(driver, "close", "Vehicle Movement - Confirmation", true, true);
		
		RC_Global.navigateTo(driver, "Manage", "Mass Upload Portal", "");
		Thread.sleep(2000);
		RC_Global.enterCustomerNumber(driver, custNum, "", "", true);
		String fleetChange = RC_Manage.modifyCells_ColumnName_UnitNum(driver, curFilePath, "Moved to Fleet Number", 1, iUnitNumber, "Update", toChangeToFleetNum);
		String accountChange = RC_Manage.modifyCells_ColumnName_UnitNum(driver, curFilePath, "Moved to Account Number", 1, iUnitNumber, "Update",toChangeToAccountNum);
		String subAccountChange = RC_Manage.modifyCells_ColumnName_UnitNum(driver, curFilePath, "Moved to Sub-Account Number", 1, iUnitNumber, "Update",toChangeToSubAccountNum);
		
		String iter = RandomStringUtils.randomNumeric(1);
		if(iter.equalsIgnoreCase("0"))iter="3";
		
//		int i = Integer.parseInt(iter);
//		if(i>sFleetNum.length)i=sFleetNum.length;
//		sFleetNum[i];
		fleetChange = RC_Manage.modifyCells_ColumnName_UnitNum(driver, curFilePath, "Moved to Fleet Number", 1, unassignedUnitNumber, "Update", changedFleetNum);
		submitTime = RC_Manage.fileUpload(driver, curDir, curFilePath, "Vehicle Movement Upload", "", defTimeZon, userName, "");    	
		Thread.sleep(3000);
		RC_Global.waitElementVisible(driver, 120, "(//div[@class='ui-grid-canvas'])[1]/div[1]//div[text()='100%']", "Upload Complete", true, false);
		uploadedTime = RC_Manage.selectDownloadResults(driver, userName, submitTime, defTimeZon);//download the results file
    	if (defTimeZon.equalsIgnoreCase("CST") || defTimeZon.equalsIgnoreCase("America/Chicago")) {
    		valDate = RC_Manage.driverHistory_DateFormat(driver, queryObjects, uploadedTime, "No");
		} 
    	else {
			valDate = RC_Manage.driverHistory_DateFormat(driver, queryObjects, uploadedTime, "Yes");
		}
    	fileDownload = RC_Manage.moveFileFromDownloads(driver, fileName, "DownloadedFiles", true);
        if (fileDownload.contains(";")) {
        	downDir = fileDownload.substring(0, fileDownload.indexOf(";"));
        	downFilePath = fileDownload.replace(";", "\\");
        }
        
//        RC_Global.navigateTo(driver, "Manage", "Administration", "Vehicle Details");
        
        Thread.sleep(2000);
        RC_Global.panelAction(driver, "close", "Mass Upload Portal", true, false);
        
        RC_Global.logout(driver, true);
        RC_Global.login(driver);
        
        WebElement unitNumber1 = null;
        String[] uNumber = {iUnitNumber,unassignedUnitNumber};
        String[] changedFleets = {toChangeToFleet,changedFleet};
        for(int itera=0;itera<2;itera++) {
			
        	if (itera==0) {
        		RC_Global.navigateTo(driver, "Manage", "Administration", "Vehicle Details");
            	Thread.sleep(2000);
        	}
	    	unitNumber1 = driver.findElement(By.xpath("//div[label[text()='Unit Number']]/input"));
	    	RC_Global.enterInput(driver, uNumber[itera], unitNumber1, true, false);
	    	RC_Global.clickButton(driver, "Search", true, true);
	    	RC_Global.waitElementVisible(driver, 60, "//h5/span[text()='Vehicle Details']", "Vehicle Details", true, false);
	    	RC_Global.waitElementVisible(driver, 60, "//div[div[text()='Fleet:']]/div[2]", "Fleet Details", true, false);
	    	String fleet = driver.findElement(By.xpath("//div[div[text()='Fleet:']]/div[2]")).getText().trim();
	    	if(fleet.contains(changedFleets[itera]))
	    		queryObjects.logStatus(driver, Status.PASS, "Verify the change in Fleet Name", "Change in Fleet Name successful", null);
	    	else {
	    		queryObjects.logStatus(driver, Status.FAIL, "Verify the change in Fleet Name", "Change in Fleet Name is not successful", null);
	    	}
	    	driver.findElement(By.id("vehicle-details-main-search")).click();
        	RC_Global.waitElementVisible(driver, 60, "(//h5/span[text()='Vehicle Details'])[2]", "Vehicle Details", true, false);
        	((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", driver.findElement(By.xpath("(//h5/span[text()='Vehicle Details'])[1]")));
        	 RC_Global.clickUsingXpath(driver, "(//h5/span[text()='Vehicle Details'])[1]/..//i[@ng-click='closePanel()']", "Close Vehicle Details", true, false);
        	}
	        RC_Global.panelAction(driver, "close", "Vehicle Details", true, false);
	     for(int it=0;it<2;it++) {
	    	 if (it==0) {
		    		RC_Global.navigateTo(driver, "Billing", "Vehicle Movement", "");
			        Thread.sleep(2000);
			        unitNumber1 = driver.findElement(By.xpath("//div[label[text()='Unit Number']]/input"));
				}
		    unitNumber1.clear();
	        RC_Global.enterInput(driver, uNumber[it], unitNumber1, true, false);
	        RC_Global.clickButton(driver, "Search", true, true);
	        RC_Global.waitElementVisible(driver, 60, "(//table//tbody/tr[1])[1]", "Grid row", true, false);
	        RC_Global.clickUsingXpath(driver, "(//table//tbody/tr[1])[1]", "Grid row", true, false);
	        if(driver.findElements(By.xpath("//h5[span[text()='Driver Details']]/i[@ng-click='closePanel()']")).size()>0) {
	        	RC_Global.panelAction(driver, "close", "Driver Details", true, false);
	        	RC_Global.panelAction(driver, "expand", "Vehicle Movement", true, false);
	        }
	        RC_Global.clickUsingXpath(driver, "//label[text()=' History ']", "History link", true, true);
	        RC_Global.panelAction(driver, "expand", "Vehicle Movement History", true, false);
	        
	        RC_Global.clickUsingXpath(driver, "(//td[text()='Vehicle Moved'])[1]", "Vehicle Moved", true, false);
	        String fleetNm = driver.findElement(By.xpath("(//table//tr//tbody/tr[2])[1]/td[3]")).getText();
	        if(changedFleets[it].contains(fleetNm))
	    		queryObjects.logStatus(driver, Status.PASS, "Verify the change in Fleet Name", "Change in Fleet Name successful", null);
	    	else
	    	{
	    		queryObjects.logStatus(driver, Status.FAIL, "Verify the change in Fleet Name", "Change in Fleet Name is not successful", null);
	    	}
	        RC_Global.panelAction(driver, "close", "Vehicle Movement History", true, false);
	    }
	     RC_Global.panelAction(driver, "close", "Vehicle Movement", true, false);	     
		RC_Global.logout(driver, false);
		
		String fleetLW = "";
		RC_LW_Global.leaseWaveLogin(driver, true);		
		for(int in=0;in<uNumber.length;in++) {
			if (in==0) {
				RC_Global.createNode(driver, "Driver Data Changes upload validations in LeaseWave - Portfolio Management_Asset Lists for UnitNumber - "+uNumber[in]);
				try {
		        	RC_Global.clickUsingXpath(driver,"//a[contains(text(),'Portfolio Management')]","Portfolio Management",true, true);
		            RC_Global.waitElementVisible(driver, 50, "//a[contains(text(),'Portfolio Management')]", "Portfolio Management",true, true);
		            RC_Global.clickUsingXpath(driver,"//td[@accesskey='3' and text()='.Asset']","Asset option",true, true);
		            RC_Global.clickUsingXpath(driver,"(//td[@accesskey='P']/div[text()='rofile'])[2]","Drivers",true, true);            
		            
		        } catch(Exception e) {
		    			queryObjects.logStatus(driver, Status.FAIL, "Navigate to Asset List page Failed", e.getLocalizedMessage(), e);	
		    			RC_Global.endTestRun(driver);
		        }
			}
			 	WebElement eleUnitNumber = driver.findElement(By.xpath("//tr[td[text()='Unit Number']]/td/input"));		        
		        RC_Global.enterInput(driver, uNumber[in], eleUnitNumber, true, true);
		        RC_Global.clickUsingXpath(driver, "//button[text()='Searc' and @accesskey='H']", "Search Button", true, true);
				Thread.sleep(3000);
				fleetLW = driver.findElement(By.xpath("(//table[tbody[tr[td[div[table]]]]])[2]//td[19]")).getText();
		        
			if(changedFleets[in].contains(fleetLW))
				queryObjects.logStatus(driver, Status.PASS, "Verify the change in Fleet Name", "Change in Fleet Name successful", null);
			else
			{
				queryObjects.logStatus(driver, Status.FAIL, "Verify the change in Fleet Name", "Change in Fleet Name is not successful", null);
			}
		}
		
		RC_LW_Global.leaseWaveLogOut(driver, true);
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Billing", "Vehicle Movement", "");
		RC_Global.waitElementVisible(driver, 30, "//div[label[normalize-space(text())='Customer Number']]/input", "Customer Number", true, false);
		RC_Global.enterCustomerNumber(driver, custNum, "", "", true);
		WebElement unitNumberInp = driver.findElement(By.xpath("//div[label[text()='Unit Number']]/input"));
		RC_Global.enterInput(driver, iUnitNumber, unitNumberInp, true, false);
		
		RC_Global.clickButton(driver, "Search", true, true);
		Thread.sleep(1000);
		
		RC_Global.waitElementVisible(driver, 30, "(//table/tbody/tr)[1]", "Result Grid", true, false);
		
		RC_Global.clickUsingXpath(driver, "(//table/tbody/tr)[1]", "First Grid Result", true, true);
		
		Thread.sleep(2000);
		RC_Global.panelAction(driver, "close", "Driver Details", true, false);
		RC_Global.panelAction(driver, "expand", "Vehicle Movement", true, false);
		
		RC_Global.clickButton(driver, "Initiate Vehicle Movement", true, true);
		
		RC_Global.waitElementVisible(driver, 30, "//legend[text()='New Customer Structure Assignment']", "New Customer Structure Assignement", true, false);
		Thread.sleep(3000);
		
		RC_Global.clickUsingXpath(driver, "(//div[@class='tree-label ']/span)[1]", "New Employee Assignment", true, false);
		RC_Global.clickUsingXpath(driver, "(//button[text()='Next'])[2]", "Next button", true, true);
		Thread.sleep(2000);
		
		RC_Global.clickUsingXpath(driver, "(//button[text()='Submit '])[1]", "Submit button", true, true);
		RC_Global.waitElementVisible(driver, 30, "//h2[text()='Your vehicle move is complete!']", "Vehicle Movement Complete", true, true);
		
		RC_Global.panelAction(driver, "close", "Vehicle Movement - Confirmation", true, true);
		
	}
}
