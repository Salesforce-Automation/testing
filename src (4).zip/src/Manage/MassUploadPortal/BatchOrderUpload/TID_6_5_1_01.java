package Manage.MassUploadPortal.BatchOrderUpload;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_5_1_01 {
	public void BatchOrderUpload_VerifyOMBatchUploadProcess(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		String defTimeZon = "";String retVal = "";String sptVal[] = null;String curFilePath = "";String newFileName = "";
		String curDir = "";String cusno= "LS008320";String submitTime = "";String userName = "";
		String selType = "Batch Order Upload";
		String Filename="BatchOrderUpload-"+cusno+".xlsx";
		
		
		defTimeZon = java.util.TimeZone.getDefault().getID();
		
		RC_Manage.deleteFile_Downloads(driver, "BatchOrderUpload");
		RC_Manage.deleteAllFolder_Files(driver);
		RC_Global.login(driver);
        RC_Global.navigateTo(driver, "Manage", "Mass Upload Portal", "");
		
		RC_Global.waitElementVisible(driver, 60, "//div//h3[text()='Mass Uploads']", "Mass Uploads",false,true);
		RC_Global.enterCustomerNumber(driver, "LS008320", "", "",true);
		retVal = RC_Manage.fileDownload(driver, selType, Filename);
		 if (retVal.contains(";")) {
	        	sptVal = retVal.split(";");
	        	curDir= sptVal[0];
	        	newFileName = sptVal[1];
	        	curFilePath = curDir+"\\"+newFileName;
		 }
//		 RC_Manage.fillBlankCellValues(driver, curFilePath, "red");
		 
//		 String path = curDir+"\\"+newFileName;
		/* FileInputStream fs = new FileInputStream("C:\\MFAutoScripts\\BatchOrderExcel\\BatchOrderUpload-LS008320 - REGRESSION FILE.xlsx");
		 Workbook wb = new XSSFWorkbook(fs);
		 Sheet sheet1 = wb.getSheetAt(2);
		 int lastRow = sheet1.getLastRowNum();
		 for(int i=0; i<=lastRow; i++){
		 Row row = sheet1.getRow(i);
		 Cell cell = row.createCell(6);
		 cell.setCellValue("WriteintoExcel");
		 }
		 FileOutputStream fos = new FileOutputStream(curFilePath);
		 wb.write(fos);
		 fos.close();*/
		 
		 String excelFilePath = "C:\\MFAutoScripts\\BatchOrderExcel\\BatchOrderUpload-LS008320 - REGRESSION FILE.xlsx";	
		 String excelopFilePath = curFilePath;
			String copySheetName = "Batch Order";
		 RC_Manage.getExcelData(excelFilePath,excelopFilePath, copySheetName, 5, 11);
		
		 
		                      
		 
//		 XSSFWorkbook workbook = new XSSFWorkbook(new FileInputStream(curDir+"\\"+newFileName));
//		    XSSFSheet sheet = workbook.getSheet("Batch Order");
////		    XSSFWorkbook workbook1 = new XSSFWorkbook(new FileInpinthutStream("C:\\MFAutoScripts\\BatchOrderExcel\\BatchOrderUpload-LS008320 - REGRESSION FILE.xlsx"));
//		    RC_Manage.copyRowExistingToDownload(workbook, sheet, 5, sheet, 11, false);
//		    FileOutputStream out = new FileOutputStream("C:\\MFAutoScripts\\BatchOrderExcel\\BatchOrderUpload-LS008320 - REGRESSION FILE.xlsx");
//		RC_Manage.copyRowExistingToDownload(driver, curDir+"\\BatchOrderUpload-LS008320 - REGRESSION FILE.xlsx", 5, curDir+"\\"+newFileName, 11, false);
		
		 userName = driver.findElement(By.xpath("//span[contains(@ng-show,'user.FullName') and @id='Span1']")).getText();
		 submitTime = RC_Manage.fileUpload(driver, curDir, curFilePath, selType, "", defTimeZon, userName, "");
		 RC_Global.logout(driver, false);	
			queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}

}
