package Manage.MassUploadPortal.DriverPoolAssignmentUpload;

import java.io.FileInputStream;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_5_3_01 {
	public void FieldsReturnedInDriver_PoolAssignmentDownloadTemplateAndDriver_Pool_UnitNumberAscending(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		String menu = "Manage";
		String firstSubMenu = "Mass Upload Portal";
		String CustomerNumber = "LS010143"; 
		String selType = "Driver/Pool Assignment Upload"; 
		String Filename="DriverPoolAssignment-"+CustomerNumber+".xlsx"; String curFilePath = "";
		String sptVal[] = null;	String retVal = "";String newFileName = ""; String curDir = "";
		String colNames = "Results;Reason;Unit Number;CVN;VIN;Year;Make;Model;Driver/Pool Name;Apply Driver Address to Vehicle Address;Address Validation Override;Vehicle Address 1;Vehicle Address 2;Vehicle Address City;Vehicle Address State;Vehicle Address Zip Code;Vehicle Address County;Vehicle Address Country;Fleet Number;Fleet Name;Account Number;Account Name;Sub-Account Number;Sub-Account Name";
		String colNamesCol = "Unit Number;CVN;VIN;Year;Make;Model;Driver/Pool Name;Apply Driver Address to Vehicle Address;Address Validation Override;Vehicle Address 1;Vehicle Address 2;Vehicle Address City;Vehicle Address State;Vehicle Address Zip Code;Vehicle Address County;Vehicle Address Country;Fleet Number;Fleet Name;Account Number;Account Name;Sub-Account Number;Sub-Account Name";

		ArrayList<String> UnitNumList=new ArrayList<String>();
		String colName = ""; boolean UnitNumPr =false;
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,"");
		RC_Global.waitElementVisible(driver, 30,"//h3[text()='Mass Uploads']", "Mass Upload Portal", true, true);
		RC_Global.enterCustomerNumber(driver,CustomerNumber, "", "", true);
		retVal = RC_Manage.fileDownload(driver, selType, Filename);
		RC_Global.createNode(driver, "Customer level Validations in downloaded DriverPoolAssignment excel file");
		 if (retVal.contains(";")) {
	        	sptVal = retVal.split(";");
	        	curDir= sptVal[0];
	        	newFileName = sptVal[1];
	        	curFilePath = curDir+"\\"+newFileName;
		RC_Manage.validateColumnNames(driver, curDir+"\\"+newFileName, Filename, colNamesCol);
		RC_Manage.columnHeadingBGColorValidation(driver, curFilePath, colNames);
		UnitNumList = RC_Manage.sorting_ColumnNames(driver, curDir+"\\"+newFileName, "Unit Number");
		 }
		 
		RC_Global.panelAction(driver, "close", "Mass Upload Portal", false, true);		
		RC_Global.navigateTo(driver,menu,firstSubMenu,"");
		RC_Global.enterCustomerNumber(driver, CustomerNumber,"", "Fleet level", true);
		String SubLeve = driver.findElement(By.xpath("//label[normalize-space(text())='Customer Number']/following::input[2]")).getAttribute("value");
		String filename1 ="DriverPoolAssignment-"+SubLeve+".xlsx";
		retVal = "";
		retVal = RC_Manage.fileDownload(driver, selType, filename1);
		RC_Global.createNode(driver, "Fleet level Validations in downloaded DriverPoolAssignment excel file");
		 if (retVal.contains(";")) {
	        	sptVal = retVal.split(";");
	        	curDir= sptVal[0];
	        	newFileName = sptVal[1];
	        	curFilePath = curDir+"\\"+newFileName;
	        	
	        	RC_Manage.validateColumnNames(driver, curDir+"\\"+newFileName, Filename, colNamesCol);
	    		RC_Manage.columnHeadingBGColorValidation(driver, curFilePath, colNames);
	    		RC_Manage.sorting_ColumnNames(driver, curDir+"\\"+newFileName, "Unit Number");
	    		 FileInputStream fis = new FileInputStream(curFilePath); 
	             XSSFWorkbook wb = new XSSFWorkbook(fis); 
	             ArrayList<String> UnitNumListSubNode=new ArrayList<String>();
	             XSSFSheet sh = wb.getSheetAt(1);
	             int roww = sh.getLastRowNum();   int roww1= sh.getLastRowNum();
	             Boolean columnValue = false;
	             	for (int i = 5; i < roww+1; i++) {
	             		XSSFCell ccell = sh.getRow(i).getCell(2);
	             		colName = ccell.getStringCellValue();	
	             		UnitNumListSubNode.add(colName);
	             		}
	             	fis.close();
	                
	             	
	            for (int i=0;i<UnitNumListSubNode.size();i++) 	{
	            	 for (int j=0;j<=UnitNumList.size();j++) {
	            		 if(UnitNumListSubNode.get(i).contains(UnitNumList.get(j))) {
	            			 UnitNumPr =true;
	            			 break;
	            		 }
	            		 else {
	            			 UnitNumPr = false;
	            		 }
	            	 }
	            }
	            if(UnitNumPr)
	            	queryObjects.logStatus(driver, Status.PASS, "Customer Number UnitNumber list has all UnitNumbers listed in Subaccount level", "", null);
	    		else {
	                queryObjects.logStatus(driver, Status.FAIL, "Customer Number UnitNumber list does not have all UnitNumbers listed in Subaccount level", "", null);
	                RC_Global.endTestRun(driver);
	    		}
	        	
		 }
        	
		RC_Global.panelAction(driver, "close", "Mass Upload Portal", false, true);
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}
}
