package Manage.MassUploadPortal.DriverPoolAssignmentUpload;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import MF.Source.Cred;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;


public class TID_6_5_3_04 {
	public void MandatoryCDFfieldsAndAddressValidationOfDriver_PoolAssignmentTemplate (WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		String menu = "Manage";
		String firstSubMenu = "Mass Upload Portal";
		String CustomerNumber = "LS008742";  String downFilePath = "";
		String selType = "Driver/Pool Assignment Upload"; String fileDownload="";String downDir = "";
		String Filename="DriverPoolAssignment-"+CustomerNumber+".xlsx"; String curFilePath = ""; String submitTime = "";
		String sptVal[] = null;	String retVal = "";String newFileName = ""; String curDir = "";String defTimeZone = "";String userName = "";
		defTimeZone = java.util.TimeZone.getDefault().getID();
		String rowVals = "";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,"");
		RC_Global.waitElementVisible(driver, 30,"//h3[text()='Mass Uploads']", "Mass Upload Portal", true,false);
		RC_Global.enterCustomerNumber(driver,CustomerNumber, "", "", true);
		retVal = RC_Manage.fileDownload(driver, selType, Filename);
		 if (retVal.contains(";")) {
	        	sptVal = retVal.split(";");
	        	curDir= sptVal[0];
	        	newFileName = sptVal[1];
	        	curFilePath = curDir+"\\"+newFileName;	}
		
		RC_Manage.addressValidationOverrideColumnsData(driver, curFilePath,8,2,"No","SPLIT","","Yes",false);
		RC_Manage.addressValidationOverrideColumnsData(driver, curFilePath,10,2,"Yes","SPLIT","","",false);
		RC_Manage.addressValidationOverrideColumnsData(driver, curFilePath,12,2,"No","11111","","",false);
		RC_Manage.addressValidationOverrideColumnsData(driver, curFilePath,14,2,"Yes","11111","","",false);
		RC_Manage.addressValidationOverrideColumnsData(driver, curFilePath,16,2,"No","","","Yes",false);
		RC_Manage.addressValidationOverrideColumnsData(driver, curFilePath,18,2,"Yes","","","Yes",false);
		RC_Manage.addressValidationOverrideColumnsData(driver, curFilePath,20,2,"No","1111","abcd","",false);
		RC_Manage.addressValidationOverrideColumnsData(driver, curFilePath,22,2,"Yes","","abcd","",false);
		RC_Manage.ModifyNonMandatoryClientData(driver, curFilePath,25,2, true);
		RC_Manage.ModifyMandatoryFields(driver, curFilePath,30,2, true);
		
		userName = driver.findElement(By.xpath("//span[contains(@ng-show,'user.FullName') and @id='Span1']")).getText();
		submitTime = RC_Manage.fileUpload(driver, curDir, curFilePath, selType, "", defTimeZone, userName, "");
    	RC_Manage.selectDownloadResults(driver, userName, submitTime, defTimeZone);//download file
    	fileDownload = RC_Manage.moveFileFromDownloads(driver, Filename, "DownloadedFiles", true);
         if (fileDownload.contains(";")) {
        	downDir = fileDownload.substring(0, fileDownload.indexOf(";"));
        	downFilePath = fileDownload.replace(";", "\\");
        	RC_Manage.validateUploadChanges(driver, downFilePath, RC_Manage.UnitNumberAOY, "Success");	
        	RC_Manage.validateUploadChanges(driver, downFilePath, RC_Manage.UnitNumberAON, "Error");	
		}
        Thread.sleep(2000);
        RC_Global.panelAction(driver, "close", "Mass Upload Portal", true,true);
        
        	RC_Global.navigateTo(driver,menu,"Administration","Driver Data Change");
        	int getRowNum ;	WebElement zip ;
        	String[] Unum = RC_Manage.UnitNumberAOY.split(";");
        	String[] Unums = RC_Manage.UnitNumberAON.split(";");
        	String[] Unums1 = RC_Manage.UnitNumber.split(";");
        	
        	RC_Global.enterCustomerNumber(driver,CustomerNumber, "", "", true);
        	RC_Global.clickButton(driver,"Search", true,true);
        	RC_Global.waitElementVisible(driver, 30, "//tbody//tr[1]","Grid load", true,true);
        	
        	
        	RC_Global.createNode(driver, "Validate ClientData in driverDataChange page for records with Address Validation Override field set as Yes");
        	for(int i=0;i<Unum.length;i++) {
        	List<WebElement> UnitNum = driver.findElements(By.xpath("//tbody//td[contains(text(),'"+Unum[i]+"')]"));
        	if(UnitNum.size()>0) {
        	switch(i) {
        	case 0: 
        		RC_Manage.clientDataFieldValidation(driver, "zipcode", Unum[0]);      
        		break;
        	case 1: 
        		RC_Manage.clientDataFieldValidation(driver, "zipcode", Unum[1]);   
        		break;
        	case 2: 
        		RC_Manage.clientDataFieldValidation(driver, "zipcode", Unum[2]); 
        		break;
        	case 3: 
        		RC_Manage.clientDataFieldValidation(driver, "zipcode", Unum[3]); 
        		break;
        	case 4: 
        		RC_Manage.clientDataFieldValidation(driver, "Address", Unum[4]); 
        		break;
        	case 5: 
        		RC_Manage.clientDataFieldValidation(driver, "Address", Unum[5]);  
        		break;
        		}
        	}       
}
        	RC_Global.createNode(driver, "Validate ClientData in driverDataChange page for records with Address Validation Override field set as No");
        	for(int i=0;i<Unums.length;i++) {
        	List<WebElement> UnitNums = driver.findElements(By.xpath("//tbody//td[contains(text(),'"+Unums[i]+"')]"));
        	if(UnitNums.size()>0) {
        	switch(i) {
        	case 0: 
        		RC_Manage.clientDataFieldValidationforAddValOvr(driver, "zipcode", Unums[0]);      
        		break;
        	case 1: 
        		RC_Manage.clientDataFieldValidationforAddValOvr(driver, "zipcode", Unums[1]);   
        		break;
        	case 2: 
        		RC_Manage.clientDataFieldValidationforAddValOvr(driver, "zipcode", Unums[2]); 
        		break;
        	case 3: 
        		RC_Manage.clientDataFieldValidationforAddValOvr(driver, "zipcode", Unums[3]); 
        		break;
        	case 4: 
        		RC_Manage.clientDataFieldValidationforAddValOvr(driver, "Address", Unums[4]); 
        		break;
        	case 5: 
        		RC_Manage.clientDataFieldValidationforAddValOvr(driver, "Address", Unums[5]);  
        		break;
        		}
        	}       }
        	
        	RC_Global.createNode(driver, "Validate ClientData in driverDataChange page for records with Address Validation Override field set as Yes");
        	WebElement unitNum = driver.findElement(By.xpath("//input[@placeholder='Unit Number']"));
        	RC_Global.enterInput(driver, Unums1[0], unitNum, true,true);
        	RC_Global.clickButton(driver,"Search", true,false);
        	RC_Global.waitUntilPanelVisibility(driver,"Driver Details", "TV", true,false);
        	RC_Manage.clientDataFieldValidation(driver, "NonMandatoryclient", Unums1[0]);  
        	
        	RC_Global.panelAction(driver, "close", "Driver Details", true,false);
        	RC_Global.navigateTo(driver,menu,"Administration","Driver Data Change");
        	WebElement unitNumIn = driver.findElement(By.xpath("//input[@placeholder='Unit Number']"));
        	RC_Global.enterInput(driver, Unums1[1], unitNumIn, true,true);
        	RC_Global.clickButton(driver,"Search", true,true);
        	RC_Global.waitUntilPanelVisibility(driver,"Driver Details", "TV", true,false);
        	RC_Manage.clientDataFieldValidation(driver, "NonMandatoryclient", Unums1[1]);  
        	
        	RC_Global.panelAction(driver, "close", "Driver Details", true,false);
        	RC_Global.logout(driver, true);
        	queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
}}