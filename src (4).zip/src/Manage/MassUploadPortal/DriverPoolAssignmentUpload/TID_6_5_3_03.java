package Manage.MassUploadPortal.DriverPoolAssignmentUpload;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.RandomUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.LeaseWave.RC_LW_Global;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_5_3_03 {
	public static void UploadDriver_PoolAndValidateDataBetweenDDCAndLeasewave(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{

		String newFileName = ""; String curDir = "";
		String curFilePath = ""; String sptVal[] = null;
		String userName = ""; String defTimeZon = ""; String submitTime = ""; String uploadedTime = ""; 
		String fileName = "DriverPoolAssignment-LS010143.xlsx";
		String fileDownload = ""; String downDir = ""; String downFilePath= "";
//		String columnNames = "Unit Number;CVN;VIN;Year;Make;Model;Driver/Pool Name;Apply Driver Address to Vehicle Address;Address Validation Override;Vehicle Address 1;Vehicle Address 2;Vehicle Address City;Vehicle Address State;Vehicle Address Zip Code;Vehicle Address County;Vehicle Address Country;Fleet Number;Fleet Name;Account Number; Account Name;Sub-Account Number;Sub-Account Name";
		String unitNumber = ""; String sptUnits[] = null; String errUnitNos = "";String updUnitNos = ""; String valDate = null;
		
		
		RC_Manage.deleteFile_Downloads(driver, "DriverPoolAssignment");
		RC_Manage.deleteAllFolder_Files(driver);
		RC_Global.login(driver);
		
		RC_Global.navigateTo(driver, "Manage", "Administration", "Driver Data Change");
		RC_Global.waitUntilPanelVisibility(driver, "Driver Data Change", "TV", true, false);
		RC_Global.enterCustomerNumber(driver, "LS010143", "", "", true);
		RC_Global.validateSearchFilterAction(driver, "Pool Name", "pool", "Driver Data Change", true, false);
		Thread.sleep(2000);
		String[] poolName = {"",""};
		String[] pools = new String[2];
		List<WebElement> poolList =  driver.findElements(By.xpath("//table/tbody/tr/td[5]")); 
		int poolCount = 0;
		int usedPoolIndex = 0;
		
		for(int it=0;it<poolList.size();it++) {			
			if (poolCount==1) {
				RC_Manage.getAddress_DriverSelection(driver, "DiffUnitNum-Pool", true);
				unitNumber = unitNumber+";"+driver.findElement(By.xpath("//strong[text()='Unit Number: ']/following-sibling::a")).getText();
			} else {
				RC_Manage.getAddress_DriverSelection(driver, "Pool Change", true);
				unitNumber = driver.findElement(By.xpath("//strong[text()='Unit Number: ']/following-sibling::a")).getText();
			}
            List<WebElement> availPoolList = driver.findElements(By.xpath("//select[@id='changePool']/option[not(@selected)]"));
            int poolIndex = Integer.parseInt(RandomStringUtils.randomNumeric(1));
            if(poolIndex==0)poolIndex=1;
            if(poolIndex==usedPoolIndex)poolIndex++;
            usedPoolIndex = poolIndex;
            pools[poolCount]=availPoolList.get(poolIndex).getText();            
            RC_Global.panelAction(driver, "close", "Driver Details", true, false);
            RC_Global.panelAction(driver, "expand", "Driver Data Change", true, false);
            
            poolCount++;
            if(poolCount==2) {
            	break;
            }
		}
		
		String[] driverName = {"",""};
		String[] drivers = new String[2];
		RC_Global.clickButton(driver, "Reset", true, false);
		RC_Global.enterCustomerNumber(driver, "LS010143", "", "", true);
		RC_Global.clickButton(driver, "Search", true, false);
		
		RC_Global.waitElementVisible(driver, 30, "//tbody/tr[1]", "First Row Grid Load", true, false);
		RC_Global.clickUsingXpath(driver, "//th/div[@class='th']/span[text()='Driver/Pool Name']", "Driver/Pool Name Column sort", false, false);
		Thread.sleep(2000);
		RC_Global.clickUsingXpath(driver, "//th/div[@class='th']/span[text()='Driver/Pool Name']", "Driver/Pool Name Column sort", false, false);
		Thread.sleep(2000);
		int usedDriverIndex = 0;
		List<WebElement> driverList =  driver.findElements(By.xpath("//table/tbody/tr/td[5]")); 
		int driverCount = 0;
		for(int it=0;it<driverList.size();it++) {
			if (driverCount==1) {
				RC_Manage.getAddress_DriverSelection(driver, "DiffUnitNum", true);
			} else {
				RC_Manage.getAddress_DriverSelection(driver, "Driver Change", true);
			}
			unitNumber = unitNumber+";"+driver.findElement(By.xpath("//strong[text()='Unit Number: ']/following-sibling::a")).getText();
			RC_Global.clickUsingXpath(driver, "//button[text()=' Search']", "Search driver button", true, false);
            RC_Global.waitElementVisible(driver, 30, "//h3[text()='Select Driver']", "Select Driver", true, false);
            RC_Global.clickUsingXpath(driver, "//fieldset/button[text()='Search']", "Search driver button", true, false);
           
            RC_Global.waitElementVisible(driver, 30, "//table/tbody/tr/td[2]", "Select Driver Grid", true, false);
            Thread.sleep(2000);
            List<WebElement> driverNameList = driver.findElements(By.xpath("//table/tbody/tr/td[2]"));
            Thread.sleep(2000);
            
            int driverIndex = Integer.parseInt(RandomStringUtils.randomNumeric(1));
            if(driverIndex==0)driverIndex=1;
            if(driverIndex==usedDriverIndex)driverIndex++;
            usedDriverIndex = driverIndex;
            
            drivers[driverCount]=driverNameList.get(usedDriverIndex).getText();
            JavascriptExecutor executor = (JavascriptExecutor)driver;
            executor.executeScript("document.body.style.zoom = '80%'");
            Thread.sleep(2000);
            
            WebElement element = driver.findElement(By.xpath("//button[text()='Cancel']"));
            executor.executeScript("arguments[0].click();", element);
            executor.executeScript("document.body.style.zoom = '100%'");
            
            RC_Global.panelAction(driver, "close", "Driver Details", true, false);
            RC_Global.panelAction(driver, "expand", "Driver Data Change", true, false);
            
            driverCount++;
            if(driverCount==2) {
            	break;   
           	}
		}
		
		System.out.println(unitNumber);
		
		String pool1=pools[0];
		String pool2=pools[1];
		String driver1=drivers[0];
		String driver2=drivers[1];
//		String driversName = "Zach "+RandomStringUtils.randomAlphabetic(4);
		//RandomSelection
		ArrayList<String> randomAddressSelection1 = (ArrayList<String>) RC_Manage.RandomSelection(driver);
		String resAddress1 = randomAddressSelection1.get(0);
		String city1 = randomAddressSelection1.get(1);
		String state1 = randomAddressSelection1.get(2);
		String zipCode1 = randomAddressSelection1.get(3);
		String county1 = randomAddressSelection1.get(4);
		
		ArrayList<String> randomAddressSelection2 = (ArrayList<String>) RC_Manage.RandomSelection(driver);
		System.out.println(randomAddressSelection2);
		String resAddress2 = randomAddressSelection2.get(0);
		String city2 = randomAddressSelection2.get(1);
		String state2 = randomAddressSelection2.get(2);
		String zipCode2 = randomAddressSelection2.get(3);
		String county2 = randomAddressSelection2.get(4);
		
		//Download the DriverPoolAssignment excel file			
		RC_Global.navigateTo(driver, "Manage", "Mass Upload Portal", "");
		RC_Global.waitUntilPanelVisibility(driver, "Mass Upload Portal", "TV", true, false);
		Thread.sleep(3000);
		RC_Global.panelAction(driver, "close", "Driver Data Change", true, false);
		RC_Global.panelAction(driver, "expand", "Mass Upload Portal", true, false);
		RC_Global.enterCustomerNumber(driver, "LS010143", "", "", true);
		
		String downloadPath = RC_Manage.fileDownload(driver, "Driver/Pool Assignment Upload", fileName);
		Thread.sleep(3000);
		if (downloadPath.contains(";")) {
        	sptVal = downloadPath.split(";");
        	curDir= sptVal[0];
        	newFileName = sptVal[1];
        	curFilePath = curDir+"\\"+newFileName;	
		}
		userName = driver.findElement(By.xpath("//span[contains(@ng-show,'user.FullName') and @id='Span1']")).getText();
		
		//"123 S 4th St 1909", "Miami", "FL", "23567-6760"
		String driverPoolName = RC_Manage.modifyCells_ColumnName_UnitNum(driver, curFilePath, "Driver/Pool Name", 4, unitNumber, "Update",pool1+";"+pool2+";"+driver1+";"+driver2);
		String address1 = RC_Manage.modifyCells_ColumnName_UnitNum(driver, curFilePath, "Vehicle Address 1", 4, unitNumber, "Update","508"+RandomStringUtils.randomNumeric(1)+" Commercial Cir Ste 21;"+resAddress1+";12"+RandomStringUtils.randomNumeric(1)+" S 4th St 1909;"+resAddress2);
		String city = RC_Manage.modifyCells_ColumnName_UnitNum(driver, curFilePath, "Vehicle Address City", 4, unitNumber, "Update","Oxnard;"+city1+";Miami;"+city2);
		String state = RC_Manage.modifyCells_ColumnName_UnitNum(driver, curFilePath, "Vehicle Address State", 4, unitNumber, "Update","CA;"+state1+";FL;"+state2);
		String zipCode = RC_Manage.modifyCells_ColumnName_UnitNum(driver, curFilePath, "Vehicle Address Zip Code", 4, unitNumber, "Update","93030-"+RandomStringUtils.randomNumeric(4)+";"+zipCode1+";23567-"+RandomStringUtils.randomNumeric(4)+";"+zipCode2);
		String county = RC_Manage.modifyCells_ColumnName_UnitNum(driver, curFilePath, "Vehicle Address County", 4, unitNumber, "Update","Ventura;"+county1+";Sample;"+county2);
		String country = RC_Manage.modifyCells_ColumnName_UnitNum(driver, curFilePath, "Vehicle Address Country", 4, unitNumber, "Update","AND;"+randomAddressSelection1.get(5)+";ANT;"+randomAddressSelection2.get(5));		
    	sptUnits = unitNumber.split(";");
    	errUnitNos = sptUnits[0]+";"+sptUnits[2];
    	updUnitNos  = sptUnits[1]+";"+sptUnits[3];
		submitTime = RC_Manage.fileUpload(driver, curDir, curFilePath, "Driver/Pool Assignment Upload", "", defTimeZon, userName, "");    	
    	uploadedTime = RC_Manage.selectDownloadResults(driver, userName, submitTime, defTimeZon);//download the results file
    	if (defTimeZon.equalsIgnoreCase("CST") || defTimeZon.equalsIgnoreCase("America/Chicago")) {
    		valDate = RC_Manage.driverHistory_DateFormat(driver, queryObjects, uploadedTime, "No");
		} else {
			valDate = RC_Manage.driverHistory_DateFormat(driver, queryObjects, uploadedTime, "Yes");
		}
    	
    	fileDownload = RC_Manage.moveFileFromDownloads(driver, fileName, "DownloadedFiles", true);
        if (fileDownload.contains(";")) {
        	downDir = fileDownload.substring(0, fileDownload.indexOf(";"));
        	downFilePath = fileDownload.replace(";", "\\");
        	RC_Manage.validateUploadChanges(driver, downFilePath, errUnitNos, "Error");
        	RC_Manage.validateUploadChanges(driver, downFilePath, updUnitNos, "Success");
        	RC_Manage.deleteFolder(driver, downDir);
        }
		//Validate the results in the downloaded excel file
		RC_Global.logout(driver, true);
		
		String driverPool = "";
		String resAddress = "";
		String resCity = "";
		String resState = "";
		String resCounty = "";
		String resZipCode = "";
		
		String[] unitNumbers = unitNumber.split(";");
		RC_LW_Global.leaseWaveLogin(driver, true);		
		for(int i=1;i<unitNumbers.length;i+=2) {
			RC_Global.createNode(driver, "Driver Data Changes upload validations in LeaseWave - Fleet Management for UnitNumber - "+unitNumbers[i]);
	        try {
	        	RC_Global.clickUsingXpath(driver,"//a[contains(text(),'Fleet Management')]","Fleet Management",true, true);
	            RC_Global.waitElementVisible(driver, 50, "//a[contains(text(),'Fleet Management')]", "Fleet Management",true, true);
	            RC_Global.clickUsingXpath(driver,"//td[@accesskey='1' and text()='. Profiles']","Profiles option",true, true);
	            RC_Global.clickUsingXpath(driver,"//td[@accesskey='D']/div[text()='rivers']","Drivers",true, true);
	            RC_Global.clickUsingXpath(driver,"//td[@accesskey='A']/div[text()='ssign Driver to Asset']","Assign Driver to Asset",true, true);
	            
	        } catch(Exception e) {
	    			queryObjects.logStatus(driver, Status.FAIL, "Navigate to Asset List page Failed", e.getLocalizedMessage(), e);	
	    			RC_Global.endTestRun(driver);
	        }
	        
	        
	        WebElement eleUnitNumber = driver.findElement(By.xpath("//tr[td[text()='Unit Number']]/td/input"));
	        
	        RC_Global.enterInput(driver, unitNumbers[i], eleUnitNumber, true, true);
	        RC_Global.clickUsingXpath(driver, "//button[text()='Searc' and @accesskey='H']", "Search Button", true, true);
			Thread.sleep(3000);
			RC_Global.clickUsingXpath(driver, "//button[text()='elect' and @accesskey='S']", "Select Button", true, true);
			Thread.sleep(3000);
			
			if(driver.findElement(By.xpath("//table/tbody/tr[1]/td[nobr][9]")).getText().equalsIgnoreCase("Active")) 
				queryObjects.logStatus(driver, Status.PASS, "Verify the Status of the first row is Active", "The status is 'Active' as expected", null);
			
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify the Status of the first row is Active", "The status is not 'Active'", null);
			
			String date = driver.findElement(By.xpath("//table/tbody/tr[1]/td[nobr][10]")).getText();
			Date date1=new SimpleDateFormat("MM/dd/yyyy").parse(date);
			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");  
			String strDate = dateFormat.format(date1); 
			
			if(strDate.equalsIgnoreCase(RC_Global.getDateTime(driver, "MM/dd/yyyy", 0, true))) 
				queryObjects.logStatus(driver, Status.PASS, "Verify the Assigned Date is today's date", "The Assigned Date is today's date as expected", null);
			
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify the Assigned Date is today's date", "The Assigned Date is not today's date", null);
			
			if(driver.findElements(By.xpath("//table/tbody/tr[1]/td[nobr][12]//input[@checked]")).size()>0) 
				queryObjects.logStatus(driver, Status.PASS, "Verify the isPrimary checkbox is checked", "The isPrimary checkbox is checked as expected", null);
			
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify the isPrimary checkbox is checked", "The isPrimary checkbox is not checked", null);
			
			int rowCount = driver.findElements(By.xpath("//table/tbody/tr[td[nobr]]")).size();
			if(driver.findElement(By.xpath("//table/tbody/tr[2]/td[nobr][11]")).getAttribute("style").contains("red")) 
				queryObjects.logStatus(driver, Status.PASS, "Verify the previous value row is in Red", "The previous value row is in Red", null);
				
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify the previous value row is in Red", "The previous value row is not in Red", null);
			
			date = driver.findElement(By.xpath("//table/tbody/tr[2]/td[nobr][11]")).getText();
			date1=new SimpleDateFormat("MM/dd/yyyy").parse(date);
			dateFormat = new SimpleDateFormat("MM/dd/yyyy");  
			strDate = dateFormat.format(date1); 
			String sdate = driver.findElement(By.xpath("//table/tbody/tr["+(rowCount)+"]/td[nobr][11]")).getText();
			Date sdate1=new SimpleDateFormat("MM/dd/yyyy").parse(date);
			DateFormat sdateFormat = new SimpleDateFormat("MM/dd/yyyy");  
			String sstrDate = dateFormat.format(date1); 
			
			if(strDate.equalsIgnoreCase(RC_Global.getDateTime(driver, "MM/dd/yyyy", 0, true))||sstrDate.equalsIgnoreCase(RC_Global.getDateTime(driver, "MM/dd/yyyy", 0, true))) 
				queryObjects.logStatus(driver, Status.PASS, "Verify the 'Remove Date' for the previous data", "The 'Remove Date' for the previous data is today's date", null);
			
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify the 'Remove Date' for the previous data", "The 'Remove Date' for the previous data is not today's date", null);
			
			if(driver.findElements(By.xpath("//table/tbody/tr[2]/td[12]/nobr/input[@disabled]")).size()>0||driver.findElements(By.xpath("//table/tbody/tr["+(rowCount-1)+"]/td[12]/nobr/input[@disabled]")).size()>0) 
				queryObjects.logStatus(driver, Status.PASS, "Verify the isPrimary checkbox is unchecked", "The isPrimary checkbox is unchecked as expected", null);
			
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify the isPrimary checkbox is unchecked", "The isPrimary checkbox is not unchecked", null);
			
			RC_Global.clickUsingXpath(driver, "//button[text()='lose' and @accesskey='C']", "Close Button", true, true);
			Thread.sleep(3000);
			
			RC_Global.createNode(driver, "Driver Data Changes upload validations in LeaseWave - Portfolio Management_Asset Lists for UnitNumber - "+unitNumbers[i]);
			 try {
		        	RC_Global.clickUsingXpath(driver,"//a[contains(text(),'Portfolio Management')]","Portfolio Management",true, true);
		            RC_Global.waitElementVisible(driver, 50, "//a[contains(text(),'Portfolio Management')]", "Portfolio Management",true, true);
		            RC_Global.clickUsingXpath(driver,"//td[@accesskey='3' and text()='.Asset']","Asset option",true, true);
		            RC_Global.clickUsingXpath(driver,"(//td[@accesskey='P']/div[text()='rofile'])[2]","Drivers",true, true);            
		            
		        } catch(Exception e) {
		    			queryObjects.logStatus(driver, Status.FAIL, "Navigate to Asset List page Failed", e.getLocalizedMessage(), e);	
		    			RC_Global.endTestRun(driver);
		        }
		        
			 	eleUnitNumber = driver.findElement(By.xpath("//tr[td[text()='Unit Number']]/td/input"));
		        
		        RC_Global.enterInput(driver, unitNumbers[i], eleUnitNumber, true, true);
		        RC_Global.clickUsingXpath(driver, "//button[text()='Searc' and @accesskey='H']", "Search Button", true, true);
				Thread.sleep(3000);
				
				RC_Global.clickUsingXpath(driver, "//button[text()='dit' and @accesskey='E']", "Edit Button", true, true);
				Thread.sleep(3000);
				
				RC_Global.clickUsingXpath(driver, "//a[text()='Asset Profile']", "Asset Profile", true, true);
				Thread.sleep(3000);
				
				if(i==1) {
					driverPool = pool1;
					resAddress = resAddress1;
					resCity = city1;
					resState = state1;
					resCounty = county1;
					resZipCode = zipCode1;
				}
				else if(i==3) {
					driverPool = driver1;
					resAddress = resAddress2;
					resCity = city2;
					resState = state2;
					resCounty = county2;
					resZipCode = zipCode2;
				}
				String locationCode = driver.findElement(By.xpath("//table//tr/td[1]/nobr")).getText();
				if(driver.findElement(By.xpath("//table//tr/td[5]/nobr")).getText().equalsIgnoreCase(resAddress))
					queryObjects.logStatus(driver, Status.PASS, "Verify the Residential Address 1 is updated", "The residential address is updated to "+resAddress, null);
				else
					queryObjects.logStatus(driver, Status.FAIL, "Verify the Residential Address 1 is updated", "The residential address is not updated to "+resAddress, null);
				
				if(driver.findElement(By.xpath("//table//tr/td[6]/nobr")).getText().equalsIgnoreCase(resCity))
					queryObjects.logStatus(driver, Status.PASS, "Verify the Residential City is updated", "The residential city is updated to "+resCity, null);
				else
					queryObjects.logStatus(driver, Status.FAIL, "Verify the Residential City is updated", "The residential city is not updated to "+resCity, null);
				
				if(driver.findElement(By.xpath("//table//tr/td[7]/nobr")).getText().equalsIgnoreCase(resCounty))
					queryObjects.logStatus(driver, Status.PASS, "Verify the Residential County is updated", "The residential county is updated to "+resCounty, null);
				else
					queryObjects.logStatus(driver, Status.FAIL, "Verify the Residential County is updated", "The residential county is not updated to "+resCounty, null);
				
				if(driver.findElement(By.xpath("//table//tr/td[10]/nobr")).getText().equalsIgnoreCase(resZipCode))
					queryObjects.logStatus(driver, Status.PASS, "Verify the Zip Code is updated", "The zip code is updated to "+resZipCode, null);
				else
					queryObjects.logStatus(driver, Status.FAIL, "Verify the Zip Code is updated", "The zip code is not updated to "+resZipCode, null);
				
				RC_Global.clickUsingXpath(driver, "(//button[text()='lose' and @accesskey='C'])[2]", "Close button", true, true);
				
				RC_Global.clickUsingXpath(driver, "//a[text()='Location History']", "Location History", true, true);
				Thread.sleep(3000);
				
				if(driver.findElement(By.xpath("//table//tr[1]/td[4]/nobr")).getText().equalsIgnoreCase(locationCode))
					queryObjects.logStatus(driver, Status.PASS, "Verify the location code", "The location code is "+locationCode, null);
				else
					queryObjects.logStatus(driver, Status.FAIL, "Verify the location code", "The location code is not "+locationCode, null);
				
				date = driver.findElement(By.xpath("//table//tr[1]/td[3]/nobr")).getText();
				date1=new SimpleDateFormat("MM/dd/yyyy").parse(date);
				dateFormat = new SimpleDateFormat("MM/dd/yyyy");  
				strDate = dateFormat.format(date1); 
				
				if(strDate.equalsIgnoreCase(RC_Global.getDateTime(driver, "MM/dd/yyyy", 0, false)))
					queryObjects.logStatus(driver, Status.PASS, "Verify the location effective date is today's date", "The location effective date is "+strDate, null);
				else
					queryObjects.logStatus(driver, Status.FAIL, "Verify the location effective date is today's date", "The location effective date is "+strDate, null);
				
				if(driver.findElement(By.xpath("//table//tr[1]/td[8]/nobr")).getText().equalsIgnoreCase(resAddress))
					queryObjects.logStatus(driver, Status.PASS, "Verify the Residential Address 1 is updated", "The residential address is updated to "+resAddress, null);
				else
					queryObjects.logStatus(driver, Status.FAIL, "Verify the Residential Address 1 is updated", "The residential address is not updated to "+resAddress, null);
				
				if(driver.findElement(By.xpath("//table//tr[1]/td[9]/nobr")).getText().equalsIgnoreCase(resCity))
					queryObjects.logStatus(driver, Status.PASS, "Verify the Residential City is updated", "The residential city is updated to "+resCity, null);
				else
					queryObjects.logStatus(driver, Status.FAIL, "Verify the Residential City is updated", "The residential city is not updated to "+resCity, null);
				
				if(driver.findElement(By.xpath("//table//tr[1]/td[12]/nobr")).getText().equalsIgnoreCase(resCounty))
					queryObjects.logStatus(driver, Status.PASS, "Verify the Residential County is updated", "The residential county is updated to "+resCounty, null);
				else
					queryObjects.logStatus(driver, Status.FAIL, "Verify the Residential County is updated", "The residential county is not updated to "+resCounty, null);
				
				if(driver.findElement(By.xpath("//table//tr[1]/td[11]/nobr")).getText().equalsIgnoreCase(resZipCode))
					queryObjects.logStatus(driver, Status.PASS, "Verify the Zip Code is updated", "The zip code is updated to "+resZipCode, null);
				else
					queryObjects.logStatus(driver, Status.FAIL, "Verify the Zip Code is updated", "The zip code is not updated to "+resZipCode, null);
			
				RC_Global.clickUsingXpath(driver, "(//button[text()='lose' and @accesskey='C'])[2]", "Close Button", true, true);
				Thread.sleep(3000);
				RC_Global.clickUsingXpath(driver, "//button[text()='lose' and @accesskey='C']", "Close Button", true, true);
				Thread.sleep(3000);
				
				
		}
		RC_LW_Global.leaseWaveLogOut(driver, true);
	}
}
