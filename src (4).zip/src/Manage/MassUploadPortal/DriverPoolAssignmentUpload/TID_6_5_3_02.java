package Manage.MassUploadPortal.DriverPoolAssignmentUpload;


import java.io.FileInputStream;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import MF.Source.Cred;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;


public class TID_6_5_3_02 {
	public void  CurrentDriver_PoolChangeOnDriver_PoolAssignmentTemplate(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		String CustomerNumber = "LS008742";String selType = "Driver/Pool Assignment Upload"; String fileDownload="";String downDir = "";
		String Filename="DriverPoolAssignment-"+CustomerNumber+".xlsx"; String curFilePath = ""; String submitTime = "";
		String sptVal[] = null;	String retVal = "";String newFileName = ""; String curDir = "";String defTimeZone = "";String userName = "";
		defTimeZone = java.util.TimeZone.getDefault().getID();String unitNumber =""; String downFilePath = "";String DriverPoolName ="";
		List<Integer> rowsChange = null;String UpdatedDriverPoolName = "";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,"Manage","Mass Upload Portal","");
		RC_Global.waitElementVisible(driver, 30,"//h3[text()='Mass Uploads']", "Mass Upload Portal", true,false);
		RC_Global.enterCustomerNumber(driver,CustomerNumber, "", "", true);
		retVal = RC_Manage.fileDownload(driver, selType, Filename);
		 if (retVal.contains(";")) {
	        	sptVal = retVal.split(";");
	        	curDir= sptVal[0];
	        	newFileName = sptVal[1];
	        	curFilePath = curDir+"\\"+newFileName;	}
		 
		 //read 2 unit num from excel
		 FileInputStream fis = new FileInputStream(curFilePath);
         XSSFWorkbook wb = new XSSFWorkbook(fis); XSSFCell ccell ;
         XSSFSheet sh = wb.getSheetAt(1);
         int rows = sh.getLastRowNum();
         int cols= sh.getRow(2).getLastCellNum();
         do{
         rowsChange = RC_Manage.RandomNumbers(driver, 5, rows, 1);
         ccell = sh.getRow(rowsChange.get(0)).getCell(2);
         unitNumber = ccell.getStringCellValue();	
         ccell = sh.getRow(rowsChange.get(0)).getCell(8);
         DriverPoolName = ccell.getStringCellValue();	}while(!DriverPoolName.contains("Pool"));
         fis.close();
         Thread.sleep(2000);
		 RC_Global.panelAction(driver, "close", "Mass Upload Portal", true,false);
		 
		 
		 RC_Global.navigateTo(driver,"Manage","Administration","Driver Data Change");
		 RC_Global.waitElementVisible(driver, 30,"(//span[text()='Driver Data Change'])[2]", "Driver Data Change", true,false);
		 WebElement UnitNum = driver.findElement(By.xpath("//input[@placeholder='Unit Number']"));
		 RC_Global.enterInput(driver, unitNumber, UnitNum, true,true);
		 RC_Global.clickButton(driver, "Search", true,true);
		 RC_Global.waitElementVisible(driver, 30,"//span[text()='Driver Details']", "Driver Details", true,true);
		 //changePool
		 Thread.sleep(2000);
		 List<WebElement> DriverType = driver.findElements(By.xpath("//button[(contains(@class,'active')) and (@uib-btn-radio='assignmentTypes.driver')]"));
		 if(DriverType.size()>0) {
			 driver.findElement(By.xpath("//button[(@uib-btn-radio='assignmentTypes.pool')]")).click();
			 Thread.sleep(2000);
		 }
		 String CuPoolName = driver.findElement(By.xpath("//select[@id='changePool']/option[@selected='selected']")).getText();
		 driver.findElement(By.xpath("//select[@id='changePool']")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("(//select[@id='changePool']/option[not(@selected='selected')])[1]")).click();
		 Thread.sleep(3000);
		 List<WebElement> Message = driver.findElements(By.xpath("(//label[contains(text(),'Changing states requires')])[2]"));
		 if(Message.size()>0) {
			 driver.findElement(By.xpath("(//button[@ng-model='updateOdometer'])[3]")).click();
			 Thread.sleep(2000);
			 WebElement Odometer = driver.findElement(By.xpath("(//input[@placeholder='Odometer'])[2]"));
			 RC_Global.enterInput(driver, "10,000", Odometer, true,false);
		 }
		 RC_Global.clickUsingXpath(driver, "(//button[text()=' Save '])[2]", "Save button", true,true);
		 RC_Manage.waitUntilMethods(driver, "(//button[text()=' Save '])[2]/div[@ng-show='isSaving']","class","ng-hide", "attribute visible");		 
		 RC_Global.verifyDisplayedMessage(driver, "Update Successful", true);
		 RC_Global.panelAction(driver, "close","Driver Details", true,false);
		 
		 //upload
			RC_Global.navigateTo(driver,"Manage","Mass Upload Portal","");
			RC_Global.waitElementVisible(driver, 30,"//h3[text()='Mass Uploads']", "Mass Upload Portal", true,true);
			RC_Global.enterCustomerNumber(driver,CustomerNumber, "", "", true);
			userName = driver.findElement(By.xpath("//span[contains(@ng-show,'user.FullName') and @id='Span1']")).getText();
			submitTime = RC_Manage.fileUpload(driver, curDir, curFilePath, selType, "", defTimeZone, userName, "");
		
	         retVal = RC_Manage.fileDownload(driver, selType, Filename);
			 if (retVal.contains(";")) {
		        	sptVal = retVal.split(";");
		        	curDir= sptVal[0];
		        	newFileName = sptVal[1];
		        	curFilePath = curDir+"\\"+newFileName;	}
			 
			 
			 //read 2 unit num from excel
			 fis = new FileInputStream(curFilePath);
	         wb = new XSSFWorkbook(fis); 
	         sh = wb.getSheetAt(1);
	         ccell = sh.getRow(rowsChange.get(0)).getCell(2);
	         unitNumber = ccell.getStringCellValue();	
	         ccell = sh.getRow(rowsChange.get(0)).getCell(8);
	         UpdatedDriverPoolName = ccell.getStringCellValue();
	         fis.close();
	         Thread.sleep(2000);
	         if(!UpdatedDriverPoolName.equalsIgnoreCase(DriverPoolName))
	        	 queryObjects.logStatus(driver, Status.PASS, "Driver/Pool name", "Driver/Pool name in excel matches the value entered in the Driver data change", null);
	         else {
	               queryObjects.logStatus(driver, Status.FAIL, "Driver/Pool name","Driver/Pool name in excel does not matches the value entered in the Driver data change", null);
	               RC_Global.endTestRun(driver);}
			 RC_Global.panelAction(driver, "close", "Mass Upload Portal", true,false);
			 RC_Global.logout(driver, false);
			 queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
}
}