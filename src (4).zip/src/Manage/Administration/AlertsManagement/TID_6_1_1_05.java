package Manage.Administration.AlertsManagement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_1_05 {
	public void FuelAlert_ExternalUserAccess(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		 String Manage = "";
		 String  Save= "";
		 String  AddAlert= "";
		 
		RC_Global.externalUserLogin(driver, "kentuckytest3", "Yes");
		

		RC_Global.navigateTo(driver, "Manage", "Administration", "Alerts Management");
		Manage = driver.findElement(By.xpath("//span[text()='Manage']")).getText();
		RC_Global.clickUsingXpath(driver, "//a[text()='Fuel']", "Fuel", false,true);
		RC_Global.validateHeaderName(driver, "Alerts Management - Fuel", false);
	    RC_Global.panelAction(driver, "expand", "Alerts Management - Fuel", false,true);
	    
	    
	     AddAlert= driver.findElement(By.xpath("//button[text()='Add Alert']")).getText();
		 RC_Global.clickButton(driver, "Add Alert", false,true);
		 RC_Global.validateHeaderName(driver, "Alert Setup - New Alert", false);
		 RC_Global.panelAction(driver, "expand", "Alert Setup - New Alert", false,true);
		 
		Save= driver.findElement(By.xpath("//button[text()='Save']")).getText();
		 RC_Global.buttonStatusValidation(driver, "Save", "Disable", false);
		 RC_Global.panelAction(driver, "close", "Alert Setup - New Alert", false,true);
		 RC_Global.panelAction(driver, "expand", "Alerts Management - Fuel", false,true);
   
		 RC_Global.clickUsingXpath(driver, "(//td[@ng-click='openSetup(data)'])[1]", "Edit", false, true);
		 String category = driver.findElement(By.xpath("(//tr[td[@ng-click='openSetup(data)']])[1]/td[4]")).getText();
		 RC_Global.validateHeaderName(driver, "Alert Setup - "+category, false);
		 RC_Global.panelAction(driver, "expand", "Alert Setup - "+category, false,true);
		 
		 RC_Global.buttonStatusValidation(driver, "Save", "Enable", false);
		 RC_Global.panelAction(driver, "close", "Alert Setup - "+category, false,true);
		 RC_Global.panelAction(driver, "expand", "Alerts Management - Fuel", false,true);


		 RC_Global.clickUsingXpath(driver, "//a[text()='Clone'][1]", "Clone", false, true);
		 RC_Global.validateHeaderName(driver, "Clone Alert", false);
		 RC_Global.panelAction(driver, "expand", "Clone Alert", false,true);
		 
		 RC_Global.buttonStatusValidation(driver, "Save", "Enable", false);
		 RC_Global.panelAction(driver, "close", "Clone Alert", false,true);
		 RC_Global.panelAction(driver, "expand", "Alerts Management - Fuel", false,true);
		 RC_Global.panelAction(driver, "close", "Alerts Management - Fuel", false,true);

		 
		 RC_Global.logout(driver,false);
		 
		 RC_Global.externalUserLogin(driver, "mobiletestdriver4", "");


		 if(Manage.equalsIgnoreCase("Manage"))
		 {
		 queryObjects.logStatus(driver, Status.PASS, "Validate Driver has No Access for Manage - Alert Management Module ", "verified successfully", null);
		 }
		 else
		 {
		 queryObjects.logStatus(driver, Status.FAIL, "Validate Driver has No Access for Manage - Alert Management Module ", "Failed", null);



		 }



		 RC_Global.logout(driver,false);

		 RC_Global.externalUserLogin(driver, "TestAdmin", "");
		 RC_Global.navigateTo(driver, "Manage", "Administration", "Alerts Management");
		 
		 RC_Global.clickUsingXpath(driver, "//a[text()='Fuel']", "Fuel", false,true);
		 RC_Global.validateHeaderName(driver, "Alerts Management - Fuel", false);
		 RC_Global.panelAction(driver, "expand", "Alerts Management - Fuel", false,true);
		 
		 if(AddAlert.equalsIgnoreCase("Add Alert"))

				 {
			 queryObjects.logStatus(driver, Status.PASS, "Validation of Add Alert button not displayed", "Verified Successfully", null);

				 }

				 else

				 {queryObjects.logStatus(driver, Status.FAIL, "Validation of Add Alert button displayed", "Failed", null);

				 }
		 
		 RC_Global.clickUsingXpath(driver, "(//td[@ng-click='openSetup(data)'])[1]", "Edit", false, true);
		 category = driver.findElement(By.xpath("(//tr[td[@ng-click='openSetup(data)']])[1]/td[4]")).getText();
		 RC_Global.validateHeaderName(driver, "Alert Setup - "+category, false);
		 RC_Global.panelAction(driver, "expand", "Alert Setup - "+category, false,true);
		 
		 if(driver.findElements(By.xpath("//input[@name='alertName' and @disabled='disabled']")).size()>0)

		 {
	 queryObjects.logStatus(driver, Status.PASS, "Validation of Alert Name field is disabled", "Verified Successfully", null);

		 }

		 else

		 {
			 queryObjects.logStatus(driver, Status.FAIL, "Validation of Alert Name field is not disabled", "Failed", null);

		 }
		 
		 
		 
		 
		 if(Save.equalsIgnoreCase("Save"))

				 {
			 queryObjects.logStatus(driver, Status.PASS, "Validation of Save button not displayed", "Verified Successfully", null);

				 }

				 else

				 {
					 queryObjects.logStatus(driver, Status.FAIL, "Validation of Save button displayed", "Failed", null);

				 }
		 RC_Global.logout(driver, false);
			queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);


	}

}
