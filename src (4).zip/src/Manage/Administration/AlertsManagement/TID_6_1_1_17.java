package Manage.Administration.AlertsManagement;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_1_17 {
	public void  PersonalUseAlert_ValidateMaintenanceCategoryAndExceptionError(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver; 
		String CustomerNumberNotPU = "LS010043"; String AlertName = "";String dropDownValues = "Missing Submissions;Submission Reminder";
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,"Manage","Administration","Customer Administration");
		RC_Global.enterCustomerNumber(driver, CustomerNumberNotPU, "", "", true);
		RC_Global.clickUsingXpath(driver, "//a[text()='Personal Use']", "PersonalUse Tab", true, true);
		RC_Global.waitElementVisible(driver, 30, "//legend[text()='Personal Use']", "", true, false);
		List<WebElement> personalUseToggleButton = driver.findElements(By.xpath("//button[contains(@class,'active') and @name='buttonEnrolledInPersonalUseNo']"));
		if(personalUseToggleButton.size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Personal Use Toggle Options", "Personal Use Toggle Options is set to NO", null);
		RC_Global.panelAction(driver, "close", "Customer Administration", true, false);
		
		RC_Global.navigateTo(driver,"Manage","Administration","Alerts Management");
		RC_Global.enterCustomerNumber(driver, CustomerNumberNotPU, "", "", true);
		List<WebElement> personalUse = driver.findElements(By.xpath("//div[text()=' Fuel ']"));
		List<WebElement> Fuel = driver.findElements(By.xpath("//div[text()=' Maintenance ']"));
		List<WebElement> Maintenance = driver.findElements(By.xpath("//div[text()=' Personal Use ']"));
		if(personalUse.size()>0 && Fuel.size()>0 && Maintenance.size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Hyperlinks", "Personal Use, Fuel and Maintenance hyperlinks are displaying with Number of Alerts", null);
		else {
            BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Hyperlinks", "Personal Use, Fuel and Maintenance hyperlinks are not displaying with Number of Alerts", null);
            RC_Global.endTestRun(driver);
		}
		RC_Global.panelAction(driver, "close", "Alerts Management", true, false);
		
		RC_Global.navigateTo(driver,"Manage","Administration","Customer Administration");
		Thread.sleep(2000);
		RC_Global.enterCustomerNumber(driver, "LS008737", "", "", true);
		RC_Global.clickUsingXpath(driver, "//a[text()='Personal Use']", "PersonalUse Tab", true, true);
		RC_Global.waitElementVisible(driver, 30, "//legend[text()='Personal Use']", "", true, false);
		personalUseToggleButton = driver.findElements(By.xpath("//button[contains(@class,'active') and @name='buttonEnrolledInPersonalUseYes']"));
		if(personalUseToggleButton.size()>0)
			queryObjects.logStatus(driver, Status.PASS, "", "", null);
		RC_Global.panelAction(driver, "close", "Customer Administration", true, false);
		
		RC_Global.navigateTo(driver,"Manage","Administration","Alerts Management");
		RC_Global.enterCustomerNumber(driver, "LS008737", "", "", true);
		RC_Global.waitElementVisible(driver, 30, "//a[text()='Personal Use']", "Personal Use Hyperlink", true, false);
		RC_Global.clickUsingXpath(driver, "//a[text()='Personal Use']", "Personal Use Hyperlink", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Alerts Management - Personal Use", "TV", true, true);
		RC_Global.panelAction(driver, "close", "Alerts Management", true, false);
		RC_Global.panelAction(driver, "expand", "Alerts Management - Personal Use", true, false);
		RC_Global.clickButton(driver, "Add Alert", true, true);
		RC_Global.panelAction(driver, "close", "Alerts Management - Personal Use", true, false);
		RC_Global.panelAction(driver, "expand", "Alert Setup - New Alert", true, false);
		
		RC_Global.createNode(driver, "Verify New Alert screen layout option");
		RC_Global.verifyScreenComponents(driver, "lable", "Name*", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Category*", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Description", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Customer*", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Distribution", false);
		RC_Global.dropdownValuesValidation(driver, dropDownValues, "//select[@name='alert']", true, true);
		RC_Global.buttonStatusValidation(driver, "Save", "Disable", true);
		WebElement Alertname = driver.findElement(By.xpath("//input[@name='alertName']"));
		AlertName = RandomStringUtils.randomAlphabetic(5);
		RC_Global.createNode(driver, "Enter the mandatory fields in Add alert page");
		RC_Global.selectDropdownOption(driver, "alert", "Missing Submissions", true, false);
		RC_Global.enterInput(driver, AlertName, Alertname, true, true);
		RC_Global.clickUsingXpath(driver, "//div[@ng-show='showMonthly']//input[@name='frequencyRadio']", "", true, false);
		RC_Global.clickUsingXpath(driver, "(//input[@ng-model='day.checked'])[8]", "", true, false);
		RC_Global.selectDropdownOption(driver, "data.TimeZone", "Eastern Standard Time (EST)", true, false);
		RC_Global.selectDropdownOption(driver, "customerAlertItem.DistributionMethod", "Email", true, false);
		RC_Global.buttonStatusValidation(driver, "Save", "Enable", true);

		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
