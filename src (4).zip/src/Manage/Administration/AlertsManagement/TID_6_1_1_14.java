package Manage.Administration.AlertsManagement;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_1_14 {
	public static void MaintenanceAlert_ExternalUser_AddAndEdit(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		RC_Global.externalUserLogin(driver, "kentuckytest3", "Yes");
		RC_Global.navigateTo(driver, "Manage", "Administration", "Alerts Management");
		RC_Global.waitUntilPanelVisibility(driver, "Alerts Management", "TV", true, false);
		
		Thread.sleep(2000);
		
		RC_Global.clickUsingXpath(driver, "//a[normalize-space(text())='Maintenance']", "Maintenance link", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Alerts Management - Maintenance", "TV", true, false);
		
		RC_Global.panelAction(driver, "close", "Alerts Management", true, true);
		RC_Global.panelAction(driver, "expand", "Alerts Management - Maintenance", true, false);
		
		RC_Global.clickButton(driver, "Add Alert", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Alert Setup - New Alert", "TV", true, false);
		
		RC_Global.panelAction(driver, "close", "Alerts Management - Maintenance", true, true);
		RC_Global.panelAction(driver, "expand", "Alert Setup - New Alert", true, false);
		
		
		RC_Global.waitElementVisible(driver, 30, "//input[@name='alertName' and not(@disabled)]", "", true, false);
		RC_Global.createNode(driver, "UI validation of Alert Setup - New Alert screen");
		if(driver.findElements(By.xpath("//div[label[text()='Category*']]//select")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify Category is a field present in Alert Setup - New Alert", "Category is a field present in Alert Setup - New Alert",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Category is a field present in Alert Setup - New Alert", "Category is not a field present in Alert Setup - New Alert",null);
		
		if(driver.findElements(By.xpath("//div[label[text()='Name*']]//input")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify Name is a field present in Alert Setup - New Alert", "Name is a field present in Alert Setup - New Alert",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Name is a field present in Alert Setup - New Alert", "Name is not a field present in Alert Setup - New Alert",null);
		
		if(driver.findElements(By.xpath("//div[label[normalize-space(text())='Description']]//input")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify Description is a field present in Alert Setup - New Alert", "Description is a field present in Alert Setup - New Alert",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Description is a field present in Alert Setup - New Alert", "Description is not a field present in Alert Setup - New Alert",null);
		
		if(driver.findElements(By.xpath("//div[label[normalize-space(text())='Customer*']]//ul/following-sibling::div/input")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify Customer is a field present in Alert Setup - New Alert", "Customer is a field present in Alert Setup - New Alert",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Customer is a field present in Alert Setup - New Alert", "Customer is not a field present in Alert Setup - New Alert",null);
		
		if(driver.findElements(By.xpath("//div[label[text()='Distribution']]//select")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify Distribution is a field present in Alert Setup - New Alert", "Distribution is a field present in Alert Setup - New Alert",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Distribution is a field present in Alert Setup - New Alert", "Distribution is not a field present in Alert Setup - New Alert",null);
		
		if(driver.findElements(By.xpath("//h4[text()='Distribution Groups']")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify Distribution Groups section is present in Alert Setup - New Alert", "Distribution Groups section is present in Alert Setup - New Alert",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Distribution Groups section is present in Alert Setup - New Alert", "Distribution Groups section is not present in Alert Setup - New Alert",null);
		
		if(driver.findElements(By.xpath("//h4[text()='Included Service']")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify Included Service section is present in Alert Setup - New Alert", "Included Service section is present in Alert Setup - New Alert",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Included Service section is present in Alert Setup - New Alert", "Included Service section is not present in Alert Setup - New Alert",null);
		
		
		WebElement name = driver.findElement(By.xpath("//div[label[text()='Name*']]//input"));
		WebElement miles = driver.findElement(By.xpath("(//div[div[span[text()='Past Due']]]//input)[1]"));
		WebElement days = driver.findElement(By.xpath("(//div[div[span[text()='Past Due']]]//input)[2]"));
		
		String strName= "Sample Test "+RandomStringUtils.randomNumeric(3);
		RC_Global.enterInput(driver, strName, name, true, true);
		RC_Global.clickUsingXpath(driver, "//div[h4[text()='Included Service']]//div[label[text()='Service*']]//select", "Select Service option", true, true);
		RC_Global.clickUsingXpath(driver, "//div[h4[text()='Included Service']]//div[label[text()='Service*']]//select/option[2]", "Select Service option", true, true);
		
		RC_Global.enterInput(driver, RandomStringUtils.randomNumeric(3), miles, true, true);
				
		RC_Global.enterInput(driver, RandomStringUtils.randomNumeric(2), days, true, true);
		Thread.sleep(2000);
		
		RC_Global.clickButton(driver, "Save", true, true);
		Thread.sleep(4000);
		try {
			RC_Global.waitElementVisible(driver, 120, "//h4[text()='Save Successful']", "Save Success Message", true, true);
			queryObjects.logStatus(driver, Status.PASS, "Verify Save was Successful", "Save was Successful", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify Save was Successful", "Save was not Successful", null);
		}
		
		
		RC_Global.downloadAndVerifyFileDownloaded(driver, "Export.xlsx", "Verify Export to Excel - Alert Setup-New Alert", true);
		
		RC_Global.panelAction(driver, "close", "Alert Setup - New Alert", true, true);
		
		RC_Global.navigateTo(driver, "Manage", "Administration", "Alerts Management");
		RC_Global.waitUntilPanelVisibility(driver, "Alerts Management", "TV", true, false);
		
		Thread.sleep(2000);

		RC_Global.clickUsingXpath(driver, "//a[normalize-space(text())='Maintenance']", "Maintenance link", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Alerts Management - Maintenance", "TV", true, false);
		
		RC_Global.panelAction(driver, "close", "Alerts Management", true, true);
		RC_Global.panelAction(driver, "expand", "Alerts Management - Maintenance", true, false);
		
		Thread.sleep(1000);
		try {
			RC_Global.waitElementVisible(driver, 60, "(//standard-grid//div[@class='ui-grid-canvas']//div[@role='gridcell'][5])[1]", "Name", false, true);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "", "", e);
		}
		Thread.sleep(2000);
		int noOfRows = driver.findElements(By.xpath("//standard-grid//div[@class='ui-grid-canvas']//div[@role='gridcell'][5]")).size();
		String availRow = "0";
		for(int iter=1;iter<=noOfRows;iter++) {
			if(driver.findElement(By.xpath("(//standard-grid//div[@class='ui-grid-canvas']//div[@role='gridcell'][5])["+iter+"]")).getText().equalsIgnoreCase(strName)) {
				availRow = Integer.toString(iter);
				break;
			}
		}
		if(availRow.equalsIgnoreCase("0"))
			queryObjects.logStatus(driver, Status.FAIL, "Verify Newly added Maintenance Alert is displayed in the Grid", "Newly added Maintenance Alert is not displayed in the Grid", null);
		else {
			queryObjects.logStatus(driver, Status.PASS, "Verify Newly added Maintenance Alert is displayed in the Grid", "Newly added Maintenance Alert is displayed in the Grid", null);
			RC_Global.clickUsingXpath(driver, "(//standard-grid//div[@class='ui-grid-canvas']//div[@role='gridcell'][5])["+availRow+"]", "Editting newly created Maintenance Alert", true, true);
			
			RC_Global.panelAction(driver, "close", "Alerts Management - Maintenance", true, true);
			RC_Global.panelAction(driver, "expand", "Alert Setup - Maintenance Reminder", true, false);
			
			RC_Global.waitElementVisible(driver, 30, "//input[@name='alertName' and not(@disabled)]", "", true, false);
			name = driver.findElement(By.xpath("//div[label[text()='Name*']]//input"));
			miles = driver.findElement(By.xpath("(//div[div[span[text()='Past Due']]]//input)[1]"));
			days = driver.findElement(By.xpath("(//div[div[span[text()='Past Due']]]//input)[2]"));
			
			strName= "Sample Test "+RandomStringUtils.randomNumeric(2);
			RC_Global.enterInput(driver, strName, name, true, true);
			RC_Global.clickUsingXpath(driver, "//div[h4[text()='Included Service']]//div[label[text()='Service*']]//select", "Select Service option", true, true);
			RC_Global.clickUsingXpath(driver, "//div[h4[text()='Included Service']]//div[label[text()='Service*']]//select/option[2]", "Select Service option", true, true);
			
			RC_Global.enterInput(driver, RandomStringUtils.randomNumeric(2), miles, true, true);
					
			RC_Global.enterInput(driver, RandomStringUtils.randomNumeric(1), days, true, true);
			Thread.sleep(2000);
			
			RC_Global.clickButton(driver, "Save", true, true);
			Thread.sleep(4000);
			try {
				RC_Global.waitElementVisible(driver, 120, "//h4[text()='Save Successful']", "Save Success Message", true, true);
				queryObjects.logStatus(driver, Status.PASS, "Verify Save was Successful", "Save was Successful", null);
			}
			catch(Exception e) {
				queryObjects.logStatus(driver, Status.FAIL, "Verify Save was Successful", "Save was not Successful", null);
			}
			
			RC_Global.panelAction(driver, "close", "Alert Setup - Maintenance Reminder", true, true);
			
			RC_Global.navigateTo(driver, "Manage", "Administration", "Alerts Management");
			RC_Global.waitUntilPanelVisibility(driver, "Alerts Management", "TV", true, false);
			
			Thread.sleep(2000);

			RC_Global.clickUsingXpath(driver, "//a[normalize-space(text())='Maintenance']", "Maintenance link", true, true);
			RC_Global.waitUntilPanelVisibility(driver, "Alerts Management - Maintenance", "TV", true, false);
			
			RC_Global.panelAction(driver, "close", "Alerts Management", true, true);
			RC_Global.panelAction(driver, "expand", "Alerts Management - Maintenance", true, false);
			
			RC_Global.waitElementVisible(driver, 60, "(//standard-grid//div[@class='ui-grid-canvas']//div[@role='gridcell'][5])[1]", "Name", true, false);
			Thread.sleep(2000);
			noOfRows = driver.findElements(By.xpath("//standard-grid//div[@class='ui-grid-canvas']//div[@role='gridcell'][5]")).size();
			availRow = "0";
			for(int iter=1;iter<=noOfRows;iter++) {
				if(driver.findElement(By.xpath("(//standard-grid//div[@class='ui-grid-canvas']//div[@role='gridcell'][5])["+iter+"]")).getText().equalsIgnoreCase(strName)) {
					availRow = Integer.toString(iter);
					break;
				}
			}
			if(availRow.equalsIgnoreCase("0"))
				queryObjects.logStatus(driver, Status.FAIL, "Verify Newly added Maintenance Alert is displayed in the Grid", "Newly added Maintenance Alert is not displayed in the Grid", null);
			else 
				queryObjects.logStatus(driver, Status.PASS, "Verify Newly added Maintenance Alert is displayed in the Grid", "Newly added Maintenance Alert is displayed in the Grid", null);
			
			RC_Global.clickUsingXpath(driver, "(//a[text()='History'])["+availRow+"]", "History link", true, false);
		
			RC_Global.panelAction(driver, "close", "Alerts Management - Maintenance", true, true);
			RC_Global.panelAction(driver, "expand", "Alert History - Maintenance", true, false);
			
			String custNumber = driver.findElement(By.xpath("//div[label[text()='Customer #']]")).getText().trim().split("\n")[1];
			if(custNumber.equalsIgnoreCase("LS008737"))
				queryObjects.logStatus(driver, Status.PASS, "Verify Customer Number", "Customer Number is "+custNumber, null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify Customer Number", "Customer Number is not LS008737", null);
			
			String custName = driver.findElement(By.xpath("//div[label[text()='Customer Name']]")).getText().trim().split("\n")[1];;
			if(custName.equalsIgnoreCase("Kentucky Farm Bureau Mutual Insurance Company"))
				queryObjects.logStatus(driver, Status.PASS, "Verify Customer Name", "Customer Name is "+custName, null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify Customer Name", "Customer Name is not Kentucky Farm Bureau Mutual Insurance Company", null);
			
			String category = driver.findElement(By.xpath("//div[label[text()='Category']]")).getText().trim().split("\n")[1];;
			if(category.equalsIgnoreCase("Maintenance Reminder"))
				queryObjects.logStatus(driver, Status.PASS, "Verify Category", "Category is "+category, null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify Category", "Category is not Maintenance Reminder", null);
			
			String modifiedDate = driver.findElement(By.xpath("(//div[@class='ui-grid-canvas'])[1]/div[1]/div/div[2]/div")).getText().trim();
			if(modifiedDate.equalsIgnoreCase(RC_Global.getDateTime(driver, "MM/dd/yyyy", 0, true)))
				queryObjects.logStatus(driver, Status.PASS, "Verify Modified Date", "Modified Date is today's date", null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify Modified Date", "Modified Date is not today's date", null);
				
			String modifiedBy = driver.findElement(By.xpath("(//div[@class='ui-grid-canvas'])[1]/div[1]/div/div[9]/div")).getText().trim();
			String userFullName = driver.findElement(By.xpath("//div[@user-menu]//li//span/span[not(contains(@class,'ng-hide'))]")).getText().trim();
			if(modifiedBy.equalsIgnoreCase(userFullName))
				queryObjects.logStatus(driver, Status.PASS, "Verify Modified By", "Modified Date is '"+userFullName+"'", null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify Modified Date", "Modified Date is not '"+userFullName+"'", null);
			
			RC_Global.panelAction(driver, "close", "Alert History - Maintenance", true, true);
			
			RC_Global.navigateTo(driver, "Manage", "Administration", "Alerts Management");
			RC_Global.waitUntilPanelVisibility(driver, "Alerts Management", "TV", true, false);
			
			Thread.sleep(2000);

			RC_Global.clickUsingXpath(driver, "//a[normalize-space(text())='Maintenance']", "Maintenance link", true, true);
			RC_Global.waitUntilPanelVisibility(driver, "Alerts Management - Maintenance", "TV", true, false);
			
			RC_Global.panelAction(driver, "close", "Alerts Management", true, true);
			RC_Global.panelAction(driver, "expand", "Alerts Management - Maintenance", true, false);
			
			RC_Global.waitElementVisible(driver, 60, "(//standard-grid//div[@class='ui-grid-canvas']//div[@role='gridcell'][5])[1]", "Name", true, false);
			Thread.sleep(2000);
			noOfRows = driver.findElements(By.xpath("//standard-grid//div[@class='ui-grid-canvas']//div[@role='gridcell'][5]")).size();
			availRow = "0";
			for(int iter=1;iter<=noOfRows;iter++) {
				if(driver.findElement(By.xpath("(//standard-grid//div[@class='ui-grid-canvas']//div[@role='gridcell'][5])["+iter+"]")).getText().equalsIgnoreCase(strName)) {
					availRow = Integer.toString(iter);
					break;
				}
			}
			RC_Global.clickUsingXpath(driver, "(//a[text()='Delete'])["+availRow+"]", "Delete link", true, false);
			RC_Global.clickUsingXpath(driver, "//button[text()='Continue']", "Delete link", true, false);
			
			RC_Global.panelAction(driver, "close", "Alerts Management - Maintenance", true, false);
			
		}
		
	}
}
