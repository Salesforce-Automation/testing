package Manage.Administration.AlertsManagement;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_1_21 {
	public void  PersonalUseAlert_ExternalUser_AddAndEditAlert(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	String CustomerNumber = "LS008742"; String AlertName = "";String HisColumnNmes = "Changes;Date;Alert Name;Alert Description;Modified By;";
	RC_Global.externalUserLogin(driver, "TestUser09", "Yes");
	RC_Global.navigateTo(driver,"Manage","Administration","Alerts Management");
	RC_Global.waitElementVisible(driver, 30, "//a[text()='Personal Use']", "Personal Use Hyperlink", true, false);
	RC_Global.clickUsingXpath(driver, "//a[text()='Personal Use']", "Personal Use Hyperlink", true, true);
	RC_Global.waitUntilPanelVisibility(driver, "Alerts Management - Personal Use", "TV", true, true);
	RC_Global.panelAction(driver, "close", "Alerts Management", true, false);
	RC_Global.panelAction(driver, "expand", "Alerts Management - Personal Use", true, false);
	RC_Global.clickButton(driver, "Add Alert", true, true);
	
	RC_Global.panelAction(driver, "expand", "Alert Setup - New Alert", true, false);
	
	RC_Global.createNode(driver, "Verify New Alert screen layout option");
	RC_Global.verifyScreenComponents(driver, "lable", "Name*", false);
	RC_Global.verifyScreenComponents(driver, "lable", "Category*", false);
	RC_Global.verifyScreenComponents(driver, "lable", "Description", false);
	RC_Global.verifyScreenComponents(driver, "lable", "Customer*", false);
	RC_Global.verifyScreenComponents(driver, "lable", "Distribution", false);
	
	WebElement Alertname = driver.findElement(By.xpath("//input[@name='alertName']"));	
	WebElement Description = driver.findElement(By.xpath("//input[@ng-model='customerAlertItem.CustomerAlertItemDescription']"));	
	AlertName = RandomStringUtils.randomAlphabetic(5);
	RC_Global.createNode(driver, "Enter the mandatory fields in Add alert page");
	RC_Global.selectDropdownOption(driver, "alert", "Missing Submissions", true, false);
	RC_Global.enterInput(driver, AlertName, Alertname, true, true);
	RC_Global.enterInput(driver, "QWERTY", Description, true, true);
	RC_Global.clickUsingXpath(driver, "//div[@ng-show='showMonthly']//input[@name='frequencyRadio']", "", true, false);
	RC_Global.clickUsingXpath(driver, "(//input[@ng-model='day.checked'])[8]", "", true, false);
	RC_Global.selectDropdownOption(driver, "data.TimeZone", "Eastern Standard Time (EST)", true, false);
	RC_Global.selectDropdownOption(driver, "customerAlertItem.DistributionMethod", "Email", true, false);
	RC_Global.clickUsingXpath(driver, "(//td//input[@type='checkbox'])[1]", "", true, false);

	RC_Global.clickButton(driver, "Save", true, true);
	Thread.sleep(3000);
	try {
		RC_Global.waitElementVisible(driver, 120, "//h4[text()='Save Successful']", "Save Success Message", true, true);
		queryObjects.logStatus(driver, Status.PASS, "Verify Save was Successful", "Save was Successful", null);
	}
	catch(Exception e) {
		queryObjects.logStatus(driver, Status.FAIL, "Verify Save was Successful", "Save was not Successful", null);
	}
	RC_Global.panelAction(driver, "close", "Alert Setup - New Alert", true, false);
	
	RC_Global.panelAction(driver, "expand", "Alerts Management - Personal Use", true, false);
	RC_Global.waitElementVisible(driver, 60, "//td[text()='"+AlertName+"']", "", true, false);
	List<WebElement> Alertscloned = driver.findElements(By.xpath("//td[text()='"+AlertName+"']"));
	if(Alertscloned.size()>0)   
		queryObjects.logStatus(driver, Status.PASS, "Newly added Fuel alert", "Newly added Fuel Alert displays under Alerts result grid", null);
	else {
        queryObjects.logStatus(driver, Status.FAIL, "Newly added Fuel alert", "Newly added Fuel Alert failed to displays under Alerts result grid", null);
        RC_Global.endTestRun(driver);
	}
	RC_Global.clickUsingXpath(driver, "(//td[text()='"+AlertName+"'])[1]", "Alert Name", true, true);
	RC_Global.waitUntilPanelVisibility(driver, "Alert Setup - Missing Submissions", "TV", true, true);
	RC_Global.panelAction(driver, "expand", "Alert Setup - Missing Submissions", true, false);
    
	RC_Global.createNode(driver, "Editing created Alert");
	String AlertEdName = driver.findElement(By.xpath("//input[@name='alertName']")).getAttribute("value");
	String DisEdName = driver.findElement(By.xpath("//input[@ng-model='customerAlertItem.CustomerAlertItemDescription']")).getAttribute("value");
	String TimeZone = driver.findElement(By.xpath("//select[@ng-model='data.TimeZone']/option[@selected='selected']")).getText();
	String DisMethod = driver.findElement(By.xpath("//select[@ng-model='customerAlertItem.DistributionMethod']/option[@selected='selected']")).getText();

	if(AlertEdName.contains(AlertName) && DisEdName.contains("QWERTY") && TimeZone.contains("Eastern Standard Time (EST)") && DisMethod.contains(""))
		queryObjects.logStatus(driver, Status.PASS, "Alert Setup screen options", "Alert Setup screen options has all the existing values", null);
	else {
        queryObjects.logStatus(driver, Status.FAIL, "Alert Setup screen options", "Alert Setup screen options doesnot have all the existing values", null);
        RC_Global.endTestRun(driver);
	}
	AlertName = RandomStringUtils.randomAlphabetic(4);
	Alertname = driver.findElement(By.xpath("//input[@name='alertName']"));	
	Description = driver.findElement(By.xpath("//input[@ng-model='customerAlertItem.CustomerAlertItemDescription']"));	
	Alertname.clear();
	Description.clear();
	RC_Global.enterInput(driver, AlertName, Alertname, true, true);
	RC_Global.enterInput(driver, "QWERTYS", Description, true, true);
	RC_Global.selectDropdownOption(driver, "customerAlertItem.DistributionMethod", "Text Message", true, false);
	RC_Global.clickUsingXpath(driver, "//div[@ng-show='showCustom']//input[@name='frequencyRadio']", "", true, false);
	RC_Global.clickUsingXpath(driver, "(//input[@ng-model='month.checked'])[1]", "", true, false);

	RC_Global.clickButton(driver, "Save", true, true);
	Thread.sleep(4000);	
	RC_Global.waitElementVisible(driver, 60, "//h4[normalize-space(text())='Save Successful']", "Save button", false, false);
	RC_Global.verifyDisplayedMessage(driver, "Save Successful", true);
	RC_Global.panelAction(driver, "close", "Alert Setup - Missing Submissions", true, false);
	RC_Global.panelAction(driver, "expand", "Alerts Management - Personal Use", true, false);
	Thread.sleep(2000);
	
	RC_Global.clickUsingXpath(driver, "//td[text()='"+AlertName+"']/following::td[text()='History']", "", true, false);
	RC_Global.waitUntilPanelVisibility(driver, "Alert History", "TV", true, true);
	RC_Global.panelAction(driver, "expand", "Alert History", true, false);
    String HisAlertName = driver.findElement(By.xpath("(//Strong/parent::div)[2]")).getText();
    String CustomerName = driver.findElement(By.xpath("(//Strong/parent::div)[1]")).getText();
    if(HisAlertName.contains(AlertName) && CustomerName.contains("Wawa Inc"))
    	queryObjects.logStatus(driver, Status.PASS, "Customer Name and Alert Name Fields", "Customer Name and Alert Name Field Data matches the Alert name creted", null);
	else {
        queryObjects.logStatus(driver, Status.FAIL, "Customer Name and Alert Name Fields", "Customer Name and Alert Name Fields Data do not matches the Alert name creted", null);
        RC_Global.endTestRun(driver);
	}
    
	RC_Global.createNode(driver, "History Screen grid Column name Validation");
    String [] HisColumnNme = HisColumnNmes.split(";");
	for(int i=0; i<HisColumnNme.length; i++) {
		try {
			driver.findElement(By.xpath("//span[text()='"+HisColumnNme[i]+"']"));
			queryObjects.logStatus(driver, Status.INFO, "Validate Report Column Names--->Column: " + HisColumnNme[i], "Was Found", null);
		}
		catch(Exception e) {
		queryObjects.logStatus(driver, Status.FAIL, "Validate History Screen Column Names--->Column: " + HisColumnNme[i] + "--->Was NOT Found", e.getLocalizedMessage(), e);
		}
	}
	RC_Global.clickUsingXpath(driver, "(//a[text()='View'])[1]", "View Change Details Hyperlink", true, true);
	RC_Global.createNode(driver, "Cloned Alert Changes Section");
	RC_Global.verifyScreenComponents(driver, "sectionHeading", "Old Alert", false);
	RC_Global.verifyScreenComponents(driver, "sectionHeading", "New Alert", false);
	RC_Global.panelAction(driver, "close", "Alert History", true, false);
	RC_Global.panelAction(driver, "expand", "Alerts Management - Personal Use", true, false);

	
	RC_Global.clickUsingXpath(driver, "(//td[text()='"+AlertName+"']/following::a[text()='Delete'])[1]", "Delete Action Button", true, true);
	Thread.sleep(2000);	
	Alertscloned = driver.findElements(By.xpath("//td[text()='"+AlertName+"']"));
	Thread.sleep(3000);
	if(Alertscloned.size()==0)   
			queryObjects.logStatus(driver, Status.PASS, "Delete Action on newly added alert", "The alert is deleted and no longer be seen on the Alerts Management - Fuel screen", null);
		else {
            queryObjects.logStatus(driver, Status.FAIL, "Delete Action on newly added alert", "The alert is failed to deleted and still can be seen on the Alerts Management - Fuel screen", null);
            RC_Global.endTestRun(driver);
		}
	
	RC_Global.logout(driver, false);
	queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	
	}
}
