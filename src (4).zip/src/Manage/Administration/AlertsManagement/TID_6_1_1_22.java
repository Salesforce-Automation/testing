package Manage.Administration.AlertsManagement;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_1_22 {
	public void  PersonalUseAlert_ExternalUse_CloneAndDeleteAlert(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		String CustomerNumber = "LS008742"; String AlertName = "";
		RC_Global.externalUserLogin(driver, "TestUser09", "Yes");
		RC_Global.navigateTo(driver,"Manage","Administration","Alerts Management");
		RC_Global.waitElementVisible(driver, 30, "//a[text()='Personal Use']", "Personal Use Hyperlink", true, false);
		RC_Global.clickUsingXpath(driver, "//a[text()='Personal Use']", "Personal Use Hyperlink", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Alerts Management - Personal Use", "TV", true, true);
		RC_Global.panelAction(driver, "close", "Alerts Management", true, false);
		RC_Global.panelAction(driver, "expand", "Alerts Management - Personal Use", true, false);
		RC_Global.waitElementVisible(driver, 30, "(//a[text()='Clone'])[1]", "", true, false);
		RC_Global.clickUsingXpath(driver, "(//a[text()='Clone'])[1]", "Clone Action Button", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Clone Alert", "TV", true, true);
		RC_Global.panelAction(driver, "expand", "Clone Alert", true, false);
		
		RC_Global.createNode(driver, "Verify Clone Alert screen layout option");
		RC_Global.verifyScreenComponents(driver, "lable", "Category*", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Name*", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Description", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Customer*", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Threshold", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Distribution", false);
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Distribution Groups", false);
		WebElement Alertname = driver.findElement(By.xpath("//input[@name='alertName']"));
		AlertName = RandomStringUtils.randomAlphabetic(5);
		Alertname.clear();
		RC_Global.enterInput(driver, AlertName, Alertname, true, true);
		if (driver.findElements(By.xpath("//div[@ng-show='showMonthly']/input[@type='radio' and @checked]")).size()==0) {
			driver.findElement(By.xpath("//div[@ng-show='showMonthly']/input[@type='radio']")).click();
			RC_Global.clickUsingXpath(driver, "(//input[@type='checkbox' and contains(@ng-checked,'data.SelectedDays')])[1]", "select desired date of month", false, true);
			
			//Time and time Zone			
			WebElement Hours = driver.findElement(By.xpath("//input[@placeholder='HH']"));
			driver.findElement(By.xpath("//input[@placeholder='HH']")).clear();
	        RC_Global.enterInput(driver,"02" , Hours  , false,true);
	        WebElement Minutes = driver.findElement(By.xpath("//input[@placeholder='MM']"));
	        driver.findElement(By.xpath("//input[@placeholder='MM']")).clear();
	        RC_Global.enterInput(driver,"30" , Minutes  , false,true);
	        RC_Global.clickUsingXpath(driver, "//button[@ng-click='toggleMeridian()']", "Time Toggle", true, true);
	        RC_Global.selectDropdownOption(driver, "Time Zone:*", "Central Standard Time (CST)", false,true);
		}
		RC_Global.clickButton(driver, "Save", true, true);
		try {
			RC_Global.waitElementVisible(driver, 120, "//h4[text()='Save Successful']", "Save Success Message", true, true);
			queryObjects.logStatus(driver, Status.PASS, "Verify Save was Successful", "Save was Successful", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify Save was Successful", "Save was not Successful", null);
		}
		RC_Global.panelAction(driver, "close", "Clone Alert", true, false);
		RC_Global.panelAction(driver, "expand", "Alerts Management - Personal Use", true, false);
		
		List<WebElement> Alertscloned = driver.findElements(By.xpath("//td[text()='"+AlertName+"']"));
		if(Alertscloned.size()>0)   
			queryObjects.logStatus(driver, Status.PASS, "Newly added Fuel alert", "Newly added Fuel Alert displays under Alerts result grid", null);
		else {
            queryObjects.logStatus(driver, Status.FAIL, "Newly added Fuel alert", "Newly added Fuel Alert failed to displays under Alerts result grid", null);
            RC_Global.endTestRun(driver);
		}
		WebElement Delete= driver.findElement(By.xpath("//div[contains(@style,'top: 46px')]"));
		executor.executeScript("arguments[0].scrollLeft += 800",Delete);
		Thread.sleep(2000);
		RC_Manage.deleteAlert(driver, AlertName, false);
		Thread.sleep(2000);
		Alertscloned = driver.findElements(By.xpath("//td[text()='"+AlertName+"']"));
		Thread.sleep(3000);
		if(Alertscloned.size()==0)   
				queryObjects.logStatus(driver, Status.PASS, "Delete Action on newly added alert", "The alert is deleted and no longer be seen on the Alerts Management - Fuel screen", null);
			else {
	            queryObjects.logStatus(driver, Status.FAIL, "Delete Action on newly added alert", "The alert is failed to deleted and still can be seen on the Alerts Management - Fuel screen", null);
	            RC_Global.endTestRun(driver);
			}
		RC_Global.panelAction(driver, "close", "Alerts Management - Personal Use", true, true);
		
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

		
	}
}
