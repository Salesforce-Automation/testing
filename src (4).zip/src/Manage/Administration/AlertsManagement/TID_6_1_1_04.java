package Manage.Administration.AlertsManagement;

import java.util.List;
import java.util.NoSuchElementException;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_1_04 {
	public void  FuelAlert_CloneAndDeleteAlert(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		String CustomerNumber = "LS008737"; String AlertName = "";
		String ColumnNmes ="Eligible;Role;Count;Add;Manage";String HisColumnNmes = "Changes;Date;Alert Name;Alert Description;Modified By;";
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,"Manage","Administration","Alerts Management");
		RC_Global.enterCustomerNumber(driver, CustomerNumber, "", "", true);
		RC_Global.waitElementVisible(driver, 30, "//a[text()='Fuel']", "Fuel Hyperlink", true, false);
		RC_Global.clickUsingXpath(driver, "//a[text()='Fuel']", "Fuel Hyperlink", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Alerts Management - Fuel", "TV", true, true);
		RC_Global.panelAction(driver, "close", "Alerts Management", true, false);
		RC_Global.panelAction(driver, "expand", "Alerts Management - Fuel", true, false);
		RC_Global.clickUsingXpath(driver, "(//a[text()='Clone'])[1]", "Clone Action Button", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Clone Alert", "TV", true, true);
		RC_Global.panelAction(driver, "expand", "Clone Alert", true, false);
		
		RC_Global.createNode(driver, "Verify Clone Alert screen layout option");
		RC_Global.verifyScreenComponents(driver, "label", "Category*", false);
		RC_Global.verifyScreenComponents(driver, "label", "Name*", false);
		RC_Global.verifyScreenComponents(driver, "label", "Description", false);
		RC_Global.verifyScreenComponents(driver, "label", "Customer*", false);
		RC_Global.verifyScreenComponents(driver, "label", "Threshold", false);
		RC_Global.verifyScreenComponents(driver, "label", "Distribution", false);
		RC_Global.verifyScreenComponents(driver, "label", "Distribution Groups", false);
		
		RC_Global.createNode(driver, "Distribution Groups grid Column name Validation");
		//column
		String [] expColName = ColumnNmes.split(";");

		for(int i=0; i<expColName.length; i++) {
			try {
				driver.findElement(By.xpath("//span[@column-field-name='"+expColName[i]+"']"));	
				queryObjects.logStatus(driver, Status.INFO, "Validate Report Column Names--->Column: " + expColName[i], "Was Found", null);

			}
			catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Validate Distrubution Group Column Names--->Column: " + expColName[i] + "--->Was NOT Found", e.getLocalizedMessage(), e);
			}
		}
		List<WebElement> Eligible = driver.findElements(By.xpath("//tr//td//input[@type='checkbox']"));
		if(Eligible.size()>0)
			BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Eligible Column", "Eligible Column is populated with a checkbox for each role line entry", null);
		else {
            BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Eligible Column", "Eligible Column is not populated with a checkbox for each role line entry", null);
            RC_Global.endTestRun(driver);
		}
		List<WebElement> ManageHyp = driver.findElements(By.xpath("//tr//td[text()='Manage ']"));
		if(ManageHyp.size()>0)
			BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Manage Hyperlink", "Recipient column is populated with a hyperlinked value for each role line entry", null);
		else {
            BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Manage Hyperlink", "Recipient column is not populated with a hyperlinked value for each role line entry", null);
            RC_Global.endTestRun(driver);
		}
		RC_Global.clickUsingXpath(driver, "//tr//td[text()='Manage ']", "Manage Hyperlink", true, true);
		RC_Global.waitElementVisible(driver, 30, "//h3[text()='Select Fleet Manager to Receive Alerts']", "The Select Employee to Receive Alerts shadowbox", true, true);
		RC_Global.clickUsingXpath(driver, "(//td[text()=' Opted In '])[1]", "", true, false);

		Thread.sleep(1000);
		WebElement DoneButton= driver.findElement(By.xpath("//button[text()='Done']"));
		executor.executeScript("arguments[0].scrollIntoView(true);",DoneButton);
		Thread.sleep(2000);
		RC_Global.clickButton(driver, "Done", true, true);
		
		RC_Global.clickButton(driver, "Save", true, true);
		//Clone Alert
		RC_Global.verifyDisplayedMessage(driver, "The Alert can not have a name that has already been used on another Alert.", true);
		WebElement Alertname = driver.findElement(By.xpath("//input[@name='alertName']"));
		AlertName = RandomStringUtils.randomAlphabetic(5);
		Alertname.clear();
		RC_Global.enterInput(driver, AlertName, Alertname, true, true);
		RC_Global.clickButton(driver, "Save", true, true);
		Thread.sleep(4000);
		RC_Global.verifyDisplayedMessage(driver, "Save Successful", true);
		Thread.sleep(2000);
		RC_Global.downloadAndVerifyFileDownloaded(driver, "Export", "Clone Alert Page Export Excel icon Validation", true);
		Thread.sleep(2000);
		RC_Global.panelAction(driver, "close", "Clone Alert", true, false);
		RC_Global.panelAction(driver, "expand", "Alerts Management - Fuel", true, false);
		//History Validation
		RC_Global.clickUsingXpath(driver, "//td[text()='"+AlertName+"']/following::td[text()='History']", "", true, false);
		RC_Global.waitUntilPanelVisibility(driver, "Alert History", "TV", true, true);
		RC_Global.panelAction(driver, "expand", "Alert History", true, false);
        String HisAlertName = driver.findElement(By.xpath("(//Strong/parent::div)[2]")).getText();
        String CustomerName = driver.findElement(By.xpath("(//Strong/parent::div)[1]")).getText();
        if(HisAlertName.contains(AlertName) && CustomerName.contains("Kentucky Farm"))
        	queryObjects.logStatus(driver, Status.PASS, "Customer Name and Alert Name Fields", "Customer Name and Alert Name Field Data matches the Alert name creted", null);
		else {
            queryObjects.logStatus(driver, Status.FAIL, "Customer Name and Alert Name Fields", "Customer Name and Alert Name Fields Data do not matches the Alert name creted", null);
            RC_Global.endTestRun(driver);
		}
        
    	RC_Global.createNode(driver, "History Screen grid Column name Validation");
        String [] HisColumnNme = HisColumnNmes.split(";");
		for(int i=0; i<HisColumnNme.length; i++) {
			try {
				driver.findElement(By.xpath("//span[text()='"+HisColumnNme[i]+"']"));
				queryObjects.logStatus(driver, Status.INFO, "Validate Report Column Names--->Column: " + expColName[i], "Was Found", null);
			}
			catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Validate History Screen Column Names--->Column: " + HisColumnNme[i] + "--->Was NOT Found", e.getLocalizedMessage(), e);
			}
		}
		RC_Global.clickUsingXpath(driver, "(//a[text()='View'])[1]", "View Change Details Hyperlink", true, true);
		RC_Global.createNode(driver, "Cloned Alert Changes Section");
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Old Alert", false);
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "New Alert", false);
		RC_Global.panelAction(driver, "close", "Alert History", true, false);
		RC_Global.panelAction(driver, "expand", "Alerts Management - Fuel", true, false);
		//Delete Alert
		RC_Manage.deleteAlert(driver, AlertName, false);
//		WebElement Delete= driver.findElement(By.xpath("//div[contains(@style,'top: 46px')]"));
//		executor.executeScript("arguments[0].scrollLeft += 800",Delete);
//		Thread.sleep(2000);
	//	RC_Global.clickUsingXpath(driver, "(//a[text()='"+AlertName+"']/following::a[text()='Delete'])[1]", "Delete Action Button", true, true);
		Thread.sleep(2000);
		List<WebElement> 	Alertscloned = driver.findElements(By.xpath("//td[text()='"+AlertName+"']"));
		Thread.sleep(3000);
		if(Alertscloned.size()==0)   
				queryObjects.logStatus(driver, Status.PASS, "Delete Action on newly added alert", "The alert is deleted and no longer be seen on the Alerts Management - Fuel screen", null);
			else {
	            queryObjects.logStatus(driver, Status.FAIL, "Delete Action on newly added alert", "The alert is failed to deleted and still can be seen on the Alerts Management - Fuel screen", null);
	            RC_Global.endTestRun(driver);
			}
		RC_Global.panelAction(driver, "close", "Alerts Management - Fuel", true, true);
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
