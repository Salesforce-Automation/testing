package Manage.Administration.AlertsManagement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_1_16 {
	public void PersonalUseAlert_ScreenValidationAndResultGrid(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String ColumnNames="Alert Type;Customer #;Customer Name;Category;Name;Description;Threshold;# of Fleet Managers;# of Employees;History;Fleet #;Fleet Name;Account #;Account Name;Sub-Account #;Sub-Account Name;Actions";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Alerts Management");
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", false);
		RC_Global.waitElementVisible(driver, 5, "//a[text()='Personal Use']", "Alert Group is displayed", true,true);
		RC_Global.clickUsingXpath(driver, "//a[text()='Personal Use']", "Fuel", true,true);
		RC_Global.panelAction(driver, "close", "Alerts Management", false,true);
		RC_Global.panelAction(driver, "expand", "Alerts Management", false,true);
		Thread.sleep(2000);
		RC_Global.createNode(driver, "Verification of the search filters in the 'Alerts Management-Personal Use' screen");
		if(driver.findElements(By.xpath("//label[text()='Alert Type Filter']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Alert Type Filter' is displayed in the 'Alerts Management-Personal Use' screen", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "'Alert Type Filter' is not displayed in the 'Alerts Management-Personal Use' screen", "", null);
		}
		if(driver.findElements(By.xpath("//label[text()=' Customer Number ']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Customer Number' is displayed in the 'Alerts Management-Personal Use' screen", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "'Customer Number' is not displayed in the 'Alerts Management-Personal Use' screen", "", null);
		}
		if(driver.findElements(By.xpath("//label[text()='Customer Name']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Customer Name' is displayed in the 'Alerts Management-Personal Use' screen", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "'Customer Name' is not displayed in the 'Alerts Management-Personal Use' screen", "", null);
		}
		if(driver.findElements(By.xpath("//h4[text()='Alerts']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Alerts' is displayed in the 'Alerts Management-Personal Use' screen", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "'Alerts ' is not displayed in the 'Alerts Management-Personal Use' screen", "", null);
		}
		RC_Global.createNode(driver, "Availability of 'Add Alert' button");
		if(driver.findElements(By.xpath("//button[text()='Add Alert']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Add Alert' button is displayed in the 'Alerts Management-Fuel' screen", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "'Add Alert' button is not displayed in the 'Alerts Management-Fuel' screen", "", null);
		}
		RC_Global.verifyColumnNames(driver, ColumnNames, false);
		RC_Global.clickUsingXpath(driver, "//table/tbody/tr[1]/td[5]", "Name", false, true);
		RC_Global.waitElementVisible(driver, 30, "//span[contains(text(),'Alert Setup')]", "Alert Setup - Category", false, true);
		RC_Global.panelAction(driver, "close", "Alert Setup", false,true);
		RC_Global.panelAction(driver, "expand", "Alerts Management", false,true);
		RC_Global.clickUsingXpath(driver, "//table/tbody/tr[1]/td[10]", "History", false, true);
		RC_Global.waitElementVisible(driver, 30, "//span[text()='Alert History']", "Alert History", false, true);
		RC_Global.panelAction(driver, "close", "Alert History", false,true);
		RC_Global.panelAction(driver, "expand", "Alerts Management", false,true);
		RC_Global.clickUsingXpath(driver, "//table/tbody/tr[1]/td[17]/a[1]", "Clone", false, true);
		RC_Global.waitElementVisible(driver, 30, "//span[text()='Clone Alert']", "Clone Alert", false, true);
		RC_Global.panelAction(driver, "close", "Clone Alert", false,true);
		RC_Global.panelAction(driver, "expand", "Alerts Management", false,true);
		RC_Global.clickUsingXpath(driver, "//button/img", "Excel", false, true);
		Thread.sleep(3000);
		RC_Global.downloadAndVerifyFileDownloaded(driver,"Export","Export To Excel Functionality", true);
		RC_Global.panelAction(driver, "close", "Alerts Management", false,true);
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
