package Manage.Administration.AlertsManagement;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_1_15 {

	public void  MaintenanceAlert_ExternalUse_CloneAndDeleteAlert(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver; 
		String CustomerNumber = "LS008742"; String AlertName = "";
		RC_Global.externalUserLogin(driver, "TestUser09", "Yes");
		RC_Global.navigateTo(driver,"Manage","Administration","Alerts Management");
		RC_Global.waitElementVisible(driver, 30, "//a[text()='Maintenance']", "Maintenance Hyperlink", true, false);
		RC_Global.clickUsingXpath(driver, "//a[text()='Maintenance']", "Maintenance Hyperlink", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Alerts Management - Maintenance", "TV", true, true);
		RC_Global.panelAction(driver, "close", "Alerts Management", true, false);
		RC_Global.panelAction(driver, "expand", "Alerts Management - Maintenance", true, false);
		RC_Global.waitElementVisible(driver, 30, "(//a[text()='Clone'])[1]", "", true, false);
		RC_Global.clickUsingXpath(driver, "(//a[text()='Clone'])[1]", "Clone Action Button", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Alert Setup - Maintenance Reminder", "TV", true, true);
		RC_Global.panelAction(driver, "expand", "Alert Setup - Maintenance Reminder", true, false);
		Thread.sleep(3000);
		RC_Global.createNode(driver, "Verify Clone Alert screen layout option");
		RC_Global.verifyScreenComponents(driver, "lable", "Name*", false);
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Clone Alert", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Description", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Customer* ", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Distribution", false);
		Thread.sleep(3000);
		
		WebElement Alertname = driver.findElement(By.xpath("//input[@name='alertName']"));
		AlertName = RandomStringUtils.randomAlphabetic(5);
		Alertname.clear();
		RC_Global.enterInput(driver, AlertName, Alertname, true, true);
		RC_Global.clickButton(driver, "Save", true, true);
		Thread.sleep(6000);
		try {
			RC_Global.waitElementVisible(driver, 120, "//h4[text()='Save Successful']", "Save Success Message", true, true);
			queryObjects.logStatus(driver, Status.PASS, "Verify Save was Successful", "Save was Successful", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify Save was Successful", "Save was not Successful", null);
		}
		RC_Global.panelAction(driver, "close", "Alert Setup - Maintenance Reminder", true, false);
		RC_Global.panelAction(driver, "expand", "Alerts Management - Maintenance", true, false);
		RC_Global.waitElementVisible(driver, 60, "//a[text()='"+AlertName+"']", "", true, false);
		List<WebElement> Alertscloned = driver.findElements(By.xpath("//a[text()='"+AlertName+"']"));
		if(Alertscloned.size()>0)   
			queryObjects.logStatus(driver, Status.PASS, "Newly added Fuel alert", "Newly added Fuel Alert displays under Alerts result grid", null);
		else {
            queryObjects.logStatus(driver, Status.FAIL, "Newly added Fuel alert", "Newly added Fuel Alert failed to displays under Alerts result grid", null);
            RC_Global.endTestRun(driver);
		}
		
		Thread.sleep(2000);
		RC_Global.clickUsingXpath(driver, "(//a[text()='"+AlertName+"']/following::a[text()='Delete'])[1]", "Delete Action Button", true, true);
		Thread.sleep(2000);	
		RC_Global.waitElementVisible(driver, 30, "//h3[text()='Alert will be deleted. Do you want to continue?']", "Alert will be deleted. Do you want to continue?", true, true);
		RC_Global.buttonStatusValidation(driver, "Continue", "Enable", true);
		RC_Global.buttonStatusValidation(driver, "Cancel", "Enable", true);
		RC_Global.clickButton(driver, "Continue", true, true);
		
		Alertscloned = driver.findElements(By.xpath("//td[text()='"+AlertName+"']"));
		Thread.sleep(3000);
		if(Alertscloned.size()==0)   
				queryObjects.logStatus(driver, Status.PASS, "Delete Action on newly added alert", "The alert is deleted and no longer be seen on the Alerts Management - Fuel screen", null);
			else {
	            queryObjects.logStatus(driver, Status.FAIL, "Delete Action on newly added alert", "The alert is failed to deleted and still can be seen on the Alerts Management - Fuel screen", null);
	            RC_Global.endTestRun(driver);
			}
		RC_Global.panelAction(driver, "close", "Alerts Management - Maintenance", true, true);
		
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

		
	}

}
