package Manage.Administration.AlertsManagement;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_1_09 {
	public static void MaintenanceAlert_ValidateMaintenanceCategoryAndExceptionError(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
		RC_Global.enterCustomerNumber(driver, "LS000093", "", "", true);
		RC_Global.waitElementVisible(driver, 30, "//a[text()='Maintenance']", "Maintenance Tab", true, false);
		RC_Global.clickUsingXpath(driver, "//a[text()='Maintenance']", "Maintenance Tab", true, true);
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Enrolled in Maintenance *']]", "Enrolled in Maintenance field", true, true);

		RC_Global.createNode(driver, "Customer not Enrolled in Maintenance");
		if(driver.findElement(By.xpath("//div[label[text()='Enrolled in Maintenance *']]//button[contains(@class,'active')]")).getText().trim().equalsIgnoreCase("No"))
			queryObjects.logStatus(driver, Status.PASS, "Verify Customer not Enrolled in Maintenance", "Customer not Enrolled in Maintenance",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Customer not Enrolled in Maintenance", "Customer Enrolled in Maintenance",null);
		
		RC_Global.panelAction(driver, "close", "Customer Administration", true, true);
		
		RC_Global.navigateTo(driver, "Manage", "Administration", "Alerts Management");
		RC_Global.waitUntilPanelVisibility(driver, "Alerts Management", "TV", true, false);
		
		RC_Global.enterCustomerNumber(driver, "LS000093", "", "", true);
		Thread.sleep(2000);
		RC_Global.verifyColumnNames(driver, "Alert Group;Number Of Alerts", true);
		
		Thread.sleep(1000);
		
		RC_Global.createNode(driver, "Maintenance is not a hyperlink");
		if(driver.findElement(By.xpath("//div[a[text()='Maintenance']]")).getAttribute("class").contains("ng-scope ng-hide"))
			queryObjects.logStatus(driver, Status.PASS, "Verify Maintenance is not a hyperlink", "Maintenance is not a hyperlink",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Maintenance is not a hyperlink", "Maintenance is a hyperlink",null);
		
		RC_Global.panelAction(driver, "close", "Alerts Management", true, true);
		
		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
		RC_Global.waitUntilPanelVisibility(driver, "Customer Administration", "TV", true, false);
		
		RC_Global.enterCustomerNumber(driver, "LS008737", "", "", true);
		RC_Global.waitElementVisible(driver, 30, "//a[text()='Maintenance']", "Maintenance Tab", true, false);
		RC_Global.clickUsingXpath(driver, "//a[text()='Maintenance']", "Maintenance Tab", true, true);
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Enrolled in Maintenance *']]", "Enrolled in Maintenance field", true, true);

		RC_Global.createNode(driver, "Customer Enrolled in Maintenance");
		if(driver.findElement(By.xpath("//div[label[text()='Enrolled in Maintenance *']]//button[contains(@class,'active')]")).getText().trim().equalsIgnoreCase("Yes"))
			queryObjects.logStatus(driver, Status.PASS, "Verify Customer Enrolled in Maintenance", "Customer Enrolled in Maintenance",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Customer Enrolled in Maintenance", "Customer not Enrolled in Maintenance",null);
		
		RC_Global.panelAction(driver, "close", "Customer Administration", true, true);
		
		RC_Global.navigateTo(driver, "Manage", "Administration", "Alerts Management");
		RC_Global.waitUntilPanelVisibility(driver, "Alerts Management", "TV", true, false);
		
		RC_Global.enterCustomerNumber(driver, "LS008737", "", "", true);
		Thread.sleep(2000);
		
		RC_Global.verifyColumnNames(driver, "Alert Group;Number Of Alerts", true);
		
		RC_Global.createNode(driver, "Maintenance is a hyperlink");
		if(driver.findElements(By.xpath("//div[contains(@class,'ng-scope ng-hide')]/a[text()='Maintenance']")).size()==0)
			queryObjects.logStatus(driver, Status.PASS, "Verify Maintenance is a hyperlink", "Maintenance is a hyperlink",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Maintenance is a hyperlink", "Maintenance is not a hyperlink",null);
		
		RC_Global.clickUsingXpath(driver, "//a[normalize-space(text())='Maintenance']", "Maintenance link", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Alerts Management - Maintenance", "TV", true, false);
		
		RC_Global.panelAction(driver, "close", "Alerts Management", true, true);
		RC_Global.panelAction(driver, "expand", "Alerts Management - Maintenance", true, false);
		
		RC_Global.clickButton(driver, "Add Alert", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Alert Setup - New Alert", "TV", true, false);
		
		RC_Global.panelAction(driver, "close", "Alerts Management - Maintenance", true, true);
		RC_Global.panelAction(driver, "expand", "Alert Setup - New Alert", true, false);
		
		RC_Global.createNode(driver, "UI validation of Alert Setup - New Alert screen");
		if(driver.findElements(By.xpath("//div[label[text()='Category*']]//select")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify Category is a field present in Alert Setup - New Alert", "Category is a field present in Alert Setup - New Alert",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Category is a field present in Alert Setup - New Alert", "Category is not a field present in Alert Setup - New Alert",null);
		
		if(driver.findElements(By.xpath("//div[label[text()='Name*']]//input")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify Name is a field present in Alert Setup - New Alert", "Name is a field present in Alert Setup - New Alert",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Name is a field present in Alert Setup - New Alert", "Name is not a field present in Alert Setup - New Alert",null);
		
		if(driver.findElements(By.xpath("//div[label[normalize-space(text())='Description']]//input")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify Description is a field present in Alert Setup - New Alert", "Description is a field present in Alert Setup - New Alert",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Description is a field present in Alert Setup - New Alert", "Description is not a field present in Alert Setup - New Alert",null);
		
		if(driver.findElements(By.xpath("//div[label[normalize-space(text())='Customer*']]//ul/following-sibling::div/input")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify Customer is a field present in Alert Setup - New Alert", "Customer is a field present in Alert Setup - New Alert",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Customer is a field present in Alert Setup - New Alert", "Customer is not a field present in Alert Setup - New Alert",null);
		
		if(driver.findElements(By.xpath("//div[label[text()='Distribution']]//select")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify Distribution is a field present in Alert Setup - New Alert", "Distribution is a field present in Alert Setup - New Alert",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Distribution is a field present in Alert Setup - New Alert", "Distribution is not a field present in Alert Setup - New Alert",null);
		
		if(driver.findElements(By.xpath("//h4[text()='Distribution Groups']")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify Distribution Groups section is present in Alert Setup - New Alert", "Distribution Groups section is present in Alert Setup - New Alert",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Distribution Groups section is present in Alert Setup - New Alert", "Distribution Groups section is not present in Alert Setup - New Alert",null);
		
		if(driver.findElements(By.xpath("//h4[text()='Included Service']")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify Included Service section is present in Alert Setup - New Alert", "Included Service section is present in Alert Setup - New Alert",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Included Service section is present in Alert Setup - New Alert", "Included Service section is not present in Alert Setup - New Alert",null);
		
		if(driver.findElement(By.xpath("//div[label[text()='Category*']]//select/option")).getAttribute("selected").equalsIgnoreCase("true"))
			queryObjects.logStatus(driver, Status.PASS, "Verify 'Maintenance Reminder' is the option selected by default", "'Maintenance Reminder' is the option selected by default", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify 'Maintenance Reminder' is the option selected by default", "'Maintenance Reminder' is not the option selected by default", null);
		
		
		List<WebElement> categoryList = driver.findElements(By.xpath("//div[label[text()='Category*']]//select/option"));
		String[] catList = {"Maintenance Reminder", "Maintenance Reminder - Coming Due", "Maintenance Reminder - Real Time"};
		int notAvailIndex = -1;
		for(WebElement cl:categoryList) {
			boolean flag=false;
			for(int iter=0;iter<catList.length;iter++) {
				if(catList[iter].equalsIgnoreCase(cl.getText())) {
					flag=true;
					notAvailIndex=iter;
					queryObjects.logStatus(driver, Status.INFO, "Verify "+catList[iter]+" is an option in the dropdown", catList[iter]+" is an option in the dropdown", null);
					break;
				}
				
			}
			if(!flag&&notAvailIndex!=-1)
				queryObjects.logStatus(driver, Status.FAIL, "Verify "+catList[(notAvailIndex+1)]+" is an option in the dropdown", catList[(notAvailIndex+1)]+" is not an option in the dropdown", null);

		}
		
		if(driver.findElements(By.xpath("//div[h4[text()='Included Service']]//div[label[text()='Service*']]//select")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify Service field is present in Included Service section of Alert Setup - New Alert", "Service field is present in Included Service section of Alert Setup - New Alert",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Service field is present in Included Service section of Alert Setup - New Alert", "Service field is not present in Included Service section of Alert Setup - New Alert",null);
		
		if(driver.findElements(By.xpath("//div[h4[text()='Included Service']]//label[text()='Thresholds*']")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify Thresholds field is present in Included Service section of Alert Setup - New Alert", "Thresholds field is present in Included Service section of Alert Setup - New Alert",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Thresholds field is present in Included Service section of Alert Setup - New Alert", "Thresholds field is not present in Included Service section of Alert Setup - New Alert",null);
		
		
		List<WebElement> serviceList = driver.findElements(By.xpath("//div[h4[text()='Included Service']]//div[label[text()='Service*']]//select/option"));
		String[] servList = {"LOF", "Perform PM Service - Equipment", "Tire Rotation"};
		notAvailIndex = -1;
		for(WebElement sl:serviceList) {
			boolean flag=false;
			for(int iter=0;iter<servList.length;iter++) {
				if(servList[iter].equalsIgnoreCase(sl.getText().trim())) {
					flag=true;
					notAvailIndex=iter;
					queryObjects.logStatus(driver, Status.INFO, "Verify "+servList[iter]+" is an option in the dropdown", servList[iter]+" is an option in the dropdown", null);
					break;
				}
			}
			if(!flag&&notAvailIndex!=-1)
				queryObjects.logStatus(driver, Status.FAIL, "Verify "+servList[(notAvailIndex+1)]+" is an option in the dropdown", servList[(notAvailIndex+1)]+" is not an option in the dropdown", null);

		}
		
		RC_Global.clickUsingXpath(driver, "//a[text()='Add Service']", "Add Service link", true, false);
		Thread.sleep(2000);
		
		RC_Global.createNode(driver, "Validate Add Service link");
		if(driver.findElements(By.xpath("(//div[h4[text()='Included Service']]//div[label[text()='Service*']]//select)[2]")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify Service field is added in Included Service section of Alert Setup - New Alert", "Service field is added in Included Service section of Alert Setup - New Alert",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Service field is added in Included Service section of Alert Setup - New Alert", "Service field is not added in Included Service section of Alert Setup - New Alert",null);
		
		if(driver.findElements(By.xpath("(//div[h4[text()='Included Service']]//label[text()='Thresholds*'])[2]")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify Thresholds field is added in Included Service section of Alert Setup - New Alert", "Thresholds field is added in Included Service section of Alert Setup - New Alert",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Thresholds field is added in Included Service section of Alert Setup - New Alert", "Thresholds field is not added in Included Service section of Alert Setup - New Alert",null);
		
		RC_Global.clickUsingXpath(driver, "(//a[text()='Remove'])[2]", "Remove Service link for the second service", true, false);
		Thread.sleep(2000);
		
		RC_Global.createNode(driver, "Validate Remove link");
		if(driver.findElements(By.xpath("//div[h4[text()='Included Service']]//div[label[text()='Service*']]//select")).size()==1)
			queryObjects.logStatus(driver, Status.PASS, "Verify the Service field added is removed from Included Service section of Alert Setup - New Alert", "Service field is removed from Included Service section of Alert Setup - New Alert",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify the Service field added is removed from Included Service section of Alert Setup - New Alert", "Service field is not removed from Included Service section of Alert Setup - New Alert",null);
		
		if(driver.findElements(By.xpath("//div[h4[text()='Included Service']]//label[text()='Thresholds*']")).size()==1)
			queryObjects.logStatus(driver, Status.PASS, "Verify Thresholds field added is removed from Included Service section of Alert Setup - New Alert", "Thresholds field is removed in Included Service section of Alert Setup - New Alert",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Thresholds field added is removed from Included Service section of Alert Setup - New Alert", "Thresholds field is not removed in Included Service section of Alert Setup - New Alert",null);
		
		RC_Global.buttonStatusValidation(driver, " Save ", "Disable", true);
		
		WebElement name = driver.findElement(By.xpath("//div[label[text()='Name*']]//input"));
		WebElement miles = driver.findElement(By.xpath("(//div[div[span[text()='Past Due']]]//input)[1]"));
		WebElement days = driver.findElement(By.xpath("(//div[div[span[text()='Past Due']]]//input)[2]"));
		RC_Global.enterInput(driver, "Sample Test "+RandomStringUtils.randomNumeric(1), name, true, true);
		RC_Global.clickUsingXpath(driver, "//div[h4[text()='Included Service']]//div[label[text()='Service*']]//select", "Select Service option", true, true);
		RC_Global.clickUsingXpath(driver, "//div[h4[text()='Included Service']]//div[label[text()='Service*']]//select/option[2]", "Select Service option", true, true);
		
		RC_Global.enterInput(driver, RandomStringUtils.randomNumeric(2), miles, true, true);
				
		RC_Global.enterInput(driver, RandomStringUtils.randomNumeric(1), days, true, true);
		Thread.sleep(2000);
		
		RC_Global.buttonStatusValidation(driver, "Save", "Enable", true);
		
		
	}
}
