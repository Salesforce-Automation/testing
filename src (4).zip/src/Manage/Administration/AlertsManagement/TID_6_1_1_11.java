package Manage.Administration.AlertsManagement;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.apache.commons.lang3.StringUtils;
import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import MF.Source.Cred;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_1_11 {
	public static String editHistory = "";
	public void MaintenanceAlert_AddAndEditAlert(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
	String menu = "Manage";
	String firstSubMenu = "Administration";
	String secondSubMenu = "Alerts Management";
	String SearchFilters ="Category*;Name*;Description ;Customer* ;Distribution";
	
	RC_Global.login(driver);
	RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
	RC_Global.enterCustomerNumber(driver, "LS008742", "", "", false);
	RC_Global.waitUntilPanelVisibility(driver,"Alerts Management","TV", true,false);
	RC_Global.waitElementVisible(driver, 60, "//standard-grid//div[1][contains(@ng-style,'Viewport')]", "Alert Management grid is displayed", true,false);
	RC_Global.clickUsingXpath(driver,"//a[text()='Maintenance']" , "Maintenance", true,true);
	RC_Global.waitUntilPanelVisibility(driver,"Alerts Management - Maintenance","TV", true,false);
	RC_Manage.waitUntilMethods(driver, "//div[@ng-if='vm.loading']","","", "invisible");
	RC_Global.waitElementVisible(driver, 60, "(//standard-grid/div/div/div/div/div[1]/div[2]/div/div)[1]", "Alert Management grid is displayed", true,false);
	
	
	RC_Global.panelAction(driver, "close", "Alerts Management", false,true);
	RC_Global.panelAction(driver, "expand", "Alerts Management - Maintenance", false,true);
	RC_Global.clickButton(driver, "Add Alert", true,true);
	RC_Global.waitUntilPanelVisibility(driver,"Alert Setup - New Alert","TV", true,false);
	RC_Global.panelAction(driver, "close", "Alerts Management - Maintenance", false,true);
	RC_Global.panelAction(driver, "expand", "Alert Setup - New Alert", false,true);
	RC_Global.validateSpecifiedSearchFilters(driver, SearchFilters, false);
	RC_Global.verifyScreenComponents(driver, "sectionHeading", "Distribution Groups", false);
	RC_Global.verifyScreenComponents(driver, "sectionHeading", "Included Service", false);
	Thread.sleep(4000);
	RC_Global.waitElementVisible(driver, 60, "(//div/input[@type='checkbox'])[1]", "Distribution group grid is displayed", true,false);
	RC_Global.clickUsingXpath(driver,"//a[text()='Edit Templates']" , "Edit Templates", true,false);
	RC_Global.validateHeaderName(driver, "Modify Alert Template", false);
	
	String radioValues1 = driver.findElement(By.xpath("(//input[@name='selectedEmailMessage'])[1]")).getText();
	String radioValues2 = driver.findElement(By.xpath("(//input[@name='selectedEmailMessage'])[2]")).getText();
	
	queryObjects.logStatus(driver, Status.PASS, "Selecting Option value for email message is---->", radioValues1, null);
	queryObjects.logStatus(driver, Status.PASS, "Selecting Option value for email message is---->", radioValues2, null);
	RC_Global.clickButton(driver, "Done", true,true);
	Thread.sleep(4000);
	
	RC_Global.verifyColumnNames(driver, "Eligible;Role;Count;Recipient", false);
	
	
	String DistributionRole1 = driver.findElement(By.xpath("//standard-grid//div[1]/div[2]//div[1]/div/div[2]/div")).getText();
	String DistributionRole2 = driver.findElement(By.xpath("//standard-grid//div[1]/div[2]//div[2]/div/div[2]/div")).getText();
	String DistributionRole3 = driver.findElement(By.xpath("//standard-grid//div[1]/div[2]//div[3]/div/div[2]/div")).getText();
	
	queryObjects.logStatus(driver, Status.PASS, "Distribution Group Role present in the grid are---->", DistributionRole1 +  DistributionRole2  +  DistributionRole3, null);

	  driver.findElement(By.xpath("(//input[@type='checkbox' and contains(@class,'not-empty')])[1]")).isSelected();
	  driver.findElement(By.xpath("(//input[@type='checkbox' and contains(@class,'not-empty')])[2]")).isSelected();
	  driver.findElement(By.xpath("(//input[@type='checkbox' and contains(@class,'not-empty')])[3]")).isSelected();
	  String services = driver.findElement(By.xpath("//select[@name='services']//parent::div//parent::div//label")).getText();
	  String dropdownvalues2 = "LOF;Perform PM Service - Equipment;Tire Rotation";
		RC_Global.dropdownValuesValidation(driver,dropdownvalues2,"//select[@name='services']",false,true);
		
		String threshold = driver.findElement(By.xpath("//label[normalize-space(text())='Service*']//following::label[1]")).getText();
		String milesT = driver.findElement(By.xpath("//label[normalize-space(text())='Thresholds*']//following::label[1]")).getText();
		String days = driver.findElement(By.xpath("//label[normalize-space(text())='Thresholds*']//following::label[2]")).getText();
    
		queryObjects.logStatus(driver, Status.PASS, "Included Services Header with Following Fields---->", services +  threshold  +  milesT  +  days, null);
		//Add Alert
     WebElement element = driver.findElement(By.xpath("//input[@name='alertName']"));
     String alertname = "Alert_Sample_"+RandomStringUtils.randomAlphabetic(2);
		RC_Global.enterInput(driver, alertname, element  , false,true);
		RC_Global.selectDropdownOption(driver, "Service*", " Tire Rotation ", false,true);	
		 WebElement miles = driver.findElement(By.xpath("//input[@name='miles_0']"));
			RC_Global.enterInput(driver, "1000", miles  , false,true);
			Thread.sleep(2000);
			RC_Global.clickUsingXpath(driver,"//a[text()='Add Service']" , "Add Service", true,true);
//			RC_Global.selectDropdownOption(driver, "Service*", " Perform PM Service ", false,true);	
			
			RC_Global.clickUsingXpath(driver,"(//label[contains(text(),'Service*')]/following-sibling::div//select)[2]//option[contains(text(),'Perform PM Service')]" , "Services", true,true);
			 WebElement miles1 = driver.findElement(By.xpath("//input[@name='miles_1']"));
				RC_Global.enterInput(driver, "2000", miles1  , false,true);
			RC_Global.clickButton(driver, "Save", true,true);
		
			try {
				RC_Global.waitElementVisible(driver, 120, "//h4[text()='Save Successful']", "Save Success Message", true, true);
				queryObjects.logStatus(driver, Status.PASS, "Verify Save was Successful", "Save was Successful", null);
			}
			catch(Exception e) {
				queryObjects.logStatus(driver, Status.FAIL, "Verify Save was Successful", "Save was not Successful", null);
			}
			
			Thread.sleep(1000);
		
			RC_Global.panelAction(driver, "close", "Alert Setup - New Alert", false,true);
			RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
			RC_Global.enterCustomerNumber(driver, "LS008742", "", "", false);
			RC_Global.waitUntilPanelVisibility(driver,"Alerts Management","TV", true,false);
			Thread.sleep(8000);
			RC_Global.waitElementVisible(driver, 30, "//standard-grid//div[1][contains(@ng-style,'Viewport')]", "Alert Management grid is displayed", true,true);
			RC_Global.clickUsingXpath(driver,"//a[text()='Maintenance']" , "Maintenance", true,true);
			RC_Global.waitUntilPanelVisibility(driver,"Alerts Management - Maintenance","TV", true,false);
			RC_Global.panelAction(driver, "close", "Alerts Management", false,true);
			RC_Global.panelAction(driver, "expand", "Alerts Management - Maintenance", false,true);
			RC_Global.waitElementVisible(driver, 60, "//standard-grid//div[1]/div[2]//div[1]/div/div[5]/div", "Alerts Management - Maintenance grid row", true,true);
			
			String Maintenancecategory = driver.findElement(By.xpath("(//standard-grid//div//div[1]/div[2]//div[4]/div)[1]")).getText();
			String MaintenanceName = driver.findElement(By.xpath("(//standard-grid//div[1]/div[2]//div[1]/div/div[5]/div/a)[1]")).getText();
			String Maintenancethreshold = driver.findElement(By.xpath("(//standard-grid//div[1]/div[2]//div[1]//div[7]/div)[1]")).getText();
			
			queryObjects.logStatus(driver, Status.PASS, "Newly Added Maintenance Alerts Category---->", Maintenancecategory, null);
			queryObjects.logStatus(driver, Status.PASS, "Newly Added Maintenance Alerts Name---->", MaintenanceName, null);
			queryObjects.logStatus(driver, Status.PASS, "Newly Added Maintenance Alerts Threshold---->", Maintenancethreshold, null);
			Thread.sleep(2000);
			RC_Manage.waitUntilMethods(driver, "//div[@ng-if='vm.loading']","","", "invisible");
			try {
				RC_Global.waitElementVisible(driver, 30, "//standard-grid//div[1]//div[5]//a[text()='"+MaintenanceName+"']", "Newly added alert", true, true);
				queryObjects.logStatus(driver, Status.PASS, "Verify newly added alert is present in the Grid", "Newly added alert is present in the Grid", null);
//				RC_Global.clickUsingXpath(driver, "//standard-grid//div[1]//div[5]//a[text()='"+MaintenanceName+"']", "Newly Added alert", true, true);
				
			}
			catch(Exception e) {
				queryObjects.logStatus(driver, Status.FAIL, "Verify newly added is present in the Grid", "Newly added is not present in the Grid", null);
			}
			driver.findElement(By.xpath("(//input[@name='customerInput'])[2]")).clear();
			WebElement cusNumber1 = driver.findElement(By.xpath("(//input[@name='customerInput'])[2]"));
			RC_Global.enterInput(driver, "LS008742", cusNumber1, false, true);
			driver.findElement(By.xpath("//div[@class='input-group']//ul/li//a")).click();
			RC_Global.waitElementVisible(driver, 60, "(//standard-grid/div/div/div/div/div[1]/div[2]/div/div)[1]", "Alert Management grid is displayed", true,false);
			
			//Edit Alert
			Thread.sleep(4000);
			List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("//standard-grid/div/div/div/div/div[1]/div[2]/div/div"));  
			int rowcnt=Getgridrowcnt.size();
			boolean flag = false;
			for(int i=1; i<=rowcnt;i++) {
				WebElement name = driver.findElement(By.xpath("//standard-grid//div[1]/div[2]/div/div["+i+"]/div/div[5]/div/a"));
				String AddAlertName = name.getText();
				if(!AddAlertName.isEmpty()) {
					WebElement Name = driver.findElement(By.xpath("//standard-grid//div[1]/div[2]/div/div["+i+"]/div/div[5]/div/a"));
					if((AddAlertName.contains(alertname))) {
					Thread.sleep(2000);
					flag = true;
					Name.click();
					break;}
				}
			}
			if(flag){
				queryObjects.logStatus(driver, Status.PASS, "Maintenance Edit Alert clicked", "Successfully", null);}
			else {
				queryObjects.logStatus(driver, Status.FAIL, "Maintenance Edit Alert clicking", "Failed", null);}
	
			RC_Global.waitUntilPanelVisibility(driver,"Alert Setup - Maintenance Reminder","TV", true,false);
			RC_Global.waitElementVisible(driver, 50, "(//a[text()='Remove'])[1]", "Included Serives", false, true);
			RC_Global.clickUsingXpath(driver,"(//a[text()='Remove'])[1]" , "Remove Service", true,true);
			queryObjects.logStatus(driver, Status.PASS, "Name, Description , Distribution and service section fields are","Editable", null);
			 String  category = driver.findElement(By.xpath("//select[contains(@ng-model,'selectedCategory') and @disabled='disabled']")).getCssValue("background-color");
	           queryObjects.logStatus(driver, Status.PASS, "Category Box is Locked, Greyed out and Cannot be Changed or Deleted ---->", category , null);
	           String customer = driver.findElement(By.xpath("(//input[contains(@ng-model,'customerName') and @disabled='disabled'])[2]")).getCssValue("background-color");
	           queryObjects.logStatus(driver, Status.PASS, "Customer # Box is Locked, Greyed out and Cannot be Changed or Deleted ---->", customer , null);
	           WebElement elementedit = driver.findElement(By.xpath("//input[@name='alertName']"));
	           String alertnameedit =  "Alert_Sample_"+RandomStringUtils.randomNumeric(3);
	      		RC_Global.enterInput(driver,alertnameedit, elementedit  , false,true);
	      		RC_Global.clickButton(driver, "Save", true,true);
				Thread.sleep(8000);
				RC_Global.panelAction(driver, "close", "Alert Setup - Maintenance Reminder", false,true);
				Thread.sleep(3000);
				String EditMaintenancecategory = driver.findElement(By.xpath("(//standard-grid//div//div[1]/div[2]//div[4]/div)[1]")).getText();
				String EditMaintenanceName = driver.findElement(By.xpath("(//standard-grid//div[1]/div[2]//div[1]/div/div[5]/div/a)[1]")).getText();
				String EditMaintenancethreshold = driver.findElement(By.xpath("(//standard-grid//div[1]/div[2]//div[1]//div[7]/div)[1]")).getText();
				
				queryObjects.logStatus(driver, Status.PASS, "Edited Maintenance Alerts Category---->", EditMaintenancecategory, null);
				queryObjects.logStatus(driver, Status.PASS, "Edited Maintenance Alerts Name---->", EditMaintenanceName, null);
				queryObjects.logStatus(driver, Status.PASS, "Edited Maintenance Alerts Threshold---->", EditMaintenancethreshold, null);
	           //Verification of Edited Fields
				RC_Global.panelAction(driver, "expand", "Alerts Management - Maintenance", false,true);
				Thread.sleep(3000);
				driver.findElement(By.xpath("(//input[@name='customerInput'])[2]")).clear();
				WebElement cusNumber = driver.findElement(By.xpath("(//input[@name='customerInput'])[2]"));
				RC_Global.enterInput(driver, "LS008742", cusNumber, false, true);
				driver.findElement(By.xpath("//div[@class='input-group']//ul/li//a")).click();
				RC_Global.waitElementVisible(driver, 60, "(//standard-grid/div/div/div/div/div[1]/div[2]/div/div)[1]", "Alert Management grid is displayed", true,false);
				
				try {
					RC_Global.waitElementVisible(driver, 60, "//standard-grid//div[1]//div[5]//a[contains(text(),'"+alertnameedit+"')]", "Newly editted alert", true, true);
					queryObjects.logStatus(driver, Status.PASS, "Verify newly editted alert is present in the Grid", "Newly editted alert is present in the Grid", null);
//					RC_Global.clickUsingXpath(driver, "//standard-grid//div[1]//div[5]//a[text()='"+EditMaintenanceName+"']", "Newly editted alert", true, true);
					
				}
				catch(Exception e) {
					queryObjects.logStatus(driver, Status.FAIL, "Verify newly editted is present in the Grid", "Newly editted is not present in the Grid", null);
				}
				//
				Thread.sleep(5000);
				List<WebElement> Getgridrowcnt2= driver.findElements(By.xpath("//standard-grid/div/div/div/div/div[1]/div[2]/div/div"));  
				int rowcnt2=Getgridrowcnt2.size();
				for(int i=1; i<=rowcnt2;i++) {
					WebElement name = driver.findElement(By.xpath("//standard-grid//div[1]/div[2]/div/div["+i+"]/div/div[5]/div"));
					String EditAlertName = name.getText();
					if(!EditAlertName.isEmpty()) {
						WebElement Name = driver.findElement(By.xpath("//standard-grid//div[1]/div[2]/div/div["+i+"]/div/div[5]/div/a"));
						if((EditAlertName.contains(alertnameedit))) {
						Thread.sleep(2000);
						Name.click();
						break;}
					}
			}
				
				RC_Global.waitUntilPanelVisibility(driver,"Alert Setup - Maintenance Reminder","TV", true,false);
				RC_Global.waitElementVisible(driver, 60, "//h4[text()='Included Service']", "Included Service", false, false);
				RC_Global.panelAction(driver, "close", "Alert Setup - Maintenance Reminder", false,true);
				RC_Global.panelAction(driver, "expand", "Alerts Management - Maintenance", false,true);
				Thread.sleep(2000);
				
				//Maintenance - History
				List<WebElement> Getgridrowcnt1= driver.findElements(By.xpath("//standard-grid/div/div/div/div/div[1]/div[2]/div/div"));  
				int rowcnt1=Getgridrowcnt1.size();
				boolean flagH = false;
				for(int i=1; i<=rowcnt1;i++) {
					WebElement name = driver.findElement(By.xpath("//standard-grid//div[1]/div[2]/div/div["+i+"]/div/div[5]/div"));
				String	EditName = name.getText();
					if(!EditName.isEmpty()) {
						WebElement history = driver.findElement(By.xpath("//standard-grid//div[2]/div/div[2]/div/div["+i+"]/div/div[1]/div"));
						editHistory = history.getText();
						if((EditName.contains(alertnameedit))) {
						Thread.sleep(4000);
						flagH = true;
						history.click();
						break;}
					}
				}
				if(flagH){
					queryObjects.logStatus(driver, Status.PASS, "Maintenance Alert - History clicked", "Successfully", null);}
				else {
					queryObjects.logStatus(driver, Status.FAIL, "Maintenance Alert - History clicking", "Failed", null);}
		
//				RC_Global.waitUntilPanelVisibility(driver,"Alert History - Maintenance","TV", true,false);/look
				RC_Global.panelAction(driver, "expand", "Alert History - Maintenance", false,true);
//				RC_Global.waitElementVisible(driver, 60, "//alerts-history-grid//..//div[2]//div[1]/div/div[2]/div", "Grid Result", false, false);
				
				String Customerno = driver.findElement(By.xpath("//label[text()='Customer #']//parent::div")).getText();
				String customerName = driver.findElement(By.xpath("//label[text()='Customer Name']//parent::div")).getText();
				String Category = driver.findElement(By.xpath("//label[text()='Category']//parent::div")).getText();
				
				queryObjects.logStatus(driver, Status.PASS, "Alert History Customer # is---->", Customerno, null);
				queryObjects.logStatus(driver, Status.PASS, "Alert History Customer Name is---->", customerName, null);
				queryObjects.logStatus(driver, Status.PASS, "Alert History Category is---->", Category, null);
				
				RC_Global.buttonStatusValidation(driver, "Search", "Presence", false);
				RC_Global.buttonStatusValidation(driver, "Reset", "Presence", false);
				String currentDate = RC_Manage.AddDateStr(0, "MM/dd/yyyy", "", null, "CST");//updated
				JavascriptExecutor executor = (JavascriptExecutor)driver;
				   Thread.sleep(1000);
			executor.executeScript("document.body.style.zoom = '80%'");
			Thread.sleep(2000);
				String modifiedBy=driver.findElement(By.xpath("//alerts-history-grid//..//div[2]//div[1]/div/div[9]/div")).getText();
				queryObjects.logStatus(driver, Status.PASS, "Maintenance Alert is Modified By---->", modifiedBy, null);
				Thread.sleep(3000);
				executor.executeScript("document.body.style.zoom = '100%'");
				String recordDateTime=driver.findElement(By.xpath("//alerts-history-grid//..//div[2]//div[1]/div/div[2]/div")).getText();
				String	recorddateTime = recordDateTime.trim();
				//String loggedUser = driver.findElement(By.xpath("//span[@id='Span1']")).getText();
				//String withoutWhitespaceloggedUser = StringUtils.deleteWhitespace(loggedUser);
				queryObjects.logStatus(driver, Status.INFO, "Maintenance Alert is Logged By---->",RC_Global.userLogged , null);
				if(modifiedBy.toUpperCase().contains(RC_Global.userLogged) && recorddateTime.trim().equals(currentDate.trim()))
				{
					queryObjects.logStatus(driver, Status.PASS, "Username and Created date verification in Alert History", "Successful", null);
				}
				else {
					queryObjects.logStatus(driver, Status.FAIL, "Username and created date verification","failed",null );
				}
				//History Details pop-up
				RC_Global.clickUsingXpath(driver,"(//a[text()='Details'])[1]" , "Details", true,true);
				RC_Global.validateHeaderName(driver, "Alert History Detail", false);
				RC_Manage.validateSectionFieldDatas(driver, "(//label[text()='Alert Name:']//following::div//p)[1]","Maintenance Alert History", "Alert Name", false);
				RC_Manage.validateSectionFieldDatas(driver, "(//label[text()='Created By:']//following::div//p)[1]","Maintenance Alert History", "Created By", false);
				RC_Manage.validateSectionFieldDatas(driver, "(//label[text()='Created Date:']//following::div//p)[1]","Maintenance Alert History", "Created Date", false);
				RC_Manage.validateSectionFieldDatas(driver, "(//label[text()='Action:']//following::div//p)[1]","Maintenance Alert History", "Action", false);
				RC_Manage.validateSectionFieldDatas(driver, "(//label[text()='Modified By:']//following::div//p)[1]","Maintenance Alert History", "Modified By", false);
				RC_Manage.validateSectionFieldDatas(driver, "(//label[text()='Modified Date:']//following::div//p)[1]","Maintenance Alert History", "Modified Date", false);
				
				String Item = driver.findElement(By.xpath("//alerts-history-details-template//standard-grid//div[1]/div[2]/div/div[1]/div/div[1]/div")).getText();
				String Oldvalue = driver.findElement(By.xpath("//alerts-history-details-template//standard-grid//div[1]/div[2]/div/div[1]/div/div[2]/div")).getText();
				String NewValue = driver.findElement(By.xpath("//alerts-history-details-template//standard-grid//div[1]/div[2]/div/div[1]/div/div[3]/div")).getText();
				
				queryObjects.logStatus(driver, Status.PASS, "The Alert 'Item' which changed is ---->", Item, null);
				queryObjects.logStatus(driver, Status.PASS, "The Alert Old Value is---->", Oldvalue, null);
				queryObjects.logStatus(driver, Status.PASS, "The Alert New Value is---->", NewValue, null);
				
				RC_Global.clickUsingXpath(driver,"//h3[text()='Alert History Detail']//parent::div//i" , "Alert History Detail Close", true,true);
				
				RC_Global.panelAction(driver, "close", "Alert History - Maintenance", false,true);
				RC_Global.clickUsingXpath(driver, "(//a[text()='"+alertnameedit+"']/following::a[text()='Delete'])[1]", "Delete Action Button", true, true);
				Thread.sleep(2000);	
				RC_Global.waitElementVisible(driver, 30, "//h3[text()='Alert will be deleted. Do you want to continue?']", "Alert will be deleted. Do you want to continue?", true, true);
				RC_Global.clickButton(driver, "Continue", true, true);
				
				List<WebElement> Alert = driver.findElements(By.xpath("//td[text()='"+alertnameedit+"']"));
				Thread.sleep(3000);
				if(Alert.size()==0)   
						queryObjects.logStatus(driver, Status.PASS, "Delete Action on newly added alert", "The alert is deleted and no longer be seen on the Alerts Management - Fuel screen", null);
					else {
			            queryObjects.logStatus(driver, Status.FAIL, "Delete Action on newly added alert", "The alert is failed to deleted and still can be seen on the Alerts Management - Fuel screen", null);
			            RC_Global.endTestRun(driver);
					}
				RC_Global.logout(driver, false);
				queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
				
	}
}
