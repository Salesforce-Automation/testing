package Manage.Administration.AlertsManagement;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_1_20 {
	public void PersonalUseAlert_ExternalUserAccess(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String AlertGroup ="";
		String NumberOfAlert ="";
		int RowCount, flag=0;
		
		RC_Global.externalUserLogin(driver, "kentuckytest3", "Yes");
		RC_Global.navigateTo(driver, "Manage", "Administration", "Alerts Management");
		if(driver.findElement(By.xpath("//input[@name='customerInput']")).getAttribute("disabled").contains("true"))
		{ 
			queryObjects.logStatus(driver, Status.PASS, "Alert management page open with customer number grayed out and not modifiable", "", null);
		}
		if(driver.findElements(By.xpath("//div[@ui-grid-row='row']")).size()>0)
		{
			RowCount = driver.findElements(By.xpath("//div[@ui-grid-row='row']")).size();
			queryObjects.logStatus(driver, Status.PASS, "Total number of 'Alert Groups' displayed is ", Integer.toString(RowCount), null);
			for(int i=1;i<=RowCount;i++)
			{
				AlertGroup = driver.findElement(By.xpath("(//div[@ui-grid-row='row'])["+i+"]/div/div/a")).getText();
				NumberOfAlert = driver.findElement(By.xpath("((//div[@ui-grid-row='row'])["+i+"]/div/div)[3]")).getText();
				queryObjects.logStatus(driver, Status.PASS, ""+AlertGroup+ "'Alert Group'is dispalyed with corresponding 'Number Of Alerts'", NumberOfAlert, null);
			}
			for(int i=1;i<=RowCount;i++)
			{
				AlertGroup = driver.findElement(By.xpath("(//div[@ui-grid-row='row'])["+i+"]/div/div/a")).getText();
				NumberOfAlert = driver.findElement(By.xpath("((//div[@ui-grid-row='row'])["+i+"]/div/div)[3]")).getText();
				RC_Global.clickUsingXpath(driver, "(//div[@ui-grid-row='row'])["+i+"]/div/div/a", AlertGroup, false, true);
				RC_Global.panelAction(driver, "close", "Alerts Management", false,true);
				RC_Global.panelAction(driver, "expand", "Alerts Management", false,true);
				RC_Global.clickButton(driver, "Add Alert", false, true);
				if(driver.findElements(By.xpath("//span[text()='Alert Setup - New Alert']")).size()>0)
				{
					queryObjects.logStatus(driver, Status.PASS, "'Add Alert' screen is opened for "+AlertGroup+"", "", null);
				}
				RC_Global.panelAction(driver, "close", "Alert Setup", false,true);
				RC_Global.panelAction(driver, "expand", "Alerts Management - "+AlertGroup+"", false,true);
				
				
				if(!AlertGroup.equals("Maintenance"))
				{
					if(NumberOfAlert.equals("0"))
					{
						queryObjects.logStatus(driver, Status.PASS, "There is no alert for ", AlertGroup, null);
						RC_Global.panelAction(driver, "close", "Alerts Management - "+AlertGroup+"", false,true);
						RC_Global.navigateTo(driver, "Manage", "Administration", "Alerts Management");
						continue;
					}
					RC_Global.clickUsingXpath(driver, "//tr[1]/td[5]", "Alert Name", false, true);
					if(driver.findElements(By.xpath("//span[contains(text(),'Alert Setup')]")).size()>0)
					{
						queryObjects.logStatus(driver, Status.PASS, "'Edit Alert' screen is opened for "+AlertGroup+"", "", null);
					}
					RC_Global.panelAction(driver, "close", "Alert Setup", false,true);
					RC_Global.panelAction(driver, "expand", "Alerts Management - "+AlertGroup+"", false,true);
					RC_Global.clickUsingXpath(driver, "//table/tbody/tr[1]/td[17]/a[1]", "Clone Alert", false, true);
					if(driver.findElements(By.xpath("//span[text()='Clone Alert']")).size()>0)
					{
						queryObjects.logStatus(driver, Status.PASS, "'Clone Alert' screen is opened for "+AlertGroup+"", "", null);
					}
					RC_Global.panelAction(driver, "close", "Clone Alert", false,true);
					RC_Global.panelAction(driver, "close", "Alerts Management - "+AlertGroup+"", false,true);
					RC_Global.navigateTo(driver, "Manage", "Administration", "Alerts Management");
					
				}
				else
				{
					if(NumberOfAlert.equals("0"))
					{
						queryObjects.logStatus(driver, Status.PASS, "There is no alert for ", AlertGroup, null);
						RC_Global.panelAction(driver, "close", "Alerts Management - "+AlertGroup+"", false,true);
						RC_Global.navigateTo(driver, "Manage", "Administration", "Alerts Management");
						continue;
					}
					RC_Global.clickUsingXpath(driver, "//div[@role='gridcell'][5]/div/a", "Alert Name", false, true);
					if(driver.findElements(By.xpath("//span[contains(text(),'Alert Setup')]")).size()>0)
					{
						queryObjects.logStatus(driver, Status.PASS, "'Edit Alert' screen is opened for "+AlertGroup+"", "", null);
					}
					RC_Global.panelAction(driver, "close", "Alert Setup", false,true);
					RC_Global.panelAction(driver, "expand", "Alerts Management - "+AlertGroup+"", false,true);
					RC_Global.clickUsingXpath(driver, "//a[text()='Clone'][1]", "Clone Alert", false, true);
					if(driver.findElements(By.xpath("//h4[text()='Clone Alert']")).size()>0)
					{
						queryObjects.logStatus(driver, Status.PASS, "'Clone Alert' screen is opened for "+AlertGroup+"", "", null);
					}
					RC_Global.panelAction(driver, "close", "Alert Setup", false,true);
					RC_Global.panelAction(driver, "close", "Alerts Management - "+AlertGroup+"", false,true);
					RC_Global.navigateTo(driver, "Manage", "Administration", "Alerts Management");
				}
			}
			RC_Global.panelAction(driver, "close", "Alerts Management", false,true);
			RC_Global.logout(driver, false);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "No Alert Groups are displayed", "", null);
		}
		
		RC_Global.externalUserLogin(driver, "mobiletestdriver4", "Yes");
		RC_Global.createNode(driver, "Verify Manage menu access for 'Driver'");
		for(int i=1;i<=driver.findElements(By.xpath("//div[@class='top-nav']/ul/li/a/span")).size();i++)
		{
			String menu = driver.findElement(By.xpath("//div[@class='top-nav']/ul/li/a/span")).getText();
			if(menu.equals("Manage"))
			{
				flag++;
			}
		}
		if(flag==0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Drivers have no access to 'Manage' menu", "", null);
		}
		RC_Global.logout(driver, false);
		
		RC_Global.externalUserLogin(driver, "TestAdmin", "Yes");
		RC_Global.navigateTo(driver, "Manage", "Administration", "Alerts Management");
		RC_Global.clickUsingXpath(driver, "//a[text()='Personal Use']", "Personal Use", false, true);
		RC_Global.panelAction(driver, "close", "Alerts Management", false,true);
		RC_Global.panelAction(driver, "expand", "Alerts Management", false,true);
		RC_Global.createNode(driver, "Verify alert creation for 'Admin'");
		for(int i=1;i<=driver.findElements(By.xpath("//button")).size();i++)
		{
			if(driver.findElement(By.xpath("(//button)["+i+"]")).getText().equals("Add Alert"))
			{
				flag++;
				break;
			}
		}
		if(flag==0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Add Alert' button is not visible", "Admin can not add an alert", null);
		}
		RC_Global.clickUsingXpath(driver, "//td[5]", "Alert Name", false, true);
		RC_Global.panelAction(driver, "close", "Alerts Management", false,true);
		RC_Global.panelAction(driver, "expand", "Alert Setup", false,true);
		RC_Global.createNode(driver, "Verify alert modification for 'Admin'");
		if(driver.findElement(By.xpath("//label[text()='Name*']/following-sibling::div/input")).getAttribute("disabled").equals("true"))
		{
			queryObjects.logStatus(driver, Status.PASS, "Name* input is disabled", "", null);
		}
		if(driver.findElement(By.xpath("//label[text()='Description']/following-sibling::div/input")).getAttribute("disabled").equals("true"))
		{
			queryObjects.logStatus(driver, Status.PASS, "Description input is disabled", "", null);
		}
		if(driver.findElement(By.xpath("//label[text()='Category*']/following-sibling::div/select")).getAttribute("disabled").equals("true"))
		{
			queryObjects.logStatus(driver, Status.PASS, "Category dropdown is disabled", "", null);
		}
		
		if(driver.findElement(By.xpath("//label[text()='Customer*']/following-sibling::div/select")).getAttribute("disabled").equals("true"))
		{
			queryObjects.logStatus(driver, Status.PASS, "Customer* dropdown is disabled", "", null);
		}
		if(driver.findElement(By.xpath("//label[text()='Distribution']/following-sibling::div/select")).getAttribute("disabled").equals("true"))
		{
			queryObjects.logStatus(driver, Status.PASS, "Distribution dropdown is disabled", "", null);
		}
		if(driver.findElement(By.xpath("//div[@ng-show='showMonthly']/input")).getAttribute("disabled").equals("true"))
		{
			queryObjects.logStatus(driver, Status.PASS, "Monthly radio button is disabled", "", null);
		}
		if(driver.findElement(By.xpath("//div[@ng-show='showCustom']/input")).getAttribute("disabled").equals("true"))
		{
			queryObjects.logStatus(driver, Status.PASS, "Custom radio button is disabled", "", null);
		}
		if(driver.findElement(By.xpath("//input[@placeholder='Start Date']")).getAttribute("disabled").equals("true"))
		{
			queryObjects.logStatus(driver, Status.PASS, "Start Date input is disabled", "", null);
		}
		if(driver.findElement(By.xpath("//input[@placeholder='End Date']")).getAttribute("disabled").equals("true"))
		{
			queryObjects.logStatus(driver, Status.PASS, "End Date input is disabled", "", null);
		}
		if(driver.findElement(By.xpath("//select[@ng-model='data.TimeZone']")).getAttribute("disabled").equals("true"))
		{
			queryObjects.logStatus(driver, Status.PASS, "Time Zone* input is disabled", "", null);
		}
		RC_Global.panelAction(driver, "close", "Alert Setup", false,true);
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
