package Manage.Administration.AlertsManagement;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_1_02 {
	public static void FuelAlert_ValidateFuelCategoryAndExceptionError(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
		RC_Global.enterCustomerNumber(driver, "LS004792", "", "", true);
		RC_Global.waitElementVisible(driver, 30, "//a[text()='Fuel']", "Fuel Tab", true, false);
		RC_Global.clickUsingXpath(driver, "//a[text()='Fuel']", "Fuel Tab", true, true);
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Enrolled in Fuel']]", "Enrolled in Fuel field", true, true);

		if(driver.findElement(By.xpath("//div[@fuel-attributes='fuelAttributes']//label[contains(@class,'active')]")).getText().equalsIgnoreCase("Fuel Attributes"))
			queryObjects.logStatus(driver, Status.PASS, "Verify 'Fuel Attributed' Tab is selected by default", "'Fuel Attributed' Tab is selected by default",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify 'Fuel Attributed' Tab is selected by default", "'Fuel Attributed' Tab is not selected by default",null);
	
		if(driver.findElement(By.xpath("//div[label[text()='Enrolled in Fuel']]//button[contains(@class,'disabled-active-button')]")).getText().equalsIgnoreCase("No"))
			queryObjects.logStatus(driver, Status.PASS, "Verify Customer not Enrolled in Fuel", "Customer not Enrolled in Fuel",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Customer not Enrolled in Fuel", "Customer Enrolled in Fuel",null);
		
		RC_Global.panelAction(driver, "close", "Customer Administration", true, true);
		
		RC_Global.navigateTo(driver, "Manage", "Administration", "Alerts Management");
		RC_Global.waitUntilPanelVisibility(driver, "Alerts Management", "TV", true, false);
		
		RC_Global.enterCustomerNumber(driver, "LS004792", "", "", true);
		Thread.sleep(2000);
		RC_Global.verifyColumnNames(driver, "Alert Group;Number Of Alerts", true);
		
		Thread.sleep(1000);
		if(driver.findElement(By.xpath("//div[a[text()='Fuel']]")).getAttribute("class").contains("ng-scope ng-hide"))
			queryObjects.logStatus(driver, Status.PASS, "Verify Fuel is not a hyperlink", "Fuel is not a hyperlink",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Fuel is not a hyperlink", "Fuel is a hyperlink",null);
		
		RC_Global.panelAction(driver, "close", "Alerts Management", true, true);
		
		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
		RC_Global.waitUntilPanelVisibility(driver, "Customer Administration", "TV", true, false);
		
		RC_Global.enterCustomerNumber(driver, "LS008737", "", "", true);
		RC_Global.waitElementVisible(driver, 30, "//a[text()='Fuel']", "Fuel Tab", true, false);
		RC_Global.clickUsingXpath(driver, "//a[text()='Fuel']", "Fuel Tab", true, true);
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Enrolled in Fuel']]", "Enrolled in Fuel field", true, true);

		if(driver.findElement(By.xpath("//div[@fuel-attributes='fuelAttributes']//label[contains(@class,'active')]")).getText().equalsIgnoreCase("Fuel Attributes"))
			queryObjects.logStatus(driver, Status.PASS, "Verify 'Fuel Attributed' Tab is selected by default", "'Fuel Attributed' Tab is selected by default",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify 'Fuel Attributed' Tab is selected by default", "'Fuel Attributed' Tab is not selected by default",null);
	
		if(driver.findElement(By.xpath("//div[label[text()='Enrolled in Fuel']]//button[contains(@class,'disabled-active-button')]")).getText().equalsIgnoreCase("Yes"))
			queryObjects.logStatus(driver, Status.PASS, "Verify Customer Enrolled in Fuel", "Customer Enrolled in Fuel",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Customer Enrolled in Fuel", "Customer not Enrolled in Fuel",null);
		
		RC_Global.panelAction(driver, "close", "Customer Administration", true, true);
		
		RC_Global.navigateTo(driver, "Manage", "Administration", "Alerts Management");
		RC_Global.waitUntilPanelVisibility(driver, "Alerts Management", "TV", true, false);
		
		RC_Global.enterCustomerNumber(driver, "LS008737", "", "", true);
		Thread.sleep(2000);
		RC_Global.verifyColumnNames(driver, "Alert Group;Number Of Alerts", true);
		
		if(driver.findElements(By.xpath("//div[contains(@class,'ng-scope ng-hide')]/a[text()='Fuel']")).size()==0)
			queryObjects.logStatus(driver, Status.PASS, "Verify Fuel is a hyperlink", "Fuel is a hyperlink",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Fuel is a hyperlink", "Fuel is not a hyperlink",null);
		
		RC_Global.clickUsingXpath(driver, "//a[normalize-space(text())='Fuel']", "Fuel link", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Alerts Management - Fuel", "TV", true, false);
		
		RC_Global.panelAction(driver, "close", "Alerts Management", true, true);
		RC_Global.panelAction(driver, "expand", "Alerts Management - Fuel", true, false);
		
		RC_Global.clickButton(driver, "Add Alert", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Alert Setup - New Alert", "TV", true, false);
		
		RC_Global.panelAction(driver, "close", "Alerts Management - Fuel", true, true);
		RC_Global.panelAction(driver, "expand", "Alert Setup - New Alert", true, false);
		
		if(driver.findElements(By.xpath("//div[label[text()='Category*']]//select")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify Category is a field present in Alert Setup - New Alert", "Category is a field present in Alert Setup - New Alert",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Category is a field present in Alert Setup - New Alert", "Category is not a field present in Alert Setup - New Alert",null);
		
		if(driver.findElements(By.xpath("//div[label[text()='Name*']]//input")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify Name is a field present in Alert Setup - New Alert", "Name is a field present in Alert Setup - New Alert",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Name is a field present in Alert Setup - New Alert", "Name is not a field present in Alert Setup - New Alert",null);
		
		if(driver.findElements(By.xpath("//div[label[text()='Description']]//input")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify Description is a field present in Alert Setup - New Alert", "Description is a field present in Alert Setup - New Alert",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Description is a field present in Alert Setup - New Alert", "Description is not a field present in Alert Setup - New Alert",null);
		
		if(driver.findElements(By.xpath("//div[label[text()='Customer*']]//input")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify Customer is a field present in Alert Setup - New Alert", "Customer is a field present in Alert Setup - New Alert",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Customer is a field present in Alert Setup - New Alert", "Customer is not a field present in Alert Setup - New Alert",null);
		
		if(driver.findElements(By.xpath("//div[label[text()='Distribution']]//select")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify Distribution is a field present in Alert Setup - New Alert", "Distribution is a field present in Alert Setup - New Alert",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Distribution is a field present in Alert Setup - New Alert", "Distribution is not a field present in Alert Setup - New Alert",null);
		
		RC_Global.clickUsingXpath(driver, "//div/a[text()='Edit Templates']", "Edit Templates link", true, true);
		
		RC_Global.waitElementVisible(driver, 30, "//h3[text()='Modify Alert Template']", "Modify Alert Template", true, false);
		
		if(driver.findElements(By.xpath("//legend[text()='Email']")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify 'Email' is present in Modify Alert Template", "'Email' is present in Modify Alert Template", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify 'Email' is present in Modify Alert Template", "'Email' is not present in Modify Alert Template", null);
		
		if(driver.findElements(By.xpath("//legend[text()='Text Message']")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify 'Text Message' is present in Modify Alert Template", "'Text Message' is present in Modify Alert Template", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify 'Text Message' is present in Modify Alert Template", "'Text Message' is not present in Modify Alert Template", null);
		
		if(driver.findElement(By.xpath("//legend[text()='Email']/following-sibling::div[1]/label[input[@ng-value=\"'default'\"]]")).getText().trim().equalsIgnoreCase("Default Message"))
			queryObjects.logStatus(driver, Status.PASS, "Verify 'Default Message' is present in Modify Alert Template and selected by default", "'Default Message' is present in Modify Alert Template and selected by default", null);
		else if(driver.findElement(By.xpath("//legend[text()='Email']/following-sibling::div[1]/label[input][1]")).getText().trim().equalsIgnoreCase("Default Message"))
			queryObjects.logStatus(driver, Status.FAIL, "Verify 'Default Message' is present in Modify Alert Template and selected by default", "'Default Message' is present in Modify Alert Template but not selected by default", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify 'Default Message' is present in Modify Alert Template and selected by default", "'Default Message' is not present in Modify Alert Template", null);
		
		if(driver.findElement(By.xpath("//legend[text()='Email']/following-sibling::div[1]/label[input][2]")).getText().trim().equalsIgnoreCase("Customized Message"))
			queryObjects.logStatus(driver, Status.PASS, "Verify 'Customized Message' is present in Modify Alert Template and selected by default", "'Customized Message' is present in Modify Alert Template", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify 'Customized Message' is present in Modify Alert Template and selected by default", "'Customized Message' is not present in Modify Alert Template", null);
		
		if(driver.findElement(By.xpath("//legend[text()='Text Message']/following-sibling::div[1]/label[input[@ng-value=\"'default'\"]]")).getText().trim().equalsIgnoreCase("Default Message"))
			queryObjects.logStatus(driver, Status.PASS, "Verify 'Default Message' is present in Modify Alert Template and selected by default", "'Default Message' is present in Modify Alert Template and selected by default", null);
		else if(driver.findElement(By.xpath("//legend[text()='Text Message']/following-sibling::div[1]/label[input][1]")).getText().trim().equalsIgnoreCase("Default Message"))
			queryObjects.logStatus(driver, Status.FAIL, "Verify 'Default Message' is present in Modify Alert Template and selected by default", "'Default Message' is present in Modify Alert Template but not selected by default", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify 'Default Message' is present in Modify Alert Template and selected by default", "'Default Message' is not present in Modify Alert Template", null);
		
		if(driver.findElement(By.xpath("//legend[text()='Text Message']/following-sibling::div[1]/label[input][2]")).getText().trim().equalsIgnoreCase("Customized Message"))
			queryObjects.logStatus(driver, Status.PASS, "Verify 'Customized Message' is present in Modify Alert Template and selected by default", "'Customized Message' is present in Modify Alert Template", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify 'Customized Message' is present in Modify Alert Template and selected by default", "'Customized Message' is not present in Modify Alert Template", null);
		
		RC_Global.buttonStatusValidation(driver, "Done", "Enable", true);
		RC_Global.buttonStatusValidation(driver, "Cancel", "Enable", true);
		
		RC_Global.clickButton(driver, "Done", true, true);
		
		Thread.sleep(2000);
		List<WebElement> categoryList = driver.findElements(By.xpath("//div[label[text()='Category*']]//select/option"));
		String[] catList = {"Fuel Amount Over X% of Limit", "Fuel Type Purchased", "Mismatched Fuel Type Over X Gallons", "Number of Transactions Over X Days", "Off-Hour Purchases", "Transactions Exceeding X Gallons", "Vehicles with Non-Sequential Odometer", "Weekend Purchases", "X Number of Declines Over X Hours"};
		int notAvailIndex = -1;
		for(WebElement cl:categoryList) {
			boolean flag=false;
			for(int iter=0;iter<catList.length;iter++) {
				if(catList[iter].equalsIgnoreCase(cl.getText())) {
					flag=true;
					notAvailIndex=iter;
					queryObjects.logStatus(driver, Status.INFO, "Verify "+catList[iter]+" is an option in the dropdown", catList[iter]+" is an option in the dropdown", null);
					break;
				}
				
			}
			if(!flag&&notAvailIndex!=-1)
				queryObjects.logStatus(driver, Status.FAIL, "Verify "+catList[(notAvailIndex+1)]+" is an option in the dropdown", catList[(notAvailIndex+1)]+" is not an option in the dropdown", null);

		}
		if(driver.findElement(By.xpath("//button[text()='Save']")).getAttribute("disabled").equalsIgnoreCase("true"))
			queryObjects.logStatus(driver, Status.PASS, "Verify 'Save' button is disabled", "'Save' button is disabled", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify 'Save' button is disabled", "'Save' button is not disabled", null);
		
		RC_Global.clickUsingXpath(driver, "//div[label[text()='Category*']]//select", "Select Category option", true, true);
		RC_Global.clickUsingXpath(driver, "//div[label[text()='Category*']]//select/option[2]", "Select Category option", true, true);
		WebElement name = driver.findElement(By.xpath("//div[label[text()='Name*']]//input"));
		WebElement description = driver.findElement(By.xpath("//div[label[text()='Description']]//input"));
		RC_Global.clickUsingXpath(driver, "//div[label[text()='Distribution']]//select", "Select Distribution option", true, true);
		RC_Global.clickUsingXpath(driver, "//div[label[text()='Distribution']]//select/option[2]", "Select Distribution option", true, true);
		RC_Global.enterInput(driver, "Sample Test "+RandomStringUtils.randomNumeric(1), name, true, true);
		RC_Global.enterInput(driver, "Sample Test "+RandomStringUtils.randomNumeric(1), description, true, true);
		
		RC_Global.clickButton(driver, "Save", true, true);
		
		try {
			RC_Global.waitElementVisible(driver, 30, "//h4[text()='At least one Role must be selected as Eligible.']", "Error Message Validation", true, true);
			queryObjects.logStatus(driver, Status.INFO, "Verify 'At least one Role must be selected as Eligible.' message is displayed", "Message is displayed", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify 'At least one Role must be selected as Eligible.' message is displayed", "Message is not displayed", e);	
		}

		try {
			RC_Global.waitElementVisible(driver, 30, "//h4[text()='Threshold is a required field.']", "Error Message Validation", true, true);
			queryObjects.logStatus(driver, Status.INFO, "Verify 'Threshold is a required field.' message is displayed", "Message is displayed", null);	
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify 'Threshold is a required field.' message is displayed", "Message is not displayed", e);	
		}
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
