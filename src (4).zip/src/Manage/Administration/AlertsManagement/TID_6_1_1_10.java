package Manage.Administration.AlertsManagement;

import java.io.File;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_1_10 {

	public void MaintenanceAlert_ValidateAlertExtendedAdd_EditServices(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception {

		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Alerts Management");
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", false);
		RC_Global.waitElementVisible(driver, 5, "//a[text()='Maintenance']", "Alert Group is displayed", true, true);
		
		// Click on Fuel Alert Group
		RC_Global.clickUsingXpath(driver, "//a[text()='Maintenance']", "Maintenance", true, true);		
//		RC_Global.panelAction(driver, "expand", "Alerts Management", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Alerts Management - Maintenance","TV", true,false);
		RC_Global.panelAction(driver, "close", "Alerts Management", false, true);
		
		// Click Add Alert button
		RC_Global.clickButton(driver, "Add Alert", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Alert Setup - New Alert","TV", true,false);
		RC_Global.panelAction(driver, "close", "Alerts Management - Maintenance", false,true);
		RC_Global.panelAction(driver, "expand", "Alert Setup - New Alert", false,true);
		
		// verify the Included Service section
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Included Service", false);
		Thread.sleep(2000);
//		RC_Global.waitUntilPanelVisibility(driver,"//label[contains(text(),'Service')]","TV", true,false);
		
		// Verify the Services Dropdown values
		String services = driver.findElement(By.xpath("//select[@name='services']//parent::div//parent::div//label")).getText();
		String dropdownvalues2 = "LOF;Perform PM Service - Equipment;Tire Rotation";
		Thread.sleep(2000);
		RC_Global.dropdownValuesValidation(driver,dropdownvalues2,"//select[@name='services']",false,true);
		
		// Verify the Threshold field values	
		String threshold = driver.findElement(By.xpath("//label[normalize-space(text())='Service*']//following::label[1]")).getText();
		String milesT = driver.findElement(By.xpath("//label[normalize-space(text())='Thresholds*']//following::label[1]")).getText();
		String days = driver.findElement(By.xpath("//label[normalize-space(text())='Thresholds*']//following::label[2]")).getText();
	    
		queryObjects.logStatus(driver, Status.PASS, "Included Services Header with Following Fields----> Services with dropdown values",  dropdownvalues2 , null);
		queryObjects.logStatus(driver, Status.PASS, "Included Services Header with Following Fields----> Thresholds with "+milesT +" ", days, null);
		
		RC_Global.selectDropdownOption(driver, "Service*", " Tire Rotation ", false,true);	
		WebElement miles = driver.findElement(By.xpath("//input[@name='miles_0']"));
		RC_Global.enterInput(driver, "1000", miles  , false,true);
		
		// Click Add Service
		RC_Global.clickUsingXpath(driver,"//a[text()='Add Service']" , "Add Service", true,true);
//			RC_Global.selectDropdownOption(driver, "Service*", " Perform PM Service - Equipment ", false,true);	
		RC_Global.clickUsingXpath(driver,"(//label[contains(text(),'Service')]/following-sibling::div//select)[2]", "select dropdown", false,false);
		Thread.sleep(2000);
		RC_Global.clickUsingXpath(driver,"(//label[contains(text(),'Service')]/following-sibling::div//select)[2]//option[normalize-space(text())='LOF']" , "Services", true,true);
		
		WebElement miles1 = driver.findElement(By.xpath("//input[@name='miles_1']"));
		RC_Global.enterInput(driver, "2000", miles1  , false,true);
		
		// Verify Remove Hyperlink
		RC_Global.createNode(driver, "Validate Remove hyperlink");
		if(driver.findElements(By.xpath("//a[text()='Remove']")).size()>1)
		{
			queryObjects.logStatus(driver, Status.PASS, "Verified 'Remove hyperlink' for every section of service", "Successfully" , null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Unable to find 'Remove hyperlink' for every section of service", " " , null);	
		}
		
		// Click Add Service
		RC_Global.clickUsingXpath(driver,"//a[text()='Add Service']" , "Add Service", true,true);
		
		// Verify Add Service hyperlink
		RC_Global.createNode(driver, "Validate Add service hyperlink");
		if(driver.findElements(By.xpath("//a[text()='Add Service']")).size()!=1)
		{
			queryObjects.logStatus(driver, Status.PASS, "Verified 'Add Service hyperlink' is not displayed after adding 2 services", "Successfully" , null);
			
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "'Add Service hyperlink' is displayed after adding 2 services", " " , null);
		}
		
		// Click Remove hyperlink, validate add service hyperlink and service sub sections count
		RC_Global.createNode(driver, "Validate Add service hyperlink and service sub section count");
		RC_Global.clickUsingXpath(driver,"(//a[text()='Remove'])[1]" , "Remove Service", true,false);
		
		if(driver.findElement(By.xpath("//a[text()='Add Service']")).isDisplayed())
		{
			queryObjects.logStatus(driver, Status.PASS, "Verified 'Add Service hyperlink' is displayed", "Successfully" , null);
	
		List<WebElement> Servicesection= driver.findElements(By.xpath("//label[contains(text(),'Service')]"));  
        Thread.sleep(2000);
        int servicecnt=Servicesection.size();
        
       
			if(servicecnt==2)
			{
				queryObjects.logStatus(driver, Status.PASS, "Verified two service detail sub section is displayed", "Successfully" , null);
			}
			else
			{
				queryObjects.logStatus(driver, Status.FAIL, "Two service detail sub section is not displayed", " " , null);
			}
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, " 'Add Service hyperlink' is not displayed", " " , null);
		}
		
		// Click Remove hyperlink, validate remove hyperlink and service sub sections count
		RC_Global.createNode(driver, "Validate Remove hyperlink and service sub section count");
		RC_Global.clickUsingXpath(driver,"(//a[text()='Remove'])[1]" , "Remove Service", true,false);
		
		if(driver.findElements(By.xpath("//a[text()='Remove']")).size()!=1)
		{
			queryObjects.logStatus(driver, Status.PASS, "Verified 'Remove hyperlink' is not displayed", "Successfully" , null);
			List<WebElement> Servicesection= driver.findElements(By.xpath("//label[contains(text(),'Service')]"));  
	        Thread.sleep(2000);
	        int servicecnt=Servicesection.size();
	        if(servicecnt==1)
			{
				queryObjects.logStatus(driver, Status.PASS, "Verified one service detail sub section is displayed", "Successfully" , null);
			}
			else
			{
				queryObjects.logStatus(driver, Status.FAIL, "one service detail sub section is not displayed", " " , null);
			}
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "'Remove hyperlink' is displayed", " " , null);
		}
		
		RC_Global.panelAction(driver, "close", "Alert Setup - New Alert", false,true);
		
		RC_Global.logout(driver, false);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}

}
