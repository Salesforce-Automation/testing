package Manage.Administration.AlertsManagement;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_1_06 {
	public static String editHistory = "";
	
	public void FuelAlert_ExternalUser_Add_Edit(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Alerts Management";
		String SearchFilters ="Category*;Name*;Description;Customer*;Distribution";
		
		RC_Global.externalUserLogin(driver, "kentuckytest3", "Yes");
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);	
		RC_Global.waitUntilPanelVisibility(driver,"Alerts Management","TV", true,false);
		RC_Global.waitElementVisible(driver, 60, "//standard-grid//div[1][contains(@ng-style,'Viewport')]", "Alert Management grid is displayed", true,false);
		RC_Global.clickUsingXpath(driver,"//a[text()='Fuel']" , "Fuel", true,true);
		RC_Global.waitUntilPanelVisibility(driver,"Alerts Management - Fuel","TV", true,false);
		RC_Global.panelAction(driver, "close", "Alerts Management", false,true);
		RC_Global.panelAction(driver, "expand", "Alerts Management - Fuel", false,true);
		RC_Global.clickButton(driver, "Add Alert", true,true);
		RC_Global.waitUntilPanelVisibility(driver,"Alert Setup - New Alert","TV", true,false);
		RC_Global.panelAction(driver, "close", "Alerts Management - Fuel", false,true);
		RC_Global.panelAction(driver, "expand", "Alert Setup - New Alert", false,true);
		RC_Global.validateSpecifiedSearchFilters(driver, SearchFilters, false);
		
		//Add Fuel
		RC_Global.selectDropdownOption(driver, "Category*", "Fuel Amount Over X% of Limit", false,true);
		 WebElement element = driver.findElement(By.xpath("//input[@name='alertName']"));
	     String alertname = RandomStringUtils.randomAlphanumeric(7);
			RC_Global.enterInput(driver, "Alert_Sample_"+alertname, element  , false,true);
			RC_Global.selectDropdownOption(driver, "Distribution", "Email", false,true);
			WebElement threshold = driver.findElement(By.xpath("//div//label[text()='Threshold']//following::div[4]//input[contains(@ng-model,'customerAlertItem')]"));
			RC_Global.enterInput(driver,"60",threshold,false,true);
			RC_Global.clickUsingXpath(driver,"(//input[@type='checkbox' and contains(@class,'ng-empty')])[1]" , "Distribution Group Selection", true,true);
			RC_Global.clickButton(driver, "Save", true,true);
			Thread.sleep(8000);
			RC_Global.verifyDisplayedMessage(driver, "Save Successful", false);
			RC_Global.downloadAndVerifyFileDownloaded(driver,"Export","Export To Excel Functionality", true);
			RC_Global.panelAction(driver, "close", "Alert Setup - New Alert", false,true);
			
			RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
			RC_Global.waitUntilPanelVisibility(driver,"Alerts Management","TV", true,false);
			Thread.sleep(5000);
			RC_Global.waitElementVisible(driver, 30, "//standard-grid//div[1][contains(@ng-style,'Viewport')]", "Alert Management grid is displayed", true,true);
			RC_Global.clickUsingXpath(driver,"//a[text()='Fuel']" , "Fuel", true,true);
			RC_Global.waitUntilPanelVisibility(driver,"Alerts Management - Fuel","TV", true,false);
			RC_Global.panelAction(driver, "close", "Alerts Management", false,true);
			RC_Global.panelAction(driver, "expand", "Alerts Management - Fuel", false,true);
			
			//Edit Alert
			List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("//table//tbody//tr"));  
			int rowcnt=Getgridrowcnt.size();
			boolean flag = false;
			for(int i=1; i<=rowcnt;i++) {
				WebElement name = driver.findElement(By.xpath("//tr["+i+"]//td[5]"));
				String AddAlertName = name.getText();
				if(!AddAlertName.isEmpty()) {
					WebElement Name = driver.findElement(By.xpath("//tbody//tr["+i+"]//td[5]"));
					if(( AddAlertName.contains(alertname))) {
					Thread.sleep(2000);
					flag = true;
					Name.click();
					break;}
				}
			}
				if(flag){
					queryObjects.logStatus(driver, Status.PASS, "Personal Use Edit Alert clicked", "Successfully", null);}
				else {
					queryObjects.logStatus(driver, Status.FAIL, "Personal Use Edit Alert clicking", "Failed", null);}
		
			

			if(driver.findElements(By.xpath("(//h5/span[1])[2]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, driver.findElement(By.xpath("(//h5/span[1])[2]")).getText()+" panel is", "Visible", null);
			}
			queryObjects.logStatus(driver, Status.PASS, "Name , Description , Distribution and Threshold Fields are","Editable", null);
			Thread.sleep(2000);
			String customer = driver.findElement(By.xpath("(//input[contains(@ng-model,'customerName') and @disabled='disabled'])[2]")).getCssValue("background-color");
	           queryObjects.logStatus(driver, Status.PASS, "Customer # Box is Locked, Greyed out and Cannot be Changed or Deleted ---->", customer , null);
	           WebElement elementedit = driver.findElement(By.xpath("//input[@name='alertName']"));
	           String alertnameedit = RandomStringUtils.randomNumeric(3);
	           Thread.sleep(6000);
	      		RC_Global.enterInput(driver, "FuelAlert_Sample_"+alertnameedit, elementedit  , false,true);
	      		RC_Global.clickButton(driver, "Save", true,true);
				Thread.sleep(8000);
				RC_Global.verifyDisplayedMessage(driver, "Save Successful", false);
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//h5/span[1])[2]")));
			    RC_Global.panelAction(driver, "close", driver.findElement(By.xpath("(//h5/span[1])[2]")).getText(), false, false);
				
				RC_Global.panelAction(driver, "expand", "Alerts Management - Fuel", false,true);
				String EditFuelcategory = driver.findElement(By.xpath("//table/tbody/tr[1]//td[4]")).getText();
				String EditFuelName = driver.findElement(By.xpath("(//table/tbody/tr[1]//td[5])[1]")).getText();
				String EditFuelThreshold = driver.findElement(By.xpath("(//table/tbody/tr[1]//td[7])[1]")).getText();
				
				queryObjects.logStatus(driver, Status.PASS, "Edited Fuel Alerts Category---->", EditFuelcategory, null);
				queryObjects.logStatus(driver, Status.PASS, "Edited Fuel Alerts Name---->", EditFuelName, null);
				queryObjects.logStatus(driver, Status.PASS, "Edited Fuel Alerts # of Employees---->",EditFuelThreshold, null);
				
				List<WebElement> Getgridrowcnt1= driver.findElements(By.xpath("//table//tbody//tr"));  
				int rowcnt1=Getgridrowcnt1.size();
				for(int i=1; i<=rowcnt1;i++) {
					WebElement name = driver.findElement(By.xpath("//tr["+i+"]//td[5]"));
				String	EditName = name.getText();
					if(!EditName.isEmpty()) {
						WebElement history = driver.findElement(By.xpath("//tbody//tr["+i+"]//td[10]"));
						editHistory = history.getText();
						if(( EditName.contains(alertnameedit))) {
						Thread.sleep(2000);
						history.click();
						break;}
					}
				}
				
				//Fuel - History
				
				RC_Global.waitUntilPanelVisibility(driver,"Alert History","TV", true,false);
				RC_Global.panelAction(driver, "close", "Alerts Management - Fuel", false,true);
				RC_Global.panelAction(driver, "expand", "Alert History", false,true);
				RC_Global.waitElementVisible(driver, 60, "(//tbody[1]/tr[1]/td[1])[1]", "Grid Result", false, false);
				
				String customerName = driver.findElement(By.xpath("//strong[text()='Customer Name: ']//parent::div")).getText();
				String AlertName = driver.findElement(By.xpath("//strong[text()='Alert Name: ']//parent::div")).getText();
				
				queryObjects.logStatus(driver, Status.PASS, "Alert History Alert Name is---->", AlertName, null);
				queryObjects.logStatus(driver, Status.PASS, "Alert History Customer Name is---->", customerName, null);
		
				String currentDate = RC_Manage.AddDateStr(0, "MMM d, yyyy hh:mm:ss", "", null, "CST");//updated
				String modifiedBy=driver.findElement(By.xpath("//table/tbody[1]/tr[1]/td[5]")).getText();
				String recordDateTime=driver.findElement(By.xpath("(//table/tbody[1]/tr[1]/td[2])[1]")).getText().trim();
				//String loggedUser = driver.findElement(By.xpath("//span[@id='Span1']")).getText();
				if(modifiedBy.toUpperCase().contains(RC_Global.userLogged) || recordDateTime.equals(currentDate.trim()))
				{
					queryObjects.logStatus(driver, Status.PASS, "Username and Created date verification in Alert History", "Successful", null);
				}
				else {
					queryObjects.logStatus(driver, Status.FAIL, "Username and created date verification","failed",null );
				}
				
			//History validation
			RC_Global.clickUsingXpath(driver,"(//table/tbody[1]/tr[1]/td[1])[1]" , "Changes", true,true);
				
			String oldHistoryValue = driver.findElement(By.xpath("//table/tbody[1]/tr[2]/td[2]/table/tbody/tr/td[2]")).getText().trim();
			String newHistoryValue = driver.findElement(By.xpath("//table/tbody[1]/tr[2]/td[2]/table/tbody/tr/td[3]")).getText().trim();
			queryObjects.logStatus(driver, Status.PASS, "Old Fields Details is displayed in Changed Item section", oldHistoryValue, null);
			queryObjects.logStatus(driver, Status.PASS, "New Fields Details is displayed in Changed Item section", newHistoryValue, null);
				
			Thread.sleep(2000);
	        
			//RC_Global.panelAction(driver, "close", "Alerts Management", false,true);
			//RC_Global.panelAction(driver, "close", "Alert History", false,true);
			RC_Global.logout(driver, false);
			queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
