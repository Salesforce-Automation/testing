package Manage.Administration.AlertsManagement;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_1_18 {
	public static String editHistory = "";
	public void PersonalUseAlert_AddAndEditAlertVehiclesToOptIn_Out(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Alerts Management";
		String SearchFilters ="Category*;Name*;Description;Customer*;Distribution";
		String PopUpSearchFilters ="Customer #;First Name;Last Name;Username;Email;Employee Id;Status;Employee Assignment";
		String email = RandomStringUtils.randomAlphabetic(6); 
		String com = "@fleet.com";
		String Lastname = RandomStringUtils.randomAlphabetic(5);
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Employee Management");
		RC_Global.clickButton(driver, "Create", false,true);
		RC_Global.panelAction(driver, "close", "Employee Management", false,true);
		RC_Global.panelAction(driver, "expand", "Create Employee", false,true);
		RC_Manage.editEmployeeForm(driver, "LS008742", "Alexander", Lastname, "4500 Courthouse Blvd Ste 150", "Stow", "OH", "44224-6837", "Email", "(576) 453-5737", email+com);
		RC_Global.clickUsingXpath(driver, "//span[@title='10447 - 11001']", "Employee Assignment", false,true);
		RC_Global.clickUsingXpath(driver, "//input[contains(@ng-model,'IsEnrolledInPersonalUse')]", "Enrolled in Personal Use Checkbox", false,true);
		RC_Global.clickUsingXpath(driver, "(//button[normalize-space(text())='Save'])[1]", "Save", false,true);
		if(driver.findElements(By.xpath("//h3[text()='Potential Duplicate Employee Detected']")).size()>0){
            RC_Global.clickUsingXpath(driver, "//input[@type='radio' and @value='override']", "Modify Selected Employee with Entered Information", false,true);
            RC_Global.clickButton(driver, "OK", false,true);
        }
		Thread.sleep(3000);
		RC_Global.panelAction(driver, "close", "Create Employee", false,true);
		
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", false);
		RC_Global.waitUntilPanelVisibility(driver,"Alerts Management","TV", true,false);
		RC_Global.waitElementVisible(driver, 60, "//standard-grid//div[1][contains(@ng-style,'Viewport')]", "Alert Management grid is displayed", true,false);
		RC_Global.clickUsingXpath(driver,"//a[text()='Personal Use']" , "Personal Use", true,true);
		RC_Global.waitUntilPanelVisibility(driver,"Alerts Management - Personal Use","TV", true,false);
		RC_Global.panelAction(driver, "close", "Alerts Management", false,true);
		RC_Global.panelAction(driver, "expand", "Alerts Management - Personal Use", false,true);
		RC_Global.clickButton(driver, "Add Alert", true,true);
		RC_Global.waitUntilPanelVisibility(driver,"Alert Setup - New Alert","TV", true,false);
		RC_Global.panelAction(driver, "close", "Alerts Management - Personal Use", false,true);
		RC_Global.panelAction(driver, "expand", "Alert Setup - New Alert", false,true);
		RC_Global.validateSpecifiedSearchFilters(driver, SearchFilters, false);
		
		RC_Global.selectDropdownOption(driver, "Category*", "Missing Submissions", false,true);
		
		String Field1 = driver.findElement(By.xpath("(//div[1][contains(@schedule-data,'AlertFrequency')]//div//label)[1]")).getText();
		String Field2 = driver.findElement(By.xpath("//input[@name='frequencyRadio' and @value='3']")).getText();
		String Field3 = driver.findElement(By.xpath("//input[@name='frequencyRadio' and @value='4']")).getText();
		
		queryObjects.logStatus(driver, Status.PASS, "Missing Submissions category alert pop-up Fields are---->", Field1 +  Field2  +  Field3, null);

		RC_Global.clickUsingXpath(driver, "//input[@name='frequencyRadio' and @value='3']", "Monthly", false, true);
		
		String MonthlyField1 = driver.findElement(By.xpath("(//div[1][contains(@schedule-data,'AlertFrequency')]//div//label)[3]")).getText();
		String MonthlyField2 = driver.findElement(By.xpath("//input[@type='checkbox' and contains(@ng-checked,'data.SelectedDays')]")).getText();//LI
		String MonthlyField3 = driver.findElement(By.xpath("//input[@type='checkbox' and @value='lastDayOfMonth.value']")).getText();
		String MonthlyField4 = driver.findElement(By.xpath("//input[@type='checkbox' and @value='allDaysSelected']")).getText();
		queryObjects.logStatus(driver, Status.PASS, "Monthly Frequency Fields are---->", MonthlyField1 +  MonthlyField2  + MonthlyField3  + MonthlyField4, null);
		
		RC_Global.clickUsingXpath(driver, "//input[@name='frequencyRadio' and @value='4']", "Custom", false, true);
		
		String CustomField1 = driver.findElement(By.xpath("//fieldset[3]/div[2]//div[4]/div/label")).getText();
		String CustomField2 = driver.findElement(By.xpath("//input[@type='checkbox' and @ng-model='month.checked']")).getText();//LI
		String CustomField3 = driver.findElement(By.xpath("//input[@type='checkbox' and @value='allMonthsSelected']")).getText();
		queryObjects.logStatus(driver, Status.PASS, "Monthly Frequency Fields are---->", CustomField1 +  CustomField2  + CustomField3, null);
		
		String dropdownvalues1 = "Eastern Standard Time (EST);Central Standard Time (CST);Mountain Standard Time (MST);Pacific Standard Time (PST);Alaska Standard Time (AKST);Hawaii-Aleutian Standard Time (HAST)";
		RC_Global.dropdownValuesValidation(driver,dropdownvalues1,"//select[@ng-model='data.TimeZone']",false,true);//Time Zone
		
		//Add Personal Use
		 WebElement element = driver.findElement(By.xpath("//input[@name='alertName']"));
	     String alertname = RandomStringUtils.randomAlphabetic(4);
			RC_Global.enterInput(driver, "Personal Use Alert_Sample_"+alertname, element  , false,true);
			RC_Global.selectDropdownOption(driver, "Distribution", "Email", false,true);
			RC_Global.clickUsingXpath(driver, "//input[@name='frequencyRadio' and @value='3']", "Monthly", false, true);
			RC_Global.clickUsingXpath(driver, "(//input[@type='checkbox' and contains(@ng-checked,'data.SelectedDays')])[1]", "select desired date of month", false, true);
			//Time and time Zone
			
			WebElement Hours = driver.findElement(By.xpath("//input[@placeholder='HH']"));
	        RC_Global.enterInput(driver,"02" , Hours  , false,true);
	        WebElement Minutes = driver.findElement(By.xpath("//input[@placeholder='MM']"));
	        RC_Global.enterInput(driver,"30" , Minutes  , false,true);
	        RC_Global.clickUsingXpath(driver, "//button[@ng-click='toggleMeridian()']", "Time Toggle", true, true);
	        RC_Global.selectDropdownOption(driver, "Time Zone:*", "Central Standard Time (CST)", false,true);
			RC_Global.clickUsingXpath(driver, "//input[@type='checkbox' and @ng-model='data.IsEligible']", "Distribution Group", false, true);
			RC_Global.clickUsingXpath(driver, "//td[text()='Manage ']", "Manage", true, true);
			Thread.sleep(2000);
			RC_Global.validateHeaderName(driver, "Select Employee to Receive Alerts", false);
           String color = driver.findElement(By.xpath("//input[contains(@ng-model,'customerNumber')]")).getCssValue("background-color");
           queryObjects.logStatus(driver, Status.PASS, "Customer # Box is Locked, Greyed out and Cannot be Changed or Deleted ---->", color , null);
           RC_Global.validateSpecifiedSearchFilters(driver, PopUpSearchFilters, false);
           String dropdownvalues3 = "Opted Out;Opted In";
   		RC_Global.dropdownValuesValidation(driver,dropdownvalues3,"//Select[contains(@ng-model,'status')]",false,true);//status
   		WebElement frstName = driver.findElement(By.xpath("//input[@placeholder='Filter First Name']"));
        RC_Global.enterInput(driver,"Alexander" , frstName  , false,true);
        WebElement lastName = driver.findElement(By.xpath("//input[@placeholder='Filter Last Name']"));
        RC_Global.enterInput(driver,Lastname , lastName  , false,true);
        String userName = driver.findElement(By.xpath("(//tbody/tr/td[2])[1]")).getText();
        queryObjects.logStatus(driver, Status.PASS, "Displays the Created Employee Name in the Grid ---->", userName , null);
   		
        String statusvalue = driver.findElement(By.xpath("(//tbody/tr/td[1])[1]")).getText();
        queryObjects.logStatus(driver, Status.PASS, "The Available Value For the Status Column is ---->", statusvalue , null);
        RC_Global.clickUsingXpath(driver, "(//tbody/tr/td[1])[1]", "Status", false, true);
        String statusvalue1 = driver.findElement(By.xpath("(//tbody/tr/td[1])[1]")).getText();
        queryObjects.logStatus(driver, Status.PASS, "The Available Value For the Status Column after Toggle is ---->", statusvalue1 , null);
        RC_Global.clickUsingXpath(driver, "(//tbody/tr/td[1])[1]", "Status", false, true);
        RC_Global.clickButton(driver, "Done", true,true);
        Thread.sleep(2000);
        RC_Global.clickButton(driver, "Save", true,true);
		Thread.sleep(8000);
		RC_Global.verifyDisplayedMessage(driver, "Save Successful", false);
		RC_Global.panelAction(driver, "close", "Alert Setup - New Alert", false,true);
		
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", false);
		RC_Global.waitUntilPanelVisibility(driver,"Alerts Management","TV", true,false);
		Thread.sleep(5000);
		RC_Global.waitElementVisible(driver, 30, "//standard-grid//div[1][contains(@ng-style,'Viewport')]", "Alert Management grid is displayed", true,true);
		RC_Global.clickUsingXpath(driver,"//a[text()='Personal Use']" , "Personal Use", true,true);
		RC_Global.waitUntilPanelVisibility(driver,"Alerts Management - Personal Use","TV", true,false);
		RC_Global.panelAction(driver, "close", "Alerts Management", false,true);
		RC_Global.panelAction(driver, "expand", "Alerts Management - Personal Use", false,true);
		
		RC_Global.waitElementVisible(driver, 60, "//table/tbody/tr[1]", "Alerts Management - Personal Use grid row", true,true);
		
		String PersonalUsecategory = driver.findElement(By.xpath("//table/tbody/tr[1]//td[4]")).getText();
		String PersonalUseName = driver.findElement(By.xpath("(//table/tbody/tr[1]//td[5])[1]")).getText();
		String PersonalUseEmployees = driver.findElement(By.xpath("(//table/tbody/tr[1]//td[9])[1]")).getText();
		
		queryObjects.logStatus(driver, Status.PASS, "Newly Added Personal Use Alerts Category---->", PersonalUsecategory, null);
		queryObjects.logStatus(driver, Status.PASS, "Newly Added Personal Use Alerts Name---->", PersonalUseName, null);
		queryObjects.logStatus(driver, Status.PASS, "Newly Added Personal Use Alerts # of Employees---->", PersonalUseEmployees, null);
		
		try {
			RC_Global.waitElementVisible(driver, 30, "//tbody/tr[1]/td[text()='"+PersonalUseName+"']", "Newly added alert", true, true);
			queryObjects.logStatus(driver, Status.PASS, "Verify newly added alert is present in the Grid", "Newly added alert is present in the Grid", null);
			//RC_Global.clickUsingXpath(driver, "//tbody/tr[1]/td[text()='"+PersonalUseName+"']", "Newly Added alert", true, true);
			
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify newly added is present in the Grid", "Newly added is not present in the Grid", null);
		}
		List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("//table//tbody//tr"));  
		int rowcnt=Getgridrowcnt.size();
		boolean flag = false;
		for(int i=1; i<=rowcnt;i++) {
			WebElement name = driver.findElement(By.xpath("//tr["+i+"]//td[5]"));
			String AddAlertName = name.getText();
			if(!AddAlertName.isEmpty()) {
				WebElement Name = driver.findElement(By.xpath("//tbody//tr["+i+"]//td[5]"));
				if(( AddAlertName.contains(alertname))) {
				Thread.sleep(2000);
				flag = true;
				Name.click();
				break;}
			}
		}
		if(flag){
			queryObjects.logStatus(driver, Status.PASS, "Personal Use Edit Alert clicked", "Successfully", null);}
		else {
			queryObjects.logStatus(driver, Status.FAIL, "Personal Use Edit Alert clicking", "Failed", null);}

		RC_Global.waitUntilPanelVisibility(driver,"Alert Setup - Missing Submissions","TV", true,false);
		queryObjects.logStatus(driver, Status.PASS, "Category, Name , Description , Distribution, Frequency, Start - End Date, Send Time and Time Zone fields are","Editable", null);
		Thread.sleep(2000);
		String  category = driver.findElement(By.xpath("//select[contains(@ng-model,'selectedAlert') and @disabled='disabled']")).getCssValue("background-color");
           queryObjects.logStatus(driver, Status.PASS, "Category Box is Locked, Greyed out and Cannot be Changed or Deleted ---->", category , null);
           String customer = driver.findElement(By.xpath("(//input[contains(@ng-model,'customerName') and @disabled='disabled'])[2]")).getCssValue("background-color");
           queryObjects.logStatus(driver, Status.PASS, "Customer # Box is Locked, Greyed out and Cannot be Changed or Deleted ---->", customer , null);
           WebElement elementedit = driver.findElement(By.xpath("//input[@name='alertName']"));
           String alertnameedit = RandomStringUtils.randomNumeric(4);
      		RC_Global.enterInput(driver, "PersonalUseAlert_Sample_"+alertnameedit, elementedit  , false,true);
      		RC_Global.clickButton(driver, "Save", true,true);
			Thread.sleep(8000);
			RC_Global.panelAction(driver, "close", "Alert Setup - Missing Submissions", false,true);
			
			RC_Global.panelAction(driver, "expand", "Alerts Management - Personal Use", false,true);
			String EditPersonalUsecategory = driver.findElement(By.xpath("//table/tbody/tr[1]//td[4]")).getText();
			String EditPersonalUseName = driver.findElement(By.xpath("(//table/tbody/tr[1]//td[5])[1]")).getText();
			String EditPersonalUseEmployees = driver.findElement(By.xpath("(//table/tbody/tr[1]//td[9])[1]")).getText();
			
			queryObjects.logStatus(driver, Status.PASS, "Edited Personal Use Alerts Category---->", EditPersonalUsecategory, null);
			queryObjects.logStatus(driver, Status.PASS, "Edited Personal Use Alerts Name---->", EditPersonalUseName, null);
			queryObjects.logStatus(driver, Status.PASS, "Edited Personal Use Alerts # of Employees---->",EditPersonalUseEmployees, null);
			
			try {
				RC_Global.waitElementVisible(driver, 30, "//tbody/tr[1]/td[text()='"+EditPersonalUseName+"']/following-sibling::td[text()='History']", "Newly editted alert", true, true);
				queryObjects.logStatus(driver, Status.PASS, "Verify newly added alert is present in the Grid", "Newly editted alert is present in the Grid", null);
				//RC_Global.clickUsingXpath(driver, "//tbody/tr[1]/td[text()='"+EditPersonalUseName+"']]/td[text()='History']", "Newly editted alert", true, true);
				
			}
			catch(Exception e) {
				queryObjects.logStatus(driver, Status.FAIL, "Verify newly editted is present in the Grid", "Newly editted is not present in the Grid", null);
			}
			List<WebElement> Getgridrowcnt1= driver.findElements(By.xpath("//table//tbody//tr"));  
			int rowcnt1=Getgridrowcnt1.size();
			boolean flagH = false;
			for(int i=1; i<=rowcnt1;i++) {
				WebElement name = driver.findElement(By.xpath("//tr["+i+"]//td[5]"));
			String	EditName = name.getText();
				if(!EditName.isEmpty()) {
					WebElement history = driver.findElement(By.xpath("//tbody//tr["+i+"]//td[10]"));
					editHistory = history.getText();
					if(( EditName.contains(alertnameedit))) {
					Thread.sleep(2000);
					flagH = true;
					history.click();
					break;}
				}
			}
			if(flagH){
				queryObjects.logStatus(driver, Status.PASS, "Personal Use Alert - History clicked", "Successfully", null);}
			else {
				queryObjects.logStatus(driver, Status.FAIL, "Personal Use Alert - History clicking", "Failed", null);}
	
			//PersonalUse - History
			
			RC_Global.waitUntilPanelVisibility(driver,"Alert History","TV", true,false);
			RC_Global.panelAction(driver, "close", "Alerts Management - Personal Use", false,true);
			RC_Global.panelAction(driver, "expand", "Alert History", false,true);
			RC_Global.waitElementVisible(driver, 60, "(//tbody[1]/tr[1]/td[1])[1]", "Grid Result", false, false);
			
			String customerName = driver.findElement(By.xpath("//strong[text()='Customer Name: ']//parent::div")).getText();
			String AlertName = driver.findElement(By.xpath("//strong[text()='Alert Name: ']//parent::div")).getText();
			
			queryObjects.logStatus(driver, Status.PASS, "Alert History Alert Name is---->", AlertName, null);
			queryObjects.logStatus(driver, Status.PASS, "Alert History Customer Name is---->", customerName, null);
	
			String currentDate = RC_Manage.AddDateStr(0, "MMM d, yyyy hh:mm:ss", "", null, "CST");//updated
			String modifiedBy=driver.findElement(By.xpath("//table/tbody[1]/tr[1]/td[5]")).getText();
			String recordDateTime=driver.findElement(By.xpath("(//table/tbody[1]/tr[1]/td[2])[1]")).getText().trim();
			//String loggedUser = driver.findElement(By.xpath("//span[@id='Span1']")).getText();
			if(modifiedBy.toUpperCase().contains(RC_Global.userLogged) || recordDateTime.equals(currentDate.trim()))
			{
				queryObjects.logStatus(driver, Status.PASS, "Username and Created date verification in Alert History", "Successful", null);
			}
			else {
				queryObjects.logStatus(driver, Status.FAIL, "Username and created date verification","failed",null );
			}
			
			//History validation
			int i =0;
			String historyrow1 = driver.findElement(By.xpath("(//table/tbody[1]/tr[1]/td[1])[1]")).getText();
			String historyrow2 = driver.findElement(By.xpath("//table/tbody[2]/tr[1]/td[1]")).getText();
			if(historyrow1.contains("Alert Name")) {
				RC_Global.clickUsingXpath(driver,"(//table/tbody[1]/tr[1]/td[1])[1]" , "Changes", true,true);
				i = 1;
			} else if(historyrow2.contains("Alert Name")) {
				RC_Global.clickUsingXpath(driver,"//table/tbody[2]/tr[1]/td[1]" , "Changes", true,true);
				i = 2;
			}
		String oldHistoryValue = driver.findElement(By.xpath("(//td[text()='Alert Name']//following-sibling::td[contains(text(),'Personal Use Alert_Sample')])["+i+"]")).getText().trim();
		String newHistory = driver.findElement(By.xpath("//td[text()='Alert Name']//following-sibling::td[contains(text(),'Personal Use Alert_Sample')]//following-sibling::td[contains(text(),'PersonalUseAlert_Sample')]")).getText().trim();
		String newHistoryValue=newHistory.replaceAll(" ", "");
		
		
		
		if(oldHistoryValue.equalsIgnoreCase("Personal Use Alert_Sample_"+alertname))
		{
			queryObjects.logStatus(driver, Status.PASS, "Old Fields Details is displayed in Changed Item section", oldHistoryValue, null);
		}
		else {
			queryObjects.logStatus(driver, Status.FAIL, "Old Fields Details is not displayed in Changed Item section","failed. expected- Personal Use Alert_Sample_"+alertname+" actual- "+oldHistoryValue,null );
		}
		if(newHistoryValue.equalsIgnoreCase("PersonalUseAlert_Sample_"+alertnameedit))
		{
			queryObjects.logStatus(driver, Status.PASS, "New Fields Details is displayed in Changed Item section", newHistoryValue, null);
		}
		else {
			queryObjects.logStatus(driver, Status.FAIL, "New Fields Details is not displayed in Changed Item section","Failed. expected- PersonalUseAlert_Sample_"+alertnameedit+" actual- "+newHistoryValue,null );
		}
		Thread.sleep(1000);
        
		RC_Global.panelAction(driver, "close", "Alert History", false,true);
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
