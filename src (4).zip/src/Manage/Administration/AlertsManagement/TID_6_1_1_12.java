package Manage.Administration.AlertsManagement;

import java.io.File;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_1_12 {
	public void MaintenanceAlert_CloneAndDeleteAlert(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver; String DistributionDropDown = "Email;Text Message;Both";
		String CustomerNumber = "LS008737"; String AlertName = "";
		RC_Manage.deleteFile_Downloads(driver, "Export");
		String ColumnNmes ="Eligible;Role;Count;Add;Manage";String HisColumnNmes = "Action;Modified Date;Alert Name;Alert Description;Threshold;# Of Fleet Managers;# Of Pool Contacts;# Of Vehicles;Modified By";
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,"Manage","Administration","Alerts Management");
		RC_Global.enterCustomerNumber(driver, CustomerNumber, "", "", true);
		RC_Global.waitElementVisible(driver, 30, "//a[text()='Maintenance']", "Maintenance Hyperlink", true, false);
		RC_Global.clickUsingXpath(driver, "//a[text()='Maintenance']", "Maintenance Hyperlink", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Alerts Management - Maintenance", "TV", true, true);
		RC_Global.panelAction(driver, "close", "Alerts Management", true, false);
		RC_Global.panelAction(driver, "expand", "Alerts Management - Maintenance", true, false);
		RC_Global.waitElementVisible(driver, 30, "(//a[text()='Clone'])[1]", "", false, false);
		RC_Global.clickUsingXpath(driver, "(//a[text()='Clone'])[1]", "Clone Action Button", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Alert Setup - Maintenance Reminder", "TV", true, true);
		RC_Global.panelAction(driver, "expand", "Alert Setup - Maintenance Reminder", true, false);
		
		RC_Global.createNode(driver, "Verify Clone Alert screen layout option");
		RC_Global.verifyScreenComponents(driver, "lable", "Name*", false);
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Clone Alert", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Description", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Customer* ", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Distribution", false);
		
		RC_Global.dropdownValuesValidation(driver, DistributionDropDown, "//select[@id='distributionOptions']", true, true);
		List<WebElement> Eligible = driver.findElements(By.xpath("(//div/input[@type='checkbox'])[1]"));
		driver.findElement(By.xpath("(//div/input[@type='checkbox'])[1]")).click();
		if(Eligible.size()>0)
			BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Eligible Column", "Eligible Column is populated with a checkbox for each role line entry", null);
		else {
            BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Eligible Column", "Eligible Column is not populated with a checkbox for each role line entry", null);
            RC_Global.endTestRun(driver);
		}
		List<WebElement> ManageHyp = driver.findElements(By.xpath("(//a[text()='Manage'])[1]"));
		if(ManageHyp.size()>0)
			BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Manage Hyperlink", "Recipient column is populated with a hyperlinked value for each role line entry", null);
		else {
            BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Manage Hyperlink", "Recipient column is not populated with a hyperlinked value for each role line entry", null);
            RC_Global.endTestRun(driver);
		}
		RC_Global.clickUsingXpath(driver, "(//a[text()='Manage'])[1]", "Manage Hyperlink", true, true);
		
		RC_Global.waitElementVisible(driver, 60, "//h3[text()='Select Fleet Manager to Receive Alerts']", "The Select Fleet Manager to Receive Alerts shadowbox", true, true);
		RC_Global.waitElementVisible(driver, 60, "(//a[text()='Opted In'])[1]", "", false, false);
		RC_Global.clickUsingXpath(driver, "(//a[text()='Opted In'])[1]", "", true, false);
		
		//revert changes
		RC_Global.clickUsingXpath(driver, "(//a[text()='Opted Out'])[1]", "", true, false);
		
		Thread.sleep(1000);
		WebElement DoneButton= driver.findElement(By.xpath("//button[text()='Done']"));
		executor.executeScript("arguments[0].scrollIntoView(true);",DoneButton);
		Thread.sleep(2000);
		RC_Global.clickButton(driver, "Done", true, true);
		
		RC_Global.clickButton(driver, "Save", true, true);
		RC_Global.verifyDisplayedMessage(driver, "The Alert can not have a name that has already been used on another Alert.", true);

		try {
			RC_Global.waitElementVisible(driver, 120, "//h4[text()='The Alert can not have a name that has already been used on another Alert.']", "Verify error Message", true, true);
			queryObjects.logStatus(driver, Status.PASS, "Verify error Message", "Error message displayed", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify error Message", "Error message not displayed", null);
		}
		
		WebElement Alertname = driver.findElement(By.xpath("//input[@name='alertName']"));
		AlertName = RandomStringUtils.randomAlphabetic(5);
		Alertname.clear();
		RC_Global.enterInput(driver, AlertName, Alertname, true, true);
		RC_Global.buttonStatusValidation(driver, "Done", "Enable", true);
		RC_Global.buttonStatusValidation(driver, "Save", "Enable", true);

		RC_Global.clickButton(driver, "Save", true, true);
		try {
			RC_Global.waitElementVisible(driver, 120, "//h4[text()='Save Successful']", "Save Success Message", true, true);
			queryObjects.logStatus(driver, Status.PASS, "Verify Save was Successful", "Save was Successful", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify Save was Successful", "Save was not Successful", null);
		}
		RC_Global.waitElementNotVisible(driver, 60, "//h4[normalize-space(text())='Save Successful']", "Save Message Invisible", false, false);
		WebElement element = null;
		if(driver.findElements(By.xpath("(//button[contains(@ng-click,'exportToExcel()')])[2]")).size()==1)
             element = driver.findElement(By.xpath("(//button[contains(@ng-click,'exportToExcel()')])[2]"));
		executor.executeScript("arguments[0].click();", element);

		Thread.sleep(5000);
	        try {
	        String home = System.getProperty("user.home");
	             
	        boolean flag = false;
	        File listofFiles= new File(home+"/Downloads/" );
			// Check for the files available
	        for (File file :listofFiles.listFiles() ) {
	            String filename= file.getName();
			 if(filename.contains("Export")) {
				flag = true;
				file.delete();
					break;
					}	
				}
				if(flag){
					queryObjects.logStatus(driver, Status.PASS, "Clone Alert Page Export Excel icon Validation", "Successfully", null);}
				else {
					queryObjects.logStatus(driver, Status.FAIL, "Clone Alert Page Export Excel icon Validation", "Failed", null);}
		}
		catch (Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Download and verify failed", e.getLocalizedMessage(), e);
		}
		Thread.sleep(4000);
		RC_Global.panelAction(driver, "close", "Alert Setup - Maintenance Reminder", true, false);
		RC_Global.panelAction(driver, "expand", "Alerts Management - Maintenance", true, false);
		Thread.sleep(5000);
		RC_Global.waitElementVisible(driver, 30, "//a[text()='"+AlertName+"']", "", true, false);
		RC_Global.createNode(driver, "History Validtaion");
		Thread.sleep(2000);
		RC_Global.clickUsingXpath(driver, "//a[text()='"+AlertName+"']/following::a[text()='History']", "", true, false);
		RC_Global.waitUntilPanelVisibility(driver, "Alert History", "TV", true, true);
		RC_Global.panelAction(driver, "expand", "Alert History", true, false);
        String HisAlertName = driver.findElement(By.xpath("//a[text()='"+AlertName+"']")).getText();
        if(HisAlertName.contains(AlertName))
        	queryObjects.logStatus(driver, Status.PASS, "Customer Name and Alert Name Fields", "Customer Name and Alert Name Field Data matches the Alert name creted", null);
		else {
            queryObjects.logStatus(driver, Status.FAIL, "Customer Name and Alert Name Fields", "Customer Name and Alert Name Fields Data do not matches the Alert name creted", null);
            RC_Global.endTestRun(driver);
		}
        
        RC_Global.createNode(driver, "History Screen grid Column name Validation");
        String [] HisColumnNme = HisColumnNmes.split(";");
    	for(int i=0; i<HisColumnNme.length; i++) {
    		try {
    			driver.findElement(By.xpath("//span[text()='"+HisColumnNme[i]+"']"));
    			queryObjects.logStatus(driver, Status.INFO, "Validate Report Column Names--->Column: " + HisColumnNme[i], "Was Found", null);
    		}
    		catch(Exception e) {
    		queryObjects.logStatus(driver, Status.FAIL, "Validate History Screen Column Names--->Column: " + HisColumnNme[i] + "--->Was NOT Found", e.getLocalizedMessage(), e);
    		}
    	}
	
        RC_Global.panelAction(driver, "close", "Alert History", true, false);
		RC_Global.panelAction(driver, "expand", "Alerts Management - Maintenance", true, false);

        Thread.sleep(2000);
        RC_Global.clickUsingXpath(driver, "(//a[text()='"+AlertName+"']/following::a[text()='Delete'])[1]", "Delete Action Button", true, true);
		Thread.sleep(2000);	
		RC_Global.waitElementVisible(driver, 30, "//h3[text()='Alert will be deleted. Do you want to continue?']", "Alert will be deleted. Do you want to continue?", true, true);
		RC_Global.buttonStatusValidation(driver, "Continue", "Enable", true);
		RC_Global.buttonStatusValidation(driver, "Cancel", "Enable", true);
		RC_Global.clickButton(driver, "Continue", true, true);
		
		List<WebElement> Alertscloned = driver.findElements(By.xpath("//td[text()='"+AlertName+"']"));
		Thread.sleep(3000);
		if(Alertscloned.size()==0)   
				queryObjects.logStatus(driver, Status.PASS, "Delete Action on newly added alert", "The alert is deleted and no longer be seen on the Alerts Management - Fuel screen", null);
			else {
	            queryObjects.logStatus(driver, Status.FAIL, "Delete Action on newly added alert", "The alert is failed to deleted and still can be seen on the Alerts Management - Fuel screen", null);
	            RC_Global.endTestRun(driver);
			}
		RC_Global.panelAction(driver, "close", "Alerts Management - Maintenance", true, true);
        
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}
}
