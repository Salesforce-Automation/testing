package Manage.Administration.AlertsManagement;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_1_07 {
	public void  FuelAlert_ExternalUser_CloneAndDelete(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		String CustomerNumber = "LS008742"; String AlertName = "";
		RC_Global.externalUserLogin(driver, "TestUser09", "Yes");
		RC_Global.navigateTo(driver,"Manage","Administration","Alerts Management");
		RC_Global.waitElementVisible(driver, 30, "//a[text()='Fuel']", "Fuel Hyperlink", true, false);
		RC_Global.clickUsingXpath(driver, "//a[text()='Fuel']", "Fuel Hyperlink", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Alerts Management - Fuel", "TV", true, true);
		RC_Global.panelAction(driver, "close", "Alerts Management", true, false);
		RC_Global.panelAction(driver, "expand", "Alerts Management - Fuel", true, false);
		RC_Global.clickUsingXpath(driver, "(//a[text()='Clone'])[1]", "Clone Action Button", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Clone Alert", "TV", true, true);
		RC_Global.panelAction(driver, "expand", "Clone Alert", true, false);
		
		RC_Global.createNode(driver, "Verify Clone Alert screen layout option");
		RC_Global.verifyScreenComponents(driver, "lable", "Category*", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Name*", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Description", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Customer*", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Threshold", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Distribution", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Distribution Groups", false);
		WebElement Alertname = driver.findElement(By.xpath("//input[@name='alertName']"));
		AlertName = RandomStringUtils.randomAlphabetic(5);
		Alertname.clear();
		RC_Global.enterInput(driver, AlertName, Alertname, true, true);
		RC_Global.clickButton(driver, "Save", true, true);
		RC_Manage.waitUntilMethods(driver, "(//button[text()='Save'])[1]//div[@ng-show='isSaving']","class","ng-hide", "attribute visible");
		RC_Global.verifyDisplayedMessage(driver, "Save Successful", true);
		RC_Global.panelAction(driver, "close", "Clone Alert", true, false);
		RC_Global.panelAction(driver, "expand", "Alerts Management - Fuel", true, false);
		
		List<WebElement> Alertscloned = driver.findElements(By.xpath("//td[text()='"+AlertName+"']"));
		if(Alertscloned.size()>0)   
			queryObjects.logStatus(driver, Status.PASS, "Newly added Fuel alert", "Newly added Fuel Alert displays under Alerts result grid", null);
		else {
            queryObjects.logStatus(driver, Status.FAIL, "Newly added Fuel alert", "Newly added Fuel Alert failed to displays under Alerts result grid", null);
            RC_Global.endTestRun(driver);
		}
		WebElement Delete= driver.findElement(By.xpath("//div[contains(@style,'top: 46px')]"));
		executor.executeScript("arguments[0].scrollLeft += 800",Delete);
		Thread.sleep(2000);
		RC_Global.clickUsingXpath(driver, "(//td[text()='"+AlertName+"']/following::a[text()='Delete'])[1]", "Delete Action Button", true, true);
		Thread.sleep(2000);
		Alertscloned = driver.findElements(By.xpath("//td[text()='"+AlertName+"']"));
		Thread.sleep(3000);
		if(Alertscloned.size()==0)   
				queryObjects.logStatus(driver, Status.PASS, "Delete Action on newly added alert", "The alert is deleted and no longer be seen on the Alerts Management - Fuel screen", null);
			else {
	            queryObjects.logStatus(driver, Status.FAIL, "Delete Action on newly added alert", "The alert is failed to deleted and still can be seen on the Alerts Management - Fuel screen", null);
	            RC_Global.endTestRun(driver);
			}
		RC_Global.panelAction(driver, "close", "Alerts Management - Fuel", true, true);
		
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

		
	}
}
