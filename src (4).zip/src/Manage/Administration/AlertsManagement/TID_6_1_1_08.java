package Manage.Administration.AlertsManagement;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_1_08 {
	public void MaintenanceAlert_ScreenValidationAndResultGrid(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Alerts Management";
		String ColumnName ="Alert Group;Number Of Alerts";
		String SearchFilters ="Alert Type Filter;Customer Number;Customer Name;Alerts";
		String columnName ="Alert Type;Customer Number;Customer Name;Category;Name;Description;Threshold;# Of Fleet Managers;# Of Pool Contacts;# Of Vehicles;Fleet Number;Fleet Name;Account Number;Account Name;Sub-Account Number;Sub-Account Name;History;Actions";
 //       String HisAct = "History;Actions";
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.enterCustomerNumber(driver, "LS010143", "", "", false);
        RC_Global.verifyColumnNames(driver, ColumnName,true);
        
       RC_Global.clickUsingXpath(driver, "//a[text()='Maintenance']", "Maintenance", false,true);
	   RC_Global.panelAction(driver, "close", "Alerts Management", false,true);
	   RC_Global.validateHeaderName(driver, "Alerts Management - Maintenance", false);
	   RC_Global.panelAction(driver, "expand", "Alerts Management - Maintenance", false,true);
	   RC_Global.validateSpecifiedSearchFilters(driver, SearchFilters, false);
       RC_Global.buttonStatusValidation(driver, "Add Alert", "", false);
       
    //   RC_Global.verifyColumnNames(driver, columnName,false);
    //   RC_Manage.verifyGridColumnNames(driver, columnName, false);
   //    RC_Global.verifyColumnNames(driver, HisAct, false);
     //  RC_Manage.verifyGridColumnNames(driver,HisAct , false);
       
       RC_Manage.verifyGridColumnsByName(driver, columnName, "Alerts Management", false);
  //     RC_Manage.verifyGridColumnsByName(driver, columnName, "Alerts Management", false);


       Thread.sleep(3000);
       RC_Global.waitElementVisible(driver, 90, "(//div[contains(@ng-class,'isSelected')])[2]", "Row", false,true);	
       RC_Global.clickUsingXpath(driver, "(//a[contains(@ng-click,'editAlert')])[1]", "Name", false,true);
       
	   RC_Global.validateHeaderName(driver, "Alert Setup - Maintenance Reminder", false);
	   RC_Global.panelAction(driver, "expand", "Alert Setup - Maintenance Reminder", false,true);
	   RC_Global.panelAction(driver, "close", "Alert Setup - Maintenance Reminder", false,true);
	   
	   RC_Global.panelAction(driver, "expand", "Alerts Management - Maintenance", false,true);

       RC_Global.clickUsingXpath(driver, "(//a[contains(@ng-click,'alertHistory')])[1]", "History", false,true);
       
	   RC_Global.validateHeaderName(driver, "Alert History - Maintenance", false);
	   RC_Global.panelAction(driver, "expand", "Alert History - Maintenance", false,true);
	   RC_Global.panelAction(driver, "close", "Alert History - Maintenance", false,true);
	   
	   RC_Global.panelAction(driver, "expand", "Alerts Management - Maintenance", false,true);

       RC_Global.clickUsingXpath(driver, "(//a[contains(@ng-click,'cloneAlert')])[1]", "Clone", false,true);
       
	   RC_Global.validateHeaderName(driver, "Alert Setup - Maintenance Reminder", false);
	   RC_Global.panelAction(driver, "expand", "Alert Setup - Maintenance Reminder", false,true);
	   RC_Global.panelAction(driver, "close", "Alert Setup - Maintenance Reminder", false,true);
	   Thread.sleep(2000);
	   RC_Global.panelAction(driver, "expand", "Alerts Management - Maintenance", false,true);

//	   RC_Global.downloadAndVerifyFileDownloaded(driver, "Export", "Export to Excel Functionality", false);
	   Thread.sleep(4000);
	   WebElement element = null;
		if(driver.findElements(By.xpath("(//button[contains(@ng-click,'exportToExcel()')])[1]")).size()==1)
            element = driver.findElement(By.xpath("(//button[contains(@ng-click,'exportToExcel()')])[1]"));
		Thread.sleep(2000);
		element.click();
		//executor.executeScript("arguments[0].click();", element);

		Thread.sleep(10000);
	        try {
	        String home = System.getProperty("user.home");
	             
	        boolean flag = false;
	        File listofFiles= new File(home+"/Downloads/" );
			// Check for the files available
	        for (File file :listofFiles.listFiles() ) {
	            String filename= file.getName();
			 if(filename.contains("Export")) {
				flag = true;
				file.delete();
					break;
					}	
				}
				if(flag){
					queryObjects.logStatus(driver, Status.PASS, "Clone Alert Page Export Excel icon Validation", "Successfully", null);}
				else {
					queryObjects.logStatus(driver, Status.FAIL, "Clone Alert Page Export Excel icon Validation", "Failed", null);}
		}
		catch (Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Download and verify failed", e.getLocalizedMessage(), e);
		}
		
		
	}


}
