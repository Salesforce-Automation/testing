package Manage.Administration.DocumentCenter;

import java.io.File;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_6_05 {

	public void DocumentCenter_UploadAndValidateTheDocument(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Document Center";
		String SearchFilters ="Customer Number;Unit #;Document Type *;Document File *;Visibility;Document Date *;Description *";
		String ColumnNames = "Customer #;Customer Name;Unit #;CVN;VIN;Year;Make;Model;State;Document Type;Description;Invoice Number;Date Added;Preview Document Image";
		String ColumnNames1 = "Fleet #;Fleet Name;Account #;Account Name;Sub-Account #;Sub-Account Name";
		String errorMsg = "Attached are copies of select E-Billing documentation from Merchants Fleet Management";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.waitUntilPanelVisibility(driver,"Document Center","TV", true,false);
		RC_Global.clickButton(driver, "Upload Document", false,true);
		RC_Global.panelAction(driver, "close", "Document Center", false,true);
		RC_Global.panelAction(driver, "expand", "Document Center Upload Document", false,true);
		RC_Global.validateSpecifiedSearchFilters(driver, SearchFilters, false);
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", false);
		RC_Global.selectDropdownOption(driver, "Document Type *", "Customer Document", false,true);
		//choose file
		driver.findElement(By.xpath("(//input[@type='checkbox' and contains(@class,'not-empty')])[1]")).isSelected();
		RC_Global.getDateTime(driver, "MM/dd/yyyy", 0, true);
		 WebElement Description = driver.findElement(By.xpath("//input[contains(@ng-model,'DocumentDescription')]"));
		 String document = RandomStringUtils.randomNumeric(2);
	        RC_Global.enterInput(driver,"Sample_Testing_doc_"+document, Description , false,true);
		Thread.sleep(2000);
		WebElement InvoiceUpload= driver.findElement(By.xpath("//input[@type='file']"));
        String UploadfileName="Sample_Document.xlsx";
        String uploadFilePath= String.valueOf(String.valueOf(String.valueOf(System.getProperty("user.dir")))) + File.separator + "DocumentUpload" + File.separator + UploadfileName;
		
		InvoiceUpload.sendKeys(uploadFilePath);
		Thread.sleep(2000);
		
		
		
		RC_Global.buttonStatusValidation(driver, "Save Document", "Enable",true);
		RC_Global.clickButton(driver, "Save Document", false,true);
		Thread.sleep(1000);
		RC_Global.waitElementVisible(driver, 90, "//p[text()='Document Upload Successful']", "Document Upload Successful",false,true);
		
		String Successmsg = driver.findElement(By.xpath("(//p[@ng-show='showSuccessMessage'])[1]")).getText();
		if (Successmsg.trim().equals("Document Upload Successful")) {
			queryObjects.logStatus(driver, Status.PASS, "Document uploaded", "Successfully", null);}
		Thread.sleep(2000);
		RC_Global.panelAction(driver, "close", "Document Center Upload Document", false,true);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.waitUntilPanelVisibility(driver,"Document Center","TV", true,false);
		RC_Global.selectDropdownOption(driver, "Document Type *", "Customer Document", false,true);
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", false);
		RC_Global.clickButton(driver, "Search", false,true);

		Thread.sleep(2000);
		RC_Global.panelAction(driver, "close", "Document Center", false,true);
		RC_Manage.verifyGridColumnsByName(driver, ColumnNames, "DocumentCenter", false);
		RC_Manage.verifyGridColumnsByName(driver, ColumnNames1, "DocumentCenter", false);
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		   executor.executeScript("arguments[0].scrollIntoView();", ((WebElement)driver.findElement(By.xpath("//div//span[contains(text(),'Date Added')]"))));
		RC_Global.clickUsingXpath(driver, "//span[text()='Date Added']", "Date added", false, true);//Modif
		 executor.executeScript("arguments[0].scrollIntoView();", ((WebElement)driver.findElement(By.xpath("//div//span[contains(text(),'Date Added')]"))));
		RC_Global.clickUsingXpath(driver, "//span[text()='Date Added']", "Date added", false, false);//Modif
		RC_Global.clickUsingXpath(driver, "//img[@src='assets/img/pdf-icon.png']", "PDF document", false, false);//pdf
		Thread.sleep(3000);		
		String home = System.getProperty("user.home");
		File listofFiles= new File(home+"/Downloads/" );
		for (File file :listofFiles.listFiles() ) {
			String filename= file.getName();
			if(filename.contains(UploadfileName)) {
			queryObjects.logStatus(driver, Status.PASS, "Uploaded "+UploadfileName+" Respective document PDF is Downloaded", "Successfully", null);
			break;}}
		 Thread.sleep(1000);
			executor.executeScript("document.body.style.zoom = '30%'");
				   Thread.sleep(2000);
			executor.executeScript("document.body.style.zoom = '100%'");
		driver.findElement(By.xpath("//tbody/tr[1]/td[contains(text(),'Testing_doc_"+document+"')]//following::input[@name='selectedDocumentIds[]']")).click();
		RC_Global.buttonStatusValidation(driver, "Open", "Enable",false);
        RC_Global.buttonStatusValidation(driver, "Email", "Enable",false);
        RC_Global.buttonStatusValidation(driver, "Print", "Enable",false);
        RC_Global.clickButton(driver, "Open",false,true);
		Thread.sleep(3000);
	    
        try {
            String home1 = System.getProperty("user.home");
            
            boolean flag = false;
            File listofFiles1= new File(home1+"/Downloads/" );
            for (File file :listofFiles1.listFiles() ) {
                String filename= file.getName();
                if(filename.contains("ScannedDocument")) {
                    flag = true;
                    file.delete();
                    break;}
            }
            if(flag) {
               queryObjects.logStatus(driver, Status.PASS, "Upload PDF download", "Successfully", null);}
             else{ 			
                 queryObjects.logStatus(driver, Status.FAIL, "Upload PDF download", "Failed", null); }   
        }
        catch(Exception e) {			
        	queryObjects.logStatus(driver, Status.FAIL, "Download and verify failed", e.getLocalizedMessage(), e);
        }
			
        RC_Global.clickButton(driver, "Email",true,true);
        RC_Global.waitElementVisible(driver, 60, "//h3[text()='Email Documents']", "Email Documents",false,true);
        RC_Global.verifyDisplayedMessage(driver, errorMsg,true);
        Thread.sleep(1000);
        RC_Global.scrollById(driver, "(//div[4]//button[2][normalize-space(text()='Cancel')])[2]");
        RC_Global.clickUsingXpath(driver, "(//div[4]//button[2][normalize-space(text()='Cancel')])[2]", "Cancel",false,true);
        Thread.sleep(4000);
        //Hover to perview image
        
        WebElement element = driver.findElement(By.xpath("(//img[@service-path='documents/preview/'])[1]"));
        ((JavascriptExecutor)driver).executeScript("var mouseEvent = document.createEvent('MouseEvents');mouseEvent.initEvent('mouseover', true, true); arguments[0].dispatchEvent(mouseEvent);", element);
        Thread.sleep(2000);
        
        RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
        
	}
}
