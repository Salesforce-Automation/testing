package Manage.Administration.DocumentCenter;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_6_06 {

	public void DocumentCenter_ValidateSearchFiltersAndDocumentTypeUsingExternalUser(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Document Center";
		String SearchFilters ="Document Type *;Customer Number;Unit #;Plate #;Plate State;Customer Vehicle #;Make;Model;Year;VIN;Driver First Name;Driver Last Name;Client Data Field;Client Data Value;Invoice #;Maintenance PO #;Violations #";
		String dropdownvalues = "Customer Document;Customer Report;Dealer Invoice;Delivery Receipt;Disposition;Driver Log;Excise Tax;Executed Schedule A;Factory Invoice;Inspections;Insurance;Insurance Certificate;Maintenance PO;Master Lease Agreement;Misc Sundry;Miscellaneous;MSO;Off Lease;Perfected Schedule A;Plate;Plate Return Receipt;Proforma Schedule A;Purchase & Disposal;Rate Sheet;Registration;Registration Title Tax;Schedule A;SE Transmittal;UCC;Vehicle Documentation;Violations";

		RC_Global.externalUserLogin(driver, "kentuckytest1", "Yes");
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.waitUntilPanelVisibility(driver,"Document Center","TV", true,false);
		RC_Global.validateSpecifiedSearchFilters(driver, SearchFilters, false);
		RC_Global.buttonStatusValidation(driver, "Upload Document", "Presence",false);
        RC_Global.buttonStatusValidation(driver, " Search ", "Presence",false);
        RC_Global.buttonStatusValidation(driver, "Reset", "Presence",false);
        Thread.sleep(2000);
		RC_Global.dropdownValuesValidation(driver, dropdownvalues, "//select[contains(@ng-model,'DocumentTypeId')]",false, true);
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
