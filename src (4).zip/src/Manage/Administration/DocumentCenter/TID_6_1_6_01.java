package Manage.Administration.DocumentCenter;

import java.io.File;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Wait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_6_01 {
	
	public void DocumentCenter_MaintenancePO_ExternalUserSearchAndAccessDocument(WebDriver driver, BFrameworkQueryObjects queryObjects)throws Exception
	{
		ArrayList<String> getWindows = new ArrayList<String>(driver.getWindowHandles());
		String DwnFileNm = "";
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		
		RC_Global.externalUserLogin(driver,"pantest","Yes");
		RC_Global.navigateTo(driver, "Manage", "Administration", "Document Center");
		RC_Global.validateHeaderName(driver, "Document Center", true);
	// Select doc type
		RC_Global.selectDropdownOption(driver, "docTypeSelect", "Maintenance PO", false, true);
		RC_Global.clickButton(driver, "Search", false, true);
		Thread.sleep(3000);
		RC_Global.waitElementVisible(driver, 120, "//span[text()='Document Center Search Results']", "Document Center Search Results screen",false, false);
		
	// Download file	
		 DwnFileNm = driver.findElement(By.xpath("(//td[3]/a[@title='Open Vehicle Details'])[1]")).getText();
	        RC_Global.clickUsingXpath(driver,"(//span[text()='Maintenance PO']/../img[@src='assets/img/pdf-icon.png'])[1]", "Document Type",true, true);
	        Thread.sleep(7000);
	       
	        try {
	        String home = System.getProperty("user.home");
	             
	        boolean flag = false;
	        File listofFiles= new File(home+"/Downloads/" );
	        for (File file :listofFiles.listFiles() ) {
	            String filename= file.getName();
	            if(filename.contains(DwnFileNm)) {
	                flag = true;
	                file.delete();
	                break;
	        }
	        }
	        if(flag) {
	           queryObjects.logStatus(driver, Status.PASS, "Document type - Maintenance PO PDF download", "Successfully", null);
	           }
	         else{ 			
	             queryObjects.logStatus(driver, Status.FAIL, "Document type - Maintenance PO PDF download", "Failed", null);
	        }
	        }
	        catch(Exception e) {			
	        	queryObjects.logStatus(driver, Status.FAIL, "Download and verify failed", e.getLocalizedMessage(), e);
	        }
	        
		driver.switchTo().window(getWindows.get(0));
		
	//	Button status validation
		RC_Global.buttonStatusValidation(driver, "Open", "Enable", false);
		RC_Global.buttonStatusValidation(driver, "Print", "Enable", false);
		RC_Global.buttonStatusValidation(driver, "Email", "Enable", false);
		
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.findElement(By.xpath("(//td/input[@ng-click='toggleDocumentSelected(data)'])[1]")));
		 RC_Global.clickUsingXpath(driver, "(//td/input[@ng-click='toggleDocumentSelected(data)'])[1]", "Document",true, true);
		 RC_Global.clickUsingXpath(driver, "(//td/input[@ng-click='toggleDocumentSelected(data)'])[2]", "Document",true, false);
	
	//	 Email Screen validation
		 RC_Global.clickButton(driver, "Email",false, true);
		 RC_Global.validateHeaderName(driver, "Email Documents", false);
		 RC_Global.scrollById(driver, "(//div[4]//button[2][normalize-space(text()='Cancel')])[2]");
		 RC_Global.clickUsingXpath(driver, "(//div[4]//button[2][normalize-space(text()='Cancel')])[2]", "Cancel",false,true);
		 Thread.sleep(1000);
		
		 RC_Global.panelAction(driver, "close", "Document Center Search Results", false, false);
		 RC_Global.panelAction(driver, "close", "Document Center", false, false);
		 RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
		 
			
	
	}
}
