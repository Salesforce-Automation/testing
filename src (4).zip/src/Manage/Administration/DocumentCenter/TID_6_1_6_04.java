package Manage.Administration.DocumentCenter;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_6_04 {
	public static void DocumentCenter_ValidateDocumentTypeValueAndUIException(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Document Center");
		RC_Global.waitUntilPanelVisibility(driver, "Document Center", "TV", true, false);
		
		boolean flag=false;
		String[] documentTypeInputs = {"Accounts Payable","Addendums","Billing","Check In Sheet","Claims","Credit","Customer Document","Customer Report","Dealer Invoice","Delivery Receipt","Disposition","Driver Log","Excise Tax","Executed Schedule A","Factory Invoice","Inspections","Insurance","Maintenance PO","Master Lease Agreement","Misc Sundry","Miscellaneous","MSO","Off Lease","Perfected Schedule A","Plate","Plate Return Receipt","Proforma Schedule A","Purchase & Disposal","Rate Sheet","Registration","Registration Title Tax","Schedule A","SE Transmittal","UCC","Vehicle Documentation","Violations"};
		List<WebElement> docTypeList = driver.findElements(By.xpath("//select[@id='docTypeSelect']/option"));
		for(int iterator=0;iterator<documentTypeInputs.length;iterator++) {
			for(WebElement dtl:docTypeList) {
				if(dtl.getText().equalsIgnoreCase(documentTypeInputs[iterator])) {
					flag=true;
					queryObjects.logStatus(driver, Status.INFO, "Validating Document Type", documentTypeInputs[iterator]+" option is available in Document Type dropdown", null);
					break;
				}
				else flag=false;
			}
			if(!flag)
				queryObjects.logStatus(driver, Status.FAIL, "Validating Document Type", documentTypeInputs[iterator]+" option is not available in Document Type dropdown", null);
			
		}
		RC_Global.enterCustomerNumber(driver, "LS010143", "", "", true);
		RC_Global.clickButton(driver, "Search", true, true);
		
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//h4[text()='Document Type required.']")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Validating error message", "'Document Type required.' error message is displayed as expected", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Validating error message", "'Document Type required.' error message is not displayed", null);
		
		RC_Global.clickButton(driver, "Reset", true, true);
		
//		RC_Global.clickUsingXpath(driver, "driver.findElements(By.xpath(\"//select[@id='docTypeSelect']", "Document Type", true, createND);
		
		RC_Global.selectDropdownOption(driver, "docTypeSelect",  docTypeList.get(2).getText(), true, true);
		RC_Global.clickButton(driver, "Search", true, true);
		
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//h4[text()='Additional filter criteria of at least one of the following is required: Customer #, Unit #, Plate #, Invoice # or VIN.']")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Validating error message", "'Additional filter criteria of at least one of the following is required: Customer #, Unit #, Plate #, Invoice # or VIN.' error message is displayed as expected", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Validating error message", "'Additional filter criteria of at least one of the following is required: Customer #, Unit #, Plate #, Invoice # or VIN.' error message is not displayed", null);
	
		RC_Global.panelAction(driver, "close", "Document Center", false, true);
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
