package Manage.Administration.DocumentCenter;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;


public class TID_6_1_6_03 {
	public void  DocumentCenter_UploadDocument(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		String searchFilters = "Customer Number;Unit #;Document Type *;Document File *;Visibility;Document Date *;Description *";
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,"Manage","Administration","Document Center");
		RC_Global.clickButton(driver, "Upload Document", true,true);
		RC_Global.waitUntilPanelVisibility(driver, "Document Center Upload Document", "TV", true,false);
		RC_Global.panelAction(driver,"close", "Document Center", true,false);
		RC_Global.panelAction(driver,"expand", "Document Center Upload Document", true,false);
		RC_Global.validateSpecifiedSearchFilters(driver, searchFilters, true);
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		RC_Global.selectDropdownOption(driver, "Document Type *", "Customer Document", true,true);
		//RC_Global.clickUsingXpath(driver, "", "Set Visibility as Customer", true);
		WebElement Description = driver.findElement(By.xpath("//input[@id='docDescription']"));
		RC_Global.enterInput(driver, "Testing", Description, true,true);
		RC_Global.createNode(driver, "Choose a file to upload");
		Thread.sleep(2000);
		WebElement FileUpload= driver.findElement(By.xpath("//input[@type='file']"));
        String UploadfileName="Sample_Invoiceupdate.xlsx";
        FileUpload.sendKeys(String.valueOf(String.valueOf(String.valueOf(System.getProperty("user.dir")))) + File.separator +"Uploadfiles\\"+UploadfileName+"");
		Thread.sleep(2000);
		RC_Global.clickButton(driver, "Save Document", true,true);
		RC_Global.verifyDisplayedMessage(driver, "Document Upload Successful", true);
		RC_Global.panelAction(driver,"close", "Document Center Upload Document", true,true);
		
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
