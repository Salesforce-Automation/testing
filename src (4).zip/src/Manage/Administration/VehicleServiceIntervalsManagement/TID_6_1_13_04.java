package Manage.Administration.VehicleServiceIntervalsManagement;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_13_04 {
	public void VehicleSegmentIntervalsManagement_ValidateSearchFilters (WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		String menu = "Manage";String CustomerNumber = "LS008742"; String  ServiceTabSearchFil = "Repair Item;VMRS Code";
		String firstSubMenu = "Administration";String SecSubMenu = "Vehicle Service Intervals Management";
		String searchFilters = "Customer Number;Unit Number;Service;Segment;Year;Make;Model;Show Inactive";
//		String ServiceDropDownVal = "LOF;Tire Rotation;Tire Rotation";
//		String  SegmentDropDownVal = "autotest1534738789;Full Size Van;gbXQv Car;Heavy Truck;Intermediate Crossover;Intermediate Sedan;Intermediate SUV;Kcnva Car;KFGkH Car;KQcvU Car;LeAOo Car;Light Truck I;Light Truck II;Luxury Sedan;Luxury SUV";
//		String  MakeDropDownVal = "Acura;Alfa Romeo;AM General;AMC;Aston Martin;Audi;Bentley;BMW;Bugatti;Buick;Cadillac;Chevrolet;Chrysler;Daewoo";
//		String  ModelDropDownVal = "1 Series M;100;1000;124 Spider;128;135;1500;18i;190;190E;200;200;2000;200SX";

		List<String> ServiceDropDownValue=new ArrayList<String>();
		List<String> SegmentDropDownValue=new ArrayList<String>();
		List<String> MakeDropDownValue=new ArrayList<String>();
		List<String> ModelDropDownValue=new ArrayList<String>();

		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,SecSubMenu);
		RC_Global.validateSpecifiedSearchFilters(driver, searchFilters, true);
		//
		RC_Global.clickUsingXpath(driver, "//input[@id='service']", "Service DD", false, false);
		for(int i=1;i<=driver.findElements(By.xpath("//input[@id='service']/following-sibling::ul/li/a")).size();i++)
		{
		ServiceDropDownValue.add(driver.findElement(By.xpath("(//input[@id='service']/following-sibling::ul/li/a)["+i+"]")).getText());
		}
		Thread.sleep(2000);
		RC_Global.clickUsingXpath(driver, "//input[@id='segment']", "Segement DD", false, false);
		Thread.sleep(2000);
		for(int i=1;i<=driver.findElements(By.xpath("//input[@id='segment']/following-sibling::ul/li/a")).size();i++)
		{
		SegmentDropDownValue.add(driver.findElement(By.xpath("(//input[@id='segment']/following-sibling::ul/li/a)["+i+"]")).getText());
		}
		Thread.sleep(2000);
		RC_Global.clickUsingXpath(driver, "//input[@id='vehicleMake']", "Make DD", false, false);
		Thread.sleep(2000);
		for(int i=1;i<=driver.findElements(By.xpath("//input[@id='vehicleMake']/following-sibling::ul/li/a")).size();i++)
		{
		MakeDropDownValue.add(driver.findElement(By.xpath("(//input[@id='vehicleMake']/following-sibling::ul/li/a)["+i+"]")).getText());
		}
		Thread.sleep(2000);
		RC_Global.clickUsingXpath(driver, "//input[@id='vehicleModel']", "Make DD", false, false);
		Thread.sleep(2000);
		for(int i=2;i<=driver.findElements(By.xpath("//input[@id='vehicleModel']/following-sibling::ul/li/a")).size();i++)
		{
		ModelDropDownValue.add(driver.findElement(By.xpath("(//input[@id='vehicleModel']/following-sibling::ul/li/a)["+i+"]")).getText());
		}
		//
		RC_Manage.dropdownValuesValidation(driver, ServiceDropDownValue,"Service","//input[@id='service']", true);
		RC_Manage.dropdownValuesValidation(driver, SegmentDropDownValue,"Segment","//input[@id='segment']", true);
		RC_Manage.dropdownValuesValidation(driver, MakeDropDownValue,"Make","//input[@id='vehicleMake']", true);
		RC_Manage.dropdownValuesValidation(driver, ModelDropDownValue,"Mode","//input[@id='vehicleModel']", true);
		
		RC_Global.enterCustomerNumber(driver,CustomerNumber, "", "", true);
		RC_Global.clickButton(driver,"Search", true,true);
    	RC_Global.waitElementVisible(driver, 30, "(//div[text()='"+CustomerNumber+"'])[1]","Grid load", true,false);
    	String UnitNumber = driver.findElement(By.xpath("(//a[@href='#'])[1]")).getText();
    	String Year = "2019";
    	WebElement UnitNumberIn = driver.findElement(By.xpath("//input[@id='unitNumber']"));
    	WebElement YearIn = driver.findElement(By.xpath("//input[@id='year']"));
    	
    	//search unitnum and yeAR
    	RC_Global.clickButton(driver,"Reset", true,true);
    	RC_Global.enterInput(driver, UnitNumber, UnitNumberIn, true,true);   	
    	RC_Global.clickButton(driver,"Search", true,true);
    	RC_Global.waitElementVisible(driver, 30,"(//div[@role='row'])[2]", "Search Results for UnitNumber Filter", true,true);
    	
    	RC_Global.clickButton(driver,"Reset", true,true);
    	RC_Global.enterInput(driver, Year, YearIn, true,true);   	
    	RC_Global.clickButton(driver,"Search", true,true);
    	RC_Global.waitElementVisible(driver, 30,"(//div[@role='row'])[2]", "Search Results for Year Filter", true,true);
    	
    	RC_Manage.dropDownSearchFilterValidation(driver,ServiceDropDownValue,"Service","service",true);
    	driver.findElement(By.xpath("(//button[text()='Reset'])[1]")).click();
    	Thread.sleep(2000);
    	RC_Manage.dropDownSearchFilterValidation(driver,SegmentDropDownValue,"Segment","segment",true);
    	driver.findElement(By.xpath("(//button[text()='Reset'])[1]")).click();
    	Thread.sleep(2000);
    	RC_Manage.dropDownSearchFilterValidation(driver,MakeDropDownValue,"Make","vehicleMake",true);
    	driver.findElement(By.xpath("(//button[text()='Reset'])[1]")).click();
    	Thread.sleep(2000);
    	RC_Manage.dropDownSearchFilterValidation(driver,ModelDropDownValue,"Mode","vehicleModel",true);
    	
    	RC_Global.buttonStatusValidation(driver, "Search", "Enable", true);
     	RC_Global.buttonStatusValidation(driver, "Reset", "Enable", true);
     	RC_Global.buttonStatusValidation(driver, " Add New ", "Enable", true);
     	RC_Global.buttonStatusValidation(driver, " Edit ", "Disable", true);
     	RC_Global.buttonStatusValidation(driver, " Clone ", "Disable", true);
     	RC_Global.buttonStatusValidation(driver, " History ", "Disable", true);
     	
     	RC_Global.clickUsingXpath(driver,"//a[text()='Services']", "Services Tab", true,true);
     	RC_Global.validateSpecifiedSearchFilters(driver, ServiceTabSearchFil, true);
     	WebElement RepairItem = driver.findElement(By.xpath("//input[@id='name']"));
    	WebElement VMRScode = driver.findElement(By.xpath("//input[@id='vmrsCode']"));
    	
    	
    	RC_Global.enterInput(driver,"Tire Rotation", RepairItem, true,true);   	
    	driver.findElement(By.xpath("(//button[text()='Search'])[2]")).click();
    	Thread.sleep(2000);
    	RC_Global.waitElementVisible(driver, 30,"(//div[text()='Tire Rotation'])[1]","Result based on the search filter Repair Item is displayed in the grid", true,true);
    	 
    	
    	driver.findElement(By.xpath("(//button[text()='Reset'])[2]")).click();
    	Thread.sleep(2000);
    	RC_Global.enterInput(driver,"Perform PM Service", VMRScode, true,true);   	
    	driver.findElement(By.xpath("(//button[text()='Search'])[2]")).click();
    	Thread.sleep(2000);
     	RC_Global.waitElementVisible(driver, 30,"(//div[text()='Perform PM Service'])[1]","Result based on the search filter VMRS Code is displayed in the grid", true,true);
     	
    	RC_Global.buttonStatusValidation(driver, "Search", "Enable", true);
     	RC_Global.buttonStatusValidation(driver, "Reset", "Enable", true);
     	RC_Global.buttonStatusValidation(driver, " Add New ", "Enable", true); 
     	RC_Global.buttonStatusValidation(driver, " Edit ", "Disable", true);
     	RC_Global.buttonStatusValidation(driver, " History ", "Disable", true);
     	
     	RC_Global.panelAction(driver, "close","Vehicle Service Intervals Management", true,true);
     	RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
