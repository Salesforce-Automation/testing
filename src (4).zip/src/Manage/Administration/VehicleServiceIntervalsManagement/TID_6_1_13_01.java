package Manage.Administration.VehicleServiceIntervalsManagement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_13_01 {
	public void MVSI_CloneServiceIntervals_DuplicateIntervalErrorMessage(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
		RC_Global.validateHeaderName(driver, "Customer Administration", true);
		RC_Global.enterCustomerNumber(driver, "LS010116", "", "", true);
		Thread.sleep(2000);
	//	RC_Global.clickUsingXpath(driver, "//a[text()='Maintenance']", "Maintenance Tab", true,true);
		RC_Global.clickUsingXpath(driver, "//a[text()='Maintenance']", "Maintenance Tab", false,true);
		RC_Global.buttonStatusValidation(driver, "Yes", "Enable", false);

		
		String maintenance = driver.findElement(By.xpath("//button[contains(@ng-click,'YesClick()')]")).getText();
		if (maintenance.equals("Yes"))
		{
		queryObjects.logStatus(driver, Status.PASS, "Customer Number Enrolled in Maintenance as", maintenance , null);
		
        RC_Global.panelAction(driver, "close", "Customer Administration",false,true);

		RC_Global.navigateTo(driver, "Manage", "Administration", "Vehicle Service Intervals Management");
		RC_Global.validateHeaderName(driver, "Vehicle Service Intervals Management", true);
		RC_Global.enterCustomerNumber(driver, "LS010116", "", "", true);
	//	select LOF row
		
		String Service = driver.findElement(By.xpath("(//standard-grid/div//div[1]/div/div[10]/div)[2]")).getText();
		RC_Global.clickUsingXpath(driver, "(//standard-grid/div//div[1]/div/div[10]/div)[2]", "Select a row", false,true);
	
		if((Service.equals("LOF") || Service.equals("Tire Rotation")))
		{
		queryObjects.logStatus(driver, Status.PASS, "Service Interval created as", Service , null);
		}
		else
		{
		queryObjects.logStatus(driver, Status.FAIL, "Service Interval not created as", Service , null);
		}



		RC_Global.clickButton(driver, " Clone ", false,true);
		RC_Global.validateHeaderName(driver, "Vehicle Service Intervals - Clone Interval",true);
        RC_Global.panelAction(driver, "close", "Vehicle Service Intervals Management",false,true);
        RC_Global.panelAction(driver, "expand", "Vehicle Service Intervals - Clone Interval",false,true);
        
        WebElement element = driver.findElement(By.xpath("//input[@id='miles']"));
		String input = "2000";
		RC_Global.enterInput(driver, input, element, false,true);
		
		RC_Global.clickButton(driver, " Save ", false,true);
	    RC_Global.verifyDisplayedMessage(driver, "Duplicate Interval Exists.", false);
		
		}
		else
		{
		queryObjects.logStatus(driver, Status.FAIL, "Customer Number Enrolled in Maintenance as", maintenance , null);
		}
	
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
}
}


