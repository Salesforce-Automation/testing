package Manage.Administration.VehicleServiceIntervalsManagement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_13_02 {
	public void MVSI_AddNewIntervalDuplicateIntervalErrorMessage(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
		RC_Global.validateHeaderName(driver, "Customer Administration", true);
		RC_Global.enterCustomerNumber(driver, "LS004792", "", "", true);
		Thread.sleep(2000);
	//	RC_Global.clickUsingXpath(driver, "//a[text()='Maintenance']", "Maintenance Tab", true,true);
		RC_Global.clickUsingXpath(driver, "//a[text()='Maintenance']", "Maintenance Tab", false,true);
		RC_Global.buttonStatusValidation(driver, "Yes", "Enable", false); 
        
		String maintenance = driver.findElement(By.xpath("//button[contains(@ng-click,'YesClick()')]")).getText();
		if (maintenance.equals("Yes"))
		{
		queryObjects.logStatus(driver, Status.PASS, "Customer Number Enrolled in Maintenance as", maintenance , null);
		
        RC_Global.panelAction(driver, "close", "Customer Administration",false,true);

		RC_Global.navigateTo(driver, "Manage", "Administration", "Vehicle Service Intervals Management");
		RC_Global.validateHeaderName(driver, "Vehicle Service Intervals Management", true);
		RC_Global.enterCustomerNumber(driver, "LS004792", "", "", true);
		RC_Global.clickButton(driver, "Search", false,true);
		
		RC_Global.clickButton(driver, " Add New ", false,true);
//		RC_Global.validateHeaderName(driver, "Vehicle Service Intervals - Add Interval", true);
        RC_Global.panelAction(driver, "close", "Vehicle Service Intervals Management",false,true);
        RC_Global.panelAction(driver, "expand", "Vehicle Service Intervals - Add Interval",false,true);
        
        RC_Global.clickUsingXpath(driver, "(//label[text()='Segment']/..//input)[1]", "Segment", false,true);
        RC_Global.clickUsingXpath(driver, "(//label[text()='Segment']/../ul/li/a)[1]", "Segment", false,true);

    //    RC_Global.selectDropdownOption(driver, "typeahead-40753-2600-option-0", "Full Size Van", false,true);
        
        RC_Global.clickUsingXpath(driver, "(//label[text()='Service']/..//input)[1]", "Service", false,true);
        RC_Global.clickUsingXpath(driver, "(//label[text()='Service']/../ul/li/a)[1]", "Service", false,true);

    //    RC_Global.selectDropdownOption(driver, "typeahead-40754-8898-option-0", "LOF", false,true);
        
        WebElement element = driver.findElement(By.xpath("//input[@id='miles']"));
		String input = "2000";
		RC_Global.enterInput(driver, input, element, false,true);
		
		RC_Global.clickButton(driver, " Save ", false,true);
	    RC_Global.verifyDisplayedMessage(driver, "Duplicate Interval Exists.", false);

		RC_Global.panelAction(driver, "close", "Vehicle Service Intervals - Add Interval", false,true);
		
		RC_Global.logout(driver, false);

		}
		else
		{
		queryObjects.logStatus(driver, Status.FAIL, "Customer Number Enrolled in Maintenance as", maintenance , null);
		}
	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	
	}
	
}
