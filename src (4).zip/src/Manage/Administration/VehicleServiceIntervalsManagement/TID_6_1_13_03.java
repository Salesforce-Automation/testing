package Manage.Administration.VehicleServiceIntervalsManagement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_13_03 {

	public void MVSI_VehicleServiceIntervals_AddNewInterval(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Vehicle Service Intervals Management";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Vehicle Details");
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details","TV", true,false);
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", false);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Manage.driverSelection(driver, false);
		String UnitNumber = driver.findElement(By.xpath("(//a[@ng-click='openVehicleDetails()'])[1]")).getText();
		queryObjects.logStatus(driver, Status.PASS, "Unit Number of vehicle Enrolled in Maintenance---->", UnitNumber, null);
		RC_Global.panelAction(driver, "close", "Driver Details", false,true);
		RC_Global.panelAction(driver, "close", "Vehicle Details", false,true);
		
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Service Intervals Management","TV", true,false);
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", false);
		WebElement element = driver.findElement(By.xpath("//input[@ng-model='vm.unitNumber']"));
		RC_Global.enterInput(driver, UnitNumber, element, false, true);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.clickButton(driver, "Add New", false,true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Service Intervals - Add Interval","TV", true,false);

		WebElement element1 = driver.findElement(By.xpath("//input[@ng-change='vm.onUnitNumberChange()']"));
		RC_Global.enterInput(driver, UnitNumber, element1, false, true);
		
		String Year = driver.findElement(By.xpath("//input[@ng-model='vm.unitYear']")).getAttribute("year");
		String Make = driver.findElement(By.xpath("//input[@ng-model='vm.unitMake']")).getAttribute("make");
		String Model = driver.findElement(By.xpath("//input[@ng-model='vm.unitModel']")).getAttribute("model");
		queryObjects.logStatus(driver, Status.PASS, "Populated as set for this Unit Number Year is ---->", Year, null);
		queryObjects.logStatus(driver, Status.PASS, "Populated as set for this Unit Number Make is ---->", Make, null);
		queryObjects.logStatus(driver, Status.PASS, "Populated as set for this Unit Number Model is ---->", Model, null);
		
		WebElement Service = driver.findElement(By.xpath("//input[@ng-model='vm.service']"));
		RC_Global.enterInput(driver, "LOF", Service, false, true);
		WebElement Miles = driver.findElement(By.xpath("//input[@name='miles']"));
		RC_Global.enterInput(driver, "3000", Miles, false, true);
		WebElement Days = driver.findElement(By.xpath("//input[@name='days']"));
		RC_Global.enterInput(driver, "90", Days, false, true);
		RC_Global.clickUsingXpath(driver, "//input[contains(@ng-model,'IsActiveIndicator')]", "Active", false, true);
		
		RC_Global.clickButton(driver, "Save", false,true);
		Thread.sleep(5000);
		RC_Global.verifyDisplayedMessage(driver, "Save Successful", false);
		Thread.sleep(3000);
		RC_Global.panelAction(driver, "close", "Edit Interval", false,true);
		RC_Global.panelAction(driver, "close", "Vehicle Service Intervals Management", false,true);
		//RC_Global.panelAction(driver, "close", "Vehicle Service Intervals - Add Interval", false,true);

		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Service Intervals Management","TV", true,false);
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", false);
		WebElement element2 = driver.findElement(By.xpath("//input[@ng-model='vm.unitNumber']"));
		RC_Global.enterInput(driver, UnitNumber, element2, false, true);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.clickUsingXpath(driver, "//a[contains(@ng-click,'openVehicleDetails')]", "Unit Number", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details","TV", true,false);
		Thread.sleep(2000);
		RC_Global.clickUsingXpath(driver, "//strong[text()='Maintenance']", "Maintenance", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details - Maintenance","TV", true,false);
		RC_Global.clickUsingXpath(driver, "//button[text()=' Maintenance Summary ']", "Maintenance Summary", false, true);
		RC_Global.waitElementVisible(driver, 60, "//div[text()='Service Intervals']", "service", false, false);
		
		String Servicemiles = driver.findElement(By.xpath("(//span[contains(@ng-if,'IntervalMileage')])[1]")).getText();
		String Servicedays = driver.findElement(By.xpath("(//span[contains(@ng-if,'IntervalDays')])[2]")).getText();
		queryObjects.logStatus(driver, Status.PASS, "Updated Service Miles is ---->", Servicemiles, null);
		queryObjects.logStatus(driver, Status.PASS, "Updated Service Days is ---->", Servicedays, null);
//		RC_Global.panelAction(driver, "close", "Vehicle Details - Maintenance", false,true);
		RC_Global.panelAction(driver, "close", "Vehicle Details", false,true);
		RC_Global.panelAction(driver, "close", "Vehicle Service Intervals Management", false,true);
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);	
	}
}
