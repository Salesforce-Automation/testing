package Manage.Administration.VehicleServiceIntervalsManagement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_13_05 {
	public void VehicleSegmentIntervalsManagement_ServicesTab_EditExistingServices(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String currentDate = RC_Manage.AddDateStr(0, "M/d/yy", "", null, "CST");
		String NewRepairItem="";
		
		RC_Global.login(driver);
		String loggedUser = driver.findElement(By.xpath("//div[@class='bottom-nav bottom-right-menu']//div/ul[@class='nav-right list-unstyled pull-right user-menu']/li/a")).getText();

		RC_Global.navigateTo(driver, "Manage", "Administration", "Vehicle Service Intervals Management");
		RC_Global.clickUsingXpath(driver, "//a[text()='Services']", "Service", false, true);
		Thread.sleep(1000);
		String OldRepairItem = driver.findElement(By.xpath("((//div[@class='ui-grid-canvas'])[2]/div[2]/div/div)[1]/div")).getText();
		RC_Global.clickUsingXpath(driver, "((//div[@class='ui-grid-canvas'])[2]/div[2]/div/div)[1]/div", "2nd row", false, true);
		RC_Global.clickUsingXpath(driver, "(//button[text()=' Edit '])[2]", "Edit", false, true);
		RC_Global.waitElementVisible(driver, 10, "//h3[text()='Add/Edit Service Details']", "Add/Edit Service Details", false, true);
		if(OldRepairItem.equals("Perform PM Service - Equipment"))
		{
			NewRepairItem="Perform PM Service";
		}
		else
		{
			NewRepairItem="Perform PM Service - Equipment";
		}
		WebElement NameInputField = driver.findElement(By.xpath("(//input[@id='name'])[1]"));
		NameInputField.clear();
		RC_Global.enterInput(driver, NewRepairItem, NameInputField, false, true);
		RC_Global.clickButton(driver, "Save", false, true);
		Thread.sleep(3000);
		RC_Global.createNode(driver, "Validate the edited Service Details");
		if(driver.findElement(By.xpath("((//div[@class='ui-grid-canvas'])[2]/div[2]/div/div)[1]/div")).getText().contains(NewRepairItem))
		{
			queryObjects.logStatus(driver, Status.PASS, "Edited Service details reflects in 'Vehicle Service Intervals Management(Services Tab)' screen", NewRepairItem, null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Edited Service details does not reflect in 'Vehicle Service Intervals Management(Services Tab)' screen", "", null);
		}
		RC_Global.clickUsingXpath(driver, "((//div[@class='ui-grid-canvas'])[2]/div[2]/div/div)[1]/div", "2nd row", false, true);
		RC_Global.clickUsingXpath(driver, "(//button[text()=' History '])[2]", "History", false, true);
		RC_Global.panelAction(driver, "close", "Vehicle Service Intervals Management", false, true);
		RC_Global.panelAction(driver, "expand", "Services History", false, true);
		RC_Global.createNode(driver, "Validate Service History Screen");
		if(driver.findElements(By.xpath("//label[text()='From:']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "In 'Services History Detail' screen", "'From:' search filter is Displayed", null);
		}
		if(driver.findElements(By.xpath("//label[text()='To:']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "In 'Services History Detail' screen", "'To:' search filter is Displayed", null);
		}
		if(driver.findElements(By.xpath("//label[text()='Service Name']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "In 'Services History Detail' screen", "'Service Name' search filter is Displayed", null);
		}
		if(driver.findElements(By.xpath("//button[text()='Search']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "In 'Services History Detail' screen", "'Search' button is Displayed", null);
		}
		if(driver.findElements(By.xpath("//button[text()='Reset']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "In 'Services History Detail' screen", "'Reset' button is Displayed", null);
		}
		RC_Global.clickUsingXpath(driver, "((//div[@class='ui-grid-row ng-scope'])[1]//div[@role='gridcell'])[6]/div", "Details", false, true);
		Thread.sleep(1000);
		RC_Global.createNode(driver, "Validate 'Services History Details' popup screen");
		if(driver.findElements(By.xpath("(//label[text()='Repair Item'])[1]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "In 'Services History Details' popup screen", "'Repair Item' is Displayed", null);
		}
		if(driver.findElements(By.xpath("(//label[text()='Is Active'])[1]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "In 'Services History Details' popup screen", "'Is Active' is Displayed", null);
		}
		if(driver.findElements(By.xpath("(//label[text()='Created Date'])[1]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "In 'Services History Details' popup screen", "'Created Date' is Displayed", null);
		}
		if(driver.findElements(By.xpath("(//label[text()='Service Description'])[1]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "In 'Services History Details' popup screen", "'Service Description' is Displayed", null);
		}
		if(driver.findElements(By.xpath("(//label[text()='Modified By'])[1]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "In 'Services History Details' popup screen", "'Modified By' is Displayed", null);
			String ModifiedBy = driver.findElement(By.xpath("(//label[text()='Modified By'])[1]//..//following-sibling::div")).getText();
			if(ModifiedBy.contains(RC_Global.userLogged))
			{
				queryObjects.logStatus(driver, Status.PASS, "'Modified By' displays the logged user's name", ModifiedBy, null);
			}
			else
			{
				queryObjects.logStatus(driver, Status.FAIL, "The logged user's name", "'Modified By' is not Displayed", null);
			}
		}
		if(driver.findElements(By.xpath("(//label[text()='Modified Date'])[1]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "In 'Services History Details' popup screen", "'Modified Date' is displayed", null);
			String ModifiedDate = driver.findElement(By.xpath("(//label[text()='Modified Date'])[1]//..//following-sibling::div")).getText();
			System.out.println("ModifiedDate "+ModifiedDate);
			if(ModifiedDate.contains(currentDate))
			{
				queryObjects.logStatus(driver, Status.PASS, "'Modified Date' displays", "The current date", null);
			}
			else
			{
				queryObjects.logStatus(driver, Status.PASS, "'Modified Date' displays", "The current date", null);
			}
		}
		String NewValueModifiedDate = driver.findElement(By.xpath("((//div[@class='ui-grid-row ng-scope'])[5]//div[@role='gridcell'])[3]/div")).getText();
		if(NewValueModifiedDate.contains(currentDate))
		{
			queryObjects.logStatus(driver, Status.PASS, "New Value column 'Modified Date' displays", "The current date", null);
		}
		else {
			queryObjects.logStatus(driver, Status.FAIL, "New Value column 'Modified Date' is", "Not Display the current date", null);
		}
		if(driver.findElement(By.xpath("(//div[@class='ui-grid-header-cell-wrapper'])[1]/div/div[1]/div/div/span[1]")).getText().equals("Item"))
		{
			queryObjects.logStatus(driver, Status.PASS, "In the Service Changes grid", "'Item' Column is Displayed", null);
		}
		if(driver.findElement(By.xpath("(//div[@class='ui-grid-header-cell-wrapper'])[1]/div/div[2]/div/div/span[1]")).getText().equals("Old Value"))
		{
			queryObjects.logStatus(driver, Status.PASS, "In the Service Changes grid", "'Old Value' Column is Displayed", null);
		}
		if(driver.findElement(By.xpath("(//div[@class='ui-grid-header-cell-wrapper'])[1]/div/div[3]/div/div/span[1]")).getText().equals("New Value"))
		{
			queryObjects.logStatus(driver, Status.PASS, "In the Service Changes grid", "'New Value' Column is Displayed", null);
		}
		
		if(driver.findElement(By.xpath("(//div[@class='ui-grid-canvas'])[1]/div[1]/div/div[2]/div")).getText().equals(OldRepairItem) && 
				driver.findElement(By.xpath("(//div[@class='ui-grid-canvas'])[1]/div[1]/div/div[3]/div")).getText().equals(NewRepairItem))
		{
			queryObjects.logStatus(driver, Status.PASS, "Old Repair Item Value and New Repair Item Value are ", "Displayed in the columns", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Old Repair Item Value and New Repair Item Value are", "Not Displayed in the columns", null);
		}
		RC_Global.clickButton(driver, "X", false, true);
		RC_Global.panelAction(driver, "close", "Services History", false, true);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Vehicle Service Intervals Management");
		RC_Global.clickUsingXpath(driver, "//a[text()='Services']", "Service", false, true);
		Thread.sleep(1000);
		RC_Global.clickUsingXpath(driver, "((//div[@class='ui-grid-canvas'])[2]/div[2]/div/div)[1]/div", "2nd row", false, true);
		RC_Global.clickUsingXpath(driver, "(//button[text()=' Edit '])[2]", "Edit", false, true);
		Thread.sleep(1000);
		NameInputField = driver.findElement(By.xpath("(//input[@id='name'])[1]"));
		NameInputField.clear();
		RC_Global.enterInput(driver, "Perform PM Service - Equipment", NameInputField, false, true);
		RC_Global.clickButton(driver, "Save", false, true);
		Thread.sleep(4000);
		RC_Global.panelAction(driver, "close", "Vehicle Service Intervals Management", false, true);
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
