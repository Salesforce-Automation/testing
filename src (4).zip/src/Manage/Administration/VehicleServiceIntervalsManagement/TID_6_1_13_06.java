package Manage.Administration.VehicleServiceIntervalsManagement;

import java.util.concurrent.ThreadLocalRandom;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_13_06 {
	public void VehicleSegmentIntervalsManagement_IntervalTab_EditExistingIntervals(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		boolean isSelected = false;
		String currentDate = RC_Manage.AddDateStr(0, "M/d/yy", "", null, "CST");
		String Days=ThreadLocalRandom.current().nextInt(1, 99)+"";
		String OldDays="";
		String UnitNumber="";
		RC_Global.login(driver);
		//String loggedUser = driver.findElement(By.xpath("//div[@class='bottom-nav bottom-right-menu']//div/ul[@class='nav-right list-unstyled pull-right user-menu']/li/a")).getText();
		String loggedUser = RC_Global.userLogged;
		RC_Global.navigateTo(driver, "Manage", "Administration", "Vehicle Service Intervals Management");
		RC_Global.waitElementVisible(driver, 30, "((//div[@role='row'])[2]/div/div)[1]", "1st row", false, false);
		int rows = driver.findElements(By.xpath("(//div[@class='ui-grid-canvas'])[1]/div")).size();
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		//executor.executeScript("document.body.style.zoom = '80%'");
        Thread.sleep(1000);
        executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//div/span[text()='Days']/..")));
		RC_Global.clickUsingXpath(driver, "//div/span[text()='Days']", "'Days' column sort", true, false);
		Thread.sleep(4000);
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//div/span[text()='Days']/..")));
		RC_Global.clickUsingXpath(driver, "//div/span[text()='Days']", "'Days' column sort", true, false);
		Thread.sleep(4000);
        //executor.executeScript("document.body.style.zoom = '100%'");
		executor.executeScript("document.body.style.zoom = '30%'");
		   Thread.sleep(2000);
		  executor.executeScript("document.body.style.zoom = '100%'");
		for(int i=1;i<=rows;i++)
		{
			UnitNumber = driver.findElement(By.xpath("(//div[@class='ui-grid-canvas'])[1]/div["+i+"]/div/div[5]/div/a")).getText();
			if(!UnitNumber.equals(""))
			{
				OldDays=driver.findElement(By.xpath("(//div[@class='ui-grid-canvas'])[1]/div[1]/div/div[12]/div")).getText();
				if(!OldDays.equals("")) {
					RC_Global.clickUsingXpath(driver, "((//div[@class='ui-grid-canvas'])[1]/div["+i+"]/div/div/div)[1]", "Click on row "+i, false, true);
					isSelected = true;
					break;
				}
			}
		}
		if (isSelected) {
			queryObjects.logStatus(driver, Status.INFO, "Unit Number data---->", UnitNumber, null);
			queryObjects.logStatus(driver, Status.INFO, "Old Days data---->", OldDays, null);
			RC_Global.clickUsingXpath(driver, "(//button[text()=' Edit '])[1]", "Edit", false, true);
			Thread.sleep(2000);
			executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//h5[span[contains(text(),'Vehicle Service Intervals Management')]]/i[@ng-click='closePanel()']")));
			RC_Global.panelAction(driver, "close", "Vehicle Service Intervals Management", false, true);
			RC_Global.panelAction(driver, "expand", "Vehicle Service Intervals - Edit Interval", false, true);
			WebElement DaysElement = driver.findElement(By.xpath("(//input[@id='days'])[1]"));
			RC_Global.enterInput(driver, Days, DaysElement, false, true);
			RC_Global.clickButton(driver, "Save", false,true);
			Thread.sleep(3000);
			RC_Global.waitElementVisible(driver, 90, "//h4[text()='Save Successful']", "Save Successful message", false, false);
			Thread.sleep(1000);
			RC_Global.panelAction(driver, "close", "Edit Interval", false, true);
			RC_Global.navigateTo(driver, "Manage", "Administration", "Vehicle Service Intervals Management");
			RC_Global.waitElementVisible(driver, 10, "((//div[@role='row'])[2]/div/div)[1]", "1st row", false, false);
			WebElement UnitNumberInputField = driver.findElement(By.xpath("//input[@id='unitNumber']"));
			RC_Global.enterInput(driver, UnitNumber, UnitNumberInputField, false, true);
			RC_Global.clickUsingXpath(driver, "(//button[text()='Search'])[1]", "Search", false, true);
			RC_Global.waitElementVisible(driver, 10, "((//div[@role='row'])[2]/div/div)[1]", "Search Result Grid", false, true);
			RC_Global.clickUsingXpath(driver, "((//div[@role='row'])[2]/div/div)[1]", "Searched Record", false, true);
			RC_Global.clickUsingXpath(driver, "(//button[text()=' History '])[1]", "History", false, true);
			RC_Global.panelAction(driver, "close", "Vehicle Service Intervals Management", false, true);
			RC_Global.panelAction(driver, "expand", "Service Intervals History", false, true);
			RC_Global.createNode(driver, "Validate Service Intervals History Screen");
			if(driver.findElements(By.xpath("//label[text()='From:']")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "'From:' search filter is displayed in 'Service Intervals History' screen", "", null);
			}
			if(driver.findElements(By.xpath("//label[text()='To:']")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "'To:' search filter is displayed in 'Service Intervals History' screen", "", null);
			}
			if(driver.findElements(By.xpath("//label[text()='Service']")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "'Service Name' search filter is displayed in 'Service Intervals History' screen", "", null);
			}
			if(driver.findElements(By.xpath("//label[text()='Customer Number']")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "'Customer Number' search filter is displayed in 'Service Intervals History' screen", "", null);
			}
			if(driver.findElements(By.xpath("//label[text()='Customer Name']")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "'Customer Name' search filter is displayed in 'Service Intervals History' screen", "", null);
			}
			if(driver.findElements(By.xpath("//button[text()='Search']")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "'Search' button is displayed in 'Service Intervals History' screen", "", null);
			}
			if(driver.findElements(By.xpath("//button[text()='Reset']")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "'Reset' button is displayed in 'Service Intervals History' screen", "", null);
			}
			RC_Global.clickUsingXpath(driver, "((//div[@class='ui-grid-row ng-scope'])[1]//div[@role='gridcell'])[15]/div/a", "Detalis", false, true);
			Thread.sleep(1000);
			RC_Global.createNode(driver, "Validate 'Service Interval History Details' popup screen");
			if(driver.findElements(By.xpath("(//label[text()='Customer Number'])[1]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "'Customer Number' is displayed in 'Service Intervals History Details' popup screen", "", null);
			}
			if(driver.findElements(By.xpath("(//label[text()='Customer Name'])[1]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "'Customer Name' is displayed in 'Service Intervals History Details' popup screen", "", null);
			}
			if(driver.findElements(By.xpath("(//label[text()='Unit Number'])[1]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "'Unit Number' is displayed in 'Service Intervals History Details' popup screen", "", null);
			}
			if(driver.findElements(By.xpath("(//label[text()='Year'])[1]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "'Year' is displayed in 'Service Intervals History Details' popup screen", "", null);
			}
			if(driver.findElements(By.xpath("(//label[text()='Make'])[1]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "'Make' is displayed in 'Service Intervals History Details' popup screen", "", null);
			}
			if(driver.findElements(By.xpath("(//label[text()='Model'])[1]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "'Model' is displayed in 'Service Intervals History Details' popup screen", "", null);
			}
			if(driver.findElements(By.xpath("(//label[text()='Segment'])[1]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "'Segment' is displayed in 'Service Intervals History Details' popup screen", "", null);
			}
			if(driver.findElements(By.xpath("(//label[text()='Service'])[1]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "'Service' is displayed in 'Service Intervals History Details' popup screen", "", null);
			}
			if(driver.findElements(By.xpath("(//label[text()='Miles'])[1]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "'Miles' is displayed in 'Service Intervals History Details' popup screen", "", null);
			}
			if(driver.findElements(By.xpath("(//label[text()='Days'])[1]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "'Days' is displayed in 'Service Intervals History Details' popup screen", "", null);
			}
			if(driver.findElements(By.xpath("(//label[text()='Active'])[1]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "'Active' is displayed in 'Service Intervals History Details' popup screen", "", null);
			}
			if(driver.findElements(By.xpath("(//label[text()='Created Date'])[1]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "'Created Date' is displayed in 'Service Intervals History Details' popup screen", "", null);
			}
			if(driver.findElements(By.xpath("(//label[text()='Modified By'])[1]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "'Modified By' is displayed in 'Service Intervals History Details' popup screen", "", null);
			}
			if(driver.findElements(By.xpath("(//label[text()='Modified Date'])[1]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "'Modified Date' is displayed in 'Service Intervals History Details' popup screen", "", null);
			}
			if(driver.findElement(By.xpath("(//label[text()='Modified By'])[1]//../following-sibling::div")).getText().toUpperCase().contains(loggedUser))
			{
				queryObjects.logStatus(driver, Status.PASS, "'Modified By' displays the logged user's name", loggedUser, null);
			}
			else
			{
				queryObjects.logStatus(driver, Status.FAIL, "'Modified By' does not display the logged user's name", "", null);
			}
			if(driver.findElement(By.xpath("(//label[text()='Modified Date'])[1]//../following-sibling::div")).getText().contains(currentDate))
			{
				queryObjects.logStatus(driver, Status.PASS, "'Modified Date' displays the current date", currentDate, null);
			}
			else
			{
				queryObjects.logStatus(driver, Status.FAIL, "'Modified Date' does not display the current date", "", null);
			}
			RC_Global.clickButton(driver, "X", false, true);
			RC_Global.panelAction(driver, "close", "Service Intervals History", false, true);			
			queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
		} else {
			queryObjects.logStatus(driver, Status.FAIL, "Row with Days is not selected", "", null);
		}
		RC_Global.logout(driver, false);	
	}
}
