package Manage.Administration.DashboardAdministration;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_5_07 {
	
	public void DashboardAdministrationScreenFunctionValidation (WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String[] fleetMatrices= {"Total Fleet Size","Units on Lease","Open End Leased Vehicles","Closed End Leased Vehicles","Services Only Vehicles","Units on Maintenance","Units on Fuel","Active Pool Units","Due for Replacement � Open End","Due for Replacement � Closed End"};
		String[] fleetExceptionsAndAlerts= {"Open Maintenance POs","Maintenance POs Pending Approval","Units Missing Lube/Oil/Filter Service","Plates Coming Due","Fuel Transactions Exceeding $","Fuel Transaction Exceeding Gallons","Same Day Fuel Transactions","Units with Fuel Transactions Over Tank Capacity","Drivers with Non-Sequential Odometers", "Drivers Missing E-Mail"};
		String[] fleetFacts= {"Average Price per Gallon","Average Maintenance Cost per Service","Average Maintenance Cost per Unit","Average Fuel Cost per Unit","Average # of Fuel Transactions per Unit","CPM Maintenance","CPM Fuel"}; 
		String[] graphics= {"Total Monthly Maintenance Spend","Total Monthly Fuel Spend","Total Monthly Lease Spend"};
		String[] unfleetFacts= {"CPM Maintenance","CPM Fuel"};
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		
		RC_Global.login(driver);		
		RC_Global.navigateTo(driver, "Manage", "Administration", "Dashboard Administration");
		RC_Global.validateHeaderName(driver, "Dashboard Administration", false);
		RC_Global.enterCustomerNumber(driver, "LS008737", "", "", false);
		
		// Result based on the search filters is displayed in the grid ----------> doubt
		RC_Global.clickButton(driver, "Add New", false, true);
		RC_Global.clickUsingXpath(driver, "(//*[text()='Dashboard Administration'])[2]/../i[1]", "Close Dashboard Administration", false, false);
		RC_Global.panelAction(driver, "expand", "Dashboard Administration", false, true);
		String DName = "DashboardTest"+RandomStringUtils.randomNumeric(2);
		RC_Global.enterInput(driver, DName, driver.findElement(By.xpath("//label[text()='Dashboard Name']/../input")), false, true);
		
		// Noted General Preferences under dashboard
		RC_Global.createNode(driver, "Selected Dashboard General Preferences values");
		driver.findElement(By.xpath("//label[text()='Dashboard']/../select"));
		String Dashboard = driver.findElement(By.xpath("//label[text()='Dashboard']/../select/option[@selected='selected']")).getText();
		queryObjects.logStatus(driver, Status.INFO, "'Dashboard' Field Selected value -->", Dashboard, null);
		
		String DefaultOpenUponLogin = driver.findElement(By.xpath("//div[label[text()='Default Open Upon Login']]/following-sibling::div/label[contains(@class,'active')]")).getText();
		queryObjects.logStatus(driver, Status.INFO, "'Default Open Upon Login' Field Selected value -->", DefaultOpenUponLogin, null);
		
		String DefaultDashboard = driver.findElement(By.xpath("//div[label[text()='Default Dashboard']]/following-sibling::div/label[contains(@class,'active')]")).getText();
		queryObjects.logStatus(driver, Status.INFO, "'Default Dashboard' Field Selected value -->", DefaultDashboard, null);
		
		String DashboardName = driver.findElement(By.xpath("//label[text()='Dashboard Name']/../input")).getText();
		queryObjects.logStatus(driver, Status.INFO, "'Dashboard Name' Field Selected value -->", DashboardName, null);
		
		String MarkedAsFavorite = driver.findElement(By.xpath("//div[label[text()='Marked as Favorite']]/following-sibling::div/label[contains(@class,'active')]")).getText();
		queryObjects.logStatus(driver, Status.INFO, "'Marked as Favorite' Field Selected value -->", MarkedAsFavorite, null);
		
//		RC_Global.clickButton(driver, "Save", false, true);
//		Thread.sleep(2000);
//		RC_Global.verifyDisplayedMessage(driver, "Update Successful", false);
		RC_Global.clickButton(driver, "Restore to Default", false, true);
		RC_Global.waitElementVisible(driver, 60, "//div[div/span[text()='Total Fleet Size']]/div/input[contains(@class,'ng-not-empty') and @type='checkbox']", "Total Fleet Size section", false, false);
		
		RC_Global.createNode(driver, "Validate Fleet Metrics section");
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Total Fleet Size", "Yes", "Yes", "1", false);
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Units on Lease", "Yes", "Yes", "2", false);
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Units on Maintenance", "Yes", "Yes", "3", false);
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Units on Fuel", "Yes", "Yes", "4", false);
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Total Fuel Spend", "Yes", "Yes", "5", false);
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Total Maintenance Spend", "Yes", "Yes", "6", false);
		
		RC_Global.createNode(driver, "Validate Fleet Exception and Alerts section");
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Open Maintenance POs", "Yes", "Yes", "1", false);
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Maintenance POs Pending Approval", "Yes", "Yes", "2", false);
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Plates Coming Due", "Yes", "Yes", "4", false);		
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Same Day Fuel Transactions", "Yes", "Yes", "5", false);
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Missing Plate State", "Yes", "Yes", "6", false);
		
		RC_Global.createNode(driver, "Validate Fleet Facts section");
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Average Maintenance Cost per Unit", "Yes", "Yes", "1", false);
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Average Fuel Cost per Unit", "Yes", "Yes", "2", false);
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Average # of Fuel Transactions per Unit", "Yes", "Yes", "3", false);		
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Average Fleet Age", "Yes", "Yes", "4", false);
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Average Fleet Mileage", "Yes", "Yes", "5", false);
		
		RC_Global.createNode(driver, "Validate Graphics section");
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Total Monthly Lease Spend", "Yes", "Yes", "3", false);	
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Fleet Fuel Economy", "Yes", "Yes", "1", false);
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Average Price per Gallon", "Yes", "Yes", "2", false);
		
		RC_Global.clickUsingXpath(driver, "//h3[text()='Fleet Metrics']/../div/button[text()='Reset']", "Fleet Metrics section reset button", false, true);
		
		RC_Global.createNode(driver, "Validate Fleet Metrics section - Order selection and values are cleared");	
		 if(driver.findElements(By.xpath("//div[div/span[text()='Total Fleet Size']]/div/input[contains(@class,'ng-empty') and @type='checkbox']")).size()>0)
		 {					
			 queryObjects.logStatus(driver, Status.PASS, " 'Total Fleet Size' checkbox is not selected, all Order section and values are cleared ","Succesfully" , null);
		 }
		 else {
			 queryObjects.logStatus(driver, Status.FAIL, " 'Total Fleet Size' checkbox is selected"," " , null);
		 }			
		
		 RC_Global.clickUsingXpath(driver, "//h3[text()='Fleet Exceptions and Alerts']/../div/button[text()='Reset']", "Fleet Exceptions and Alerts section reset button", false, true);
		 RC_Global.clickUsingXpath(driver, "//h3[text()='Fleet Facts']/../div/button[text()='Reset']", "Fleet Facts section reset button", false, true);
		 RC_Global.clickUsingXpath(driver, "//h3[text()='Graphics']/../div/button[text()='Reset']", "Graphics section reset button", false, true);
		 RC_Global.createNode(driver, "Select checkboxes from Fleet Metrics");
			for(int j=0;j<fleetMatrices.length;j++)
			{
				RC_Manage.selectFleetMetrices_DashboardAdminstration(driver, fleetMatrices[j], false);
			}

		RC_Global.createNode(driver, "Select checkboxes from Fleet Exceptions and Alerts");
			for(int j=0;j<fleetExceptionsAndAlerts.length;j++)
			{
				RC_Manage.selectFleetExceptionsAndAlerts_DashboardAdminstration(driver, fleetExceptionsAndAlerts[j], false);
			}

		RC_Global.createNode(driver, "Select checkboxes from Fleet Facts");
			for(int j=0;j<fleetFacts.length;j++)
			{
				RC_Manage.selectFleetFacts_DashboardAdminstration(driver, fleetFacts[j], false);
			}

		RC_Global.createNode(driver, "Select checkboxes from Graphics");
			for(int j=0;j<graphics.length;j++)
			{
				RC_Manage.selectGraphics_DashboardAdminstration(driver, graphics[j], false);
			}

		RC_Global.clickButton(driver, "Save", false, true);
		Thread.sleep(2000);
		RC_Global.verifyDisplayedMessage(driver, "You have selected more than the maximum number of items under Fleet Facts", false);
			
		RC_Global.createNode(driver, "Select checkboxes from Fleet Facts");
		for(int j=0;j<unfleetFacts.length;j++)
		{
			RC_Manage.selectFleetFacts_DashboardAdminstration(driver, unfleetFacts[j], false);
		}
		
		RC_Global.clickUsingXpath(driver, "//a[text()='Assign Dashboard']", "Assign Dashboard", false, true);
		if(driver.findElements(By.xpath("//div[div/div/p/span[text()='Fleet Manager']]//div/input[contains(@class,'ng-not-empty') and @type='checkbox' ]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.INFO, "'Fleet Manager' is already selected-->", "Successfully", null);
			RC_Global.clickUsingXpath(driver, "//div[div/div/p/span[text()='Fleet Manager']]//div/input[contains(@class,'ng-not-empty') and @type='checkbox' ]", "Uncheck Fleet Manager checkbox", false, true);
			RC_Global.clickUsingXpath(driver, "//div[div/div/p/span[text()='Fleet Manager']]/../div//a[text()='Manage']", "Manage hypelink", false, true);
		}
		else if(driver.findElements(By.xpath("//div[div/div/p/span[text()='Fleet Manager']]//div/input[contains(@class,'ng-empty') and @type='checkbox' ]")).size()>0)
		{
			RC_Global.clickUsingXpath(driver, "//div[div/div/p/span[text()='Fleet Manager']]/../div//a[text()='Manage']", "Manage hypelink", false, true);
		}
		
		try {
			RC_Global.waitElementVisible(driver, 30, "(//h4[text()='The dashboard must be saved first or select existing dashboard'])[1]", "Dashboard Error Message", true, false);
			queryObjects.logStatus(driver, Status.PASS, "Verify Error Message displays", "Error Message displays", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify Error Message displays", "Error Message doe not display", null);
		}
//		RC_Global.verifyDisplayedMessage(driver, "The dashboard must be saved first or select existing dashboard", false);
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//h5/span[text()='Dashboard Administration']")));
		RC_Global.panelAction(driver, "close", "Dashboard Administration", false, true);
		
		RC_Global.navigateTo(driver, "Manage", "Administration", "Dashboard Administration");
		List<WebElement> Gridrowcnt= driver.findElements(By.xpath("(//div[@role='rowgroup'])[2]/div/div"));
		for(int i=1; i<=Gridrowcnt.size();i++) {
		WebElement name = driver.findElement(By.xpath("//div[@role='rowgroup'][2]//div["+i+"]/div/div[2]/div//span"));	
		WebElement Deletedashb = driver.findElement(By.xpath("//div[@role='rowgroup'][2]//div["+i+"]/div/div[5]/div//img[1]"));
		String AddAlertName = name.getText();
			if(AddAlertName.equals(DName))
			{		 
				 Deletedashb.click();
				 driver.switchTo().alert().accept();				
				 break;
			}
		}

		RC_Global.logout(driver, false);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
