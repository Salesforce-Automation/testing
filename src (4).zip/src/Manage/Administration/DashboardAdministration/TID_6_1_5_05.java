package Manage.Administration.DashboardAdministration;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_5_05 {
	public static void CreatingNewDashboardForExternalUserWithRoleAsFleetManager(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Utilities", "User Setup");
		RC_Global.waitUntilPanelVisibility(driver, "User Setup", "TV", true, false);
		Thread.sleep(2000);
		RC_Global.waitElementVisible(driver, 30, "//table//tbody/tr[1]/td[1]", "Search Result", true, false);
		WebElement searchBox = driver.findElement(By.xpath("//input[@placeholder='Find User by Username']"));
		RC_Global.enterInput(driver, "cartest", searchBox, true, false);
		
		RC_Global.waitElementVisible(driver, 30, "//table//tbody/tr[1]/td[1]", "Search Result", true, false);
		RC_Global.clickUsingXpath(driver, "//table//tbody/tr[1]/td[1]", "Search Result", true, true);
		
		RC_Global.waitUntilPanelVisibility(driver, "User Detail", "TV", true, false);
		RC_Global.panelAction(driver, "close", "User Setup", true, false);
		RC_Global.panelAction(driver, "expand", "User Detail", true, false);
		
		RC_Global.selectDropdownOption(driver, "Role ", "Fleet Manager", true, true);
		boolean flag=false;
		if(driver.findElements(By.xpath("//div[@class='added-customer alert ng-hide']")).size()>0) {
			//RC_Global.clickUsingXpath(driver, "//div[@table-scroll]//table//tr[1]", "Employee Assignment", true, true);
			RC_Global.clickUsingXpath(driver, "//table//tr[1]", "Employee Assignment", true, true);
			flag=true;
		}
		String assignedName = driver.findElement(By.xpath("//div[@class='added-customer alert']/span")).getText();
		
		String firstName = assignedName.split(" ")[0];
		RC_Global.clickButton(driver, "Save", true, true);
		
		if(flag)
			driver.switchTo().alert().accept();
		
		try {
			RC_Global.waitElementVisible(driver, 30, "//h4[text()='Save Successful']", "Save Successful message", true, true);
			queryObjects.logStatus(driver, Status.PASS, "Verify Save Successful message is displayed", "Save Successful message is displayed", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.PASS, "Verify Save Successful message is displayed", "Save Successful message is not displayed", null);
		}
	
		RC_Global.panelAction(driver, "close", "User Detail", true, true);
		

		RC_Global.navigateTo(driver, "Manage", "Administration", "Dashboard Administration");
		RC_Global.waitUntilPanelVisibility(driver, "Dashboard Administration", "TV", true, false);
		
		RC_Global.waitElementVisible(driver, 30, "(//div[@role='columnheader'])[1]", "", true, false);
		Thread.sleep(2000);

		RC_Global.enterCustomerNumber(driver, "LS008255", "", "", true);
		RC_Global.clickButton(driver, "Add New", true, true);
		
		RC_Global.waitElementVisible(driver, 30, "(//h5/span[text()='Dashboard Administration'])[2]", "Second panel of Dashboard Administration", true, false);
		
		RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='Dashboard Administration']])[1]", true, false);
		RC_Global.panelAction(driver, "expand", "Dashboard Administration", true, false);
		
		if(driver.findElement(By.xpath("//div[label[text()='Default Open Upon Login']]/following-sibling::div/label[contains(@class,'disabled-active-button')]")).getText().equalsIgnoreCase("No"))
			RC_Global.clickUsingXpath(driver, "//div[label[text()='Default Open Upon Login']]/following-sibling::div/label[text()='Yes']", "Yes for 'Default Open Upon Login'", true, true);
		
		WebElement dashboardName  = driver.findElement(By.xpath("//div[label[text()='Dashboard Name']]/input"));
		String dashboardTitle = "Auto Test "+RandomStringUtils.randomNumeric(2);
		RC_Global.enterInput(driver, dashboardTitle, dashboardName, true, true);
		
		RC_Global.clickButton(driver, "Restore to Default", true, true);
		
		RC_Global.waitElementVisible(driver, 30, "//h3[text()='Fleet Metrics']", "Fleet Metrics", true, false);
		
		RC_Global.clickUsingXpath(driver, "(//button[text()=' Save'])[1]", "Save button", true, true);
		
		try {
			RC_Global.waitElementVisible(driver, 30, "(//h4[text()='Update Successful'])[1]", "Save Successful Message", true, true);
			queryObjects.logStatus(driver, Status.PASS, "Verify Update Successful message is displayed", "Update Successful message is displayed", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify Update Successful message is displayed", "Update Successful message is not displayed", null);
		}

		RC_Global.clickUsingXpath(driver, "//a[text()='Assign Dashboard']", "Assign Dashboard tab", true, false);
		
		RC_Global.waitElementVisible(driver, 30, "(//div[h3[text()='Roles']]/following-sibling::div//div[1]/div/input)[1]", "Fleet Manager checkbox", true, false);		
		Thread.sleep(2000);

		if(driver.findElement(By.xpath("(//div[h3[text()='Roles']]/following-sibling::div//div[1]/div/input)[1]")).isSelected())
			RC_Global.clickUsingXpath(driver, "(//div[h3[text()='Roles']]/following-sibling::div//div[1]/div/input)[1]", "Fleet Manager checkbox", true, false);
		
		RC_Global.clickUsingXpath(driver, "(//div[4]/div/a[text()='Manage'])[1]", "Manage link", true, false);
		
		Thread.sleep(2000);

			RC_Global.clickUsingXpath(driver, "//div[div[div[div[text()='"+firstName+"']]]]//a[text()='Opted Out']", "'Opted Out' link", true, false);
		Thread.sleep(2000);
		RC_Global.clickButton(driver, "Done", true, true);
		Thread.sleep(2000);
		
		RC_Global.clickUsingXpath(driver, "(//button[text()=' Save'])[1]", "Save button", true, true);
		
		try {
			RC_Global.waitElementVisible(driver, 30, "(//h4[text()='Update Successful'])[1]", "Save Successful Message", true, true);
			queryObjects.logStatus(driver, Status.PASS, "Verify Update Successful message is displayed", "Update Successful message is displayed", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify Update Successful message is displayed", "Update Successful message is not displayed", null);
		}

		Thread.sleep(3000);
		
		RC_Global.logout(driver, true);
		
		RC_Global.externalUserLogin(driver, "cartest", "Yes");
		
		RC_Global.clickUsingXpath(driver, "//button[@data-toggle]/i", "Dashboard Icon", true, false);
//		String dashboard = driver.findElement(By.xpath("(//div[div[normalize-space(text())='My Dashboards']]/ul/li)[1]")).getText().trim();
//		if(dashboardTitle.equalsIgnoreCase(dashboard))
//			queryObjects.logStatus(driver, Status.PASS, "Verify newly created dashboard is displayed", "Newly created dashboard is displayed", null);
//		else
//			queryObjects.logStatus(driver, Status.FAIL, "Verify newly created dashboard is displayed", "Newly created dashboard is not displayed", null);
//		
		RC_Global.navigateTo(driver, "Manage", "Administration", "Dashboard Administration");
		RC_Global.waitUntilPanelVisibility(driver, "Dashboard Administration", "TV", true, false);
		
		RC_Global.waitElementVisible(driver, 30, "(//div[@role='columnheader'])[1]", "", true, false);
		Thread.sleep(2000);
		
		RC_Global.clickUsingXpath(driver, "//div[div[p[span[text()='"+dashboardTitle+"']]]]/following-sibling::div/div/img[@title='Edit']", "Edit", true, false);
		RC_Global.waitElementVisible(driver, 30, "(//h5[span[text()='Dashboard Administration']])[2]", "Dashboard Administration", true, false);
		
		RC_Global.clickButton(driver, " Delete ", true, true);
		
		RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='Dashboard Administration']])[2]", true, false);
		RC_Global.panelAction(driver, "expand", "Dashboard Administration", true, false);
		
		driver.findElement(By.xpath("//div[div[p[span[text()='"+dashboardTitle+"']]]]/following-sibling::div//div/img[@title='Delete']")).click();
		driver.switchTo().alert().accept();
		
		RC_Global.panelAction(driver, "close", "Dashboard Administration", true, true);
		RC_Global.logout(driver, true);
		
	}

}
