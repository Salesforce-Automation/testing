package Manage.Administration.DashboardAdministration;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_5_12 {

	public void DashboardGroup_4(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		
		String custNo="LS008737"; int count=0; String dName="DashboardGroup_4";
		String[] graphics= {"Fleet Fuel Economy","Active Units","Units on Lease"};
		String[] fleetExceptionsAndAlerts= {"Open Maintenance POs"};
		
		
		RC_Global.login(driver);
		RC_Global.enterCustomerFocus(driver, custNo, false);
		if(driver.findElements(By.xpath("(//span[text()='Fleet Metrics'])[1]")).size()>0)
			RC_Global.clickUsingXpath(driver, "//li[@class='dashboard-icon'][1]/button/i", "Dashboard Icon", false, false);
		RC_Global.clickUsingXpath(driver, "((//li[@class='dashboard-icon'])[1]/following-sibling::li/button/i)[1]", "Dashboard Lists", false, false);

		int dCount=driver.findElements(By.xpath("//*[text()=' My Dashboards ']/../ul/li")).size();
		for(int i=1;i<=dCount;i++)
		{
			String listDName=driver.findElement(By.xpath("//*[text()=' My Dashboards ']/../ul/li["+i+"]")).getText();
			if(listDName.contains(dName))
			{
				count=1;
				RC_Global.clickUsingXpath(driver, "//*[text()=' My Dashboards ']/../ul/li["+i+"]", "DashboardGroup_4", false, true);
				break;
			}
		}
		if(count==0)
		{
			//DashboardGroup4 if it's not created
		RC_Global.navigateTo(driver, "Manage", "Administration", "Dashboard Administration");
		RC_Global.validateHeaderName(driver, "Dashboard Administration", false);
		RC_Global.clickButton(driver, "Add New", false, true);
		RC_Global.clickUsingXpath(driver, "(//*[text()='Dashboard Administration'])[2]/../i[1]", "Close Dashboard Administration", false, false);
		RC_Global.panelAction(driver, "expand", "Dashboard Administration", false, true);
		
		Select dashboardDropDown=new Select(driver.findElement(By.xpath("//label[text()='Dashboard']/following-sibling::select")));
		if(dashboardDropDown.getFirstSelectedOption().getText().contains("Default"))
		{
			dashboardDropDown.selectByIndex(0); 
		}
		WebElement dNameField = driver.findElement(By.xpath("//*[text()='Dashboard Name']/following-sibling::input"));
		RC_Global.enterInput(driver, dName, dNameField, false, true);
		//
		for(int j=0;j<fleetExceptionsAndAlerts.length;j++)
		{
			RC_Manage.selectFleetExceptionsAndAlertsDashboardAdminstration(driver, fleetExceptionsAndAlerts[j], false);
		}
		//
		RC_Global.createNode(driver, "Select checkboxes from Graphics and Maps");
		//Graphics
		for(int i=0;i<graphics.length;i++)
		{
			RC_Manage.selectGraphicsDashboardAdminstration(driver, graphics[i], false);
		}
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//span[text()='Dashboard Administration'])[2]")));
		RC_Global.clickUsingXpath(driver, "(//button[text()=' Save'])[1]", "Save", false, true);
		Thread.sleep(6000);
		if(driver.findElements(By.xpath("(//*[text()='Update Successful'])[3]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Update Successful message is displayed", "", null);
		}
		RC_Global.panelAction(driver, "close", "Dashboard Administration", false, true);
		Thread.sleep(3000);
			WebElement boardData = driver.findElement(By.xpath("(//span[text()='Fleet Metrics'])[1]"));
			if (!(boardData.isDisplayed())) {
				RC_Global.clickUsingXpath(driver, "//li[contains(@class,'dropdown dashboard-icon')]/button/i", "Dashboard Dropdown Icon", false,false);
				RC_Global.clickUsingXpath(driver, "//div[div[(text()= ' My Dashboards ')]]//li[contains(., 'Group_4')]", "Select from Dashboard Lists", false, false);
				RC_Global.waitElementVisible(driver, 90, "//span[text()='Open Maintenance POs']", "Dashboard data's are displayed in the main page", false, true);				
			}
		dCount=driver.findElements(By.xpath("//*[text()=' My Dashboards ']/../ul/li")).size();
		
		}
		//Fleet Fuel Economy
		RC_Global.waitElementVisible(driver, 30, "//span[text()='Fleet Fuel Economy']/../..//div[@class='highcharts-container']//*[name()='g']/*[name()='path' and contains(@fill,'953735')]", "Dashboard_4", true, false);
		RC_Global.clickUsingXpath(driver, "//span[text()='Fleet Fuel Economy']/../..//div[@class='highcharts-container']//*[name()='g']/*[name()='path' and contains(@fill,'953735')]", "Fleet Fuel Economy", false, false);
		if(driver.findElements(By.xpath("(//h5)[2]/span[1]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, driver.findElement(By.xpath("(//h5)[2]/span[1]")).getText()+" screen is opened for", "Fleet Fuel Economy", null);
		}
	    RC_Global.verifyColumnNames(driver, "Timeframe;Average MPG;High MPG;Low MPG;Vehicle Count", false);
	    RC_Global.waitElementVisible(driver, 60, "//tbody//tr[1]//td[1]", "Fuel Summary Grid results", false, true);
	    RC_Global.clickUsingXpath(driver, "//tr[1]/td[2]/span/a", "Average MPG", false, true);
	    RC_Global.validateHeaderName(driver, "Fuel Summary By Vehicle (E)", false);
	    RC_Global.panelAction(driver, "close", "Fuel Summary By Vehicle (E)", false, true);
	    RC_Global.panelAction(driver, "expand", driver.findElement(By.xpath("(//h5)[2]/span[1]")).getText(), false, false);
	    
	    RC_Global.clickUsingXpath(driver, "//tr[1]/td[3]/span/a", "High MPG", false, true);
//	    RC_Global.validateHeaderName(driver, "Fuel Transaction Detail (E)", false);
//	    RC_Global.panelAction(driver, "close", "Fuel Transaction Detail (E)", false, true);
	    RC_Global.validateHeaderName(driver, "Fuel Summary By Vehicle", false);
	    RC_Global.panelAction(driver, "close", "Fuel Summary By Vehicle", false, true);
	    RC_Global.panelAction(driver, "expand", driver.findElement(By.xpath("(//h5)[2]/span[1]")).getText(), false, false);
	    
	    RC_Global.clickUsingXpath(driver, "//tr[1]/td[4]/span/a", "Low MPG", false, true);
//	    RC_Global.validateHeaderName(driver, "Fuel Transaction Detail (E)", false);
//	    RC_Global.panelAction(driver, "close", "Fuel Transaction Detail (E)", false, true);
	    RC_Global.validateHeaderName(driver, "Fuel Summary By Vehicle", false);
	    RC_Global.panelAction(driver, "close", "Fuel Summary By Vehicle", false, true);
	    RC_Global.panelAction(driver, "close", driver.findElement(By.xpath("(//h5)[2]/span[1]")).getText(), false, false);
	    
	    //Active Units
	    String map = driver.findElement(By.xpath("//span[text()='Active Units']/../..//div[@class='highcharts-container']//*[name()='g']/*[name()='text']/*[name()='tspan']")).getText();
	    char ch = map.charAt(0);
	    if(Character.isDigit(ch))  {
	    	RC_Global.clickUsingXpath(driver, "//span[text()='Active Units']/../..//div[@class='highcharts-container']//*[name()='g']/*[name()='text']/*[name()='tspan']", "Active Units", false, true);
          }
	    RC_Global.validateHeaderName(driver, "Active Units", false);
	    RC_Global.verifyColumnNames(driver, "County;Vehicle Count", false);
	    RC_Global.waitElementVisible(driver, 60, "//tbody//tr[1]//td[1]", "List Of Fleet Grid results", false, true);
	    RC_Global.clickUsingXpath(driver, "//tr[1]/td[2]/span/a", "Vehicle Count", false, true);
	    RC_Global.validateHeaderName(driver, "List Of Fleet (E)", false);
	    RC_Global.panelAction(driver, "close", "List Of Fleet (E)", false, true);
	    
	    RC_Global.panelAction(driver, "expand", "Active Units", false, true);
	    String vehicleno = driver.findElement(By.xpath("//tr[1]/td[2]/span/a")).getText();
	    Thread.sleep(2000);
	    int vehicleCount=Integer.parseInt(vehicleno);  
	    RC_Global.clickUsingXpath(driver, "//tr[1]/td[1]/span/a", "County", false, true);
	    RC_Global.waitElementVisible(driver, 60, "//table//tbody//tr[1]", "", false, false);
	    List<WebElement> countyCount= driver.findElements(By.xpath("//table//tbody//tr"));		
	    Thread.sleep(3000);
        int rowcount=countyCount.size();
        
        if (vehicleCount == rowcount) {
        	queryObjects.logStatus(driver, Status.PASS, "Vehicle Count Value is", "Similar To Number of Record In The Grid\"", null);
        }
        else {queryObjects.logStatus(driver, Status.FAIL, "Vehicle Count Value is", "Not Similar To Number of Record In The Grid", null);}
        RC_Global.verifyColumnNames(driver, "Unit #;CVN;Vehicle Status;Current Odometer", false);
        RC_Global.clickButton(driver, "Show State Data", true, false);
        RC_Global.panelAction(driver, "close", driver.findElement(By.xpath("(//h5)[2]/span[1]")).getText(), false, false);
        
        //Units On Lease
        String map1 = driver.findElement(By.xpath("//span[text()='Units on Lease']/../..//div[@class='highcharts-container']//*[name()='g']/*[name()='text']/*[name()='tspan']")).getText();
	    char ch1 = map1.charAt(0);
	    if(Character.isDigit(ch1))  {
	    	RC_Global.clickUsingXpath(driver, "//span[text()='Units on Lease']/../..//div[@class='highcharts-container']//*[name()='g']/*[name()='text']/*[name()='tspan']", "Active Units", false, true);
          }
	    RC_Global.validateHeaderName(driver, "Units on Lease", false);
	    RC_Global.verifyColumnNames(driver, "County;Vehicle Count", false);
	    RC_Global.waitElementVisible(driver, 60, "//tbody//tr[1]//td[1]", "List Of Fleet Grid results", false, true);
	    RC_Global.clickUsingXpath(driver, "//tr[1]/td[2]/span/a", "Vehicle Count", false, true);
	    RC_Global.validateHeaderName(driver, "List Of Fleet (E)", false);
	    RC_Global.panelAction(driver, "close", "List Of Fleet (E)", false, true);
        
	    RC_Global.panelAction(driver, "expand", "Units on Lease", false, true);
	    String vehicleno1 = driver.findElement(By.xpath("//tr[1]/td[2]/span/a")).getText();
	    Thread.sleep(3000);
	    int vehicleCount1=Integer.parseInt(vehicleno1);  
	    RC_Global.clickUsingXpath(driver, "//tr[1]/td[1]/span/a", "County", false, true);
	    RC_Global.waitElementVisible(driver, 90, "//table//tbody//tr[1]", "", false, false);
	    List<WebElement> countyCount1= driver.findElements(By.xpath("//table//tbody//tr"));	
	    Thread.sleep(2000);
        int rowcount1=countyCount1.size();
        if (vehicleCount1 == rowcount1) {
        	queryObjects.logStatus(driver, Status.PASS, "Vehicle Count Value is", "Similar To Number of Record In The Grid", null);
        }
        else {queryObjects.logStatus(driver, Status.FAIL, "Vehicle Count Value is", "Not Similar To Number of Record In The Grid", null);}
        RC_Global.verifyColumnNames(driver, "Unit #;CVN;Vehicle Status;Lease Agreement Type;Current Odometer", false);
        RC_Global.clickButton(driver, "Show State Data", true, false);
        RC_Global.panelAction(driver, "close", driver.findElement(By.xpath("(//h5)[2]/span[1]")).getText(), false, false);
		 
        /*revert changes
		RC_Global.navigateTo(driver, "Manage", "Administration", "Dashboard Administration");
		RC_Global.validateHeaderName(driver, "Dashboard Administration", false);
		// Delete Dashboard
		List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("(//div[@role='rowgroup'])[2]/div/div"));  
		int rowcnt=Getgridrowcnt.size();
		for(int i=1; i<=rowcnt;i++) {
			WebElement name = driver.findElement(By.xpath("//div[@role='rowgroup'][2]//div["+i+"]/div/div[2]/div"));
			String AddAlertName = name.getText();
			if(!AddAlertName.isEmpty()) {
				WebElement dashbDelete = driver.findElement(By.xpath("//div[@role='rowgroup'][2]//div["+i+"]/div/div[5]/div//img[1]"));
				if((AddAlertName.contains(dName))) {
				Thread.sleep(4000);
				dashbDelete.click();
				driver.switchTo().alert().accept();
				break;}
			}
		}*/
		Thread.sleep(2000);
		
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
