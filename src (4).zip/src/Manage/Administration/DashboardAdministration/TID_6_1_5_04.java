package Manage.Administration.DashboardAdministration;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_5_04 {
	public void DashboardAdministration_AssignDashboardResultGridValidation_ExternalUser(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		String columnNames = "Eligible;Role;Count;Recipient";
		
		RC_Global.externalUserLogin(driver, "kentuckytest2", "Yes");
		RC_Global.navigateTo(driver, "Manage", "Administration", "Dashboard Administration");
		RC_Global.waitUntilPanelVisibility(driver, "Dashboard Administration", "TV", true, false);
		RC_Global.clickButton(driver, "Add New", true, false);
		RC_Global.waitElementVisible(driver, 30, "(//h5/span[text()='Dashboard Administration'])[2]", "Second panel of Dashboard Administration", true, false);
		
		RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='Dashboard Administration']])[1]", true, false);
		RC_Global.panelAction(driver, "expand", "Dashboard Administration", true, false);
		
		RC_Global.clickUsingXpath(driver, "//a[text()='Assign Dashboard']", "Assign Dashboard tab", true, false);
		RC_Global.waitElementVisible(driver, 30, "//div/span[normalize-space(text())='Eligible']", "Assign Dashboard grid", true, false);
//		RC_Global.verifyColumnNames(driver, columnNames, true);
		
		String [] expColName = columnNames.split(";");

		for(int i=0; i<expColName.length; i++) {
			try {
				driver.findElement(By.xpath("//div/span[normalize-space(text())='"+expColName[i]+"']"));				
			}
			catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Validate Report Column Names--->Column: " + expColName[i] + "--->Was NOT Found", e.getLocalizedMessage(), e);
			}
		}
		
		List<WebElement> role = driver.findElements(By.xpath("//div/div/div[2]/div/p/span"));
		if(role.get(0).getText().equalsIgnoreCase("Fleet Manager"))
			queryObjects.logStatus(driver, Status.PASS, "Verify Role column has Fleet Number", "Role column has Fleet Number", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Role column has Fleet Number", "Role column does have Fleet Number", null);
	
		if(role.get(1).getText().equalsIgnoreCase("Admin"))
			queryObjects.logStatus(driver, Status.PASS, "Verify Role column has Admin", "Role column has Admin", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Role column has Admin", "Role column does have Admin", null);
	
		if(driver.findElements(By.xpath("//div[4]/div/a[text()='Manage']")).size()==2)
			queryObjects.logStatus(driver, Status.PASS, "Verify Recipient column has Manage link", "Recipient column has Manage link", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Recipient column has Manage link", "Recipient column does not have Manage link", null);
	
		RC_Global.clickUsingXpath(driver, "(//div[4]/div/a[text()='Manage'])[1]", "Manage link", true, false);
		
		try {
			RC_Global.waitElementVisible(driver, 30, "(//h4[text()='The dashboard must be saved first or select existing dashboard'])[1]", "Error Message", true, true);
			queryObjects.logStatus(driver, Status.PASS, "Verify error message is displayed", "Error message is displayed", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify error message is displayed", "Error message is not displayed", null);
		}
		
		RC_Global.clickUsingXpath(driver, "//a[text()='Select Options']", "Select Options tab", true, false);
		WebElement dashboardName  = driver.findElement(By.xpath("//div[label[text()='Dashboard Name']]/input"));
		RC_Global.enterInput(driver, "Default_Sample"+RandomStringUtils.randomNumeric(2), dashboardName, true, false);
		
		RC_Global.clickButton(driver, "Restore to Default", true, true);
		
		RC_Global.waitElementVisible(driver, 30, "//h3[text()='Fleet Metrics']", "Fleet Metrics", true, false);
		
		RC_Global.clickUsingXpath(driver, "(//button[text()=' Save'])[1]", "Save button", true, true);
		
		try {
			RC_Global.waitElementVisible(driver, 30, "(//h4[text()='Update Successful'])[1]", "Save Successful Message", true, true);
			queryObjects.logStatus(driver, Status.PASS, "Verify Update Successful message is displayed", "Update Successful message is displayed", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify Update Successful message is displayed", "Update Successful message is not displayed", null);
		}

		RC_Global.clickUsingXpath(driver, "//a[text()='Assign Dashboard']", "Assign Dashboard tab", true, false);
		
		RC_Global.clickUsingXpath(driver, "(//div[4]/div/a[text()='Manage'])[1]", "Manage link", true, false);
		RC_Global.clickUsingXpath(driver, "(//a[text()='Opted Out'])[1]", "'Opted Out' link", true, false);
		
		RC_Global.clickButton(driver, "Done", true, true);
		
		RC_Global.clickUsingXpath(driver, "(//button[text()=' Save'])[1]", "Save button", true, true);
		
		try {
			RC_Global.waitElementVisible(driver, 30, "(//h4[text()='Update Successful'])[1]", "Save Successful Message", true, true);
			queryObjects.logStatus(driver, Status.PASS, "Verify Update Successful message is displayed", "Update Successful message is displayed", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify Update Successful message is displayed", "Update Successful message is not displayed", null);
		}

		Thread.sleep(3000);
		
		RC_Global.clickUsingXpath(driver, "(//div[4]/div/a[text()='Manage'])[1]", "Manage link", true, false);
		RC_Global.clickUsingXpath(driver, "(//a[text()='Opted In'])[1]", "'Opted In' link", true, false);
		
		RC_Global.clickButton(driver, "Done", true, true);
				
		RC_Global.clickButton(driver, "Delete", true, true);
		
		try {
			RC_Global.waitElementVisible(driver, 30, "(//h4[text()='Update Successful'])[1]", "Save Successful Message", true, true);
			queryObjects.logStatus(driver, Status.PASS, "Verify Update Successful message is displayed", "Update Successful message is displayed", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify Update Successful message is displayed", "Update Successful message is not displayed", null);
		}

		RC_Global.logout(driver, false);
		
	}
}
