package Manage.Administration.DashboardAdministration;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_5_01 {
	public void  Dashboard_SelectMultipleLevelsOfStructure_CustomerFocus (WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		String DAshboardName ="";
		RC_Global.login(driver);
		RC_Global.enterCustomerFocus(driver, "LS008742", true);
		RC_Global.navigateTo(driver,"Manage","Administration","Dashboard Administration");
		RC_Global.clickButton(driver, "Add New", true, true);
		RC_Global.waitElementVisible(driver, 30, "(//h5//span[text()='Dashboard Administration'])[2]", "Dashboard Administration Page", true, true);
		RC_Global.clickUsingXpath(driver, "((//h5//span[text()='Dashboard Administration'])[1]/following::i[@ng-click='closePanel()'])[1]", "", true, false);
		RC_Global.panelAction(driver, "expand", "Dashboard Administration", true, false);
		RC_Global.clickButton(driver, "Restore to Default", true, true);
		driver.findElement(By.xpath("//input[@ng-model='userDashboard.DashboardName']")).clear();
		DAshboardName = "DashboardTest"+RandomStringUtils.randomNumeric(2);
		RC_Global.enterInput(driver, DAshboardName, driver.findElement(By.xpath("//input[@ng-model='userDashboard.DashboardName']")), true,	true);
		RC_Global.clickUsingXpath(driver, "(//button[text()=' Save'])[1]", "Save", true, true);
		RC_Global.waitElementVisible(driver, 30, "//div[@ng-show='updateSuccessful && topSave']", "Update Successfull", true, false);
		List<WebElement> SuccMessage = driver.findElements(By.xpath("//div[@ng-show='updateSuccessful && topSave']"));
		if(SuccMessage.size()>0)  
			BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Successfull Message", "Update Successfull message is displayed", null);
		else {
            BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Successfull Message", "Update Successfull message failed to display", null);
            RC_Global.endTestRun(driver);}
		RC_Global.panelAction(driver, "close", "Dashboard Administration", true, false);
		RC_Global.clickUsingXpath(driver, "//button[@data-toggle='dropdown']", "", true, false);
		RC_Global.clickUsingXpath(driver, "//ul//li[normalize-space(text())='"+DAshboardName+"']", DAshboardName+"", true, false);
		Thread.sleep(2000);
		if (driver.findElements(By.xpath("//div[@class='dashboard-desktop ng-scope ng-hide']")).size()>0) {
			RC_Global.clickUsingXpath(driver, "//button[@data-toggle='dropdown']", "", true, false);
			RC_Global.clickUsingXpath(driver, "//ul//li[normalize-space(text())='"+DAshboardName+"']", DAshboardName+"", true, false);
		}
		RC_Global.waitElementVisible(driver, 60, "//div[@class='dashboard-section-header']//span[text()='Fleet Metrics']", "Dashboard ", true, true);
		String FleetSize = driver.findElement(By.xpath("//span[text()='Total Fleet Size']/following::a[1]//span[contains(@ng-bind,'number : decimals')]")).getText();
		String UnitsOnLease = driver.findElement(By.xpath("//span[text()='Units on Lease']/following::a[1]//span[contains(@ng-bind,'number : decimals')]")).getText();
		RC_Global.clickUsingXpath(driver, "//a[@ng-click='vm.toggleMultiSelectCustomerFocus()']", "", true, false);
		RC_Global.clickUsingXpath(driver, "//button[@ng-click='vm.toggleHierarchy($event)']", "", true, false);
		RC_Global.clickUsingXpath(driver, "//i[@ng-click='selectNodeHead(node)']", "", true, false);
		RC_Global.clickUsingXpath(driver, "//i[@ng-click='selectNodeHead(node)']//following::input[1]", "", true, false);
		RC_Global.clickUsingXpath(driver, "(//i[@ng-click='selectNodeHead(node)']//following::input)[5]", "", true, false);
		RC_Global.clickButton(driver, "Apply", true, true);
		
		String FleetSizeFleetLevel = driver.findElement(By.xpath("//span[text()='Total Fleet Size']/following::a[1]//span[contains(@ng-bind,'number : decimals')]")).getText();
		String UnitsOnLeaseFleetLevel = driver.findElement(By.xpath("//span[text()='Units on Lease']/following::a[1]//span[contains(@ng-bind,'number : decimals')]")).getText();
		
		if(!(FleetSize.equalsIgnoreCase(FleetSizeFleetLevel) && UnitsOnLease.equalsIgnoreCase(UnitsOnLeaseFleetLevel)))
			BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Dashboard Data", "Dashboard Data value displayes differ from customer level to fleet level", null);
		else {
            BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Dashboard Data", "Dashboard Data value displayes doesn't differ from customer level to fleet level", null);
            RC_Global.endTestRun(driver);}
		
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Metrics", "Total Fleet Size", "List Of Fleet", "", false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Metrics", "Units on Lease", "Units On Lease", "", false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Metrics", "Units on Maintenance", "Units On Maintenance", "", false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Metrics", "Units on Fuel", "Units On Fuel", "", false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Metrics", "Total Fuel Spend", "Fuel Summary By Vehicle", "", false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Metrics", "Total Maintenance Spend", "Maintenance History Summary", "", false);

		
		RC_Global.navigateTo(driver, "Manage", "Administration", "Dashboard Administration");
		RC_Global.validateHeaderName(driver, "Dashboard Administration", false);
		// Delete Dashboard
		List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("(//div[@role='rowgroup'])[2]/div/div"));  
		int rowcnt=Getgridrowcnt.size();
		for(int i=1; i<=rowcnt;i++) {
			WebElement name = driver.findElement(By.xpath("//div[@role='rowgroup'][2]//div["+i+"]/div/div[2]/div"));
			String AddDashbName = name.getText();
			if(!AddDashbName.isEmpty()) {
				WebElement dashbDelete = driver.findElement(By.xpath("//div[@role='rowgroup'][2]//div["+i+"]/div/div[5]/div//img[1]"));
				if((AddDashbName.contains(DAshboardName))) {
				Thread.sleep(4000);
				dashbDelete.click();
				driver.switchTo().alert().accept();
				break;}
			}
		}
		RC_Global.panelAction(driver, "close", "Dashboard Administration", true, false);
		
		RC_Global.logout(driver, true);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
		
		
	}
}
