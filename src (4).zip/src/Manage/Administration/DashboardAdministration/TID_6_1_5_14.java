package Manage.Administration.DashboardAdministration;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_5_14 {
	
	public void DashboardGroup_6(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{ 
		
		String custNo="LS008742"; int count=0; String dName="DashboardGroup_6";
		String[] graphics= {"Missing Plate State","Coming Due for Replacement - Closed End","Average Price per Gallon"};
		String[] fleetExceptionsAndAlerts= {"Open Maintenance POs"};
		
		
		RC_Global.login(driver);
		RC_Global.enterCustomerFocus(driver, custNo, false);
		if(driver.findElements(By.xpath("(//span[text()='Fleet Metrics'])[1]")).size()>0)
			RC_Global.clickUsingXpath(driver, "//li[@class='dashboard-icon'][1]/button/i", "Dashboard Icon", false, false);
		RC_Global.clickUsingXpath(driver, "((//li[@class='dashboard-icon'])[1]/following-sibling::li/button/i)[1]", "Dashboard Lists", false, false);

		int dCount=driver.findElements(By.xpath("//*[text()=' My Dashboards ']/../ul/li")).size();
		for(int i=1;i<=dCount;i++)
		{
			String listDName=driver.findElement(By.xpath("//*[text()=' My Dashboards ']/../ul/li["+i+"]")).getText();
			if(listDName.contains(dName))
			{
				count=1;
			RC_Global.clickUsingXpath(driver, "//*[text()=' My Dashboards ']/../ul/li["+i+"]", "DashboardGroup_6", false, true);
				break;
			}
		}
		if(count==0)
		{
			//DashboardGroup4 if it's not created
		RC_Global.navigateTo(driver, "Manage", "Administration", "Dashboard Administration");
		RC_Global.validateHeaderName(driver, "Dashboard Administration", false);
		RC_Global.clickButton(driver, "Add New", false, true);
		RC_Global.clickUsingXpath(driver, "(//*[text()='Dashboard Administration'])[2]/../i[1]", "Close Dashboard Administration", false, false);
		RC_Global.panelAction(driver, "expand", "Dashboard Administration", false, true);
		
		Select dashboardDropDown=new Select(driver.findElement(By.xpath("//label[text()='Dashboard']/following-sibling::select")));
		if(dashboardDropDown.getFirstSelectedOption().getText().contains("Default"))
		{
			dashboardDropDown.selectByIndex(0); 
		}
		WebElement dNameField = driver.findElement(By.xpath("//*[text()='Dashboard Name']/following-sibling::input"));
		RC_Global.enterInput(driver, dName, dNameField, false, true);
		//
		for(int j=0;j<fleetExceptionsAndAlerts.length;j++)
		{
			RC_Manage.selectFleetExceptionsAndAlertsDashboardAdminstration(driver, fleetExceptionsAndAlerts[j], false);
		}
		//
		RC_Global.createNode(driver, "Select checkboxes from Maps");
		//Graphics
		for(int i=0;i<graphics.length;i++)
		{
			RC_Manage.selectGraphicsDashboardAdminstration(driver, graphics[i], false);
		}
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//span[text()='Dashboard Administration'])[2]")));
		RC_Global.clickUsingXpath(driver, "(//button[text()=' Save'])[1]", "Save", false, true);
		Thread.sleep(6000);
		if(driver.findElements(By.xpath("(//*[text()='Update Successful'])[3]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Update Successful message is displayed", "", null);
		}
		RC_Global.panelAction(driver, "close", "Dashboard Administration", false, true);
		Thread.sleep(3000);
		WebElement boardData = driver.findElement(By.xpath("(//span[text()='Fleet Metrics'])[1]"));
		if (!(boardData.isDisplayed())) {
			RC_Global.clickUsingXpath(driver, "//li[contains(@class,'dropdown dashboard-icon')]/button/i", "Dashboard Dropdown Icon", false,false);
			RC_Global.clickUsingXpath(driver, "//div[div[(text()= ' My Dashboards ')]]//li[contains(., 'Group_6')]", "Select from Dashboard Lists", false, false);
			RC_Global.waitElementVisible(driver, 90, "//span[text()='Open Maintenance POs']", "Dashboard data's are displayed in the main page", false, true);			
		}
		dCount=driver.findElements(By.xpath("//*[text()=' My Dashboards ']/../ul/li")).size();
		Thread.sleep(4000);
		}
	
		Thread.sleep(4000);
		//Missing Plate State
		 String map = driver.findElement(By.xpath("//span[text()='Missing Plate State']/../..//div[@class='highcharts-container']//*[name()='g']/*[name()='text']/*[name()='tspan']")).getText();
		    char ch = map.charAt(0);
		    if(Character.isDigit(ch))  {
		    	RC_Global.clickUsingXpath(driver, "//span[text()='Missing Plate State']/../..//div[@class='highcharts-container']//*[name()='g']/*[name()='text']/*[name()='tspan']", "Missing Plate State", false, true);
	          }
		    RC_Global.validateHeaderName(driver, "Missing Plate State", false);
		    RC_Global.waitElementVisible(driver, 60, "//tbody//tr[1]//td[1]", "Missing Plate State Grid results", false, true);
		    RC_Global.verifyColumnNames(driver, "County;Vehicle Count", false);
		    RC_Global.clickUsingXpath(driver, "//tr[1]/td[2]/span/a", "Vehicle Count", false, true);
		    RC_Global.validateHeaderName(driver, "Missing Plate/State (E)", false);
		    RC_Global.panelAction(driver, "close", "Missing Plate/State (E)", false, true);
		    
		    RC_Global.panelAction(driver, "expand", "Missing Plate State", false, true);
		    Thread.sleep(3000);
		    String vehicleno = driver.findElement(By.xpath("//tr[1]/td[2]/span/a")).getText();
		    int vehicleCount=Integer.parseInt(vehicleno);  
		    RC_Global.clickUsingXpath(driver, "//tr[1]/td[1]/span/a", "County", false, true);
		    List<WebElement> countyCount= driver.findElements(By.xpath("//table//tbody//tr"));				
	        int rowcount=countyCount.size();
	        if (vehicleCount == rowcount) {
	        	queryObjects.logStatus(driver, Status.PASS, "Vehicle Count Value is", "Similar To Number of Record In The Grid", null);
	        }
	        else {queryObjects.logStatus(driver, Status.FAIL, "Vehicle Count Value is", "Not Similar To Number of Record In The Grid", null);}
	        RC_Global.verifyColumnNames(driver, "Unit #;CVN;Vehicle Status;Current Odometer", false);
	        RC_Global.clickButton(driver, "Show State Data", true, false);
	        RC_Global.panelAction(driver, "close", driver.findElement(By.xpath("(//h5)[2]/span[1]")).getText(), false, false);
	        
		//Coming Due for Replacement - Closed End
	        String map1 = driver.findElement(By.xpath("//span[text()='Coming Due for Replacement - Closed End']/../..//div[@class='highcharts-container']//*[name()='g']/*[name()='text']/*[name()='tspan']")).getText();
		    char ch1 = map1.charAt(0);
		    if(Character.isDigit(ch1))  {
		    	RC_Global.clickUsingXpath(driver, "//span[text()='Coming Due for Replacement - Closed End']/../..//div[@class='highcharts-container']//*[name()='g']/*[name()='text']/*[name()='tspan']", "Coming Due for Replacement - Closed End", false, true);
	          }
		    RC_Global.validateHeaderName(driver, "Coming Due for Replacement - Closed End", false);
		    RC_Global.waitElementVisible(driver, 60, "//tbody//tr[1]//td[1]", "Coming Due for Replacement - Closed End Grid results", false, true);
		    RC_Global.verifyColumnNames(driver, "County;Vehicle Count", false);
		    RC_Global.clickUsingXpath(driver, "//tr[1]/td[2]/span/a", "Vehicle Count", false, true);
		    RC_Global.validateHeaderName(driver, "List Of Fleet (E)", false);
		    RC_Global.panelAction(driver, "close", "List Of Fleet (E)", false, true);
		    
		    RC_Global.panelAction(driver, "expand", "Coming Due for Replacement - Closed End", false, true);
		    String vehicleno1 = driver.findElement(By.xpath("//tr[1]/td[2]/span/a")).getText();
		    int vehicleCount1=Integer.parseInt(vehicleno1);  
		    RC_Global.clickUsingXpath(driver, "//tr[1]/td[1]/span/a", "County", false, true);
		    List<WebElement> countyCount1= driver.findElements(By.xpath("//table//tbody//tr"));				
	        int rowcount1=countyCount1.size();
	        if (vehicleCount1 == rowcount1) {
	        	queryObjects.logStatus(driver, Status.PASS, "Vehicle Count Value is", "Similar To Number of Record In The Grid", null);
	        }
	        else {queryObjects.logStatus(driver, Status.FAIL, "Vehicle Count Value is", "Not Similar To Number of Record In The Grid", null);}
	        RC_Global.verifyColumnNames(driver, "Unit #;CVN;Vehicle Status;Current Odometer;Expected End Date;Days Coming Due", false);
	        RC_Global.clickButton(driver, "Show State Data", true, false);
	        RC_Global.panelAction(driver, "close", driver.findElement(By.xpath("(//h5)[2]/span[1]")).getText(), false, false);
	        
		//Average Price per Gallon
	        List<WebElement> map2 = driver.findElements(By.xpath("//span[text()='Average Price per Gallon']/../..//div[@class='highcharts-container']//*[name()='g']/*[name()='text']/*[name()='tspan']"));
	        int dolDatacount=map2.size();
	        for(int i=1; i<=dolDatacount;i++) {
				WebElement gallon = driver.findElement(By.xpath("(//span[text()='Average Price per Gallon']/../..//div[@class='highcharts-container']//*[name()='g']/*[name()='text']/*[name()='tspan'])["+i+"]"));
				String gallonPrice = gallon.getText();
				if(gallonPrice.startsWith("$")) {
					gallon.click();
		    	break;
				}
	          }
		    RC_Global.validateHeaderName(driver, "Average Price per Gallon", false);
		    RC_Global.waitElementVisible(driver, 60, "//tbody//tr[1]//td[1]", "Average Price per Gallon Grid results", false, true);
		    RC_Global.verifyColumnNames(driver, "County;Average PPG;High PPG;Low PPG;Transaction Count;Vehicle Count", false);
		    RC_Global.clickUsingXpath(driver, "//tr[1]/td[5]/span/a", "Transaction Count", false, true);
		    RC_Global.validateHeaderName(driver, "Fuel Transaction Detail (E)", false);
		    RC_Global.panelAction(driver, "close", "Fuel Transaction Detail (E)", false, true);
	        
		    RC_Global.panelAction(driver, "expand", "Average Price per Gallon", false, true);
		    Thread.sleep(3000);
		    RC_Global.waitElementVisible(driver, 90, "//tbody//tr[2]//td[1]", "Average Price per Gallon Grid results", false, true);
		    Thread.sleep(3000);
		    String vehicleno2 = driver.findElement(By.xpath("//tr[2]/td[6]/span")).getText();
		    int vehicleCount2=Integer.parseInt(vehicleno2);  
		    RC_Global.clickUsingXpath(driver, "//tr[2]/td[1]/span/a", "County", false, true);
		    List<WebElement> countyCount2= driver.findElements(By.xpath("//table//tbody//tr"));		
		    Thread.sleep(4000);
	        int rowcount2=countyCount2.size();
	        if (vehicleCount2 == rowcount2) {
	        	queryObjects.logStatus(driver, Status.PASS, "Vehicle Count Value is", "Similar To Number of Record In The Grid", null);
	        }
	        else {queryObjects.logStatus(driver, Status.FAIL, "Vehicle Count Value is", "Not Similar To Number of Record In The Grid", null);}
	        RC_Global.verifyColumnNames(driver, "Unit #;CVN;Average PPG;High PPG;Low PPG;Transaction Total;Transaction Count", false);
	        RC_Global.clickButton(driver, "Show State Data", true, false);
	        RC_Global.panelAction(driver, "close", driver.findElement(By.xpath("(//h5)[2]/span[1]")).getText(), false, false);
			 
			RC_Global.logout(driver, false);
			queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
		}
	}
