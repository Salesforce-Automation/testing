package Manage.Administration.DashboardAdministration;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_5_02 {
	public void  DashboardAdministration_VerifyTheDefaultDashboardAndValidateTheDataMatchesOnDashboardAndTheReports (WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		String DAshboardName ="";
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		RC_Global.login(driver);
		RC_Global.enterCustomerFocus(driver, "LS008742", true);
		RC_Global.navigateTo(driver,"Manage","Administration","Dashboard Administration");
		RC_Global.clickButton(driver, "Add New", true, true);
		RC_Global.waitElementVisible(driver, 30, "(//h5//span[text()='Dashboard Administration'])[2]", "Dashboard Administration Page", true, true);
		RC_Global.clickUsingXpath(driver, "((//h5//span[text()='Dashboard Administration'])[1]/following::i[@ng-click='closePanel()'])[1]", "", true, false);
		RC_Global.panelAction(driver, "expand", "Dashboard Administration", true, false);

		RC_Global.createNode(driver, "Dashboard Administration Screen Components Validation");
		RC_Global.verifyScreenComponents(driver, "lable", "Dashboard Name", true);
		RC_Global.verifyScreenComponents(driver, "lable", "Default Open Upon Login", true);
		RC_Global.verifyScreenComponents(driver, "lable", "Default Dashboard", true);
		RC_Global.verifyScreenComponents(driver, "lable", "Marked as Favorite", true);
				
		RC_Global.buttonStatusValidation(driver, "Restore to Default", "Enable", true);
		RC_Global.buttonStatusValidation(driver, "Delete", "Enable", true);
		RC_Global.buttonStatusValidation(driver, "Save", "Enable", true);
		
		RC_Global.clickButton(driver, "Restore to Default", true, true);
		RC_Global.waitElementVisible(driver, 60, "//div[div/span[text()='Total Fleet Size']]/div/input[contains(@class,'ng-not-empty') and @type='checkbox']", "Total Fleet Size section", false, false);
		List<WebElement> DefaultLoginYes = driver.findElements(By.xpath("//label[@name='buttonIsExternalUserAllowedYes' and contains(@ng-class,'ShouldOpenUponLoginIndicator')]"));
		List<WebElement> DefaultLoginNo = driver.findElements(By.xpath("//label[@name='buttonIsExternalUserAllowedNo' and contains(@ng-class,'ShouldOpenUponLoginIndicator')]"));
		List<WebElement> DefaultDashboardYes = driver.findElements(By.xpath("//label[@name='buttonIsExternalUserAllowedYes' and contains(@ng-class,'UseAsDefaultIndicator')]"));
		List<WebElement> DefaultDashboardNo = driver.findElements(By.xpath("//label[@name='buttonIsExternalUserAllowedNo' and contains(@ng-class,'UseAsDefaultIndicator')]"));
		List<WebElement> FavDashYes = driver.findElements(By.xpath("//label[@name='buttonIsExternalUserAllowedYes' and contains(@ng-class,'IsFavoriteIndicator')]"));
		List<WebElement> FavDashNo = driver.findElements(By.xpath("//label[@name='buttonIsExternalUserAllowedNo' and contains(@ng-class,'IsFavoriteIndicator')]"));

		if(DefaultLoginYes.size()==1 && DefaultLoginNo.size()==1)
			BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Default Open Upon Login", "Default Open Upon Login section has toggle button with YES/No values", null);
		else {
            BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Default Open Upon Login", "Default Open Upon Login section doesn't have toggle button with YES/No values", null);
            RC_Global.endTestRun(driver);}
		
		if(DefaultDashboardYes.size()==1 && DefaultDashboardNo.size()==1)
			BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Default Dashboard", "Default Dashboard section has toggle button with YES/No values", null);
		else {
            BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Default Dashboard", "Default Dashboard section doesn't have toggle button with YES/No values", null);
            RC_Global.endTestRun(driver);}
		
		if(FavDashYes.size()==1 && FavDashNo.size()==1)
			BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Marked As Favorite", "Marked As Favorite section has toggle button with YES/No values", null);
		else {
            BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Marked As Favorite", "Marked As Favorite section doesn't have toggle button with YES/No values", null);
            RC_Global.endTestRun(driver);}
		
		RC_Global.createNode(driver, "Validate Fleet Metrics section");
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Total Fleet Size", "Yes", "Yes", "1", false);
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Units on Lease", "Yes", "Yes", "2", false);
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Units on Maintenance", "Yes", "Yes", "3", false);
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Units on Fuel", "Yes", "Yes", "4", false);
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Total Fuel Spend", "Yes", "Yes", "5", false);
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Total Maintenance Spend", "Yes", "Yes", "6", false);
		
		RC_Global.createNode(driver, "Validate Fleet Exception and Alerts section");
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Open Maintenance POs", "Yes", "Yes", "1", false);
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Maintenance POs Pending Approval", "Yes", "Yes", "2", false);
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Plates Coming Due", "Yes", "Yes", "4", false);		
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Same Day Fuel Transactions", "Yes", "Yes", "5", false);
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Missing Plate State", "Yes", "Yes", "6", false);
		
		RC_Global.createNode(driver, "Validate Fleet Facts section");
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Average Maintenance Cost per Unit", "Yes", "Yes", "1", false);
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Average Fuel Cost per Unit", "Yes", "Yes", "2", false);
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Average # of Fuel Transactions per Unit", "Yes", "Yes", "3", false);		
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Average Fleet Age", "Yes", "Yes", "4", false);
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Average Fleet Mileage", "Yes", "Yes", "5", false);
		
		RC_Global.createNode(driver, "Validate Graphics section");
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Total Monthly Lease Spend", "Yes", "Yes", "3", false);	
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Fleet Fuel Economy", "Yes", "Yes", "1", false);
		RC_Manage.optionFieldSelectionandOrderValidation(driver, "Average Price per Gallon", "Yes", "Yes", "2", false);
		driver.findElement(By.xpath("//input[@ng-model='userDashboard.DashboardName']")).clear();
		DAshboardName = "DashboardTest_"+RandomStringUtils.randomNumeric(3);
		RC_Global.enterInput(driver, DAshboardName, driver.findElement(By.xpath("//input[@ng-model='userDashboard.DashboardName']")), true,	true);
		RC_Global.clickUsingXpath(driver, "(//button[text()=' Save'])[1]", "Save", true, true);
		RC_Global.waitElementVisible(driver, 30, "//div[@ng-show='updateSuccessful && topSave']", "Update Successfull", true, false);
		List<WebElement> SuccMessage = driver.findElements(By.xpath("//div[@ng-show='updateSuccessful && topSave']"));
		if(SuccMessage.size()>0)  
			BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Successfull Message", "Update Successfull message is displayed", null);
		else {
            BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Successfull Message", "Update Successfull message failed to display", null);
            RC_Global.endTestRun(driver);}
		executor.executeScript("document.body.style.zoom = '30%'");
		   Thread.sleep(2000);
		executor.executeScript("document.body.style.zoom = '100%'");
		RC_Global.panelAction(driver, "close", "Dashboard Administration", true, false);
		RC_Global.clickUsingXpath(driver, "//button[@data-toggle='dropdown']", "", true, false);
		RC_Global.clickUsingXpath(driver, "//ul//li[text()=' "+DAshboardName+" ']", DAshboardName+"", true, false);
		RC_Global.waitElementVisible(driver, 30, "//div[@class='dashboard-section-header']//span[text()='Fleet Metrics']", "Dashboard ", true, true);
		
		RC_Global.createNode(driver, "Dashboard Section Validation");
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Fleet Metrics", true);
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Exceptions & Alerts", true);
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Fleet Facts", true);
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Fleet Fuel Economy", true);
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Average Price per Gallon", true);
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Total Monthly Lease Spend", true);
		
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Metrics", "Total Fleet Size", "List Of Fleet (E)", "", false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Metrics", "Units on Lease", "Units On Lease (E)", "", false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Metrics", "Units on Maintenance", "Units On Maintenance (E)", "", false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Metrics", "Units on Fuel", "Units On Fuel (E)", "", false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Metrics", "Total Fuel Spend", "Fuel Summary By Vehicle (E)", "", false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Metrics", "Total Maintenance Spend", "Maintenance History Summary (E)", "", false);

		RC_Manage.validateDashboardGroupSection(driver, "Exceptions & Alerts", "Open Maintenance POs", "Open Purchase Orders (E)", "", false);
		RC_Manage.validateDashboardGroupSection(driver, "Exceptions & Alerts", "Maintenance POs Pending Approval", "Purchase Orders Pending Approval (E)", "", false);
		RC_Manage.validateDashboardGroupSection(driver, "Exceptions & Alerts", "Plates Coming Due", "Plate Expiration (E)", "", false);
		RC_Manage.validateDashboardGroupSection(driver, "Exceptions & Alerts", "Same Day Fuel Transactions", "Same Day Fuel Exceptions (E)", "", false);
		RC_Manage.validateDashboardGroupSection(driver, "Exceptions & Alerts", "Missing Plate State", "Missing Plate/State (E)", "", false);
		
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Facts", "Average Maintenance Cost per Unit", "Maintenance History Summary (E)", "", false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Facts", "Average Fuel Cost per Unit", "Fuel Summary By Vehicle (E)", "", false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Facts", "Average # of Fuel Transactions per Unit", "Fuel Summary By Vehicle (E)", "", false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Facts", "Average Fleet Age", "List Of Fleet (E)", "3", false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Facts", "Average Fleet Mileage", "List Of Fleet (E)", "4", false);

		
		//Fleet Fuel Economy
				RC_Global.clickUsingXpath(driver, "//span[text()='Fleet Fuel Economy']/../..//div[@class='highcharts-container']//*[name()='g']/*[name()='path' and contains(@fill,'953735')]", "Fleet Fuel Economy", false, false);
				if(driver.findElements(By.xpath("(//h5)[2]/span[1]")).size()>0)
				{
					queryObjects.logStatus(driver, Status.PASS, driver.findElement(By.xpath("(//h5)[2]/span[1]")).getText()+" screen is opened for", "Fleet Fuel Economy", null);
				}
			    RC_Global.verifyColumnNames(driver, "Timeframe;Average MPG;High MPG;Low MPG;Vehicle Count", false);
			    RC_Global.waitElementVisible(driver, 60, "//tbody//tr[1]//td[1]", "Fuel Summary Grid results", false, true);
			    RC_Global.clickUsingXpath(driver, "//tr[1]/td[2]/span/a", "Average MPG", false, true);
			    RC_Global.validateHeaderName(driver, "Fuel Summary By Vehicle (E)", false);
			    RC_Global.panelAction(driver, "close", "Fuel Summary By Vehicle (E)", false, true);
			    RC_Global.panelAction(driver, "expand", driver.findElement(By.xpath("(//h5)[2]/span[1]")).getText(), false, false);
			    
//			    RC_Global.clickUsingXpath(driver, "//tr[1]/td[3]/span/a", "High MPG", false, true);
//			    RC_Global.validateHeaderName(driver, "Fuel Transaction Detail (E)", false);
//			    RC_Global.panelAction(driver, "close", "Fuel Transaction Detail (E)", false, true);
//			    RC_Global.panelAction(driver, "expand", driver.findElement(By.xpath("(//h5)[2]/span[1]")).getText(), false, false);
//			    
//			    RC_Global.clickUsingXpath(driver, "//tr[1]/td[4]/span/a", "Low MPG", false, true);
//			    RC_Global.validateHeaderName(driver, "Fuel Transaction Detail (E)", false);
//			    RC_Global.panelAction(driver, "close", "Fuel Transaction Detail (E)", false, true);
//			    RC_Global.panelAction(driver, "close", driver.findElement(By.xpath("(//h5)[2]/span[1]")).getText(), false, false);
			    ///----Commented as it is Not in the test case steps
			    	
		//Average Price per Gallon
        List<WebElement> map2 = driver.findElements(By.xpath("//span[text()='Average Price per Gallon']/../..//div[@class='highcharts-container']//*[name()='g']/*[name()='text']/*[name()='tspan']"));
        int dolDatacount=map2.size();
        for(int i=1; i<=dolDatacount;i++) {
			WebElement gallon = driver.findElement(By.xpath("(//span[text()='Average Price per Gallon']/../..//div[@class='highcharts-container']//*[name()='g']/*[name()='text']/*[name()='tspan'])["+i+"]"));
			String gallonPrice = gallon.getText();
			if(gallonPrice.startsWith("$")) {
				gallon.click();
	    	break;
			}
          }
	    RC_Global.validateHeaderName(driver, "Average Price per Gallon", false);
	    RC_Global.waitElementVisible(driver, 60, "//tbody//tr[1]//td[1]", "Average Price per Gallon Grid results", false, true);
	    RC_Global.verifyColumnNames(driver, "County;Average PPG;High PPG;Low PPG;Transaction Count;Vehicle Count", false);
	    RC_Global.clickUsingXpath(driver, "//tr[1]/td[5]/span/a", "Transaction Count", false, true);
	    RC_Global.validateHeaderName(driver, "Fuel Transaction Detail (E)", false);
	    RC_Global.panelAction(driver, "close", "Fuel Transaction Detail (E)", false, true);
        
	    RC_Global.panelAction(driver, "expand", "Average Price per Gallon", false, true);
	    RC_Global.waitElementVisible(driver, 60, "//tbody//tr[2]//td[1]", "Average Price per Gallon Grid results", false, true);
	    String vehicleno2 = driver.findElement(By.xpath("//tr[2]/td[6]/span")).getText();
	    Thread.sleep(2000);
	    int vehicleCount2=Integer.parseInt(vehicleno2);  
	    RC_Global.clickUsingXpath(driver, "//tr[2]/td[1]/span/a", "County", false, true);
	    RC_Global.waitElementVisible(driver, 60, "//table//tbody//tr[1]", "", false, false);
	    List<WebElement> countyCount2= driver.findElements(By.xpath("//table//tbody//tr"));		
	    Thread.sleep(4000);
        int rowcount2=countyCount2.size();
        if (vehicleCount2 == rowcount2) {
        	queryObjects.logStatus(driver, Status.PASS, "Vehicle Count Value is", "Similar To Number of Record In The Grid", null);
        }
        else {queryObjects.logStatus(driver, Status.FAIL, "Vehicle Count Value is", "Not Similar To Number of Record In The Grid", null);}
        RC_Global.verifyColumnNames(driver, "Unit #;CVN;Average PPG;High PPG;Low PPG;Transaction Total;Transaction Count", false);
        RC_Global.clickButton(driver, "Show State Data", true, false);
        RC_Global.panelAction(driver, "close", driver.findElement(By.xpath("(//h5)[2]/span[1]")).getText(), false, false);
		 
        
        
		RC_Global.navigateTo(driver,"Manage","Administration","Dashboard Administration");
		RC_Global.clickUsingXpath(driver, "(//span[text()='"+DAshboardName+"']/following::img[@title='Delete'])[1]", "", true, false);
		RC_Global.panelAction(driver, "close", "Dashboard Administration", true, false);
		
		RC_Global.logout(driver, true);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
