package Manage.Administration.DashboardAdministration;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_5_08 {
	public void DashboardAdministrationEditAndDeleteFunctionValidation (WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{	WebDriverWait wait = new WebDriverWait(driver,60);
		
		RC_Global.login(driver);		
		RC_Global.enterCustomerFocus(driver, "LS008742", false);		
		RC_Global.navigateTo(driver, "Manage", "Administration", "Dashboard Administration");	
		RC_Global.validateHeaderName(driver, "Dashboard Administration", false);
		
		RC_Global.clickButton(driver, "Add New", false, true);
		RC_Global.clickUsingXpath(driver, "(//*[text()='Dashboard Administration'])[2]/../i[1]", "Close Dashboard Administration Search screen", false, false);
		RC_Global.panelAction(driver, "expand", "Dashboard Administration", false, true);
		String DName = "DashboardTest"+RandomStringUtils.randomNumeric(3);
		RC_Global.enterInput(driver, DName, driver.findElement(By.xpath("//label[text()='Dashboard Name']/../input")), false, true);
		
		// Noted General Preferences under dashboard
		RC_Global.createNode(driver, "Selected Dashboard General Preferences values");
		driver.findElement(By.xpath("//label[text()='Dashboard']/../select"));
		String Dashboard = driver.findElement(By.xpath("//label[text()='Dashboard']/../select/option[@selected='selected']")).getText();
		queryObjects.logStatus(driver, Status.INFO, "'Dashboard' Field Selected value -->", Dashboard, null);
				
		String DefaultOpenUponLogin = driver.findElement(By.xpath("//div[label[text()='Default Open Upon Login']]/following-sibling::div/label[contains(@class,'active')]")).getText();
		queryObjects.logStatus(driver, Status.INFO, "'Default Open Upon Login' Field Selected value -->", DefaultOpenUponLogin, null);
				
		String DefaultDashboard = driver.findElement(By.xpath("//div[label[text()='Default Dashboard']]/following-sibling::div/label[contains(@class,'active')]")).getText();
		queryObjects.logStatus(driver, Status.INFO, "'Default Dashboard' Field Selected value -->", DefaultDashboard, null);
				
		String DashboardName = driver.findElement(By.xpath("//label[text()='Dashboard Name']/../input")).getText();
		queryObjects.logStatus(driver, Status.INFO, "'Dashboard Name' Field Selected value -->", DashboardName, null);
				
		String MarkedAsFavorite = driver.findElement(By.xpath("//div[label[text()='Marked as Favorite']]/following-sibling::div/label[contains(@class,'active')]")).getText();
		queryObjects.logStatus(driver, Status.INFO, "'Marked as Favorite' Field Selected value -->", MarkedAsFavorite, null);
				
		RC_Global.clickButton(driver, "Save", false, true);
		Thread.sleep(2000);
		
		try {
			RC_Global.waitElementVisible(driver, 30, "(//h4[text()='Update Successful'])[1]", "Save Success Message", true, true);
			queryObjects.logStatus(driver, Status.PASS, "Verify Update Success message is displayed", "Update Success message is displayed", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify Update Success message is displayed", "Update Success message is not displayed", null);
		}
				
		// Assign Dashboard
		RC_Global.clickUsingXpath(driver, "//a[text()='Assign Dashboard']", "Assign Dashboard", false, true);
		if(driver.findElements(By.xpath("//div[div/div/p/span[text()='Fleet Manager']]//div/input[contains(@class,'ng-not-empty') and @type='checkbox' ]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.INFO, "'Fleet Manager' is already selected-->", "Successfully", null);
			RC_Global.clickUsingXpath(driver, "//div[div/div/p/span[text()='Fleet Manager']]//div/input[contains(@class,'ng-not-empty') and @type='checkbox' ]", "Uncheck Fleet Manager checkbox", false, true);
			Thread.sleep(2000);
			if(driver.findElements(By.xpath("//div[div/div/p/span[text()='Fleet Manager']]//div/input[contains(@class,'ng-empty') and @type='checkbox' ]")).size()>0)
			{
			RC_Global.clickUsingXpath(driver, "//div[div/div/p/span[text()='Fleet Manager']]//div/input[contains(@class,'ng-empty') and @type='checkbox' ]", "Fleet Manager checkbox", false, true);
			Thread.sleep(2000);
			RC_Global.clickUsingXpath(driver, "//div[div/div/p/span[text()='Fleet Manager']]/../div//a[text()='Manage']", "Manage hypelink", false, true);
			}
		}
		else if(driver.findElements(By.xpath("//div[div/div/p/span[text()='Fleet Manager']]//div/input[contains(@class,'ng-empty') and @type='checkbox' ]")).size()>0)
		{
		RC_Global.clickUsingXpath(driver, "//div[div/div/p/span[text()='Fleet Manager']]//div/input[contains(@class,'ng-empty') and @type='checkbox' ]", "Fleet Manager checkbox", false, true);
		Thread.sleep(2000);
		RC_Global.clickUsingXpath(driver, "//div[div/div/p/span[text()='Fleet Manager']]/../div//a[text()='Manage']", "Manage hypelink", false, true);
		}
		
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h4[text()='Select Fleet Manager to Assign Dashboard']")));
		RC_Global.validateHeaderName(driver, "Select Fleet Manager to Assign Dashboard", false);
		String Name = driver.findElement(By.xpath("(//standard-grid//div[2]//div[1]/div/div[2]/div)[1]")).getText();
		
		if(driver.findElements(By.xpath("//div[div[1]/a[text()='Opted In']]/../div[2]/div[text()='"+Name+"']")).size()>0)
		{
		RC_Global.clickUsingXpath(driver, "(//a[text()='Opted In'])[1]", "Status", false, false);
			if(driver.findElements(By.xpath("//div[div[1]/a[text()='Opted Out']]/../div[2]/div[text()='"+Name+"']")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "'Status' column is changed as - Opted out -->", "Successfully", null);
			}
			else {
				queryObjects.logStatus(driver, Status.FAIL, "'Status' column is not changed as - Opted out -->", "", null);
			}
		}
		else {
			queryObjects.logStatus(driver, Status.WARNING, "'Status' column is not as - Opted In -->", "", null);
		}

		
		RC_Global.clickButton(driver, "Done", false, false);
		Thread.sleep(2000);
		if(!(driver.findElements(By.xpath("//h4[text()='Select Fleet Manager to Assign Dashboard']")).size()>0))
		{
			queryObjects.logStatus(driver, Status.PASS, " 'Select Fleet Manager to Assign Dashboard' screen is closed-->", "Successfully", null);
		}
		else {
			queryObjects.logStatus(driver, Status.FAIL, " 'Select Fleet Manager to Assign Dashboard' screen is not closed-->", "", null);
		}
		
		RC_Global.clickButton(driver, "Save", false, true);
		Thread.sleep(2000);
		try {
			RC_Global.waitElementVisible(driver, 60, "(//h4[text()='Update Successful'])[1]", "Update Successful message", true, true);
			queryObjects.logStatus(driver, Status.PASS, "Verify Update Successful message is displayed", "Update Successful message is displayed", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify Update Successful message is displayed", "Update Successful message is not displayed", null);
		}
		
		RC_Global.panelAction(driver, "close", "Dashboard Administration", false, true);
		
		RC_Global.navigateTo(driver, "Manage", "Administration", "Dashboard Administration");
		RC_Global.validateHeaderName(driver, "Dashboard Administration", false);
		
		// Validate created Dashboard name displays in grid, edit dashboard and delete dashboard
		boolean data = false;		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("((//div[@role='rowgroup'])[2]/div/div)[1]")));
		List<WebElement> Gridrowcnt= driver.findElements(By.xpath("(//div[@role='rowgroup'])[2]/div/div"));		
		for(int i=1; i<=Gridrowcnt.size();i++) {
		WebElement name = driver.findElement(By.xpath("//div[@role='rowgroup'][2]//div["+i+"]/div/div[2]/div//span"));
		WebElement Editdashb = driver.findElement(By.xpath("//div[@role='rowgroup'][2]//div["+i+"]/div/div[5]/div//img[2]"));
		WebElement Deletedashb = driver.findElement(By.xpath("//div[@role='rowgroup'][2]//div["+i+"]/div/div[5]/div//img[1]"));
		String AddAlertName = name.getText();
		if(AddAlertName.equals(DName))
		{
			
		 Editdashb.click();
		 RC_Global.clickUsingXpath(driver, "(//*[text()='Dashboard Administration'])[2]/../i[1]", "Close Dashboard Administration Search screen", false, false);
			if(driver.findElements(By.xpath("//h5/span[text()='Dashboard Administration']")).size()>0)
			{
				 if(!(driver.findElements(By.xpath("//div[label[text()='Marked as Favorite']]/following-sibling::div/label[contains(@class,'active') and text()='Yes']")).size()>0))
				 {
				 RC_Global.clickUsingXpath(driver, "//div[label[text()='Marked as Favorite']]/following-sibling::div/label[text()='Yes']", "Marked as Favorite - Yes", false, true);
				 queryObjects.logStatus(driver, Status.PASS, "Newly added dashboard 'Marked as Favorite' is Yes", "Successfully", null);
				 }
				 else{
				 queryObjects.logStatus(driver, Status.FAIL, "Newly added dashboard is already 'Marked as Favorite' is Yes", " ", null);
			 	 }
			 RC_Global.clickButton(driver, "Save", false, true);
			 Thread.sleep(2000);
			 
			 try {
				 RC_Global.waitElementVisible(driver, 30, "(//h4[text()='Update Successful'])[1]", "Update Successful message", true, true);
				 queryObjects.logStatus(driver, Status.PASS, "Verify Update Successful message is displayed", "Update Successful message is displayed", null);
			 }
			 catch(Exception e) {
				 queryObjects.logStatus(driver, Status.FAIL, "Verify Update Successful message is displayed", "Update Successful message is not displayed", null);
			 }

			 RC_Global.panelAction(driver, "close", "Dashboard Administration", false, false);	
			 data = true;
			 
			}break;
		}
		
		}
		if(data = true)
		{
			queryObjects.logStatus(driver, Status.PASS, "Newly added dashboard '"+DName+"' is displayed in grid", "Successfully", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Newly added dashboard is not displayed in grid", "", null);
		}
	
		RC_Global.navigateTo(driver, "Manage", "Administration", "Dashboard Administration");
	
		for(int i=1; i<=Gridrowcnt.size();i++) {
		WebElement name = driver.findElement(By.xpath("//div[@role='rowgroup'][2]//div["+i+"]/div/div[2]/div//span"));	
		WebElement Deletedashb = driver.findElement(By.xpath("//div[@role='rowgroup'][2]//div["+i+"]/div/div[5]/div//img[1]"));
		String AddAlertName = name.getText();
			if(AddAlertName.equals(DName))
			{		 
				 Deletedashb.click();
				 driver.switchTo().alert().accept();				
				 break;
			}
		}


		Thread.sleep(2000);
		if(!(driver.findElements(By.xpath("//span[text()='"+DName+"']")).size()>0))
		{
			queryObjects.logStatus(driver, Status.PASS, "Newly added dashboard '"+DName+"' is deleted from grid", "Successfully", null);
		}
		else{
			queryObjects.logStatus(driver, Status.FAIL, "Newly added dashboard '"+DName+"' is not deleted from grid", "", null);
		}
		
		RC_Global.panelAction(driver, "close", "Dashboard Administration", false, true);		
		RC_Global.logout(driver, false);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
