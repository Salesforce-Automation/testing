package Manage.Administration.DashboardAdministration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_5_09_C {
	public void DashboardGroup1_FleetFacts(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String dName="DashboardGroup1";JavascriptExecutor executor = (JavascriptExecutor) driver;
		String[] fleetMatrices= {"Total Fleet Size","Units on Lease","Open End Leased Vehicles","Closed End Leased Vehicles","Services Only Vehicles","Units on Maintenance","Units on Fuel","Active Pool Units","Due for Replacement � Open End","Due for Replacement � Closed End"};
		String[] fleetExceptionsAndAlerts= {"Open Maintenance POs","Maintenance POs Pending Approval","Units Missing Lube/Oil/Filter Service","Plates Coming Due","Fuel Transactions Exceeding $","Fuel Transaction Exceeding Gallons","Same Day Fuel Transactions","Units with Fuel Transactions Over Tank Capacity","Drivers with Non-Sequential Odometers"};
		String[] fleetFacts= {"Average Price per Gallon","Average Maintenance Cost per Service","Average Maintenance Cost per Unit","Average Fuel Cost per Unit","Average # of Fuel Transactions per Unit"};
		String[] graphics= {"Total Monthly Maintenance Spend","Total Monthly Fuel Spend","Total Monthly Lease Spend"};

		RC_Global.login(driver);
		RC_Global.enterCustomerFocus(driver, "LS008737", false);
		Thread.sleep(1000);
		if(driver.findElement(By.xpath("(//span[text()='Fleet Metrics'])[1]")).isDisplayed())
			RC_Global.clickUsingXpath(driver, "//li[@class='dashboard-icon'][1]/button/i", "Dashboard Icon", false, false);
		RC_Global.clickUsingXpath(driver, "((//li[@class='dashboard-icon'])[1]/following-sibling::li/button/i)[1]", "Dashboard Lists", false, false);
		Thread.sleep(1000);
		
		RC_Global.createNode(driver, dName+" Existence Status");
		if(driver.findElements(By.xpath("//div[div[(text()= ' My Dashboards ')]]//li[contains(., 'Group1')]")).size()==1)
		{
			queryObjects.logStatus(driver, Status.PASS, dName, "Already Created", null);
			RC_Global.clickUsingXpath(driver, "//div[div[(text()= ' My Dashboards ')]]//li[contains(., 'Group1')]", dName, false, true);
		}
		else
		{
			queryObjects.logStatus(driver, Status.PASS, dName, "is not created", null);
			RC_Global.navigateTo(driver, "Manage", "Administration", "Dashboard Administration");
			RC_Global.clickButton(driver, "Add New", false, true);
			RC_Global.clickUsingXpath(driver, "(//*[text()='Dashboard Administration'])[2]/../i[1]", "Close Dashboard Administration", false, false);
			RC_Global.panelAction(driver, "expand", "Dashboard Administration", false, true);
			Select dashboardDropDown=new Select(driver.findElement(By.xpath("//label[text()='Dashboard']/following-sibling::select")));
			if(dashboardDropDown.getFirstSelectedOption().getText().contains("Default"))
			{
				dashboardDropDown.selectByIndex(0);
			}
			WebElement dNameField = driver.findElement(By.xpath("//*[text()='Dashboard Name']/following-sibling::input"));
			RC_Global.enterInput(driver, dName, dNameField, false, true);

			RC_Global.createNode(driver, "Select checkboxes from Fleet Metrics");
			for(int j=0;j<fleetMatrices.length;j++)
			{
				RC_Manage.selectCheckBoxesDashboardAdminstration(driver, fleetMatrices[j],"Fleet Metrics", false);
			}

			RC_Global.createNode(driver, "Select checkboxes from Fleet Exceptions and Alerts");
			for(int j=0;j<fleetExceptionsAndAlerts.length;j++)
			{
				RC_Manage.selectCheckBoxesDashboardAdminstration(driver, fleetExceptionsAndAlerts[j],"Fleet Exceptions and Alerts", false);
			}

			RC_Global.createNode(driver, "Select checkboxes from Fleet Facts");
			for(int j=0;j<fleetFacts.length;j++)
			{
				RC_Manage.selectCheckBoxesDashboardAdminstration(driver, fleetFacts[j],"Fleet Facts", false);
			}

			RC_Global.createNode(driver, "Select checkboxes from Graphics");
			for(int j=0;j<graphics.length;j++)
			{
				RC_Manage.selectCheckBoxesDashboardAdminstration(driver, graphics[j],"Graphics", false);
			}

			executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//span[text()='Dashboard Administration'])[2]")));
			RC_Global.clickUsingXpath(driver, "(//button[text()=' Save'])[1]", "Save", false, true);
			Thread.sleep(6000);
			if(driver.findElements(By.xpath("(//*[text()='Update Successful'])[3]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Update Successful message is displayed", "", null);
			}
			RC_Global.panelAction(driver, "close", "Dashboard Administration", false, true);
			
			if(driver.findElement(By.xpath("(//span[text()='Fleet Metrics'])[1]")).isDisplayed())
				RC_Global.clickUsingXpath(driver, "//li[@class='dashboard-icon'][1]/button/i", "Dashboard Icon", false, false);
			
			RC_Global.clickUsingXpath(driver, "((//li[@class='dashboard-icon'])[1]/following-sibling::li/button/i)[1]", "Dashboard Lists", false, false);
			
			RC_Global.createNode(driver, dName+" Creation Status");
			if(driver.findElements(By.xpath("//div[div[(text()= ' My Dashboards ')]]//li[contains(., 'Group1')]")).size()==1)
			{
				queryObjects.logStatus(driver, Status.PASS, dName+" creation", "Successful", null);
				RC_Global.clickUsingXpath(driver, "//div[div[(text()= ' My Dashboards ')]]//li[contains(., 'Group1')]", dName, false, true);
			}
			else
			{
				queryObjects.logStatus(driver, Status.FAIL, dName+" creation", "Unsuccessful", null);
			}
		}
		RC_Global.waitElementVisible(driver, 60, "//h4[text()='Average Price per Gallon']", "Fleet Facts section is diplayed for "+dName, false, true);
					
		if(driver.findElements(By.xpath("//h4[text()='Average Price per Gallon']")).size()==1)
			RC_Manage.validateDashboardGroupTopSections(driver, "Fleet Facts", "Average Price per Gallon", "Fuel Transaction Detail", false);
		else	
			RC_Manage.validateDashboardGroupSection(driver, "Fleet Facts", "Average Price per Gallon", "Fuel Transaction Detail","", false);
		
		if(driver.findElements(By.xpath("//h4[text()='Average Maintenance Cost per Service']")).size()==1)
			RC_Manage.validateDashboardGroupTopSections(driver, "Fleet Facts", "Average Maintenance Cost per Service", "Maintenance History Detail", false);
		else
			RC_Manage.validateDashboardGroupSection(driver, "Fleet Facts", "Average Maintenance Cost per Service", "Maintenance History Detail","1", false);
		
		if(driver.findElements(By.xpath("//h4[text()='Average Maintenance Cost per Unit']")).size()==1)
			RC_Manage.validateDashboardGroupTopSections(driver, "Fleet Facts", "Average Maintenance Cost per Unit", "Maintenance History Summary", false);
		else
			RC_Manage.validateDashboardGroupSection(driver, "Fleet Facts", "Average Maintenance Cost per Unit", "Maintenance History Summary","2", false);
		
		if(driver.findElements(By.xpath("//h4[text()='Average Fuel Cost per Unit']")).size()==1)
			RC_Manage.validateDashboardGroupTopSections(driver, "Fleet Facts", "Average Fuel Cost per Unit", "Fuel Summary By Vehicle", false);
		else
			RC_Manage.validateDashboardGroupSection(driver, "Fleet Facts", "Average Fuel Cost per Unit", "Fuel Summary By Vehicle","3", false);
		
		if(driver.findElements(By.xpath("//h4[text()='Average # of Fuel Transactions per Unit']")).size()==1)
			RC_Manage.validateDashboardGroupTopSections(driver, "Fleet Facts", "Average # of Fuel Transactions per Unit", "Fuel Summary By Vehicle", false);
		else
			RC_Manage.validateDashboardGroupSection(driver, "Fleet Facts", "Average # of Fuel Transactions per Unit", "Fuel Summary By Vehicle","4", false);
		
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
