package Manage.Administration.DashboardAdministration;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_5_03 {
	public void DashboardAdministartion_ResultGridValidation(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String dName="";int rowCount;String custNo="LS008737";
		String colNames="Dashboards;Dashboard Name;Marked As Favorite;Default Dashboard;Actions";
		
		RC_Global.login(driver);
		RC_Global.enterCustomerFocus(driver, custNo, false);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Dashboard Administration");
		RC_Global.validateHeaderName(driver, "Dashboard Administration", false);
		RC_Global.clickButton(driver, "Add New", false, true);
		RC_Global.clickUsingXpath(driver, "(//*[text()='Dashboard Administration'])[2]/../i[1]", "Close Dashboard Administration", false, false);
		RC_Global.panelAction(driver, "expand", "Dashboard Administration", false, true);
		WebElement dNameField = driver.findElement(By.xpath("//*[text()='Dashboard Name']/following-sibling::input"));
		dName="TestSample"+RandomStringUtils.randomAlphanumeric(4);
		RC_Global.enterInput(driver, dName, dNameField, false, true);
		RC_Global.clickUsingXpath(driver, "(//*[text()='Marked as Favorite']/../following-sibling::div/label[text()='Yes'])", "Marked as Favorite -> Yes", false, true);
		RC_Global.clickUsingXpath(driver, "(//button[text()=' Save'])[1]", "Save", false, true);
		Thread.sleep(2000);
//		if(driver.findElements(By.xpath("(//*[text()='Update Successful'])[3]")).size()>0)
		try{
			RC_Global.waitElementVisible(driver, 30, "(//h4[text()='Update Successful'])[1]", "Update Successfull Message", true, true);
			queryObjects.logStatus(driver, Status.PASS, "Update Successful message is displayed", "", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Update Successful message is not displayed", "", null);
		}
			
		RC_Global.panelAction(driver, "close", "Dashboard Administration", false, true);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Dashboard Administration");
		RC_Global.verifyColumnNames(driver, colNames, false);
		if(driver.findElements(By.xpath("(//div[@role='rowgroup'])[2]/div/div[1]/div/div/div/img")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Delete and Edit are displayed in Action column", "", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "Delete and Edit are not displayed in Action column", "", null);
			
		rowCount=driver.findElements(By.xpath("(//div[@role='rowgroup'])[2]/div/div")).size();
		for(int i=1;i<=rowCount;i++)
		{
			if(driver.findElement(By.xpath("((//div[@role='rowgroup'])[2]/div/div["+i+"]/div/div/div/p/span)[2]")).getText().equals(dName))
			{
				RC_Global.clickUsingXpath(driver, "(//div[@role='rowgroup'])[2]/div/div["+i+"]/div/div/div/img[2]", "Edit", false, true);
				Thread.sleep(1000);
				if(driver.findElements(By.xpath("//*[text()='General Preferences']")).size()>0)
				{
					queryObjects.logStatus(driver, Status.PASS, "Dashboard Administration screen opens in the new window ", "", null);
					RC_Global.clickUsingXpath(driver, "(//*[text()='Dashboard Administration'])[3]/../i[1]", "Close Dashboard Edit Screen", false, false);
					RC_Global.panelAction(driver, "expand", "Dashboard Administration", false, true);
				}
				driver.findElement(By.xpath("((//div[@role='rowgroup'])[2]/div/div["+i+"]/div/div/div/img)[1]")).click();
				WebDriverWait wait = new WebDriverWait(driver, 30);
				//queryObjects.logStatus(driver, Status.PASS, driver.switchTo().alert().getText() +"Popup appears on the screen with two buttons", "OK and Cancel", null);
				String alertText=driver.switchTo().alert().getText();
				Thread.sleep(1000);
				driver.switchTo().alert().dismiss();
				Thread.sleep(1000);
				driver.findElement(By.xpath("((//div[@role='rowgroup'])[2]/div/div["+i+"]/div/div/div/img)[1]")).click();
				driver.switchTo().alert().accept();
				queryObjects.logStatus(driver, Status.PASS, alertText +" Popup appears on the screen with two buttons", "OK and Cancel", null);
				break;
			}
		}
		RC_Global.downloadAndVerifyFileDownloaded(driver,"Export","Export To Excel Functionality", true);
		RC_Global.panelAction(driver, "close", "Dashboard Administration", false, true);
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
