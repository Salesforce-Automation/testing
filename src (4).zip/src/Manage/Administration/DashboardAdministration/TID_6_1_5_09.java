package Manage.Administration.DashboardAdministration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_5_09 {
	public void DashboardGroup_1(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String dName="DashboardGroup1";int dCount;String listDName="";JavascriptExecutor executor = (JavascriptExecutor) driver;
		String[] fleetMatrices= {"Total Fleet Size","Units on Lease","Open End Leased Vehicles","Closed End Leased Vehicles","Services Only Vehicles","Units on Maintenance","Units on Fuel","Active Pool Units","Due for Replacement � Open End","Due for Replacement � Closed End"};
		String[] fleetExceptionsAndAlerts= {"Open Maintenance POs","Maintenance POs Pending Approval","Units Missing Lube/Oil/Filter Service","Plates Coming Due","Fuel Transactions Exceeding $","Fuel Transaction Exceeding Gallons","Same Day Fuel Transactions","Units with Fuel Transactions Over Tank Capacity","Drivers with Non-Sequential Odometers"};
		String[] fleetFacts= {"Average Price per Gallon","Average Maintenance Cost per Service","Average Maintenance Cost per Unit","Average Fuel Cost per Unit","Average # of Fuel Transactions per Unit"};
		String[] graphics= {"Total Monthly Maintenance Spend","Total Monthly Fuel Spend","Total Monthly Lease Spend"};int count=0;

		RC_Global.login(driver);
		RC_Global.enterCustomerFocus(driver, "LS008737", false);
		if(driver.findElements(By.xpath("(//span[text()='Fleet Metrics'])[1]")).size()>0)
			RC_Global.clickUsingXpath(driver, "//li[@class='dashboard-icon'][1]/button/i", "Dashboard Icon", false, false);
		RC_Global.clickUsingXpath(driver, "((//li[@class='dashboard-icon'])[1]/following-sibling::li/button/i)[1]", "Dashboard Lists", false, false);

		dCount=driver.findElements(By.xpath("//*[text()=' My Dashboards ']/../ul/li")).size();
		for(int i=1;i<=dCount;i++)
		{
			listDName=driver.findElement(By.xpath("//*[text()=' My Dashboards ']/../ul/li["+i+"]")).getText();
			if(listDName.contains(dName))
			{
				count=1;
				RC_Global.clickUsingXpath(driver, "//*[text()=' My Dashboards ']/../ul/li["+i+"]", "DashboardGroup1", false, true);
				break;
			}
		}
		if(count==0)
		{
			//DashboardGroup1 is not created
			RC_Global.navigateTo(driver, "Manage", "Administration", "Dashboard Administration");
			RC_Global.clickButton(driver, "Add New", false, true);
			RC_Global.clickUsingXpath(driver, "(//*[text()='Dashboard Administration'])[2]/../i[1]", "Close Dashboard Administration", false, false);
			RC_Global.panelAction(driver, "expand", "Dashboard Administration", false, true);
			Select dashboardDropDown=new Select(driver.findElement(By.xpath("//label[text()='Dashboard']/following-sibling::select")));
			if(dashboardDropDown.getFirstSelectedOption().getText().contains("Default"))
			{
				dashboardDropDown.selectByIndex(0);
			}
			WebElement dNameField = driver.findElement(By.xpath("//*[text()='Dashboard Name']/following-sibling::input"));
			RC_Global.enterInput(driver, dName, dNameField, false, true);

			RC_Global.createNode(driver, "Select checkboxes from Fleet Metrics");
			for(int j=0;j<fleetMatrices.length;j++)
			{
				RC_Manage.selectCheckBoxesDashboardAdminstration(driver, fleetMatrices[j],"Fleet Metrics", false);
			}

			RC_Global.createNode(driver, "Select checkboxes from Fleet Exceptions and Alerts");
			for(int j=0;j<fleetExceptionsAndAlerts.length;j++)
			{
				RC_Manage.selectCheckBoxesDashboardAdminstration(driver, fleetExceptionsAndAlerts[j],"Fleet Exceptions and Alerts", false);
			}

			RC_Global.createNode(driver, "Select checkboxes from Fleet Facts");
			for(int j=0;j<fleetFacts.length;j++)
			{
				RC_Manage.selectCheckBoxesDashboardAdminstration(driver, fleetFacts[j],"Fleet Facts", false);
			}

			RC_Global.createNode(driver, "Select checkboxes from Graphics");
			for(int j=0;j<graphics.length;j++)
			{
				RC_Manage.selectCheckBoxesDashboardAdminstration(driver, graphics[j],"Graphics", false);
			}

			executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//span[text()='Dashboard Administration'])[2]")));
			RC_Global.clickUsingXpath(driver, "(//button[text()=' Save'])[1]", "Save", false, true);
			Thread.sleep(6000);
			if(driver.findElements(By.xpath("(//*[text()='Update Successful'])[3]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Update Successful message is displayed", "", null);
			}
			RC_Global.panelAction(driver, "close", "Dashboard Administration", false, true);
			if(driver.findElements(By.xpath("(//span[text()='Fleet Metrics'])[1]")).size()>0)
				RC_Global.clickUsingXpath(driver, "//li[@class='dashboard-icon'][1]/button/i", "Dashboard Icon", false, false);
			RC_Global.clickUsingXpath(driver, "((//li[@class='dashboard-icon'])[1]/following-sibling::li/button/i)[1]", "Dashboard Lists", false, false);
			dCount=driver.findElements(By.xpath("//*[text()=' My Dashboards ']/../ul/li")).size();
			for(int i=1;i<=dCount;i++)
			{
				listDName=driver.findElement(By.xpath("//*[text()=' My Dashboards ']/../ul/li["+i+"]")).getText();
				if(listDName.contains(dName))
				{
					RC_Global.clickUsingXpath(driver, "//*[text()=' My Dashboards ']/../ul/li["+i+"]", "DashboardGroup1", false, true);
					break;
				}
			}
		}
		RC_Global.waitElementVisible(driver, 60, "//span[text()='Open Maintenance POs']", "Dashboard data's are displayed in the main page", false, true);
			
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Metrics", "Total Fleet Size", "List Of Fleet","", false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Metrics", "Units on Lease", "Units On Lease", "",false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Metrics", "Open End Leased Vehicles", "Units On Lease","", false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Metrics", "Closed End Leased Vehicles", "Units On Lease", "",false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Metrics", "Services Only Vehicles", "List Of Fleet","", false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Metrics", "Units on Maintenance", "Units On Maintenance","", false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Metrics", "Units on Fuel", "Units On Fuel","", false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Metrics", "Active Pool Units", "List Of Fleet","", false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Metrics", "Due for Replacements - Open End", "","", false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Metrics", "Due for Replacements - Close End", "","", false);
		//due to bug, Due for Replacements - Open End and Due for Replacements - Close End are not displaying in the Fleet Metrics section
		//so the script will fail for line 112,113
		
		RC_Manage.validateDashboardGroupSection(driver, "Exceptions & Alerts", "Open Maintenance POs", "Open Purchase Orders","", false);
		RC_Manage.validateDashboardGroupSection(driver, "Exceptions & Alerts", "Maintenance POs Pending Approval", "Purchase Orders Pending Approval","1", false);
		RC_Manage.validateDashboardGroupSection(driver, "Exceptions & Alerts", "Units Missing Lube/Oil/Filter Service", "Units Missing Lube/Oil/Filter Service","2", false);
		RC_Manage.validateDashboardGroupSection(driver, "Exceptions & Alerts", "Plates Coming Due", "Plate Expiration", "3",false);
		RC_Manage.validateDashboardGroupSection(driver, "Exceptions & Alerts", "Fuel Transactions Exceeding $", "Fuel Transaction Exceeding Cost Gallons","4", false);
		RC_Manage.validateDashboardGroupSection(driver, "Exceptions & Alerts", "Fuel Transaction Exceeding Gallons", "Fuel Transaction Exceeding Cost Gallons","5", false);
		RC_Manage.validateDashboardGroupSection(driver, "Exceptions & Alerts", "Same Day Fuel Transactions", "Same Day Fuel Exceptions","6", false);
		RC_Manage.validateDashboardGroupSection(driver, "Exceptions & Alerts", "Units with Fuel Transactions Over Tank Capacity", "Fuel Transactions Over Tank Capacity","7", false);
		RC_Manage.validateDashboardGroupSection(driver, "Exceptions & Alerts", "Drivers with Non-Sequential Odometers", "Non Sequential Odometer","8", false);
		
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Facts", "Average Price per Gallon", "Fuel Transaction Detail","", false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Facts", "Average Maintenance Cost per Service", "Maintenance History Detail","1", false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Facts", "Average Maintenance Cost per Unit", "Maintenance History Summary","2", false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Facts", "Average Fuel Cost per Unit", "Fuel Summary By Vehicle","3", false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Facts", "Average # of Fuel Transactions per Unit", "Fuel Summary By Vehicle","4", false);
		
		//step no- 19,24 commented in RC_Manage->validateDashboardGroup1GraphSection() due to expected results are not coming
		
		RC_Manage.validateDashboardGroup1GraphSection(driver, "Total Monthly Maintenance Spend", false);
		RC_Manage.validateDashboardGroup1GraphSection(driver, "Total Monthly Fuel Spend", false);
		RC_Manage.validateDashboardGroup1GraphSection(driver, "Total Monthly Lease Spend", false);	
		
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
