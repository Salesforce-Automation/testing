package Manage.Administration.DashboardAdministration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_5_10 {
	public void DashboardGroup_2(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String dName="DashboardGroup2";JavascriptExecutor executor = (JavascriptExecutor) driver;
		String[] fleetMatrices= {"Total Fuel Spend","Total Maintenance Spend","Total Maintenance Savings","Total Lease Spend","Preferred Vendor Utilization % "};
		String[] fleetExceptionsAndAlerts= {"Drivers Missing E-Mail","Missing Plate State","Closed End Vehicles Past Term","Under-Utilized Vehicles","Fuel Purchases Off Hours"};
		String[] fleetFacts= {"CPM Maintenance","CPM Fuel","Non-PM Cost per Service","Average Fleet Age","Average Fleet Mileage"};
		String[] graphics= {"National Account Utilization","Average Fuel Price per Gallon","Average Maintenance Cost per Unit"};

		RC_Global.login(driver);
		RC_Global.enterCustomerFocus(driver, "LS008737", false);
		if(driver.findElement(By.xpath("(//span[text()='Fleet Metrics'])[1]")).isDisplayed())
			RC_Global.clickUsingXpath(driver, "//li[@class='dashboard-icon'][1]/button/i", "Dashboard Icon", false, false);
		RC_Global.clickUsingXpath(driver, "((//li[@class='dashboard-icon'])[1]/following-sibling::li/button/i)[1]", "Dashboard Lists", false, false);
		Thread.sleep(1000);
		
		RC_Global.createNode(driver, dName+" Existence Status");
		if(driver.findElements(By.xpath("//div[div[(text()= ' My Dashboards ')]]//li[contains(., 'Group2')]")).size()==1)
		{
			queryObjects.logStatus(driver, Status.PASS, dName, "Already Created", null);
			RC_Global.clickUsingXpath(driver, "//div[div[(text()= ' My Dashboards ')]]//li[contains(., 'Group2')]", dName, false, true);
		}
		else
		{
			queryObjects.logStatus(driver, Status.PASS, dName, "is not created", null);
			RC_Global.navigateTo(driver, "Manage", "Administration", "Dashboard Administration");
			RC_Global.clickButton(driver, "Add New", false, true);
			RC_Global.clickUsingXpath(driver, "(//*[text()='Dashboard Administration'])[2]/../i[1]", "Close Dashboard Administration", false, false);
			RC_Global.panelAction(driver, "expand", "Dashboard Administration", false, true);
			Select dashboardDropDown=new Select(driver.findElement(By.xpath("//label[text()='Dashboard']/following-sibling::select")));
			if(dashboardDropDown.getFirstSelectedOption().getText().contains("Default"))
			{
				dashboardDropDown.selectByIndex(0);
			}
			WebElement dNameField = driver.findElement(By.xpath("//*[text()='Dashboard Name']/following-sibling::input"));
			RC_Global.enterInput(driver, dName, dNameField, false, true);

			RC_Global.createNode(driver, "Select checkboxes from Fleet Metrics");
			for(int j=0;j<fleetMatrices.length;j++)
			{
				RC_Manage.selectCheckBoxesDashboardAdminstration(driver, fleetMatrices[j],"Fleet Metrics", false);
			}

			RC_Global.createNode(driver, "Select checkboxes from Fleet Exceptions and Alerts");
			for(int j=0;j<fleetExceptionsAndAlerts.length;j++)
			{
				RC_Manage.selectCheckBoxesDashboardAdminstration(driver, fleetExceptionsAndAlerts[j],"Fleet Exceptions and Alerts", false);
			}

			RC_Global.createNode(driver, "Select checkboxes from Fleet Facts");
			for(int j=0;j<fleetFacts.length;j++)
			{
				RC_Manage.selectCheckBoxesDashboardAdminstration(driver, fleetFacts[j],"Fleet Facts", false);
			}

			RC_Global.createNode(driver, "Select checkboxes from Graphics");
			for(int j=0;j<graphics.length;j++)
			{
				RC_Manage.selectCheckBoxesDashboardAdminstration(driver, graphics[j],"Graphics", false);
			}

			executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//span[text()='Dashboard Administration'])[2]")));
			RC_Global.clickUsingXpath(driver, "(//button[text()=' Save'])[1]", "Save", false, true);
			Thread.sleep(6000);
			try {
//			if(driver.findElements(By.xpath("(//*[text()='Update Successful'])[3]")).size()>0)
				RC_Global.waitElementVisible(driver, 30, "(//h4[text()='Update Successful'])[1]", "Update Successful message", true, true);
				queryObjects.logStatus(driver, Status.PASS, "Update Successful message is displayed", "", null);
			}
			catch(Exception e) {
				queryObjects.logStatus(driver, Status.FAIL, "Update Successful message is not displayed", "", null);
			}
			RC_Global.panelAction(driver, "close", "Dashboard Administration", false, true);
			if(driver.findElements(By.xpath("(//span[text()='Fleet Metrics'])[1]")).size()>0)
				RC_Global.clickUsingXpath(driver, "//li[@class='dashboard-icon'][1]/button/i", "Dashboard Icon", false, false);
			RC_Global.clickUsingXpath(driver, "((//li[@class='dashboard-icon'])[1]/following-sibling::li/button/i)[1]", "Dashboard Lists", false, false);
			
			RC_Global.createNode(driver, dName+" Creation Status");
			if(driver.findElements(By.xpath("//div[div[(text()= ' My Dashboards ')]]//li[contains(., 'Group2')]")).size()==1)
			{
				queryObjects.logStatus(driver, Status.PASS, dName+" creation", "Successful", null);
				RC_Global.clickUsingXpath(driver, "//div[div[(text()= ' My Dashboards ')]]//li[contains(., 'Group2')]", dName, false, true);
			}
			else
			{
				queryObjects.logStatus(driver, Status.FAIL, dName+" creation", "Unsuccessful", null);
			}
		}
		RC_Global.waitElementVisible(driver, 60, "//span[text()='Drivers Missing E-Mail']", "Dashboard data's are displayed in the main page", false, true);
			
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Metrics", "Total Fuel Spend", "Fuel Summary By Vehicle","", false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Metrics", "Total Maintenance Spend", "Maintenance History Summary", "",false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Metrics", "Total Maintenance Savings", "Maintenance History Summary","", false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Metrics", "Total Lease Spend", "List Of Fleet", "",false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Metrics", "Preferred Vendor Utilization % ", "Preferred Vendor Utilization","", false);
	
		RC_Manage.validateDashboardGroupSection(driver, "Exceptions & Alerts", "Drivers Missing E-Mail", "Drivers Missing Email","", false);
		RC_Manage.validateDashboardGroupSection(driver, "Exceptions & Alerts", "Missing Plate State", "Missing Plate/State","1", false);
		RC_Manage.validateDashboardGroupSection(driver, "Exceptions & Alerts", "Closed End Vehicles Past Term", "Replacement Report","2", false);
		RC_Manage.validateDashboardGroupSection(driver, "Exceptions & Alerts", "Under-Utilized Vehicles", "Under Utilized Vehicles","3",false);
		RC_Manage.validateDashboardGroupSection(driver, "Exceptions & Alerts", "Fuel Purchases Off Hours", "Off Hours Purchases","4", false);
		
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Facts", "CPM Maintenance", "Units On Maintenance","", false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Facts", "CPM Fuel", "Units On Fuel","1", false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Facts", "Non-PM Cost per Service", "Maintenance Repairs By Type","2", false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Facts", "Average Fleet Age", "List Of Fleet","3", false);
		RC_Manage.validateDashboardGroupSection(driver, "Fleet Facts", "Average Fleet Mileage", "List Of Fleet","4", false);
		
		//step no- 19,30 commented in RC_Manage->validateDashboardGroup2GraphSection() due to expected results are not coming
		
		RC_Manage.validateDashboardGroup2GraphSection(driver, "National Account Utilization", true);
		RC_Manage.validateDashboardGroup2GraphSection(driver, "Average Fuel Price per Gallon", true);
		RC_Manage.validateDashboardGroup2GraphSection(driver, "Average Maintenance Cost per Unit", false);
		
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
