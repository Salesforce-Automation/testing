package Manage.Administration.ClientDataSetup;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_2_03 {
	
	

	public void ClientDataSetup_ActiveInactive(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		WebElement Inactive=null;
		String FirstName="";
		WebElement Active=null;
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Client Data Setup";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.enterCustomerNumber(driver, "LS008628", "", "", false);
		
		RC_Global.waitElementVisible(driver, 30, "//table//tbody//tr", "Client Setup grid is displayed", true,true);
		RC_Global.verifyAsHyperlinkByLinkName(driver, "Inactive", false);
//		String Inactive = driver.findElement(By.xpath("(//span[text()=' Inactive '])[1]")).getText();
		
		Inactive=driver.findElement(By.xpath("(//span[text()=' Inactive '])[1]"));
		Inactive.click();
	    RC_Global.verifyDisplayedMessage(driver, "Deactivation Successful", false);
	    
	    Active=driver.findElement(By.xpath("(//span[text()=' Inactive '])[1]"));
		Active.click();
	    RC_Global.verifyDisplayedMessage(driver, "Activation Successful", false); 
	    
	    RC_Global.clickButton(driver, "Add New Client Data", false,true);
	    RC_Global.validateSpecifiedSearchFilters(driver, "Name;Description", false);
	    
	    WebElement element = driver.findElement(By.xpath("//input[@placeholder='Name']"));
	    String CDName = "ClientData_Sample"+RandomStringUtils.randomNumeric(2);
		RC_Global.enterInput(driver, CDName, element  , false,true);
		
		RC_Global.clickUsingXpath(driver, "//input[contains(@ng-model,'IsRequiredIndicator')]", "Mandatory", false,true);
	//	RC_Global.clickUsingXpath(driver, "//input[contains(@ng-model,'IsActive')]", "InActive", false);
	    RC_Global.clickButton(driver, "Save ",true,true);
	    
		RC_Global.panelAction(driver, "close", "Client Data Setup", false,true);
        RC_Global.navigateTo(driver,"Manage","Administration","Driver Data Change");
        
        RC_Global.validateHeaderName(driver, "Driver Data Change", false);
		RC_Global.enterCustomerNumber(driver, "LS008628", "", "", false);
		RC_Global.clickButton(driver, "Search", false,true);
		
		RC_Global.waitElementVisible(driver, 60, "(//td[contains(@title,'Open Driver Change')])[1]", "Driver Details link", false,true);

		RC_Global.clickUsingXpath(driver, "(//td[contains(@title,'Open Driver Change')])[1]", "Driver Details", false,true);
		RC_Global.panelAction(driver, "close", "Driver Data Change", false,true);

		RC_Global.panelAction(driver, "expand", "Driver Details", false,true);
		RC_Global.waitElementVisible(driver, 60, "//h3[text()='Client Data Definitions']", "Client Data Definitions", false,true);
		
		String Owner = driver.findElement(By.xpath("(//select[contains(@ng-model,'clientDataValue')])[1]")).getText();
		
		String ClientData_Sample1=driver.findElement(By.xpath("//label[text()='"+CDName+"']")).getText();

		queryObjects.logStatus(driver, Status.PASS, "Newly added Client data field reflecting as expected", ClientData_Sample1, null);
		
		
		RC_Global.panelAction(driver, "close", "Driver Details", false,true);

		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
	//	RC_Global.panelAction(driver, "expand", "Client Data Setup", false,true);

		RC_Global.enterCustomerNumber(driver, "LS008628", "", "", false);

		
		try {
			Thread.sleep(1000);
			List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("//table//tbody//tr"));  
			int rowcnt=Getgridrowcnt.size();
			Boolean	firstpage=false;
			
			for(int i=1; i<=rowcnt;i++) {
				WebElement sub = driver.findElement(By.xpath("//tr["+i+"]//td[2]"));
				String Cname = sub.getText();
				if(!Cname.isEmpty()) {
					WebElement Status = driver.findElement(By.xpath("//tbody//tr[\"+i+\"]//td[7]//span"));
					WebElement clmn = driver.findElement(By.xpath("//tbody//tr["+i+"]//td[2]"));
				String	Name = clmn.getText();
					if((Name.equals(CDName))) {
					Thread.sleep(2000);
					Status.click();
				    RC_Global.verifyDisplayedMessage(driver, "Deactivation Successful", false);

					break;}
				}
			}
	}
		catch (Exception e){
			queryObjects.logStatus(driver, Status.FAIL, "Status hyperlink clicking unsuccesful", e.getLocalizedMessage(), e);	
			}

       
		RC_Global.panelAction(driver, "close", "Client Data Setup", false,true);
        RC_Global.navigateTo(driver,"Manage","Administration","Driver Data Change");
        
        RC_Global.validateHeaderName(driver, "Driver Data Change", false);
		RC_Global.enterCustomerNumber(driver, "LS008628", "", "", false);
		RC_Global.clickButton(driver, "Search", false,true);
		
		RC_Global.waitElementVisible(driver, 60, "(//td[contains(@title,'Open Driver Change')])[1]", "Driver Details link", false,true);
		RC_Global.clickUsingXpath(driver, "(//td[contains(@title,'Open Driver Change')])[1]", "Driver Details", false,true);
		
	//	RC_Global.panelAction(driver, "close", "Client Data Setup", false,true);

		RC_Global.panelAction(driver, "expand", "Driver Details", false,true);
		RC_Global.waitElementVisible(driver, 60, "//h3[text()='Client Data Definitions']", "Client Data Definitions", false,true);
		
	    RC_Global.validateSpecifiedSearchFilters(driver, ""+CDName+"", false);
		queryObjects.logStatus(driver, Status.PASS, "Inactive Client data field not displaying in client data definition as expected", ClientData_Sample1, null);
		RC_Global.panelAction(driver, "close", "Driver Details", false,true);
		RC_Global.panelAction(driver, "close", "Driver Data Change", false,true);		
		
		//Reset the changes
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
	//	RC_Global.panelAction(driver, "expand", "Client Data Setup", false,true);
		Thread.sleep(2000);
		RC_Global.enterCustomerNumber(driver, "LS008628", "", "", false);
		Thread.sleep(2000);
		int eleCnt = driver.findElements(By.xpath("(//td[2][text()='"+CDName+"']/../td[6]/span)")).size();
		for (int i = 1; i <= eleCnt; i++) {
			driver.findElement(By.xpath("(//td[2][text()='"+CDName+"']/../td[6]/span)[1]")).click();
			if (driver.findElement(By.xpath("//input[@ng-model='clientDataField.IsRequiredIndicator']")).isSelected()) {
				driver.findElement(By.xpath("//input[@ng-model='clientDataField.IsRequiredIndicator']")).click();
			}
			if (driver.findElement(By.xpath("//input[@ng-model='clientDataField.IsActiveIndicator']")).isSelected()) {
				driver.findElement(By.xpath("//input[@ng-model='clientDataField.IsActiveIndicator']")).click();
			}
			RC_Global.clickButton(driver, "Save ",false, true);
			RC_Global.waitElementVisible(driver, 60, "(//span[text()='Client Data Setup'])[2]", "Client Data Setup",false, false);
		}
		
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
}
				}
				
