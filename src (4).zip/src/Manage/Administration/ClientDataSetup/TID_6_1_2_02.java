package Manage.Administration.ClientDataSetup;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_2_02 {

	public void ClientDataSetup_AddNewDataSetup(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Client Data Setup";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.enterCustomerNumber(driver, "LS007076", "", "", false);
		RC_Global.waitElementVisible(driver, 30, "//table//tbody//tr", "Client Setup grid is displayed", true, true);
		//step 4
		List<WebElement> clientData= driver.findElements(By.xpath("//tbody/tr/td[1]"));
		for (int i = 1; i <=clientData.size(); i++) {
			String withorder = driver.findElement(By.xpath("//tbody/tr/td[text()='Client Data Value: "+i+"']")).getText();
			queryObjects.logStatus(driver, Status.PASS, "Validation of Client Data value with order number: ", withorder, null);
		}
		String Name = driver.findElement(By.xpath("//tbody/tr[1]/td[text()='Client Data Value: 1']//following::td[1]")).getText();
		queryObjects.logStatus(driver, Status.PASS, "The value of Name column is: ", Name, null);
		String dataType = driver.findElement(By.xpath("//tbody/tr[1]/td[text()='Client Data Value: 1']//following::td[2]")).getText();
		queryObjects.logStatus(driver, Status.PASS, "The value of Data Type column is: ", dataType, null);
		if (driver.findElements(By.xpath("//input[@disabled='' and @ng-model ='item.IsRequiredIndicator']")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Mandatory column field checkboxes are disabled", "Successfully", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Mandatory column field checkboxes are not disabled", "", null);
		if (driver.findElements(By.xpath("//input[@disabled='' and @ng-model ='item.UseForOrderingIndicator']")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Use For Ordering column field checkboxes are disabled", "Successfully", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Use For Ordering column field checkboxes are not disabled", "", null);
		
		RC_Global.verifyAsHyperlinkByLinkName(driver, "Edit", false);
		RC_Global.verifyAsHyperlinkByLinkName(driver, "Inactive", false);
		RC_Global.clickButton(driver, "Add New Client Data",true, true);
		RC_Global.waitElementVisible(driver, 60, "//span[text()='Client Data Values']", "Client Data Values",false, true);
		//step 6
		RC_Global.validateSpecifiedSearchFilters(driver, "Name;Description", false);
		RC_Manage.checkBoxValidation(driver, "Mandatory;Use for Ordering;Is Active", false);
		for(int i=1;i<=9;i++)
		{
			if(driver.findElements(By.xpath("//input[@value='"+i+"']")).size()>0)
			{
				String dataTypeValue =driver.findElement(By.xpath("//input[@value='"+i+"']")).getText();
				queryObjects.logStatus(driver, Status.PASS, "The Data Type Values are:", dataTypeValue, null);
				break;
			}
		}
		RC_Global.clickButton(driver, "Save ",false, true);
		
		RC_Global.createNode(driver,"Verify the displayed error message");
		RC_Global.verifyDisplayedMessage(driver, "Name is a required field.", false);
		
		WebElement element = driver.findElement(By.xpath("//input[@placeholder='Name']"));
		RC_Global.enterInput(driver, "ClientData_Sample", element  , false, true);
		RC_Global.clickUsingXpath(driver, "//input[contains(@ng-model,'IsActive')]", "InActive", false, true);
	    RC_Global.clickButton(driver, "Save ",true, true);
	    RC_Global.waitElementVisible(driver, 60, "(//span[text()='Client Data Setup'])[2]", "Client Data Setup",false, true);
	    RC_Global.clickButton(driver, "History",true, true);
	    RC_Global.panelAction(driver, "close", "Client Data Setup", false, true);
		RC_Global.panelAction(driver, "expand", "Client Data History", false, true);
		RC_Global.waitElementVisible(driver, 30, "//table//tbody//tr[1]", "Client Data History is displayed", true, false);
		//String userName = driver.findElement(By.xpath("//span[contains(@ng-show,'user.FullName') and @id='Span1']")).getText();
		RC_Manage.VerifyUsernameCreatedDate(driver, false);
		RC_Global.clickUsingXpath(driver, "//tbody[1]/tr[1]/td[6]/a[text()='View']", "View", false, true);
		
		String newHistoryValue=driver.findElement(By.xpath("//div//h4[text()='New Field Details']//following::div[2]//div[2]")).getText();
		String newHistoryValue1=driver.findElement(By.xpath("//div//h4[text()='New Field Details']//following::div[8]//div[2]")).getText();
		String newHistoryValue2=driver.findElement(By.xpath("//div//h4[text()='New Field Details']//following::div[11]//div[2]")).getText();
		String newHistoryValue3=driver.findElement(By.xpath("//div//h4[text()='New Field Details']//following::div[14]//div[2]")).getText();
		
		queryObjects.logStatus(driver, Status.PASS, "New Fields Details is displayed in Status Changed section", newHistoryValue, null);
		queryObjects.logStatus(driver, Status.PASS, "New Fields Details is displayed in Status Changed section", newHistoryValue1, null);
		queryObjects.logStatus(driver, Status.PASS, "New Fields Details is displayed in Status Changed section", newHistoryValue2, null);
		queryObjects.logStatus(driver, Status.PASS, "New Fields Details is displayed in Status Changed section", newHistoryValue3, null);
		
		RC_Global.clickUsingXpath(driver, "((//tbody/tr)[1]/td)[1]", "Changes", false, true);
		
		String newHistoryChanges=driver.findElement(By.xpath("(//tbody[1]/tr[2]//td[text()='Name']//..//td[3])[1]")).getText();
		String newHistoryChanges1=driver.findElement(By.xpath("(//tbody[1]/tr[2]//td[text()='Is Required']//..//td[3])[1]")).getText();
		String newHistoryChanges2=driver.findElement(By.xpath("(//tbody[1]/tr[2]//td[text()='Data Type']//..//td[3])[1]")).getText();
		
		queryObjects.logStatus(driver, Status.PASS, "Changed Fields are Displayed under the grid", newHistoryChanges, null);
		queryObjects.logStatus(driver, Status.PASS, "Changed Fields are Displayed under the grid", newHistoryChanges1, null);
		queryObjects.logStatus(driver, Status.PASS, "New Fields Details is displayed in Status Changed section", newHistoryChanges2, null);
		
		RC_Global.downloadAndVerifyFileDownloaded(driver,"Export","Export To Excel Functionality", true);
		RC_Global.panelAction(driver, "close", "Client Data History", false, false);
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
