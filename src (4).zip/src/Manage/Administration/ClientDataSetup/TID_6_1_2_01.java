package Manage.Administration.ClientDataSetup;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_2_01 {

	public void ClientDataSetup_FieldSetupAtCustomerLevel(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		String custNum = "LS010143";String dataTypeValue = "";
	
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,"Manage","Administration","Client Data Setup");
		RC_Global.enterCustomerNumber(driver, custNum, "", "", false);
		RC_Global.waitElementVisible(driver, 30, "//table//tbody//tr", "Client Setup grid is displayed", true, false);
		
		//Add client data field and validate for customer structure levels - customer level
		RC_Global.clickButton(driver, "Add New Client Data",true, true);
		RC_Global.waitElementVisible(driver, 60, "//span[text()='Client Data Values']", "Client Data Values",false, false);
		
		RC_Global.validateSpecifiedSearchFilters(driver, "Name;Description", false);
		RC_Manage.checkBoxValidation(driver, "Mandatory;Use for Ordering;Is Active", false);
		for(int i=1;i<=9;i++)
		{
			if(driver.findElements(By.xpath("//input[@value='"+i+"']")).size()>0)
			{
				dataTypeValue =driver.findElement(By.xpath("//input[@value='"+i+"']/..")).getText();
				queryObjects.logStatus(driver, Status.PASS, "The Data Type Values are:", dataTypeValue, null);
				break;
			}
		}
		String CDName = "ClientData_Test" +RandomStringUtils.randomNumeric(2);
		RC_Global.enterInput(driver, CDName, driver.findElement(By.xpath("//input[@placeholder='Name']")), false, true);
//		RC_Global.clickUsingXpath(driver, "//input[contains(@ng-model,'IsActive')]", "InActive", false, true);	
		if(dataTypeValue.equalsIgnoreCase("Picklist"))
		{
			WebElement addPicklist = driver.findElement(By.xpath("//input[@ng-model='addOptionText']"));
	        RC_Global.enterInput(driver, "Sample_Picklist", addPicklist  , false,true);
	        RC_Global.clickButton(driver, "Add",true,true);
	        RC_Global.enterInput(driver, "Test_Picklist", addPicklist  , false,true);
	        RC_Global.clickButton(driver, "Add",true,true);
	        RC_Global.enterInput(driver, "Add_Picklist", addPicklist  , false,true);
	        RC_Global.clickButton(driver, "Add",true,true);			
		}
		RC_Global.clickButton(driver, "Save",true, true);
		RC_Global.waitElementVisible(driver, 30, "(//span[text()='Client Data Setup'])[2]", "Client Data Setup",false, false);
		RC_Global.panelAction(driver, "close", "Client Data Setup", false, false);
		
	//	Validate the newly added client data field displays on fleet level
		RC_Manage.validateAddedCDCusStructurelevel(driver, custNum, "Fleet level", CDName, false);
	//  Validate the cancel action 
	    RC_Global.clickButton(driver, "Cancel",true, true);
	    RC_Global.waitElementVisible(driver, 30, "(//span[text()='Client Data Setup'])[2]", "Client Data Setup",false, false);
	    //RC_Global.panelAction(driver, "close", "Client Data Setup", false, false);

   //	Validate the newly added client data field displays on Account level  
	    RC_Manage.validateAddedCDCusStructurelevel(driver, custNum, "Account level", CDName, false);
	    RC_Global.clickButton(driver, "Cancel",true, true);
	    RC_Global.waitElementVisible(driver, 30, "(//span[text()='Client Data Setup'])[2]", "Client Data Setup",false, false);
	    //RC_Global.panelAction(driver, "close", "Client Data Setup", false, false);
	
	// 	Validate the newly added client data field displays on SubAccount level
	    RC_Manage.validateAddedCDCusStructurelevel(driver, custNum, "SubAccount level", CDName, false);
	    RC_Global.clickButton(driver, "Cancel",true, true);
	    RC_Global.waitElementVisible(driver, 30, "(//span[text()='Client Data Setup'])[2]", "Client Data Setup",false, false);
	    //RC_Global.panelAction(driver, "close", "Client Data Setup", false, false);
	    
	//  Validate Inactivated existing client Data at custLevel 
	    RC_Manage.clientdataStatusChange(driver, custNum, "Customer level", "Active", CDName, false);
	    RC_Manage.clientdataStatusChange(driver, custNum, "Fleet level", "Active", "", false);
	    RC_Manage.clientdataStatusChange(driver, custNum, "Account level", "Active", "", false);
	    RC_Manage.clientdataStatusChange(driver, custNum, "SubAccount level", "Active","", false);
	    RC_Manage.clientdataStatusChange(driver, custNum, "RevertChange", "",CDName, false);
	    
	//	Edit the existing client data field(Name & Data type)
	    //RC_Global.navigateTo(driver,"Manage","Administration","Client Data Setup");
	    driver.findElement(By.xpath("//div[@class='input-group']/input[@name='customerInput']")).clear();
	    RC_Global.enterCustomerNumber(driver, custNum, "", "", false);

	    RC_Global.clickUsingXpath(driver, "(//td[2][text()='"+CDName+"']/../td[6]/span)[1]", "Client data name", false, true);
	    Thread.sleep(2000);
	    RC_Global.waitElementVisible(driver, 60, "//span[text()='Client Data Values']", "Client Data Values",false, false);
	    String Name = driver.findElement(By.xpath("//input[@name='name']")).getAttribute("value");
	    if(CDName.equals(Name))
	    {
	    queryObjects.logStatus(driver, Status.INFO, "Client Data Name from grid result ", Name, null);
	    }
	    dataTypeValue= "";
	    WebElement DTV = null;
	    for(int i=1;i<=9;i++)
		{
			if(driver.findElement(By.xpath("//input[@value='"+i+"']")).isSelected())
			{
				DTV=driver.findElement(By.xpath("//div[input[@value='"+i+"']]"));
				dataTypeValue = DTV.getText();
				queryObjects.logStatus(driver, Status.PASS, "Existing DataType value ", dataTypeValue, null);
				 break;
			}
		}
	    if(dataTypeValue.contains("Text"))
	    {
	    	RC_Global.clickUsingXpath(driver, "//div[text()='Picklist ']/input", "Picklist radio button", false, true);
	    	WebElement addPicklist = driver.findElement(By.xpath("//input[@ng-model='addOptionText']"));
	        RC_Global.enterInput(driver, "Sample_Picklist", addPicklist  , false,true);
	        RC_Global.clickButton(driver, "Add",true,true);
	        RC_Global.enterInput(driver, "Test_Picklist", addPicklist  , false,true);
	        RC_Global.clickButton(driver, "Add",true,true);
	        RC_Global.enterInput(driver, "Add_Picklist", addPicklist  , false,true);
	        RC_Global.clickButton(driver, "Add",true,true);	
	    	
	    }
	    else
	    {
	    	RC_Global.clickUsingXpath(driver, "//div[text()='Text ']/input", "Text radio button", false, true);
	    }	
	    
	    Thread.sleep(2000);
	    String UpdateddataTypeValue = "";
	    for(int j=1;j<=9;j++)
		{
			if(driver.findElement(By.xpath("//input[@value='"+j+"']")).isSelected())
			{
				UpdateddataTypeValue = driver.findElement(By.xpath("//div[input[@value='"+j+"']]")).getText();
				queryObjects.logStatus(driver, Status.PASS, "Updated DataType value ", UpdateddataTypeValue, null);
				break;
			}
	   
		}
	    RC_Global.clickButton(driver, "Save ",false, true);
	    RC_Global.waitElementVisible(driver, 30, "(//span[text()='Client Data Setup'])[2]", "Client Data Setup",false, false);
	    RC_Global.panelAction(driver, "close", "Client Data Setup", false, false);
	    
	  //Edit the existing client data field(Name & Data type) and validate for customer structure levels
	    RC_Manage.validateEditedCDCusStructurelevel(driver, custNum, "Fleet level", CDName, UpdateddataTypeValue, false);
	    RC_Manage.validateEditedCDCusStructurelevel(driver, custNum, "Account level", CDName, UpdateddataTypeValue, false);
	    RC_Manage.validateEditedCDCusStructurelevel(driver, custNum, "SubAccount level", CDName, UpdateddataTypeValue, false);
	    
	    //Validate updated(Modified) client data field
	    RC_Global.navigateTo(driver, "Manage", "Administration", "Driver Data Change");
	    
	    RC_Global.waitElementVisible(driver, 30, "(//span[text()='Driver Data Change'])[2]", "Driver Data Change screen", false, false);
	    RC_Global.enterCustomerNumber(driver, custNum, "", "", false);
	    RC_Global.clickButton(driver, "Search", false, true);
	    //RC_Global.panelAction(driver, "expand", "Driver Data Change", false, true);
	    RC_Manage.driverNameSelection(driver, "", false);
	    RC_Global.waitElementVisible(driver, 30, "//span[text()='Driver Details']", "Driver Details screen", false, false);
	    RC_Global.panelAction(driver, "close", "Driver Data Change", false, false);
	    RC_Global.panelAction(driver, "expand", "Driver Details", false, false);
	    
	    RC_Global.createNode(driver, "Validate the CD in Driver details screen");
	    WebElement element1 = driver.findElement(By.xpath("//h3[text()='Client Data Definitions']"));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element1);
	   
	    
	    Thread.sleep(2000);
	    if (driver.findElements(By.xpath("//label[text()='"+CDName+"']")).size()>0)
	    {
	    	if(UpdateddataTypeValue.equals("Text"))
	    	{
	    		Thread.sleep(2000);
	    		if(driver.findElements(By.xpath("//label[text()='"+CDName+"']/../div//input")).size()>0)
	    		{
	    			queryObjects.logStatus(driver, Status.PASS, "Modified client Data matches under driver details-client defininition ", Name, null);
	    		}
	    		else
	    		{
	    			queryObjects.logStatus(driver, Status.FAIL, "Modified client Data not matches under driver details-client defininition ", Name, null);
	    		}
	    		
	    	}
	    	else if (UpdateddataTypeValue.equals("Picklist"))
	    	{
	    		Thread.sleep(2000);
	    		if(driver.findElements(By.xpath("//label[text()='"+CDName+"']/../div//select")).size()>0)
	    		{
	    			queryObjects.logStatus(driver, Status.PASS, "Modified client Data matches under driver details-client defininition ", Name, null);
	    		}
	    		else
	    		{
	    			queryObjects.logStatus(driver, Status.FAIL, "Modified client Data not matches under driver details-client defininition ", Name, null);
	    		}
	    	}
	    }
	    else
	    {
	    	queryObjects.logStatus(driver, Status.FAIL, "client Data not displays under driver details-client defininition ", Name, null);
	    }
	    
	    WebElement element2 = driver.findElement(By.xpath("//h5/span[text()='Driver Details']"));
	    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element2);
	    
	    RC_Global.panelAction(driver, "close", "Driver Details", false, false);
	    
	    
	    //Revert the Changes made for existing client data 
	    RC_Global.navigateTo(driver,"Manage","Administration","Client Data Setup");
	    RC_Global.enterCustomerNumber(driver, custNum, "", "", false);
	    driver.findElement(By.xpath("(//td[2][text()='"+CDName+"']/../td[6]/span)[1]")).click();
	    RC_Global.waitElementVisible(driver, 60, "//span[text()='Client Data Values']", "Client Data Values",false, false);
	    driver.findElement(By.xpath("//div[text()[normalize-space()='"+dataTypeValue+"']]/input")).click();
	    RC_Global.clickUsingXpath(driver, "//input[contains(@ng-model,'IsActive')]", "InActive", false, true);
	    RC_Global.clickButton(driver, "Save ",false, true);
	    RC_Global.waitElementVisible(driver, 60, "(//span[text()='Client Data Setup'])[2]", "Client Data Setup",false, false);
	    RC_Global.panelAction(driver, "close", "Client Data Setup", false, false);
	    
	    RC_Global.logout(driver, false);
	    
	}
}
