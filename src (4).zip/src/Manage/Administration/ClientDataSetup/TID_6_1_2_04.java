package Manage.Administration.ClientDataSetup;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;


public class TID_6_1_2_04 {
	public void EditClientData(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Client Data Setup";
		String oldValue="";
		String newValue="";
		String oldHistoryValue="";
		String newHistoryValue="";
		String cDataName = "";

		RC_Global.login(driver);
		String loggedUser = driver.findElement(By.xpath("//div[@class='bottom-nav bottom-right-menu']//div/ul[@class='nav-right list-unstyled pull-right user-menu']/li/a")).getText();
		RC_Global.waitElementVisible(driver, 10, "//span[text()='LS000000 - Merchants Portfolio']", "", false, false);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.enterCustomerNumber(driver, "LS007076", "", "", false);
		RC_Global.waitElementVisible(driver, 5, "//table//tbody", "Customer's Client Setup grid is displayed", true, false);
		cDataName = RC_Manage.ClientDataGridSelection(driver, "Active", false);
		int dataTypeValue=0;
		for(int i=1;i<=9;i++)
		{
			if(driver.findElement(By.xpath("//input[@value='"+i+"']")).isSelected())
			{
				dataTypeValue=i;
				break;
			}
		}
		if(dataTypeValue==2)
		{
			oldValue="PickList";
			if(driver.findElements(By.xpath("//select[@ng-model='selectedOption']")).size()>0 && 
					driver.findElements(By.xpath("//button[text()='Add']")).size()>0 && 
					driver.findElements(By.xpath("//button[text()='Remove']")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "User can Add or Remove options in picklist DATA TYPE", "", null);
			}
			RC_Global.clickUsingXpath(driver, "//input[@value='1']", "Text", true, true);
			if(driver.findElement(By.xpath("//input[@value='1']")).isSelected())
			{
				queryObjects.logStatus(driver, Status.PASS, "User can update any data type in the section ", "", null);
			}
			newValue="Text";
		}
		else
		{
			oldValue= driver.findElement(By.xpath("//input[@value='"+dataTypeValue+"']/..")).getText();
			RC_Global.clickUsingXpath(driver, "//input[@value='2']", "Picklist", true, true);
			if(driver.findElement(By.xpath("//input[@value='2']")).isSelected())
			{
				queryObjects.logStatus(driver, Status.PASS, "User can update any data type in the section ", "", null);
			}
			if(driver.findElements(By.xpath("//select[@ng-model='selectedOption']")).size()>0 && 
					driver.findElements(By.xpath("//button[text()='Add']")).size()>0 && 
					driver.findElements(By.xpath("//button[text()='Remove']")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "User can Add or Remove options in picklist DATA TYPE", "", null);
			}
			newValue="PickList";
		}
		RC_Global.clickButton(driver, "Save", true, true);
		RC_Global.waitElementVisible(driver, 60, "//table//tbody", "Client Data Setup page is displayed", true, true);
		RC_Global.clickButton(driver, "History", true, true);
		RC_Global.panelAction(driver, "close", "Client Data Setup", false, true);
		RC_Global.panelAction(driver, "expand", "Client Data History", false, true);
		RC_Global.waitElementVisible(driver, 10, "//table//tbody", "Client Data History is displayed", true, true);
		RC_Manage.VerifyUsernameCreatedDate(driver, false);
		driver.findElement(By.xpath("((//table/tbody/tr)[1]/td)[6]")).click();
		//RC_Global.scrollById(driver, "//h3[text()='Type Changed']");
		oldHistoryValue = driver.findElement(By.xpath("(//div[@class='row'])[1]/div[3]/div[2]")).getText().trim();
		newHistoryValue = driver.findElement(By.xpath("(//div[@class='row'])[2]/div[3]/div[2]")).getText().trim();
		Thread.sleep(2000);
		if(oldHistoryValue.equals(oldValue) && newHistoryValue.equals(newValue))
		{
			queryObjects.logStatus(driver, Status.PASS, "Old Field details and New Fields Details is displayed in Status Changed section", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Old Field details and New Fields Details value mismatch", "", null);
		}
		
		
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.panelAction(driver, "close", "Client Data History", false, true);
		RC_Global.enterCustomerNumber(driver, "LS007076", "", "", false);
		RC_Global.waitElementVisible(driver, 5, "(//table//tbody/tr)[1]", "Customer's Client Setup grid is displayed", true, false);
		RC_Manage.ResetClientDataSelection(driver, cDataName, false);
		if(oldValue.equals("PickList")) {
			RC_Global.clickUsingXpath(driver, "//input[@value='2']", "Text", true, true);
		} else {
			RC_Global.clickUsingXpath(driver, "//input[@value='2']", oldValue, true, true);
		}
		RC_Global.clickButton(driver, "Save", true, true);
		RC_Global.waitElementVisible(driver, 30, "(//table//tbody/tr)[1]", "Client Data Setup page is displayed", true, true);
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
		
	}
}
