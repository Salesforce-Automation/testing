package Manage.Administration.ClientDataSetup;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_2_06 {
	
	public void ExternalUser_EditClientDataForInactiveStatus(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Client Data Setup";
		String oldValue=""; String newValue="";
		
		
		RC_Global.externalUserLogin(driver, "kentuckytest3", "Yes");
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.waitElementVisible(driver, 30, "//table//tbody//tr", "Client Setup grid is displayed", true, false);
		//-------
	    RC_Global.clickButton(driver, "Add New Client Data",true, true);
	    RC_Global.waitElementVisible(driver, 60, "//span[text()='Client Data Values']", "Client Data Values",false, false);
	    WebElement element2 = driver.findElement(By.xpath("//input[@placeholder='Name']"));
		RC_Global.enterInput(driver, "Picklist_Testing", element2  , false, true);
		RC_Global.clickUsingXpath(driver, "//div[text()='Picklist ']//child::input[@type='radio']", "Picklist Data types", false, true);
		WebElement addPicklist = driver.findElement(By.xpath("//input[@ng-model='addOptionText']"));
        RC_Global.enterInput(driver, "Sample_Picklist", addPicklist  , false, true);
        RC_Global.clickButton(driver, "Add",true, false);
        RC_Global.enterInput(driver, "Test_Picklist", addPicklist  , false, true);
        RC_Global.clickButton(driver, "Add",true, false);
        RC_Global.enterInput(driver, "Add_Picklist", addPicklist  , false, true);
        RC_Global.clickButton(driver, "Add",true, false);
		RC_Global.clickUsingXpath(driver, "//input[contains(@ng-model,'IsActive')]", "InActive", false, true);
		RC_Global.clickButton(driver, "Save ",true, true);
		RC_Global.waitElementVisible(driver, 60, "(//span[text()='Client Data Setup'])[2]", "Client Data Setup",false, false);
		//------
		RC_Manage.ClientDataGridSelection(driver,"Inactive", false);
		RC_Global.waitElementVisible(driver, 60, "//span[text()='Client Data Values']", "Client Data Values",false, false);
	
		int dataTypeValue=0;
		for(int i=1;i<=9;i++)
		{
			if(driver.findElement(By.xpath("//input[@value='"+i+"']")).isSelected())
			{
				dataTypeValue=i;
				break;
			}
		}
		if(dataTypeValue==2)
		{
			oldValue="PickList";
			if(driver.findElements(By.xpath("//select[@ng-model='selectedOption']")).size()>0 && 
					driver.findElements(By.xpath("//button[text()='Add']")).size()>0 && 
					driver.findElements(By.xpath("//button[text()='Remove']")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "User can Add or Remove options in picklist DATA TYPE", "Successfully", null);
			}
			RC_Global.clickUsingXpath(driver, "//input[@value='1']", "Text", true, true);
			if(driver.findElement(By.xpath("//input[@value='1']")).isSelected())
			{
				queryObjects.logStatus(driver, Status.PASS, "User can update any data type in the section ", "Successfully", null);
			}
			newValue="Text";
		}
		else
		{
			oldValue= driver.findElement(By.xpath("//input[@value='"+dataTypeValue+"']/..")).getText();
			RC_Global.clickUsingXpath(driver, "//input[@value='2']", "Picklist", true, true);
			if(driver.findElement(By.xpath("//input[@value='2']")).isSelected())
			{
				queryObjects.logStatus(driver, Status.PASS, "User can update any data type in the section ", "Successfully", null);
			}
			if(driver.findElements(By.xpath("//select[@ng-model='selectedOption']")).size()>0 && 
					driver.findElements(By.xpath("//button[text()='Add']")).size()>0 && 
					driver.findElements(By.xpath("//button[text()='Remove']")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "User can Add or Remove options in picklist DATA TYPE", "Successfully", null);
			}
			newValue="PickList";
		}
		if (newValue=="PickList") {
			driver.findElement(By.xpath("//input[@ng-model='addOptionText']")).sendKeys("Test_Picklist"+RandomStringUtils.randomNumeric(3));
		     RC_Global.clickButton(driver, "Add",true, false);
		}
		 RC_Global.clickButton(driver, "Save ",true, true);
		    RC_Global.waitElementVisible(driver, 60, "(//span[text()='Client Data Setup'])[2]", "Client Data Setup",false, false);
		    
		    RC_Global.clickButton(driver, "History",true, true);
		    RC_Global.panelAction(driver, "close", "Client Data Setup", false, false);
			RC_Global.panelAction(driver, "expand", "Client Data History", false, true);
			RC_Global.waitElementVisible(driver, 30, "//table//tbody//tr[1]", "Client Data History is displayed", true, true);
			//String userName = driver.findElement(By.xpath("//span[contains(@ng-show,'user.FullName') and @id='Span1']")).getText();
			RC_Manage.VerifyUsernameCreatedDate(driver, false);
			RC_Global.clickUsingXpath(driver, "//tbody[1]/tr[1]/td[6]/a[text()='View']", "View", false, true);
			
			String newHistoryValue=driver.findElement(By.xpath("//div//h4[text()='New Field Details']//following::div[2]//div[2]")).getText();
			String newHistoryValue1=driver.findElement(By.xpath("//div//h4[text()='New Field Details']//following::div[8]//div[2]")).getText();
			String newHistoryValue2=driver.findElement(By.xpath("//div//h4[text()='New Field Details']//following::div[11]//div[2]")).getText();
			String newHistoryValue3=driver.findElement(By.xpath("//div//h4[text()='New Field Details']//following::div[14]//div[2]")).getText();
			
			queryObjects.logStatus(driver, Status.PASS, "New Fields Details is displayed in Status Changed section", newHistoryValue, null);
			queryObjects.logStatus(driver, Status.PASS, "New Fields Details is displayed in Status Changed section", newHistoryValue1, null);
			queryObjects.logStatus(driver, Status.PASS, "New Fields Details is displayed in Status Changed section", newHistoryValue2, null);
			queryObjects.logStatus(driver, Status.PASS, "New Fields Details is displayed in Status Changed section", newHistoryValue3, null);
			
			
			RC_Global.panelAction(driver, "close", "Client Data History", false, false);
			RC_Global.logout(driver, false);
			queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}

}
