package Manage.Administration.VehicleDetails;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_11_03 {
	public void VehicleDetails_ValidateTheSearchFiltersFunctionality(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String SearchFilters = "Unit Number;Customer Vehicle Number;Pool Name; Customer Number ;Full VIN or Last 8;Driver First Name;Driver Last Name;Plate State;Vehicle Status";
		WebDriverWait wait = new WebDriverWait(driver,60);
		String errorMsg = "Please enter a minimum of 8 characters for a VIN.";
		String custNum = "LS010116";

		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Vehicle Details");
        RC_Global.enterCustomerNumber(driver, custNum, "", "",false);
		RC_Global.clickButton(driver, "Search", false,true);

		
		
		RC_Global.validateSpecifiedSearchFilters(driver, SearchFilters, false);
        RC_Global.validateMultipleSelectionFilter(driver, "Active lease;Active services only;Cancelled;Closed;On Order;Pending Activation;Pending termination;Sold;Terminated lease;Terminated services only", false);
        
        RC_Global.createNode(driver, "Validate the preselected - vehicle status");
        RC_Global.validateMultipleSelectionFilter(driver, "Active lease;Active services only;On Order;Pending Activation;Pending termination", false);
        
        RC_Global.createNode(driver,"Verify Buttons Available in the Screen");
		RC_Global.buttonStatusValidation(driver, "Search", "Enable", false);
		RC_Global.buttonStatusValidation(driver, "Reset", "Enable", false);
		RC_Global.buttonStatusValidation(driver, "Advanced Search", "Enable", false);
		
//		RC_Global.waitElementVisible(driver, 60, "//tbody/tr","Row", false, false);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//tbody//tr)[1]")));															
        List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("//table//tbody//tr"));
        String drivername = ""; 
        String UnitNumber = "";
        String VIN = "";
        String PlateNum ="";
        String CVN = "";
        int rowcnt=Getgridrowcnt.size();
        boolean firstpage=false;
        boolean pagination=false;
        for(int i=1; i<=rowcnt;i++) {  
            WebElement CVNrow= driver.findElement(By.xpath("//tr["+i+"]//td[4]"));
            WebElement viewsub = driver.findElement(By.xpath("//tr["+i+"]//td[6]"));																		
            WebElement Unitnorow = driver.findElement(By.xpath("//tr["+i+"]//td[3]"));
            WebElement VINnorow = driver.findElement(By.xpath("//tr["+i+"]//td[6]"));
            WebElement PlateNumrow = driver.findElement(By.xpath("//tr["+i+"]//td[10]"));
            UnitNumber = Unitnorow.getText();
            VIN = VINnorow.getText();
            PlateNum = PlateNumrow.getText();
            Thread.sleep(2000);
            CVN = CVNrow.getText();									 
            if(!(CVN.isEmpty() && VIN.isEmpty() && PlateNum.isEmpty())) {
                WebElement driverclmn =driver.findElement(By.xpath("//tbody//tr["+i+"]//td[5]"));										   
                Thread.sleep(2000);
                drivername = driverclmn.getText();
                Thread.sleep(1000);
                if(!(drivername.equalsIgnoreCase("Unassigned") || drivername.contains("Pool")||drivername.contains("Unknown")||drivername.contains("Catering")) ) {
 //                   driver.findElement(By.xpath("//tbody//tr["+i+"]//td[2]")).click();
                Thread.sleep(1000);
                firstpage = true;
                break;}
            	}
            }
        String[] Driver = drivername.split(" ");

        queryObjects.logStatus(driver, Status.INFO, "Unit Number data---->", UnitNumber, null);
		queryObjects.logStatus(driver, Status.INFO, "CVN data---->", CVN, null);
		queryObjects.logStatus(driver, Status.INFO, "VIN data---->", VIN, null);
		queryObjects.logStatus(driver, Status.INFO, "DriverName data---->", drivername, null);
		queryObjects.logStatus(driver, Status.INFO, "Plate data---->", PlateNum, null);

		RC_Global.clickButton(driver, "Reset", false,false);
		RC_Global.createNode(driver, "Vehicle Movement -- Unit Number Search Filter Functionality Validation");
		RC_Global.enterCustomerNumber(driver, custNum, "", "",false);
		Thread.sleep(2000);
		RC_Global.enterInput(driver, UnitNumber, driver.findElement(By.xpath("//input[@placeholder='Unit Number']")), false, true);
		RC_Global.clickButton(driver, "Search", false,false);
		Thread.sleep(4000);
		if(driver.findElements(By.xpath("(//tbody/tr)[1]")).size()>0) {
        	queryObjects.logStatus(driver, Status.PASS, "Search Results are", "Found", null);
        	RC_Global.clickButton(driver, "Reset", false,false);
        }
		else if(driver.findElements(By.xpath("//h5/*[text()='Vehicle Details']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Validated the Search Results header as 'Vehicle Details'", "successfully", null);
			RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='Vehicle Details']])[1]", false,true);
		}
		else {
			queryObjects.logStatus(driver, Status.FAIL, "Search Results are Not", "Found", null);
        }
		Thread.sleep(3000);

		
		
		RC_Global.createNode(driver, "Vehicle Movement -- Customer Vehicle Number Search Filter Functionality Validation");
		RC_Global.navigateTo(driver, "Manage", "Administration", "Vehicle Details");
		RC_Global.enterCustomerNumber(driver, custNum, "", "",false);
		Thread.sleep(2000);
		RC_Global.enterInput(driver, CVN, driver.findElement(By.xpath("//input[@placeholder='Vehicle Number']")), false, true);
		RC_Global.clickButton(driver, "Search", false,false);
		Thread.sleep(4000);
		if(driver.findElements(By.xpath("(//tbody/tr)[1]")).size()>0) {
        	queryObjects.logStatus(driver, Status.PASS, "Search Results are", "Found", null);
        	RC_Global.clickButton(driver, "Reset", false,false);
        }
		else if(driver.findElements(By.xpath("//h5/*[text()='Vehicle Details']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Validated the Search Results header as 'Vehicle Details'", "successfully", null);
			RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='Vehicle Details']])[1]", false,true);
		}
		else {
			queryObjects.logStatus(driver, Status.FAIL, "Search Results are Not", "Found", null);
        }
		Thread.sleep(3000);

		RC_Global.createNode(driver, "Vehicle Movement -- VIN error message Validation");
		RC_Global.navigateTo(driver, "Manage", "Administration", "Vehicle Details");
		
		WebElement element2 = driver.findElement(By.xpath("//input[@placeholder='VIN']"));
		String Vinfst5dig = VIN.substring(0, 4);  
		RC_Global.enterInput(driver, Vinfst5dig, element2, false,false);
		RC_Global.clickButton(driver, "Search", false,false);
		RC_Global.verifyDisplayedMessage(driver, errorMsg, false);
		RC_Global.clickButton(driver, "Reset", false,false);
		
		RC_Global.createNode(driver, "Vehicle Movement -- VIN Search Filter Functionality Validation");
		RC_Global.enterCustomerNumber(driver, custNum, "", "",false);
		RC_Global.enterInput(driver, VIN, driver.findElement(By.xpath("//input[@placeholder='VIN']")), false, true);
		RC_Global.clickButton(driver, "Search", false,false);
		Thread.sleep(4000);
		
		if(driver.findElements(By.xpath("(//tbody/tr)[1]")).size()>0) {
        	queryObjects.logStatus(driver, Status.PASS, "Search Results are", "Found", null);
        	RC_Global.clickButton(driver, "Reset", false,false);
        }
		else if(driver.findElements(By.xpath("//h5/*[text()='Vehicle Details']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Validated the Search Results header as 'Vehicle Details'", "successfully", null);
			RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='Vehicle Details']])[1]", false,true);
		}
		else {
			queryObjects.logStatus(driver, Status.FAIL, "Search Results are Not", "Found", null);
        }
		Thread.sleep(3000);
	
		RC_Global.createNode(driver, "Vehicle Movement -- Driver First Name Search Filter Functionality Validation");
		RC_Global.navigateTo(driver, "Manage", "Administration", "Vehicle Details");
		RC_Global.enterCustomerNumber(driver, custNum, "", "",false);
		RC_Global.enterInput(driver, Driver[0], driver.findElement(By.xpath("//input[@placeholder='Driver First Name']")), false, true);
		RC_Global.clickButton(driver, "Search", false,false);
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("(//table//th)[1]")).size()>0) {
 			RC_Global.waitElementVisible(driver, 60, "(//tbody/tr)[1]","Row", false, false);
        	queryObjects.logStatus(driver, Status.PASS, "Search Results are", "Found", null);
        	RC_Global.clickButton(driver, "Reset", false,false);
        }
		else if(driver.findElements(By.xpath("//h5/span[text()='Vehicle Details']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Validated the Search Results header as 'Vehicle Details'", "successfully", null);
			RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='Vehicle Details']])[1]", false,true);
		}
		else {
			queryObjects.logStatus(driver, Status.FAIL, "Search Results are Not", "Found", null);
        }
		Thread.sleep(3000);

		
	    RC_Global.createNode(driver, "Vehicle Movement -- Driver Last Name Search Filter Functionality Validation");
	    if(driver.findElements(By.xpath("//h5/*[text()='Vehicle Details']")).size()>0)
	    {
	    	RC_Global.enterCustomerNumber(driver, custNum, "", "",false);
	 		RC_Global.enterInput(driver, Driver[1], driver.findElement(By.xpath("//input[@placeholder='Driver Last Name']")), false, true);
	 		RC_Global.clickButton(driver, "Search", false,false);
	 		Thread.sleep(2000);
	 		if(driver.findElements(By.xpath("(//tbody/tr)[1]")).size()>0) {
	 			RC_Global.waitElementVisible(driver, 60, "(//tbody/tr)[1]","Row", false, false);
	         	queryObjects.logStatus(driver, Status.PASS, "Search Results are", "Found", null);
	         	RC_Global.clickButton(driver, "Reset", false,false);
	         }
	 		else if(driver.findElements(By.xpath("//h5/span[text()='Vehicle Details']")).size()>0)
	 		{
	 			queryObjects.logStatus(driver, Status.PASS, "Validated the Search Results header as 'Vehicle Details'", "successfully", null);
	 			RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='Vehicle Details']])[1]", false,true);
	 		}
	 		else {
	 			queryObjects.logStatus(driver, Status.FAIL, "Search Results are Not", "Found", null);
	         }
	    }
	    else
	    {
		    RC_Global.navigateTo(driver, "Manage", "Administration", "Vehicle Details");
		    RC_Global.enterCustomerNumber(driver, custNum, "", "",false);
			RC_Global.enterInput(driver, Driver[1], driver.findElement(By.xpath("//input[@placeholder='Driver Last Name']")), false, true);
			RC_Global.clickButton(driver, "Search", false,false);
			Thread.sleep(3000);
			if(driver.findElements(By.xpath("(//tbody/tr)[1]")).size()>0) {
	 			RC_Global.waitElementVisible(driver, 60, "(//tbody/tr)[1]","Row", false, false);
	 			queryObjects.logStatus(driver, Status.PASS, "Search Results are", "Found", null);
	        	RC_Global.clickButton(driver, "Reset", false,false);
	        }
			else if(driver.findElements(By.xpath("//h5/span[text()='Vehicle Details']")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Validated the Search Results header as 'Vehicle Details'", "successfully", null);
				RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='Vehicle Details']])[1]", false,true);
			}
			else {
				queryObjects.logStatus(driver, Status.FAIL, "Search Results are Not", "Found", null);
	        }
	    }

		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
        
        
	}

}
