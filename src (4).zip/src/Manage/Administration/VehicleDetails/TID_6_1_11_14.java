package Manage.Administration.VehicleDetails;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_11_14 {

	public void VehicleDetails_ValidateEachHeaderSubMenu(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Vehicle Details";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details","TV", true,false);
		RC_Global.enterCustomerNumber(driver, "LS008737", "", "", false);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.waitElementVisible(driver, 60, "//table//tbody//tr//td[1]", "Grid Result", false, false);
		RC_Manage.selectRowWithVehicleStatusFromGrid(driver, "Active Lease", true);
		RC_Global.panelAction(driver, "xpathclose", "(//h5[span[contains(text(),'Vehicle Details')]])[1]", false,true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details","TV", true,false);
		RC_Global.waitElementVisible(driver, 60, "(//div[text()='Vehicle Description:'])[2]", "Acquisition", false, false);
		RC_Manage.waitUntilMethods(driver, "//div[@ng-show='isAcquisitionSummaryLoading']","class","ng-hide", "attribute visible");
		//Acquisition
		RC_Global.clickUsingXpath(driver, "//Strong[text()='Acquisition']", "Acquisition Header", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details - Acquisition","TV", true,false);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='isMenuLoading'])[1]","class","ng-hide", "attribute visible");
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		String vehicleoverview = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[1]")).getText();
		String orderDetail = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[2]")).getText();
		String origination = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[3]")).getText();
		String operationNotes = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[4]")).getText();
		
		queryObjects.logStatus(driver, Status.PASS, " "+vehicleoverview+" "+orderDetail+" "+origination+" "+operationNotes+" Sub - Sections is","Displayed", null);
		RC_Global.waitElementVisible(driver, 90, "//h3[text()='Vehicle Overview']", "Vehicle Overview", false, false);
		queryObjects.logStatus(driver, Status.PASS, " "+vehicleoverview+" Sub-Section is Selected and Data is","Displayed", null);
		RC_Global.clickUsingXpath(driver, "//button[normalize-space(text())='"+orderDetail+"']", "Order Detail", false, true);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 90, "//div[text()='Order Date:']", "Order Detail", false, false);
		queryObjects.logStatus(driver, Status.PASS, " "+orderDetail+" Sub-Section is Selected and Data is","Displayed", null);
		
		RC_Global.clickUsingXpath(driver, "//button[normalize-space(text())='"+origination+"']", "Orgination", false, true);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 90, "//div[text()='Purchase Date:']", "Orgination", false, false);
		queryObjects.logStatus(driver, Status.PASS, " "+origination+" Sub-Section is Selected and Data is","Displayed", null);
		
		RC_Global.clickUsingXpath(driver, "//button[normalize-space(text())='"+operationNotes+"']", "Operation Notes", false, true);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 90, "//h3[text()='Operations Notes']", "Operation Notes", false, false);
		queryObjects.logStatus(driver, Status.PASS, " "+operationNotes+" Sub-Section is Selected and Data is","Displayed", null);
		
		RC_Global.clickUsingXpath(driver, "//button[normalize-space(text())='"+orderDetail+"']", "Order Detail", false, true);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 90, "//div[text()='Order Date:']", "Order Detail", false, false);
		
		if(driver.findElements(By.xpath("(//button[contains(@title,'Open Previous Unit')])[2]")).size()==1) {
			RC_Global.clickUsingXpath(driver, "(//button[contains(@title,'Open Previous Unit')])[2]", "Previous Unit #", false, true);
			RC_Global.waitElementVisible(driver, 90, "//span[text()='Closed End']", "Previous Unit Number Screen - Vehicle Details Acquisition", false, false);
			Thread.sleep(2000);
			RC_Global.clickUsingXpath(driver, "//h5/span[contains(text(),'Vehicle Details Acquisition')]/..//i[@ng-click='closePanel()']", "Vehicle Details Acquisition - Close Panel", false, true);
			}
			else {
				queryObjects.logStatus(driver, Status.INFO, "The Previous Unit # field Data is ","Not Present", null);}
		
		RC_Global.panelAction(driver, "close", "Vehicle Details - Acquisition", false,true);
		//Billing
		RC_Global.clickUsingXpath(driver, "//Strong[text()='Billing']", "Billing Header", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details - Billing","TV", true,false);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='isMenuLoading'])[1]","class","ng-hide", "attribute visible");
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		String payment = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[1]")).getText();
		String lease = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[2]")).getText();
		String services = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[3]")).getText();
		String amortSchedule = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[4]")).getText();
		String endOfTerm = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[5]")).getText();
		String invoiceGroup = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[6]")).getText();
		
		queryObjects.logStatus(driver, Status.PASS, " "+payment+" "+lease+" "+services+" "+amortSchedule+" "+endOfTerm+" "+invoiceGroup+" Sub - Sections is","Displayed", null);
		RC_Global.waitElementVisible(driver, 90, "//h3[text()='Payment']", "Payment", false, false);
		queryObjects.logStatus(driver, Status.PASS, " "+payment+" Sub-Section is Selected and Data is","Displayed", null);
		
		RC_Global.clickUsingXpath(driver, "//button[normalize-space(text())='"+lease+"']", "Lease", false, true);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 90, "//div[text()='Delivery Date:']", "Lease", false, false);
		queryObjects.logStatus(driver, Status.PASS, " "+lease+" Sub-Section is Selected and Data is","Displayed", null);
		
		RC_Global.clickUsingXpath(driver, "//button[normalize-space(text())='"+services+"']", "Services", false, true);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 90, "//div[text()='Effective From Date:']", "Services", false, false);
		queryObjects.logStatus(driver, Status.PASS, " "+services+" Sub-Section is Selected and Data is","Displayed", null);
		
		RC_Global.clickUsingXpath(driver, "//button[normalize-space(text())='"+amortSchedule+"']", "Amort Schedule", false, true);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 90, "//h3[text()='Amortization Schedule']", "Amort Schedule", false, false);
		queryObjects.logStatus(driver, Status.PASS, " "+amortSchedule+" Sub-Section is Selected and Data is","Displayed", null);
		
		RC_Global.clickUsingXpath(driver, "//button[normalize-space(text())='"+endOfTerm+"']", "End Of Term", false, true);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 90, "//div[text()='Purchase Option:']", "End Of Term", false, false);
		queryObjects.logStatus(driver, Status.PASS, " "+endOfTerm+" Sub-Section is Selected and Data is","Displayed", null);
		
		RC_Global.clickUsingXpath(driver, "//button[normalize-space(text())='"+invoiceGroup+"']", "Invoice Group", false, true);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 90, "//div[text()='Rental Invoice Group Name:']", "Invoice Group", false, false);
		queryObjects.logStatus(driver, Status.PASS, " "+invoiceGroup+" Sub-Section is Selected and Data is","Displayed", null);
		
		RC_Global.clickUsingXpath(driver, "//button[normalize-space(text())='"+services+"']", "Services", false, true);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 90, "//div[text()='Effective From Date:']", "Services", false, false);
		RC_Global.clickUsingXpath(driver, "//button[@title='Open Program History']", "Program History", false, true);
		RC_Global.waitElementVisible(driver, 90, "//h3[text()='Service Program History']", "Service Program History", false, false);
		RC_Global.panelAction(driver, "close", "Vehicle Details - Billing", false,true);
		
		//Fuel
		RC_Global.clickUsingXpath(driver, "//Strong[text()='Fuel']", "Fuel Header", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details - Fuel","TV", true,false);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='isMenuLoading'])[1]","class","ng-hide", "attribute visible");
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		String summary = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[1]")).getText();
		String detail = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[2]")).getText();
		
		queryObjects.logStatus(driver, Status.PASS, " "+summary+" "+detail+" Sub - Sections is","Displayed", null);
		RC_Global.waitElementVisible(driver, 90, "//h3[text()='Fuel Summary']", "Fuel Summary", false, false);
		queryObjects.logStatus(driver, Status.PASS, " "+summary+" Sub-Section is Selected and Data is","Displayed", null);
		
		RC_Global.clickUsingXpath(driver, "//button[normalize-space(text())='"+detail+"']", "Detail", false, true);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 90, "//div[text()='Total Spend:']", "Detail", false, false);
		queryObjects.logStatus(driver, Status.PASS, " "+detail+" Sub-Section is Selected and Data is","Displayed", null);
		RC_Global.panelAction(driver, "close", "Vehicle Details - Fuel", false,true);
		
		//Maintenance
		RC_Global.clickUsingXpath(driver, "//Strong[text()='Maintenance']", "Maintenance Header", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details - Maintenance","TV", true,false);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='isMenuLoading'])[1]","class","ng-hide", "attribute visible");
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		String maintenanceSummary  = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[1]")).getText();
		String maintenanceCategory  = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[2]")).getText();
		String maintenanceDetail  = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[3]")).getText();
		String maintenanceNote  = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[4]")).getText();
		String acquisitionDetails  = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[5]")).getText();
		String serviceIntervalHistory  = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[6]")).getText();
		String maintenanceROHistory  = driver.findElement(By.xpath("(//button[contains(@ng-click,'exportPdf')])[2]")).getText();
		
		queryObjects.logStatus(driver, Status.PASS, " "+maintenanceSummary+" "+maintenanceCategory+" "+maintenanceDetail+" "+maintenanceNote+" "+acquisitionDetails+" "+serviceIntervalHistory+" "+maintenanceROHistory+" Sub - Sections is","Displayed", null);
		RC_Global.waitElementVisible(driver, 90, "//h3[text()='Maintenance Category']", "Maintenance Category", false, false);
		queryObjects.logStatus(driver, Status.PASS, " "+maintenanceCategory+" Sub-Section is Selected and Data is","Displayed", null);
		
		RC_Global.clickUsingXpath(driver, "//button[normalize-space(text())='"+maintenanceSummary+"']", "Maintenance Summary", false, true);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 90, "(//div[text()='Agreement Type:'])[3]", "Maintenance Summary", false, false);
		queryObjects.logStatus(driver, Status.PASS, " "+maintenanceSummary+" Sub-Section is Selected and Data is","Displayed", null);
		
		RC_Global.clickUsingXpath(driver, "//button[normalize-space(text())='"+maintenanceDetail+"']", "Maintenance Detail", false, true);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 90, "(//div[text()='Agreement Type:'])[3]", "Maintenance Detail", false, false);
		queryObjects.logStatus(driver, Status.PASS, " "+maintenanceDetail+" Sub-Section is Selected and Data is","Displayed", null);
		
		RC_Global.clickUsingXpath(driver, "//button[normalize-space(text())='"+maintenanceNote+"']", "Maintenance Note", false, true);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 90, "//h3[text()='Maintenance Note']", "Maintenance Note", false, false);
		queryObjects.logStatus(driver, Status.PASS, " "+maintenanceNote+" Sub-Section is Selected and Data is","Displayed", null);
		
		RC_Global.clickUsingXpath(driver, "//button[normalize-space(text())='"+acquisitionDetails+"']", "Acquisition Details", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details Acquisition","TV", true,false);
		RC_Global.waitElementVisible(driver, 90, "//h3[text()='Vehicle Overview']", "Acquisition Details", false, false);
		queryObjects.logStatus(driver, Status.PASS, " "+acquisitionDetails+" Sub-Section is Selected and Data is","Displayed", null);
		RC_Global.panelAction(driver, "close", "Vehicle Details Acquisition", false,true);
		
		RC_Global.clickUsingXpath(driver, "//button[normalize-space(text())='"+serviceIntervalHistory+"']", "Service Interval History", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Services History","TV", true,false);
		RC_Global.waitElementVisible(driver, 90, "//label[text()='Vehicle Unit Number']", "ServiceInterval History", false, false);
		queryObjects.logStatus(driver, Status.PASS, " "+serviceIntervalHistory+" Sub-Section is Selected and Data is","Displayed", null);
		RC_Global.panelAction(driver, "close", "Vehicle Services History", false,true);
		Thread.sleep(2000);
		RC_Global.downloadAndVerifyFileDownloaded(driver, "Export", "The Maintenance RO History PDF downloaded", false);
		RC_Global.panelAction(driver, "close", "Vehicle Details - Maintenance", false,true);
		//License, Title & Insurance
		RC_Global.clickUsingXpath(driver, "//Strong[text()='License, Title & Insurance']", "License, Title & Insurance Header", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details - License, Title & Insurance","TV", true,false);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='isMenuLoading'])[1]","class","ng-hide", "attribute visible");
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		String title  = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[1]")).getText();
		String registration  = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[2]")).getText();
		String insurance  = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[3]")).getText();
		String plateHistory  = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[4]")).getText();
		String registrationNotes  = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[5]")).getText();
		
		queryObjects.logStatus(driver, Status.PASS, " "+title+" "+registration+" "+insurance+" "+plateHistory+" "+registrationNotes+" Sub - Sections is","Displayed", null);
		RC_Global.waitElementVisible(driver, 90, "//h3[text()='Title']", "Title", false, false);
		queryObjects.logStatus(driver, Status.PASS, " "+title+" Sub-Section is Selected and Data is","Displayed", null);
		
		RC_Global.clickUsingXpath(driver, "//button[normalize-space(text())='"+registration+"']", "Registration", false, true);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 90, "//h3[text()='Registration']", "Registration", false, false);
		queryObjects.logStatus(driver, Status.PASS, " "+registration+" Sub-Section is Selected and Data is","Displayed", null);
		
		RC_Global.clickUsingXpath(driver, "//button[normalize-space(text())='"+insurance+"']", "Insurance", false, true);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 90, "//h3[text()='Insurance']", "Insurance", false, false);
		queryObjects.logStatus(driver, Status.PASS, " "+insurance+" Sub-Section is Selected and Data is","Displayed", null);
		
		RC_Global.clickUsingXpath(driver, "//button[normalize-space(text())='"+plateHistory+"']", "Plate History", false, true);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 90, "//h3[text()='Plate History']", "Plate History", false, false);
		queryObjects.logStatus(driver, Status.PASS, " "+plateHistory+" Sub-Section is Selected and Data is","Displayed", null);
		
		RC_Global.clickUsingXpath(driver, "//button[normalize-space(text())='"+registrationNotes+"']", "Registration Notes", false, true);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 90, "//h3[text()='Registration Notes']", "Registration Notes", false, false);
		queryObjects.logStatus(driver, Status.PASS, " "+registrationNotes+" Sub-Section is Selected and Data is","Displayed", null);
		RC_Global.panelAction(driver, "close", "Vehicle Details - License, Title & Insurance", false,true);
		
		//Remarketing Section
		RC_Global.clickUsingXpath(driver, "//Strong[text()='Remarketing']", "Remarketing Header", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details - Remarketing","TV", true,false);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='isMenuLoading'])[1]","class","ng-hide", "attribute visible");
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		String term  = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[1]")).getText();
		String payoffQuote  = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[2]")).getText();
		String vehicleSale  = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[3]")).getText();
		
		queryObjects.logStatus(driver, Status.PASS, " "+term+" "+payoffQuote+" "+vehicleSale+" Sub - Sections is","Displayed", null);
		RC_Global.waitElementVisible(driver, 90, "//h3[text()='Term']", "Term", false, false);
		queryObjects.logStatus(driver, Status.PASS, " "+term+" Sub-Section is Selected and Data is","Displayed", null);
		
		RC_Global.clickUsingXpath(driver, "//button[normalize-space(text())='"+payoffQuote+"']", "Payoff Quote", false, true);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 90, "//h3[text()='Payoff Quote']", "Payoff Quote", false, false);
		queryObjects.logStatus(driver, Status.PASS, " "+payoffQuote+" Sub-Section is Selected and Data is","Displayed", null);
		
		RC_Global.clickUsingXpath(driver, "//button[normalize-space(text())='"+vehicleSale+"']", "Vehicle Sale", false, true);
		RC_Global.waitElementVisible(driver, 90, "//h3[text()='Vehicle Sale']", "Vehicle Sale", false, false);
		queryObjects.logStatus(driver, Status.PASS, " "+vehicleSale+" Sub-Section is Selected and Data is","Displayed", null);
		RC_Global.panelAction(driver, "close", "Vehicle Details - Remarketing", false,true);
		
		//Client Data Section
		RC_Global.clickUsingXpath(driver, "//Strong[text()='Client Data']", "Client Data Header", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Driver Details","TV", true,false);
		Thread.sleep(1000);
		RC_Global.panelAction(driver, "close", "Driver Details", false,true);
		
		//Vehicle Programs Section
		RC_Global.createNode(driver, "Vehicle Programs Header");
		WebDriverWait wait = new WebDriverWait(driver,5);	
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//strong[text()='Vehicle Programs']")));
			queryObjects.logStatus(driver, Status.PASS, "The Vehicle Programs Header is","Not Clickable", null);
		
			RC_Global.panelAction(driver, "close", "Vehicle Details", false,true);
			
			RC_Global.logout(driver, false);	
			queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
