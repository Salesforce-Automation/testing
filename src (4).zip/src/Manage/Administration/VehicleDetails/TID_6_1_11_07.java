package Manage.Administration.VehicleDetails;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_11_07 {

	public void VehicleDetails_ValidateBillingSectionFields(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Vehicle Details");
        RC_Global.enterCustomerNumber(driver, "LS010143", "", "",false);
        RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Active lease;Active services only", false);
        RC_Global.clickButton(driver, "Search",false,true);
        
        RC_Global.waitElementVisible(driver, 60, "//table//tbody//tr//td[1]", "Grid Result", false, false); 
        RC_Manage.selectRowWithVehicleStatusFromGrid(driver, "Active services only", true);
        RC_Global.panelAction(driver, "close", "Vehicle Details", false,true);
        RC_Manage.waitUntilMethods(driver, "//div[@ng-show='isBillingSummaryLoading']","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 90, " //div[text()='In Service Date:']", "Billing", false, false);
		
		RC_Global.verifyScreenComponents(driver,"lable","In Service Date:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Out of Service Date:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Agreement Type:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Months in Service:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Months Billed:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Cap Cost:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Book Value:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Residual Value:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Billed Through Date:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Stop Billing Date:", true);
		
	//	RC_Global.verifyScreenComponents(driver,"lable","Last Month's Vehicle Payment:", true);
		String label = driver.findElement(By.xpath("(//div[@id='billingSummaryVehiclePaymentValue']//parent::div//div)[1]")).getText();
		if(label.contains("Last Month's Vehicle Payment:"))
		{
           String strValue = driver.findElement(By.xpath("//button[@title='Open Billing Payment']")).getText();
            if(strValue.length()==0)
            {
                   queryObjects.logStatus(driver, Status.PASS, "To verify label "+label+" is available with ", "empty value", null);
            }
            else
            {
                   queryObjects.logStatus(driver, Status.PASS, "To verify label "+label+" is available with value ", strValue, null);
            }
		}
		else
		{
            queryObjects.logStatus(driver, Status.FAIL, "unable to find the label ", "", null);

		}

		String InSerDat = driver.findElement(By.xpath("(//button[contains(@ng-click,'openLife')])[2]")).getText();
		queryObjects.logStatus(driver, Status.PASS, "The In Service Date is a hyperlink and it value is ---->",InSerDat, null);
		
		String AgTyp = driver.findElement(By.xpath("(//span[contains(@ng-class,'highlightRed')])[3]")).getText();
		queryObjects.logStatus(driver, Status.PASS, "The Agreement Type is a hyperlink and it value is ---->",AgTyp, null);
		
		String  capcos= driver.findElement(By.xpath("(//button[contains(@ng-click,'BillingSchedule')])[1]")).getText();
		queryObjects.logStatus(driver, Status.PASS, "The Cap Cost is a hyperlink and it value is ---->",capcos, null);
		
		String BoVal = driver.findElement(By.xpath("(//button[contains(@ng-click,'BillingSchedule')])[2]")).getText();
		queryObjects.logStatus(driver, Status.PASS, "The Book Value is a hyperlink and it value is ---->",BoVal, null);
		
		String LasMon = driver.findElement(By.xpath("//button[contains(@ng-click,'BillingPayment')]")).getText();
		queryObjects.logStatus(driver, Status.PASS, "The Last Month's Vehicle Payment is a hyperlink and it value is ---->",LasMon, null);
		
		String OutSer = driver.findElement(By.xpath("//div[text()='Out of Service Date:']//following-sibling::div")).getText();
		String MonSer = driver.findElement(By.xpath("//div[text()='Months in Service:']//following-sibling::div")).getText();
		String MonBill = driver.findElement(By.xpath("//div[text()='Months Billed:']//following-sibling::div")).getText();
		String ResVal = driver.findElement(By.xpath("//div[text()='Residual Value:']//following-sibling::div")).getText();
		String BillDat = driver.findElement(By.xpath("//div[text()='Billed Through Date:']//following-sibling::div")).getText();
		String StoBill = driver.findElement(By.xpath("//div[text()='Stop Billing Date:']//following-sibling::div")).getText();
		String LaMon = driver.findElement(By.xpath("//button[@title='Open Billing Payment']")).getText();

		
	    RC_Manage.isValidDateFormat(driver, "M/dd/yyyy", "In Service Date:", InSerDat, false);
	//    RC_Manage.isValidDateFormat(driver, "", "Out of Service Date:", OutSer, false);
      
	    
	   RC_Manage.validateDataType(driver,"Billing","Agreement Type:" ,"AlphaNumeric",AgTyp , false);
	   RC_Manage.validateDataType(driver,"Billing","Months in Service:" ,"Numeric", MonSer, false);
	   RC_Manage.validateDataType(driver,"Billing","Months Billed:" ,"Numeric", MonBill, false);
	   RC_Manage.validateDataType(driver,"Billing","Cap Cost:" ,"Currency", capcos, false);
	   RC_Manage.validateDataType(driver,"Billing","Book Value:" ,"Currency",BoVal , false);
	   RC_Manage.validateDataType(driver,"Billing","Residual Value:" ,"Currency",ResVal , false);
	   RC_Manage.isValidDateFormat(driver, "M/dd/yyyy", "Billed Through Date:", BillDat, false);
//	   RC_Manage.isValidDateFormat(driver, "", "Stop Billing Date:", StoBill, false);
	   RC_Manage.validateDataType(driver,"Billing","Last Month's Vehicle Payment:" ,"Currency", LaMon, false);
	   
	   RC_Global.createNode(driver,"Verify In Service Date as hypertext and navigate to Vehicle Details - Life Cycle Dates");
       RC_Global.clickUsingXpath(driver,"(//button[contains(@ng-click,'openLife')])[2]", "In Service Date",false,true);
       RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='isMenuLoading'])[1]","class","ng-hide", "attribute visible");
       RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
       RC_Global.validateHeaderName(driver, "Vehicle Details - Life Cycle Dates",true);
       RC_Global.panelAction(driver, "close", "Vehicle Details - Life Cycle Dates",false,true);

       
       
       RC_Global.createNode(driver,"Verify Agreement Type as hypertext and navigate to Vehicle Details - Billing");
       RC_Global.clickUsingXpath(driver,"(//span[contains(@ng-class,'highlightRed')])[3]", "Agreement Type",false,true);
       RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='isMenuLoading'])[1]","class","ng-hide", "attribute visible");
       RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
       RC_Global.validateHeaderName(driver, "Vehicle Details - Billing",true); 
       RC_Global.panelAction(driver, "close", "Vehicle Details - Billing",false,true);



       RC_Global.createNode(driver,"Verify Cap Cost as hypertext and navigate to Vehicle Details - Billing");
       RC_Global.clickUsingXpath(driver,"(//button[contains(@ng-click,'BillingSchedule')])[1]", "Cap Cost",false,true);
       RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='isMenuLoading'])[1]","class","ng-hide", "attribute visible");
       RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
       RC_Global.validateHeaderName(driver, "Vehicle Details - Billing",true);
       RC_Global.panelAction(driver, "close", "Vehicle Details - Billing",false,true);


       RC_Global.createNode(driver,"Verify Book Value as hypertext and navigate to Vehicle Details - Billing");
       RC_Global.clickUsingXpath(driver,"(//button[contains(@ng-click,'BillingSchedule')])[2]", "Book Value",false,true);
       RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='isMenuLoading'])[1]","class","ng-hide", "attribute visible");
       RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
       RC_Global.validateHeaderName(driver, "Vehicle Details - Billing",true);
       RC_Global.panelAction(driver, "close", "Vehicle Details - Billing",false,true);

       
       RC_Global.createNode(driver,"Verify Last Month's Vehicle Payment as hypertext and navigate to Vehicle Details - Billing");
       RC_Global.clickUsingXpath(driver,"//button[contains(@ng-click,'BillingPayment')]", "Last Month's Vehicle Payment",false,true);
       RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='isMenuLoading'])[1]","class","ng-hide", "attribute visible");
       RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
       RC_Global.validateHeaderName(driver, "Vehicle Details - Billing",true);
       RC_Global.panelAction(driver, "close", "Vehicle Details - Billing",false,true);

       RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

		
		
		
		
	}
}
