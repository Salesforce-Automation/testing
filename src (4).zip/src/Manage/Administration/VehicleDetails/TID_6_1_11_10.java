package Manage.Administration.VehicleDetails;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_11_10 {
	
	public void VehicleDetails_ValidateFuelSectionFields(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Vehicle Details";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details","TV", true,false);
		RC_Global.enterCustomerNumber(driver, "LS008737", "", "", false);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.waitElementVisible(driver, 60, "//table//tbody//tr//td[1]", "Grid Result", false, false);
		RC_Manage.selectRowWithVehicleStatusFromGrid(driver, "Active Lease", true);
		RC_Global.panelAction(driver, "xpathclose", "(//h5[span[contains(text(),'Vehicle Details')]])[1]", false,true);
		RC_Global.waitElementVisible(driver, 60, "//div[text()='Total Fuel Spend LTD:']", "Fuel", false, false);
		RC_Manage.waitUntilMethods(driver, "//div[@ng-show='isFuelSummaryLoading']","class","ng-hide", "attribute visible");
		
		
		RC_Global.verifyScreenComponents(driver,"lable","Total Fuel Spend LTD:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Total # of Transactions:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Last Transaction Date:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Last Mileage:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Total Gallons LTD:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Avg Cost Per Gallon:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Life to Date MPG:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Tank Size:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Carbon Output (lbs):", true);
		
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Total Fuel Spend LTD:']//following-sibling::div", "Fuel", "Total Fuel Spend LTD", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Total # of Transactions:']//following-sibling::div", "Fuel", "Total # of Transactions", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Last Transaction Date:']//following-sibling::div", "Fuel", "Last Transaction Date", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Last Mileage:']//following-sibling::div", "Fuel", "Last Mileage", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Total Gallons LTD:']//following-sibling::div", "Fuel", "Total Gallons LTD", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Avg Cost Per Gallon:']//following-sibling::div", "Fuel", "Avg Cost Per Gallon", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Life to Date MPG:']//following-sibling::div", "Fuel", "Life to Date MPG", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Tank Size:']//following-sibling::div", "Fuel", "Tank Size", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Carbon Output (lbs):']//following-sibling::div", "Fuel", "Carbon Output (lbs)", false);
		
		String TotalFuelSpend = driver.findElement(By.xpath("(//button[contains(@title,'Open Fuel Detail')])[1]")).getText();
		queryObjects.logStatus(driver, Status.PASS, "The Total Fuel Spend LTD is a hyperlink and it value is ---->",TotalFuelSpend, null);
		String TotalnoTransaction = driver.findElement(By.xpath("(//button[contains(@title,'Open Fuel Detail')])[2]")).getText();
		queryObjects.logStatus(driver, Status.PASS, "The Total # of Transactions is a hyperlink and it value is ---->",TotalnoTransaction, null);
		String LastTransactionDate = driver.findElement(By.xpath("(//button[contains(@title,'Open Fuel Detail')])[3]")).getText();
		queryObjects.logStatus(driver, Status.PASS, "The Last Transaction Date is a hyperlink and it value is ---->",LastTransactionDate, null);
		String TotalGallonsLtd = driver.findElement(By.xpath("(//button[contains(@title,'Open Fuel Detail')])[4]")).getText();
		queryObjects.logStatus(driver, Status.PASS, "The Total Gallons LTD is a hyperlink and it value is ---->",TotalGallonsLtd, null);
		String AvgCostPerGallon = driver.findElement(By.xpath("(//button[contains(@title,'Open Fuel Detail')])[5]")).getText();
		queryObjects.logStatus(driver, Status.PASS, "The Avg Cost Per Gallon is a hyperlink and it value is ---->",AvgCostPerGallon, null);
		String CarbonOutputIbs = driver.findElement(By.xpath("//button[contains(@title,'Open Carbon Output')]")).getText();
		queryObjects.logStatus(driver, Status.PASS, "The Carbon Output (lbs) is a hyperlink and it value is ---->",CarbonOutputIbs, null);
		
		String lifetodateMpg = driver.findElement(By.xpath("//div[text()='Life to Date MPG:']//following-sibling::div")).getText();
		String tanksize = driver.findElement(By.xpath("//div[text()='Tank Size:']//following-sibling::div")).getText();
		//check data type
		RC_Manage.validateDataType(driver,"Fuel","Total Fuel Spend LTD" ,"Currency", TotalFuelSpend, false);
		RC_Manage.validateDataType(driver,"Fuel","Total # of Transactions" ,"Numeric", TotalnoTransaction, false);
		RC_Manage.isValidDateFormat(driver, "MM/dd/yyyy", "Last Transaction Date", LastTransactionDate, false);
		RC_Manage.validateDataType(driver,"Fuel","Total Gallons LTD" ,"Numeric", TotalGallonsLtd, false);
		RC_Manage.validateDataType(driver,"Fuel","Avg Cost Per Gallon" ,"Currency", AvgCostPerGallon, false);
		RC_Manage.validateDataType(driver,"Fuel","Life to Date MPG" ,"Numeric", lifetodateMpg, false);
		RC_Manage.validateDataType(driver,"Fuel","Tank Size" ,"Numeric", tanksize, false);
		RC_Manage.validateDataType(driver,"Fuel","Carbon Output (lbs)" ,"Numeric", CarbonOutputIbs, false);
		
		//Clicking on the Fuel Fields Hyperlinks
		RC_Global.clickUsingXpath(driver, "(//button[contains(@title,'Open Fuel Detail')])[1]", "Total Fuel Spend LTD", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details - Fuel","TV", true,false);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		String VehicleDetail = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[2]")).getText();
		queryObjects.logStatus(driver, Status.PASS, " "+VehicleDetail+" Sub - section is","selected", null);
		RC_Global.panelAction(driver, "close", "Vehicle Details - Fuel", false,true);
		
		//Clicking on the Fuel Fields Hyperlinks
		RC_Global.clickUsingXpath(driver, "(//button[contains(@title,'Open Fuel Detail')])[2]", "Total # of Transactions", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details - Fuel","TV", true,false);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		String VehicleDetail1 = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[2]")).getText();
		queryObjects.logStatus(driver, Status.PASS, " "+VehicleDetail1+" Sub - section is","selected", null);
		RC_Global.panelAction(driver, "close", "Vehicle Details - Fuel", false,true);
				
				
		//Clicking on the Fuel Fields Hyperlinks
		RC_Global.clickUsingXpath(driver, "(//button[contains(@title,'Open Fuel Detail')])[3]", "Last Transaction Date", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details - Fuel","TV", true,false);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		String VehicleDetail2 = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[2]")).getText();
		queryObjects.logStatus(driver, Status.PASS, " "+VehicleDetail2+" Sub - section is","selected", null);
		RC_Global.panelAction(driver, "close", "Vehicle Details - Fuel", false,true);
				
				
		//Clicking on the Fuel Fields Hyperlinks
		RC_Global.clickUsingXpath(driver, "(//button[contains(@title,'Open Fuel Detail')])[4]", "Total Gallons LTD", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details - Fuel","TV", true,false);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		String VehicleDetail3 = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[2]")).getText();
		queryObjects.logStatus(driver, Status.PASS, " "+VehicleDetail3+" Sub - section is","selected", null);
		RC_Global.panelAction(driver, "close", "Vehicle Details - Fuel", false,true);
				
				
		//Clicking on the Fuel Fields Hyperlinks
		RC_Global.clickUsingXpath(driver, "(//button[contains(@title,'Open Fuel Detail')])[5]", "Avg Cost Per Gallon", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details - Fuel","TV", true,false);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		String VehicleDetail4 = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[2]")).getText();
		queryObjects.logStatus(driver, Status.PASS, " "+VehicleDetail4+" Sub - section is","selected", null);
		RC_Global.panelAction(driver, "close", "Vehicle Details - Fuel", false,true);
		
		
		//Clicking on the Fuel Fields Hyperlinks
		RC_Global.clickUsingXpath(driver, "//button[contains(@title,'Open Carbon Output')]", "Carbon Output (lbs)", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Fleet Carbon Equivalent","TV", true,false);
		RC_Global.panelAction(driver, "close", "Fleet Carbon Equivalent", false,true);
		
		RC_Global.panelAction(driver, "close", "Vehicle Details", false,true);
		
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}

}
