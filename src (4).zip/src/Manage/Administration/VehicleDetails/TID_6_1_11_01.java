package Manage.Administration.VehicleDetails;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.LeaseWave.RC_LW_Global;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_11_01 {
	public void  AddNewVehicleInLeaseWave_TotalViewIntegration(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		String UnitNumber = "";
		String ContractNumber = ""; String Division = ""; 
		String currentwindow = driver.getWindowHandle();
		RC_LW_Global.leaseWaveLogin(driver, true);
		RC_Global.createNode(driver, "Navigate To: Portfolio Managegement -> Asset -> Profile");
		RC_Global.clickUsingXpath(driver,"//a[contains(text(),'Portfolio Management')]","Portfolio Management",true, false);
		RC_Global.waitElementVisible(driver, 50, "//a[contains(text(),'Portfolio Management')]", "Portfolio Management",true, true);
		driver.findElement(By.xpath("//td[text()='.Asset']")).click();
        Thread.sleep(500);
        driver.findElement(By.xpath("(//td[@accesskey='P']/div[text()='rofile'])[2]")).click();
        Thread.sleep(500);
		RC_Global.waitElementVisible(driver, 50, "(//span[text()='Asset List'])[1]", "",true, false);
		
		RC_Global.clickButton(driver, "dd", true, true);
		RC_Global.waitElementVisible(driver, 50, "//span[text()='Asset Profile']", "Asset Profile Page",true, false);
		RC_Global.createNode(driver, "Enter mandatory information under Asset Details, status, classification, GL segment assignment");
		UnitNumber = driver.findElement(By.xpath("(//span[text()='Unit Number']/following::input[contains(@name,'UnitNumber')])[1]")).getAttribute("value");
		RC_Global.selectDropdownOption(driver, "InventoryTypeID", "Ambulance_NonOwned", true, false);
	
		driver.findElement(By.xpath("//input[contains(@id,'AcquisitionDate_input')]")).click();
		driver.findElement(By.xpath("//input[contains(@id,'AcquisitionDate_input')]")).sendKeys(RC_Global.getDateTime(driver, "MM/dd/yyyy", -1, true));
		WebElement FactoryCategory = driver.findElement(By.xpath("//button[contains(@id,'ImportFactorCategoryID')]"));
		FactoryCategory.click();
		for(String winHandle : driver.getWindowHandles()){
    	    driver.switchTo().window(winHandle);
    	}
		RC_Global.waitElementVisible(driver, 50, "(//span[text()='Factor Category List'])[1]", "Factor Category List",true, false);
		RC_Global.clickButton(driver, "elect", true, false);
		driver.switchTo().window(currentwindow);
		RC_Global.selectDropdownOption(driver, "UsageConditionID", "New", true, false);
		WebElement YearOfManufacture = driver.findElement(By.xpath("//input[contains(@editid,'YearOfManufacture')]"));
		WebElement AccountNumber = driver.findElement(By.xpath("(//input[contains(@id,'AccountNumber')])[2]"));
		RC_Global.enterInput(driver, "2021", YearOfManufacture, true, false);
		RC_Global.enterInput(driver, "LS004792", AccountNumber, true, false);
		
		driver.findElement(By.xpath("(//select[contains(@id,'Contract')])")).click();
		ContractNumber = driver.findElement(By.xpath("(//select[contains(@id,'Contract')])/option[2]")).getText();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//select[contains(@id,'Contract')])/option[2]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//select[contains(@id,'Division')])")).click();
		Division = driver.findElement(By.xpath("(//select[contains(@id,'Division')])/option[2]")).getText();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//select[contains(@id,'Division')])/option[2]")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("(//select[contains(@id,'PH_GLSegmentAssignment')])[1]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//select[contains(@id,'PH_GLSegmentAssignment')])[1]/option[2]")).click();
		
		
		driver.findElement(By.xpath("(//select[contains(@id,'PH_GLSegmentAssignment')])[2]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//select[contains(@id,'PH_GLSegmentAssignment')])[2]/option[2]")).click();
		
		RC_Global.clickButton(driver, "ave", true, true);
		RC_Global.waitElementVisible(driver, 50, "//span[text()='Vehicle Details']", "Vehicle Details Page",true, false); 
		RC_Global.clickButton(driver, "ave", true, true);
		RC_Global.clickButton(driver, "lose", true, false);
		RC_LW_Global.leaseWaveLogOut(driver, false);
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,"Manage","Administration","Vehicle Details");
		WebElement UnitNumberIN = driver.findElement(By.xpath("//input[@id='unitNumber']"));
		RC_Global.enterInput(driver, UnitNumber, UnitNumberIN, true, true);
		Thread.sleep(2000);
		RC_Global.clickButton(driver, "Search", true, true);
		Thread.sleep(3000);
		RC_Global.waitElementVisible(driver, 30, "(//span[text()='Vehicle Details'])[2]", "Vehicle Details Page",true, false);
		RC_Global.waitElementVisible(driver, 30, "(//Strong[text()='Acquisition'])", "",true, false);
		RC_Manage.waitUntilMethods(driver, "//div[@ng-show='isAcquisitionSummaryLoading']","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 30, "//div[@id='vehicle-details-customer-name' and contains(text(),'LS004792 -')]", "",false, false);
		RC_Global.createNode(driver, "Customer Hierarchy Section Validation");
		String Fleet = driver.findElement(By.xpath("//div[@id='vehicle-details-customer-fleet']")).getText();
		String[] FleetNum = Fleet.split("-");
		Fleet = FleetNum[1].trim()+" - "+FleetNum[0].trim();
		Thread.sleep(500);
		String Account = driver.findElement(By.xpath("//div[@id='vehicle-details-customer-account']")).getText();
		Thread.sleep(500);
		String[] AccNum = Account.split("-");
		Account = AccNum[1].trim()+" - "+AccNum[0].trim();
		
		if(ContractNumber.equalsIgnoreCase(Fleet) && Division.equalsIgnoreCase(Account))		//if(DivisionNum[1].contains(AccNum[0]) && AccNum[0].contains(FleetNum[1]) && ConNum[1].contains(FleetNum[0]) && ConNum[0].contains(FleetNum[1]) )
			queryObjects.logStatus(driver, Status.PASS, "Customer Hierarchy Section", "Customer Hierarchy Section displays matching the hierachy tree chosen in LW", null);
		else {
			queryObjects.logStatus(driver, Status.FAIL, "Customer Hierarchy Section", "Customer Hierarchy Section does not displays matching the hierachy tree chosen in LW", null);
			RC_Global.endTestRun(driver);}
		
		RC_Global.panelAction(driver, "close", "Vehicle Details", true, true);
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
