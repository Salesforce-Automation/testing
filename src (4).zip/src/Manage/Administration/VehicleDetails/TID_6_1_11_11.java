package Manage.Administration.VehicleDetails;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_11_11 {

	public void VehicleDetails_ValidateMainInfoSectionFieldsAndPanelTitles(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Vehicle Details";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details","TV", true,false);
		RC_Global.enterCustomerNumber(driver, "LS008737", "", "", false);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.waitElementVisible(driver, 60, "//table//tbody//tr//td[1]", "Grid Result", false, false);
		RC_Manage.selectRowWithVehicleStatusFromGrid(driver, "Active Lease", true);
		RC_Global.panelAction(driver, "xpathclose", "(//h5[span[contains(text(),'Vehicle Details')]])[1]", false,true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details","TV", true,false);
		RC_Manage.waitUntilMethods(driver, "//div[@ng-show='isFuelSummaryLoading']","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 60, "//div[text()='Total Fuel Spend LTD:']", "Fuel", false, false);
		
		RC_Global.verifyScreenComponents(driver,"sectionHeading","Acquisition", true);
		RC_Global.verifyScreenComponents(driver,"sectionHeading","Billing", true);
		RC_Global.verifyScreenComponents(driver,"sectionHeading","Fuel", true);
		RC_Global.verifyScreenComponents(driver,"sectionHeading","Maintenance", true);
		RC_Global.verifyScreenComponents(driver,"sectionHeading","License, Title & Insurance", true);
		RC_Global.verifyScreenComponents(driver,"sectionHeading","Remarketing", true);
		RC_Global.verifyScreenComponents(driver,"sectionHeading","Client Data", true);
		RC_Global.verifyScreenComponents(driver,"sectionHeading","Vehicle Programs", true);
		
		RC_Global.buttonStatusValidation(driver, " Print ", "Enable", false);
		RC_Global.clickUsingXpath(driver, "//button[normalize-space(text())='Main Search']", "Main Search",true , true);
		RC_Global.panelAction(driver, "xpathclose", "(//h5[span[contains(text(),'Vehicle Details')]])[2]", false,true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details","TV", true,false);
		
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Unit #:']//following-sibling::div", "Main Info Section", "Unit #", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Customer Vehicle #:']//following-sibling::div",  "Main Info Section", "Customer Vehicle #", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Vehicle Description:']//following-sibling::div",  "Main Info Section", "Vehicle Description", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Vehicle Status:']//following-sibling::div",  "Main Info Section", "Vehicle Status", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Agreement Type:']//following-sibling::div",  "Main Info Section", "Agreement Type", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Latest Odometer:']//following-sibling::div",  "Main Info Section", "Latest Odometer", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Latest Engine Hours:']//following-sibling::div",  "Main Info Section", "Latest Engine Hours", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Driver:']//following-sibling::div",  "Main Info Section", "Driver", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Address:']//following-sibling::div",  "Main Info Section", "Address", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Cell Phone:']//following-sibling::div",  "Main Info Section", "Cell Phone", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Work Phone:']//following-sibling::div",  "Main Info Section", "Work Phone", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Email:']//following-sibling::div",  "Main Info Section", "Email", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Customer:']//following-sibling::div",  "Main Info Section", "Customer", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Fleet:']//following-sibling::div",  "Main Info Section", "Fleet", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Account:']//following-sibling::div",  "Main Info Section", "Account", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Sub Account:']//following-sibling::div",  "Main Info Section", "Sub Account", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Customer Contact:']//following-sibling::div",  "Main Info Section", "Customer Contact", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='CSR:']//following-sibling::div",  "Main Info Section", "CSR", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Sales Executive:']//following-sibling::div",  "Main Info Section", "Sales Executive", false);
		
		
		String Vehicledescrip = driver.findElement(By.xpath("(//button[contains(@title,'Open Acquisition')])[1]")).getText();
		queryObjects.logStatus(driver, Status.PASS, "The Vehicle Description is a hyperlink and it value is ---->",Vehicledescrip, null);
		String LatestOdometer = driver.findElement(By.xpath("(//button[contains(@title,'Open Odometer History')])[1]")).getText();
		queryObjects.logStatus(driver, Status.PASS, "The Latest Odometer is a hyperlink and it value is ---->",LatestOdometer, null);
		String Driver = driver.findElement(By.xpath("(//button[contains(@title,'Open Driver Change')])[1]")).getText();
		queryObjects.logStatus(driver, Status.PASS, "The Driver is a hyperlink and it value is ---->",Driver, null);
		String Email = driver.findElement(By.xpath("//button[contains(@ng-click,'openDriverChange')]//span")).getText();
		queryObjects.logStatus(driver, Status.PASS, "The Email is a hyperlink and it value is ---->",Email, null);
		
		String unitno = driver.findElement(By.xpath("//div[text()='Unit #:']//following-sibling::div")).getText();
		String CVN = driver.findElement(By.xpath("//div[text()='Customer Vehicle #:']//following-sibling::div")).getText();
		String vehicleDescrip = driver.findElement(By.xpath("//div[text()='Vehicle Description:']//following-sibling::div//button")).getText();
		String Vehiclestatus = driver.findElement(By.xpath("//div[text()='Vehicle Status:']//following::span//span")).getText();
		String Agreementtype = driver.findElement(By.xpath("//div[text()='Agreement Type:']//following::span//span")).getText();
		String LatestOdo = driver.findElement(By.xpath("(//div[text()='Latest Odometer:']//following::button)[1]")).getText();
		String Enginehrs = driver.findElement(By.xpath("(//div[text()='Latest Engine Hours:']//following::button)[1]")).getText();
		String drivername = driver.findElement(By.xpath("//div[text()='Driver:']//following-sibling::div//button")).getText();
		String Address = driver.findElement(By.xpath("//div[text()='Address:']//following-sibling::div")).getText();
		String Cellpho = driver.findElement(By.xpath("//div[text()='Cell Phone:']//following-sibling::div")).getText();
		String workpho = driver.findElement(By.xpath("//div[text()='Work Phone:']//following-sibling::div//span")).getText();
		String email = driver.findElement(By.xpath("(//div[text()='Email:']//following::button//span)[1]")).getText();
		String customer = driver.findElement(By.xpath("//div[text()='Customer:']//following-sibling::div")).getText();
		String fleet = driver.findElement(By.xpath("//div[text()='Fleet:']//following-sibling::div")).getText();
		String Account = driver.findElement(By.xpath("//div[text()='Account:']//following-sibling::div")).getText();
		String Subaccount = driver.findElement(By.xpath("//div[text()='Sub Account:']//following-sibling::div")).getText();
		String CusContact = driver.findElement(By.xpath("//div[text()='Customer Contact:']//following-sibling::div")).getText();
		String CSR = driver.findElement(By.xpath("//div[text()='CSR:']//following-sibling::div")).getText();
		String salesExecutive = driver.findElement(By.xpath("//div[text()='Sales Executive:']//following-sibling::div")).getText();
		 String[] LatOdometer = LatestOdo.split(" ");
		
		RC_Manage.validateDataType(driver,"Main Info Section","Unit #" ,"Numeric",unitno , false);
		RC_Manage.validateDataType(driver,"Main Info Section","Customer Vehicle #" ,"AlphaNumeric",CVN , false);
		RC_Manage.validateDataType(driver,"Main Info Section","Vehicle Description" ,"AlphaNumeric",vehicleDescrip , false);
		RC_Manage.validateDataType(driver,"Main Info Section","Vehicle Status" ,"Text",Vehiclestatus , false);
		RC_Manage.validateDataType(driver,"Main Info Section","Agreement Type" ,"Text",Agreementtype , false);
		RC_Manage.validateDataType(driver,"Main Info Section","Latest Odometer" ,"Numeric",LatOdometer[0] , false);//
		RC_Manage.isValidDateFormat(driver, "MM/dd/yyyy", "Latest Odometer", LatOdometer[1], false);
		RC_Manage.validateDataType(driver,"Main Info Section","Latest Engine Hours" ,"AlphaNumeric",Enginehrs , false);
		RC_Manage.validateDataType(driver,"Main Info Section","Driver" ,"Text",drivername , false);
		RC_Manage.validateDataType(driver,"Main Info Section","Address" ,"AlphaNumeric",Address , false);
		RC_Manage.validateDataType(driver,"Main Info Section","Cell Phone" ,"Numeric",Cellpho , false);
		RC_Manage.validateDataType(driver,"Main Info Section","Work Phone" ,"Numeric",workpho , false);
		RC_Manage.validateDataType(driver,"Main Info Section","Email" ,"Text",email , false);
		RC_Manage.validateDataType(driver,"Main Info Section","Customer" ,"Text",customer , false);
		RC_Manage.validateDataType(driver,"Main Info Section","Fleet" ,"Numeric",fleet , false);
		RC_Manage.validateDataType(driver,"Main Info Section","Account" ,"AlphaNumeric",Account , false);
		RC_Manage.validateDataType(driver,"Main Info Section","Sub Account" ,"AlphaNumeric",Subaccount , false);
		RC_Manage.validateDataType(driver,"Main Info Section","Customer Contact" ,"Text",CusContact , false);
		RC_Manage.validateDataType(driver,"Main Info Section","CSR" ,"Text",CSR , false);
		RC_Manage.validateDataType(driver,"Main Info Section","Sales Executive" ,"Text",salesExecutive , false);
		
		//Clicking on the Fuel Fields Hyperlinks
		RC_Global.clickUsingXpath(driver, "//div[text()='Vehicle Description:']//following-sibling::div//button", "Vehicle Description", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details - Acquisition","TV", true,false);
		
		RC_Global.panelAction(driver, "close", "Vehicle Details - Acquisition", false,true);
				
		//Clicking on the Fuel Fields Hyperlinks
		RC_Global.clickUsingXpath(driver, "(//div[text()='Latest Odometer:']//following::button)[1]", "Latest Odometer", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details - Odometer","TV", true,false);
		
		RC_Global.panelAction(driver, "close", "Vehicle Details - Odometer", false,true);
						
						
		//Clicking on the Fuel Fields Hyperlinks
		RC_Global.clickUsingXpath(driver, "//div[text()='Driver:']//following-sibling::div//button", "Driver", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Driver Details","TV", true,false);
		
		RC_Global.panelAction(driver, "close", "Driver Details", false,true);
										
		//Clicking on the Fuel Fields Hyperlinks
		RC_Global.clickUsingXpath(driver, "(//div[text()='Email:']//following::button//span)[1]", "Email", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Driver Details","TV", true,false);
		RC_Global.panelAction(driver, "close", "Driver Details", false,true);
		
	
		RC_Global.panelAction(driver, "close", "Vehicle Details", false,true);
		
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
