package Manage.Administration.VehicleDetails;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_11_12 {

	public void VehicleDetails_ValidateRemarketingSectionFields(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Vehicle Details";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details","TV", true,false);
		RC_Global.enterCustomerNumber(driver, "LS008737", "", "", false);
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Closed", false);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.waitElementVisible(driver, 60, "//table//tbody//tr//td[1]", "Grid Result", false, false);
		RC_Manage.selectRowWithVehicleStatusFromGrid(driver, " Closed ", true);
		RC_Global.panelAction(driver, "xpathclose", "(//h5[span[contains(text(),'Vehicle Details')]])[1]", false,true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details","TV", true,false);
		RC_Manage.waitUntilMethods(driver, "//div[@ng-show='isFuelSummaryLoading']","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 60, "//div[text()='Total Fuel Spend LTD:']", "Fuel", false, false);
		RC_Global.scrollById(driver, "//div[text()='Last Transaction Date:']");
		
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Off Road Date:']//following-sibling::div","Remarketing", "Off Road Date", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Sold Date:']//following-sibling::div","Remarketing", "Sold Date", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Odometer Reading:']//following-sibling::div","Remarketing", "Odometer Reading", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Expected Term:']//following-sibling::div","Remarketing", "Expected Term", false);
		
		String OffRoadDate = driver.findElement(By.xpath("//div[text()='Off Road Date:']//following-sibling::div")).getText();
		String SoldDate = driver.findElement(By.xpath("//div[text()='Sold Date:']//following-sibling::div")).getText();
		String Odometereading = driver.findElement(By.xpath("//div[text()='Odometer Reading:']//following-sibling::div")).getText();
		String ExpectedTerm = driver.findElement(By.xpath("//div[text()='Expected Term:']//following-sibling::div")).getText();
		String NetAuctionProceeds = driver.findElement(By.xpath("//div[text()='Net Auction Proceeds:']//following-sibling::div")).getText();
		String NetResidual = driver.findElement(By.xpath("//div[text()='Net Residual %:']//following-sibling::div")).getText();
		String NetSaleAmount = driver.findElement(By.xpath("//div[text()='Net Sale Amount:']//following-sibling::div")).getText();
		String ConditionReport = driver.findElement(By.xpath("//div[text()='Condition Report:']//following-sibling::div")).getText();
		
		RC_Manage.isValidDateFormat(driver, "MM/dd/yyyy", "Off Road Date", OffRoadDate, false);
		RC_Manage.isValidDateFormat(driver, "MM/dd/yyyy", "Sold Date", SoldDate, false);
		RC_Manage.validateDataType(driver,"Remarketing","Odometer Reading" ,"Numeric",Odometereading , false);
		RC_Manage.validateDataType(driver,"Remarketing","Expected Term" ,"Numeric",ExpectedTerm , false);
		RC_Manage.validateDataType(driver,"Remarketing","Net Auction Proceeds" ,"Currency",NetAuctionProceeds , false);
		RC_Manage.validateDataType(driver,"Remarketing","Net Residual" ,"Percentage",NetResidual , false);
		RC_Manage.validateDataType(driver,"Remarketing","Net Sale Amount" ,"Currency",NetSaleAmount , false);
		RC_Manage.isValidDateFormat(driver, "MM/dd/yyyy", "Condition Report", ConditionReport, false);
		
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//h5[span[contains(text(),'Vehicle Details')]])[1]")));
		RC_Global.panelAction(driver, "close", "Vehicle Details", false,true);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
