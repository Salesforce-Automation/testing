package Manage.Administration.VehicleDetails;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;
import tools.TotalView.RC_Remarketing;

public class TID_6_1_11_04 {
	
	public void VehicleDetails_ValidateAdvancedSearchFilters(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String AgreementType = "Closed End;Mobility Rental;No Selected Value;Open End;Purchase and Disposal;Services Only";
        String MaintenanceAgreementType ="Full;Administered;Reserve";
        String columnName ="Customer #;Customer Name;Unit Number;CVN;Driver/Pool Name;VIN;Year;Make;Model;Plate;Address;City;State;Zip;Vehicle Status;Client Data 1;Client Data 2;Client Data 3;Email Address;Fleet #;Fleet Name;Account #;Account Name;Sub-Account #;Sub-Account Name";
        List<String> dropdown = new ArrayList<String>(Arrays.asList("Yes",	"No"));
		
		    RC_Global.login(driver);
			RC_Global.navigateTo(driver, "Manage", "Administration", "Vehicle Details");
	 
	        RC_Global.clickButton(driver, "Advanced Search",false,true);
	        
	        RC_Global.validateHeaderName(driver, "Vehicle Details",true);
	       
	        
			 RC_Global.createNode(driver, "Validation of Vehicle Details sections");
			 String CusDet = driver.findElement(By.xpath("//h3[text()='Customer Details']")).getText();
			 String VehDet = driver.findElement(By.xpath("//h3[text()='Vehicle Details']")).getText();
			 String DriDet = driver.findElement(By.xpath("//h3[text()='Driver Details']")).getText();
			 String VehStPro= driver.findElement(By.xpath("//h3[text()='Vehicle Status and Programs']")).getText();
	
            RC_Global.validateMultipleSelectionFilter(driver, "Active lease;Active services only;On Order;Pending Activation;Pending termination", false);
            RC_Manage.dropdownValuesValidation(driver, dropdown, "Fuel Program", "//select[@name='fuelProgram']",false);
            RC_Global.validateMultipleSelectionFilter(driver, "Closed End;Mobility Rental;No Selected Value;Open End;Purchase and Disposal;Services Only", false);
    		
            RC_Global.validateMultipleSelectionFilter(driver, "Full;Administered;Reserve", false);

    		RC_Global.enterCustomerNumber(driver, "LS008737", "", "",false);
    		RC_Global.clickButton(driver, "Search", true,true);
    		RC_Global.verifyColumnNames(driver,columnName, false);
    		
    		 RC_Global.createNode(driver,"Verify Unit Number as hypertext and navigate to Vehicle Details page");
    	     RC_Global.clickUsingXpath(driver,"(//tbody//tr[1]/td[3])[1]", "Unit Number",false,true);
    	     RC_Global.validateHeaderName(driver, "Vehicle Details",true);
    	     RC_Global.clickUsingXpath(driver, "(//span[text()='Vehicle Details'])[3]", "Vehicle Details_Close", false, true);
    	     RC_Global.panelAction(driver, "expand", "Vehicle Details",false,true);
    	     
    	     RC_Global.createNode(driver,"Verify CVN displayed as hypertext and navigate to Vehicle Details page");
    	     RC_Global.clickUsingXpath(driver,"(//tbody//tr[1]/td[4])[1]", "CVN",false,true);
    	     RC_Global.validateHeaderName(driver, "Vehicle Details",true);
    	     RC_Global.clickUsingXpath(driver, "(//span[text()='Vehicle Details'])[3]", "Vehicle Details_Close", false, true);
    	     RC_Global.panelAction(driver, "expand", "Vehicle Details",false,true);
    	     
    	     RC_Global.createNode(driver,"Verify Driver/Pool Name displayed as hypertext and navigate to Driver Details page");
    	     RC_Global.clickUsingXpath(driver,"(//tbody//tr[1]/td[5])[1]", "Driver/Pool Name",false,true);
    	     RC_Global.validateHeaderName(driver, "Driver Details",true);
    	     RC_Global.clickUsingXpath(driver, "(//span[text()='Vehicle Details'])[3]", "Vehicle Details_Close", false, true);
    	     RC_Global.panelAction(driver, "close", "Vehicle Details",false,true);
    	     RC_Global.logout(driver, false);	
 			queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
    	     
            
	}

		
}
