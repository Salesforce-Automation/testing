package Manage.Administration.VehicleDetails;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_11_08 {

	public void VehicleDetails_ValidateClientDataSectionFields(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Vehicle Details";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details","TV", true,false);
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", false);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.waitElementVisible(driver, 60, "//table//tbody//tr//td[1]", "Grid Result", false, false);
		RC_Manage.selectRowWithVehicleStatusFromGrid(driver, "Active services only", true);
		RC_Global.panelAction(driver, "xpathclose", "(//h5[span[contains(text(),'Vehicle Details')]])[1]", false,true);
		RC_Manage.waitUntilMethods(driver, "//div[@ng-show='isClientDataSummaryLoading']","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 60, "//div[text()='Manager:']", "Client data", false, false);
		RC_Global.scrollById(driver, "//div[text()='Last Transaction Date:']");
		
		RC_Global.verifyScreenComponents(driver,"lable","Manager:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Charge Code:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Fuel GL:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Job Title:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Owner:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Store Ops Chg Code Y/N:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Vehicle Segment:", true);
		
		String manager = driver.findElement(By.xpath("//div[text()='Manager:']//following-sibling::div")).getText();
		String chargeCode = driver.findElement(By.xpath("//div[text()='Charge Code:']//following-sibling::div")).getText();
		String fuelGL = driver.findElement(By.xpath("//div[text()='Fuel GL:']//following-sibling::div")).getText();
		String jobTitle = driver.findElement(By.xpath("//div[text()='Job Title:']//following-sibling::div")).getText();
		String owner = driver.findElement(By.xpath("//div[text()='Owner:']//following-sibling::div")).getText();
		String storeOps = driver.findElement(By.xpath("//div[text()='Store Ops Chg Code Y/N:']//following-sibling::div")).getText();
		String vehicleSegment = driver.findElement(By.xpath("//div[text()='Vehicle Segment:']//following-sibling::div")).getText();
		
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Manager:']//following-sibling::div", "Client Data", "Manager", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Charge Code:']//following-sibling::div", "Client Data", "Charge Code", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Fuel GL:']//following-sibling::div", "Client Data", "Fuel GL", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Job Title:']//following-sibling::div", "Client Data", "Job Title", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Owner:']//following-sibling::div", "Client Data", "Owner", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Store Ops Chg Code Y/N:']//following-sibling::div", "Client Data", "Store Ops Chg Code Y/N", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Vehicle Segment:']//following-sibling::div", "Client Data", "Vehicle Segment", false);
		
		RC_Global.clickUsingXpath(driver, "//strong[text()='Client Data']", "Client Data", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Driver Details","TV", true,false);
		RC_Global.panelAction(driver, "expand", "Driver Details", false,true);
		
		RC_Global.scrollById(driver, "//label[text()='Email']");
		
		String managerD = driver.findElement(By.xpath("//label[normalize-space(text())='Manager']//following::div[1]//select")).getAttribute("value");
		String chargeCodeD = driver.findElement(By.xpath("//label[normalize-space(text())='Charge Code']//following::div[1]//select")).getAttribute("value");
		String fuelGLD = driver.findElement(By.xpath("//label[normalize-space(text())='Fuel GL']//following::div[1]//select")).getAttribute("value");
		String jobTitleD = driver.findElement(By.xpath("//label[normalize-space(text())='Job Title']//following::div[1]//input")).getAttribute("value");
		String ownerD = driver.findElement(By.xpath("//label[normalize-space(text())='Owner']//following::div[1]//select")).getAttribute("value");
		String storeOpsD = driver.findElement(By.xpath("//label[normalize-space(text())='Store Ops Chg Code Y/N']//following::div[1]//select")).getAttribute("value");
		String vehicleSegmentD = driver.findElement(By.xpath("//label[normalize-space(text())='Vehicle Segment']//following::div[1]//select")).getAttribute("value");
		
		RC_Global.createNode(driver, "Vehicle Details Client Data value and Driver Details Client Data value Validation");
		queryObjects.logStatus(driver, Status.PASS, "The Client Data Definition Value of Manager: ---->",managerD, null);
		queryObjects.logStatus(driver, Status.PASS, "The Client Data Definition Value of Charge Code: ---->",chargeCodeD, null);
		queryObjects.logStatus(driver, Status.PASS, "The Client Data Definition Value of Fuel GL: ---->",fuelGLD, null);
		queryObjects.logStatus(driver, Status.PASS, "The Client Data Definition Value of Job Title: ---->",jobTitleD, null);
		queryObjects.logStatus(driver, Status.PASS, "The Client Data Definition Value of Owner: ---->",ownerD, null);
		queryObjects.logStatus(driver, Status.PASS, "The Client Data Definition Value of Store Ops Chg Code Y/N: ---->",storeOpsD, null);
		queryObjects.logStatus(driver, Status.PASS, "The Client Data Definition Value of Vehicle Segment: ---->",vehicleSegmentD, null);
		
		if(manager.equalsIgnoreCase(managerD)) {
			 queryObjects.logStatus(driver, Status.PASS, "Client Data Manager Value and Client Data Definition Manager: value "+manager+" ", "are Matched", null);} 
		else {queryObjects.logStatus(driver, Status.FAIL, "Client Data Manager Value and Client Data Definition Manager: value "+manager+" ", "are Not Matched", null);} 
		
		if(chargeCode.equalsIgnoreCase(chargeCodeD)) {
			 queryObjects.logStatus(driver, Status.PASS, "Client Data Charge Code Value and Client Data Definition Charge Code: value "+chargeCode+" ", "are Matched", null);} 
		else {queryObjects.logStatus(driver, Status.FAIL, "Client Data Charge Code Value and Client Data Definition Charge Code: value "+chargeCode+" ", "are Not Matched", null);} 
		
		if(fuelGL.equalsIgnoreCase(fuelGLD)) {
			 queryObjects.logStatus(driver, Status.PASS, "Client Data Fuel GL Value and Client Data Definition Fuel GL: value "+fuelGL+" ", "are Matched", null);} 
		else {queryObjects.logStatus(driver, Status.FAIL, "Client Data Fuel GL Value and Client Data Definition Fuel GL: value "+fuelGL+" ", "are Not Matched", null);} 
		
		if(jobTitle.equalsIgnoreCase(jobTitleD)) {
			 queryObjects.logStatus(driver, Status.PASS, "Client Data Job Title Value and Client Data Definition Job Title: value "+jobTitle+" ", "are Matched", null);} 
		else {queryObjects.logStatus(driver, Status.FAIL, "Client Data Job Title Value and Client Data Definition Job Title: value "+jobTitle+" ", "are Not Matched", null);} 
		
		if(owner.equalsIgnoreCase(ownerD)) {
			 queryObjects.logStatus(driver, Status.PASS, "Client Data Owner Value and Client Data Definition Owner: value "+owner+" ", "are Matched", null);} 
		else {queryObjects.logStatus(driver, Status.FAIL, "Client Data Owner Value and Client Data Definition Owner: value "+owner+" ", "are Not Matched", null);} 
		
		if(storeOps.equalsIgnoreCase(storeOpsD)) {
			 queryObjects.logStatus(driver, Status.PASS, "Client Data Store Ops Chg Code Y/N Value and Client Data Definition Store Ops Chg Code Y/N: value "+storeOps+" ", "are Matched", null);} 
		else {queryObjects.logStatus(driver, Status.FAIL, "Client Data Store Ops Chg Code Y/N Value and Client Data Definition Store Ops Chg Code Y/N: value "+storeOps+" ", "are Not Matched", null);} 
		
		if(vehicleSegment.equalsIgnoreCase(vehicleSegmentD)) {
			 queryObjects.logStatus(driver, Status.PASS, "Client Data Vehicle Segment Value and Client Data Definition Vehicle Segment: value "+vehicleSegment+" ", "are Matched", null);} 
		else {queryObjects.logStatus(driver, Status.FAIL, "Client Data Vehicle Segment Value and Client Data Definition Vehicle Segment: value "+vehicleSegment+" ", "are Not Matched", null);} 
		
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
		
	}
}
