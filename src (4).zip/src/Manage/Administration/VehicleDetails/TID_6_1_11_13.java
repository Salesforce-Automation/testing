package Manage.Administration.VehicleDetails;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_11_13 {

	public void VehicleDetails_ValidateVehicleProgramsSectionFields(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Vehicle Details";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details","TV", true,false);
		RC_Global.enterCustomerNumber(driver, "LS008737", "", "", false);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.waitElementVisible(driver, 60, "//table//tbody//tr//td[1]", "Grid Result", false, false);
		RC_Manage.selectRowWithVehicleStatusFromGrid(driver, "Active services only", true);
		RC_Global.panelAction(driver, "xpathclose", "(//h5[span[contains(text(),'Vehicle Details')]])[1]", false,true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details","TV", true,false);
		RC_Manage.waitUntilMethods(driver, "//div[@ng-show='isFuelSummaryLoading']","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 60, "//div[text()='Total Fuel Spend LTD:']", "Fuel", false, false);
		RC_Global.scrollById(driver, "//div[text()='Last PM Date:']");
		
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Accident Management:']//following-sibling::div","Vehicle Programs", "Accident Management", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Driver Safety Training:']//following-sibling::div","Vehicle Programs", "Driver Safety Training", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Lease:']//following-sibling::div","Vehicle Programs", "Lease", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Maintenance:']//following-sibling::div","Vehicle Programs", "Maintenance", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Personal Use:']//following-sibling::div","Vehicle Programs", "Personal Use", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Fuel:']//following-sibling::div","Vehicle Programs", "Fuel", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Roadside:']//following-sibling::div","Vehicle Programs", "Roadside", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Vehicle Registration:']//following-sibling::div","Vehicle Programs", "Vehicle Registration", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Telematics:']//following-sibling::div","Vehicle Programs", "Telematics", false);
		RC_Manage.validateSectionFieldDatas(driver, "//div[text()='Insurance:']//following-sibling::div","Vehicle Programs", "Insurance", false);
		
		String accidentManagement = driver.findElement(By.xpath("//div[text()='Accident Management:']//following-sibling::div")).getText();
		String driversafetyTraining = driver.findElement(By.xpath("//div[text()='Driver Safety Training:']//following-sibling::div")).getText();
		String lease = driver.findElement(By.xpath("(//div[text()='Lease:']//following::span//span)[1]")).getText();
		String maintenance = driver.findElement(By.xpath("//div[text()='Maintenance:']//following-sibling::div")).getText();
		String personalUse = driver.findElement(By.xpath("//div[text()='Personal Use:']//following-sibling::div")).getText();
		String fuel = driver.findElement(By.xpath("//div[text()='Fuel:']//following-sibling::div")).getText();
		String roadside = driver.findElement(By.xpath("//div[text()='Roadside:']//following-sibling::div")).getText();
		String vehicleRegis = driver.findElement(By.xpath("//div[text()='Vehicle Registration:']//following-sibling::div")).getText();
		String telematics = driver.findElement(By.xpath("//div[text()='Telematics:']//following-sibling::div")).getText();
		String insurance = driver.findElement(By.xpath("//div[text()='Insurance:']//following-sibling::div")).getText();
		
		RC_Manage.validateDataType(driver,"Vehicle Programs","Accident Management" ,"Boolean",accidentManagement , false);
		RC_Manage.validateDataType(driver,"Vehicle Programs","Driver Safety Training" ,"Boolean",driversafetyTraining , false);
		RC_Manage.validateDataType(driver,"Vehicle Programs","Lease" ,"Text",lease , false);
		RC_Manage.validateDataType(driver,"Vehicle Programs","Maintenance" ,"Text",maintenance , false);
		RC_Manage.validateDataType(driver,"Vehicle Programs","Personal Use" ,"Boolean", personalUse, false);
		RC_Manage.validateDataType(driver,"Vehicle Programs","Fuel" ,"Boolean",fuel , false);
		RC_Manage.validateDataType(driver,"Vehicle Programs","Roadside" ,"Text", roadside, false);
		RC_Manage.validateDataType(driver,"Vehicle Programs","Vehicle Registration" ,"Text", vehicleRegis, false);
		RC_Manage.validateDataType(driver,"Vehicle Programs","Telematics" ,"Text",telematics , false);
		RC_Manage.validateDataType(driver,"Vehicle Programs","Insurance" ,"Text",insurance , false);
		
		RC_Global.panelAction(driver, "close", "Vehicle Details", false,true);
		
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
		
	}
	
}
