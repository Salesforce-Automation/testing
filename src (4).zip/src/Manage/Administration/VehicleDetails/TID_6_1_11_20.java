package Manage.Administration.VehicleDetails;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_11_20 {
	public void VehicleDetails_ValidateRemarketingServicesOnlyAgreementTypeUsingExternalUser(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String UnitNumber = "";
		
		WebDriverWait wait = new WebDriverWait(driver,60);
	
		RC_Global.externalUserLogin(driver, "TestextFM", "");
		RC_Global.navigateTo(driver, "Manage", "Administration", "Vehicle Details");
		RC_Global.waitUntilPanelVisibility(driver, "Vehicle Details", "TV", false, false);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//select[@id='vehicleStatus']/option[text()='Active lease']")));
		if(driver.findElements(By.xpath("(//input[@name='customerInput' and @disabled='disabled'])[2]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Customer # entered by default and disabled", "Successfully", null);
		    }
        else
	        {
	        	queryObjects.logStatus(driver, Status.FAIL,"Customer # not entered by default and disabled", "", null);
	        }
		
		RC_Manage.multipleSelectSearchFilter(driver, "vehicleStatus", "Active lease;Active services only;Cancelled;Closed;On Order;Pending Activation;Pending termination;Sold;Terminated lease;Terminated services only", false);
		RC_Global.enterInput(driver, "702212", driver.findElement(By.xpath("//input[@placeholder='Unit Number']")), false, true);
		Thread.sleep(2000);
		RC_Global.clickUsingXpath(driver, "//div/button[text()='Search']", "Search button", true, false);
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@ng-show='tableDataLoading || !tableDataLoaded']/i[@class='fa fa-spinner fa-spin ng-scope']")));
		Thread.sleep(6000);
		if(driver.findElements(By.xpath("//div[text()='Vehicle Status:']/following-sibling::div/span/span[text()='Terminated Services Only']")).size()>0)
		{
			Thread.sleep(2000);
		}
		else if(driver.findElements(By.xpath("(//div/span[text()='No Results'])[1]")).size()>0)
		{
		
		RC_Global.clickButton(driver, "Reset", false,true);
		RC_Manage.multipleSelectSearchFilter(driver, "Vehicle Status", "Terminated Services Only", false);
		RC_Global.clickButton(driver, "Search", false,true);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//tbody//tr)[1]")));															
        List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("//table//tbody//tr"));
        String drivername = ""; 
        String CVN = "";
        int rowcnt=Getgridrowcnt.size();
        boolean    firstpage=false;
        boolean    pagination=false;
        for(int i=1; i<=rowcnt;i++) {  
            WebElement CVNrow= driver.findElement(By.xpath("//tr["+i+"]//td[4]"));          																
            WebElement Unitnorow = driver.findElement(By.xpath("//tr["+i+"]//td[3]"));
            UnitNumber = Unitnorow.getText();
            Thread.sleep(2000);
            CVN = CVNrow.getText();									 
            if(!(CVN.isEmpty())) {
                WebElement driverclmn =driver.findElement(By.xpath("//tbody//tr["+i+"]//td[5]"));										   
                Thread.sleep(2000);
                drivername = driverclmn.getText();
                Thread.sleep(1000);
                if(!(drivername.equalsIgnoreCase("Unassigned") || drivername.contains("Pool")||drivername.contains("Unknown")||drivername.contains("Catering")) ) {
 //                   driver.findElement(By.xpath("//tbody//tr["+i+"]//td[2]")).click();
                Thread.sleep(1000);
                firstpage = true;
                break;}
            	}
            }
        
        queryObjects.logStatus(driver, Status.INFO, "Unit Number for vehicle status Terminated Services Only---->", UnitNumber, null);

        RC_Global.clickButton(driver, "Reset", false, false);
        RC_Global.enterInput(driver, UnitNumber, driver.findElement(By.xpath("//input[@placeholder='Unit Number']")), false, true);
        RC_Manage.multipleSelectSearchFilter(driver, "Vehicle Status", "Active lease;Active services only;Cancelled;Closed;On Order;Pending Activation;Pending termination;Sold;Terminated lease;Terminated services only", false);
        RC_Global.clickButton(driver, "Search", false,true);
        RC_Global.waitElementVisible(driver, 60, "//h5/span[text()='Vehicle Details']", "Vehicle Details", false, true);
		}
		Thread.sleep(4000);
		
	        String VehicleStatus = driver.findElement(By.xpath("//div[text()='Vehicle Status:']/following-sibling::div/span/span")).getText();
	 //       		"Terminated Services Only";
	        String AgreementType = driver.findElement(By.xpath("//div[text()='Agreement Type:']/following-sibling::div/span/span")).getText();
	//        		"Services Only";
	       
	        if(VehicleStatus.equalsIgnoreCase("Terminated Services Only"))
	        {
	        	queryObjects.logStatus(driver, Status.PASS, "Vehicle Status for unit matches---->", UnitNumber, null);
	        }
	        else
	        {
	        	queryObjects.logStatus(driver, Status.FAIL, "Vehicle Status for unit not matches---->", UnitNumber, null);
	        }
	        
	        if(AgreementType.equalsIgnoreCase("Services Only"))
	        {
	        	queryObjects.logStatus(driver, Status.PASS, "Agreement Type for unit matches---->", UnitNumber, null);
	        }
	        else
	        {
	        	queryObjects.logStatus(driver, Status.FAIL, "Agreement Type for unit not matches---->", UnitNumber, null);
	        }
	        
	        RC_Global.scrollById(driver, "//button[@id='vehicleDetailsRemarketingSummaryHeader']");
	        RC_Global.createNode(driver, "Verify field displayed under Remarketing Section");
	        RC_Manage.validateNoSectionFieldDatas(driver, "Remarketing", "Net Auction Proceeds", "//div[contains (@id,'NetAuctionProceeds')][1]", true);
	        RC_Manage.validateNoSectionFieldDatas(driver, "Remarketing", "Net Sale Amount", "//div[contains (@id,'NetSaleAmount')][1]", true);	    
	        RC_Manage.validateNoSectionFieldDatas(driver, "Remarketing", "Condition Report", "//div[contains (@id,'ConditionReport')][1]", true);
	        
	        
	        RC_Global.clickUsingXpath(driver, "//button/strong[text()='Remarketing']", "Remarketing link", false, true);
	        RC_Global.panelAction(driver, "close", "Vehicle Details", false, false);
	        
	        RC_Global.waitElementVisible(driver, 60, "//h5/span[text()='Vehicle Details - Remarketing']", "Vehicle Details - Remarketing", false, true);
	        
	        if(driver.findElements(By.xpath("//li[contains(@class,'active')]/button[normalize-space(text()='Term')]")).size()>0)
	        {
	        	queryObjects.logStatus(driver, Status.PASS, "Verify by default 'Terms' tab is selected in Vehicle Details - Remarketing screen", "Sucessfully", null);
	        }
	        else{
	        	queryObjects.logStatus(driver, Status.FAIL, "By default 'Terms' tab is not selected in Vehicle Details - Remarketing screen", " ", null);
	        }
	        
	        RC_Global.createNode(driver, "Verify field displayed under Terms Tab");
	        RC_Manage.validateNoSectionFieldDatas(driver, "Remarketing", "OffRoad Date", "//div[contains(@id,'OffRoadDate')][1]", true);
	        RC_Manage.validateNoSectionFieldDatas(driver, "Remarketing", "Secured Date", "//div[contains(@id,'SecuredDate')][1]", true);
	        RC_Manage.validateNoSectionFieldDatas(driver, "Remarketing", "Terminated Date", "//div[contains(@id,'TerminatedDate')][1]", true);	        
	        RC_Manage.validateNoSectionFieldDatas(driver, "Remarketing", "Sale Status", "//div[contains(@id,'SaleStatus')][1]", true);
	        RC_Manage.validateNoSectionFieldDatas(driver, "Remarketing", "Sale Date", "//div[contains(@id,'SaleDate')][1]", true);
	        RC_Manage.validateNoSectionFieldDatas(driver, "Remarketing", "Gross Sales Price", "//div[contains(@id,'GrossSalesPrice')][1]", true);
	        RC_Manage.validateNoSectionFieldDatas(driver, "Remarketing", "Net Auction Proceeds", "//div[contains(@id,'NetAuctionProceeds')][1]", true);	      
	        RC_Manage.validateNoSectionFieldDatas(driver, "Remarketing", "Disposition Fees", "//div[contains(@id,'DispositionFees')][1]", true);	        
	        RC_Manage.validateNoSectionFieldDatas(driver, "Remarketing", "Net Sale Amount", "//div[contains(@id,'NetSaleAmount')][1]", true);
	        RC_Manage.validateNoSectionFieldDatas(driver, "Remarketing", "Guaranteed BuyOffer", "//div[contains(@id,'GuaranteedBuyOffer')][1]", true);	     	        	      
	        RC_Manage.validateNoSectionFieldDatas(driver, "Remarketing", "Sold Date", "//div[contains(@id,'SoldDate')][1]", true);
	        RC_Manage.validateNoSectionFieldDatas(driver, "Remarketing", "Sale Type", "//div[contains(@id,'SaleType')][1]", true);
	        RC_Manage.validateNoSectionFieldDatas(driver, "Remarketing", "Odometer Reading", "//div[contains(@id,'OdometerReading')][1]", true);
	        RC_Manage.validateNoSectionFieldDatas(driver, "Remarketing", "Expected Lease Term", "//div[contains(@id,'ExpectedLeaseTerm')][1]", true);
	        RC_Manage.validateNoSectionFieldDatas(driver, "Remarketing", "Vehicle Grade", "//div[contains(@id,'VehicleGrade')][1]", true);
	        RC_Manage.validateNoSectionFieldDatas(driver, "Remarketing", "Estimated Repair Cost", "//div[contains(@id,'EstimatedRepairCost')][1]", true);
	        
	        RC_Global.scrollById(driver, "(//h5/span[contains(text(),'Vehicle Details')])[1]");
	        RC_Global.panelAction(driver, "close", "Vehicle Details - Remarketing", false,true);
		
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}


}
