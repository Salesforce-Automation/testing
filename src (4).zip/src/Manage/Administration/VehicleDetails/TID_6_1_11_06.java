package Manage.Administration.VehicleDetails;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Billing;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_11_06 {
	public void VehicleDetails_ValidateLicense_TitleAndInsuranceSectionfields(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
			RC_Global.login(driver);
			RC_Global.navigateTo(driver, "Manage", "Administration", "Vehicle Details");
	        RC_Global.enterCustomerNumber(driver, "LS010143", "", "",false);
	        RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Active lease;Active services only", false);
	        RC_Global.clickButton(driver, "Search",false,true);
	        RC_Global.waitElementVisible(driver, 60, "//table//tbody//tr//td[1]", "Grid Result", false, false); 
	        RC_Manage.selectRowWithVehicleStatusFromGrid(driver, "Active services only", true);
	        RC_Global.panelAction(driver, "close", "Vehicle Details", false,true);
			RC_Global.waitElementVisible(driver, 90, " //div[text()='Title Status:']", "License, Title & Insurance", false, false);
			RC_Manage.waitUntilMethods(driver, "//div[@ng-show='isLTISummaryLoading']","class","ng-hide", "attribute visible");
	
			RC_Global.verifyScreenComponents(driver,"lable","Title Status:", true);
			RC_Global.verifyScreenComponents(driver,"lable","Title Received Date:", true);
			RC_Global.verifyScreenComponents(driver,"lable","Plate Number:", true);
			RC_Global.verifyScreenComponents(driver,"lable","Plate State:", true);
			RC_Global.verifyScreenComponents(driver,"lable","Expiration Date:", true);
			RC_Global.verifyScreenComponents(driver,"lable","Plate Type:", true);
			RC_Global.verifyScreenComponents(driver,"lable","Insurance Company:", true);
			RC_Global.verifyScreenComponents(driver,"lable","Expiration Date:", true);

			
	         
	        String TitSta = driver.findElement(By.xpath("(//button[contains(@ng-click,'openLicense')])[2]")).getText();
			queryObjects.logStatus(driver, Status.PASS, "The Title Status is a hyperlink and it value is ---->",TitSta, null);
			
			 String PlaNum = driver.findElement(By.xpath("(//button[contains(@ng-click,'openLicense')])[3]")).getText();
			 queryObjects.logStatus(driver, Status.PASS, "The Plate Number is a hyperlink and it value is ---->",PlaNum, null);
			 
			 String InsCom = driver.findElement(By.xpath("(//button[contains(@ng-click,'openLicense')])[3]")).getText();
			 queryObjects.logStatus(driver, Status.PASS, "The Insurance Company is a hyperlink and it value is ---->",InsCom, null);
			 
			 String TitleRe = driver.findElement(By.xpath("//div[text()='Title Received Date:']//following-sibling::div")).getText();
			 String PlaSta = driver.findElement(By.xpath("//div[text()='Plate Number:']//following-sibling::div")).getText();
			 String ExpDat = driver.findElement(By.xpath("//div[text()='Expiration Date:']//following-sibling::div")).getText();
			 String PlaType = driver.findElement(By.xpath("//div[text()='Expiration Date:']//following-sibling::div")).getText();
			 String InCom = driver.findElement(By.xpath("//div[text()='Insurance Company:']//following-sibling::div")).getText();
			 String ExpDate = driver.findElement(By.xpath("//div[text()='Expiration Date:']//following-sibling::div")).getText();

			 
			 
			 RC_Manage.validateDataType(driver,"License, Title & Insurance","Title Status:" ,"AlphaNumeric", TitSta, false);
	//		 RC_Manage.validateDataType(driver,"License, Title & Insurance","Title Received Date:" ,"AlphaNumeric", TitleRe, false);
			 
			 RC_Manage.isValidDateFormat(driver, "M/dd/yyyy", "Title Received Date:", TitleRe, false);
			 RC_Manage.validateDataType(driver,"License, Title & Insurance","Plate Number:" ,"Numeric", PlaNum, false);
			 RC_Manage.validateDataType(driver,"License, Title & Insurance","Plate Number:" ,"AlphaNumeric", PlaSta, false);
			 RC_Manage.isValidDateFormat(driver, "M/dd/yyyy", "Expiration Date:", ExpDat, false);
			 RC_Manage.validateDataType(driver,"License, Title & Insurance","Plate Number:" ,"AlphaNumeric", PlaType, false);
			 RC_Manage.validateDataType(driver,"License, Title & Insurance","Insurance Company:" ,"AlphaNumeric", InCom, false);
			 RC_Manage.isValidDateFormat(driver, "M/dd/yyyy", "Expiration Date:", ExpDate, false);

			 
			RC_Global.createNode(driver,"Verify Title Status as hypertext and navigate to Vehicle Details page");
	        RC_Global.clickUsingXpath(driver,"(//button[contains(@ng-click,'openLicense')])[2]", "Title Status",false,true);
	        RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
	        RC_Global.validateHeaderName(driver, "Vehicle Details - License, Title & Insurance",true);
	        
	        RC_Global.panelAction(driver, "close","Vehicle Details - License, Title & Insurance",false,true);
	   //     RC_Global.panelAction(driver, "expand", "Vehicle Details",false,true);
	        
	       

	        RC_Global.createNode(driver,"Verify Plate Number as hypertext and navigate to Vehicle Details page");
	        RC_Global.clickUsingXpath(driver,"(//button[contains(@ng-click,'openLicense')])[3]", "Plate Number",false,true);
	        RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
	        RC_Global.validateHeaderName(driver, "Vehicle Details - License, Title & Insurance",true);
	        RC_Global.panelAction(driver, "close","Vehicle Details - License, Title & Insurance",false,true);

	        RC_Global.createNode(driver,"Verify Insurance Company as hypertext and navigate to Vehicle Details page");
	        RC_Global.clickUsingXpath(driver,"(//button[contains(@ng-click,'openLicense')])[4]", "Insurance Company",false,true);
	        RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
	        RC_Global.validateHeaderName(driver, "Vehicle Details - License, Title & Insurance",true);
	        RC_Global.panelAction(driver, "close","Vehicle Details - License, Title & Insurance",false,true);
	        
	        RC_Global.logout(driver, false);	
			queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	        
	        


	}

}
