package Manage.Administration.VehicleDetails;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_11_05 {
	public void VehicleDetails_ValidateMaintenanceSectionFields(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Vehicle Details");
        RC_Global.enterCustomerNumber(driver, "LS010116", "", "",false);
        RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Active lease;Active services only", false);
        RC_Global.clickButton(driver, "Search",false,true);
        
        RC_Global.waitElementVisible(driver, 60, "//table//tbody//tr//td[1]", "Grid Result", false, false); 
        RC_Manage.selectRowWithVehicleStatusFromGrid(driver, "Active services only", true);
        RC_Global.panelAction(driver, "close", "Vehicle Details", false,true);
		RC_Global.waitElementVisible(driver, 90, "//div[text()='Spend LTD:']", "Maintenance", false, false);	
		
	//	RC_Global.verifyScreenComponents(driver,"lable","Pending Approval PO's:", true);
	//	RC_Global.verifyScreenComponents(driver,"lable","Open PO's:", true);
	//	RC_Global.verifyScreenComponents(driver,"lable","Closed PO's LTD:", true);
		String label1 = driver.findElement(By.xpath("(//div[@id='maintSummaryPending']//parent::div//div)[1]")).getText();
		if(label1.contains("Pending Approval PO's:"))
		{
           String strValue = driver.findElement(By.xpath("((//div[contains(text(),'Pending Approval PO')])[1]//following::div)[3]")).getText();
            if(strValue.length()==0)
            {
                   queryObjects.logStatus(driver, Status.PASS, "To verify label "+label1+" is available with ", "empty value", null);
            }
            else
            {
                   queryObjects.logStatus(driver, Status.PASS, "To verify label "+label1+" is available with value ", strValue, null);
            }
		}
		else
		{
            queryObjects.logStatus(driver, Status.FAIL, "unable to find the label ", "", null);

		}
		
		String label2 = driver.findElement(By.xpath("(//div[@id='maintSummaryOpen']//parent::div//div)[1]")).getText();
		if(label2.contains("Open PO's:"))
		{
           String strValue = driver.findElement(By.xpath("((//div[contains(text(),'Open PO')])//following::div)[3]")).getText();
            if(strValue.length()==0)
            {
                   queryObjects.logStatus(driver, Status.PASS, "To verify label "+label2+" is available with ", "empty value", null);
            }
            else
            {
                   queryObjects.logStatus(driver, Status.PASS, "To verify label "+label2+" is available with value ", strValue, null);
            }
		}
		else
		{
            queryObjects.logStatus(driver, Status.FAIL, "unable to find the label ", "", null);

		}
		
		
		String label3 = driver.findElement(By.xpath("(//div[@id='maintSummaryClosed']//parent::div//div)[1]")).getText();
		if(label3.contains("Closed PO's LTD:"))
		{
           String strValue = driver.findElement(By.xpath("//button[contains(@title,'For Closed POs')]")).getText();
            if(strValue.length()==0)
            {
                   queryObjects.logStatus(driver, Status.PASS, "To verify label "+label3+" is available with ", "empty value", null);
            }
            else
            {
                   queryObjects.logStatus(driver, Status.PASS, "To verify label "+label3+" is available with value ", strValue, null);
            }
		}
		else
		{
            queryObjects.logStatus(driver, Status.FAIL, "unable to find the label ", "", null);

		}
		
		RC_Global.verifyScreenComponents(driver,"lable","Spend LTD:", false);
		RC_Global.verifyScreenComponents(driver,"lable","PM Spend LTD:", false);
		RC_Global.verifyScreenComponents(driver,"lable","Brakes LTD:", false);
		RC_Global.verifyScreenComponents(driver,"lable","Tires LTD:", false);
		RC_Global.verifyScreenComponents(driver,"lable","Non-Preventive LTD:", false);
		RC_Global.verifyScreenComponents(driver,"lable","Last PM Date:", false);
		RC_Global.verifyScreenComponents(driver,"lable","Last PM Service Odometer:", false);
		RC_Global.verifyScreenComponents(driver,"lable","Maintenance RO History:", false);
		RC_Global.verifyScreenComponents(driver,"lable","Last Engine Hours:", false);
		
		//Verify the Field is Hyperlink or not
		RC_Global.createNode(driver, "Field Type Validation");
		String PenApp = RC_Manage.verifyFieldType(driver, "VehicleHyperlink", "maintSummaryPendingValue", false);
		String OpePo = RC_Manage.verifyFieldType(driver, "VehicleHyperlink", "maintSummaryOpenValue", false);
		String CloPo = RC_Manage.verifyFieldType(driver, "VehicleHyperlink", "maintSummaryClosedValue", false);//
		String SpeLT = RC_Manage.verifyFieldType(driver, "VehicleHyperlink", "maintSummarySpendLTDValue", false);
		String PMSpe = RC_Manage.verifyFieldType(driver, "VehicleHyperlink", "maintSummaryPMSpendLTDValue", false);
		String BraLTD = RC_Manage.verifyFieldType(driver, "VehicleHyperlink", "maintSummaryBrakesValue", false);
		String TirLT = RC_Manage.verifyFieldType(driver, "VehicleHyperlink", "maintSummaryTiresLTDValue", false);
		String NoPRE = RC_Manage.verifyFieldType(driver, "VehicleHyperlink", "maintSummaryTiresLTDNonValue", false);
		String LasPM= RC_Manage.verifyFieldType(driver, "VehicleHyperlink", "maintSummaryLastPMDateValue", false);
		String LastPMOdo = RC_Manage.verifyFieldType(driver, "VehicleHyperlink", "maintSummaryLastPMOdoValue", false);
		String  MaiRO =  RC_Manage.verifyFieldType(driver, "VehicleHyperlink", "maintSummaryMaintenancePOHistoryReportLink", false);
		String LasEng = RC_Manage.verifyFieldType(driver, "VehicleHyperlink", "lastEngineHoursValue", false);
		
		
		RC_Manage.validateDataType(driver,"Maintenance","Pending Approval PO's:" ,"Numeric", PenApp, false);
		RC_Manage.validateDataType(driver,"Maintenance","Open PO's:" ,"Numeric",OpePo , false);
		RC_Manage.validateDataType(driver,"Maintenance","Closed PO's LTD:" ,"Numeric",CloPo , false);
		RC_Manage.validateDataType(driver,"Maintenance","Spend LTD:" ,"Currency",SpeLT , false);
		RC_Manage.validateDataType(driver,"Maintenance","PM Spend LTD:" ,"Currency",PMSpe , false);
		RC_Manage.validateDataType(driver,"Maintenance","Brakes LTD:" ,"Currency",BraLTD , false);
		RC_Manage.validateDataType(driver,"Maintenance","Tires LTD:" ,"Currency",TirLT , false);
		RC_Manage.validateDataType(driver,"Maintenance","Non-Preventive LTD:" ,"Currency",NoPRE , false);
		
		if (LasPM!=""&& LasPM!=null) {
			RC_Manage.isValidDateFormat(driver, "M/dd/yyyy", "Last PM Date:", LasPM, false);
		}
		if (LastPMOdo!="" && LastPMOdo!=null) {
			RC_Manage.validateDataType(driver,"Maintenance","Last PM Service Odometer:" ,"Numeric", LastPMOdo, false);
		}
		RC_Manage.validateDataType(driver,"Maintenance","Maintenance RO History:" ,"AlphaNumeric", MaiRO, false);
		RC_Manage.validateDataType(driver,"Maintenance","Last Engine Hours:" ,"Numeric", LasEng, false);
		
		RC_Global.createNode(driver,"Verify Maintenance RO History as hypertext and download the PDF's");
		RC_Global.clickUsingXpath(driver,"//button[contains(@ng-click,'exportPdf()')]", "Maintenance RO History",false,true);
		Thread.sleep(5000);
        try {
        String home = System.getProperty("user.home");
             
        boolean flag = false;
        File listofFiles= new File(home+"/Downloads/" );
		// Check for the files available
        for (File file :listofFiles.listFiles() ) {
            String filename= file.getName();
		 if(filename.contains("Export")) {
			flag = true;
			file.delete();
				break;
				}	
			}
			if(flag){
				queryObjects.logStatus(driver, Status.PASS, "Verify Maintenance RO History as hypertext and download the PDF's", "Download Successful", null);}
			else {
				queryObjects.logStatus(driver, Status.FAIL, "Verify Maintenance RO History as hypertext and download the PDF's", "Download Failed", null);}
        	}
        catch (Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Download and verify failed", e.getLocalizedMessage(), e);
		}
		
		if(driver.findElements(By.xpath("//div[@id='maintSummaryPendingValue']/div/button")).size()>0)
		{
		RC_Global.createNode(driver,"Verify Pending Approval PO's as hypertext and navigate to Vehicle Details - Maintenance");
		RC_Global.clickUsingXpath(driver,"//div[@id='maintSummaryPendingValue']/div/button", "Pending Approval PO's",false,true);
		RC_Manage.waitUntilMethods(driver, "//div[contains(@class,'vehicle-details-section-spinner')]","class","ng-hide", "attribute visible");
		RC_Global.validateHeaderName(driver, "Vehicle Details - Maintenance",true);
		RC_Global.panelAction(driver, "close", "Vehicle Details - Maintenance", false,true);
		} else {
			queryObjects.logStatus(driver, Status.INFO, "NO Data link available in Pending Approval PO's", "Link click cannot be validated", null);
		}
		
		if(driver.findElements(By.xpath("//div[@id='maintSummaryOpenValue']/div/button")).size()>0)
		{
		RC_Global.createNode(driver,"Verify Open PO's as hypertext and navigate to Vehicle Details - Maintenance");
		RC_Global.clickUsingXpath(driver,"//div[@id='maintSummaryOpenValue']/div/button", "Open PO's",false,true);
		RC_Manage.waitUntilMethods(driver, "//div[contains(@class,'vehicle-details-section-spinner')]","class","ng-hide", "attribute visible");
		RC_Global.validateHeaderName(driver, "Vehicle Details - Maintenance",true);
		RC_Global.panelAction(driver, "close", "Vehicle Details - Maintenance", false,true);
		} else {
			queryObjects.logStatus(driver, Status.INFO, "NO Data link available in Open PO's", "Link click cannot be validated", null);
		}
		
		if(driver.findElements(By.xpath("//div[@id='maintSummaryClosedValue']/div/button")).size()>0)
		{
		RC_Global.createNode(driver,"Verify Closed PO's LTD as hypertext and navigate to Vehicle Details - Maintenance");
		RC_Global.clickUsingXpath(driver,"//div[@id='maintSummaryClosedValue']/div/button", "Closed PO's LTD",false,true);
		RC_Manage.waitUntilMethods(driver, "//div[contains(@class,'vehicle-details-section-spinner')]","class","ng-hide", "attribute visible");
		RC_Global.validateHeaderName(driver, "Vehicle Details - Maintenance",true);
		RC_Global.panelAction(driver, "close", "Vehicle Details - Maintenance", false,true);
		} else {
			queryObjects.logStatus(driver, Status.INFO, "NO Data link available in Closed PO's LTD field", "Link click cannot be validated", null);
		}
		
		if(driver.findElements(By.xpath("//div[@id='maintSummarySpendLTDValue']/div/button")).size()>0)
		{
		RC_Global.createNode(driver,"Verify Spend LTD as hypertext and navigate to Vehicle Details - Maintenance");
		RC_Global.clickUsingXpath(driver,"//div[@id='maintSummarySpendLTDValue']/div/button", "Spend LTD",false,true);
		RC_Manage.waitUntilMethods(driver, "//div[contains(@class,'vehicle-details-section-spinner')]","class","ng-hide", "attribute visible");
		RC_Global.validateHeaderName(driver, "Vehicle Details - Maintenance",true);
		RC_Global.panelAction(driver, "close", "Vehicle Details - Maintenance", false,true);
		} else {
			queryObjects.logStatus(driver, Status.INFO, "NO Data link available in Spend LTD field", "Link click cannot be validated", null);
		}
		
		if(driver.findElements(By.xpath("//div[@id='maintSummaryPMSpendLTDValue']/div/button")).size()>0)
		{
		RC_Global.createNode(driver,"Verify PM Spend LTD as hypertext and navigate to Vehicle Details - Maintenance");
		RC_Global.clickUsingXpath(driver,"//div[@id='maintSummaryPMSpendLTDValue']/div/button", "PM Spend LTD:",false,true);
		RC_Manage.waitUntilMethods(driver, "//div[contains(@class,'vehicle-details-section-spinner')]","class","ng-hide", "attribute visible");
		RC_Global.validateHeaderName(driver, "Vehicle Details - Maintenance",true);
		RC_Global.panelAction(driver, "close", "Vehicle Details - Maintenance", false,true);
		} else {
			queryObjects.logStatus(driver, Status.INFO, "NO Data link available in PM Spend LTD field", "Link click cannot be validated", null);
		}
		
		if(driver.findElements(By.xpath("//div[@id='maintSummaryBrakesValue']/div/button")).size()>0)
		{
		RC_Global.createNode(driver,"Verify Brakes LTD as hypertext and navigate to Vehicle Details - Maintenance");
		RC_Global.clickUsingXpath(driver,"//div[@id='maintSummaryBrakesValue']/div/button", "Brakes LTD",false,true);
		Thread.sleep(5000);
		RC_Global.validateHeaderName(driver, "Vehicle Details - Maintenance",true);
		RC_Global.panelAction(driver, "close", "Vehicle Details - Maintenance", false,true);
		} else {
			queryObjects.logStatus(driver, Status.INFO, "NO Data link available in Brakes LTD field", "Link click cannot be validated", null);
		}
		
		if(driver.findElements(By.xpath("//div[@id='maintSummaryTiresLTDValue']/div/button")).size()>0)
		{
		RC_Global.createNode(driver,"Verify Tires LTD as hypertext and navigate to Vehicle Details - Maintenance");
		RC_Global.clickUsingXpath(driver,"//div[@id='maintSummaryTiresLTDValue']/div/button", "Tires LTD",false,true);
		Thread.sleep(5000);
		RC_Global.validateHeaderName(driver, "Vehicle Details - Maintenance",true);
		RC_Global.panelAction(driver, "close", "Vehicle Details - Maintenance", false,true);
		} else {
			queryObjects.logStatus(driver, Status.INFO, "NO Data link available in Tires LTD field", "Link click cannot be validated", null);
		}
		
		if(driver.findElements(By.xpath("//div[@id='maintSummaryTiresLTDNonValue']/div/button")).size()>0)
		{
		RC_Global.createNode(driver,"Verify Non-Preventive LTD as hypertext and navigate to Vehicle Details - Maintenance");
		RC_Global.clickUsingXpath(driver,"//div[@id='maintSummaryTiresLTDNonValue']/div/button", "Non-Preventive LTD",false,true);
		RC_Manage.waitUntilMethods(driver, "//div[contains(@class,'vehicle-details-section-spinner')]","class","ng-hide", "attribute visible");
		RC_Global.validateHeaderName(driver, "Vehicle Details - Maintenance",true);
		RC_Global.panelAction(driver, "close", "Vehicle Details - Maintenance", false,true);
		} else {
			queryObjects.logStatus(driver, Status.INFO, "NO Data link available in Non-Preventive LTD field", "Link click cannot be validated", null);
		}
		
		
		
		if(driver.findElements(By.xpath("//div[@id='maintSummaryLastPMDateValue']/div/button")).size()>0)
		{
		RC_Global.createNode(driver,"Verify Last PM Date as hypertext and navigate to Vehicle Details - Maintenance");
		if((LasPM == ""||LasPM == null)) {
		RC_Global.clickUsingXpath(driver,"//button[contains(@ng-click,'PONumber')]", "Last PM Date",false,true);
		Thread.sleep(5000);
		RC_Global.validateHeaderName(driver, "Vehicle Details - Maintenance",true);
		RC_Global.panelAction(driver, "close", "Vehicle Details - Maintenance", false,true);
		} else {
			queryObjects.logStatus(driver, Status.INFO, "NO Data link available in Last PM Date field", "Link click cannot be validated", null);
		}
		} else {
			queryObjects.logStatus(driver, Status.INFO, "NO Data link available in Last PM Date field", "Link click cannot be validated", null);
		}
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}

		

}
