package Manage.Administration.VehicleDetails;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_11_17 {

	public void VehicleDetails_ValidateRemarketingGBUY_OpenEndAgreementTypeUsingExternalUser(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
	        String UnitNumber = "";
			
			WebDriverWait wait = new WebDriverWait(driver,60);
			
			RC_Global.externalUserLogin(driver, "TestextFM", "");
			RC_Global.navigateTo(driver, "Manage", "Administration", "Vehicle Details");
			RC_Global.waitUntilPanelVisibility(driver, "Vehicle Details", "TV", false, false);
			
			if(driver.findElements(By.xpath("(//input[@name='customerInput' and @disabled='disabled'])[2]")).size()>0)
				{
					queryObjects.logStatus(driver, Status.PASS, "Customer # entered by default and disabled", "Successfully", null);
			    }
	        else
		        {
		        	queryObjects.logStatus(driver, Status.FAIL,"Customer # not entered by default and disabled", "", null);
		        }
			
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//select[@id='vehicleStatus']/option[text()='Active lease']")));	
			        
			RC_Global.enterInput(driver, "509955", driver.findElement(By.xpath("//input[@placeholder='Unit Number']")), false, true);
			Thread.sleep(2000);		
			driver.findElement(By.xpath("//select[@id='vehicleStatus']/option[@value][1]")).click();
			RC_Manage.multipleSelectSearchFilter(driver, "vehicleStatus", "Active lease;Active services only;Cancelled;Closed;On Order;Pending Activation;Pending termination;Sold;Terminated lease;Terminated services only", false);
			RC_Global.clickUsingXpath(driver, "//div/button[text()='Search']", "Search button", true, false);
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@ng-show='tableDataLoading || !tableDataLoaded']/i[@class='fa fa-spinner fa-spin ng-scope']")));
			Thread.sleep(6000);
		//	RC_Global.clickButton(driver, "Search", false,true);
			
			if(driver.findElements(By.xpath("//div[text()='Vehicle Status:']/following-sibling::div/span/span[text()='Sold']")).size()>0)
			{	
				Thread.sleep(2000);
				
			}
			else if(driver.findElements(By.xpath("(//div/span[text()='No Results'])[1]")).size()>0)
			{	Thread.sleep(2000);
				
				 String Sql ="SELECT TOP 1 UnitNumber = UnitNumber\r\n" + 
				 		"     , GuaranteedBuyOffer = IIF(IsForRemarketing = 1, 0, NetValue)\r\n" + 
				 		"	 ,IsUnitGuaranteedBuy = 1\r\n" + 
				 		"\r\n" + 
				 		"FROM Inventory_Profile";
				 RC_Global.database(Sql);
			
	        queryObjects.logStatus(driver, Status.INFO, "Unit Number fetched from DB for vehicle status GBUY-Open End---->", RC_Global.unitNum, null);

	        RC_Global.clickButton(driver, "Reset", false, false);
	        RC_Global.enterInput(driver, RC_Global.unitNum, driver.findElement(By.xpath("//input[@placeholder='Unit Number']")), false, true);
	        RC_Manage.multipleSelectSearchFilter(driver, "vehicleStatus", "Active lease;Active services only;Cancelled;Closed;On Order;Pending Activation;Pending termination;Sold;Terminated lease;Terminated services only", false);
	        RC_Global.clickButton(driver, "Search", false,true);
	        RC_Global.waitElementVisible(driver, 60, "//h5/span[text()='Vehicle Details']", "Vehicle Details", false, true);
			}
			RC_Manage.waitUntilMethods(driver, "//div[@ng-show='isBillingSummaryLoading']","class","ng-hide", "attribute visible");
			Thread.sleep(2000);

			RC_Global.createNode(driver, "Verify Vehicle status and Agreement type");
		        String VehicleStatus = driver.findElement(By.xpath("//div[text()='Vehicle Status:']/following-sibling::div/span/span")).getText();
		 //       		"Sold";
		        String AgreementType = driver.findElement(By.xpath("//div[text()='Agreement Type:']/following-sibling::div/span/span")).getText();
		//        		"Open End";
		       
		        if(VehicleStatus.equals("Sold"))
		        {
		        	queryObjects.logStatus(driver, Status.PASS, "Vehicle Status-"+VehicleStatus+" for unit matches---->", UnitNumber, null);
		        }
		        else
		        {
		        	queryObjects.logStatus(driver, Status.FAIL, "Vehicle Status-"+VehicleStatus+" for unit not matches---->", UnitNumber, null);
		        }
		        
		        if(AgreementType.equals("Open End"))
		        {
		        	queryObjects.logStatus(driver, Status.PASS, "Agreement Type-"+AgreementType+" for unit matches---->", UnitNumber, null);
		        }
		        else
		        {
		        	queryObjects.logStatus(driver, Status.FAIL, "Agreement Type-"+AgreementType+" for unit not matches---->", UnitNumber, null);
		        }
		        
		        RC_Global.scrollById(driver, "//button[@id='vehicleDetailsRemarketingSummaryHeader']");
		        RC_Global.createNode(driver, "Verify fields are not displayed under Remarketing Section");
		        RC_Manage.validateNoSectionFieldDatas(driver, "Remarketing", "Net Auction Proceeds", "//div[contains (@id,'NetAuctionProceeds')][1]", true);
		        RC_Manage.validateNoSectionFieldDatas(driver, "Remarketing", "Net Sale Amount", "//div[contains (@id,'NetSaleAmount')][1]", true);
		        RC_Manage.validateNoSectionFieldDatas(driver, "Remarketing", "Net Residual", "//div[contains (@id,'NetResidual')][1]", true);		       
		        RC_Manage.validateNoSectionFieldDatas(driver, "Remarketing", "Condition Report", "//div[contains (@id,'ConditionReport')][1]", true);
		        		      
		        RC_Global.clickUsingXpath(driver, "//button/strong[text()='Remarketing']", "Remarketing link", false, true);
		
		        RC_Global.panelAction(driver, "close", "Vehicle Details", false, false);
		        
		        RC_Global.waitElementVisible(driver, 60, "//h5/span[text()='Vehicle Details - Remarketing']", "Vehicle Details - Remarketing", false, true);
		        RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='isMenuLoading'])[1]","class","ng-hide", "attribute visible");
		        RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		        if(driver.findElements(By.xpath("//li[contains(@class,'active')]/button[normalize-space(text()='Term')]")).size()>0)
		        {
		        	queryObjects.logStatus(driver, Status.PASS, "Verify by default 'Terms' tab is selected in Vehicle Details - Remarketing screen", "Sucessfully", null);
		        }
		        else{
		        	queryObjects.logStatus(driver, Status.FAIL, "By default 'Terms' tab is not selected in Vehicle Details - Remarketing screen", " ", null);
		        }
		        
		        RC_Global.createNode(driver, "Verify field displayed under Terms Tab");		     
		        RC_Manage.validateNoSectionFieldDatas(driver, "Remarketing", "Guaranteed Buy Offer", "//div[contains(@id,'GuaranteedBuyOffer')][1]", true);		        
		        RC_Manage.validateNoSectionFieldDatas(driver, "Remarketing", "Odometer Reading", "//div[contains(@id,'OdometerReading')][1]", true);
		        
		        RC_Global.createNode(driver, "Verify field data displayed under Terms Tab");	
		        String GuaranteedBuyOffer = driver.findElement(By.xpath("//div[text()='Guaranteed Buy Offer:']//following-sibling::div")).getText();
				String OdometerReading = driver.findElement(By.xpath("//div[text()='Odometer Reading:']//following-sibling::div")).getText();
				
				RC_Manage.validateDataType(driver,"Remarketing","Guaranteed Buy Offer" ,"Currency",GuaranteedBuyOffer , false);
		        RC_Manage.validateDataType(driver,"Remarketing","Odometer Reading" ,"Numeric",OdometerReading , false);
		        
		        RC_Global.scrollById(driver, "(//h5/span[contains(text(),'Vehicle Details')])[1]");
		        RC_Global.panelAction(driver, "close", "Vehicle Details - Remarketing", false,true);
		        RC_Global.logout(driver, false);
	
			queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	
	}
}
