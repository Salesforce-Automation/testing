package Manage.Administration.VehicleDetails;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_11_09 {

	public void VehicleDetails_ValidateAcquisitionSectionFields(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Vehicle Details";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details","TV", true,false);
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", false);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.waitElementVisible(driver, 60, "//table//tbody//tr//td[1]", "Grid Result", false, false);
		RC_Manage.selectRowWithVehicleStatusFromGrid(driver, "Active services only", true);
		RC_Global.panelAction(driver, "xpathclose", "(//h5[span[contains(text(),'Vehicle Details')]])[1]", false,true);
		RC_Manage.waitUntilMethods(driver, "//div[@ng-show='isAcquisitionSummaryLoading']","class","ng-hide", "attribute visible");
		RC_Global.waitElementVisible(driver, 60, "//div[text()='Acquisition Type:']", "Vehicle Details search result", false, false);
		
		RC_Global.verifyScreenComponents(driver,"lable","Vehicle Description:", true);
		RC_Global.verifyScreenComponents(driver,"lable","VIN:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Exterior Color:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Acquisition Type:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Delivering Dealer:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Delivered Date:", true);
		RC_Global.verifyScreenComponents(driver,"lable","GVWR:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Upfit:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Previous Unit #:", true);
		RC_Global.verifyScreenComponents(driver,"lable","New Unit #:", true);
		
		String vehicleDes = driver.findElement(By.xpath("(//button[contains(@title,'Open Acquisition Vehicle Overview')])[1]")).getText();
		queryObjects.logStatus(driver, Status.PASS, "The Vehicle description is a hyperlink and it value is ---->",vehicleDes, null);
		String vin = driver.findElement(By.xpath("(//button[contains(@title,'Open Acquisition Vehicle Overview')])[2]")).getText();
		queryObjects.logStatus(driver, Status.PASS, "The VIN is a hyperlink and it value is ---->",vin, null);
		String Acquisitiontype = driver.findElement(By.xpath("//button[contains(@title,'Open Acquisition Order Detail')]")).getText();
		queryObjects.logStatus(driver, Status.PASS, "The Acquisition Type is a hyperlink and it value is ---->",Acquisitiontype, null);
		String Deliverydate = driver.findElement(By.xpath("(//button[contains(@title,'Open Life Cycle Dates')])[1]")).getText();
		queryObjects.logStatus(driver, Status.PASS, "The Delivered Date is a hyperlink and it value is ---->",Deliverydate, null);
		String Unitno = driver.findElement(By.xpath("(//button[contains(@title,'Open Next Unit')])[1]")).getText();
		queryObjects.logStatus(driver, Status.PASS, "The New Unit # is a hyperlink and it value is ---->",Unitno, null);
		
		String Gvwr = driver.findElement(By.xpath("//div[text()='GVWR:']//following-sibling::div")).getText();
		queryObjects.logStatus(driver, Status.PASS, "The GVWR value displayed as",Gvwr, null);
		String Upfit = driver.findElement(By.xpath("//div[text()='Upfit:']//following-sibling::div")).getText();
		//check data type
		RC_Manage.validateDataType(driver,"Acquisition","Vehicle description" ,"AlphaNumeric", vehicleDes, false);
		RC_Manage.validateDataType(driver,"Acquisition","VIN" ,"AlphaNumeric", vin, false);
		RC_Manage.validateDataType(driver,"Acquisition","Acquisition Type" ,"Text", Acquisitiontype, false);
		RC_Manage.isValidDateFormat(driver, "M/dd/yyyy", "Delivered Date", Deliverydate, false);
		RC_Manage.validateDataType(driver,"Acquisition","GVWR" ,"Text", Gvwr, false);
		RC_Manage.validateDataType(driver,"Acquisition","Upfit" ,"Boolean", Upfit, false);
		RC_Manage.validateDataType(driver,"Acquisition","New Unit #" ,"Numeric", Unitno, false);
		
		
		RC_Global.clickUsingXpath(driver, "(//button[contains(@title,'Open Acquisition Vehicle Overview')])[1]", "Vehicle description", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details - Acquisition","TV", true,false);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		String Vehicleoverview = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[1]")).getText();
		queryObjects.logStatus(driver, Status.PASS, " "+Vehicleoverview+" Sub - section is","selected", null);
		RC_Global.panelAction(driver, "close", "Vehicle Details - Acquisition", false,true);
		
		RC_Global.clickUsingXpath(driver, "(//button[contains(@title,'Open Acquisition Vehicle Overview')])[2]", "VIN", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details - Acquisition","TV", true,false);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		String Vehicleoverview1 = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[1]")).getText();
		queryObjects.logStatus(driver, Status.PASS, " "+Vehicleoverview1+" Sub - section is","selected", null);
		RC_Global.panelAction(driver, "close", "Vehicle Details - Acquisition", false,true);
		
		RC_Global.clickUsingXpath(driver, "//button[contains(@title,'Open Acquisition Order Detail')]", "Acquisition Type", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details - Acquisition","TV", true,false);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		String Vehicleoverview2 = driver.findElement(By.xpath("(//button[contains(@ng-click,'selectMenuItem')])[2]")).getText();
		queryObjects.logStatus(driver, Status.PASS, " "+Vehicleoverview2+" Sub - section is","selected", null);
		RC_Global.panelAction(driver, "close", "Vehicle Details - Acquisition", false,true);
		
		RC_Global.clickUsingXpath(driver, "(//button[contains(@title,'Open Life Cycle Dates')])[1]", "Delivered Date", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details - Life Cycle Dates","TV", true,false);
		RC_Manage.waitUntilMethods(driver, "(//div[@ng-show='section.isLoading'])[1]","class","ng-hide", "attribute visible");
		RC_Global.panelAction(driver, "close", "Vehicle Details - Life Cycle Dates", false,true);
		
		if(driver.findElements(By.xpath("(//button[contains(@title,'Open Next Unit')])[1]")).size()==0) {
		RC_Global.clickUsingXpath(driver, "(//button[contains(@title,'Open Next Unit')])[1]", "New Unit #", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details","TV", true,false);
		Thread.sleep(2000);
		RC_Global.panelAction(driver, "close", "Vehicle Details", false,true);
		}
		else {
			queryObjects.logStatus(driver, Status.INFO, "The New Unit # field Data is ","Not Present", null);}
			
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
		
	}
}
