package Manage.Administration.VehicleDetails;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_11_15 {

	public void VehicleDetails_ValidateVehicleDetailsScreenUsingExternalUser(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Vehicle Details";
		String SearchFilters ="Unit Number;Customer Vehicle Number;Pool Name;Customer Number;Full VIN or Last 8;Driver First Name;Driver Last Name;Plate Number;Plate State;Vehicle Status";
		String SelectionOptions = "Active lease;Active services only;Cancelled;Closed;On Order;Pending Activation;Pending termination;Sold;Terminated lease;Terminated services only";
		
		RC_Global.externalUserLogin(driver, "kentuckytest", "Yes");
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details","TV", true,false);
		RC_Global.validateSpecifiedSearchFilters(driver, SearchFilters, false);
		RC_Global.validateMultipleSelectionFilter(driver, SelectionOptions, false);
		RC_Global.buttonStatusValidation(driver, "Search", "Presence", false);
		RC_Global.buttonStatusValidation(driver, "Reset", "Presence", false);
		RC_Global.buttonStatusValidation(driver, "Advanced Search", "Presence", false);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.waitElementVisible(driver, 60, "//table//tbody//tr//td[1]", "Grid Result", false, false);
		RC_Manage.selectRowWithVehicleStatusFromGrid(driver, "Active Lease", true);
		RC_Global.panelAction(driver, "xpathclose", "(//h5[span[contains(text(),'Vehicle Details')]])[1]", false,true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details","TV", true,false);
		RC_Global.waitElementVisible(driver, 60, "//div[text()='Total Fuel Spend LTD:']", "Fuel", false, false);
		
		RC_Global.verifyScreenComponents(driver,"sectionHeading","Acquisition", true);
		RC_Global.verifyScreenComponents(driver,"sectionHeading","Billing", true);
		RC_Global.verifyScreenComponents(driver,"sectionHeading","Fuel", true);
		RC_Global.verifyScreenComponents(driver,"sectionHeading","Maintenance", true);
		RC_Global.verifyScreenComponents(driver,"sectionHeading","License, Title & Insurance", true);
		RC_Global.verifyScreenComponents(driver,"sectionHeading","Remarketing", true);
		RC_Global.verifyScreenComponents(driver,"sectionHeading","Client Data", true);
		RC_Global.verifyScreenComponents(driver,"sectionHeading","Vehicle Programs", true);
		
		//Clicking on the Hyperlinks
		RC_Global.clickUsingXpath(driver, "(//div[text()='Latest Odometer:']//following::button)[1]", "Latest Odometer", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details - Odometer","TV", true,false);
		RC_Global.panelAction(driver, "close", "Vehicle Details - Odometer", false,true);
								
		//Clicking on the Hyperlinks
		RC_Global.clickUsingXpath(driver, "//div[text()='Driver:']//following-sibling::div//button", "Driver", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Driver Details","TV", true,false);
		RC_Global.panelAction(driver, "close", "Driver Details", false,true);
		
		RC_Global.scrollById(driver, "//div[text()='Last Transaction Date:']");
		RC_Global.downloadAndVerifyFileDownloaded(driver, "Export", "The Maintenance RO History PDF downloaded", false);
		
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//h5[span[contains(text(),'Vehicle Details')]])[1]")));
		RC_Global.panelAction(driver, "close", "Vehicle Details", false,true);
		
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
			
	}
	
}
