package Manage.Administration.DocumentUpload;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_7_03 {
	public void Documentupload_UploadDocumentUsingExternalUser(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String currentDate = RC_Manage.AddDateStr(0, "MM/dd/yyyy", "", null, "CST");
		String uploadFileName="Sample_Document.xlsx";
		String uploadFilePath= String.valueOf(String.valueOf(String.valueOf(System.getProperty("user.dir")))) + File.separator + "DocumentUpload" + File.separator + uploadFileName;
		
		String description="testingExtUser";
		
		RC_Global.externalUserLogin(driver, "kentuckytest1", "Yes");
		RC_Global.navigateTo(driver, "Manage", "Administration", "Document Upload");
		if(driver.findElement(By.xpath("(//div[@ng-show='customerChosen'])[1]/input")).getAttribute("value").contains("LS008737") && 
				driver.findElement(By.xpath("(//div[@ng-show='customerChosen'])[1]/input")).getAttribute("disabled").equals("true"))
		{
			queryObjects.logStatus(driver, Status.PASS, "Customer # is set to 'LS008737' and is grayed out. ", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Customer # is not set to 'LS008737' and is not grayed out. ", "", null);
		}
		String docDate=driver.findElement(By.xpath("//input[@name='documentDateField']")).getAttribute("value");
		if(currentDate.equals(docDate))
		{
			queryObjects.logStatus(driver, Status.PASS, "Document Date is today's date.", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Document Date is not today's date.", "", null);
		}
		if(driver.findElement(By.xpath("(//input[@type='checkbox'])[2]")).isSelected())
		{
			queryObjects.logStatus(driver, Status.PASS, "Visibility is set to 'Customer'", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Visibility is not set to 'Customer'", "", null);
		}
		RC_Global.selectDropdownOption(driver, "docTypeSelect", "Customer Document", false, true);
		RC_Global.createNode(driver, "Choose File");
		driver.findElement(By.xpath("//label[text()='Document File *']/following-sibling::input")).sendKeys(uploadFilePath);
		if(driver.findElement(By.xpath("//label[text()='Document File *']/following-sibling::input")).getAttribute("value").contains(uploadFileName))
		{
			queryObjects.logStatus(driver, Status.PASS, "File upload is successful",uploadFileName , null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.PASS, "File upload is not successful","" , null);
		}
		Thread.sleep(1000);
		WebElement descriptionElement = driver.findElement(By.xpath("//label[text()='Description *']/following-sibling::input"));
		RC_Global.enterInput(driver, description, descriptionElement, false, true);
		RC_Global.clickButton(driver, "Save Document", false, true);
		RC_Global.waitElementVisible(driver, 60, "//p[text()='Document Upload Successful']", "'Document Upload Successful' message is displayed", false, true);
		RC_Global.panelAction(driver, "close", "Document Upload", false, true);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Document Center");
		RC_Global.waitElementVisible(driver, 5, "(//span[text()='Document Center'])[2]", "'Document Center' screen is displayed", true,true);
		RC_Global.selectDropdownOption(driver, "docTypeSelect", "Customer Document", false, true);
		RC_Global.clickButton(driver, "Search", false, true);
		RC_Global.waitElementVisible(driver, 30, "//span[text()='Document Center Search Results']", "'Document Center Search Results' screen is displayed", false, true);
		RC_Global.panelAction(driver, "close", "Document Center", false, true);
		RC_Global.panelAction(driver, "expand", "Document Center Search Results", false, true);
		RC_Global.clickUsingXpath(driver, "//a[text()='Last']", "Last", false, true);
		int rowCount = driver.findElements(By.xpath("//table/tbody/tr")).size();
		System.out.println(rowCount);
		for(int i=rowCount;i>=1;i--)
		{
			String descriptionColValue= driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td[11]")).getText();
			String DateAdded= driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td[15]")).getText();
			if(descriptionColValue.equals(description) && DateAdded.equals(currentDate))
			{
				WebElement docImg = driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td[16]/div/img"));
				String chkBox="//table/tbody/tr["+i+"]/td[18]/input";
				RC_Global.clickUsingXpath(driver, chkBox, "Check Box", false, true);
				Thread.sleep(2000);
				JavascriptExecutor executor = (JavascriptExecutor)driver;
				executor.executeScript("document.body.style.zoom = '60%'");
				Thread.sleep(2000);
				RC_Global.mouseHoverElement(driver, docImg, "Preview Document Image");
				if(driver.findElements(By.xpath("//iframe[@id='documentCenterPrintIFrame']/following-sibling::div")).size()>0)
				{
					queryObjects.logStatus(driver, Status.PASS, "Document is previewed", "", null);
				}
				else
				{
					queryObjects.logStatus(driver, Status.FAIL, "Document is not previewed", "", null);
				}
				executor.executeScript("document.body.style.zoom = '100%'");
				break;
			}
		}
		Thread.sleep(2000);
		RC_Global.downloadAndVerifyFileDownloaded(driver,"Export","Export To Excel Functionality", true);
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	
	}
	
}
