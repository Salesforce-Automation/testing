package Manage.Administration.DocumentUpload;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_7_02 {
	public void DocumentUpload_SaveDocument(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String uploadFileName="Sample_Document.xlsx";
		String uploadFilePath= String.valueOf(String.valueOf(String.valueOf(System.getProperty("user.dir")))) + File.separator + "DocumentUpload" + File.separator + uploadFileName;
		
		String currentDate = RC_Manage.AddDateStr(0, "MM/dd/yyyy", "", null, "CST");
		
		RC_Global.login(driver);
		RC_Global.waitElementVisible(driver, 10, "//span[text()='LS000000 - Merchants Portfolio']", "", false,false);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Document Upload");
		RC_Global.waitElementVisible(driver, 5, "(//span[text()='Document Upload'])[2]", "'Document Upload' screen is displayed", true,true);
		RC_Global.createNode(driver, "Verify the fields in Document Upload Page");
		if(driver.findElements(By.xpath("//label[text()=' Customer Number ']/following-sibling::input")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Customer Number *' field is displayed in the 'Document Upload' screen", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "'Customer Number *' field is not displayed in the 'Document Upload' screen", "", null);
		}
		if(driver.findElements(By.xpath("//label[text()='Unit #']/following-sibling::input")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Unit #' field is displayed in the 'Document Upload' screen", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "'Unit #' field is not displayed in the 'Document Upload' screen", "", null);
		}
		if(driver.findElements(By.xpath("//label[text()='Document Type *']/following-sibling::select")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Document Type *' dropdown is displayed in the 'Document Upload' screen", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "'Document Type *' dropdown is not displayed in the 'Document Upload' screen", "", null);
		}
		if(driver.findElements(By.xpath("//label[text()='Document File *']/following-sibling::input")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Document File' field is displayed in the 'Document Upload' screen", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "'Document File' field is not displayed in the 'Document Upload' screen", "", null);
		}
		if(driver.findElements(By.xpath("//label[text()='Visibility']/following-sibling::div")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Visibility' field is displayed in the 'Document Upload' screen", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "'Visibility' field is not displayed in the 'Document Upload' screen", "", null);
		}
		if(driver.findElements(By.xpath("//label[text()='Document Date *']/following-sibling::p/input")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Document Date *' field is displayed in the 'Document Upload' screen", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "'Document Date *' field is not displayed in the 'Document Upload' screen", "", null);
		}
		if(driver.findElements(By.xpath("//label[text()='Description *']/following-sibling::input")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Description *' field is displayed in the 'Document Upload' screen", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "'Description *' field is not displayed in the 'Document Upload' screen", "", null);
		}
		RC_Global.createNode(driver, "Verify the buttons in Document Upload page");
		if(driver.findElements(By.xpath("//button[text()=' Save Document ']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Save Document' button is displayed in the 'Document Upload' screen", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "'Save Document' button is not displayed in the 'Document Upload' screen", "", null);
		}
		WebElement ChooseFileElement = driver.findElement(By.xpath("//label[text()='Document File *']/following-sibling::input"));
		WebElement DateElement = driver.findElement(By.xpath("//label[text()='Document Date *']/following-sibling::p/input"));
		WebElement DescriptionElement = driver.findElement(By.xpath("//label[text()='Description *']/following-sibling::input"));
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", false);
		RC_Global.selectDropdownOption(driver, "docTypeSelect", "Customer Document", false, true);
		RC_Global.createNode(driver, "Choose File");
		ChooseFileElement.sendKeys(uploadFilePath);
		if(ChooseFileElement.getAttribute("value").contains(uploadFileName))
		{
			queryObjects.logStatus(driver, Status.PASS, "File upload is successful",uploadFileName , null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.PASS, "File upload is not successful","" , null);
		}
		RC_Global.createNode(driver, "Set Visibility");
		if(driver.findElement(By.xpath("(//input[@type='checkbox'])[2]")).isSelected())
		{
			queryObjects.logStatus(driver, Status.PASS, "Visibility is set to 'Customer'", "", null);
		}
		else
		{
			RC_Global.clickUsingXpath(driver, "(//input[@type='checkbox'])[2]", "Customer Checkbox", false, false);
			queryObjects.logStatus(driver, Status.PASS, "Visibility is set to 'Customer'", "", null);
		}
		DateElement.clear();
		RC_Global.enterInput(driver, currentDate, DateElement, false, true);
		RC_Global.enterInput(driver, "desTesting02New", DescriptionElement, false, true);
		RC_Global.clickButton(driver, "Save Document", false, true);
		RC_Global.waitElementVisible(driver, 60, "//p[text()='Document Upload Successful']", "'Document Upload Successful' message is displayed", false, true);
		Thread.sleep(2000);
		RC_Global.panelAction(driver, "close", "Document Upload", false, true);
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}

}
