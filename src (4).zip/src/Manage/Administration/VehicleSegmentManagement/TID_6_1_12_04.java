package Manage.Administration.VehicleSegmentManagement;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.RandomUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_12_04 {

	public void AddAndEditVehicleSegmentManagement(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Vehicle Segment Management");
		RC_Global.validateHeaderName(driver, "Segment Management", true);
		RC_Global.clickUsingXpath(driver,"//a[contains(text(),'Segments')]", "Segments",false, true); 
		RC_Global.clickButton(driver, "Add", false, true);
		RC_Global.waitElementVisible(driver, 60, "//h3[text()='Add ']", "Add",false, false);
		RC_Global.validateSpecifiedSearchFilters(driver, "Segment Name", false);
		RC_Global.validateSpecifiedSearchFilters(driver, "Segment Code", false);
		RC_Global.clickUsingXpath(driver, "//input[@name='AssignIntervalsIndicator']", "Service Interval Assignable", false, true);
		RC_Manage.checkBoxValidation(driver,"Service Interval Assignable" , false);
		WebElement element = driver.findElement(By.xpath("//input[contains(@ng-model,'SegmentName')]"));
		String segmentname= RandomStringUtils.randomAlphabetic(5)+" Car";
		RC_Global.enterInput(driver, segmentname, element, false, true);
		String segementcode = RandomStringUtils.randomAlphabetic(3).toUpperCase();
		WebElement element1 = driver.findElement(By.xpath("//input[contains(@ng-model,'SegmentCode')]"));
		RC_Global.enterInput(driver, segementcode, element1, false, true);
		String segementcoden="";
		if(driver.findElements(By.xpath("//h4[text()='Segment Code already exists.']")).size()>1)
		{
			segementcoden = RandomStringUtils.randomAlphabetic(3).toUpperCase();
			RC_Global.enterInput(driver, segementcoden, element1, false, true);
		}
		RC_Global.clickButton(driver, " Save ", false, true);
		
	    Thread.sleep(2000);
	    RC_Global.enterInput(driver, segmentname, driver.findElement(By.xpath("//input[@ng-model='vm.name']")), false, true);
	    driver.findElement(By.xpath("(//button[text()='Search'])[3]")).click();
		Thread.sleep(2000);
	    if(driver.findElements(By.xpath("//standard-grid//div[2]//div[1]/div[text()='"+segmentname+"']")).size()>0)
	    {
	    	queryObjects.logStatus(driver, Status.PASS, "Grid Displays newly added segment name value:"+segmentname+"", "Successfully", null);
	    }
	    else {
    	   
			queryObjects.logStatus(driver, Status.WARNING, "Grid Not Displays newly added segment name value", "", null);
       	}
	    if(driver.findElements(By.xpath("//standard-grid//div[2]//div[2]/div[text()='"+segementcode+"']")).size()>0)
	    {
	    	queryObjects.logStatus(driver, Status.PASS, "Grid Displays newly added segment name value:"+segementcode+"", "Successfully", null);
	    }
	  
	    else if(driver.findElements(By.xpath("//standard-grid//div[2]//div[1]/div[text()='"+segementcoden+"']")).size()>0)
	    {
	    	queryObjects.logStatus(driver, Status.PASS, "Grid Displays newly added segment name value:"+segementcoden+"", "Successfully", null);
	    }
	    else {
	    	   
			queryObjects.logStatus(driver, Status.WARNING, "Grid Not Displays newly added segment name value", "", null);
	    }
	    driver.findElement(By.xpath("(//button[text()='Reset'])[3]")).click();
		RC_Global.clickUsingXpath(driver, "(//a[text()='Edit'])[2]", "Edit", false, true);
		RC_Global.waitElementVisible(driver, 60, "//h3[text()='Edit ']", "Edit",false, false);
		
		
		WebElement element2 = driver.findElement(By.xpath("//input[contains(@ng-model,'SegmentName')]"));
		String segmentname1 = RandomStringUtils.randomAlphabetic(5)+" Car";
		RC_Global.enterInput(driver, segmentname1, element2, false, true);
		
		String segementcode1 = RandomStringUtils.randomAlphabetic(3).toUpperCase();
		WebElement element3 = driver.findElement(By.xpath("//input[contains(@ng-model,'SegmentCode')]"));
		RC_Global.enterInput(driver, segementcode1, element3, false, true);
		String segementcodens ="";
		if(driver.findElements(By.xpath("//h4[text()='Segment Code already exists.']")).size()>1)
		{
			 segementcodens = RandomStringUtils.randomAlphabetic(3).toUpperCase();
			RC_Global.enterInput(driver, segementcodens, element3, false, true);
		}
		
		RC_Global.clickButton(driver, " Save ", false, true);
		
		Thread.sleep(2000);
		RC_Global.enterInput(driver, segmentname1, driver.findElement(By.xpath("//input[@ng-model='vm.name']")), false, true);
		driver.findElement(By.xpath("(//button[text()='Search'])[3]")).click();
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//standard-grid//div[2]//div[1]/div[text()='"+segmentname1+"']")).size()>0)
	    {
	    	queryObjects.logStatus(driver, Status.PASS, "Grid Displays newly added segment name value:"+segmentname1+"", "Successfully", null);
	    }
	    else {
    	   
			queryObjects.logStatus(driver, Status.WARNING, "Grid Not Displays newly added segment name value", "", null);
       	}
	    if(driver.findElements(By.xpath("//standard-grid//div[2]//div[2]/div[text()='"+segementcode1+"']")).size()>0)
	    {
	    	queryObjects.logStatus(driver, Status.PASS, "Grid Displays newly added segment name value:"+segementcode1+"", "Successfully", null);
	    }
	  
	    else if(driver.findElements(By.xpath("//standard-grid//div[2]//div[1]/div[text()='"+segementcodens+"']")).size()>0)
	    {
	    	queryObjects.logStatus(driver, Status.PASS, "Grid Displays newly added segment name value:"+segementcodens+"", "Successfully", null);
	    }
	    else {
	    	   
			queryObjects.logStatus(driver, Status.WARNING, "Grid Not Displays newly added segment name value", "", null);
	    }
	    driver.findElement(By.xpath("(//button[text()='Reset'])[3]")).click();
			
	  RC_Global.downloadAndVerifyFileDownloaded(driver, "Export", "Export to Excel", false);
	  RC_Global.panelAction(driver, "close", "Segment Management", false, false);
	  	
	  RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
