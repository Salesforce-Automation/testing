package Manage.Administration.VehicleSegmentManagement;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_12_01 {
	
	public void  MappingRules_ChangeMerchantsSegment (WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
	
		String ColumnNames = "Make;Model;Trim;Merchants Segment";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Vehicle Segment Management");
		RC_Global.validateHeaderName(driver, "Segment Management", true);
		
		if(driver.findElements(By.xpath("//ul/li/a[text()='Manual Assignment']")).size()>1)
		{
			queryObjects.logStatus(driver, Status.INFO, "Segment Management screen open with default view being on the Manual Assignment tab", "", null);
		}
		
		RC_Global.clickUsingXpath(driver, "//ul/li/a[text()='Mapping Rules']", "Mapping Rules Tab", false, true);
		
		RC_Manage.verifyGridColumnNames(driver, ColumnNames, false);
		
		RC_Global.clickUsingXpath(driver, "//ul/li/a[text()='Segments']", "Segments Tab", false, true);
		Thread.sleep(2000);
		String Segment = driver.findElement(By.xpath("(//vehicle-segments//standard-grid//div[14]/div/div[1]/div)[1]")).getText();
		RC_Global.clickUsingXpath(driver, "//ul/li/a[text()='Mapping Rules']", "Mapping Rules Tab", false, true);
		
		RC_Manage.segmentValidation(driver, Segment, false);
		
		RC_Global.createNode(driver, "Validation of Type-ahead feature dropdown values");
		String textToSelect = "Truck";		
		WebElement element = driver.findElement(By.xpath("(//vehicle-segment-mapping-rules//standard-grid//div[4]/div/input)[1]"));
		String input = "Truck";
		RC_Global.enterInput(driver, input, element, false, false);
		Thread.sleep(2000);
		queryObjects.logStatus(driver, Status.INFO, "Type-ahead entered input: ", input, null);
		List<WebElement> optionsToSelect = driver.findElements(By.xpath("//li[@class='uib-typeahead-match ng-scope active']/a"));
		Thread.sleep(2000);
		for(WebElement option : optionsToSelect){
			queryObjects.logStatus(driver, Status.INFO, "Option displayed: ", ""+option.getText()+"", null);
			  Thread.sleep(2000);
		    if(option.getText().contains(textToSelect)) {
		    	queryObjects.logStatus(driver, Status.INFO, "selects the type ahead option : ", textToSelect, null);
		        option.click();
		      
		        break;
		    }
		    else
		    {
		    	queryObjects.logStatus(driver, Status.WARNING, "No type ahead option value displays ", "", null);
		    }
		    }
		RC_Global.clickUsingXpath(driver, "(//button[text()='Save'])[2]", "Save Button", false, true);
		RC_Global.verifyDisplayedMessage(driver, "Saved Successfully", false);
		RC_Global.panelAction(driver, "close", "Segment Management", false, true);
		RC_Global.logout(driver, false);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
