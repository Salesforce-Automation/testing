package Manage.Administration.VehicleSegmentManagement;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_12_02 {
	public void ManualAssignment_AssignSegmentToVehicle(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String selSegment = "";
		RC_Global.login(driver);
		RC_Global.waitElementVisible(driver, 10, "//span[text()='LS000000 - Merchants Portfolio']", "", false, false);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Vehicle Segment Management");
		Thread.sleep(1000);
		RC_Global.panelAction(driver, "compress", "Segment Management", false, false);
		Thread.sleep(2000);
		RC_Global.panelAction(driver, "expand", "Segment Management", false, false);
		List<String> uniqueUnitDetails = RC_Manage.uniqueUnitNumberSelection(driver, false);
		String make = uniqueUnitDetails.get(0);
		String model = uniqueUnitDetails.get(1);
		String trim = uniqueUnitDetails.get(2);
		String unitNumber = uniqueUnitDetails.get(3);
		WebElement UnitNumberInput = driver.findElement(By.xpath("//input[@id='vehicleUnitNumber']"));
		RC_Global.enterInput(driver, unitNumber, UnitNumberInput, false, true);
		RC_Global.clickUsingXpath(driver, "(//button[text()='Search'])[1]", "Search", true, true);
		Thread.sleep(1000);
		RC_Global.waitElementVisible(driver, 20, "//div[@class='ui-grid-row ng-scope'][1]", "Segment grid is displayed", true, true);
		String SegmentToSelect="Compact Sedan";
		WebElement SegmentInputField = driver.findElement(By.xpath("(//input[contains(@uib-typeahead,'SegmentName')])[1]"));
		RC_Global.enterInput(driver, SegmentToSelect, SegmentInputField, false, true);
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//strong[text()='Compact Sedan'])[1]")).click();
		Thread.sleep(1000);
		selSegment = driver.findElement(By.xpath("(//input[contains(@name,'Segment_uiGrid')])")).getAttribute("value");
		RC_Global.clickUsingXpath(driver, "(//button[text()='Save'])[1]", "Save", true, true);
		Thread.sleep(5000);
		RC_Global.enterInput(driver, unitNumber, UnitNumberInput, false, true);
		RC_Global.clickUsingXpath(driver, "(//button[text()='Search'])[1]", "Search", true, true);
		Thread.sleep(3000);
		if(driver.findElements(By.xpath("(//span[@id='tableStatusNoResults'])[1]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Updated record is disappeared from Manual Assignment Screen", "", null);
		}
		RC_Global.clickUsingXpath(driver, "//a[text()='Mapping Rules']", "Mapping Rules", true, true);
		//RC_Global.panelAction(driver, "expand", "Segment Management", false, true);
		WebElement MakeInputField = driver.findElement(By.xpath("(//input[@ng-model='vm.vehicleMake'])[2]"));
		WebElement ModelInputField =driver.findElement(By.xpath("(//input[@ng-model='vm.vehicleModel'])[2]"));
		WebElement TrimInputField =driver.findElement(By.xpath("(//input[@ng-model='vm.vehicleTrim'])[2]"));
		RC_Global.enterInput(driver, make, MakeInputField, false, true);
		RC_Global.enterInput(driver, model, ModelInputField, false, true);
		RC_Global.enterInput(driver, trim, TrimInputField, false, true);
		RC_Global.enterInput(driver, selSegment, driver.findElement(By.xpath("//input[@id='segmentName']")), false, true);
		
		RC_Global.clickUsingXpath(driver, "//button[@id='segment-mapping-rule-search']", "Search", true, true);
		RC_Global.waitElementVisible(driver, 40, "(//div[@class='ui-grid-row ng-scope'][1])", "Segment grid is displayed", true, true);
		Thread.sleep(5000);
		String MappingRulesMake=driver.findElement(By.xpath("((//div[@class='ui-grid-canvas'])[2]/div/div/div/div)[1]")).getText().toUpperCase();
		String MappingRulesModel=driver.findElement(By.xpath("((//div[@class='ui-grid-canvas'])[2]/div/div/div/div)[2]")).getText();
		String MappingRulesTrim=driver.findElement(By.xpath("((//div[@class='ui-grid-canvas'])[2]/div/div/div/div)[3]")).getText();
		if(MappingRulesMake.contains(make.toUpperCase()))
		{
			queryObjects.logStatus(driver, Status.PASS, "Make for the selected Segment is displayed", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Make for the selected Segment is not displayed", "Expected->"+make+" Actual->"+MappingRulesMake,  null);
		}
		if(MappingRulesModel.equalsIgnoreCase(model))
		{
			queryObjects.logStatus(driver, Status.PASS, "Model for the selected Segment is displayed", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Model for the selected Segment is not displayed", "Expected->"+model+" Actual->"+MappingRulesModel, null);
		}
		if(MappingRulesTrim.equalsIgnoreCase(trim))
		{
			queryObjects.logStatus(driver, Status.PASS, "Trim for the selected Segment is displayed", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Trim for the selected Segment is not displayed", "Expected->"+trim+" Actual->"+MappingRulesTrim, null);
		}
		RC_Global.panelAction(driver, "close", "Segment Management", false, false);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Vehicle Details"); 
		UnitNumberInput = driver.findElement(By.xpath("//input[@placeholder='Unit Number']"));
		RC_Global.enterInput(driver, unitNumber, UnitNumberInput, false, true);
		RC_Global.clickButton(driver, "Search", true, true);
		RC_Global.waitElementVisible(driver, 30, "//strong[text()='Acquisition']", "", false, false);
		RC_Global.clickUsingXpath(driver, "//strong[text()='Acquisition']", "Acquisition", true, true);
		Thread.sleep(2000);
		RC_Global.waitElementVisible(driver, 30, "//div[text()='Segment:']", "", false, false);
		if(driver.findElements(By.xpath("//h3[text()='Vehicle Overview']")).size()>0)
		{	
			queryObjects.logStatus(driver, Status.PASS, "Vehicle Overview screen is displayed", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Vehicle Overview screen is not displayed", "", null);
		}
		if(driver.findElement(By.xpath("(//div[text()='Segment:']/../div)[2]")).getText().contains(SegmentToSelect))
		{
			queryObjects.logStatus(driver, Status.PASS, "Segment field is displaying the selected Segment", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Segment field is not displaying the selected Segment", "", null);
		}
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}

}
