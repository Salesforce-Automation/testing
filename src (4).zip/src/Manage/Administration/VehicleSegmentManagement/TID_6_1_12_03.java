package Manage.Administration.VehicleSegmentManagement;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_12_03 {

	public void ManualAssignment_CascadeSegmentAssignment(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		String txt= "";
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Vehicle Segment Management");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//li[contains(@class,'uib-tab nav-item')]//a[text()='Segments']")).click();
		Thread.sleep(2000);
		txt = driver.findElement(By.xpath("((//h3[text()='Merchants Segments']/parent::div/../..//div[@ui-grid-row='row'])//div[@class='ui-grid-cell-contents ng-binding ng-scope'])[4]")).getText();
		System.out.println(txt);
		Thread.sleep(1000);
		driver.findElement(By.xpath("//li[contains(@class,'uib-tab nav-item')]//a[text()='Manual Assignment']")).click();
		Thread.sleep(1000);
		RC_Manage.dropDownListBox(driver, false);
//		String dropdownvalues = "Acura Car;Alpine Car;AMG Car;APOLLO Car;Austin Car;autotest1570960030;BMW Car;Compact Cargo;Compact Pickup;Compact Sedan;Elite;Equipment;Fuel Only Card;Full Size Crossover;Full Size Sedan";
		RC_Manage.dropDownValuesSortedAlphabetically(driver , false);
		RC_Global.createNode(driver, "Validation of Type-ahead feature dropdown values");
        String textToSelect = txt.substring(2, txt.length());       
        WebElement element = driver.findElement(By.xpath("(//standard-grid//div[2]//div[1]//div[8]//input)[1]"));
        RC_Global.enterInput(driver,  txt.substring(0, 2) , element, false, false);
        Thread.sleep(1000);
        List<WebElement> optionsToSelect = driver.findElements(By.xpath("//li[@class='uib-typeahead-match ng-scope active']/a"));
        for(WebElement option : optionsToSelect){
            queryObjects.logStatus(driver, Status.INFO, "Option displayed: ", ""+option+"", null);
            if(option.getText().contains(textToSelect)) {
                queryObjects.logStatus(driver, Status.INFO, "selects the type ahead option : ", textToSelect, null);
                Thread.sleep(2000);
                option.click();
                break;
            }
            else
            {
                queryObjects.logStatus(driver, Status.WARNING, "No type ahead option value displays ", "", null);
            }
            }
        
        element.clear();
        RC_Global.clickUsingXpath(driver, "(//standard-grid//div[2]//div[1]//div[8]//input)[1]", "Segment", false, true);
        RC_Global.clickUsingXpath(driver, "(//standard-grid//div[2]//div[1]//div[8]//input//..//a)[2]", txt, false, true);
        RC_Manage.validateCascadeSegment(driver, txt, false);
        
        RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
