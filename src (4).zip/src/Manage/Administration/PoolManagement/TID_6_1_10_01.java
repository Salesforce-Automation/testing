package Manage.Administration.PoolManagement;



import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_10_01 {
	public void AddNewPoolDetailsForCustomer(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Pool Management";
		String SearchFilters="Change Pool;Status*;Pool Name*;First Name*;Last Name*;Email;Cell Phone;Work Phone;Home Phone;Alert Distribution Method*;Address 1*;Address 2;City*;County;Country";
		String FirstName="";
		WebElement element=null;
		
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.validateSpecifiedSearchFilters(driver, SearchFilters, false);
        RC_Global.enterCustomerNumber(driver, "LS008320", "", "", false);
        List<WebElement> dropDown = driver.findElements(By.xpath("//select[@ng-model='driverPool']/option"));
        int count = dropDown.size();
        queryObjects.logStatus(driver, Status.PASS, "Based on customer number displays dropdown value with size:",""+count+"", null);
        RC_Global.clickUsingXpath(driver, "//select[@ng-model='driverPool']", "Change Pool", false, true);
        RC_Global.selectDropdownOption(driver, "poolManagementChangePool", "Store 030 - Salt Lake City", false, true);

        List<WebElement> ReadOnly = driver.findElements(By.xpath("//input[@ng-readonly= 'readOnly' and @readonly='readonly']"));
      
        for(int i=1; i<=ReadOnly.size();i++) {
            String Details = driver.findElement(By.xpath("//input[@ng-readonly= 'readOnly' and @readonly='readonly']")).getAttribute("id");
            queryObjects.logStatus(driver, Status.PASS, "Pool Management screen - ReadOnly mode fields are", Details, null);
        }
        
        RC_Global.clickButton(driver, "Add New Pool", false, true);
        
        List<WebElement> ReadOnly1 = driver.findElements(By.xpath("//input[@ng-readonly= 'readOnly' and @readonly='readonly']"));                

        List<WebElement> Readwrite = driver.findElements(By.xpath("//input[@ng-readonly= 'readOnly']"));     

       if(!(ReadOnly1.size()>0)){

       for(int i=1; i<=Readwrite .size();i++) {        

          String Details = driver.findElement(By.xpath("//input[@ng-readonly= 'readOnly']")).getAttribute("id");           

        queryObjects.logStatus(driver, Status.PASS, "Pool Management screen - ReadOnly mode fields are", Details, null);   
        }
       }     
       
       
        RC_Global.selectDropdownOption(driver, "poolManagementChangePool", "Store 030 - Salt Lake City", false, true);
        element=driver.findElement(By.xpath("//input[@placeholder='First Name']"));
        FirstName=element.getText();
		element.clear();
		if(!FirstName.isEmpty())
	        RC_Global.enterInput(driver, FirstName, element, false, true);
	    else
	        {
	        	String Name = "Sample";
	        	RC_Global.enterInput(driver, Name, element, false, true);
	        }
		
  //      RC_Global.enterInput(driver, poolName, element, false);
 
        RC_Global.clickButton(driver, " Save ", false, true);
        Thread.sleep(5000);
        if(driver.findElements(By.xpath("//span[text()=' address entered.']")).size()>0){
        	RC_Global.clickButton(driver, "Save As Entered", true,true);
        	Thread.sleep(5000);
        }
        
        RC_Global.verifyDisplayedMessage(driver, "Save Successful", false);
        
        RC_Global.createNode(driver,"Verify a click a Associated Units and navigate to Vehicle Details page");
        RC_Global.clickUsingXpath(driver,"(//tr[@ng-click='openPoolVehicle(vehicle)'])[1]", "Select Row",false, true);
        RC_Global.validateHeaderName(driver, "Vehicle Details",true);
        RC_Global.panelAction(driver, "close","Pool Management",false, false);
        RC_Global.panelAction(driver, "expand", "Vehicle Details",false, false);
        RC_Global.panelAction(driver, "close", "Vehicle Details",false, false);
        RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
       
        
	}

}
