package Manage.Administration.PoolManagement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_10_02 {
	public void EditPoolDetailsForCustomer(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Pool Management";

		RC_Global.login(driver);
		RC_Global.waitElementVisible(driver, 10, "//span[text()='LS000000 - Merchants Portfolio']", "", false, false);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.enterCustomerNumber(driver, "LS008320", "", "", false);
		RC_Global.selectDropdownOption(driver, "poolManagementChangePool", "Store 030 - Salt Lake City", true, true);
		RC_Global.clickButton(driver, "Edit", true, true);
		RC_Global.selectDropdownOption(driver, "poolManagementChangePool", "Store 040 - Tuscon", true, true);
		if(driver.findElement(By.xpath("//input[@placeholder='Pool Name']")).getAttribute("value").equals("Store 040 - Tuscon"))
		{
			queryObjects.logStatus(driver, Status.PASS, "Based on Pool selection, details are updated in section fields", "", null);
		}
		String firstName = driver.findElement(By.xpath("//input[@placeholder='First Name']")).getAttribute("value");
		driver.findElement(By.xpath("//input[@placeholder='First Name']")).clear();
		if(driver.findElement(By.xpath("(//button[text()=' Save '])[1]")).isEnabled())
		{
			queryObjects.logStatus(driver, Status.PASS, "'Save' button is enabled", "", null);
		}
		RC_Global.clickUsingXpath(driver, "(//button[text()=' Save '])[1]", "Save", true, true);
		if(driver.findElements(By.xpath("//h4[contains(text(),'is a required field.')]")).size()>0 || 
				driver.findElements(By.xpath("//h4[text()='Email is required.']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Application validates the mandatory fields and the notifications are displayed", "", null);
		}
		WebElement elementFirstName = driver.findElement(By.xpath("//input[@placeholder='First Name']"));
		RC_Global.enterInput(driver, firstName, elementFirstName, false, true);
		RC_Global.clickUsingXpath(driver, "(//button[text()=' Save '])[1]", "Save", true, true);
		if(driver.findElements(By.xpath("//h4[text()='Save Successful']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Save Successful' is displayed", "", null);
		}
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}

}
