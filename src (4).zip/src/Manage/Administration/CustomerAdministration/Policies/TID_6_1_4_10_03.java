package Manage.Administration.CustomerAdministration.Policies;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_4_10_03 {
	public void ValidatePoliciesAttributesAndUploadPolicyDocument(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String currentDate = RC_Manage.AddDateStr(0, "MM/dd/yyyy", "", null, "CST");
		String pStatusDD = "Show All;Active;Inactive"; String pTypeDD="Show All;General;Mobile;Acquisition";
		String colNames = "Select;Customer #;Customer Name;Policy Type;Policy Status;Created By;Created Date;Document Date;Document;Available Actions";
		JavascriptExecutor executor = (JavascriptExecutor) driver; String policyDDValue="";
		String uploadFileName="Sample_Document.xlsx";
		String uploadFilePath= String.valueOf(String.valueOf(String.valueOf(System.getProperty("user.dir")))) + File.separator + "DocumentUpload" + File.separator + uploadFileName;
		String historyColNames ="Modified Date;Event;Modified By"; String [] expColName;
				
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
		RC_Global.enterCustomerNumber(driver, "LS010143", "", "", false);
		RC_Global.clickUsingXpath(driver, "//a[text()='Policies']", "Policies", false, true);
		RC_Global.dropdownValuesValidation(driver, pStatusDD, "//label[text()='Policy Status']/following-sibling::select", false, true);
		RC_Global.dropdownValuesValidation(driver, pTypeDD, "//label[text()='Policy Type']/following-sibling::select", false, true);
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//span[text()='Select']")));
		if(driver.findElements(By.xpath("(//table)[17]/tbody/tr")).size()>0)
		{
			//executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//span[text()='Select']")));
			RC_Global.createNode(driver, "Validate Column Names");
			expColName = colNames.split(";");

			for(int i=0; i<expColName.length; i++) {
				try {
					driver.findElement(By.xpath("(//thead/tr)[12]/th/div/span[text()='"+expColName[i]+"']"));
					queryObjects.logStatus(driver, Status.INFO, "Validate Report Column Names--->Column: " + expColName[i] + "--->Was Found", "", null);
				}
				catch(Exception e) {
					queryObjects.logStatus(driver, Status.FAIL, "Validate Report Column Names--->Column: " + expColName[i] + "--->Was NOT Found", e.getLocalizedMessage(), e);
				}
			}
			RC_Global.clickUsingXpath(driver, "(//table)[17]/tbody/tr/td/input[@type='checkbox']", "Select checkbox", false, true);
			executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//*[text()='Add New Policy']")));
			RC_Global.clickUsingXpath(driver, "//*[text()='Add New Policy']", "Add New Policy", false, true);
			executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//*[text()='Upload New Policy']")));
			RC_Global.clickUsingXpath(driver, "//*[text()='Policy Used For']/following-sibling::select", "Policy Used for* Dropdown", false, false);
			for(int i=1;i<=driver.findElements(By.xpath("//*[text()='Policy Used For']/following-sibling::select/option")).size();i++)
			{
				policyDDValue=driver.findElement(By.xpath("//*[text()='Policy Used For']/following-sibling::select/option["+i+"]")).getText();
				queryObjects.logStatus(driver, Status.PASS, "Policy User For* dropdown value is displayed",policyDDValue , null);
			}
			if(driver.findElements(By.xpath("(//label[text()=' Customer # ']/following-sibling::input)[2]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Customer # input field is displayed ", "", null);
			}
			if(driver.findElements(By.xpath("//input[@id='documentDate']")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Document Date* input field is displayed ", "", null);
			}
			if(driver.findElements(By.xpath("(//input[@type='file'])[2]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Document File* input field is displayed ", "", null);
			}
			RC_Global.selectDropdownOption(driver, "Policy Used For", policyDDValue, false, true);
			WebElement docDate = driver.findElement(By.xpath("//input[@id='documentDate']"));
			RC_Global.enterInput(driver, currentDate, docDate, false, true);
			driver.findElement(By.xpath("(//input[@type='file'])[2]")).sendKeys(uploadFilePath);
			Thread.sleep(1000);
			if(driver.findElements(By.xpath("//button[text()='Save Document ']")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Save Document button is enabled", "", null);
			}
			executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//label[text()=' Customer # '])[1]")));
			RC_Global.clickUsingXpath(driver, "((//ul[@class='ng-scope'])[2]/li/div/span)[1]", "Fleet Level", false, true);
			RC_Global.waitElementVisible(driver, 10, "//label[text()='Policy Status']", "Policies tab loading", false, false);
			if(driver.findElements(By.xpath("//div[@class='row fieldset']/div[@class='col-xs-12']/button[contains(@class,'ng-hide')]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "'Add New Policy' button does not exist for Fleet level", "", null);
			}
			RC_Global.clickUsingXpath(driver, "((//ul[@class='ng-scope'])[2]/li/i)[1]", "Expand Fleet Level", false, false);
			RC_Global.clickUsingXpath(driver, "((//ul[@class='ng-scope'])[3]/li/div/span)[1]", "Account Level", false, true);
			RC_Global.waitElementVisible(driver, 10, "//label[text()='Policy Status']", "Policies tab loading", false, false);
			if(driver.findElements(By.xpath("//div[@class='row fieldset']/div[@class='col-xs-12']/button[contains(@class,'ng-hide')]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "'Add New Policy' button does not exist for Account level", "", null);
			}
			
			RC_Global.clickUsingXpath(driver, "((//ul[@class='ng-scope'])[3]/li/i)[1]", "Expand Account Level", false, false);
			RC_Global.clickUsingXpath(driver, "((//ul[@class='ng-scope'])[4]/li/div/span)[1]", "Sub Account Level", false, true);
			RC_Global.waitElementVisible(driver, 10, "//label[text()='Policy Status']", "Policies tab loading", false, false);
			if(driver.findElements(By.xpath("//div[@class='row fieldset']/div[@class='col-xs-12']/button[contains(@class,'ng-hide')]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "'Add New Policy' button does not exist for Sub Account level", "", null);
			}
			RC_Global.clickUsingXpath(driver, "(//label[text()=' History '])[10]", "History", false, true);
			RC_Global.waitElementVisible(driver, 10, "//span[text()='Modified Date']", "Policy Attribute History screen opened with Grid", false, true);
			RC_Global.createNode(driver, "Validate Column Names");
			expColName = historyColNames.split(";");

			for(int i=0; i<expColName.length; i++) {
				try {
					driver.findElement(By.xpath("//span[text()='"+expColName[i]+"']"));
					queryObjects.logStatus(driver, Status.INFO, "Validate Report Column Names--->Column: " + expColName[i] + "--->Was Found", "", null);
				}
				catch(Exception e) {
					queryObjects.logStatus(driver, Status.FAIL, "Validate Report Column Names--->Column: " + expColName[i] + "--->Was NOT Found", e.getLocalizedMessage(), e);
				}
			}
			RC_Global.panelAction(driver, "close", "Policy Attribute History", false, true);
		}
		else {
			RC_Global.createNode(driver, "No Results");
			queryObjects.logStatus(driver, Status.INFO, "No Result displayed in the grid", "", null);	
		}
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//span[text()='Customer Administration'])[2]")));
		RC_Global.panelAction(driver, "close", "Customer Administration", false, true);
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
