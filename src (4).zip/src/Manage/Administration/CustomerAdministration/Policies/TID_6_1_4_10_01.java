package Manage.Administration.CustomerAdministration.Policies;

import java.io.File;

import org.openqa.selenium.By;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import MF.Source.Cred;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_4_10_01 {
	public void UploadGeneralPolicyForDriver(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception {
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
		RC_Global.validateHeaderName(driver, "Customer Administration", false);
		RC_Global.enterCustomerNumber(driver, "LS007656", "", "", true);// //LS010087
		RC_Global.clickUsingXpath(driver, "//a[text()='Policies']", "Policies Tab", false, true);
	
		RC_Global.waitElementVisible(driver, 60, "//label[text()='Policy Status']", "policies Section", false, true);
		RC_Manage.removePolicyRecord(driver, false);
		RC_Global.clickButton(driver, "Add New Policy", true, true);
		
		
		RC_Global.waitElementVisible(driver, 60, "//legend[text()='Upload New Policy']", "Upload New Policy module", false, true);
		
		RC_Global.scrollById(driver, "//label[text()='Policy Status']");
		//RC_Global.selectDropdownOption(driver, "DriverOrderPolicyAttributeTypeID", "General", false,true);
		
		RC_Global.selectDropdownOption(driver, "Policy Type", "General", false,true);
		Thread.sleep(5000);
		RC_Global.selectDropdownOption(driver, "Policy Used For", "General", false,true);	
		Thread.sleep(5000);
		//WebElement Date = driver.findElement(By.xpath("//input[@id='documentDate']"));
		//String dateinput = RC_Global.getDateTime(driver, "MM/dd/yyyy", 0, true);
		//RC_Global.enterInput(driver, dateinput, Date, false, true);		
		RC_Global.clickUsingXpath(driver, "//input[@id='documentDate']", "documentDate", false, true);
		Thread.sleep(8000);		
		RC_Global.clickButton(driver, "Today", true, true);		
		Thread.sleep(8000);
		WebElement InvoiceUpload= driver.findElement(By.xpath("//label[text()=' Document File ']/following-sibling::input"));
		String UploadfileName="Sample_Document.xlsx";
		String uploadFilePath= String.valueOf(String.valueOf(String.valueOf(System.getProperty("user.dir")))) + File.separator + "DocumentUpload" + File.separator + UploadfileName;		
        InvoiceUpload.sendKeys(uploadFilePath);
		Thread.sleep(5000);
		RC_Global.buttonStatusValidation(driver, "Save Document ", "Enable",true);
		RC_Global.clickUsingXpath(driver, "//button[text()='Save Document ']", "Save Document", true, true);
		Thread.sleep(3000);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		   Thread.sleep(1000);
	    executor.executeScript("document.body.style.zoom = '30%'");
		   Thread.sleep(2000);
	    executor.executeScript("document.body.style.zoom = '100%'");
	    String Username = driver.findElement(By.xpath("//span[contains(@ng-show,'user.FullName')]")).getText();
	    
		RC_Global.clickUsingXpath(driver, "//td[text()='"+Username+"']/following::button[text()=' Deactivate ']", "Deactivate", false, false);
		 RC_Global.panelAction(driver, "close", "Customer Administration", false,true);
         RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
		
		
	}

}
