package Manage.Administration.CustomerAdministration.Maintenance;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import MF.Source.Cred;
import tools.TotalView.RC_Global;

public class TID_6_1_4_6_01 {
	public void MaintenanceAttributeRemoveInheritanceOfEnrollment(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Customer Administration";
		
	
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.enterCustomerNumber(driver, "LS010087", "", "", false);
		
		if(driver.findElements(By.xpath("//span[text()='LS010087 - Tribus Services Inc.']")).size()>0)
		{
			String labelText = driver.findElement(By.xpath(" (//label[text()='Customer Name'])[6]")).getText();
			String data = driver.findElement(By.xpath("(//div[text()=' Tribus Services Inc. '])[6]")).getText();
			queryObjects.logStatus(driver, Status.PASS, "Customer # level selection has label "+labelText+" with value", data, null);

		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Customer # Level selection value not found in label", null, null);

		}
		
		RC_Global.clickUsingXpath(driver, "//a[text()='Maintenance']", "Maintenance", false, true);
        RC_Global.waitElementVisible(driver, 60, "(//legend[text()='Enrollment'])[2]", "Enrollment", false, true);
        
        
        if(driver.findElements(By.xpath("//button[contains(@ng-click,'YesClick()')]")).size()>0)
        {
    		RC_Global.clickUsingXpath(driver, "//button[contains(@ng-click,'NoClick()')]", "No_button", false, true);
    		queryObjects.logStatus(driver, Status.PASS, "verifyusercanelect 'No'", "successfully", null);

        }
        else if(driver.findElements(By.xpath("//button[contains(@ng-click,'NoClick()')]")).size()>0)
        {
        	RC_Global.clickUsingXpath(driver, "//button[contains(@ng-click,'YesClick()')]", "Yes_button", false, true);
    		queryObjects.logStatus(driver, Status.PASS, "verifyusercanelect 'Yes'", "successfully", null);

        }
        
        else
        {
    		queryObjects.logStatus(driver, Status.FAIL, "Unable to elect enrollement of maintenance program", "", null);

        }
        
        RC_Global.clickUsingXpath(driver, " //span[text()='LS007728 - Tribus Services Inc']", "Fleet Level", false, true);
        
        if(driver.findElements(By.xpath(" //span[text()='LS007728 - Tribus Services Inc']")).size()>0)
		{
			String labelText = driver.findElement(By.xpath("(//label[text()='Fleet Name'])[6]")).getText();
			String data = driver.findElement(By.xpath("(//div[text()=' Tribus Services Inc '])[6]")).getText();
			queryObjects.logStatus(driver, Status.PASS, "Fleet # level selection has label "+labelText+" with value", data, null);

		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Fleet # Level selection value not found in label", null, null);

		}
        
       RC_Global.waitElementVisible(driver, 60, "(//legend[text()='Enrollment'])[2]", "Enrollment", false, true);
        
        
        if(driver.findElements(By.xpath("//button[contains(@ng-click,'YesClick()')]")).size()>0)
        {
    		RC_Global.clickUsingXpath(driver, "//button[contains(@ng-click,'NoClick()')]", "No_button", false, true);
    		queryObjects.logStatus(driver, Status.PASS, "verifyusercanelect 'No'", "successfully", null);

        }
        else if(driver.findElements(By.xpath("//button[contains(@ng-click,'NoClick()')]")).size()>0)
        {
        	RC_Global.clickUsingXpath(driver, "//button[contains(@ng-click,'YesClick()')]", "Yes_button", false, true);
    		queryObjects.logStatus(driver, Status.PASS, "verifyusercanelect 'Yes'", "successfully", null);

        }
        
        else
        {
    		queryObjects.logStatus(driver, Status.FAIL, "Unable to elect enrollement of maintenance program", "", null);

        }
        
		String enroll = driver.findElement(By.xpath("//button[contains(@ng-click,'YesClick()')]")).getText();
		String selection ="";
		if(enroll.equalsIgnoreCase("Yes"))
		{
    		RC_Global.clickUsingXpath(driver, "//button[contains(@ng-click,'NoClick()')]", "No_button", false, true);
    		Thread.sleep(2000);
    		selection=driver.findElement(By.xpath("//label[contains(text(),'Enrolled in Maintenance')]/../div//button[contains(@class,'active')]")).getText();
    		RC_Global.clickUsingXpath(driver, "(//button[contains(@class,'tab-save')])[4]", "Save", false, true);
    	//	RC_Global.clickButton(driver, " Save ", false, true);
    		Thread.sleep(2000);
    		RC_Global.verifyDisplayedMessage(driver, "Maintenance Attributes Saved", false);
    		queryObjects.logStatus(driver, Status.PASS, "Manitenance enrollement at lowerlevel is not enrolled as "+selection+"", "successfully", null);

		}
        
		else if(enroll.equalsIgnoreCase("No"))
		{
			RC_Global.clickUsingXpath(driver, "//button[contains(@ng-click,'YesClick()')]", "Yes_button", false, true);	
			Thread.sleep(2000);
			selection=driver.findElement(By.xpath("//label[contains(text(),'Enrolled in Maintenance')]/../div//button[contains(@class,'active')]")).getText();
    		RC_Global.clickUsingXpath(driver, "(//button[contains(@class,'tab-save')])[4]", "Save", false, true);
		//	RC_Global.clickButton(driver, " Save ", false, true);
    		Thread.sleep(2000);
    		RC_Global.verifyDisplayedMessage(driver, "Maintenance Attributes Saved", false);
    		queryObjects.logStatus(driver, Status.PASS, "Manitenance enrollement at lowerlevel is not enrolled as "+selection+"", "successfully", null);

		}
		else
		{
    		queryObjects.logStatus(driver, Status.FAIL, "Unable to elect enrollement", "", null);

		}
		
		RC_Global.clickUsingXpath(driver, "//span[text()='LS010087 - Tribus Services Inc.']", "CustomerLevel", false, true);
		Thread.sleep(3000);
		String cusenroll= driver.findElement(By.xpath("//label[contains(text(),'Enrolled in Maintenance')]/../div//button[contains(@class,'active')]")).getText();
		if(!(cusenroll.equals(selection)))
				{
			   queryObjects.logStatus(driver, Status.PASS, "Verified Maintenance attributes are not inherited from the level above", "successfully", null);

				}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Verified Maintenance attributes are inherited from the level", "", null);
		}
		
        RC_Global.clickUsingXpath(driver, " //span[text()='LS007728 - Tribus Services Inc']", "Fleet Level", false, true);

		
		RC_Global.clickUsingXpath(driver, "(//label[normalize-space(text())='History'])[5]", "History", false, true);
		RC_Global.waitUntilPanelVisibility(driver, "Maintenance History", "TV", false, true);
		Thread.sleep(2000);
		String methodusername=driver.findElement(By.xpath("(//vehicle-maintenance-history//standard-grid//div[3]/div)[2]")).getText();
		//String username =driver.findElement(By.xpath("//span[@id='Span1']")).getText();
		//String username = Cred.UserName;
		//String withoutWhitespaceloggedUser = StringUtils.deleteWhitespace(username);
		queryObjects.logStatus(driver, Status.PASS, "Maintenance Alert is Logged By---->",RC_Global.userLogged , null);
		
		String cDate = driver.findElement(By.xpath("(//vehicle-maintenance-history//standard-grid//div[2]/div)[3]")).getText();
		
		
		Format T = new SimpleDateFormat("MM/dd/yyyy");
		String currentdate = T.format(new Date());
		
		Thread.sleep(2000);
		if((methodusername.toUpperCase().contains(RC_Global.userLogged)) && (cDate.contains(currentdate)))
		{
			if(driver.findElements(By.xpath("(//div[normalize-space(text())='Maintenence Attributes Updated'])[1]")).size()>0)
				{
			   queryObjects.logStatus(driver, Status.PASS, "Changes made in maintenace tab updated", "successfully", null);
				}
			else
			{
				queryObjects.logStatus(driver, Status.FAIL, "Changes made in maintenance tab not updated", "", null);
	
			}
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "History not found for maintenance tab update", "", null);

		}
		
		RC_Global.logout(driver, true);
	}

	 
}
