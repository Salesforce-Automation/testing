package Manage.Administration.CustomerAdministration.Maintenance;


import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;

import com.aventstack.extentreports.Status;
import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

	public class TID_6_1_4_6_02 {
			public void ValidateMaintenanceAttributeAtCustomer_FleetAndAccountlevel(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
		RC_Global.validateHeaderName(driver, "Customer Administration", false);
		RC_Global.enterCustomerNumber(driver, "LS007656", "", "", true);// //LS010087
		RC_Global.clickUsingXpath(driver, "//div/ul/li/a[text()='Maintenance']", "Maintenance Tab", false, true);
		RC_Global.waitElementVisible(driver, 60, "(//legend[text()='Enrollment'])[2]", "Maintenance Section", false, true);
		
		RC_Manage.toggleButtonStatusValidation(driver, "Enrolled in Maintenance *", "Yes", "Enable", false);
		RC_Manage.toggleButtonStatusValidation(driver, "Enrolled in Maintenance *", "No", "Enable", false);
		RC_Manage.toggleButtonStatusValidation(driver, "Enrolled in Maintenance *", "Yes", "DefaultSelection", false);
		//No
		
		RC_Global.waitElementVisible(driver, 60, "(//legend[text()='Enrollment'])[2]", "Maintenance Section", false, true);
		  String mainmsg =  driver.findElement(By.xpath("//fieldset//legend[text()='Maintenance Approval Limit']//following::div[3]")).getText();
		 queryObjects.logStatus(driver, Status.PASS, "The Maintenance Approval Limit Intructions are", mainmsg, null);
		
		 String color = driver.findElement(By.xpath("//fieldset//legend[text()='Maintenance Approval Limit']//following::div[3]")).getCssValue("background-color");
		 String hex = Color.fromString(color).asHex();
		 System.out.println(hex);
		 String coloryel = "#ffff00";
		 if(coloryel.equalsIgnoreCase(hex)) {
			 queryObjects.logStatus(driver, Status.PASS, "The Maintenance Approval Limit Intructions background-color is ", "Yellow", null);}
		 else {
			 queryObjects.logStatus(driver, Status.FAIL, "The Maintenance Approval Limit Intructions background-color is ", "not Yellow", null);}
		 
		 String empName = driver.findElement(By.xpath("//label[contains(@ng-click,'editEmployee')]")).getText();
		 RC_Global.scrollById(driver, "//legend[text()='Tire Program']");
		 queryObjects.logStatus(driver, Status.PASS, "The Employee Name displayed in Maintenance Approval Limit is", empName, null);
		 String apprLimit = driver.findElement(By.xpath("//input[contains(@ng-model,'ApprovalLimit')]")).getAttribute("value");
		 queryObjects.logStatus(driver, Status.PASS, "The Approval Limit displayed in Maintenance is", apprLimit, null);
		 String cell = driver.findElement(By.xpath("(//span[contains(@class,'earphone')]//parent::li)[1]")).getText();
		 queryObjects.logStatus(driver, Status.PASS, "The Cell number displayed in Maintenance Approval Limit is", cell, null);
		 String work = driver.findElement(By.xpath("(//span[contains(@class,'earphone')]//parent::li)[2]")).getText();
		 queryObjects.logStatus(driver, Status.PASS, "The Work number displayed in Maintenance Approval Limit is", work, null);
		 String email = driver.findElement(By.xpath("//span[contains(@class,'envelope')]//parent::li")).getText();
		 queryObjects.logStatus(driver, Status.PASS, "The Email displayed in Maintenance Approval Limit is", email, null);
		 
		//	         
		 RC_Global.clickButton(driver, "Add", true, true);
		 Thread.sleep(2000);
		 RC_Global.waitUntilPanelVisibility(driver,"Assign Approver","TV", true,false);
//		 RC_Global.panelAction(driver, "compress", "Assign Approver", true, false);
//		 RC_Global.panelAction(driver, "close", "Customer Administration", true, false);
//		 RC_Global.panelAction(driver, "expand", "Assign Approver", true, false);
		 RC_Global.clickButton(driver, "Search", true, true);
		 //ADD Approver
		 Thread.sleep(2000);
		 int rowCount = driver.findElements(By.xpath("//div/table/tbody/tr[1]/td[3]")).size();
		 RC_Global.waitElementVisible(driver, 60, "(//div/table/tbody/tr[1]/td[3])["+rowCount+"]", "Grid Results", false, true);
		 RC_Global.clickUsingXpath(driver, "(//div/table/tbody/tr[1]/td[3])["+rowCount+"]", "Add Approver", false, true);
		 RC_Global.clickButton(driver, "Select Approver", true, true);
		 Thread.sleep(2000);
		 
//		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
//		RC_Global.validateHeaderName(driver, "Customer Administration", false);
//		RC_Global.enterCustomerNumber(driver, "LS007656", "", "", true);// //LS010087
//		RC_Global.clickUsingXpath(driver, "//div/ul/li/a[text()='Maintenance']", "Maintenance Tab", false, true);
//		RC_Global.waitElementVisible(driver, 60, "(//legend[text()='Enrollment'])[2]", "Maintenance Section", false, true);
//		
		 
		 //Remove Approver
		 RC_Global.scrollById(driver, "//legend[text()='Tire Program']");
		 RC_Global.clickUsingXpath(driver, "(//button[normalize-space(text())='Remove'])[2]", "Remove Approver", false, true);
		 //yes
		 RC_Global.clickUsingXpath(driver, "//div//label[text()='Enrolled in Maintenance *']//following::div[2]//button[normalize-space(text())='Yes']", "Enrolled in Maintenance", false, true);
		 RC_Global.waitElementVisible(driver, 60, "(//legend[text()='Enrollment'])[2]", "Maintenance Section", false, true);
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Maintenance Program(s) Elected *", false);
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Specialty Tires", false);
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Tax Exemption", false);
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Rental Program", false);
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Vendor Preferences", false);
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Glass", false);
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Tire Program", false);
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Rebates", false);
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Maintenance Approval Limit", false);
		//Speciality Tires
		String dropdownvalues = "Yes;No;With Approval";
		RC_Global.dropdownValuesValidation(driver,dropdownvalues,"//select[@name='snowTiresPermitted']",false,true);
		String dropdownvalues1 = "Yes;No;With Approval";
		RC_Global.dropdownValuesValidation(driver,dropdownvalues1,"//select[@name='kevlarTiresPermitted']",false,true);
		String dropdownvalues2 = "Yes;No;With Approval";
		RC_Global.dropdownValuesValidation(driver,dropdownvalues2,"//select[@name='retreadsPermitted']",false,true);
		RC_Global.selectDropdownOption(driver, "Snow Tires Permitted *", "With Approval", false,true);
		RC_Global.selectDropdownOption(driver, "Kevlar Tires Permitted *", "With Approval", false,true);
		RC_Global.selectDropdownOption(driver, "Retreads Permitted *", "With Approval", false,true);
		RC_Global.verifyScreenComponents(driver, "lable", "Authorization Limit for Snow Tires *", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Authorization Limit for Kevlar Tires *", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Authorization Limit for Retreads *", false);
		//Tax Exemption
		RC_Manage.toggleButtonStatusValidation(driver, "Maintenance Repairs *", "Yes", "Enable", false);
		RC_Manage.toggleButtonStatusValidation(driver, "Maintenance Repairs *", "No", "Enable", false);
		//Vendor Preferences
		String dropdownvalues3 = "Yes;No;With Approval";
		RC_Global.dropdownValuesValidation(driver,dropdownvalues3,"//select[@name='vendorPrefs']",false,true);
		//Enrollment
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Customer Maintenance Program(s) Elected", "Full;Reserve", false);
		//Tire Program
		RC_Manage.toggleButtonStatusValidation(driver, "Enrolled *", "Yes", "Enable", false);
		RC_Manage.toggleButtonStatusValidation(driver, "Enrolled *", "No", "Enable", false);
		//Glass
		RC_Global.scrollById(driver, "//legend[text()='Tire Program']");
		String dropdownvalues4 = "Yes;No;With Approval";
		RC_Global.dropdownValuesValidation(driver,dropdownvalues4,"//select[contains(@ng-model,'GlassRepairsPermittedSelected')]",false,true);
		String dropdownvalues5 = "Yes;No;With Approval";
		RC_Global.dropdownValuesValidation(driver,dropdownvalues5,"//select[@name='GlassReplacementPermitted']",false,true);
		//Rebates
		RC_Manage.toggleButtonStatusValidation(driver, "Rebates Extended *", "Yes", "Enable", false);
		RC_Manage.toggleButtonStatusValidation(driver, "Rebates Extended *", "No", "Enable", false);
		//Notes
		String note = driver.findElement(By.xpath("//textarea[@ng-model='vm.notes']")).getTagName();
		queryObjects.logStatus(driver, Status.PASS, "The Notes Section has multiline ", ""+note+" permeating 200 characters", null);
		//Fleet Level
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			   Thread.sleep(1000);
		executor.executeScript("document.body.style.zoom = '30%'");
			   Thread.sleep(2000);
		executor.executeScript("document.body.style.zoom = '100%'");
		String custNum = "LS007656";
		RC_Global.enterCustomerNumber(driver, custNum, "Customer", "Fleet level", false);
		RC_Global.waitElementVisible(driver, 60, "(//legend[text()='Inheritance'])[4]", "Maintenance Section", false, true);
		RC_Manage.toggleButtonStatusValidation(driver, "Inherit Attributes *", "Yes", "Enable", false);
		RC_Manage.toggleButtonStatusValidation(driver, "Inherit Attributes *", "No", "Enable", false);
		 String colorin = driver.findElement(By.xpath("//select[@name='snowTiresPermitted']")).getCssValue("background-color");
		 String hexin = Color.fromString(colorin).asHex();
		 System.out.println(hexin);
		 String colorgrey = "#ffffff";
		 if(colorgrey.equalsIgnoreCase(hexin)) {
			queryObjects.logStatus(driver, Status.PASS, "In Maintenance Tab except Inheritance", "Other section fields are grayed out", null);}
		
		 //Choose Settings Pop-Up validation
		RC_Global.clickUsingXpath(driver, "(//div//label[text()='Inherit Attributes *']//following::div[2]//button[normalize-space(text())='No'])[4]", "Inherit Attributes", false, true);
		RC_Global.validateHeaderName(driver, "Choose Settings", false);
		 String popmsg =  driver.findElement(By.xpath("(//h3[text()='Choose Settings']//following::div[2]//div)[1]")).getText();
		 queryObjects.logStatus(driver, Status.PASS, "The Pop-up message displayed in Choose Settings are", popmsg, null);
		 String popmsg1 =  driver.findElement(By.xpath("(//input[@name='setting']//following-sibling::label)[1]")).getText();
		 queryObjects.logStatus(driver, Status.PASS, "The Pop-up message displayed in Choose Settings are", popmsg1, null);
		 String popmsg2 =  driver.findElement(By.xpath("(//input[@name='setting']//following-sibling::label)[2]")).getText();
		 queryObjects.logStatus(driver, Status.PASS, "The Pop-up message displayed in Choose Settings are", popmsg2, null);
		 String popmsg3 =  driver.findElement(By.xpath("//h3[text()='Choose Settings']//following::div[1]//div[4]")).getText();
		 queryObjects.logStatus(driver, Status.PASS, "The Pop-up message displayed in Choose Settings are", popmsg3, null);
		 boolean radioButton =  driver.findElement(By.xpath("//input[contains(@ng-click,'true')]")).isSelected();
		 queryObjects.logStatus(driver, Status.PASS, "Copy All Settings so you can Modify Them" , "Set by default "+radioButton+" ", null);
		 RC_Global.buttonStatusValidation(driver, "Ok", "Enable", false);
		 RC_Global.buttonStatusValidation(driver, "Cancel", "Enable", false);
		 RC_Global.clickButton(driver, "OK", true, true);
		 queryObjects.logStatus(driver, Status.PASS, "All the existing inherited settings for attributes are copied and it allows user to modify the attributes", "", null);
		
		 RC_Global.panelAction(driver, "close", "Customer Administration", false,true);
		 RC_Global.logout(driver, false);
queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}



