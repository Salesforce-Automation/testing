package Manage.Administration.CustomerAdministration.Remarketing;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_4_5_02 {

public void RemarketingAttributes_SectionsValidation(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Customer Administration";
		
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", false);
		RC_Global.clickUsingXpath(driver, "//div/ul/li//a[text()='Remarketing']", "Remarketing Tab", true,true);
		RC_Global.waitElementVisible(driver, 30, "//legend[text()='Remarketing Enrollment']", "Remarketing Section", false, true);
		//section validation
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Remarketing Enrollment", false);
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Contract Details", false);
		
		//Toggle validation
		RC_Manage.toggleButtonStatusValidation(driver, "Enrolled In Remarketing *", "Yes", "Enable", false);
		RC_Manage.toggleButtonStatusValidation(driver, "Enrolled In Remarketing *", "No", "Enable", false);
		RC_Manage.toggleButtonStatusValidation(driver, "Enrolled In Remarketing *", "Yes", "DefaultSelection", false);
		RC_Manage.toggleButtonStatusValidation(driver, "Client Directed Sales Permitted *", "Yes", "Enable", false);
		RC_Manage.toggleButtonStatusValidation(driver, "Client Directed Sales Permitted *", "No", "Enable", false);
		RC_Manage.toggleButtonStatusValidation(driver, "Client Directed Sales Permitted *", "Yes", "DefaultSelection", false);
		RC_Manage.toggleButtonStatusValidation(driver, "Courtesy Sales Permitted *", "Yes", "Enable", false);
		RC_Manage.toggleButtonStatusValidation(driver, "Courtesy Sales Permitted *", "No", "Enable", false);
		RC_Manage.toggleButtonStatusValidation(driver, "Courtesy Sales Permitted *", "Yes", "DefaultSelection", false);
		String salesProceed = driver.findElement(By.xpath("(//label[text()='Sales Proceeds Paid By *']//following::div//select//option[@selected='selected'])[1]")).getText();
		queryObjects.logStatus(driver, Status.PASS, "Sales Proceeds Paid By Default is set to", salesProceed, null);
		RC_Manage.toggleButtonStatusValidation(driver, "Optional Driver message for Vehicle Pickup *", "Yes", "Enable", false);
		RC_Manage.toggleButtonStatusValidation(driver, "Optional Driver message for Vehicle Pickup *", "No", "Enable", false);
		RC_Manage.toggleButtonStatusValidation(driver, "Optional Driver message for Vehicle Pickup *", "Yes", "DefaultSelection", false);
		RC_Manage.toggleButtonStatusValidation(driver, "3rd Party Inspection Required *", "Yes", "Enable", false);
		RC_Manage.toggleButtonStatusValidation(driver, "3rd Party Inspection Required *", "No", "Enable", false);
		RC_Manage.toggleButtonStatusValidation(driver, "3rd Party Inspection Required *", "No", "DefaultSelection", false);

		//Documentation Fee Input Box Validation
		String docFee = driver.findElement(By.xpath("//input[@name='DocumentationFee']")).getAttribute("value");
		queryObjects.logStatus(driver, Status.PASS, "Documentation Fee By Default Value is ", docFee, null);
		RC_Manage.inputBoxFormatValidation(driver, "DocumentationFee", "000.00", "FormatType", false);
		RC_Manage.inputBoxFormatValidation(driver, "DocumentationFee", "999.99", "MaxLimit", false);
		RC_Manage.inputBoxFormatValidation(driver, "DocumentationFee", "-142.8", "NegativeValue", false);
		
		RC_Global.verifyScreenComponents(driver, "lable", "Client *", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Driver *", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Other *", false);
		RC_Manage.toggleButtonStatusValidation(driver, "Client *", "Yes", "Enable", false);
		RC_Manage.toggleButtonStatusValidation(driver, "Client *", "No", "Enable", false);
		RC_Manage.toggleButtonStatusValidation(driver, "Client *", "No", "DefaultSelection", false);
		RC_Manage.toggleButtonStatusValidation(driver, "Driver *", "Yes", "Enable", false);
		RC_Manage.toggleButtonStatusValidation(driver, "Driver *", "No", "Enable", false);
		RC_Manage.toggleButtonStatusValidation(driver, "Driver *", "Yes", "DefaultSelection", false);
		RC_Manage.toggleButtonStatusValidation(driver, "Other *", "Yes", "Enable", false);
		RC_Manage.toggleButtonStatusValidation(driver, "Other *", "No", "Enable", false);
		RC_Manage.toggleButtonStatusValidation(driver, "Other *", "Yes", "DefaultSelection", false);
		
		RC_Global.panelAction(driver, "close", "Customer Administration", false,true);
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
		
	}
}
