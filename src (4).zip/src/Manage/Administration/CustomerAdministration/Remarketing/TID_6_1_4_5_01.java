package Manage.Administration.CustomerAdministration.Remarketing;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_4_5_01 {
		
	public void ValidateRemarketingAttributesFunctionality(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Customer Administration";
		String SearchFilters ="First Name *;Last Name *;Address 1 *;Address 2;City *;Phone #* ;Phone Extension";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.enterCustomerNumber(driver, "LS008737", "", "", false);
		RC_Global.clickUsingXpath(driver, "//div/ul/li//a[text()='Remarketing']", "Remarketing Tab", true,true);
		RC_Global.waitElementVisible(driver, 30, "//legend[text()='Remarketing Enrollment']", "Remarketing Section", false, true);
		//section validation
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Remarketing Enrollment", false);
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Contract Details", false);
		
		//section field validation
		RC_Global.verifyScreenComponents(driver, "lable", "Enrolled In Remarketing *", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Directed Sales Permitted *", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Courtesy Sales Permitted *", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Sales Proceeds Paid By *", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Optional Driver message for Vehicle Pickup *", false);
		RC_Global.verifyScreenComponents(driver, "lable", "3rd Party Inspection Required *", false);
		
		RC_Global.clickUsingXpath(driver, "//div//label[text()='Client Directed Sales Permitted *']//following::div[2]//label[text()='No']", "Client Directed sales permitted", true,true);
		List<WebElement> strValue = driver.findElements(By.xpath("//input[@name='DocumentationFee']"));
         if(strValue.size()>0)
         {
                queryObjects.logStatus(driver, Status.PASS, "To verify Contract Details section is ", "Disabled", null);
         }
         else
         {
                queryObjects.logStatus(driver, Status.FAIL, "To verify Contract Details section is ", "Enabled", null);
		}
		
		RC_Global.clickUsingXpath(driver, "//div//label[text()='Courtesy Sales Permitted *']//following::div[2]//label[text()='No']", "Courtesy Sales Permitted", true,true);
		List<WebElement>  strValue1 = driver.findElements(By.xpath("//label[text()='Sales Proceeds Paid By *']"));
        if(strValue1.size()==0)
        {
               queryObjects.logStatus(driver, Status.PASS, "To verify Sales Proceeds Paid By label is ", "Removed", null);
        }
        else
        {
               queryObjects.logStatus(driver, Status.FAIL, "To verify Sales Proceeds Paid By label is ","Displayed", null);
		}
        
        RC_Global.clickUsingXpath(driver, "//div//label[text()='Courtesy Sales Permitted *']//following::div[2]//label[text()='Yes']", "Courtesy Sales Permitted", true,true);
        RC_Global.selectDropdownOption(driver, "Sales Proceeds Paid By *", "Invoiced Credit", false,true);
        RC_Global.verifyScreenComponents(driver, "lable", "Optional Driver message for Vehicle Pickup *", false);
		RC_Global.verifyScreenComponents(driver, "lable", "3rd Party Inspection Required *", false);
		
		RC_Global.selectDropdownOption(driver, "Sales Proceeds Paid By *", "Check", false,true);
		RC_Global.validateSpecifiedSearchFilters(driver, SearchFilters, false);
		RC_Global.verifyScreenComponents(driver, "lable", "Optional Driver message for Vehicle Pickup *", false);
		RC_Global.verifyScreenComponents(driver, "lable", "3rd Party Inspection Required *", false);
		
		RC_Global.clickUsingXpath(driver, "//div//label[text()='3rd Party Inspection Required *']//following::div[2]//label[text()='Yes']", "3rd Party Inspection Required", true,true);
		RC_Global.verifyScreenComponents(driver, "lable", "3rd Party Inspection Billing *", false);
		String dropdownvalues = "Bill Back To Client;Client Charge Waived;Government Inspection -  No Bill Back";
		RC_Global.dropdownValuesValidation(driver,dropdownvalues,"//select[@name='thirdPartyInspectionBilling']",false,true);
		
		//Contract Details Section Validation
		RC_Global.clickUsingXpath(driver, "//div//label[text()='Client Directed Sales Permitted *']//following::div[2]//label[text()='Yes']", "Client Directed sales permitted", true,true);
		RC_Global.verifyScreenComponents(driver, "lable", "Documentation Fee *", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client *", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Driver *", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Other *", false);
		
		//Remarketing Enrollment
		RC_Global.clickUsingXpath(driver, "//div//label[text()='Enrolled In Remarketing *']//following::div[2]//label[text()='No']", "Emrolled in Remarketing", true,true);
		String dropdownvalues1 = "3rd Party Remarketer � Fleet Street;3rd Party Remarketer � Premier;3rd Party Remarketer � Other";
		RC_Global.dropdownValuesValidation(driver,dropdownvalues1,"//select[@name='remarketingDirectionType']",false,true);
		
		RC_Global.panelAction(driver, "close", "Customer Administration", false,true);
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
		
	}
}

