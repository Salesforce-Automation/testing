package Manage.Administration.CustomerAdministration.Remarketing;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_4_5_03 {
	
public void Remarketing_InheritAttributes_LowerLevel(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Customer Administration";
		String custNum = "LS008737";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.enterCustomerNumber(driver, custNum, "", "", false);
		RC_Global.clickUsingXpath(driver, "//div/ul/li//a[text()='Remarketing']", "Remarketing Tab", true,true);
		RC_Global.waitElementVisible(driver, 30, "//legend[text()='Remarketing Enrollment']", "Remarketing Section", false, true);
		RC_Global.enterCustomerNumber(driver, custNum, "Customer", "Fleet level", false);
		RC_Global.waitElementVisible(driver, 30, "//legend[text()='Remarketing Enrollment']", "Remarketing Section", false, true);
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Inheritance", false);
		
		if (driver.findElement(By.xpath("(//div//label[text()='Inherit Attributes *']//following::div[2]//button[normalize-space(text())='No'])[3]")).getAttribute("class").contains("active")) {
		 	driver.findElement(By.xpath("(//div//label[text()='Inherit Attributes *']//following::div[2]//button[normalize-space(text())='Yes'])[3]")).click();
		 	RC_Global.clickButton(driver, "Ok", true, true);
		 	RC_Global.clickUsingXpath(driver, "(//button[text()='Save'])[2]", "Save", true, true);
		 	Thread.sleep(3000);
		 	 RC_Global.verifyDisplayedMessage(driver, "Update successful", false);
		 }
		//Toggle validation
		RC_Manage.toggleButtonStatusValidation(driver, "Inherit Attributes *", "Yes", "Enable", false);
		RC_Manage.toggleButtonStatusValidation(driver, "Inherit Attributes *", "No", "Enable", false);
		RC_Manage.toggleButtonStatusValidation(driver, "Inherit Attributes *", "Yes", "DefaultSelection", false);
		
		 WebDriverWait wait = new WebDriverWait(driver,30);
         wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//label[text()='Client Directed Sales Permitted *']//following::div[2]//label[(text()='No')]")));
         queryObjects.logStatus(driver, Status.PASS, "Remarketing Enrollment Section Fields are in", "View Only Mode", null);
         wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//label[text()='Client *']//following::div[2]//label[(text()='Yes')]")));
         queryObjects.logStatus(driver, Status.PASS, "Contract Details Section Fields are in", "View Only Mode", null);
         
         //Choose Settings Pop-Up validation
         RC_Global.clickUsingXpath(driver, "(//div//label[text()='Inherit Attributes *']//following::div[2]//button[normalize-space(text())='No'])[3]", "Inherit Attributes", true,true);
         RC_Global.validateHeaderName(driver, "Choose Settings", false);
         String popmsg =  driver.findElement(By.xpath("(//h3[text()='Choose Settings']//following::div//p)[1]")).getText();
         queryObjects.logStatus(driver, Status.PASS, "The Pop-up message displayed in Choose Settings are", popmsg, null);
         String popmsg1 =  driver.findElement(By.xpath("(//input[@name='dataSetting']//following-sibling::label)[1]")).getText();
         queryObjects.logStatus(driver, Status.PASS, "The Pop-up message displayed in Choose Settings are", popmsg1, null);
         String popmsg2 =  driver.findElement(By.xpath("(//input[@name='dataSetting']//following-sibling::label)[2]")).getText();
         queryObjects.logStatus(driver, Status.PASS, "The Pop-up message displayed in Choose Settings are", popmsg2, null);
         String popmsg3 =  driver.findElement(By.xpath("(//h3[text()='Choose Settings']//following::div//p)[2]")).getText();
         queryObjects.logStatus(driver, Status.PASS, "The Pop-up message displayed in Choose Settings are", popmsg3, null);
         boolean radioButton =  driver.findElement(By.xpath("(//input[contains(@ng-model,'dataSetting')])[1]")).isSelected();
         queryObjects.logStatus(driver, Status.PASS, "Copy All Settings so you can Modify Them" , "Set by default "+radioButton+" ", null);
         RC_Global.buttonStatusValidation(driver, "Ok", "Enable", false);
         RC_Global.buttonStatusValidation(driver, "Cancel", "Enable", false);
         RC_Global.clickButton(driver, "Ok", true, true);
         queryObjects.logStatus(driver, Status.PASS, "All the existing inherited settings for attributes are copied and it allows user to modify the attributes", "", null);
         wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//label[text()='Client Directed Sales Permitted *']//following::div[2]//label[(text()='No')]")));
         queryObjects.logStatus(driver, Status.PASS, "Remarketing Enrollment and Contract Details Section User Control Button are", "Enabled", null);
         
         
         RC_Global.clickUsingXpath(driver, "(//div//label[text()='Inherit Attributes *']//following::div[2]//button[normalize-space(text())='Yes'])[3]", "Inherit Attributes", true,true);
         String popmsgyes =  driver.findElement(By.xpath("(//div[1]/div/div/div[1]/h3)[1]")).getText();
         queryObjects.logStatus(driver, Status.PASS, "The Pop-up message displayed for Inherit Attributes Yes ", popmsgyes, null);
         RC_Global.buttonStatusValidation(driver, "Ok", "Enable", false);
         RC_Global.buttonStatusValidation(driver, "Cancel", "Enable", false);
         RC_Global.clickButton(driver, "Cancel", true, true);
         wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//label[text()='Client Directed Sales Permitted *']//following::div[2]//label[(text()='No')]")));
         queryObjects.logStatus(driver, Status.PASS, "Remarketing Enrollment and Contract Details Section User Control Button are", "Enabled And all Settings Remain The Same", null);
         
         RC_Global.clickUsingXpath(driver, "(//div//label[text()='Inherit Attributes *']//following::div[2]//button[normalize-space(text())='Yes'])[3]", "Inherit Attributes", true,true);
         RC_Global.clickButton(driver, "Ok", true, true);
         RC_Global.waitElementVisible(driver, 30, "//legend[text()='Remarketing Enrollment']", "Remarketing Section", false, true);
         wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//label[text()='Client Directed Sales Permitted *']//following::div[2]//label[(text()='No')]")));
         queryObjects.logStatus(driver, Status.PASS, "All the fields are populated with values from", "The Parent Level", null);
         
         RC_Global.clickUsingXpath(driver, "(//div//label[text()='Inherit Attributes *']//following::div[2]//button[normalize-space(text())='No'])[3]", "Inherit Attributes", true,true);
         RC_Global.validateHeaderName(driver, "Choose Settings", false);
         RC_Global.clickUsingXpath(driver, "//input[contains(@ng-value,'clear')]", "Clear All Settings", true, true);
         RC_Global.clickButton(driver, "Ok", true, true);
         queryObjects.logStatus(driver, Status.PASS, "All the Inherited Settings Are Deleted and All the Original Default Settings are Reflected", "User Control Button are Enabled", null);
         RC_Global.clickUsingXpath(driver, "//label[text()='Courtesy Sales Permitted *']//following::div[2]//label[(text()='No')]", "Courtesy Sales Permitted", true, true);
         WebElement element = driver.findElement(By.xpath("//input[@name='DocumentationFee']"));
         RC_Global.enterInput(driver, "999.99", element, false, true);
         RC_Global.clickUsingXpath(driver, "(//button[text()='Save'])[2]", "Save", true, true);
         Thread.sleep(3000);
         RC_Global.verifyDisplayedMessage(driver, "Update successful", false);
         RC_Global.clickUsingXpath(driver, "//label[text()=' History']", "History", true, true);
 		 RC_Global.waitUntilPanelVisibility(driver,"Remarketing Attributes History","TV", true,false);
 		 String columnname1 = driver.findElement(By.xpath("(//div[@role='button']//span[1])[1]")).getText();
 		String columnname2 = driver.findElement(By.xpath("(//div[@role='button']//span[1])[2]")).getText();
 		String columnname3 = driver.findElement(By.xpath("(//div[@role='button']//span[1])[3]")).getText();
 		  queryObjects.logStatus(driver, Status.PASS, "Column Names Validation --> Column Names are verified", " "+columnname1+" "+columnname2+" "+columnname3+"", null);
 		
 		RC_Global.clickUsingXpath(driver, "(//div[@role='gridcell']//following::div[contains(@class,'grid-cell-contents')]//span)[1]", "Event", true, true);
 		String orig = driver.findElement(By.xpath("//div[text()='Original']")).getText();
 		String updat = driver.findElement(By.xpath("//div[text()='Updated']")).getText();
 		queryObjects.logStatus(driver, Status.PASS, "The Sub section under grid row is", orig, null);
 		queryObjects.logStatus(driver, Status.PASS, "The Sub section under grid row is", updat, null);
 		
 		String columnName1 = driver.findElement(By.xpath("(//div[@role='button']//span[1])[4]")).getText();
 		String columnName2 = driver.findElement(By.xpath("(//div[@role='button']//span[1])[5]")).getText();
 		String columnName3 = driver.findElement(By.xpath("(//div[@role='button']//span[1])[6]")).getText();
 		String columnName4 = driver.findElement(By.xpath("(//div[@role='button']//span[1])[7]")).getText();
 		String columnName5 = driver.findElement(By.xpath("(//div[@role='button']//span[1])[8]")).getText();
 		
 		queryObjects.logStatus(driver, Status.PASS, "Column Names Validation --> Column Names are verified", " "+columnName1+" "+columnName2+" "+columnName3+" "+columnName4+" "+columnName5+"", null);
 		Thread.sleep(2000);
 		
 		//revert changes
// 		 RC_Global.clickUsingXpath(driver, "(//div//label[text()='Inherit Attributes *']//following::div[2]//button[normalize-space(text())='Yes'])[3]", "Inherit Attributes", true,true);
// 		RC_Global.clickButton(driver, "Ok", true, true);
//         RC_Global.clickUsingXpath(driver, "(//button[text()='Save'])[2]", "Save", true, true);
//         RC_Global.verifyDisplayedMessage(driver, "Update successful", false);
 		RC_Global.panelAction(driver, "close", "Remarketing Attributes History", false,true);
 		
 	// if (driver.findElements(By.xpath("(//div//label[text()='Inherit Attributes *']//following::div[2]//button[normalize-space(text())='No'])[3]")).size()>0) {
 	// driver.findElement(By.xpath("(//div//label[text()='Inherit Attributes *']//following::div[2]//button[normalize-space(text())='Yes'])[3]")).click();
 	// RC_Global.clickButton(driver, "Ok", true, true);
 	//  RC_Global.clickUsingXpath(driver, "(//button[text()='Save'])[2]", "Save", true, true);
 	// Thread.sleep(3000);
 	//  RC_Global.verifyDisplayedMessage(driver, "Update successful", false);
 	// }
 		
 		RC_Global.panelAction(driver, "close", "Customer Administration", false,true);
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
