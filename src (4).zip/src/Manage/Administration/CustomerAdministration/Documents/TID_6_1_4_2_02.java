package Manage.Administration.CustomerAdministration.Documents;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_4_2_02 {
	public void ValidationOfDocumentAttributesCustomerLevel(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String ColumnNames="Subsection(s) Modified;Modified Date;Modified By";
		String ActiveButton=""; String NewValue=""; String OldValue="";
		
		
		RC_Global.login(driver);
		RC_Global.enterCustomerFocus(driver, "LS010143", false);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
		RC_Global.clickUsingXpath(driver, "//a[text()='Documents']", "Documents tab", false, true);
		RC_Global.waitElementVisible(driver, 15, "//legend[text()='Customer Originated']", "Documents tab loading", false, false);
		
		if(driver.findElements(By.xpath("//legend[text()='Customer Originated']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Customer Originated' group is displayed", "", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "'Customer Originated' group is not displayed", "", null);
		
		if(driver.findElements(By.xpath("//legend[text()='Charge Supporting Documents']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Charge Supporting Documents' group is displayed", "", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "'Charge Supporting Documents' group is not displayed", "", null);
		
		if(driver.findElements(By.xpath("//legend[text()='Vehicle Files']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Vehicle Files' group is displayed", "", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "'Vehicle Files' group is not displayed", "", null);
		
		if(driver.findElements(By.xpath("//legend[text()='Plates']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Plates' group is displayed", "", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "'Plates' group is not displayed", "", null);
		
		RC_Global.createNode(driver, "Validate Customer Details Section");
		
		if(driver.findElements(By.xpath("(//label[text()='Customer Name'])[2]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Customer Name' is displayed", "", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "'Customer Name' is not displayed", "", null);
		
		if(driver.findElements(By.xpath("(//label[text()='Customer Number'])[2]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Customer Number' is displayed", "", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "'Customer Number' is not displayed", "", null);
		
		if(driver.findElements(By.xpath("(//label[text()='Fleet Name'])[2]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Fleet Name' is displayed", "", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "'Fleet Name' is not displayed", "", null);
		
		if(driver.findElements(By.xpath("(//label[text()='Fleet Number'])[2]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Fleet Number' is displayed", "", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "'Fleet Number' is not displayed", "", null);
		
		if(driver.findElements(By.xpath("(//label[text()='Account Name'])[2]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Account Name' is displayed", "", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "'Account Name' is not displayed", "", null);
		
		if(driver.findElements(By.xpath("(//label[text()='Account Number'])[2]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Account Number' is displayed", "", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "'Account Number' is not displayed", "", null);
		
		if(driver.findElements(By.xpath("(//label[text()='Sub Account Name'])[2]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Sub Account Name' is displayed", "", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "'Sub Account Name' is not displayed", "", null);
		
		if(driver.findElements(By.xpath("(//label[text()='Sub Account Number'])[2]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Sub Account Number' is displayed", "", null);
		}
		else
			queryObjects.logStatus(driver, Status.PASS, "'Sub Account Number' is displayed", "", null);
		
		for(int i=1;i<=3;i++)
		{
			String AttrValue = driver.findElement(By.xpath("//span[text()='Delivery Receipt']/../following-sibling::div/div/label["+i+"]")).getAttribute("class");
			if(AttrValue.contains("active"))
			{
				ActiveButton=driver.findElement(By.xpath("//span[text()='Delivery Receipt']/../following-sibling::div/div/label["+i+"]")).getText();
				break;
			}
		}
		if(ActiveButton.equals("None"))
		{
			NewValue="Selected";
			OldValue="Not Selected";
			RC_Global.clickUsingXpath(driver, "//span[text()='Delivery Receipt']/../following-sibling::div/div/label[2]", "Customer", false, true);
		}
		else if(ActiveButton.equals("Customer"))
		{
			OldValue="Selected";
			NewValue="Not Selected";
			RC_Global.clickUsingXpath(driver, "//span[text()='Delivery Receipt']/../following-sibling::div/div/label[1]", "None", false, true);
		}
		else
		{
			OldValue="Not Selected";
			NewValue="Selected";
			RC_Global.clickUsingXpath(driver, "//span[text()='Delivery Receipt']/../following-sibling::div/div/label[2]", "Customer", false, true);
		}
		RC_Global.clickUsingXpath(driver, "(//button[text()='Save'])[1]", "Save", false, false);
		RC_Global.waitElementVisible(driver, 10, "(//h4[text()='Update Successful'])[1]", "Update Successful message is displayed", false, true);
		if(driver.findElements(By.xpath("(//label[text()=' History '])[1]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "There is 'History' link right below the header section on the right side", "", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "There is no 'History' link right below the header section on the right side", "", null);
		
		RC_Global.clickUsingXpath(driver, "(//label[text()=' History '])[1]", "History", false, true);
		if(driver.findElements(By.xpath("//span[text()='Customer Document Attributes History']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Customer Document Attributes History screen is displayed", "", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "Customer Document Attributes History screen is not displayed", "", null);
		
		RC_Global.verifyColumnNames(driver, ColumnNames, false);
		RC_Global.clickUsingXpath(driver, "((//tbody[@class='ng-scope'])[1]/tr/td)[1]", "Subsection(s) Modified hyperlink", false, true);
		if(driver.findElement(By.xpath("(//tr[contains(@ng-repeat,'HistoryItems')])[1]/td[1]")).getText().contains("Customer"))
		{
			if(driver.findElement(By.xpath("(//tr[contains(@ng-repeat,'HistoryItems')])[1]/td[2]")).getText().contains(OldValue) && 
					driver.findElement(By.xpath("(//tr[contains(@ng-repeat,'HistoryItems')])[1]/td[3]")).getText().contains(NewValue))
			{
				queryObjects.logStatus(driver, Status.PASS, "The old value and new value are displayed in different column for change item 'Customer'", "", null);
			}
			else
			{
				queryObjects.logStatus(driver, Status.FAIL, "The old value and new value are not displayed in different column for change item 'Customer'", "", null);
			}
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "The change item column does not display 'Customer'", "", null);
		}
		RC_Global.panelAction(driver, "close", "Customer Document Attributes History", false, true);
		RC_Global.panelAction(driver, "close", "Customer Administration", false, true);
		RC_Global.logout(driver, true);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
