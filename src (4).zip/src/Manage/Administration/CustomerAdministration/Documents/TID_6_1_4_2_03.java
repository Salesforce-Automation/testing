package Manage.Administration.CustomerAdministration.Documents;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_4_2_03 {
	public void ValidationOfDocumentAttributesReInherit(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String FleetLevel="10000 - 30 - Companies";
		String AccountLevel="1830 - 100 - Corporate Companies";
		String SubAccountLevel="116 - 107-Patterson Companies";

		RC_Global.login(driver);
		RC_Global.enterCustomerFocus(driver, "LS010143", false);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
		RC_Global.clickUsingXpath(driver, "//span[text()='"+FleetLevel+"']", "Fleet Level "+FleetLevel, false, true);
		RC_Global.clickUsingXpath(driver, "//a[text()='Documents']", "Documents tab", false, true);
		RC_Manage.validationOfDocumentAttributesReInherit_Documents(driver, false);
		RC_Global.clickUsingXpath(driver, "(//i[@ng-class='iBranchClass()'])[2]", "Expand "+FleetLevel+" Fleet Level", false, true);
		RC_Global.clickUsingXpath(driver, "//span[text()='"+AccountLevel+"']", "Account Level "+AccountLevel, false, true);
		RC_Manage.validationOfDocumentAttributesReInherit_Documents(driver, false);
		RC_Global.clickUsingXpath(driver, "(//i[@ng-class='iBranchClass()'])[3]", "Expand "+AccountLevel+" Account Level", false, true);
		RC_Global.clickUsingXpath(driver, "//span[text()='"+SubAccountLevel+"']", "Sub-Account Level "+SubAccountLevel, false, true);
		RC_Manage.validationOfDocumentAttributesReInherit_Documents(driver, false);
		RC_Global.panelAction(driver, "close", "Customer Administration", false, true);
		RC_Global.logout(driver, true);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
