package Manage.Administration.CustomerAdministration.Documents;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_4_2_01 {
	public void ValidationOfDocumentAttributesSubLevels(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String FleetLevel="10000 - 30 - Companies";
		String FleetLevel2="10001 - 31 - Dental Supply";
		String[] Sections={"Customer Originated","Vehicle Files","Charge Supporting Documents","Plates"};
		String AccountLevel="1830 - 100 - Corporate Companies";
		String SubAccountLevel="116 - 107-Patterson Companies";
		String SubAccountLevel2="117 - 113-Patterson Companies";

		RC_Global.login(driver);
		RC_Global.enterCustomerFocus(driver, "LS010143", false);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
		RC_Global.clickUsingXpath(driver, "//span[text()='"+FleetLevel+"']", "Fleet Level "+FleetLevel, false, true);
		RC_Global.clickUsingXpath(driver, "//a[text()='Documents']", "Documents tab", false, true);
		RC_Global.waitElementVisible(driver, 15, "//legend[text()='Customer Originated']", "Documents tab loading", false, false);	
		if(driver.findElements(By.xpath("//legend[text()='Customer Originated']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Customer Originated' group is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//legend[text()='Charge Supporting Documents']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Charge Supporting Documents' group is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//legend[text()='Vehicle Files']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Vehicle Files' group is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//legend[text()='Plates']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Plates' group is displayed", "", null);
		}
		if(driver.findElement(By.xpath("(//button[text()='Yes'])[1]")).getAttribute("class").contains("active"))
		{
			queryObjects.logStatus(driver, Status.PASS, "'Inherit Attributes' toggle is set to 'Yes'", "", null);
		}
		else {
			queryObjects.logStatus(driver, Status.PASS, "'Inherit Attributes' toggle is set to 'No'", "", null);
			RC_Global.clickUsingXpath(driver, "(//button[text()='Yes'])[1]", "Yes", false, true);
			RC_Global.clickButton(driver, "Ok", false, true);
			RC_Global.waitElementVisible(driver, 15, "//legend[text()='Customer Originated']", "Documents tab loading", false, false);
			RC_Global.clickUsingXpath(driver, "(//button[text()='Save'])[1]", "Save", false, true);
			RC_Global.waitElementVisible(driver, 90, "(//h4[text()='Update Successful'])[1]", "Update Successful message is displayed", false, true);
			if(driver.findElement(By.xpath("(//button[text()='Yes'])[1]")).getAttribute("class").contains("active"))
			{
				queryObjects.logStatus(driver, Status.PASS, "Now the 'Inherit Attributes' toggle is set to 'Yes'", "", null);
			}
		}
		RC_Global.createNode(driver, "Verify groups within the Documents detail page are in view only mode in Fleet level");
		if(driver.findElement(By.xpath("(//legend[text()='Customer Originated']//..)[1]")).getAttribute("disabled").equals("true"))
		{
			queryObjects.logStatus(driver, Status.PASS, "All groups under Customer Originated are disabled", "", null);
		}
		if(driver.findElement(By.xpath("(//legend[text()='Vehicle Files']//..)[1]")).getAttribute("disabled").equals("true"))
		{
			queryObjects.logStatus(driver, Status.PASS, "All groups under Vehicle Files are disabled", "", null);
		}
		if(driver.findElement(By.xpath("(//legend[text()='Charge Supporting Documents']//..)[1]")).getAttribute("disabled").equals("true"))
		{
			queryObjects.logStatus(driver, Status.PASS, "All groups under Charge Supporting Documents are disabled", "", null);
		}
		if(driver.findElement(By.xpath("(//legend[text()='Plates']//..)[1]")).getAttribute("disabled").equals("true"))
		{
			queryObjects.logStatus(driver, Status.PASS, "All groups under Plates are disabled", "", null);
		}


		RC_Global.clickUsingXpath(driver, "(//button[text()='No'])[1]", "No", false, true);
		if(driver.findElements(By.xpath("//input[@type='radio']//following-sibling::label")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Choose Settings'pop up screen is displayed with two choices", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "'Choose Settings'pop up screen is not displayed with two choices", "", null);
		}
		RC_Global.clickUsingXpath(driver, "(//input[@type='radio']//following-sibling::label)[2]", "Clear All Settings so you can Enter New", false, true);
		RC_Global.clickUsingXpath(driver, "(//button[text()='Cancel'])[1]", "Cancel", false, true);
		if(driver.findElement(By.xpath("(//button[text()='Yes'])[1]")).getAttribute("class").contains("active"))
		{
			queryObjects.logStatus(driver, Status.PASS, "'Inherit Attributes' toggle is set to 'Yes'", "", null);
		}
		RC_Global.clickUsingXpath(driver, "(//button[text()='No'])[1]", "No", false, true);
		if(driver.findElements(By.xpath("//input[@type='radio']//following-sibling::label")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Choose Settings'pop up screen is displayed with two choices", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "'Choose Settings'pop up screen is not displayed with two choices", "", null);
		}
		RC_Global.clickUsingXpath(driver, "(//input[@type='radio']//following-sibling::label)[1]", "Copy All Settings so you can Modify Them", false, true);
		RC_Global.clickUsingXpath(driver, "(//button[text()='Cancel'])[1]", "Cancel", false, true);
		if(driver.findElement(By.xpath("(//button[text()='Yes'])[1]")).getAttribute("class").contains("active"))
		{
			queryObjects.logStatus(driver, Status.PASS, "'Inherit Attributes' toggle is set to 'Yes'", "", null);
		}
		RC_Global.clickUsingXpath(driver, "(//button[text()='No'])[1]", "No", false, true);
		if(driver.findElements(By.xpath("//input[@type='radio']//following-sibling::label")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Choose Settings'pop up screen is displayed with two choices", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "'Choose Settings'pop up screen is not displayed with two choices", "", null);
		}
		RC_Global.clickUsingXpath(driver, "(//input[@type='radio']//following-sibling::label)[2]", "Clear All Settings so you can Enter New", false, true);
		RC_Global.clickButton(driver, "Ok", false, true);
		RC_Global.createNode(driver, "Verify groups within the Documents detail page are able to modify");
		for(int i=0;i<Sections.length;i++)
		{
			try {
				String attrValue = driver.findElement(By.xpath("(//legend[text()='"+Sections[i]+"']//..)[1]")).getAttribute("disabled");
				if(attrValue==null)
					queryObjects.logStatus(driver, Status.PASS, "All groups under "+Sections[i]+" are able to modify", "", null);
			}
			catch (NullPointerException e)
			{
			}
		}
		RC_Global.clickUsingXpath(driver, "//span[text()='"+FleetLevel2+"']", "Fleet Level "+FleetLevel2, false, true);
		RC_Global.clickUsingXpath(driver, "//span[text()='"+FleetLevel+"']", "Fleet Level "+FleetLevel, false, true);
		RC_Global.waitElementVisible(driver, 15, "//legend[text()='Customer Originated']", "Documents tab loading", false, false);
		if(driver.findElement(By.xpath("(//button[text()='Yes'])[1]")).getAttribute("class").contains("active"))
		{
			queryObjects.logStatus(driver, Status.PASS, "'Inherit Attributes' toggle is set to 'Yes'", "", null);
		}
		RC_Global.clickUsingXpath(driver, "(//button[text()='No'])[1]", "No", false, true);
		RC_Global.clickUsingXpath(driver, "(//input[@type='radio']//following-sibling::label)[2]", "Clear All Settings so you can Enter New", false, true);
		RC_Global.clickButton(driver, "Ok", false, true);
		RC_Global.createNode(driver, "Verify groups within the Documents detail page are able to modify in Fleet level");
		for(int i=0;i<Sections.length;i++)
		{
			try {
				String attrValue = driver.findElement(By.xpath("(//legend[text()='"+Sections[i]+"']//..)[1]")).getAttribute("disabled");
				if(attrValue==null)
					queryObjects.logStatus(driver, Status.PASS, "All groups under "+Sections[i]+" are able to modify", "", null);
			}
			catch (NullPointerException e)
			{
			}
		}
		RC_Global.clickUsingXpath(driver, "(//button[text()='Save'])[1]", "Save", false, true);
		RC_Global.waitElementVisible(driver, 90, "(//h4[text()='Update Successful'])[1]", "Update Successful message is displayed", false, true);
		RC_Global.clickUsingXpath(driver, "//span[text()='"+FleetLevel2+"']", "Fleet Level "+FleetLevel2, false, true);
		RC_Global.clickUsingXpath(driver, "//span[text()='"+FleetLevel+"']", "Fleet Level "+FleetLevel, false, true);
		RC_Global.waitElementVisible(driver, 15, "//legend[text()='Customer Originated']", "Documents tab loading", false, false);
		if(driver.findElement(By.xpath("(//button[text()='No'])[1]")).getAttribute("class").contains("active"))
		{
			queryObjects.logStatus(driver, Status.PASS, "'Inherit Attributes' toggle is set to 'No'", "", null);
		}
		
		RC_Global.clickUsingXpath(driver, "(//label[text()=' History '])[1]", "History", false, true);
		RC_Global.waitElementVisible(driver, 10, "//span[text()='Subsection(s) Modified']", "History grid is displayed", false, true);
		RC_Global.clickUsingXpath(driver, "((//tbody[@class='ng-scope'])[1]/tr/td)[1]", "Inherit Attributes", false, true);
		if(driver.findElement(By.xpath("(//tr[contains(@ng-repeat,'HistoryItems')])[1]/td[3]")).getText().equals("No"))
		{
			queryObjects.logStatus(driver, Status.PASS, "Verify able to see changes made to the 'Inherit Attributes' toggle within the history", "Successful", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Verify able to see changes made to the 'Inherit Attributes' toggle within the history", "Unsuccessful", null);
		}
		RC_Global.panelAction(driver, "close", "Customer Document Attributes History", false, true);
		RC_Global.clickUsingXpath(driver, "(//i[@ng-class='iBranchClass()'])[2]", "Expand "+FleetLevel+" Fleet Level", false, true);
		RC_Global.clickUsingXpath(driver, "(//i[@ng-class='iBranchClass()'])[3]", "Expand "+AccountLevel+" Account Level", false, true);
		RC_Global.clickUsingXpath(driver, "//span[text()='"+SubAccountLevel+"']", "Sub-Account Level "+SubAccountLevel, false, true);
		RC_Global.waitElementVisible(driver, 15, "//legend[text()='Customer Originated']", "Documents tab loading", false, false);
		if(driver.findElements(By.xpath("//legend[text()='Customer Originated']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Customer Originated' group is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//legend[text()='Charge Supporting Documents']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Charge Supporting Documents' group is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//legend[text()='Vehicle Files']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Vehicle Files' group is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//legend[text()='Plates']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Plates' group is displayed", "", null);
		}
		if(driver.findElement(By.xpath("(//button[text()='Yes'])[1]")).getAttribute("class").contains("active"))
		{
			queryObjects.logStatus(driver, Status.PASS, "'Inherit Attributes' toggle is set to 'Yes'", "", null);
		}
		else {
			queryObjects.logStatus(driver, Status.PASS, "'Inherit Attributes' toggle is set to 'No'", "", null);
			RC_Global.clickUsingXpath(driver, "(//button[text()='Yes'])[1]", "Yes", false, true);
			RC_Global.clickButton(driver, "Ok", false, true);
			RC_Global.waitElementVisible(driver, 15, "//legend[text()='Customer Originated']", "Documents tab loading", false, false);
			RC_Global.clickUsingXpath(driver, "(//button[text()='Save'])[1]", "Save", false, true);
			RC_Global.waitElementVisible(driver, 90, "(//h4[text()='Update Successful'])[1]", "Update Successful message is displayed", false, true);
			if(driver.findElement(By.xpath("(//button[text()='Yes'])[1]")).getAttribute("class").contains("active"))
			{
				queryObjects.logStatus(driver, Status.PASS, "Now the 'Inherit Attributes' toggle is set to 'Yes'", "", null);
			}
		}
		RC_Global.createNode(driver, "Verify groups within the Documents detail page are in view only mode in Sub Account level");
		if(driver.findElement(By.xpath("(//legend[text()='Customer Originated']//..)[1]")).getAttribute("disabled").equals("true"))
		{
			queryObjects.logStatus(driver, Status.PASS, "All groups under Customer Originated are disabled", "", null);
		}
		if(driver.findElement(By.xpath("(//legend[text()='Vehicle Files']//..)[1]")).getAttribute("disabled").equals("true"))
		{
			queryObjects.logStatus(driver, Status.PASS, "All groups under Vehicle Files are disabled", "", null);
		}
		if(driver.findElement(By.xpath("(//legend[text()='Charge Supporting Documents']//..)[1]")).getAttribute("disabled").equals("true"))
		{
			queryObjects.logStatus(driver, Status.PASS, "All groups under Charge Supporting Documents are disabled", "", null);
		}
		if(driver.findElement(By.xpath("(//legend[text()='Plates']//..)[1]")).getAttribute("disabled").equals("true"))
		{
			queryObjects.logStatus(driver, Status.PASS, "All groups under Plates are disabled", "", null);
		}
		RC_Global.clickUsingXpath(driver, "(//button[text()='No'])[1]", "No", false, true);
		if(driver.findElements(By.xpath("//input[@type='radio']//following-sibling::label")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Choose Settings'pop up screen is displayed with two choices", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "'Choose Settings'pop up screen is not displayed with two choices", "", null);
		}
		RC_Global.clickUsingXpath(driver, "(//input[@type='radio']//following-sibling::label)[1]", "Copy All Settings so you can Modify Them", false, true);
		RC_Global.clickUsingXpath(driver, "(//button[text()='Cancel'])[1]", "Cancel", false, true);
		if(driver.findElement(By.xpath("(//button[text()='Yes'])[1]")).getAttribute("class").contains("active"))
		{
			queryObjects.logStatus(driver, Status.PASS, "'Inherit Attributes' toggle is set to 'Yes'", "", null);
		}
		
		RC_Global.clickUsingXpath(driver, "(//button[text()='No'])[1]", "No", false, true);
		if(driver.findElements(By.xpath("//input[@type='radio']//following-sibling::label")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Choose Settings'pop up screen is displayed with two choices", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "'Choose Settings'pop up screen is not displayed with two choices", "", null);
		}
		RC_Global.clickUsingXpath(driver, "(//input[@type='radio']//following-sibling::label)[2]", "Clear All Settings so you can Enter New", false, true);
		RC_Global.clickUsingXpath(driver, "(//button[text()='Cancel'])[1]", "Cancel", false, true);
		if(driver.findElement(By.xpath("(//button[text()='Yes'])[1]")).getAttribute("class").contains("active"))
		{
			queryObjects.logStatus(driver, Status.PASS, "'Inherit Attributes' toggle is set to 'Yes'", "", null);
		}
		
		RC_Global.clickUsingXpath(driver, "(//button[text()='No'])[1]", "No", false, true);
		RC_Global.clickUsingXpath(driver, "(//input[@type='radio']//following-sibling::label)[1]", "Copy All Settings so you can Modify Them", false, true);
		RC_Global.clickButton(driver, "Ok", false, true);
		
		RC_Global.createNode(driver, "Verify groups within the Documents detail page are able to modify in Sub Account level");
		for(int i=0;i<Sections.length;i++)
		{
			try {
				String attrValue = driver.findElement(By.xpath("(//legend[text()='"+Sections[i]+"']//..)[1]")).getAttribute("disabled");
				if(attrValue==null)
					queryObjects.logStatus(driver, Status.PASS, "All groups under "+Sections[i]+" are able to modify", "", null);
			}
			catch (NullPointerException e)
			{
			}
		}
		RC_Global.clickUsingXpath(driver, "//span[text()='"+SubAccountLevel2+"']", "Sub Account Level "+SubAccountLevel2, false, true);
		RC_Global.clickUsingXpath(driver, "//span[text()='"+SubAccountLevel+"']", "Sub Account Level "+SubAccountLevel, false, true);
		RC_Global.waitElementVisible(driver, 15, "//legend[text()='Customer Originated']", "Documents tab loading", false, false);
		if(driver.findElement(By.xpath("(//button[text()='Yes'])[1]")).getAttribute("class").contains("active"))
		{
			queryObjects.logStatus(driver, Status.PASS, "'Inherit Attributes' toggle is set to 'Yes'", "", null);
		}
		
		RC_Global.clickUsingXpath(driver, "(//button[text()='No'])[1]", "No", false, true);
		RC_Global.clickUsingXpath(driver, "(//input[@type='radio']//following-sibling::label)[1]", "Copy All Settings so you can Modify Them", false, true);
		RC_Global.clickButton(driver, "Ok", false, true);
		RC_Global.createNode(driver, "Verify groups within the Documents detail page are able to modify in Sub Account level");
		for(int i=0;i<Sections.length;i++)
		{
			try {
				String attrValue = driver.findElement(By.xpath("(//legend[text()='"+Sections[i]+"']//..)[1]")).getAttribute("disabled");
				if(attrValue==null)
					queryObjects.logStatus(driver, Status.PASS, "All groups under "+Sections[i]+" are able to modify", "", null);
			}
			catch (NullPointerException e)
			{
			}
		}
		RC_Global.clickUsingXpath(driver, "(//button[text()='Save'])[1]", "Save", false, true);
		RC_Global.waitElementVisible(driver, 90, "(//h4[text()='Update Successful'])[1]", "Update Successful message is displayed", false, true);
		RC_Global.clickUsingXpath(driver, "//span[text()='"+SubAccountLevel2+"']", "Sub Account Level "+SubAccountLevel2, false, true);
		RC_Global.clickUsingXpath(driver, "//span[text()='"+SubAccountLevel+"']", "Sub Account Level "+SubAccountLevel, false, true);
		RC_Global.waitElementVisible(driver, 15, "//legend[text()='Customer Originated']", "Documents tab loading", false, false);
		if(driver.findElement(By.xpath("(//button[text()='No'])[1]")).getAttribute("class").contains("active"))
		{
			queryObjects.logStatus(driver, Status.PASS, "'Inherit Attributes' toggle is set to 'No'", "", null);
		}

		RC_Global.clickUsingXpath(driver, "(//label[text()=' History '])[1]", "History", false, true);
		RC_Global.waitElementVisible(driver, 10, "//span[text()='Subsection(s) Modified']", "History grid is displayed", false, true);
		RC_Global.clickUsingXpath(driver, "((//tbody[@class='ng-scope'])[1]/tr/td)[1]", "Inherit Attributes", false, true);
		if(driver.findElement(By.xpath("(//tr[contains(@ng-repeat,'HistoryItems')])[1]/td[3]")).getText().equals("No"))
		{
			queryObjects.logStatus(driver, Status.PASS, "Verify able to see changes made to the 'Inherit Attributes' toggle within the history", "Successful", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Verify able to see changes made to the 'Inherit Attributes' toggle within the history", "Unsuccessful", null);
		}
		RC_Global.panelAction(driver, "close", "Customer Document Attributes History", false, true);
		RC_Global.panelAction(driver, "close", "Customer Administration", false, true);
		RC_Global.logout(driver, true);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
		
	}
}
