package Manage.Administration.CustomerAdministration.Invoicing;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_4_4_01 {
	public void  Add_UpdateInvoicing(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		String CustomerNumber = "LS008737";WebElement Email = null;
		String OldFirstName = "";
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,"Manage","Administration","Customer Administration");
		RC_Global.enterCustomerNumber(driver, CustomerNumber, "", "", true);
		RC_Global.clickUsingXpath(driver, "//a[text()='Invoicing']", "Invoicing Tab", true, true);
		
		RC_Global.waitElementVisible(driver, 30, "//legend[text()='Contact']", "", true, false);
		RC_Global.createNode(driver, "Invoicing Tab Page Sections");
		RC_Global.verifyScreenComponents(driver, "lable", "Contact", true);
		RC_Global.verifyScreenComponents(driver, "lable", "Invoice Options", true);
		RC_Global.verifyScreenComponents(driver, "lable", "Invoice Details", true);
		RC_Global.verifyScreenComponents(driver, "lable", "Distribution", true);
		RC_Global.verifyScreenComponents(driver, "lable", "ACH Account Details", true);
			
		RC_Global.clickUsingXpath(driver, "//select[contains(@ng-model,'selectedDeliveryOptions')]//option[text()='Email']", "Distribution Email Option Selection", true, true);
		Email = driver.findElement(By.xpath("//input[@ng-model='selectedInvoiceGroup.SendEmailNotificationTo']"));
		RC_Global.enterInput(driver, "Abc@gmail.com", Email, true, true);
		RC_Global.clickButton(driver, "Save", true, true);
		Thread.sleep(2000);
		//RC_Global.waitElementVisible(driver, 30, "//span[@ng-show='isSaving' and @class='ng-hide']", "", true, false);
		RC_Global.verifyDisplayedMessage(driver, "Update Successful", true);	
		
		// Step 6 Validation Pending
		RC_Global.clickUsingXpath(driver, "(//label[text()=' History '])[3]", "History", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Customer Fuel Invoice History", "TV", true, true);
		RC_Global.panelAction(driver, "expand", "Customer Fuel Invoice History", true, true);
		RC_Global.createNode(driver, "History Page Validation");  
		String UserName = driver.findElement(By.xpath("(//span[contains(@ng-show,'user.FullName')])[1]")).getText();	
		OldFirstName = driver.findElement(By.xpath("(//tbody//tr[1]//td[3])[1]")).getText();	
		if(OldFirstName.contains(UserName))
			BFrameworkQueryObjects.logStatus(driver, Status.PASS, "User name in Modified by column", "User name in Modified by column has the username that made changes", null);
		else 
            BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "User name in Modified by column", "User name in Modified by column doesn't have username that made changes", null);
		
		RC_Global.clickUsingXpath(driver, "(//td[text()='Distribution'])[1]", "Subsection(s) Modified - Distribution", true, false);
		List<WebElement> NewValue = driver.findElements(By.xpath("(//td[text()='Abc@gmail.com'])[1]"));
		if(NewValue.size()>0)
			BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Subsection(s) Modified", "New Value is added successfully", null);
		else {
            BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Subsection(s) Modified", "New Value failed to update in hostory page", null);
            RC_Global.endTestRun(driver);
		}
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
