package Manage.Administration.CustomerAdministration.Invoicing;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_4_4_02 { 
	public void  ValidatingInvoicingPageAttributesInHistory(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		String CustomerNumber = "LS008737";String FuelInvoiceFrequencyDropDownValues = "Daily;Weekly;Bi-Monthly;Monthly;No Frequency";WebElement FirstNameIn = null;
		String FuelPaymentDueDateDropDownValues = "Not Applicable;Due Upon Receipt;Due and Payable Within 5 Days of the Invoice Date;Due and Payable Within 15 Days of the Invoice Date";
		String InvoiceFormatDropDownValues = "Fuel Invoice;Fuel with Subtotal;Fuel Subtotal - Excel;Fuel - Excel;Fuel - Excel Only;Std Non-Disclosure";
		String DistributionOptionDropDownValues = "Email;Mail;Fax;TotalView";String HisColumnNmes = "Subsection(s) Modified;Modified Date;Modified By";
		WebElement Email = null;
		String OldFirstName = "";
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,"Manage","Administration","Customer Administration");
		RC_Global.enterCustomerNumber(driver, CustomerNumber, "", "", true);
		RC_Global.clickUsingXpath(driver, "//a[text()='Invoicing']", "Invoicing Tab", true, true);
		RC_Global.waitElementVisible(driver, 30, "//legend[text()='Contact']", "", true, false);

		RC_Global.createNode(driver, "Invoicing Tab Page Sections");
		RC_Global.verifyScreenComponents(driver, "lable", "Select Invoice Group", true);
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Contact", true);
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Invoice Options", true);
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Invoice Details", true);
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Distribution", true);
		
		RC_Global.createNode(driver, "Invoicing Tab Page Sections");
		RC_Global.verifyScreenComponents(driver, "lable", "First Name *", true);
		RC_Global.verifyScreenComponents(driver, "lable", "Last Name *", true);
		RC_Global.verifyScreenComponents(driver, "lable", "Address *", true);
		RC_Global.verifyScreenComponents(driver, "lable", "Address 2", true);
		RC_Global.verifyScreenComponents(driver, "lable", "City *", true);
		RC_Global.verifyScreenComponents(driver, "lable", "State *", true);
		RC_Global.verifyScreenComponents(driver, "lable", "Zip *", true);
		RC_Global.verifyScreenComponents(driver, "lable", "Phone", true);
		RC_Global.verifyScreenComponents(driver, "lable", "Ext.", true);
		RC_Global.verifyScreenComponents(driver, "lable", "Fax ", true);
		RC_Global.verifyScreenComponents(driver, "lable", "Email", true);
	
		RC_Global.createNode(driver, "Fuel Invoice Frequency DropDown Values Validation");
		RC_Global.dropdownValuesValidation(driver, FuelInvoiceFrequencyDropDownValues, "//select[@id='invoiceFrequency']", true, false);
		RC_Global.createNode(driver, "Fuel Payment Due Date DropDown Values Validation");
		RC_Global.dropdownValuesValidation(driver, FuelPaymentDueDateDropDownValues, "//select[@id='invoiceDueDate']", true, false);
		
		RC_Global.createNode(driver, "Invoice Details Section Validations");
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Invoice Formats", true);
		RC_Global.createNode(driver, "Invoice Format DropDown Values Validation");
		RC_Global.dropdownValuesValidation(driver, InvoiceFormatDropDownValues, "//select[contains(@ng-model,'Fuel_InvoiceFormatRental')]", true, false);	
		
		RC_Global.createNode(driver, "Distribution Option DropDown Values Validation");
		RC_Global.dropdownValuesValidation(driver, InvoiceFormatDropDownValues, "//select[contains(@ng-model,'Fuel_InvoiceFormatRental')]", true, false);	
		RC_Global.clickUsingXpath(driver, "//select[contains(@ng-model,'selectedDeliveryOptions')]//option[text()='Email']", "Distribution Email Option Selection", true, true);
		
		RC_Global.createNode(driver, "Email Section Validation");
		RC_Global.verifyScreenComponents(driver, "lable", "Email *", true);
		RC_Global.verifyScreenComponents(driver, "lable", "CC Email", true);
		RC_Global.verifyScreenComponents(driver, "lable", "BCC Email", true);
		
		Email = driver.findElement(By.xpath("//input[@ng-model='selectedInvoiceGroup.SendEmailNotificationTo']"));
		RC_Global.enterInput(driver, "Abc@gmail.com", Email, true, true);
		
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}