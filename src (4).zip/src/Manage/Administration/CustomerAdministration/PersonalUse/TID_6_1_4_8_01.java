package Manage.Administration.CustomerAdministration.PersonalUse;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import MF.Source.Cred;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_4_8_01 {
	public void PersonalUseAttributesCustomerLevel(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{	
		String[] PersonalSection = {"Personal Use","Open Reporting Years"};
		String[] PersonalField = {"Enrolled In Personal Use *","Program Fees Applicable","Reporting Year","Personal Use Benefit Calculation Method","Fuel Benefit Enrollment *","Driver Log *","Modify Submissions *","Open Reporting Years"};
		String[] FuelEnField = {"Fuel Benefit Enrollment *", "Fuel Benefit Value (cents per mile) *", "Driver Log *", "Modify Submissions *"};
		String verifyDate = "";
		WebDriverWait wait = new WebDriverWait(driver,10);
		
		RC_Global.login(driver);
		//String Username = driver.findElement(By.xpath("(//span/../div)[1]")).getText();
		RC_Global.enterCustomerFocus(driver, "LS008737", false);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
		RC_Global.validateHeaderName(driver, "Customer Administration", false);
		RC_Global.clickUsingXpath(driver, "//a[text()='Personal Use']", "Personal Use Tab", false, true);
		RC_Global.waitElementVisible(driver, 60, "//legend[text()='Personal Use']", "Personal Use Section", false, true);
		
		// verify sections and fields when enrolled in personal use
		boolean flag = false;
		if(driver.findElements(By.xpath("//label[text()='Enrolled In Personal Use *']/../div//button[contains(@class,'active') and normalize-space(text())='Yes']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Customer Number Enrolled in Personal Use","Successfully" , null);
			
			for(int i=0;i<PersonalSection.length;i++)
			{
				if(driver.findElements(By.xpath("//legend[text()='"+PersonalSection[i]+"']")).size()>0)
				{
					queryObjects.logStatus(driver, Status.PASS, "Section present under personal use tab when enrolled in personal use", PersonalSection[i], null);					
					if("Personal Use".equalsIgnoreCase(PersonalSection[i])) {
						for(int j=0;j<PersonalField.length-1;j++)
						{
							if(driver.findElements(By.xpath("//legend[text()='"+PersonalSection[i]+"']/..//fieldset//label[text()='"+PersonalField[j]+"']")).size()>0)
							{
								queryObjects.logStatus(driver, Status.PASS, "Field present under "+PersonalSection[i]+" section when enrolled in personal use", PersonalField[j], null);
							}
							else{
								queryObjects.logStatus(driver, Status.FAIL, "Unable to find Field under "+PersonalSection[i]+" section when enrolled in personal use", PersonalField[j], null);			
							}
						}}
					else{
						for(int j=7;j<PersonalField.length;j++){
						if(driver.findElements(By.xpath("//legend[text()='"+PersonalSection[i]+"']/..//label[text()='"+PersonalField[j]+"']")).size()>0){
							queryObjects.logStatus(driver, Status.PASS, "Field present under "+PersonalSection[i]+" section when enrolled in personal use", PersonalField[j], null);
						}
						else{
							queryObjects.logStatus(driver, Status.FAIL, "Unable to find Field under "+PersonalSection[i]+" section when enrolled in personal use", PersonalField[j], null);			
						}}
					}
				}
				else{
					queryObjects.logStatus(driver, Status.FAIL, "Unable to find Section when enrolled in personal use", PersonalSection[i], null);			
				}
			}			
			Thread.sleep(2000);					
			flag = true;
		}
		else {
			queryObjects.logStatus(driver, Status.FAIL, "Customer Number Not Enrolled in Personal Use"," " , null);
		}
		
		if(flag) {
			RC_Global.clickUsingXpath(driver, "//label[text()='Enrolled In Personal Use *']/../div//button[normalize-space(text())='No']", "Unenroll PersonalUse", false, true);
		}
		Thread.sleep(1000);	
		
		// verify sections and fields when not enrolled in personal use
		if(driver.findElements(By.xpath("//label[text()='Enrolled In Personal Use *']/../div//button[contains(@class,'active') and normalize-space(text())='No']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Customer Number UnEnrolled in Personal Use","Successfully" , null);
			if(driver.findElements(By.xpath("//legend[text()='Personal Use']")).size()>0)
			{	String Section = driver.findElement(By.xpath("//form[@name='personalUseForm']//fieldset/legend")).getText();
				queryObjects.logStatus(driver, Status.PASS, "Section present under personal use tab when unenrolled in personal use", Section, null);
				if(driver.findElements(By.xpath("//label[text()='Enrolled In Personal Use *']")).size()>0)
				{ String Field = driver.findElement(By.xpath("//legend[text()='Personal Use']/../div/fieldset/label")).getText();
					queryObjects.logStatus(driver, Status.PASS, "Field present under personal use tab when unenrolled in personal use", Field, null);
				}
				else{
					queryObjects.logStatus(driver, Status.FAIL, "Unable to find Field when unenrolled in personal use", " ", null);			
				}
			}
			else{
				queryObjects.logStatus(driver, Status.FAIL, "Unable to find section when unenrolled in personal use", " ", null);			
			}
		}
		else {
			queryObjects.logStatus(driver, Status.FAIL, "Customer Number Enrolled in Personal Use", " " , null);
		}
		
		// verify field attributes when fuel benefit is enrolled under personal use
		if(driver.findElements(By.xpath("//label[text()='Enrolled In Personal Use *']/../div//button[contains(@class,'active') and normalize-space(text())='No']")).size()>0)
		{
			RC_Global.clickUsingXpath(driver, "//label[text()='Enrolled In Personal Use *']/../div//button[normalize-space(text())='Yes']", "To enroll in PersonalUse from Unenrollment", false, true);
			if(driver.findElements(By.xpath("//label[contains(text(),'Fuel Benefit Enrollment')]/../div//button[contains(@class,'active') and normalize-space(text())='No']")).size()>0)
			{
				RC_Global.clickUsingXpath(driver, "//label[contains(text(),'Fuel Benefit Enrollment')]/../div//button[normalize-space(text())='Yes']", "Fuel Benefit Enrollment", false, true);
				for(int i=0;i<FuelEnField.length;i++)
				{
					if(driver.findElements(By.xpath("//label[text()='"+FuelEnField[i]+"']")).size()>0)
					{
						queryObjects.logStatus(driver, Status.PASS, "Displays attribute when enrolled in Fuel Benefits", FuelEnField[i], null);
					}
					else{
						queryObjects.logStatus(driver, Status.FAIL, "Unable to find attribute when enrolled in Fuel Benefits",  FuelEnField[i], null);			
					}
				}
				RC_Global.clickUsingXpath(driver, "//label[contains(text(),'Fuel Benefit Enrollment')]/../div//button[normalize-space(text())='No']", "Fuel Benefit UnEnrollment", false, true);
			}
			else {
					queryObjects.logStatus(driver, Status.INFO, "Fuel Benefit Enrollment is already enrolled", "", null);
				for(int i=0;i<=FuelEnField.length;i++)
				{
					if(driver.findElements(By.xpath("//label[text()='"+FuelEnField[i]+"']")).size()>0)
					{
						queryObjects.logStatus(driver, Status.PASS, "Displays attribute when enrolled in Fuel Benefits", FuelEnField[i], null);						
					}
					else{
						queryObjects.logStatus(driver, Status.FAIL, "Unable to find attribute when enrolled in Fuel Benefits",  FuelEnField[i], null);			
					}
				}
			}
		}
		else {
				queryObjects.logStatus(driver, Status.INFO, "Customer Number Enrolled in Personal Use"," " , null);
				if(driver.findElements(By.xpath("//label[contains(text(),'Fuel Benefit Enrollment')]/../div//button[contains(@class,'active') and normalize-space(text())='No']")).size()>0)
				{
					RC_Global.clickUsingXpath(driver, "//label[contains(text(),'Fuel Benefit Enrollment')]/../div//button[normalize-space(text())='Yes']", "Fuel Benefit Enrollment", false, true);
					for(int i=0;i<=FuelEnField.length;i++)
					{
						if(driver.findElements(By.xpath("//label[text()='"+FuelEnField[i]+"']")).size()>0)
						{
							queryObjects.logStatus(driver, Status.PASS, "Displays attribute when enrolled in Fuel Benefits", FuelEnField[i], null);
							if(("Driver Log *".equalsIgnoreCase(""+FuelEnField[i]+"")) || ("Modify Submissions *".equalsIgnoreCase(""+FuelEnField[i]+"")))
							{
								List<WebElement> Option = driver.findElements(By.xpath("//label[text()='"+FuelEnField[i]+"']/../select//option"));
								for(int j=0;j<=Option.size();j++) {
									String OptionValue = driver.findElement(By.xpath("//label[text()='"+FuelEnField[i]+"']/../select//option["+j+"]")).getText();
									queryObjects.logStatus(driver, Status.PASS, "Displays "+FuelEnField[i]+" attribute values ", OptionValue, null);
								}	
							}											
						}
						else{
							queryObjects.logStatus(driver, Status.FAIL, "Unable to find attribute when enrolled in Fuel Benefits",  FuelEnField[i], null);			
						}
					}
					RC_Global.clickUsingXpath(driver, "//label[contains(text(),'Fuel Benefit Enrollment')]/../div//button[normalize-space(text())='No']", "Fuel Benefit UnEnrollment", false, true);
				}
				else {
						queryObjects.logStatus(driver, Status.INFO, "Fuel Benefit Enrollment is already enrolled", "", null);
					for(int i=0;i<=FuelEnField.length;i++)
					{
						if(driver.findElements(By.xpath("//label[text()='"+FuelEnField[i]+"']")).size()>0)
						{
							queryObjects.logStatus(driver, Status.PASS, "Displays attribute when enrolled in Fuel Benefits", FuelEnField[i], null);						
						}
						else{
							queryObjects.logStatus(driver, Status.FAIL, "Unable to find attribute when enrolled in Fuel Benefits",  FuelEnField[i], null);			
						}
					}
				}
			}	
		
		// verify No access for attributes under personal use
		RC_Global.createNode(driver, "Verify No access for the attributes on personal use tab");
		String[] NoAccess = {"Program Fees Applicable", "Reporting Year", "Personal Use Benefit Calculation Method"};
		
		for(int i=0;i<NoAccess.length;i++)
		{
			if(driver.findElements(By.xpath("//label[text()='"+NoAccess[i]+"']/../select[@disabled]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Disabled and No access for the attribute", NoAccess[i], null);						
			}
			else if(driver.findElements(By.xpath("//label[text()='"+NoAccess[i]+"']/../input[@disabled]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Disabled and No access for the attribute", NoAccess[i], null);						
			}
			else
			{
				queryObjects.logStatus(driver, Status.FAIL, ""+NoAccess[i]+" attribute is not Disabled and has access  "," ", null);						
			}
			
		}
		
		// verify able to close reporting year
		RC_Global.clickButton(driver, "Close Reporting Year", false, true);
		if(driver.findElements(By.xpath("//h3[text()='Close Reporting Year?']")).size()>0)
		{
			RC_Global.verifyDisplayedMessage(driver, " Are you sure you would like to Close the Reporting Year? This action cannot be undone and will permanently lock all submissions completed within this Reporting Year and no further submissions can be made. ", false);
			driver.findElement(By.xpath("(//button[text()='Cancel'])[1]")).click();
		}
		
		// verify can not disenroll customer if child cus are currently enrolled under personal use
		if(driver.findElements(By.xpath("//label[text()='Enrolled In Personal Use *']/../div//button[contains(@class,'active') and normalize-space(text())='Yes']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Customer Number-Fleet level Enrolled in Personal Use","Successfully" , null);
			RC_Global.clickUsingXpath(driver, "//label[text()='Enrolled In Personal Use *']/../div//button[normalize-space(text())='No']", "To unenroll PersonalUse from enrollment", false, true);
			Thread.sleep(2000);
			RC_Global.clickUsingXpath(driver, "(//button[@id='save' and text()='Save'])[4]", "Save", false, false);
			Thread.sleep(3000);
			RC_Global.verifyDisplayedMessage(driver, "You can not disenroll a customer if child customers are currently enrolled.", false);
			RC_Global.clickUsingXpath(driver, "//label[text()='Enrolled In Personal Use *']/../div//button[normalize-space(text())='Yes']", "To enroll in PersonalUse from unenrollment", false, true);
			Thread.sleep(2000);
			RC_Global.clickUsingXpath(driver, "(//button[@id='save' and text()='Save'])[4]", "Save", false, false);
			RC_Manage.waitUntilMethods(driver, "//div[@id='personalUseAttributesPanelContent']//button[@id='save']/../following-sibling::div[@ng-if='isSaving']","","", "invisible");
			Thread.sleep(3000);
			RC_Global.verifyDisplayedMessage(driver, "Update Successful", false);
		}
		else {
			queryObjects.logStatus(driver, Status.FAIL, "Customer Number-Fleet level Not Enrolled in Personal Use"," " , null);
		}
		
		// verify Atribute history 
		RC_Global.clickUsingXpath(driver, "//div[@id='personalUseAttributesPanel']/../div//label[normalize-space(text())='History']", "History", false, true);
		RC_Global.panelAction(driver, "close", "Customer Administration", false,true);
		RC_Global.waitUntilPanelVisibility(driver, "Personal Use Attributes History", "TV", false, false);
		RC_Global.panelAction(driver, "expand", "Personal Use Attributes History", false,true);
		String[] Personalclm = {"Subsection(s) Modified", "Modified Date", "Modified By"};
		List<WebElement> clmcnt = driver.findElements(By.xpath("//fieldset[legend[text()='Personal Use Attributes History']]/../div//table//tr/th//span[1]"));
		for(int i=1; i<=clmcnt.size();i++)
		{
			String clmnName = driver.findElement(By.xpath("(//fieldset[legend[text()='Personal Use Attributes History']]/../div//table//tr/th//span[1])["+i+"]")).getText();
			if(Personalclm[i-1].equalsIgnoreCase(clmnName)) {
			queryObjects.logStatus(driver, Status.PASS, "Verified Personal Use Attributes History column Name --",clmnName, null);
			}
			else {
				queryObjects.logStatus(driver, Status.FAIL, "Unable to find Personal Use Attributes History column Names "," ", null);
			}		
		}
		String Username = driver.findElement(By.xpath("//span[contains(@ng-show,'user.FullName') and @id='Span1']")).getText();	
		verifyDate = RC_Manage.AddDateStr(0, "MMM d, yyyy", "", null, "CST");
		if (driver.findElements(By.xpath("(//tbody/tr)[1]/td[3][contains(text(),'"+Username+"')]")).size()>0 && driver.findElements(By.xpath("(//table/tbody/tr)[1]//td[2][contains(text(),'"+verifyDate+"')]")).size()>0) 
		{
				driver.findElement(By.xpath("((//tbody[1]/tr)[1]/td)[1]")).click();
				queryObjects.logStatus(driver, Status.PASS, "User changes displayed in first line of history", "with the Username,"+Username+" and date,"+verifyDate, null);
		}
		else {
			queryObjects.logStatus(driver, Status.FAIL, "User changes are not reflecting in the history", "Verification failed", null);
		}
		RC_Global.panelAction(driver, "close", "Personal Use Attributes History", false,true);
	    RC_Global.logout(driver, false);
	    
	    queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);	
		
		}
	}

