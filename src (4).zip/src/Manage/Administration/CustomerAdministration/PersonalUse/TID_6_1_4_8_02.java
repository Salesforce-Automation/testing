package Manage.Administration.CustomerAdministration.PersonalUse;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_4_8_02 {
	
	public void PersonalUseAttributesSubLevels(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		WebDriverWait wait = new WebDriverWait(driver,10);
		
		RC_Global.login(driver);
		RC_Global.enterCustomerFocus(driver, "11672", false);//10447
		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
		RC_Global.validateHeaderName(driver, "Customer Administration", false);
		RC_Global.clickUsingXpath(driver, "//a[text()='Personal Use']", "Personal Use Tab", false, true);
		RC_Global.waitElementVisible(driver, 60, "//legend[text()='Personal Use']", "Personal Use Section", false, true);
		
		String cusLevel =  driver.findElement(By.xpath("//input[@name='customerInput']")).getAttribute("value");
		queryObjects.logStatus(driver, Status.PASS, "The settings for Personal Use from the customer level","inherit to the Fleet Level "+cusLevel+"", null);
		
		String personalEnrolled =  driver.findElement(By.xpath("//label[text()='Enrolled In Personal Use *']//parent::fieldset")).getAttribute("disabled");
		queryObjects.logStatus(driver, Status.PASS, "The Customer Level is not Enrolled in personal use so,","It reflects in lower level "+personalEnrolled+"", null);
		
		RC_Global.panelAction(driver, "close", "Customer Administration", false,true);
		
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@ng-click='customerFocusClicked()']")));
         RC_Global.clickUsingXpath(driver,"//a[@ng-click='customerFocusClicked()']","Customer Focus", false,false);
         RC_Global.enterInput(driver,"10447",(WebElement)(driver.findElement(By.xpath("//div[@ng-show='customerChosen']//input"))), false,false);
         wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(@title,'10447')]")));
         RC_Global.clickUsingXpath(driver,"//a[contains(@title,'10447')]","Customer Number", false,false);
         queryObjects.logStatus(driver, Status.PASS, "Entered customer number available","Customer Focus set with 10447", null);
         
         
		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
		RC_Global.validateHeaderName(driver, "Customer Administration", false);
		RC_Global.clickUsingXpath(driver, "//a[text()='Personal Use']", "Personal Use Tab", false, true);
		RC_Global.waitElementVisible(driver, 60, "//legend[text()='Personal Use']", "Personal Use Section", false, true);
		
		String cusLevelvalue =  driver.findElement(By.xpath("//input[@name='customerInput']")).getAttribute("value");
		RC_Manage.toggleButtonStatusValidation(driver, "Enrolled In Personal Use *", "Yes", "DefaultSelection", false);
		queryObjects.logStatus(driver, Status.PASS, "The Customer Level is Enrolled in Personal Use so,","Lower levels are automatically Enrolled in Personal Use "+cusLevelvalue+"", null);
		RC_Global.panelAction(driver, "close", "Customer Administration", false,true);
		
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@ng-click='customerFocusClicked()']")));
         RC_Global.clickUsingXpath(driver,"//a[@ng-click='customerFocusClicked()']","Customer Focus", false,false);
         RC_Global.enterInput(driver,"LS008742",(WebElement)(driver.findElement(By.xpath("//div[@ng-show='customerChosen']//input"))), false,false);
         wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(@title,'LS008742')]")));
         RC_Global.clickUsingXpath(driver,"//a[contains(@title,'LS008742')]","Customer Number", false,false);
         queryObjects.logStatus(driver, Status.PASS, "Entered customer number available","Customer Focus set with LS008742", null);
         //
		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
		RC_Global.validateHeaderName(driver, "Customer Administration", false);
		RC_Global.clickUsingXpath(driver, "//a[text()='Personal Use']", "Personal Use Tab", false, true);
		RC_Global.waitElementVisible(driver, 60, "//legend[text()='Personal Use']", "Personal Use Section", false, true);
		
		String cusLevelval =  driver.findElement(By.xpath("//input[@name='customerInput']")).getAttribute("value");
		RC_Manage.toggleButtonStatusValidation(driver, "Enrolled In Personal Use *", "Yes", "DefaultSelection", false);
		queryObjects.logStatus(driver, Status.PASS, "The Attribute Settings are Inherited from the Customer Level and Values are","displayed "+cusLevelvalue+" and "+cusLevelval+" ", null);
		
		RC_Global.panelAction(driver, "close", "Customer Administration", false,true);
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@ng-click='customerFocusClicked()']")));
        RC_Global.clickUsingXpath(driver,"//a[@ng-click='customerFocusClicked()']","Customer Focus", false,false);
        RC_Global.enterInput(driver,"10447",(WebElement)(driver.findElement(By.xpath("//div[@ng-show='customerChosen']//input"))), false,false);
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(@title,'10447')]")));
        RC_Global.clickUsingXpath(driver,"//a[contains(@title,'10447')]","Customer Number", false,false);
        queryObjects.logStatus(driver, Status.PASS, "Entered customer number available","Customer Focus set with 10447", null);
        //
		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
		RC_Global.validateHeaderName(driver, "Customer Administration", false);
		RC_Global.clickUsingXpath(driver, "//a[text()='Personal Use']", "Personal Use Tab", false, true);
		RC_Global.waitElementVisible(driver, 60, "//legend[text()='Personal Use']", "Personal Use Section", false, true);
		String colorin = driver.findElement(By.xpath("//select[@name='selectBenefitCalculationMethodType']")).getCssValue("background-color");
        String hexin = Color.fromString(colorin).asHex();
        System.out.println(hexin);
        String colorgrey = "#eeeeee";
        if(colorgrey.equalsIgnoreCase(hexin)) {
       	queryObjects.logStatus(driver, Status.PASS, "In Personal Use Tab except Enrolled In Personal Use", "Other section fields are grayed out Not able to Modify them at Lower Levels", null);}
        RC_Global.clickUsingXpath(driver, "//div//label[text()='Enrolled In Personal Use *']//following::div[2]//button[normalize-space(text())='No']", "Enrolled In Personal Use", false, true);
        RC_Global.clickUsingXpath(driver, "(//button[text()='Save'])[5]", "Save", true, true);
        Thread.sleep(3000);
        RC_Global.verifyDisplayedMessage(driver, "Update successful", false);
        
        RC_Global.panelAction(driver, "close", "Customer Administration", false,true);
        
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@ng-click='customerFocusClicked()']")));
        RC_Global.clickUsingXpath(driver,"//a[@ng-click='customerFocusClicked()']","Customer Focus", false,false);
        RC_Global.enterInput(driver,"LS008742",(WebElement)(driver.findElement(By.xpath("//div[@ng-show='customerChosen']//input"))), false,false);
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(@title,'LS008742')]")));
        RC_Global.clickUsingXpath(driver,"//a[contains(@title,'LS008742')]","Customer Number", false,false);
        queryObjects.logStatus(driver, Status.PASS, "Entered customer number available","Customer Focus set with LS008742", null);
        //
        RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
		RC_Global.validateHeaderName(driver, "Customer Administration", false);
		RC_Global.clickUsingXpath(driver, "//a[text()='Personal Use']", "Personal Use Tab", false, true);
		RC_Global.waitElementVisible(driver, 60, "//legend[text()='Personal Use']", "Personal Use Section", false, true);
		
		RC_Global.clickUsingXpath(driver, "//div//label[text()='Enrolled In Personal Use *']//following::div[2]//button[normalize-space(text())='No']", "Enrolled In Personal Use", false, true);
		
		RC_Global.verifyDisplayedMessage(driver, "You can not disenroll a customer if child customers are currently enrolled.", false);
		
		  RC_Global.panelAction(driver, "close", "Customer Administration", false,true);
	      RC_Global.logout(driver, false);
	 	  queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);	
		
	}	

}
