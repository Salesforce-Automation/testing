package Manage.Administration.CustomerAdministration.Ordering;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_4_7_07 {
	public void OrderingProfilesAttributesCustomerLevel(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		int rowCount; List<String> profileNamesFleet=new ArrayList<String>(); String fleetLevel="";String accountLevel="";
		String subAccountLevel=""; List<String>  profileNamesacclvl = new ArrayList<String>(); List<String>  profileNamesSubacc=new ArrayList<String>();
		
		RC_Global.login(driver);
		RC_Global.enterCustomerFocus(driver, "LS010143", false);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
		RC_Global.clickUsingXpath(driver, "//a[text()='Ordering']", "Ordering", false, true);
		if(driver.findElements(By.xpath("//label[contains(text(),'Incentive Program')]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Manufacturers' Incentive Program tab is displayed", "", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "Manufacturers' Incentive Program tab is not displayed", "", null);
		
		if(driver.findElements(By.xpath("//label[text()='Ordering Attributes']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Ordering Attributes tab is displayed", "", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "Ordering Attributes tab is not displayed", "", null);
		
		if(driver.findElements(By.xpath("//label[text()='Ordering Profiles']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Ordering Profiles tab is displayed", "", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "Ordering Profiles tab is not displayed", "", null);
		
		RC_Global.clickUsingXpath(driver, "//*[text()='Ordering Profiles']", "Ordering Profiles", false, true);
		if(driver.findElements(By.xpath("//*[text()='Add New Profile']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Add New Profile button is displayed", "User can able to add new profile", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "Add New Profile button is displayed", "User is unable to add new profile", null);
		
		if(driver.findElements(By.xpath("((//div[@ng-show='showGrid'])[1]/div/div/table)[2]/tbody/tr[1]/td/button")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Different actions are displayed in Available Actions column", "User can able to Edit/Clone/Activate/Deactivate the profiles", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "Different actions are displayed in Available Actions column", "User is unable to Edit/Clone/Activate/Deactivate the profiles", null);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		   Thread.sleep(1000);
		   executor.executeScript("document.body.style.zoom = '30%'");
		   Thread.sleep(2000);
		   executor.executeScript("document.body.style.zoom = '100%'");
		
		fleetLevel= driver.findElement(By.xpath("(//treeItem//li//div//span)[1]")).getText();
		RC_Global.clickUsingXpath(driver, "(//treeItem//li//div//span)[1]", "Fleet Level "+fleetLevel+"", false, true);
		Thread.sleep(3000);
		RC_Global.waitElementVisible(driver, 30, "((//div[@ng-show='showGrid'])[1]/div/div/table)[2]/tbody/tr", "", true, true);
		rowCount=driver.findElements(By.xpath("((//div[@ng-show='showGrid'])[1]/div/div/table)[2]/tbody/tr")).size();	
		for(int i=1;i<=rowCount;i++)
		{
			profileNamesFleet.add(driver.findElement(By.xpath("((//div[@ng-show='showGrid'])[1]/div/div/table)[2]/tbody/tr["+i+"]/td[3]")).getText());
		}
		RC_Manage.verifyCustomerLevelDefinedOrderingProfilesInSubLevels(driver, profileNamesFleet, "Fleet Level", false);
		RC_Global.scrollById(driver, "(//*[text()=' Customer # '])[1]");
		RC_Global.clickUsingXpath(driver, "(//treeItem//li//i[1])[1]", "Expand "+fleetLevel+"", false, false);
		accountLevel=driver.findElement(By.xpath("(//treeItem//li//div//span)[1]/../following-sibling::treeItem/ul/li/div/span")).getText();
		RC_Global.clickUsingXpath(driver, "(//treeItem//li//div//span)[1]/../following-sibling::treeItem/ul/li/div/span", "Account Level "+accountLevel+"", false, true);
		Thread.sleep(2000);
		RC_Global.waitElementVisible(driver, 30, "((//div[@ng-show='showGrid'])[1]/div/div/table)[2]/tbody/tr", "", true, true);
		rowCount=driver.findElements(By.xpath("((//div[@ng-show='showGrid'])[1]/div/div/table)[2]/tbody/tr")).size();	
		for(int i=1;i<=rowCount;i++)
		{
			profileNamesacclvl.add(driver.findElement(By.xpath("((//div[@ng-show='showGrid'])[1]/div/div/table)[2]/tbody/tr["+i+"]/td[3]")).getText());
		}
		RC_Manage.verifyCustomerLevelDefinedOrderingProfilesInSubLevels(driver, profileNamesacclvl, "Account Level", false);
		RC_Global.scrollById(driver, "(//*[text()=' Customer # '])[1]");
		RC_Global.clickUsingXpath(driver, "(//treeItem//li//i[1])[2]", "Expand "+accountLevel+"", false, false);
		subAccountLevel=driver.findElement(By.xpath("((//treeItem//li//div//span)[2]/../following-sibling::treeItem/ul/li/div/span)[1]")).getText();
		RC_Global.clickUsingXpath(driver, "((//treeItem//li//div//span)[2]/../following-sibling::treeItem/ul/li/div/span)[1]", "Sub Account Level "+subAccountLevel+"", false, true);
		Thread.sleep(2000);
		RC_Global.waitElementVisible(driver, 30, "((//div[@ng-show='showGrid'])[1]/div/div/table)[2]/tbody/tr", "", true, true);
		rowCount=driver.findElements(By.xpath("((//div[@ng-show='showGrid'])[1]/div/div/table)[2]/tbody/tr")).size();	
		for(int i=1;i<=rowCount;i++)
		{
			profileNamesSubacc.add(driver.findElement(By.xpath("((//div[@ng-show='showGrid'])[1]/div/div/table)[2]/tbody/tr["+i+"]/td[3]")).getText());
		}
		RC_Manage.verifyCustomerLevelDefinedOrderingProfilesInSubLevels(driver, profileNamesSubacc, "Sub Account Level", false);
		RC_Global.scrollById(driver, "(//span[text()='Customer Administration'])[2]");
		RC_Global.panelAction(driver, "close", "Customer Administration", false, true);
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
