package Manage.Administration.CustomerAdministration.Ordering;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_4_7_01 {
	public void MIP_AttributeFleetCanSeeCustomerLevel(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		JavascriptExecutor executor = (JavascriptExecutor) driver;int rowCount;int flag=0;String colValue="";String colValue2="";
		int fleetLevelrowCount;
		
		RC_Global.login(driver);// Step 1
		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");//Step 2
		RC_Global.enterCustomerNumber(driver, "LS010087", "", "", false);//Step 3
		if(driver.findElements(By.xpath("//*[@name='customerInput']/following-sibling::treecontrol/ul")).size()>0)//Step 3 Expected
		{
			queryObjects.logStatus(driver, Status.PASS, "Customer Structure tree is displayed below the Customer #", "", null);
		}
		if(driver.findElements(By.xpath("//*[text()='Customer Summary']")).size()>0)//Step 3
		{
			queryObjects.logStatus(driver, Status.PASS, "The 'Customer Summary' tab is displayed on the right", "", null);
		}
		RC_Global.clickUsingXpath(driver, "//a[text()='Ordering']", "Ordering", false, true);//Step 4
		if(driver.findElements(By.xpath("//label[contains(text(),'Incentive Program') and contains(@class,'active')]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Manufacturers' Incentive Program tab is displayed and selected by default", "", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "Manufacturers' Incentive Program tab is displayed but not selected by default", "", null);
		
		if(driver.findElements(By.xpath("//label[text()='Ordering Attributes']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Ordering Attributes button is displayed", "", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "Ordering Attributes button is not displayed", "", null);
		if(driver.findElements(By.xpath("//label[text()='Ordering Profiles']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Ordering Profiles button is displayed", "", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "Ordering Profiles button is not displayed", "", null);
		RC_Global.createNode(driver, "Verify the 'MIP' (Manufacturers' Incentive Programs) screen");
		if(driver.findElements(By.xpath("(//label[text()='Customer Number'])[7]/following-sibling::div")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "The Header displays the 'Customer Number'", driver.findElement(By.xpath("(//label[text()='Customer Number'])[7]/following-sibling::div")).getText(), null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "The Header does not display the 'Customer Number'", driver.findElement(By.xpath("(//label[text()='Customer Number'])[7]/following-sibling::div")).getText(), null);
		
		if(driver.findElements(By.xpath("(//label[text()='Customer Name'])[7]/following-sibling::div")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "The Header displays the 'Customer Name'", driver.findElement(By.xpath("(//label[text()='Customer Name'])[7]/following-sibling::div")).getText(), null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "The Header does not display the 'Customer Name'", driver.findElement(By.xpath("(//label[text()='Customer Name'])[7]/following-sibling::div")).getText(), null);
		
		if(driver.findElements(By.xpath("(//label[text()='Customer Since'])[7]/following-sibling::div")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "The Header displays the 'Customer Since'", driver.findElement(By.xpath("(//label[text()='Customer Since'])[7]/following-sibling::div")).getText(), null);
		}
		else
			queryObjects.logStatus(driver, Status.PASS, "The Header does not display the 'Customer Since'", driver.findElement(By.xpath("(//label[text()='Customer Since'])[7]/following-sibling::div")).getText(), null);
		
		if(driver.findElements(By.xpath("(//*[@type='checkbox' and contains(@class,'ng-empty')])[1]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "The 'Show Inactive' checkbox is not checked", "", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "The 'Show Inactive' checkbox is checked", "", null);
		
		if(driver.findElements(By.xpath("(//*[text()=' History '])[5]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "History hyperlink is displayed", "", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "History hyperlink is not displayed", "", null);
		
		if(driver.findElements(By.xpath("//*[text()='Create New']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Create New button is displayed", "", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "Create New button is not displayed", "", null);
		
		if(driver.findElements(By.xpath("(//tbody)[3]/tr")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, " Manufacturer Incentive Programs defined at the Customer level are listed in the grid", "", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, " Manufacturer Incentive Programs is not defined at the Customer level are listed in the grid", "", null);
		
		rowCount=driver.findElements(By.xpath("(//tbody)[3]/tr")).size();
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//span[text()='Fleet #'])[1]")));
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//button[text()=' Deactivate ']")).size()>1)
		{
			queryObjects.logStatus(driver, Status.PASS, "There is an active 'Deactivate' button associated with each Program listed", "", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "There is no active 'Deactivate' button associated with each Program listed", "", null);
		outer: for(int i=1;i<=rowCount;i++)
		{
			for(int j=11;j<=16;j++)
			{
				colValue=driver.findElement(By.xpath("(//tbody)[3]/tr["+i+"]/td["+j+"]")).getText();
				if(!colValue.equals("")) {
					flag++;
					break outer;
				}
			}
		}
		if(flag==0)
		{
			queryObjects.logStatus(driver, Status.PASS, "The 'Fleet', 'Account', and 'Sub-Account' fields are all blank", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "The 'Fleet', 'Account', and 'Sub-Account' fields are all not blank", "", null);
		}
		Thread.sleep(1000);
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//*[text()=' Customer # '])[1]")));
		RC_Global.clickUsingXpath(driver, "(//*[@class='tree-label '])[2]/span", driver.findElement(By.xpath("(//*[@class='tree-label '])[2]/span")).getText(), false, true);
		RC_Global.waitElementVisible(driver, 10, "(//*[text()='Customer #'])[1]", "Grid is loading", false, false);
		fleetLevelrowCount=driver.findElements(By.xpath("(//tbody)[3]/tr")).size();
		if(fleetLevelrowCount>rowCount)
		{
			queryObjects.logStatus(driver, Status.PASS, "The nummber of Programs displayed increases in the grid", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "The nummber of Programs displayed is not increased in the grid", "", null);
		}
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//*[text()='Customer #'])[1]")));
		for(int i=1;i<=fleetLevelrowCount;i++)
		{
			colValue=driver.findElement(By.xpath("(//tbody)[3]/tr["+i+"]/td[1]")).getText();
			if(!colValue.equals("LS010087"))
			{
				flag=5;
				break;
			}
		}
		if(flag!=5)
		{
			queryObjects.logStatus(driver, Status.PASS, "The Customer # column continues to display 'LS010087' for all rows", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "The Customer # column does not continue to display 'LS010087' for all rows", "", null);
		}
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//span[text()='Account #'])[1]")));
		Thread.sleep(2000);
		for(int i=1;i<=fleetLevelrowCount;i++)
		{
			colValue=driver.findElement(By.xpath("(//tbody)[3]/tr["+i+"]/td[11]")).getText();
			if(!colValue.equals(""))
			{
				colValue2=driver.findElement(By.xpath("(//tbody)[3]/tr["+i+"]/td[12]")).getText();
				queryObjects.logStatus(driver, Status.PASS, "The Fleet # and Fleet Name are displayed in row "+Integer.toString(i), colValue+" "+colValue2, null);
				if(driver.findElements(By.xpath("(//tbody)[3]/tr["+i+"]/td[10]/button[2]")).size()>0 && 
						driver.findElements(By.xpath("(//tbody)[3]/tr["+i+"]/td[10]/button[2][@disabled='disabled']")).size()==0)
				{
					queryObjects.logStatus(driver, Status.PASS, "An active 'Deactivate' button is displayed in row "+Integer.toString(i), "", null);
				}
				else
					queryObjects.logStatus(driver, Status.FAIL, "An active 'Deactivate' button is not displayed in row "+Integer.toString(i), "", null);
			}
			else
			{
				if(driver.findElements(By.xpath("(//tbody)[3]/tr["+i+"]/td[10]/button[2][@disabled='disabled']")).size()>0)
				{
					queryObjects.logStatus(driver, Status.PASS, "Fleet #, Fleet Name and active 'Deactivate' button is not displayed in row "+Integer.toString(i), "", null);
				}
				else
					queryObjects.logStatus(driver, Status.FAIL, "Fleet #, Fleet Name and active 'Deactivate' button is displayed in row "+Integer.toString(i), "", null);
			}
		}
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//span[text()='Customer Administration'])[2]")));
		RC_Global.clickUsingXpath(driver, "//*[text()=' Show Inactive ']/input", "Show Inactive", false, true);
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//span[text()='Customer #'])[1]")));
		for(int i=1;i<=fleetLevelrowCount;i++)
		{
			colValue=driver.findElement(By.xpath("(//tbody)[3]/tr["+i+"]/td[11]")).getText();
			if(colValue.equals(""))
			{
				RC_Global.clickUsingXpath(driver, "(//tbody)[3]/tr["+i+"]/td[3]", "Program Name", false, true);
				executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//*[text()='Program Details']")));
				if(driver.findElements(By.xpath("//*[text()='Program Details']/../form/div/div/div/div")).size()>0)
				{
					queryObjects.logStatus(driver, Status.PASS, "The Program details are listed", "", null);
				}
				else
					queryObjects.logStatus(driver, Status.FAIL, "The Program details are not listed", "", null);
				executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//*[text()='Define Tiers']")));
				if(driver.findElements(By.xpath("//*[text()='Manage Documents']")).size()>0 && 
						driver.findElements(By.xpath("//*[text()='Manage Documents' and @disabled='disabled']")).size()==0)
				{
					queryObjects.logStatus(driver, Status.PASS, "Manage Documents button is active", "", null);
				}
				else
					queryObjects.logStatus(driver, Status.FAIL, "Manage Documents button is not active", "", null);
					
				if(driver.findElements(By.xpath("(//*[text()='Cancel'])[1]")).size()>0 && 
						driver.findElements(By.xpath("(//*[text()='Cancel' and @disabled='disabled'])[1]")).size()==0)
				{
					queryObjects.logStatus(driver, Status.PASS, "Cancel button is active", "", null);
				}
				else
					queryObjects.logStatus(driver, Status.FAIL, "Cancel button is not active", "", null);
					
				RC_Global.clickButton(driver, "Manage Documents", false, true);
				if(driver.findElements(By.xpath("(//div[@class='table-body-wrapper table-responsive'])[1]/table/tbody/tr")).size()>0)
				{
					queryObjects.logStatus(driver, Status.PASS, "Documents for the program are listed", "", null);
				}
				else
					queryObjects.logStatus(driver, Status.FAIL, "Documents for the program are not listed", "", null);
				RC_Global.clickUsingXpath(driver, "(//div[@class='table-body-wrapper table-responsive'])[1]/table/tbody/tr/td[6]/input", "Checkbox for one or more documents", false, true);
				if(driver.findElements(By.xpath("(//div[@class='form-group pull-right'])[1]/fieldset[@disabled='disabled']")).size()==0)
				{
					queryObjects.logStatus(driver, Status.PASS, "The 'Open' and 'Print' buttons become enabled", "", null);
				}
				else
					queryObjects.logStatus(driver, Status.FAIL, "The 'Open' and 'Print' buttons did not become enabled", "", null);
					
				RC_Global.clickUsingXpath(driver, "(//button[text()='Cancel'])[1]", "Cancel", false, true);
				Thread.sleep(2000);
				break;
			}
		}
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//span[text()='Customer #'])[1]")));
		for(int i=1;i<=fleetLevelrowCount;i++)
		{
			colValue=driver.findElement(By.xpath("(//tbody)[3]/tr["+i+"]/td[11]")).getText();
			if(!colValue.equals(""))
			{
				RC_Global.clickUsingXpath(driver, "(//tbody)[3]/tr["+i+"]/td[3]", "Program Name", false, true);
				executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//*[text()='Program Details']")));
				if(driver.findElements(By.xpath("//*[text()='Program Details']/../form/div/div/div/div")).size()>0)
				{
					queryObjects.logStatus(driver, Status.PASS, "The Program details are listed", "", null);
				}
				else
					queryObjects.logStatus(driver, Status.FAIL, "The Program details are not listed", "", null);
					
				if(driver.findElements(By.xpath("//*[text()='Manage Documents']")).size()>0 && 
						driver.findElements(By.xpath("//*[text()='Manage Documents' and @disabled='disabled']")).size()==0)
				{
					queryObjects.logStatus(driver, Status.PASS, "Manage Documents button is active", "", null);
				}
				else
					queryObjects.logStatus(driver, Status.FAIL, "Manage Documents button is not active", "", null);
					
				if(driver.findElements(By.xpath("(//button[text()='Edit'])[1]")).size()>0 && 
						driver.findElements(By.xpath("(//button[text()='Edit' and @disabled='disabled'])[1]")).size()==0)
				{
					queryObjects.logStatus(driver, Status.PASS, "Edit button is active", "", null);
				}
				else
					queryObjects.logStatus(driver, Status.PASS, "Edit button is not active", "", null);
				
				if(driver.findElements(By.xpath("(//button[text()='Clone'])[1]")).size()>0 && 
						driver.findElements(By.xpath("(//button[text()='Clone' and @disabled='disabled'])[1]")).size()==0)
				{
					queryObjects.logStatus(driver, Status.PASS, "Clone button is active", "", null);
				}
				else
					queryObjects.logStatus(driver, Status.FAIL, "Clone button is not active", "", null);
				if(driver.findElements(By.xpath("(//button[text()='Cancel'])[1]")).size()>0 && 
						driver.findElements(By.xpath("(//button[text()='Cancel' and @disabled='disabled'])[1]")).size()==0)
				{
					queryObjects.logStatus(driver, Status.PASS, "Cancel button is active", "", null);
				}
				else
					queryObjects.logStatus(driver, Status.FAIL, "Cancel button is not active", "", null);
				break;
			}
		}
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//span[text()='Customer Administration'])[2]")));
		RC_Global.panelAction(driver, "close", "Customer Administration", false, true);
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
