package Manage.Administration.CustomerAdministration.Ordering;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_4_7_09 {
	public void  OrderingProfile_CreateCustomerLevelProfile (WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
		String CustomerNumber = "LS008737";String Profilename = "";String SelectionOptions = "Factory Order;Out of Stock;Purchase and Leaseback;Bailment Pool";
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,"Manage","Administration","Customer Administration");
		RC_Global.enterCustomerNumber(driver, CustomerNumber, "", "", true);
		RC_Global.clickUsingXpath(driver, "//a[text()='Ordering']", "Ordering Tab", true, true);
		RC_Global.waitElementVisible(driver, 30, "//label[text()='Ordering Profiles']", "", true, false);
		
		RC_Global.clickUsingXpath(driver, "//label[text()='Ordering Profiles']", "Ordering Profiles Tab", true, true);
		RC_Global.clickButton(driver, "Add New Profile", true, true);	
		RC_Global.clickUsingXpath(driver, "//span[text()=' Profile Details ']", "Profiles Details title", true, true);
		WebElement ProfileName = driver.findElement(By.xpath("(//textarea[@name='profileName'])[1]"));
		Profilename = "RegressionTest_"+RandomStringUtils.randomNumeric(5)+"_"+CustomerNumber;
		RC_Global.enterInput(driver, Profilename, ProfileName, true, true);
		
		RC_Global.validateMultipleSelectionFilter(driver, SelectionOptions, true);
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Order Type ", "Factory Order;Bailment Pool", true);
		
		RC_Global.dropdownValuesValidation(driver, "Open End;Closed End;Purchase and Disposal", "(//select[@name='agreementType'])[1]", true, true);
		RC_Global.selectDropdownOption(driver, "agreementType", "Open End", true, true);
		
		RC_Global.dropdownValuesValidation(driver, "Structured;Unstructured", "(//select[@name='pricingDeterminedBy'])[1]", true, true);
		RC_Global.selectDropdownOption(driver, "pricingDeterminedBy", "Structured", true, true);
		
		RC_Global.dropdownValuesValidation(driver, "Front;Back;Both;Both � 5/25;Both � 15/15;None � 15th/16th;None � Following Month", "(//select[@name='interimRent'])[1]", true, true);
		RC_Global.selectDropdownOption(driver, "interimRent", "None � 15th/16th", true, true);
		
		RC_Global.dropdownValuesValidation(driver, "No;Step Depreciation;Skip Payment", "(//select[@name='irregularLease'])[1]", true, true);
		RC_Global.selectDropdownOption(driver, "irregularLease", "No", true, true);
		
		RC_Global.clickButton(driver, "Save and Activate", true, true);
		if(driver.findElements(By.xpath("//span[contains(@class,'green ng-scope') and contains(@ng-show,'isValidProfileDetails')]")).size()==1)
			BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Profile Details", "Green checkmark is appering on Profile Details section", null);
		else {
            BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Profile Details", "Green checkmark doesn't appered on Profile Details section", null);
            RC_Global.endTestRun(driver);}
		
		RC_Global.clickUsingXpath(driver, "//span[text()=' Profile Details ']", "Profiles Details title", true, true);
		RC_Global.clickUsingXpath(driver, "//span[text()=' How to Bill Order Related Fees ']", "How to Bill Order Related Fees title", true, true);
		
		RC_Global.selectDropdownOption(driver, "isClientTaxExempt", "No", true, true);
		RC_Global.selectDropdownOption(driver, "upfrontSalesTax", "Capitalize", true, true);
		RC_Global.selectDropdownOption(driver, "transportation", "Capitalize", true, true);
		RC_Global.selectDropdownOption(driver, "dealerDocFees", "Capitalize", true, true);
		RC_Global.selectDropdownOption(driver, "initialRegistration", "Capitalize", true, true);
		RC_Global.selectDropdownOption(driver, "upfits", "Capitalize", true, true);
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "courtesyDeliveryFees", "Capitalize", true);

		RC_Global.clickButton(driver, "Save and Activate", true, true);
		if(driver.findElements(By.xpath("//span[contains(@class,'green ng-scope') and contains(@ng-show,'isValidHowToBillOrderRelatedFields')]")).size()==1)
			BFrameworkQueryObjects.logStatus(driver, Status.PASS, "How to Bill Order Related Fees", "Green checkmark is appering on How to Bill Order Related Fees section", null);
		else {
            BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "How to Bill Order Related Fees", "Green checkmark doesn't appered on How to Bill Order Related Fees section", null);
            RC_Global.endTestRun(driver);}
		
		RC_Global.clickUsingXpath(driver, "//span[text()=' How to Bill Order Related Fees ']", "How to Bill Order Related Fees title", true, true);
		RC_Global.clickUsingXpath(driver, "//span[text()=' Overhead and Risk ']", "Overhead and Risk title", true, true);

		RC_Global.selectDropdownOption(driver, "overheadRisk", "Low", true, true);
		RC_Global.selectDropdownOption(driver, "overheadHowToBill", "In Addition to Management Fee", true, true);
		RC_Global.selectDropdownOption(driver, "insuranceRisk", "High", true, true);
		RC_Global.selectDropdownOption(driver, "maintenanceRisk", "Normal", true, true);
		
		RC_Global.clickButton(driver, "Save and Activate", true, true);
		if(driver.findElements(By.xpath("//span[contains(@class,'green ng-scope') and contains(@ng-show,'isValidOverheadAndRisk')]")).size()==1)
			BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Overhead and Risk", "Green checkmark is appering on Overhead and Risk section", null);
		else {
            BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Overhead and Risk", "Green checkmark doesn't appered on Overhead and Risk section", null);
            RC_Global.endTestRun(driver);}
		
		RC_Global.clickUsingXpath(driver, "//span[text()=' Overhead and Risk ']", "Overhead and Risk title", true, true);
		
		RC_Global.clickUsingXpath(driver, "//span[text()=' Capitalization Cost Calculation Formula ']", "Capitalization Cost Calculation Formula title", true, true);

		RC_Global.clickUsingXpath(driver, "(//input[@type='radio' and @name='domesticFactoryOrderMarkDown'])[1]", " Domestic Factory Order Markup/Markdown radio button", true, true);
		RC_Global.enterInput(driver, "4", driver.findElement(By.xpath("//percentage-input[contains(@ng-model,'DomesticFactoryOrderMarkdown')]//input")), true, true);
		RC_Global.clickUsingXpath(driver, "(//input[@type='radio' and @name='ForeignFactoryOrderMarkdown'])[1]", " Foreign Factory Order Markup/Markdown radio button", true, true);
		RC_Global.enterInput(driver, "5", driver.findElement(By.xpath("//percentage-input[contains(@ng-model,'ForeignFactoryOrderMarkdown')]//input")), true, true);
		RC_Global.clickUsingXpath(driver, "(//input[@type='radio' and @name='SpecialtyFactoryOrderVehicleMarkup'])[1]", " Specialty Factory Order Vehicle Markup/Markdown radio button", true, true);
		RC_Global.enterInput(driver, "6", driver.findElement(By.xpath("//percentage-input[contains(@ng-model,'SpecialtyFactoryOrderVehicleMarkup')]//input")), true, true);
		RC_Global.clickUsingXpath(driver, "(//input[@type='radio' and @name='UpfitMarkup'])[1]", " Upfit Markup radio button", true, true);
		RC_Global.enterInput(driver, "7", driver.findElement(By.xpath("//percentage-input[contains(@ng-model,'UpfitMarkup')]//input")), true, true);

		RC_Global.dropdownValuesValidation(driver, "Factory Invoice;Invoice less Incentive;Holdback;Finance Money;Holdback and Finance Money", "(//select[contains(@ng-options,'MarkupMarkdownDirectionType')])[1]", true, true);
		driver.findElement(By.xpath("(//select[contains(@ng-model,'MarkdownDirectionTypeId')])[1]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//select[contains(@ng-model,'MarkdownDirectionTypeId')])[1]/option[text()='Factory Invoice']")).click();
		Thread.sleep(2000);

		driver.findElement(By.xpath("(//select[contains(@ng-model,'MarkdownDirectionTypeId')])[2]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//select[contains(@ng-model,'MarkdownDirectionTypeId')])[2]/option[text()='Factory Invoice']")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("(//select[contains(@ng-model,'MarkdownDirectionTypeId')])[3]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//select[contains(@ng-model,'MarkdownDirectionTypeId')])[3]/option[text()='Factory Invoice']")).click();
		Thread.sleep(2000);
		
		RC_Global.clickButton(driver, "Save and Activate", true, true);
		if(driver.findElements(By.xpath("//span[contains(@class,'green ng-scope') and contains(@ng-show,'isValidCapitalizationCostCalculationFormula')]")).size()==1)
			BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Capitalization Cost Calculation Formula", "Green checkmark is appering on Capitalization Cost Calculation Formula section", null);
		else {
            BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Capitalization Cost Calculation Formula", "Green checkmark doesn't appered on Capitalization Cost Calculation Formula section", null);
            RC_Global.endTestRun(driver);}
		
		RC_Global.clickUsingXpath(driver, "//span[text()=' Capitalization Cost Calculation Formula ']", "Capitalization Cost Calculation Formula title", true, true);

		RC_Global.clickUsingXpath(driver, "//span[text()=' Lease Terms and Fees ']", "Lease Terms and Fees title", true, true);
		
		RC_Global.selectDropdownOption(driver, "minimumLeaseTerm", "24", true, true);
		RC_Global.selectDropdownOption(driver, "leaseTerm", "30", true, true);
		RC_Global.selectDropdownOption(driver, "amortizationType", "DB EOM", true, true);
		RC_Global.selectDropdownOption(driver, "numberOfLeaseSteps", "2", true, true);
		RC_Global.selectDropdownOption(driver, "interestCalculationMethod", "Float", true, true);

		RC_Global.clickUsingXpath(driver, "(//input[@type='radio' and @name='fullAmortizationFeeType'])[1]", "Full Amortization Fee radio button", true, true);
		RC_Global.enterInput(driver, "9", driver.findElement(By.xpath("//percentage-input[contains(@ng-model,'FullAmortizationFee')]//input")), true, true);
		RC_Global.clickUsingXpath(driver, "(//input[@type='radio' and @name='managementFeeType'])[2]", "Management Fee radio button", true, true);
		RC_Global.enterInput(driver, "12", driver.findElement(By.xpath("//currency-input[contains(@ng-model,'ManagementFee')]//input")), true, true);
		
		RC_Global.clickUsingXpath(driver, "(//input[@type='radio' and @name='residualOrDepreciation'])[1]", "Residual radio button", true, true);
		RC_Global.clickUsingXpath(driver, "(//input[@type='radio' and @name='residualOrDeprecationValueType'])[1]", "Residual radio button", true, true);
		RC_Global.enterInput(driver, "18.25", driver.findElement(By.xpath("//currency-input[contains(@ng-model,'ResidualDesired')]//input")), true, false);

		RC_Global.selectDropdownOption(driver, "hasFlatInterestRate", "Yes", true, false);
		RC_Global.enterInput(driver, "10", driver.findElement(By.xpath("//percentage-input[contains(@ng-model,'FlatInterestRatePercentage')]//input")), true, true);

		RC_Global.clickButton(driver, "Save and Activate", true, true);
		if(driver.findElements(By.xpath("//span[contains(@class,'green ng-scope') and contains(@ng-show,'isValidLeaseTermsAndFees')]")).size()==1)
			BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Lease Terms and Fees", "Green checkmark is appering on Lease Terms and Fees section", null);
		else {
            BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Lease Terms and Fees", "Green checkmark doesn't appered on Lease Terms and Fees section", null);
            RC_Global.endTestRun(driver);}
		RC_Global.clickUsingXpath(driver, "//span[text()=' Lease Terms and Fees ']", "Lease Terms and Fees title", true, true);

		RC_Global.clickUsingXpath(driver, "//span[text()=' Fleet Account Numbers ']", "Fleet Account Numbers title", true, true);
		RC_Global.selectDropdownOption(driver, "IncentiveInstructions", "No Incentives", true, true);
		
		RC_Global.clickButton(driver, "Save and Activate", true, true);
		if(driver.findElements(By.xpath("//span[contains(@class,'green ng-scope') and contains(@ng-show,'isValidFleetAccountNumbers')]")).size()==1)
			BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Fleet Account Numbers", "Green checkmark is appering on Fleet Account Numbers section", null);
		else {
            BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Fleet Account Numbers", "Green checkmark doesn't appered on Fleet Account Numbers section", null);
            RC_Global.endTestRun(driver);}
		
		RC_Global.clickUsingXpath(driver, "//span[text()=' Fleet Account Numbers ']", "Fleet Account Numbers title", true, true);
		
		RC_Global.clickUsingXpath(driver, "//span[text()=' Programs ']", "Programs title", true, true);
		
		RC_Global.dropdownValuesValidation(driver, "Full;Administered;Reserve", "//select[@name='maintenanceProgram']", true, true);
		RC_Global.selectDropdownOption(driver, "MaintenanceProgram", "Administered", true, true);
		RC_Global.clickUsingXpath(driver, "//input[contains(@ng-model,'Programs.Telematics')]", "Telematics Checkbox", true, true);
		
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "telematicsDeviceType", "FleetShare", true);
		
		RC_Global.dropdownValuesValidation(driver, "Merchants Insurance;Client Insurance", "//select[@name='insurance']", true, true);
		RC_Global.selectDropdownOption(driver, "insurance", "Client Insurance", true, true);
		RC_Global.selectDropdownOption(driver, "clientInsurance", "Client Driven", true, true);
		RC_Global.clickButton(driver, "Save and Activate", true, true);
		Thread.sleep(3000);
		RC_Global.waitElementVisible(driver, 60, "//input[@ng-model='filter.ProfileName']", "Profile Name Input", true, false);

		RC_Global.enterInput(driver, Profilename, driver.findElement(By.xpath("//input[@ng-model='filter.ProfileName']")), true, true);
		Thread.sleep(3000);
		if(driver.findElements(By.xpath("//td[text()='"+Profilename+"']")).size()>0)
			BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Profile", "The grid displays the profile created", null);
		else {
            BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Profile", "The grid doesn't displays the profile created", null);
            RC_Global.endTestRun(driver);}
		List<WebElement> EditHyp = driver.findElements(By.xpath("//td//button[text()=' Edit ']"));
		List<WebElement> DeactHyp = driver.findElements(By.xpath("(//td//button[text()=' Deactivate '])[19]"));
		if(EditHyp.size()>0 && DeactHyp.size()>0)
			BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Edit and Deactive Hyperlinks", "Edit and Deactive Hyperlinks are displayed in the grid for Customer-"+CustomerNumber, null);
		else 
            BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Edit and Deactive Hyperlinks", "Edit and Deactive Hyperlinks are displayed in the grid for Customer-"+CustomerNumber, null);

		RC_Global.logout(driver, true);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
		
}
}
