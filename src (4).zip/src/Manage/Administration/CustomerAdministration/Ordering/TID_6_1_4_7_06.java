package Manage.Administration.CustomerAdministration.Ordering;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_4_7_06 {
	public void  OrderingAttributes_ValidateDriverOrderingAttributes(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		String CustomerNumber = "LS008737";
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,"Manage","Administration","Customer Administration");
		RC_Global.enterCustomerNumber(driver, CustomerNumber, "", "", true);
		RC_Global.clickUsingXpath(driver, "//a[text()='Ordering']", "Ordering Tab", true, true);
		RC_Global.waitElementVisible(driver, 30, "//label[text()='Ordering Profiles']",     "", true, false);
		
		RC_Global.clickUsingXpath(driver, "//label[text()='Ordering Attributes']", "Ordering Attributes Tab", true, true);
		 
		RC_Global.createNode(driver, "Driver Ordering Attributes Section Validation");
		RC_Global.verifyScreenComponents(driver, "sectionHeading", "Driver Ordering Attributes", true);
		List<WebElement> EnrolledDriverOrdering = driver.findElements(By.xpath("//label[contains(@ng-model,'IsEnrolledInDriverOrdering') and contains(@class,'active') ]"));
		if(EnrolledDriverOrdering.size()>0 )
			BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Enrolled Driver Ordering", "Enrolled Driver Ordering is displayed", null);
		
		RC_Global.verifyScreenComponents(driver, "lable", "Enrolled in Driver Ordering ", true);
		List<WebElement> EnDriverOrderingYes = driver.findElements(By.xpath("//label[contains(@ng-model,'IsEnrolledInDriverOrdering') and @uib-btn-radio='true']"));
		List<WebElement> EnDriverOrderingNo = driver.findElements(By.xpath("//label[contains(@ng-model,'IsEnrolledInDriverOrdering') and @uib-btn-radio='false']"));
		if(EnDriverOrderingYes.size()>0 && EnDriverOrderingNo.size()>0)
			BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Enrolled Driver Ordering", "Enrolled Driver Ordering has Yes/No toggle button", null);
		else {
            BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Enrolled Driver Ordering", "Enrolled Driver Ordering doesnot have Yes/No toggle button", null);
            RC_Global.endTestRun(driver);}
		
		RC_Global.verifyScreenComponents(driver, "lable", "Driver Ordering Fee ", true);
		List<WebElement> DriverOrderingFeeYes = driver.findElements(By.xpath("//label[contains(@ng-model,'IsDriverOrderingFeeApplicable') and @uib-btn-radio='true']"));
		List<WebElement> DriverOrderingFeeNo = driver.findElements(By.xpath("//label[contains(@ng-model,'IsDriverOrderingFeeApplicable') and @uib-btn-radio='false']"));
		if(DriverOrderingFeeYes.size()>0 && DriverOrderingFeeNo.size()>0)
			BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Driver Ordering Fee", "Driver Ordering Fee has Yes/No toggle button", null);
		else {
            BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Driver Ordering Fee", "Driver Ordering Fee doesnot have Yes/No toggle button", null);
            RC_Global.endTestRun(driver);}
		
		RC_Global.verifyScreenComponents(driver, "lable", "Fee Charge Method ", true);
		RC_Global.verifyScreenComponents(driver, "lable", "Driver Ordering Fee Amount ", true);
		
		RC_Global.clickUsingXpath(driver, "(//div[@class='tree-label '])[1]", "Select Sub-Customer level", true, true);
		EnrolledDriverOrdering = driver.findElements(By.xpath("//label[contains(@ng-model,'IsEnrolledInDriverOrdering') and contains(@class,'active') and @uib-btn-radio='true' ]"));
			if(EnrolledDriverOrdering.size()>0 )
				BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Sub-Customer Level", "Sub-Customer Level also has Enrolled Driver Ordering value as the Customer level" , null);
		
		RC_Global.clickUsingXpath(driver, "//label[contains(@ng-model,'IsEnrolledInDriverOrdering') and @uib-btn-radio='false']", "Enrolled in Driver Ordering No toggle button", true, true);
		EnrolledDriverOrdering = driver.findElements(By.xpath("//label[contains(@ng-model,'IsEnrolledInDriverOrdering') and contains(@class,'active') and @uib-btn-radio='false']"));
		if(EnrolledDriverOrdering.size()>0 )
			BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Enrolled Driver Ordering", "Enrolled Driver Ordering is set to No", null);
		else {
            BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Enrolled Driver Ordering", "Enrolled Driver Ordering is not set to No", null);
            RC_Global.endTestRun(driver);}
		
		RC_Global.panelAction(driver, "close", "Customer Administration", true, true);
		RC_Global.logout(driver, true);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
