package Manage.Administration.CustomerAdministration.Ordering;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_4_7_11 {
	public void OrderingProfile_AddOutofStock_OpenEnd_StructuredOrder(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		
		RC_Global.login(driver);
		RC_Global.enterCustomerFocus(driver, "LS010087", false);
		Thread.sleep(2000);
		RC_Global.navigateTo(driver,"Manage","Administration","Customer Administration");
		RC_Global.validateHeaderName(driver, "Customer Administration", false);
		if(driver.findElements(By.xpath("//input[@name='customerInput' and @required='required']")).size()>0) {
			queryObjects.logStatus(driver, Status.INFO, "Customer # field is displayed for input", "Successfully", null);
		}
		else{
			queryObjects.logStatus(driver, Status.FAIL, "Customer # field is not displayed for input", "", null);
		}
			
		//RC_Global.enterCustomerNumber(driver, "LS010143", "", "", false);
		
		// Verify default tab displayed
		if(driver.findElements(By.xpath("//li[contains(@class,'active')]//a[text()='Customer Summary']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.INFO, "Customer Summary Tab is defaulted", "Successfully", null);
		}
		else{
			queryObjects.logStatus(driver, Status.FAIL, "Customer Summary Tab is not defaulted", "", null);
		}
		
		// Validate Tabs displayed
		List<WebElement> Tabcnt= driver.findElements(By.xpath("//li[contains(@ng-click,'updateSelectedTab')]//a"));
		Thread.sleep(1000);
		for(int i=1; i<=Tabcnt.size();i++) {
		String tabs = driver.findElement(By.xpath("(//li[contains(@ng-click,'updateSelectedTab')]//a)["+i+"]")).getText();
		queryObjects.logStatus(driver, Status.INFO, "Tabs displayed in customer Administration Screen ", tabs, null);
		}
		
		// Verify cus # enrolled in maintenance
		RC_Global.clickUsingXpath(driver, "//a[text()='Maintenance']", "Maintenance", false, true);
		
		if(driver.findElements(By.xpath("//label[text()='Enrolled in Maintenance *']/..//button[contains(@class,'active') and normalize-space(text())='Yes']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.INFO, "Customer # enrolled in maintenance as", "Yes", null);
		}
		else{
			queryObjects.logStatus(driver, Status.FAIL, "Customer # not enrolled in maintenance as", "", null);
		}
		
		// Select Ordering Tab		
		RC_Global.clickUsingXpath(driver, "//a[text()='Ordering']", "Ordering", false, true);
		
		// Validate Ordering subTabs displayed
		List<WebElement> SubTabcnt= driver.findElements(By.xpath("//@customer-ordering-tab/../div//label[@ng-model='activeSection']"));
		Thread.sleep(1000);
		for(int i=1; i<=SubTabcnt.size();i++) {
		String subtabs = driver.findElement(By.xpath("(//@customer-ordering-tab/../div//label[@ng-model='activeSection'])["+i+"]")).getText();
		queryObjects.logStatus(driver, Status.INFO, "SubTabs displayed under Ordering tab", subtabs, null);
		}
		
		//@customer-ordering-tab/../div//label[contains(@class,'active') and @ng-model="activeSection"]
		if(driver.findElements(By.xpath("//@customer-ordering-tab/../div//label[contains(@class,'active') and @ng-model='activeSection']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.INFO, "The 'Manufacturer's Incentive Program' tab is highlighted", "Successfully", null);
		}
		else{
			queryObjects.logStatus(driver, Status.FAIL, "The 'Manufacturer's Incentive Program' tab is not highlighted", "", null);
		}
		
		// Select Ordering Profile Tab		
		RC_Global.clickUsingXpath(driver, "//label[text()='Ordering Profiles']", "Ordering Profiles", false, true);
		
		// validate Ordering Profile Search Fields
		String[] FieldNames = "Profile Name;Created By;Modified By;Profile Status".split(";");
		List<WebElement> Searchfields= driver.findElements(By.xpath("//div[@vehicle-ordering-profiles]//form/div[3]/div/label"));
		Thread.sleep(1000);
		for(int i=1; i<=Searchfields.size();i++) {
		String Fields = driver.findElement(By.xpath("//div[@vehicle-ordering-profiles]//form/div[3]/div["+i+"]/label")).getText();
		if(Fields.equals(FieldNames[i-1])) {
			queryObjects.logStatus(driver, Status.PASS, "Search fields on Ordering profile ->", Fields, null);
		}
		else {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to find Search fields on Ordering profile ->", "", null);
		}
		}
		
		RC_Global.buttonStatusValidation(driver, "Add New Profile", "Presence", false);
		RC_Global.clickButton(driver, "Add New Profile", false, true);		
		RC_Global.scrollById(driver, "//span[normalize-space(text())='Profile Details']");
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		   Thread.sleep(1000);
		   executor.executeScript("document.body.style.zoom = '30%'");
		   Thread.sleep(2000);
		   executor.executeScript("document.body.style.zoom = '100%'");
		// Validate sections available under Ordering Profile
		List<WebElement> Sectncnt= driver.findElements(By.xpath("//tv-accordion-group[@ng-form='ProfileDetailsForm']/..//span/../span[@class='ng-scope']"));
		Thread.sleep(1000);
		for(int i=1; i<=Sectncnt.size();i++) {
			String Section = driver.findElement(By.xpath("(//tv-accordion-group[@ng-form='ProfileDetailsForm']/..//span/../span[@class='ng-scope'])["+i+"]")).getText();
			String SectionsP = Section.trim();
			queryObjects.logStatus(driver, Status.PASS, "Sections displayed for profile creation with red check mark", SectionsP, null);	
		
			if(SectionsP.equals("Capitalization Cost Calculation Formula") || SectionsP.equalsIgnoreCase("Comments") )	{
				if(driver.findElements(By.xpath("//span[@class='glyphicon glyphicon-ok-circle green ng-scope']/../span[normalize-space(text())='Capitalization Cost Calculation Formula']")).size()>0)
				{	queryObjects.logStatus(driver, Status.INFO, "Section displayed for profile creation with Green check mark", SectionsP, null);				
				}
				else if(driver.findElements(By.xpath("//span[@class='glyphicon glyphicon-ok-circle green ng-scope']/../span[normalize-space(text())='Comments']")).size()>0)
				{	queryObjects.logStatus(driver, Status.INFO, "Section displayed for profile creation with Green check mark", SectionsP, null);				
				}
			}
		}
		
		// Validate available buttons
		RC_Global.buttonStatusValidation(driver, "Expand All", "Presence", false);
		RC_Global.buttonStatusValidation(driver, "Cancel", "Presence", false);
		RC_Global.buttonStatusValidation(driver, "Save as Draft", "Presence", false);
		RC_Global.buttonStatusValidation(driver, "Save and Activate", "Presence", false);
		
		// Click on profile Details
		RC_Global.clickUsingXpath(driver, "//span[normalize-space(text())='Profile Details']", "Profile Details", false, true);
		Thread.sleep(1000);
		
		// Search Fields Under Profile Details
		//div[contains(@ng-include,'customer-vehicle-ordering-profiles')]/../div//label[normalize-space(text())='Interim Interest Charge Rule']
		String[] SearchField = "Profile Name;Order Type;Agreement Type;Pricing Determined By;Interim Rent;Irregular Lease;Interim Interest Charge Rule".split(";");
	//	List<WebElement> Searchfields= driver.findElements(By.xpath("//div[@vehicle-ordering-profiles]//form/div[3]/div/label"));
		
		Thread.sleep(1000);
		for(int i=0; i<SearchField.length;i++) {
		String Fields = driver.findElement(By.xpath("//div[contains(@ng-include,'customer-vehicle-ordering-profiles')]/../div//label[normalize-space(text())='"+SearchField[i]+"']")).getText();
			queryObjects.logStatus(driver, Status.PASS, "Search fields on Profile Details ->", Fields, null);
		}
		
		if(driver.findElements(By.xpath("//input[contains(@class,'ng-valid-parse')]/../label[text()='Prime Plus 1% on 360 Day Rule']")).size()>0)
		{
			String DefaultSel = driver.findElement(By.xpath("(//input[contains(@class,'ng-valid-parse')]/../label)[2]")).getText();
			queryObjects.logStatus(driver, Status.INFO, "Default Value Selection for 'Interim Interest Charge Rule' ->", DefaultSel, null);
		}
		
		String ProfileName = "Sample 60 Months - Out of Stock -"+RandomStringUtils.randomNumeric(2);
		RC_Global.enterInput(driver, ProfileName, driver.findElement(By.xpath("(//textarea[@name='profileName'])[1]")), false, true);
		// Validate Order Type field multi-select values
		RC_Global.createNode(driver,"Validate Mutli-Select values for Order Type field" );
        String[] dropvalues = "Factory Order;Out of Stock;Purchase and Leaseback;Bailment Pool".split(";");
        String Drpdwn ="";
        List<WebElement> dropvaluecnt = driver.findElements(By.xpath("//select[@name='CustomerVehicleOrderProfileOrderTypeAssignments']/option"));
        boolean flag = false;
        for(int i=1; i<=dropvaluecnt.size();i++) {    
        	Drpdwn = driver.findElement(By.xpath("//select[@name='CustomerVehicleOrderProfileOrderTypeAssignments']/option["+i+"]")).getText();   
 
               if (Drpdwn.equalsIgnoreCase(dropvalues[i-1]))
               {     flag = true; }
        }
        if (flag) {
              queryObjects.logStatus(driver, Status.PASS, "Verify Mutli-Select values for Order Type field ->", Drpdwn, null);
        }else {
              queryObjects.logStatus(driver, Status.FAIL, "Dropdown Values validation", "Failed", null);}
        
        RC_Global.clickUsingXpath(driver, "//select[@name='CustomerVehicleOrderProfileOrderTypeAssignments']/option[text()='Out of Stock']", "Out of Stock value selection", false, true);   
        // Validate Agreement Type field dropdown values
        List<String> dropdown = new ArrayList<String>(Arrays.asList("Open End","Closed End","Purchase and Disposal"));
        RC_Manage.dropdownValuesValidation(driver, dropdown, "Agreement Type", "(//select[@name='agreementType'])[1]", false);
        
        RC_Global.clickUsingXpath(driver, "(//select[@name='agreementType'])[1]", "Agreement Type Field click", false, true);
        RC_Global.clickUsingXpath(driver, "(//select[@name='agreementType'])[1]/option[text()='Open End']", " Open End dropdown selection", false, true);
        
        // Validate Pricing Determined By field dropdown values
        List<String> dropdown1 = new ArrayList<String>(Arrays.asList("Structured","Unstructured"));
        RC_Manage.dropdownValuesValidation(driver, dropdown1, "Pricing Determined By", "(//select[@name='pricingDeterminedBy'])[1]", false);
        
        RC_Global.clickUsingXpath(driver, "(//select[@name='pricingDeterminedBy'])[1]", "Pricing Determined By Field click", false, true);
        RC_Global.clickUsingXpath(driver, "(//select[@name='pricingDeterminedBy'])[1]/option[text()='Structured']", " Structured dropdown selection", false, true);

        // Interim Rent Value Selection
        RC_Global.clickUsingXpath(driver, "(//select[@name='interimRent'])[1]", "Interim Rent Field click", false, true);
        RC_Global.clickUsingXpath(driver, "(//select[@name='interimRent'])[1]/option[text()='Both']", " Both dropdown selection", false, true);
      
        // Irregular Lease Value Selection
        RC_Global.clickUsingXpath(driver, "(//select[@name='irregularLease'])[1]", "Irregular Lease Field click", false, true);
        RC_Global.clickUsingXpath(driver, "(//select[@name='irregularLease'])[1]/option[text()='No']", " No dropdown selection", false, true);

        RC_Global.clickUsingXpath(driver, "//button[@ng-show='canProfileSave()' and text()='Save and Activate']", " Save and Activate", false, true); 
        RC_Global.verifyDisplayedMessage(driver, "Profile not saved. View errors in the sections above.", false);
   
        RC_Global.clickUsingXpath(driver, "//Span[normalize-space(text())='Profile Details']", "Profile Details", false, true);
        RC_Global.clickUsingXpath(driver, "//Span[normalize-space(text())='How to Bill Order Related Fees']", "How to Bill Order Related Fees", false, true);
      
	
        // HowtoBillOrderRelatedFees value selection
        RC_Manage.orderingProfilevalueselection(driver,"HowtoBillOrderRelatedFees", "isClientTaxExempt", "No", false);
        RC_Manage.orderingProfilevalueselection(driver, "HowtoBillOrderRelatedFees", "upfrontSalesTax", "Varies by State", false);
        RC_Manage.orderingProfilevalueselection(driver, "HowtoBillOrderRelatedFees", "transportation", "Capitalize", false);
        RC_Manage.orderingProfilevalueselection(driver, "HowtoBillOrderRelatedFees", "dealerDocFees", "Bill Back", false);
        RC_Manage.orderingProfilevalueselection(driver, "HowtoBillOrderRelatedFees", "upfits", "Capitalize", false);
        executor.executeScript("window.scrollBy(0,250)", "");
	//	RC_Global.selectDropdownOption(driver, "initialRegistration", "Varies by State", true, true);
        driver.findElement(By.xpath("//select[@name='initialRegistration']")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//select[@name='initialRegistration']/option[@label='Varies By State']")).click();
        RC_Manage.orderingProfilevalueselection(driver,"HowtoBillOrderRelatedFees", "courtesyDeliveryFees", "Bill Back", false);
        RC_Global.clickUsingXpath(driver, "//Span[normalize-space(text())='How to Bill Order Related Fees']", "How to Bill Order Related Fees", false, true);
      
        // Overhead and Risk value selection
        RC_Global.clickUsingXpath(driver, "//Span[normalize-space(text())='Overhead and Risk']", "Overhead and Risk", false, true);        
        RC_Manage.orderingProfilevalueselection(driver,"Overhead and Risk", "overheadRisk", "Medium", false);
        RC_Manage.orderingProfilevalueselection(driver,"Overhead and Risk", "overheadHowToBill", "Deduct from Management Fee", false);
        RC_Manage.orderingProfilevalueselection(driver,"Overhead and Risk", "insuranceRisk", "Normal", false);
        RC_Manage.orderingProfilevalueselection(driver,"Overhead and Risk", "maintenanceRisk", "High", false);
        RC_Global.clickUsingXpath(driver, "//Span[normalize-space(text())='Overhead and Risk']", "Overhead and Risk", false, true);
        
        //Lease Terms and Fees value selection
        RC_Global.clickUsingXpath(driver, "//Span[normalize-space(text())='Lease Terms and Fees']", "Lease Terms and Fees", false, true);        
        RC_Manage.orderingProfilevalueselection(driver,"Lease Terms and Fees", "minimumLeaseTerm", "12", false);
        RC_Manage.orderingProfilevalueselection(driver,"Lease Terms and Fees", "leaseTerm", "24", false);
        RC_Manage.orderingProfilevalueselection(driver,"Lease Terms and Fees", "amortizationType", "SL EOM", false);
        RC_Manage.orderingProfilevalueselection(driver,"Lease Terms and Fees", "numberOfLeaseSteps", "Annual", false);
        RC_Manage.orderingProfilevalueselection(driver,"Lease Terms and Fees", "interestCalculationMethod", "Float", false);
        
        RC_Global.clickUsingXpath(driver, "(//input[@name='fullAmortizationFeeType'])[2]", "Full Amortization Fee - $ radio selection", false, true);
        RC_Global.enterInput(driver, "22.12", driver.findElement(By.xpath("//Currency-input[contains(@ng-model,'FullAmortizationFee')]//span[text()='$']/../input")), false, true);
        
        RC_Global.clickUsingXpath(driver, "(//input[@name='managementFeeType'])[2]", "Management Fee - $ radio selection", false, true);
        RC_Global.enterInput(driver, "12.04", driver.findElement(By.xpath("//Currency-input[contains(@ng-model,'ManagementFee')]//span[text()='$']/../input")), false, true);
 
        RC_Global.clickUsingXpath(driver, "//label[text()='Residual']/../input", "Residual radio button" , false, true);
        RC_Global.clickUsingXpath(driver, "//label[text()='$']/../input", "$ radio button" , false, true);
        RC_Global.enterInput(driver, "7.14", driver.findElement(By.xpath("//Currency-input[contains(@ng-model,'ResidualDesired')]//span[text()='$']/../input")), false, true);
        RC_Manage.orderingProfilevalueselection(driver,"Lease Terms and Fees", "hasFlatInterestRate", "Yes", false);
        RC_Global.enterInput(driver, "12", driver.findElement(By.xpath("//percentage-input[contains(@ng-model,'FlatInterestRatePercentage')]//input")), false, true);
        RC_Global.clickUsingXpath(driver, "//Span[normalize-space(text())='Lease Terms and Fees']", "Lease Terms and Fees", false, true);
        
        RC_Global.clickUsingXpath(driver, "//Span[normalize-space(text())='Fleet Account Numbers']", "Fleet Account Numbers", false, true);
        RC_Manage.orderingProfilevalueselection(driver,"Fleet Account Numbers", "incentiveInstructions", "Manufacturer Incentive Off Factory", false);
        RC_Global.clickButton(driver, "Add Account Number", false, true);
        RC_Global.enterInput(driver, "1000", driver.findElement(By.xpath("//input[contains(@ng-model,'FleetAccountNumber')]")), false, true);
        RC_Global.clickUsingXpath(driver, "//Span[normalize-space(text())='Fleet Account Numbers']", "Fleet Account Numbers", false, true);
                
        RC_Global.clickUsingXpath(driver, "//Span[normalize-space(text())='Capitalization Cost Calculation Formula']", "Capitalization Cost Calculation Formula", false, true);      
        String searchFilters = "Domestic Factory Order Markup/Markdown;Foreign Factory Order Markup/Markdown;Specialty Factory Order Vehicle Markup/Markdown;Upfit Markup;Out of Stock Order Markup";
        RC_Global.validateSpecifiedSearchFilters(driver, searchFilters, false);
        RC_Global.clickUsingXpath(driver, "//label[text()=' $ ']//input[@name='OutOfStockOrderMarkup']", "Out Of Stock Order Markup - radio $", false, true);
        RC_Global.enterInput(driver, "23.456", driver.findElement(By.xpath("//Currency-input[contains(@ng-model,'OutOfStockOrderMarkup')]//span[text()='$']/../input")), false, true);
        RC_Global.clickUsingXpath(driver, "//Currency-input[contains(@ng-model,'OutOfStockOrderMarkup')]//span[text()='$']", "radio $", false, true);
        String OutofstockValue = driver.findElement(By.xpath("//Currency-input[contains(@ng-model,'OutOfStockOrderMarkup')]//span[text()='$']/../input")).getText();
        queryObjects.logStatus(driver, Status.INFO, "Displays Out of stock Value as", OutofstockValue, null);
        RC_Global.clickUsingXpath(driver, "//Span[normalize-space(text())='Capitalization Cost Calculation Formula']", "Capitalization Cost Calculation Formula", false, true);
        
        //Programs value selection
        RC_Global.clickUsingXpath(driver, "//Span[normalize-space(text())='Programs']", "Programs", false, true);
        // Validate Maintenance Management field checkbox
        if(driver.findElements(By.xpath("//input[contains(@ng-model, 'MaintenanceManagement') and contains(@class,'ng-not-empty')]")).size()>0)
        {
        	queryObjects.logStatus(driver, Status.PASS, "Maintenance Management field check box is checked", "Successfully", null);
        }
        else
        {
        	queryObjects.logStatus(driver, Status.FAIL, "Maintenance Management field check box is Unchecked", "", null);
        }
        // Validate Maintenance Brochure field checkbox
        if(driver.findElements(By.xpath("//input[contains(@ng-model, 'MaintenanceSchedule') and contains(@class,'ng-not-empty')]")).size()>0)
        {
        	queryObjects.logStatus(driver, Status.PASS, "Maintenance Schedule field check box is checked", "Successfully", null);
        }
        else
        {
        	queryObjects.logStatus(driver, Status.FAIL, "Maintenance Schedule field check box is Unchecked", "", null);
        }
        
        RC_Manage.orderingProfilevalueselection(driver,"Programs", "maintenanceProgram", "Reserve", false);
        
        
        if(driver.findElements(By.xpath("//td[text()='Tire Program']")).size()>0)
        {
        	if(driver.findElements(By.xpath("//td[text()='Tire Program']/../td/input[contains(@class,'ng-empty')]")).size()>0)
        	{
        		queryObjects.logStatus(driver, Status.PASS, "Tire Program field check box is Unchecked", "Successfully", null);
        	}
        	else {
        		queryObjects.logStatus(driver, Status.FAIL, "Tire Program field check box is checked", "", null);
        	}
        }
        else {
        	queryObjects.logStatus(driver, Status.FAIL, "Unable to find Tire Program field", "", null);
        }
        
        if(driver.findElements(By.xpath("//td[text()='Loaner']")).size()>0)
        {
        	if(driver.findElements(By.xpath("//td[text()='Loaner']/../td/input[contains(@class,'ng-empty')]")).size()>0)
        	{
        		queryObjects.logStatus(driver, Status.PASS, "Tire Program field check box is Unchecked", "Successfully", null);
        	}
        	else {
        		queryObjects.logStatus(driver, Status.FAIL, "Tire Program field check box is checked", "", null);
        	}
        }
        else {
        	queryObjects.logStatus(driver, Status.FAIL, "Unable to find Tire Program field", "", null);
        }
        
        RC_Global.clickUsingXpath(driver, "//td[normalize-space(text())='Roadside']/../td/input[contains(@class,'ng-empty')]", "Roadside checkbox", false, false);       
        RC_Global.clickUsingXpath(driver, "//td[normalize-space(text())='Accident Management']/../td/input[contains(@class,'ng-empty')]", "Accident Management checkbox", false, false);
        
        RC_Manage.orderingProfilevalueselection(driver,"Programs", "insurance", "Merchants Insurance", false);
        RC_Global.clickUsingXpath(driver, "//Span[normalize-space(text())='Programs']", "Programs", false, true);
    	
        RC_Global.clickButton(driver, "Save and Activate", false, true);
        Thread.sleep(3000);
        
        List<WebElement> Gridrowcnt = driver.findElements(By.xpath("//div[contains(@class,'vehicle-order-profile-table' )]/../table/tbody/tr"));
		for (int i=1; i<=Gridrowcnt.size();i++) {
		String NewProfile = driver.findElement(By.xpath("//div[contains(@class,'vehicle-order-profile-table' )]/../table/tbody/tr["+i+"]/td[3]")).getText();		
		Thread.sleep(2000);
    		if(NewProfile.equals(ProfileName))
    		{
    			queryObjects.logStatus(driver, Status.PASS, "Newly added profile displays in grid->", NewProfile, null);
    			break;
    		}
		}
		
		//columns validation
		String ColumnNames ="Customer #;Customer Name;Profile Name;Profile Status;Created By;Created On;Last Modified By;Last Modified Date;Fleet #;Fleet Name;Account #;Account Name;Sub-Account #;Sub-Account Name;Available Actions";
		RC_Manage.orderingProfileColumnValidation(driver, ColumnNames, ProfileName, false);
		 Thread.sleep(1000);
		   executor.executeScript("document.body.style.zoom = '30%'");
		   Thread.sleep(2000);
		   executor.executeScript("document.body.style.zoom = '100%'");
		//validate hyperlinks 
		RC_Global.buttonStatusValidation(driver, "Edit", "Presence", false);
		RC_Global.buttonStatusValidation(driver, "Clone", "Presence", false);
		RC_Global.buttonStatusValidation(driver, "Deactivate", "Presence", false);
		
		RC_Global.panelAction(driver, "close", "Customer Administration", false, false);
		RC_Global.logout(driver, false);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}