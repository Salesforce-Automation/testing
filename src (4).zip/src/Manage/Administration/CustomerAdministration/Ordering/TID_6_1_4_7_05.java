package Manage.Administration.CustomerAdministration.Ordering;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_4_7_05 {
	public void MIP_ValidateHistoryAndDeactivateNewProgramAtTheCustomerLevel(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		
		JavascriptExecutor executor = (JavascriptExecutor) driver;int flag=0;String newPName="";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
		RC_Global.enterCustomerNumber(driver, "LS010143", "", "", false);
		RC_Global.clickUsingXpath(driver, "//a[text()='Ordering']", "Ordering", false, true);
		if(driver.findElements(By.xpath("//label[contains(text(),'Incentive Program') and contains(@class,'active')]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Manufacturers' Incentive Program tab is displayed and selected by default", "", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "Manufacturers' Incentive Program tab is not displayed or not selected by default", "", null);
		
		if(driver.findElements(By.xpath("//label[text()='Ordering Attributes']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Ordering Attributes tab is displayed", "", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "Ordering Attributes tab is not displayed", "", null);
			
		if(driver.findElements(By.xpath("//label[text()='Ordering Profiles']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Ordering Profiles tab is displayed", "", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "Ordering Profiles tab is not displayed", "", null);
			
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//*[text()='Documents'])[2]")));
		RC_Global.clickUsingXpath(driver, "(//span[text()='Created Date'])[1]", "'Created Date' Column", false, false);
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//*[text()='Documents'])[2]")));
		RC_Global.clickUsingXpath(driver, "(//span[text()='Created Date'])[1]", "'Created Date' Column", false, false);
		//newPName=driver.findElement(By.xpath("(//tbody)[3]/tr[1]/td[3]")).getText();
		newPName = TID_6_1_4_7_04.orderingPgm;
		if (!newPName.isEmpty()) {
			RC_Global.clickUsingXpath(driver, "(//tbody)[3]/tr[1]/td[3]", "Program Name", false, true);
			executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//*[text()='Program Details']")));
			RC_Global.createNode(driver, "Validate Program Details section");
			if(driver.findElements(By.xpath("//*[text()='Program Name*']/following-sibling::div/input")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Program Name* text field is displayed", "", null);
			}
			else
				queryObjects.logStatus(driver, Status.FAIL, "Program Name* text field is not displayed", "", null);
				
			if(driver.findElements(By.xpath("//*[text()='FIN/FAN Code']/following-sibling::div/input")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "FIN/FAN Code text field is displayed", "", null);
			}
			else
				queryObjects.logStatus(driver, Status.FAIL, "FIN/FAN Code text field is not displayed", "", null);
			
			if(driver.findElements(By.xpath("//*[text()='Processing Code']/following-sibling::div/input")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Processing Code text field is displayed", "", null);
			}
			else
				queryObjects.logStatus(driver, Status.FAIL, "Processing Code text field is not displayed", "", null);
				
			if(driver.findElements(By.xpath("//*[text()='Year*']/following-sibling::div/select")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Year* dropdown is displayed", "", null);
			}
			else
				queryObjects.logStatus(driver, Status.FAIL, "Year* dropdown is not displayed", "", null);
			
			if(driver.findElements(By.xpath("//*[text()='Make*']/following-sibling::div/select")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Make* dropdown is displayed", "", null);
			}
			else
				queryObjects.logStatus(driver, Status.FAIL, "Make* dropdown is displayed", "", null);
				
			if(driver.findElements(By.xpath("//*[text()='Initial Pricing*']/following-sibling::div/select")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Initial Pricing* dropdown is displayed", "", null);
			}
			else
				queryObjects.logStatus(driver, Status.FAIL, "Initial Pricing* dropdown is not displayed", "", null);
				
			if(driver.findElements(By.xpath("//button[text()='Define Tiers' and @disabled='disabled']")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Define Tiers button is displayed and is disabled", "", null);
			}
			else
				queryObjects.logStatus(driver, Status.FAIL, "Define Tiers button is not displayed or is not disabled", "", null);
				
			if(driver.findElements(By.xpath("//button[text()='Add Incentives' and @disabled='disabled']")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Add Incentives button is displayed and is disabled", "", null);
			}
			else
				queryObjects.logStatus(driver, Status.FAIL, "Add Incentives button is not displayed or is not disabled", "", null);
				
			if(driver.findElements(By.xpath("//button[text()='Manage Documents']")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Manage Documents button is displayed and is enabled", "", null);
			}
			else
				queryObjects.logStatus(driver, Status.FAIL, "Manage Documents button is not displayed and is not enabled", "", null);
				
			if(driver.findElements(By.xpath("//th[text()='Model']")).size()>0 && 
					driver.findElements(By.xpath("//th[text()='Trims selected']")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Model and Trims selected columns are displayed", "", null);
				if(driver.findElements(By.xpath("(//div[@class='table-body-wrapper table-responsive'])[2]/table/tbody/tr")).size()>0)
				{
					queryObjects.logStatus(driver, Status.PASS, "List of models and number of trims selected for the selected make are displayed in the grid", "", null);
				}
				else
					queryObjects.logStatus(driver, Status.FAIL, "List of models and number of trims selected for the selected make are not displayed in the grid", "", null);
					
			}
			else
				queryObjects.logStatus(driver, Status.FAIL, "Model and Trims selected columns are not displayed", "", null);
				
			if(driver.findElements(By.xpath("//th[text()=' Available Trims ']")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Available Trims column is displayed", "", null);
				if(driver.findElements(By.xpath("(//div[@class='table-body-wrapper table-responsive'])[3]/table/tbody")).size()==0)
				{
					queryObjects.logStatus(driver, Status.PASS, "Nothing is listed in the Available Trims column", "", null);
				}
				
			}
			else
				queryObjects.logStatus(driver, Status.FAIL, "Available Trims column is not displayed", "", null);
				
			executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//th[text()='Model']")));
			if(driver.findElements(By.xpath("//button[text()='Edit']")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Edit button is displayed and is enabled", "", null);
			}
			else
				queryObjects.logStatus(driver, Status.FAIL, "Edit button is displayed and is not enabled", "", null);
				
			if(driver.findElements(By.xpath("//button[text()='Clone']")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Clone button is displayed and is enabled", "", null);
			}
			else
				queryObjects.logStatus(driver, Status.FAIL, "Clone button is not displayed or is not enabled", "", null);
				
			if(driver.findElements(By.xpath("(//button[text()='Save' and @disabled='disabled'])[2]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Save button is displayed and is disabled", "", null);
			}
			else
				queryObjects.logStatus(driver, Status.FAIL, "Save button is not displayed or is not disabled", "", null);
				
			if(driver.findElements(By.xpath("(//button[text()='Cancel'])[1]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Cancel button is displayed and is enabled", "", null);
			}
			else
				queryObjects.logStatus(driver, Status.FAIL, "Cancel button is not displayed or is not enabled", "", null);
				
			executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//*[text()='Program Details']")));
			RC_Global.clickButton(driver, "Manage Documents", false, true);
			if(driver.findElements(By.xpath("//h2[text()=' Manage Documents ']")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "The 'Manage Documents' pop-up windown is displayed", "", null);
			}
			else
				queryObjects.logStatus(driver, Status.FAIL, "The 'Manage Documents' pop-up windown is not displayed", "", null);
			
			if(driver.findElements(By.xpath("(//div[@class='table-body-wrapper table-responsive'])[1]/table/tbody/tr")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "The grid lists the documents that was uploaded in the previous test", "", null);
			}
			else
				queryObjects.logStatus(driver, Status.FAIL, "The grid does not list the documents that was uploaded in the previous test", "", null);
				
			RC_Global.clickUsingXpath(driver, "(//button[text()='Cancel'])[1]", "Cancel", false, true);
			executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//label[text()=' History '])[5]")));
			RC_Global.clickUsingXpath(driver, "(//label[text()=' History '])[5]", "History", false, true);
			RC_Global.waitElementVisible(driver, 10, "//span[text()='Ordering Attributes History']", "Ordering Attributes History screen", false, true);
			RC_Global.waitElementVisible(driver, 15, "(//span[text()='Program Name'])[2]", "Manufacturers' Incentive Programs history displayed", false, true);
			if(driver.findElements(By.xpath("(//span[text()='Program Name'])[2]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Program Name column is displayed", "", null);
			}
			else
				queryObjects.logStatus(driver, Status.FAIL, "Program Name column is not displayed", "", null);
				
			if(driver.findElements(By.xpath("(//span[text()='Modified Date'])[1]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Modified Date column is displayed", "", null);
			}
			else
				queryObjects.logStatus(driver, Status.FAIL, "Modified Date column is not displayed", "", null);
				
			if(driver.findElements(By.xpath("(//span[text()='Modified By'])[1]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Modified By column is displayed", "", null);
			}
			else
				queryObjects.logStatus(driver, Status.FAIL, "Modified By column is not displayed", "", null);
			RC_Global.clickUsingXpath(driver, "((//div[@class='table-body-wrapper table-responsive'])[6]/table/tbody/tr/td)[4]", "Program Name", false, true);
			if(driver.findElements(By.xpath("//*[text()='Program Change']")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Program Change section is displayed", "", null);
			}
			else
				queryObjects.logStatus(driver, Status.FAIL, "Program Change section is not displayed", "", null);
				
			if(driver.findElements(By.xpath("//*[text()='Program Change']/following-sibling::table/thead/tr/th[text()='Changed Item']")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Changed Item column is displayed", "", null);
			}
			else
				queryObjects.logStatus(driver, Status.FAIL, "Changed Item column is not displayed", "", null);
			
			if(driver.findElements(By.xpath("//*[text()='Program Change']/following-sibling::table/thead/tr/th[text()='Old Value']")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Old Value column is displayed", "", null);
				for(int i=1;i<=driver.findElements(By.xpath("//*[text()='Program Change']/following-sibling::table/tbody/tr/td[2]")).size();i++)
				{
					if(!driver.findElement(By.xpath("(//*[text()='Program Change']/following-sibling::table/tbody/tr/td[2])["+i+"]")).getText().equals(""))
					{
						flag++;
						break;
					}
				}
				if(flag==0)
				{
					queryObjects.logStatus(driver, Status.PASS, "Old Value column is blank", "", null);
					if(driver.findElements(By.xpath("//*[text()='Program Change']/following-sibling::table/thead/tr/th[text()='New Value']")).size()>0)
					{
						queryObjects.logStatus(driver, Status.PASS, "New Value column is displayed", "", null);
						if(driver.findElement(By.xpath("//*[text()='Program Change']/following-sibling::table/tbody/tr[3]/td[3]")).getText().equals(newPName))
						{
							queryObjects.logStatus(driver, Status.PASS, "New program name is displayed in the New Value column", newPName, null);
						}
						else
						{
							queryObjects.logStatus(driver, Status.FAIL, "New program name is not displayed in the New Value column", "", null);
						}
					}
				}
				else
				{
					queryObjects.logStatus(driver, Status.FAIL, "Old Value column is not blank", "", null);
				}
			}
			
			RC_Global.panelAction(driver, "close", "Ordering Attributes History", false, true);
			executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//span[text()='Available Actions'])[1]")));
			RC_Global.clickUsingXpath(driver, "(//tbody)[3]/tr[1]/td[10]/button[2]", "Deactivate", false, true);
			Thread.sleep(2000);
			executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//*[text()='Documents'])[2]")));
			RC_Global.clickUsingXpath(driver, "(//span[text()='Created Date'])[1]", "'Created Date' Column", false, false);
			executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//*[text()='Documents'])[2]")));
			RC_Global.clickUsingXpath(driver, "(//span[text()='Created Date'])[1]", "'Created Date' Column", false, false);
			if(!driver.findElement(By.xpath("(//tbody)[3]/tr[1]/td[3]")).getText().equals(newPName))
			{
				queryObjects.logStatus(driver, Status.PASS, "This profile is no longer listed in the grid", "", null);
			}
			else
				queryObjects.logStatus(driver, Status.FAIL, "This profile is still listed in the grid", "", null);
			executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//span[text()='Customer Administration'])[2]")));
			RC_Global.panelAction(driver, "close", "Customer Administration", false, true);
		} else {
			queryObjects.logStatus(driver, Status.FAIL, "New Program creation is not successful", "Validation failed", null);
		}
		
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}

}
