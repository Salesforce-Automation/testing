package Manage.Administration.CustomerAdministration.Ordering;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import MF.Source.Cred;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_4_7_13 {
	public void OrderingProfile_ValidateReadWriteAccessCanCloneAnActiveProfile(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String currentDate = RC_Manage.AddDateStr(0, "MMM d, yyyy", "", null, "CST");
		String userName=Cred.UserName; int rowCount; JavascriptExecutor executor = (JavascriptExecutor) driver;
		int tabCount; int flag=0; String pName=""; String user="";
		
		RC_Global.login(driver);
		user=driver.findElement(By.xpath("(//div[@class='bottom-nav bottom-right-menu']/div/ul/li/a/span/span)[1]")).getText();
		RC_Global.navigateTo(driver, "Manage", "Utilities", "User Setup");
		RC_Global.waitElementVisible(driver, 60, "(//div[@class='table-body-wrapper table-responsive']/table/tbody)/tr[1]", "User grid is displayed", false, true);
		WebElement uNameField = driver.findElement(By.xpath("//*[@placeholder='Find User by Username']"));
		RC_Global.enterInput(driver, userName, uNameField, false, true);
		RC_Global.clickUsingXpath(driver, "(//div[@class='table-body-wrapper table-responsive']/table/tbody)/tr[1]/td[1]", userName, false, true);
		Thread.sleep(2000);
		RC_Global.waitElementVisible(driver, 60, "//button[text()='Advanced']", "User Details screen is displayed", false, true);
		RC_Global.clickButton(driver, "Advanced", false, true);
		RC_Global.waitElementVisible(driver, 60, "//h4[text()='Permissions Details']", "Permissions Details are displayed", false, true);
		RC_Global.scrollById(driver, "//span[text()=' Ordering ']");
		RC_Global.clickUsingXpath(driver, "//span[text()=' Ordering ']", "Ordering", false, true);
		RC_Global.clickUsingXpath(driver, "//span[text()=' Ordering Workflow ']", "Ordering Workflow", false, true);
		RC_Global.scrollById(driver, "//span[text()=' Ordering Profile Tab ']");
		Select dd=new Select(driver.findElement(By.xpath("//span[text()=' Ordering Profile Tab ']/../../../div/select")));
		RC_Global.createNode(driver, "Validate 'Ordering Profile' access");
		if(!dd.getFirstSelectedOption().getText().equals("Read / Write"))
		{
			dd.selectByVisibleText("Read / Write");
			if(dd.getFirstSelectedOption().getText().equals("Read / Write"))
			{
				queryObjects.logStatus(driver, Status.PASS, "'Ordering Profile' access is set to 'Read/Write'", "", null);
			}
			RC_Global.scrollById(driver, "//*[text()='Driver/Employee Assignment']");
			RC_Global.clickButton(driver, "Save", false, true);
			Thread.sleep(6000);
			RC_Global.login(driver);
		}
		else
		{
			queryObjects.logStatus(driver, Status.PASS, "'Ordering Profile' access is set to 'Read/Write'", "", null);
			RC_Global.scrollById(driver, "//*[text()='User Detail']");
			RC_Global.panelAction(driver, "close", "User Detail", false, true);
			RC_Global.panelAction(driver, "close", "User Setup", false, true);
		}
		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
		RC_Global.enterCustomerNumber(driver, "LS010143", "", "", false);
		RC_Global.createNode(driver, "Validate Customer Adminstration screen");
		if(driver.findElements(By.xpath("(//ul[@class='ng-scope'])[2]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Customer Structure Tree is displayed on left", "", null);
		}
		if(driver.findElement(By.xpath("//a[text()='Customer Summary']/..")).getAttribute("class").contains("active"))
		{
			queryObjects.logStatus(driver, Status.PASS, "Customer Summary tab is defaulted", "", null);
		}
		if(driver.findElements(By.xpath("//a[text()='Documents']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Documents tab is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//a[text()='Fuel']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Fuel tab is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//a[text()='Invoicing']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Invoicing tab is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//a[text()='Remarketing']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Remarketing tab is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//a[text()='Maintenance']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Maintenance tab is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//a[text()='Ordering']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Ordering tab is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//a[text()='Personal Use']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Personal Use tab is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//a[text()='Policies']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Policies tab is displayed", "", null);
		}
		
		RC_Global.clickUsingXpath(driver, "//a[text()='Ordering']", "Ordering", false, true);
		if(driver.findElements(By.xpath("//label[contains(text(),'Incentive Program') and contains(@class,'active')]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Manufacturers' Incentive Program button is displayed and selected by default", "", null);
		}
		if(driver.findElements(By.xpath("//label[text()='Ordering Attributes']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Ordering Attributes button is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//label[text()='Ordering Profiles']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Ordering Profiles button is displayed", "", null);
		}
		
		RC_Global.clickUsingXpath(driver, "//label[text()='Ordering Profiles']", "Ordering Profiles", false, true);
		if(driver.findElements(By.xpath("(//label[text()='Customer Name'])[7]/following-sibling::div")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Customer Name is displayed", driver.findElement(By.xpath("(//label[text()='Customer Name'])[7]/following-sibling::div")).getText(), null);
		}
		if(driver.findElements(By.xpath("(//label[text()='Customer Number'])[7]/following-sibling::div")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Customer Number is displayed", driver.findElement(By.xpath("(//label[text()='Customer Number'])[7]/following-sibling::div")).getText(), null);
		}
		if(driver.findElements(By.xpath("//label[text()='Profile Name']/following-sibling::input")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Profile Name search field is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//label[text()='Created By']/following-sibling::input")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Created By search field is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//label[text()='Modified By']/following-sibling::input")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Modified By search field is displayed", "", null);
		}
		Select pStatusdd=new Select(driver.findElement(By.xpath("//label[text()='Profile Status']/following-sibling::select")));
		if(pStatusdd.getFirstSelectedOption().getText().equals("Active"))
		{
			queryObjects.logStatus(driver, Status.PASS, "Profile Status dropdown is displayed(Active is default) ", "", null);
		}
		if(driver.findElements(By.xpath("//*[text()='Add New Profile']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Add New Profile button is displayed", "", null);
		}
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//span[text()='Customer #'])[2]")));
		rowCount=driver.findElements(By.xpath("(//div[@class='table-body-wrapper table-responsive']/table)[4]/tbody/tr")).size();
		RC_Global.createNode(driver, "Validate any of the 'Active' profiles listed");
		for(int i=1;i<=rowCount;i++)
		{
			if(driver.findElement(By.xpath("(//div[@class='table-body-wrapper table-responsive']/table)[4]/tbody/tr["+i+"]/td[4]")).getText().equals("Active"))
			{
				if(driver.findElements(By.xpath("(//div[@class='table-body-wrapper table-responsive']/table)[4]/tbody/tr["+i+"]/td[15]/button[text()=' Edit ']")).size()>0)
				{
					queryObjects.logStatus(driver, Status.PASS, "Edit hyperlink is displayed", "", null);
				}
				if(driver.findElements(By.xpath("(//div[@class='table-body-wrapper table-responsive']/table)[4]/tbody/tr["+i+"]/td[15]/button[text()=' Clone ']")).size()>0)
				{
					queryObjects.logStatus(driver, Status.PASS, "Clone hyperlink is displayed", "", null);
				}
				if(driver.findElements(By.xpath("(//div[@class='table-body-wrapper table-responsive']/table)[4]/tbody/tr["+i+"]/td[15]/button[text()=' Deactivate ']")).size()>0)
				{
					queryObjects.logStatus(driver, Status.PASS, "Deactivate hyperlink is displayed", "", null);
				}
				RC_Global.clickUsingXpath(driver, "(//div[@class='table-body-wrapper table-responsive']/table)[4]/tbody/tr["+i+"]/td[15]/button[text()=' Clone ']", "Clone", false, true);
				break;
			}
		}
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//*[text()=' Profile Details ']")));
		if(driver.findElements(By.xpath("//*[text()=' Profile Details ']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Profile Details section is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//*[text()=' How to Bill Order Related Fees ']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "How to Bill Order Related Fees section is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//*[text()=' Overhead and Risk ']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Overhead and Risk section is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//*[text()=' Capitalization Cost Calculation Formula ']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Capitalization Cost Calculation Formula section is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//*[text()=' Lease Terms and Fees ']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Lease Terms and Fees section is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//*[text()=' Fleet Account Numbers ']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Fleet Account Numbers section is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//*[text()=' Programs ']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Programs section is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//*[text()=' Comments ']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Comments section is displayed", "", null);
		}
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//*[text()='Collapse All']")));
		if(driver.findElements(By.xpath("//*[text()='Collapse All']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Collapse All button is displayed", "", null);
		}
		if(driver.findElements(By.xpath("(//*[@name='customerInput'])[3]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Customer # field is displayed within 'Profile Details' section", "", null);
		}
		
		RC_Global.clickUsingXpath(driver, "(//*[@name='customerInput'])[3]/../div/button", "Customer Structure icon", false, true);
		RC_Global.clickUsingXpath(driver, "(//ul[@class='ng-scope'])[4]/li[1]/div/span", "Fleet", false, true);
		queryObjects.logStatus(driver, Status.PASS, "Fleet # is displayed", driver.findElement(By.xpath("(//*[@name='customerInput'])[3]")).getText(), null);
		
		RC_Global.createNode(driver, "Validate the fields in each section");
		RC_Global.clickUsingXpath(driver, "//*[text()='Collapse All']", "Collapse All", false, false);
		
		for(int i=1;i<=8;i++)
		{
			if(driver.findElement(By.xpath("(//div[@role='tablist'][1]/tv-accordion-group/div/div/h4/a/span/div/span[1])["+i+"]/span[1]")).getAttribute("class").contains("hide"))
				{
					flag++;
					break;
				}
		}
		if(flag==0)
		{
			queryObjects.logStatus(driver, Status.PASS, "All required fields are populated", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "All required fields are not populated", "", null);
		}
		RC_Global.clickUsingXpath(driver, "(//button[text()='Expand All'])[1]", "Expand All", false, false);
		
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//*[text()='Save and Activate'])[1]")));
		RC_Global.clickUsingXpath(driver, "(//*[text()='Save and Activate'])[1]", "Save and Activate", false, true);
		Thread.sleep(2000);
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//*[text()='Collapse All']")));
		if(driver.findElements(By.xpath("//h4[contains(text(),'Please enter a unique name')]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "An error message is received because the Profile name cannot be the same: The name selected for this Ordering Profile is currently in use for this customer. Please enter a unique name to save.", "", null);
		}
		
		WebElement pNameField = driver.findElement(By.xpath("( //textarea[@name='profileName'])[1]"));
		pNameField.clear();
		pName="SampleTest"+RandomStringUtils.randomAlphanumeric(6);
		RC_Global.enterInput(driver, pName, pNameField, false, true);
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//*[text()='Save and Activate'])[1]")));
		RC_Global.clickUsingXpath(driver, "(//*[text()='Save and Activate'])[1]", "Save and Activate", false, true);
		Thread.sleep(5000);
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//span[text()='Customer #'])[2]")));
		rowCount=driver.findElements(By.xpath("(//div[@class='table-body-wrapper table-responsive']/table)[4]/tbody/tr")).size();
		for(int i=1;i<=rowCount;i++)
		{
			if(driver.findElement(By.xpath("(//div[@class='table-body-wrapper table-responsive']/table)[4]/tbody/tr["+i+"]/td[3]")).getText().equals(pName))
			{
				flag++;
				break;
			}
		}
		if(flag==0)
		{
			queryObjects.logStatus(driver, Status.PASS, "The new profile is not listed in the grid as it is created for a Fleet", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "The new profile is listed in the grid", "", null);
		}
		
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//label[text()=' Customer # '])[1]")));
		RC_Global.clickUsingXpath(driver, "((//ul[@class='ng-scope'])[2]/li/div/span)[1]", "Fleet", false, true);
		RC_Global.waitElementVisible(driver, 10, "((//div[@class='table-body-wrapper table-responsive']/table)[4]/tbody/tr/td)[1]", "Grid displayed", false, true);
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//span[text()='Customer #'])[2]")));
		Thread.sleep(3000);
		RC_Global.waitElementVisible(driver, 10, "//td[text()='"+pName+"']", "Grid loading", false, false);
		rowCount=driver.findElements(By.xpath("(//div[@class='table-body-wrapper table-responsive']/table)[4]/tbody/tr")).size();
		for(int i=1;i<=rowCount;i++)
		{
			if(driver.findElement(By.xpath("(//div[@class='table-body-wrapper table-responsive']/table)[4]/tbody/tr["+i+"]/td[3]")).getText().equals(pName))
			{
				queryObjects.logStatus(driver, Status.PASS, "The new profile is listed in the grid", "", null);
				if(driver.findElement(By.xpath("(//div[@class='table-body-wrapper table-responsive']/table)[4]/tbody/tr["+i+"]/td[5]")).getText().contains(user))
				{
					queryObjects.logStatus(driver, Status.PASS, "Created By displays the First and Lastname of user who cloned this profile", user, null);
				}
				if(driver.findElement(By.xpath("(//div[@class='table-body-wrapper table-responsive']/table)[4]/tbody/tr["+i+"]/td[7]")).getText().contains(user))
				{
					queryObjects.logStatus(driver, Status.PASS, "Last Modified By displays the First and Lastname of user who cloned this profile", user, null);
				}
				if(driver.findElement(By.xpath("(//div[@class='table-body-wrapper table-responsive']/table)[4]/tbody/tr["+i+"]/td[6]")).getText().contains(currentDate))
				{
					queryObjects.logStatus(driver, Status.PASS, "Created Date displays today's date for new profile",currentDate , null);
				}
				if(driver.findElement(By.xpath("(//div[@class='table-body-wrapper table-responsive']/table)[4]/tbody/tr["+i+"]/td[8]")).getText().contains(currentDate))
				{
					queryObjects.logStatus(driver, Status.PASS, "Last Modified Date displays today's date for new profile", currentDate, null);
				}
				break;
			}
		}
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//label[text()=' History '])[7]")));
		RC_Global.clickUsingXpath(driver, "(//label[text()=' History '])[7]", "History", false, true);
		RC_Global.waitElementVisible(driver, 10, "//span[text()='Ordering Attributes History']", "Ordering Attributes History screen opened", false, true);
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//*[text()='Ordering Profiles History']")));
		
		if(driver.findElements(By.xpath("//*[text()='Ordering Profiles History']/../div[2]/div[2]/div")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "A grid is displayed under 'Ordering Profiles History' section", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "A grid is not displayed under 'Ordering Profiles History' section", "", null);
		}
		Thread.sleep(2000);
		//RC_Global.clickUsingXpath(driver, "//span[text()='Profile Modified']", "Grid displayed", false, false);
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//span[text()='Profile Modified']")));
		if(driver.findElement(By.xpath("(//div[@class='table-header-wrapper'])[8]/table/thead/tr/th[1]/div/span[1]")).getText().contains("Profile Modified"))
		{
			queryObjects.logStatus(driver, Status.PASS, "Profile Modified column is displayed in the grid", "", null);
			if(driver.findElement(By.xpath("((//div[@class='table-body-wrapper table-responsive'])[8]/table/tbody/tr/td)[1]")).getText().contains(pName))
			{
				queryObjects.logStatus(driver, Status.PASS, "New Profile Name is displayed in the Profile Modified column", pName, null);
			}
			else
			{
				queryObjects.logStatus(driver, Status.FAIL, "New Profile Name is not displayed in the Profile Modified column", "", null);
			}
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Profile Modified column is not displayed in the grid", "", null);
		}
		
		if(driver.findElement(By.xpath("(//div[@class='table-header-wrapper'])[8]/table/thead/tr/th[2]/div/span[1]")).getText().contains("Event"))
		{
			queryObjects.logStatus(driver, Status.PASS, "Event column is displayed in the grid", "", null);
			if(driver.findElement(By.xpath("((//div[@class='table-body-wrapper table-responsive'])[8]/table/tbody/tr/td)[2]/p")).getText().contains("Ordering Profile Created"))
			{
				queryObjects.logStatus(driver, Status.PASS, "'Ordering Profile Created' is displayed in the Event column", "", null);
			}
			else
			{
				queryObjects.logStatus(driver, Status.FAIL, "'Ordering Profile Created' is not displayed in the Event column", "", null);
			}
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Event column is not displayed in the grid", "", null);
		}
		
		if(driver.findElement(By.xpath("(//div[@class='table-header-wrapper'])[8]/table/thead/tr/th[3]/div/span[1]")).getText().contains("Modified Date"))
		{
			queryObjects.logStatus(driver, Status.PASS, "Modified Date column is displayed in the grid", "", null);
			if(driver.findElement(By.xpath("((//div[@class='table-body-wrapper table-responsive'])[8]/table/tbody/tr/td)[3]")).getText().contains(currentDate))
			{
				queryObjects.logStatus(driver, Status.PASS, "Today's Date is displayed in the Modified Date column", currentDate, null);
			}
			else
			{
				queryObjects.logStatus(driver, Status.FAIL, "Today's Date is not displayed in the Modified Date column", "", null);
			}
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Modified Date column is not displayed in the grid", "", null);
		}
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//div[@class='table-header-wrapper'])[8]/table/thead/tr/th[4]/div/span[1]")));
		if(driver.findElement(By.xpath("(//div[@class='table-header-wrapper'])[8]/table/thead/tr/th[4]/div/span[1]")).getText().contains("Modified By"))
		{
			queryObjects.logStatus(driver, Status.PASS, "Modified By column is displayed in the grid", "", null);
			String modifyBy = driver.findElement(By.xpath("((//div[@class='table-body-wrapper table-responsive'])[8]/table/tbody/tr/td)[4]")).getText();
		String UmodifyBy = modifyBy.toUpperCase();
			if(UmodifyBy.contains(RC_Global.userLogged))
			{
				queryObjects.logStatus(driver, Status.PASS, "User's name is displayed in the Modified By column", user, null);
			}
			else
			{
				queryObjects.logStatus(driver, Status.FAIL, "User's name is not displayed in the Modified By column", "", null);
			}
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Modified By column is not displayed in the grid", "", null);
		}
		
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("((//div[@class='table-body-wrapper table-responsive'])[8]/table/tbody/tr/td)[1]")));
		RC_Global.clickUsingXpath(driver, "((//div[@class='table-body-wrapper table-responsive'])[8]/table/tbody/tr/td)[1]", "New Profile Name", false, true);
		
		if(driver.findElements(By.xpath("(//*[text()='Main Profile Changes'])[1]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Main Profile Changes' section is displayed", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "'Main Profile Changes' section is not displayed", "", null);
		}
		
		if(driver.findElements(By.xpath("(//*[text()='Main Profile Changes'])[1]/../table/thead/tr/th[text()='Changed Item']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Changed Item' column is displayed", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "'Changed Item' column is not displayed", "", null);
		}
		if(driver.findElements(By.xpath("(//*[text()='Main Profile Changes'])[1]/../table/thead/tr/th[text()='Old Value']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Old Value' column is displayed", "", null);
			rowCount=driver.findElements(By.xpath("(//*[text()='Main Profile Changes'])[1]/../table/tbody")).size();
			for(int i=1;i<=rowCount;i++)
			{
				if(!driver.findElement(By.xpath("(//*[text()='Main Profile Changes'])[1]/../table/tbody["+i+"]/tr/td[2]")).getText().equals(""))
				{
					flag=5;
					break;
				}
			}
			if(flag!=5)
			{
				queryObjects.logStatus(driver, Status.PASS, "'Old Value' column is blank", "", null);
			}
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "'Old Value' column is not displayed", "", null);
		}
		if(driver.findElements(By.xpath("(//*[text()='Main Profile Changes'])[1]/../table/thead/tr/th[text()='New Value']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'New Value' column is displayed", "", null);
			if(!driver.findElement(By.xpath("(//*[text()='Main Profile Changes'])[1]/../table/tbody[1]/tr/td[3]")).getText().equals(""))
			{
				queryObjects.logStatus(driver, Status.PASS, "'New Value' column displays the entered values", "", null);
			}
			else
			{
				queryObjects.logStatus(driver, Status.FAIL, "'New Value' column does not display the entered values", "", null);
			}
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "'New Value' column is not displayed", "", null);
		}
		
		RC_Global.clickUsingXpath(driver, "((//div[@class='table-body-wrapper table-responsive'])[8]/table/tbody/tr/td)[1]", "New Profile Name", false, true);

		if(driver.findElement(By.xpath("((//div[@class='table-body-wrapper table-responsive'])[8]/table/tbody/tr)[2]")).getAttribute("class").contains("ng-hide"))
		{
			queryObjects.logStatus(driver, Status.PASS, "The history detail for this entry is now collapsed", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "The history detail for this entry is not collapsed", "", null);
		}
		Thread.sleep(2000);
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//span[text()='Ordering Attributes History']")));
		
		RC_Global.panelAction(driver, "close", "Ordering Attributes History", false, true);
		RC_Global.panelAction(driver, "close", "Customer Administration", false, true);
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
