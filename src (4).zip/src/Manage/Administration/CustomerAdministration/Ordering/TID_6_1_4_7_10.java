package Manage.Administration.CustomerAdministration.Ordering;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_4_7_10 {
	public static void OrderingProfile_UnstructuredProfile_NewAndOptionalFields(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
		RC_Global.waitUntilPanelVisibility(driver, "Customer Administration", "TV", true, false);
		
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		RC_Global.waitElementVisible(driver, 30, "//a[text()='Maintenance']", "Maintenance Tab", true, false);
		RC_Global.clickUsingXpath(driver, "//a[text()='Maintenance']", "Maintenance Tab", true, true);
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Enrolled in Maintenance *']]", "Enrolled in Maintenance field", true, true);

		RC_Global.createNode(driver, "Customer Enrolled in Maintenance");
		if(driver.findElement(By.xpath("//div[label[text()='Enrolled in Maintenance *']]//button[contains(@class,'active')]")).getText().trim().equalsIgnoreCase("Yes")) {
			queryObjects.logStatus(driver, Status.INFO, "Verify Customer Enrolled in Maintenance", "Customer Enrolled in Maintenance",null);
			RC_Global.waitElementVisible(driver, 30, "//a[text()='Ordering']", "Ordering Tab", true, false);
			RC_Global.clickUsingXpath(driver, "//a[text()='Ordering']", "Ordering Tab", true, true);
			RC_Global.waitElementVisible(driver, 30, "//label[text()='Ordering Profiles']", "Ordering Profiles Tab", true, false);
			RC_Global.clickUsingXpath(driver, "//label[text()='Ordering Profiles']", "Ordering Profiles Tab", true, true);
			Thread.sleep(2000);
			
			RC_Global.clickButton(driver, "Add New Profile", true, true);
			RC_Global.clickUsingXpath(driver, "//div[span[span[normalize-space(text())='Profile Details']]]", "Profile Details section", true, true);
			
			WebElement profileName = driver.findElement(By.xpath("(//div[label[normalize-space(text())='Profile Name']]/textarea)[1]"));
			String inputProfile = "Sample Profile "+RandomStringUtils.randomAlphanumeric(2)+" "+RandomStringUtils.randomNumeric(3);
			
			RC_Global.enterInput(driver, inputProfile, profileName, true, true);
			
			RC_Global.clickUsingXpath(driver, "//div[label[normalize-space(text())='Order Type']]/select/option[text()='Factory Order']", "Factory Order selection", true, false);
			
			RC_Global.selectDropdownOption(driver, " Agreement Type ", "Closed End", true, true);
			RC_Global.selectDropdownOption(driver, " Pricing Determined By ", "Unstructured", true, true);
			
			Thread.sleep(2000);
			RC_Global.createNode(driver, "Validate Profile Details section");
			if(driver.findElements(By.xpath("//div[label[normalize-space(text())='Payment']]//currency-input//input")).size()>0)
				queryObjects.logStatus(driver, Status.PASS, "Verify Payment input box is displayed", "Payment input box is displayed",null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify Payment input box is displayed", "Payment input box is not displayed",null);
			
			if(driver.findElements(By.xpath("//div[label[normalize-space(text())='Closed End Residual']]//currency-input//input")).size()>0)
				queryObjects.logStatus(driver, Status.PASS, "Verify Closed End Residual input box is displayed", "Closed End Residual input box is displayed",null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify Closed End Residual input box is displayed", "Closed End Residual input box is not displayed",null);
			
			if(driver.findElement(By.xpath("//label[text()=' $ ']/input")).isSelected())//getAttribute("class").contains("ng-valid-parse"))
				queryObjects.logStatus(driver, Status.PASS, "Verify '$' is selected by default", "'$' is selected by default",null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify '$' is selected by default", "'$' is not selected by default",null);
			
			if(driver.findElement(By.xpath("//div[label[text()=' Unlimited Mileage ']]/select/option[@selected='selected']")).getText().trim().equalsIgnoreCase("No"))
				queryObjects.logStatus(driver, Status.PASS, "Verify 'No' is selected by default in Unlimited Mileage", "'No' is selected by default in Unlimited Mileage",null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify 'No' is selected by default in Unlimited Mileage", "'No' is not selected by default in Unlimited Mileage",null);
			
			if(driver.findElements(By.xpath("//div[label[text()=' Lease Mileage Allowance Per Term ']]/input")).size()>0)
				queryObjects.logStatus(driver, Status.PASS, "Verify 'Lease Mileage Allowance Per Term' input box is displayed", "'Lease Mileage Allowance Per Term' input box is displayed",null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify 'Lease Mileage Allowance Per Term' input box is displayed", "'Lease Mileage Allowance Per Term' input box is not displayed",null);
			
			if(driver.findElement(By.xpath("//div[label[text()=' Excess Mileage Fees ']]//input")).getText().trim().equalsIgnoreCase(""))
				queryObjects.logStatus(driver, Status.PASS, "Verify Excess Mileage Fees input box is empty", "Excess Mileage Fees input box is empty",null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify Excess Mileage Fees input box is empty", "Excess Mileage Fees input box is not empty",null);
			
			if(driver.findElement(By.xpath("//div[label[text()=' Under Mileage Credit ']]//input")).getText().trim().equalsIgnoreCase(""))
				queryObjects.logStatus(driver, Status.PASS, "Verify Under Mileage Credit input box is empty", "Under Mileage Credit input box is empty",null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify Under Mileage Credit input box is empty", "Under Mileage Credit input box is not empty",null);
			
			RC_Global.clickUsingXpath(driver, "(//div[label[normalize-space(text())='Interim Rent']])[1]/select", "Interim Rent", true, false);
			RC_Global.clickUsingXpath(driver, "(//div[label[normalize-space(text())='Interim Rent']])[1]/select/option[2]", "Interim Rent", true, false);
			
			RC_Global.clickUsingXpath(driver, "(//div[label[normalize-space(text())='Irregular Lease']])[1]/select", "Irregular Lease", true, false);
			RC_Global.clickUsingXpath(driver, "(//div[label[normalize-space(text())='Irregular Lease']])[1]/select/option[2]", "Irregular Lease", true, false);
			
			WebElement excessMileage = driver.findElement(By.xpath("//div[label[text()=' Excess Mileage Fees ']]//input"));
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Excess Mileage Fees ']]//input", "Excess Mileage Fees", true, true);
			
			if(driver.findElement(By.xpath("//div[label[text()=' Excess Mileage Fees ']]//input")).getAttribute("value").equalsIgnoreCase("0."))
				queryObjects.logStatus(driver, Status.PASS, "Verify Under Mileage Credit input box is '0.'", "Under Mileage Credit input box is '0.'",null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify Under Mileage Credit input box is '0.'", "Under Mileage Credit input box is not '0.'",null);
			
			RC_Global.enterInput(driver, "123", excessMileage, true, true);
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Under Mileage Credit ']]//input", "Under Mileage Credit", true, false);
			
			if(driver.findElement(By.xpath("//div[label[text()=' Excess Mileage Fees ']]//input")).getAttribute("value").equalsIgnoreCase("0.12"))
				queryObjects.logStatus(driver, Status.PASS, "Verify Excess Mileage Fees input box is '0.12'", "Excess Mileage Fees input box is '0.12'",null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify Excess Mileage Fees input box is '0.12'", "Excess Mileage Fees input box is not '0.12'",null);
			
			RC_Global.enterInput(driver, "-34", excessMileage, true, true);
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Under Mileage Credit ']]//input", "Under Mileage Credit", true, false);
			
			if(driver.findElement(By.xpath("//div[label[text()=' Excess Mileage Fees ']]//input")).getAttribute("value").equalsIgnoreCase("0.34"))
				queryObjects.logStatus(driver, Status.PASS, "Verify Excess Mileage Fees input box is '0.34'", "Excess Mileage Fees input box is '0.34'",null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify Excess Mileage Fees input box is '0.34'", "Excess Mileage Fees input box is not '0.34'",null);
			
			WebElement underMileage = driver.findElement(By.xpath("//div[label[text()=' Under Mileage Credit ']]//input"));
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Under Mileage Credit ']]//input", "Under Mileage Credit", true, true);
			
			if(driver.findElement(By.xpath("//div[label[text()=' Under Mileage Credit ']]//input")).getAttribute("value").equalsIgnoreCase("-0."))
				queryObjects.logStatus(driver, Status.PASS, "Verify Under Mileage Credit input box is '-0.'", "Under Mileage Credit input box is '-0.'",null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify Under Mileage Credit input box is '-0.'", "Under Mileage Credit input box is not '-0.'",null);
			
			RC_Global.enterInput(driver, "8", underMileage, true, true);
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Excess Mileage Fees ']]//input", "Excess Mileage Fees", true, false);
			
			if(driver.findElement(By.xpath("//div[label[text()=' Under Mileage Credit ']]//input")).getAttribute("value").equalsIgnoreCase("-0.80"))
				queryObjects.logStatus(driver, Status.PASS, "Verify Under Mileage Credit input box is '-0.80'", "Under Mileage Credit input box is '-0.80'",null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify Under Mileage Credit input box is '-0.80'", "Under Mileage Credit input box is not '-0.80'",null);
			
			RC_Global.enterInput(driver, "123", underMileage, true, true);
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Excess Mileage Fees ']]//input", "Under Mileage Credit", true, false);
			
			if(driver.findElement(By.xpath("//div[label[text()=' Under Mileage Credit ']]//input")).getAttribute("value").equalsIgnoreCase("-0.12"))
				queryObjects.logStatus(driver, Status.PASS, "Verify Under Mileage Credit input box is '-0.12'", "Under Mileage Credit input box is '-0.12'",null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify Under Mileage Credit input box is '-0.12'", "Excess Mileage Fees input box is not '-0.12'",null);
			
			RC_Global.clickUsingXpath(driver, "//div[span[span[normalize-space(text())='Profile Details']]]", "Profile Details section", true, false);
			
			RC_Global.createNode(driver, "Validate How to Bill Order Related Fees section");
			RC_Global.clickUsingXpath(driver, "//div[span[span[normalize-space(text())='How to Bill Order Related Fees']]]", "How to Bill Order Related Fees section", true, true);
			
			
			if(driver.findElements(By.xpath("//div[label[text()=' Is Tax Exempt? ']]/select")).size()>0)
				queryObjects.logStatus(driver, Status.PASS, "Verify Is Tax Exempt? dropdown selection is present", "Is Tax Exempt? dropdown selection is present",null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify Is Tax Exempt? dropdown selection is present", "Is Tax Exempt? dropdown selection is not present",null);
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Is Tax Exempt? ']]/select", "Is Tax Exempt selection", true, false);
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Is Tax Exempt? ']]/select/option[2]", "Is Tax Exempt selection", true, false);
			
			if(driver.findElements(By.xpath("//div[label[text()=' Upfront Sales Tax ']]/select")).size()>0)
				queryObjects.logStatus(driver, Status.PASS, "Verify Upfront Sales Tax dropdown selection is present", "Upfront Sales Tax dropdown selection is present",null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify Upfront Sales Tax dropdown selection is present", "Upfront Sales Tax dropdown selection is not present",null);
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Upfront Sales Tax ']]/select", "Upfront Sales Tax selection", true, false);
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Upfront Sales Tax ']]/select/option[2]", "Upfront Sales Tax selection", true, false);
			
			if(driver.findElements(By.xpath("//div[label[text()=' Transportation ']]/select")).size()>0)
				queryObjects.logStatus(driver, Status.PASS, "Verify Transportation dropdown selection is present", "Transportation dropdown selection is present",null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify Transportation dropdown selection is present", "Transportation dropdown selection is not present",null);
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Transportation ']]/select", "Transportation selection", true, false);
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Transportation ']]/select/option[2]", "Transportation selection", true, false);
			
			if(driver.findElements(By.xpath("//div[label[text()=' Dealer Doc Fees ']]/select")).size()>0)
				queryObjects.logStatus(driver, Status.PASS, "Verify Dealer Doc Fees dropdown selection is present", "Dealer Doc Fees dropdown selection is present",null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify Dealer Doc Fees dropdown selection is present", "Dealer Doc Fees dropdown selection is not present",null);
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Dealer Doc Fees ']]/select", "Dealer Doc Fees selection", true, false);
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Dealer Doc Fees ']]/select/option[2]", "Dealer Doc Fees selection", true, false);
			
			if(driver.findElements(By.xpath("//div[label[text()=' Initial Registration ']]/select")).size()>0)
				queryObjects.logStatus(driver, Status.PASS, "Verify Initial Registration dropdown selection is present", "Initial Registration dropdown selection is present",null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify Initial Registration dropdown selection is present", "Initial Registration dropdown selection is not present",null);
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Initial Registration ']]/select", "Initial Registration selection", true, false);
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Initial Registration ']]/select/option[2]", "Initial Registration selection", true, false);
			
			if(driver.findElements(By.xpath("//div[label[text()=' Upfit(s) ']]/select")).size()>0)
				queryObjects.logStatus(driver, Status.PASS, "Verify Upfit(s) dropdown selection is present", "Upfit(s) dropdown selection is present",null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify Upfit(s) dropdown selection is present", "Upfit(s) dropdown selection is not present",null);
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Upfit(s) ']]/select", "Upfit(s) selection", true, false);
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Upfit(s) ']]/select/option[2]", "Upfit(s) selection", true, false);
			
			if(driver.findElements(By.xpath("//div[label[text()=' Courtesy Delivery Fees ']]/select")).size()>0)
				queryObjects.logStatus(driver, Status.PASS, "Verify Courtesy Delivery Fees dropdown selection is present", "Courtesy Delivery Fees dropdown selection is present",null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify Courtesy Delivery Fees dropdown selection is present", "Courtesy Delivery Fees dropdown selection is not present",null);
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Courtesy Delivery Fees ']]/select/option[1]", "Courtesy Delivery Fees selection", true, false);
			
			RC_Global.clickUsingXpath(driver, "//div[span[span[normalize-space(text())='How to Bill Order Related Fees']]]", "How to Bill Order Related Fees section", true, false);
			
			RC_Global.createNode(driver, "Validate Overhead and Risk section");
			RC_Global.clickUsingXpath(driver, "//div[span[span[normalize-space(text())='Overhead and Risk']]]", "Overhead and Risk section", true, true);
			
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Overhead Risk ']]/select", "Overhead Risk selection", true, false);
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Overhead Risk ']]/select/option[2]", "Overhead Risk selection", true, false);
			
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Overhead How to Bill ']]/select", "Overhead How to Bill selection", true, false);
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Overhead How to Bill ']]/select/option[2]", "Overhead How to Bill selection", true, false);
			
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Insurance Risk ']]/select", "Insurance Risk selection", true, false);
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Insurance Risk ']]/select/option[2]", "Insurance Risk selection", true, false);
			
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Maintenance Risk ']]/select", "Maintenance Risk selection", true, false);
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Maintenance Risk ']]/select/option[2]", "Maintenance Risk selection", true, true);
			
			RC_Global.clickUsingXpath(driver, "//div[span[span[normalize-space(text())='Overhead and Risk']]]", "Overhead and Risk section", true, false);
			
			RC_Global.createNode(driver, "Validate Lease Terms and Fees section");
			RC_Global.clickUsingXpath(driver, "//div[span[span[normalize-space(text())='Lease Terms and Fees']]]", "Lease Terms and Fees section", true, true);
				
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Minimum Lease Term (Months) ' and span[text()='*']]]/select", "Minimum Lease Term selection", true, false);
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Minimum Lease Term (Months) ' and span[text()='*']]]/select/option[2]", "Minimum Lease Term selection", true, false);
			
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Amortization Type ' and span[text()='*']]]/select", "Minimum Lease Term selection", true, false);
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Amortization Type ' and span[text()='*']]]/select/option[2]", "Minimum Lease Term selection", true, false);
			
			RC_Global.clickUsingXpath(driver, "//div[span[span[normalize-space(text())='Lease Terms and Fees']]]", "Lease Terms and Fees section", true, false);
			
			RC_Global.createNode(driver, "Validate Fleet Account Numbers section");
			RC_Global.clickUsingXpath(driver, "//div[span[span[normalize-space(text())='Fleet Account Numbers']]]", "Fleet Account Numbers section", true, true);
			
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Incentive Instructions ' and span[text()='*']]]/select", "Incentive Instructions selection", true, false);
			RC_Global.clickUsingXpath(driver, "//div[label[text()=' Incentive Instructions ' and span[text()='*']]]/select/option[2]", "Incentive Instructions selection", true, false);
		
			RC_Global.clickUsingXpath(driver, "//div[span[span[normalize-space(text())='Fleet Account Numbers']]]", "Fleet Account Numbers section", true, false);
		
			RC_Global.createNode(driver, "Validate Programs section");
			RC_Global.clickUsingXpath(driver, "//div[span[span[normalize-space(text())='Programs']]]", "Programs section", true, true);
			
			if(driver.findElement(By.xpath("//tr[td[text()='Maintenance Management']]/td/input")).isSelected())
				queryObjects.logStatus(driver, Status.PASS, "Validate 'Maintenance Management' is checked", "'Maintenance Management' is checked", null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Validate 'Maintenance Management' is checked", "'Maintenance Management' is not checked", null);
			
			if(driver.findElement(By.xpath("//tr[td[text()=' Maintenance Brochure ']]/td/input")).isSelected())
				queryObjects.logStatus(driver, Status.PASS, "Validate 'Maintenance Brochure' is checked", "'Maintenance Brochure' is checked", null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Validate 'Maintenance Brochure' is checked", "'Maintenance Brochure' is not checked", null);
			
			if(driver.findElement(By.xpath("//tr[td[text()='Fuel Management']]/td/input")).isSelected())
				queryObjects.logStatus(driver, Status.PASS, "Validate 'Fuel Management' is checked", "'Fuel Management' is checked", null);
			else {
				RC_Global.clickUsingXpath(driver, "//a[text()='Fuel']", "Fuel", true, false);
				RC_Global.waitElementVisible(driver, 30, "//label[text()='Enrolled in Fuel']", "Enrolled in Fuel toggle", false, false);
				if(driver.findElement(By.xpath("//div[label[text()='Enrolled in Fuel']]//button[contains(@class,'active')]")).getText().equalsIgnoreCase("Yes"))
					queryObjects.logStatus(driver, Status.FAIL, "Validate 'Fuel Management' is checked", "'Fuel Management' is not checked", null);
				else if(driver.findElement(By.xpath("//div[label[text()='Enrolled in Fuel']]//button[contains(@class,'active')]")).getText().equalsIgnoreCase("No"))
					queryObjects.logStatus(driver, Status.INFO, "Validate 'Fuel Management' is checked", "'Fuel Management' is not checked as Customer not Enrolled in Fuel", null);
				
				RC_Global.clickUsingXpath(driver, "//a[text()='Maintenance']", "Maintenance Tab", true, true);
				RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Enrolled in Maintenance *']]", "Enrolled in Maintenance field", true, true);
				RC_Global.waitElementVisible(driver, 30, "//a[text()='Ordering']", "Ordering Tab", true, false);
				RC_Global.clickUsingXpath(driver, "//a[text()='Ordering']", "Ordering Tab", true, true);
				RC_Global.waitElementVisible(driver, 30, "//label[text()='Ordering Profiles']", "Ordering Profiles Tab", true, false);
				RC_Global.clickUsingXpath(driver, "//label[text()='Ordering Profiles']", "Ordering Profiles Tab", true, true);
				Thread.sleep(2000);
				
			}
			
			if(driver.findElement(By.xpath("//tr[td[text()='Personal Use Reporting']]/td/input")).isSelected())
				queryObjects.logStatus(driver, Status.PASS, "Validate 'Personal Use Reporting' is checked", "'Personal Use Reporting' is checked", null);
			else {
				RC_Global.clickUsingXpath(driver, "//a[text()='Personal Use']", "Personal Use", true, false);
				RC_Global.waitElementVisible(driver, 30, "//fieldset[label[text()='Enrolled In Personal Use *']]//button[contains(@class,'active')]", "Enrolled in Fuel toggle", false, false);
				if(driver.findElement(By.xpath("//fieldset[label[text()='Enrolled In Personal Use *']]//button[contains(@class,'active')]")).getText().equalsIgnoreCase("Yes"))
					queryObjects.logStatus(driver, Status.FAIL, "Validate 'Personal Use Reporting' is checked", "'Personal Use Reporting' is not checked", null);
				else if(driver.findElement(By.xpath("//fieldset[label[text()='Enrolled In Personal Use *']]//button[contains(@class,'active')]")).getText().equalsIgnoreCase("No"))
					queryObjects.logStatus(driver, Status.INFO, "Validate 'Personal Use Reporting' is checked", "'Personal Use Reporting' is not checked as Customer not Enrolled in Fuel", null);
				
				RC_Global.clickUsingXpath(driver, "//a[text()='Maintenance']", "Maintenance Tab", true, true);
				RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Enrolled in Maintenance *']]", "Enrolled in Maintenance field", true, true);
				RC_Global.waitElementVisible(driver, 30, "//a[text()='Ordering']", "Ordering Tab", true, false);
				RC_Global.clickUsingXpath(driver, "//a[text()='Ordering']", "Ordering Tab", true, true);
				RC_Global.waitElementVisible(driver, 30, "//label[text()='Ordering Profiles']", "Ordering Profiles Tab", true, false);
				RC_Global.clickUsingXpath(driver, "//label[text()='Ordering Profiles']", "Ordering Profiles Tab", true, true);
				Thread.sleep(2000);
				
			}
			
			List<WebElement> maintenanceProg = driver.findElements(By.xpath("//div[label[text()=' Maintenance Program ']]/select/option[@label]"));
			String[] verifyMaintProg = {"Full", "Administered", "Reserve"};
			int iter=0;
			
			for(WebElement mp:maintenanceProg) {
				if(mp.getText().equalsIgnoreCase(verifyMaintProg[iter]))
					queryObjects.logStatus(driver, Status.PASS, "Verify "+verifyMaintProg[iter++]+" is present in the Dropdown option", "Option verification successful", null);
				else
					queryObjects.logStatus(driver, Status.FAIL, "Verify "+verifyMaintProg[iter++]+" is present in the Dropdown option", "Option verification not successful", null);
				
			}
			
			RC_Global.selectDropdownOption(driver, " Maintenance Program ", "Full", true, false);
			
			if(!driver.findElement(By.xpath("//tr[td[text()='Full Maintenance Mileage Unlimited']]/td/input")).isSelected())
				queryObjects.logStatus(driver, Status.PASS, "Verify 'Maintenance Mileage Unlimited' is not checked", "'Maintenance Mileage Unlimited' is not checked", null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify 'Maintenance Mileage Unlimited' is not checked", "'Maintenance Mileage Unlimited' is checked", null);
			
			if(driver.findElements(By.xpath("//div[label[text()=' Full Maintenance Mileage Allowance per Term ']]/input")).size()>0)
				queryObjects.logStatus(driver, Status.PASS, "Verify 'Maintenance Mileage Allowance per Term' is available", "'Maintenance Mileage Allowance per Term' is available", null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify 'Maintenance Mileage Allowance per Term' is available", "'Maintenance Mileage Allowance per Term' is not available", null);
			
			if(driver.findElement(By.xpath("//div[label[text()=' Full Maintenance Settlement ']]/select/option[@selected]")).getText().equalsIgnoreCase("Convert to Admin"))
				queryObjects.logStatus(driver, Status.PASS, "Verify 'Convert to Admin' is the default selection", "'Convert to Admin' is the default selection", null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify 'Convert to Admin' is the default selection", "'Convert to Admin' is not the default selection", null);
			
			WebElement fullMaintenanceMileage =driver.findElement(By.xpath("//div[label[text()=' Full Maintenance Mileage Allowance per Term ']]/input"));
			RC_Global.enterInput(driver, "88", fullMaintenanceMileage, true, true);
			
			List<WebElement> listFMS = driver.findElements(By.xpath("//div[label[text()=' Full Maintenance Settlement ']]/select/option[@label]"));
			String[] verifyLFMS = {"Convert to Admin", "Cost per Mile"};
			iter=0; 
			
			for(WebElement li:listFMS) {
				if(li.getText().equalsIgnoreCase(verifyLFMS[iter]))
					queryObjects.logStatus(driver, Status.PASS, "Verify "+verifyLFMS[iter++]+" is present in the Dropdown option", "Option verification successful", null);
				else
					queryObjects.logStatus(driver, Status.FAIL, "Verify "+verifyLFMS[iter++]+" is present in the Dropdown option", "Option verification not successful", null);
			}
			
			RC_Global.selectDropdownOption(driver, " Full Maintenance Settlement ", "Cost per Mile", true, false);
			
			WebElement costPerMile =driver.findElement(By.xpath("//div[label[text()=' Cost Per Mile ']]//input"));
			RC_Global.enterInput(driver, "14", costPerMile, true, true);
			
			RC_Global.selectDropdownOption(driver, " Insurance ", "Merchants Insurance", true, false);
			
			RC_Global.clickUsingXpath(driver, "(//button[text()= 'Save and Activate'])[1]", "Save and Activate button", true, true);
			
			RC_Global.createNode(driver, "Verify created New Profile");
			RC_Global.waitElementVisible(driver, 30, "//div[label[text()= 'Profile Name']]/input", "Profile Name", true, false);
			
			WebElement proName = driver.findElement(By.xpath("//div[label[text()= 'Profile Name']]/input"));
			RC_Global.enterInput(driver, inputProfile, proName, true, false);
			try {
				RC_Global.waitElementVisible(driver, 30, "//tr/td[text()= '"+inputProfile+"']", "Profile Name", true, false);
				queryObjects.logStatus(driver, Status.PASS, "Validate new Profile is created", "New Profile is created", null);
			}
			catch(Exception e) {
				queryObjects.logStatus(driver, Status.FAIL, "Validate new Profile is created", "New Profile is not created", null);
			}
			String ColumnNames = "Customer #;Customer Name;Profile Name;Profile Status;Created By;Created On;Last Modified By;Last Modified Date;Fleet #;Fleet Name;Account #;Account Name;Sub-Account #;Sub-Account Name";
			String [] expColName = ColumnNames.split(";");

			for(int i=0; i<expColName.length; i++) {
				try {
					driver.findElement(By.xpath("(//form[button[text()='Add New Profile']]/following-sibling::div)[1]//th/div/span[text()='"+expColName[i]+"']"));				
					queryObjects.logStatus(driver, Status.INFO, "Validate Report Column Names--->Column: " + expColName[i] , "--->Was Found", null);
				}
				catch(Exception e) {
					queryObjects.logStatus(driver, Status.FAIL, "Validate Report Column Names--->Column: " + expColName[i] + "--->Was NOT Found", e.getLocalizedMessage(), e);
				}
			}
			
			if(driver.findElement(By.xpath("//tr[td[text()= '"+inputProfile+"']]/td[4]")).getText().equalsIgnoreCase("Active"))
				queryObjects.logStatus(driver, Status.PASS, "Verify Profile Status is Active", "Profile Status is Active", null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify Profile Status is Active", "Profile Status is not Active", null);
			
			String username = driver.findElement(By.xpath("//span[span[@id= 'user-menu-name']]/span[1]")).getText();
			if(driver.findElement(By.xpath("//tr[td[text()= '"+inputProfile+"']]/td[5]")).getText().equalsIgnoreCase(username))
				queryObjects.logStatus(driver, Status.PASS, "Verify Created By is current user", "Created By is "+username, null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify Created By is current user", "Created By is not "+username, null);
			
			String todaysDate = RC_Global.getDateTime(driver, "MMM dd, yyyy", 0, true);
			String todaysDay = todaysDate.split(" ")[1].split("")[0];
			if(todaysDay.equalsIgnoreCase("0"))
				todaysDate = RC_Global.getDateTime(driver, "MMM d, yyyy", 0, true);
			
			if(driver.findElement(By.xpath("//tr[td[text()= '"+inputProfile+"']]/td[6]")).getText().contains(todaysDate))
				queryObjects.logStatus(driver, Status.PASS, "Verify Created Date is current date", "Created Date is "+todaysDate, null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify Created Date is current date", "Created Date is not "+todaysDate, null);
			
			if(driver.findElement(By.xpath("//tr[td[text()= '"+inputProfile+"']]/td[7]")).getText().equalsIgnoreCase(username))
				queryObjects.logStatus(driver, Status.PASS, "Verify Created By is current user", "Created By is "+username, null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify Created By is current user", "Created By is not "+username, null);
		
			if(driver.findElement(By.xpath("//tr[td[text()= '"+inputProfile+"']]/td[8]")).getText().contains(todaysDate))
				queryObjects.logStatus(driver, Status.PASS, "Verify Created Date is current date", "Created Date is "+todaysDate, null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify Created Date is current date", "Created Date is not "+todaysDate, null);
			
			if(driver.findElements(By.xpath("//tr[td[text()= '"+inputProfile+"']]/td/button[text()=' Edit ']")).size()>0)
				queryObjects.logStatus(driver, Status.PASS, "Verify Edit link is available", "Edit link is available", null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify Edit link is available", "Edit link is not available", null);
			
			if(driver.findElements(By.xpath("//tr[td[text()= '"+inputProfile+"']]/td/button[text()=' Deactivate ']")).size()>0)
				queryObjects.logStatus(driver, Status.PASS, "Verify Deactivate link is available", "Deactivate link is available", null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify Deactivate link is available", "Deactivate link is not available", null);
			
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Customer Enrolled in Maintenance", "Please use Customer Number enrolled in Maintenance",null);
		
		RC_Global.logout(driver, true);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	
	}
}
