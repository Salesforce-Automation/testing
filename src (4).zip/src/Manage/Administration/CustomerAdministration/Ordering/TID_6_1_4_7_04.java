package Manage.Administration.CustomerAdministration.Ordering;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_4_7_04 {
	public static String orderingPgm = "";
	public void MIP_AddNewProgramAtTheCustomerLevel(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String columnNames="Customer #;Customer Name;Program Name;Status;Year;Make;Initial Pricing;Created Date;Documents;Available Actions;Fleet #;Fleet Name;Account #;Account Name;Sub-Account #;Sub-Account Name";
		String year="";String make=""; String pName="Deb & Program";JavascriptExecutor executor = (JavascriptExecutor) driver;
		String Fin_Fan="";String Processing_Code="";String tSelected="";String tSelectedOf="";
		String mDocColumns="Customer #;Customer Name;Year;Make;Document Name;Fleet #;Fleet Name;Account #;Account Name;Sub-Account #;Sub-Account Name";
		String uploadFileName="Sample_Document.xlsx";
		String uploadFilePath= String.valueOf(String.valueOf(String.valueOf(System.getProperty("user.dir")))) + File.separator + "DocumentUpload" + File.separator + uploadFileName;

		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
		RC_Global.enterCustomerNumber(driver, "LS010143", "", "", false);
		RC_Global.clickUsingXpath(driver, "//a[text()='Ordering']", "Ordering", false, true);
		if(driver.findElements(By.xpath("//label[contains(text(),'Incentive Program')]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Manufacturers' Incentive Program tab is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//label[text()='Ordering Attributes']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Ordering Attributes tab is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//label[text()='Ordering Profiles']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Ordering Profiles tab is displayed", "", null);
		}
		RC_Global.createNode(driver, "Validate the 'Manufacturers' Incentive Program' screen");
		if(driver.findElements(By.xpath("(//label[text()='Customer Name'])[7]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Customer Name is displayed", "", null);
		}
		if(driver.findElements(By.xpath("(//label[text()='Fleet Name'])[7]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Fleet Name is displayed", "", null);
		}
		if(driver.findElements(By.xpath("(//label[text()='Account Name'])[7]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Account Name is displayed", "", null);
		}
		if(driver.findElements(By.xpath("(//label[text()='Sub Account Name'])[7]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Sub Account Name is displayed", "", null);
		}
		if(driver.findElements(By.xpath("(//label[text()='Customer Number'])[7]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Customer Number is displayed", "", null);
		}
		if(driver.findElements(By.xpath("(//label[text()='Fleet Number'])[7]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Fleet Number is displayed", "", null);
		}
		if(driver.findElements(By.xpath("(//label[text()='Account Number'])[8]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Account Number is displayed", "", null);
		}
		if(driver.findElements(By.xpath("(//label[text()='Sub Account Number'])[8]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Sub Account Number is displayed", "", null);
		}
		if(driver.findElements(By.xpath("(//*[text()='Last Updated By'])[7]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Last Updated By is displayed in gray shading", "", null);
		}
		if(driver.findElements(By.xpath("(//*[text()='Last Updated Date'])[7]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Last Updated Date is displayed in gray shading", "", null);
		}
		if(driver.findElements(By.xpath("(//*[text()='Customer Since'])[7]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Customer Since is displayed in gray shading", "", null);
		}
		if(driver.findElements(By.xpath("(//label[text()=' History '])[5]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "History hyperlink is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//*[text()='Create New']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Create New button is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//*[text()=' Show Inactive ']/input[@type='checkbox']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Show Inactive checkbox is displayed", "", null);
		}
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//*[text()='Customer #'])[1]")));
		if(driver.findElements(By.xpath("(//div[@class='table-wrapper'])[1]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Grid of programs listed is displayed", "", null);
		}

		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//img)[2]")));
		if(driver.findElements(By.xpath("(//img)[2]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Excel Reoprt is displayed", "", null);
		}
		if(driver.findElements(By.xpath("(//a[text()='1'])[1]")).size()>0 || driver.findElements(By.xpath("(//a[text()='2'])[1]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Navigation buttons are displayed", "", null);
		}
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//*[text()='Customer #'])[1]")));
		RC_Global.createNode(driver, "Validate Column Names");
		String [] expColName = columnNames.split(";");

		for(int i=0; i<expColName.length; i++) {
			try {
				driver.findElement(By.xpath("(//div[@class='table-header-wrapper'])[1]/table/thead/tr/th/div/span[text()='"+expColName[i]+"']"));
				queryObjects.logStatus(driver, Status.INFO, "Validate Report Column Names--->Column: " + expColName[i] + "--->Was Found", "", null);
			}
			catch(Exception e) {
				queryObjects.logStatus(driver, Status.FAIL, "Validate Report Column Names--->Column: " + expColName[i] + "--->Was NOT Found", e.getLocalizedMessage(), e);
			}
		}


		RC_Global.clickButton(driver, "Create New", false, true);
		Thread.sleep(2000);
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//*[text()='Program Details']")));
		RC_Global.createNode(driver, "Validate the 'Program Details' section");
		if(driver.findElements(By.xpath("//*[text()='Program Name*']/following-sibling::div/input")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Program Name* text field is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//*[text()='FIN/FAN Code']/following-sibling::div/input")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "FIN/FAN Code text field is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//*[text()='Processing Code']/following-sibling::div/input")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Processing Code text field is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//*[text()='Year*']/following-sibling::div/select")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Year* dropdown is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//*[text()='Make*']/following-sibling::div/select")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Make* dropdown is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//*[text()='Initial Pricing*']/following-sibling::div/select")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Initial Pricing* dropdown is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//button[text()='Define Tiers']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Define Tiers button is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//button[text()='Add Incentives']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Add Incentives button is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//button[text()='Manage Documents']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Manage Documents button is displayed", "", null);
		}
		if(driver.findElements(By.xpath("(//div[@class='table-header-wrapper'])[2]/table/thead")).size()>0 && driver.findElements(By.xpath("(//div[@class='table-header-wrapper'])[3]/table/thead")).size()>0)
		{
			if(driver.findElements(By.xpath("//th[text()='Model']")).size()>0 && driver.findElements(By.xpath("//th[text()='Trims selected']")).size()>0 && 
					driver.findElements(By.xpath("//th[text()=' Available Trims ']")).size()>0)
				queryObjects.logStatus(driver, Status.PASS, "An empty grid displayed is displayed with column names Model, Trims selected & Available Trims", "", null);
		}
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//th[text()='Model']")));
		if(driver.findElement(By.xpath("//button[text()='Edit']")).getAttribute("disabled").equals("true"))
		{
			queryObjects.logStatus(driver, Status.PASS, "Edit button is disabled", "", null);
		}
		if(driver.findElement(By.xpath("//button[text()='Clone']")).getAttribute("disabled").equals("true"))
		{
			queryObjects.logStatus(driver, Status.PASS, "Clone button is disabled", "", null);
		}
		if(driver.findElements(By.xpath("(//button[text()='Save'])[3]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Save button is enabled", "", null);
		}
		if(driver.findElements(By.xpath("(//button[text()='Cancel'])[1]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Cancel button is enabled", "", null);
		}
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//button[text()='Define Tiers']")));
		RC_Global.clickButton(driver, "Define Tiers", false, true);
		if(driver.findElements(By.xpath("(//div[@ng-repeat='tier in tiers'])/h4")).size()==5)
		{
			queryObjects.logStatus(driver, Status.PASS, "There are five columns are displayed from Tier1 to Tier5", "", null);
		}
		if(driver.findElements(By.xpath("(//div[@class='row'])[2]/div/h4[text()='Min. Quantity']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Min Quantity with Tier 1 through Tier 5", "", null);	
		}
		if(driver.findElements(By.xpath("(//div[@class='row'])[3]/div/h4[text()='Max. Quantity']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Max Quantity with Tier 1 through Tier 5", "", null);	
		}
		if(driver.findElements(By.xpath("//button[text()='Apply']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Apply button is enabled", "", null);
		}
		if(driver.findElements(By.xpath("(//button[text()='Cancel'])[1]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Cancel button is enabled", "", null);
		}
		RC_Global.clickUsingXpath(driver, "(//button[text()='Cancel'])[1]", "Cancel", false, true);
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//*[text()='Customer #'])[1]")));
		year=driver.findElement(By.xpath("(//tbody)[3]/tr[1]/td[5]")).getText();
		make=driver.findElement(By.xpath("(//tbody)[3]/tr[1]/td[6]")).getText();
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//*[text()='Program Details']")));
		WebElement pNameField = driver.findElement(By.xpath("//input[@name='ProgramName']"));
		WebElement FinField = driver.findElement(By.xpath("//input[@name='FinFanCode']"));
		WebElement pCodeField = driver.findElement(By.xpath("//input[@name='SalesProcessingCode']"));
		RC_Global.enterInput(driver, pName, pNameField, false, true);
		RC_Global.selectDropdownOption(driver, "selectYear", year, false, true);
		RC_Global.selectDropdownOption(driver, "selectMake", make, false, true);
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//button[text()='Save'])[3]")));
		RC_Global.clickUsingXpath(driver, "(//button[text()='Save'])[3]", "Save", false, true);
		Thread.sleep(1000);
		if(driver.findElements(By.xpath("//*[text()='Program already exists.']")).size()>0 && driver.findElements(By.xpath("//*[text()='Program failed to save.']")).size()>0)
		{
			executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//*[text()='Program already exists.']")));
			queryObjects.logStatus(driver, Status.PASS, "'Program already exists.' error message is displayed", "", null);
			executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//*[text()='Program failed to save.']")));
			queryObjects.logStatus(driver, Status.PASS, "'Program failed to save.' error message is displayed", "", null);
		}
		executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//*[text()='Program Details']")));
		pName="SampleTest_"+RandomStringUtils.randomAlphabetic(8).toLowerCase();
		RC_Global.enterInput(driver, pName, pNameField, false, true);
		RC_Global.selectDropdownOption(driver, "selectYear", "2022", false, true);//year value has been hardcoded as there is no data available for other selection
		Fin_Fan=RandomStringUtils.randomAlphanumeric(15);
		Processing_Code=RandomStringUtils.randomAlphanumeric(15);
		RC_Global.enterInput(driver, Fin_Fan, FinField, false, true);
		RC_Global.enterInput(driver, Processing_Code, pCodeField, false, true);
		RC_Global.selectDropdownOption(driver,"Initial Pricing*", "Yes", false, true);
		boolean isSuccess = false;
		for(int i=driver.findElements(By.xpath("//select[@id='selectMake']/option")).size();i>=2;i--)
		{
			make=driver.findElement(By.xpath("//select[@id='selectMake']/option["+i+"]")).getText();
			RC_Global.selectDropdownOption(driver, "selectMake", make, false, true);
			RC_Global.waitElementVisible(driver, 5, "(//table)[6]/tbody/tr[1]", "'Select Model' column displays all the Models available for the Make selected", false, true);

			RC_Global.clickUsingXpath(driver, "(//table)[6]/tbody/tr[1]/td[1]", "1st row model", false, true);
			if(driver.findElements(By.xpath("(//table)[6]/tbody/tr[1]/td[2]")).size()>0)
			{
				tSelected=driver.findElement(By.xpath("(//table)[6]/tbody/tr[1]/td[2]")).getText();
				tSelectedOf=driver.findElement(By.xpath("(//table)[6]/tbody/tr[1]/td[2]/span")).getText();
				queryObjects.logStatus(driver, Status.PASS, "Trim Selected column displays", tSelected, null);
			}
			RC_Global.waitElementVisible(driver, 5, "(//tr[@ng-repeat='trim in group'])[1]", "Available trims are listed for the selected Model", false, true);
			Thread.sleep(1000);
			RC_Global.clickUsingXpath(driver, "(//tr[@ng-repeat='trim in group'])[1]/td/input", "1st Available Trim", false, true);
			tSelected=driver.findElement(By.xpath("(//table)[6]/tbody/tr[1]/td[2]")).getText();
			queryObjects.logStatus(driver, Status.PASS, "Trim Selected column displays", tSelected, null);
			executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//button[text()='Save'])[3]")));
			RC_Global.clickUsingXpath(driver, "(//button[text()='Save'])[3]", "Save", false, true);
			Thread.sleep(2000);
			if(driver.findElements(By.xpath("//*[text()='Program already exists.']")).size()>0 || driver.findElements(By.xpath("//*[text()='Program failed to save.']")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Error message is displayed", "", null);
				executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//*[text()='Program Details']")));
			}
			else if(driver.findElements(By.xpath("//h4[contains(text(),'Manufacture')]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Successful' message is displayed", "", null);
				isSuccess = true;
				break;
			}
		}
		if (isSuccess) {
			orderingPgm = pName;
			executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//th[text()='Model']")));		
			RC_Global.clickButton(driver, "Edit", false, true);
			executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//*[text()='Program Details']")));
			RC_Global.clickButton(driver, "Manage Documents", false, true);
			Thread.sleep(1000);
			String[] aColNames = mDocColumns.split(";");
			for(int i=0;i<aColNames.length;i++)
			{
				if(driver.findElements(By.xpath("(//th/div/span[text()='"+aColNames[i]+"'])[1]")).size()>0)
				{
					driver.findElement(By.xpath("(//th/div/span[text()='"+aColNames[i]+"'])[1]"));
					queryObjects.logStatus(driver, Status.PASS, "Column Validation for", aColNames[i]+" Column is verified", null);
				}
				else
				{
					queryObjects.logStatus(driver, Status.FAIL, "Column Validation for ", " Column"+aColNames[i]+" is not available", null);
				}
			}
			if(driver.findElements(By.xpath("(//button/img)[1]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Excel icon is displayed", "", null);
			}
			if(driver.findElements(By.xpath("(//a[text()='1'])[1]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Navigation buttons are displayed", "", null);
			}
			if(driver.findElements(By.xpath("//fieldset[@disabled='disabled']/button[text()=' Open ']")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Open button is disabled", "", null);
			}
			if(driver.findElements(By.xpath("//fieldset[@disabled='disabled']/button[text()=' Print ']")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Print button is disabled", "", null);
			}
			if(driver.findElements(By.xpath("(//button[text()='Cancel'])[1]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Cancel button is enabled", "", null);
			}
			if(driver.findElements(By.xpath("(//button[text()='Upload Document'])[1]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Upload Document button is enabled", "", null);
			}
			driver.findElement(By.xpath("//input[@id='fileInputfield']")).sendKeys(uploadFilePath);
			RC_Global.clickUsingXpath(driver, "(//button[text()='Upload Document'])[1]", "Upload Document", false, true);
			executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//button[text()='Save'])[3]")));
			RC_Global.clickUsingXpath(driver, "(//button[text()='Save'])[3]", "Save", false, true);
			Thread.sleep(4000);
			if(driver.findElements(By.xpath("//h4[contains(text(),'Manufacture')]")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Successful' message is displayed", "", null);
			}
			Thread.sleep(1000);
			RC_Global.createNode(driver, "Verify the Manufacturing Incentive Program grid");
			executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//*[text()='Documents'])[2]")));
			RC_Global.clickUsingXpath(driver, "(//span[text()='Created Date'])[1]", "'Created Date' Column", false, false);
			executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//*[text()='Documents'])[2]")));
			RC_Global.clickUsingXpath(driver, "(//span[text()='Created Date'])[1]", "'Created Date' Column", false, false);
			executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("(//*[text()='Customer #'])[2]")));
			RC_Manage.orderingProfileColumnValidation(driver, "Customer #;Customer Name;Program Name;Status;Year;Make;Initial Pricing;Created Date;Documents;Available Actions;Fleet #;Fleet Name;Account #;Account Name;Sub-Account #;Sub-Account Name", pName, true);
		} else {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to save the program with make and model", "Unable to proceed with remaining steps validation", null);
		}
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
