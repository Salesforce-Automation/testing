package Manage.Administration.CustomerAdministration.Ordering;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_4_7_02{
	public void MIP_ValidateProgramPropagateFromCustomerLevelToAllLevels(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Customer Administration";
		
		RC_Global.login(driver);
		RC_Global.enterCustomerFocus(driver, "LS010087", false);
		Thread.sleep(2000);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);

		RC_Global.waitUntilPanelVisibility(driver, "Customer Administration", "TV", true, false);
		RC_Global.clickUsingXpath(driver, "//a[text()='Ordering']", "Ordering", false, true);
		
		
		RC_Global.clickButton(driver, "Create New", false, true);
		RC_Global.waitElementVisible(driver, 60, "//legend[text()='Program Details']", "Program Details", false,true);
		
	    String ProgramName = "Sample"+RandomStringUtils.randomAlphabetic(3).toLowerCase()+" "+RandomStringUtils.randomNumeric(3);
		WebElement element = driver.findElement(By.xpath("//input[@name='ProgramName']"));
		RC_Global.enterInput(driver, ProgramName, element  , false, true);
		
        RC_Global.clickUsingXpath(driver, "//select[@id='selectYear']", "Year", false, true);
        RC_Global.clickUsingXpath(driver, "(//select[@id='selectYear']/..//option)[4]", "2021", false, true);
        
        RC_Global.clickUsingXpath(driver, "//select[@id='selectMake']", "Make", false, true);
        List<WebElement> dropdowncnt= driver.findElements(By.xpath("//select[@id='selectMake']/..//option[@label]"));  
        int size=dropdowncnt.size();
        int RandomNumber=ThreadLocalRandom.current().nextInt(0,size);
        dropdowncnt.get(RandomNumber).click();
        
        
    //    RC_Global.clickButton(driver, "Save", false, true);
        RC_Global.clickUsingXpath(driver, "(//button[text()='Save'])[3]", "Save", false, true);
        Thread.sleep(1000);
        RC_Manage.waitUntilMethods(driver, "(//button[text()='Save'])[3]/../../following-sibling::div[@ng-show='isSaving']","class","ng-hide", "attribute visible");
        Thread.sleep(1000);
        RC_Global.verifyDisplayedMessage(driver, "Manufacturers' Incentive Program Successfully Saved", false);
        Thread.sleep(4000);
        RC_Global.waitElementVisible(driver, 60, "(//table/tbody/tr[1])[2]", " Ordering grid row", true,true);
        
        //Step 6 - Missing
        RC_Global.createNode(driver, "Verify the Program created is available in the Lower-level");
        RC_Global.clickUsingXpath(driver, "//span[@title='LS007728 - Tribus Services Inc']", "Fleet Level Number", true, false);
        
        RC_Global.clickUsingXpath(driver, "//a[text()='Ordering']", "Ordering", false, true);
		RC_Global.waitElementVisible(driver, 30, "(//table/tbody)[3]/tr[1]", "First Row of the Ordering Grid", true, false);
		
		try {
			RC_Global.waitElementVisible(driver, 30, "//table/tbody/tr/td[text()='"+ProgramName+"']", "Newly created program present in Fleet Level", true, true);
			queryObjects.logStatus(driver, Status.PASS, "Verify newly created program is present in Fleet-Level", ProgramName+" is present in the Fleet level", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify newly created program is present in Fleet-Level", ProgramName+" is not present in the Fleet level", null);
		}
		
		if(driver.findElement(By.xpath("(//li[div[span[text()='LS007728 - Tribus Services Inc']]]/i)[1]")).getAttribute("class").contains("glyphicon-chevron-right"))//[contains(@class,'glyphicon-chevron-right')]
			RC_Global.clickUsingXpath(driver, "(//li[div[span[text()='LS007728 - Tribus Services Inc']]]/i)[1]", "", true, false);
			
		RC_Global.clickUsingXpath(driver, "//span[@title='LS007728 - Tribus Services Inc']", "Account Level Number", true, false);
        
        RC_Global.clickUsingXpath(driver, "//a[text()='Ordering']", "Ordering", false, true);
		RC_Global.waitElementVisible(driver, 30, "(//table/tbody)[3]/tr[1]", "First Row of the Ordering Grid", true, false);
		
		try {
			RC_Global.waitElementVisible(driver, 30, "//table/tbody/tr/td[text()='"+ProgramName+"']", "Newly created program present in Account Level", true, true);
			queryObjects.logStatus(driver, Status.PASS, "Verify newly created program is present in Account-Level", ProgramName+" is present in the Account level", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify newly created program is present in Account-Level", ProgramName+" is not present in the Account level", null);
		}
        
		
		RC_Global.createNode(driver, "Verify the Program can be deactivated");
        RC_Global.clickUsingXpath(driver, "//span[@title='LS010087 - Tribus Services Inc.']", "Customer Level Number", true, false);
        
        RC_Global.clickUsingXpath(driver, "//a[text()='Ordering']", "Ordering", false, true);
		RC_Global.waitElementVisible(driver, 30, "(//table/tbody)[3]/tr[1]", "First Row of the Ordering Grid", true, false);
        
        
        try {
			Thread.sleep(1000);
			List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("//div[contains(@class,'manufacturer-incentive-programs')]//following-sibling::table//tbody//tr"));  
			int rowcnt=Getgridrowcnt.size();
			Boolean	firstpage=false;
			
			for(int i=1; i<=rowcnt;i++) {
				WebElement sub = driver.findElement(By.xpath("//div[contains(@class,'manufacturer-incentive-programs')]//following-sibling::table//tr["+i+"]//td[3]"));
				String Cname = sub.getText();
					WebElement AvailableAction = driver.findElement(By.xpath("//div[contains(@class,'manufacturer-incentive-programs')]//following-sibling::table//tr["+i+"]//td[10]"));
					if((Cname.equals(ProgramName))) {
					Thread.sleep(2000);
					AvailableAction.click();

					queryObjects.logStatus(driver, Status.PASS, "Verified able to administration and able to deactivate the programs created at own level","succesfully" , null);	

					break;}
				}
        }
		catch (Exception e){
			queryObjects.logStatus(driver, Status.FAIL, "Verified unable to administration and unable to deactivate the programs created at own level", e.getLocalizedMessage(), e);	
		}
	
          
	}

}
