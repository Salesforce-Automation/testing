	package Manage.Administration.CustomerAdministration.Ordering;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_4_7_03 {
	public void MIP_VerifyNewProgramCreationAtSubLevels(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		
		int rowCount;String fleetLevel="";
		String subAccountLevel="";int flag=0;
		String ProgramName_Grid="";String accountLevel="";
		String ProgramName_Input=RandomStringUtils.randomAlphabetic(10).toUpperCase();

		
		
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Customer Administration";
		
		RC_Global.login(driver);
		RC_Global.enterCustomerFocus(driver, "LS010087", false);
//		RC_Global.clickUsingXpath(driver, "//span[text()='LS010087 - Tribus Services Inc.']", "Tribus Services Inc", false, true);
//		RC_Global.clickUsingXpath(driver, "//button[@ng-click='toggleHierarchy($event)']", "Tree", false, true);
//		RC_Global.clickUsingXpath(driver, "//i[@ng-click='selectNodeHead(node)']", "Node", false, true);
//		RC_Global.clickUsingXpath(driver, "//span[text()='10803 - Forklifts - Corix Water Products']", "Account", false, true);
		Thread.sleep(2000);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		
		
		RC_Global.validateHeaderName(driver, "Customer Administration", false);
		RC_Global.clickUsingXpath(driver, "//a[text()='Ordering']", "Ordering", false, true);
		RC_Global.createNode(driver, "Validate the 'Manufacturers' Incentive Program' screen");
		if(driver.findElements(By.xpath("//label[contains(text(),'Incentive Program')]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Manufacturers' Incentive Program tab is displayed", "", null);
		}
		 RC_Global.clickUsingXpath(driver, "//span[text()='10803 - Forklifts - Corix Water Products']", "Fleet Level", false, true);
	        
		 Thread.sleep(2000);
	        if(driver.findElements(By.xpath("//span[text()='10803 - Forklifts - Corix Water Products']")).size()>0)
			{
				String labelText = driver.findElement(By.xpath("(//label[text()='Fleet Name'])[7]")).getText();
				String data = driver.findElement(By.xpath("(//div[text()=' Forklifts - Corix Water Products '])[7]")).getText();
				queryObjects.logStatus(driver, Status.PASS, "Fleet # level selection has label "+labelText+" with value", data, null);

			}
			else
			{
				queryObjects.logStatus(driver, Status.FAIL, "Fleet # Level selection value not found in label", null, null);

			}

		
		
		
		 String AvaAct =driver.findElement(By.xpath("(//button[contains(@ng-click,'data, false')])[4]")).getText();

		 RC_Global.buttonStatusValidation(driver,AvaAct, "Disable", false);
		 queryObjects.logStatus(driver, Status.PASS, "Verified able to view the program details but will not be able to modify or deactivate them", null, null);
	
	     
	     
	     RC_Global.clickButton(driver, "Create New", false, true);
	     RC_Global.waitElementVisible(driver, 60, "//legend[text()='Program Details']", "Program Details", false,true);
			
	    String ProgramName = "Sample"+RandomStringUtils.randomAlphabetic(3).toLowerCase()+" "+RandomStringUtils.randomNumeric(3);
		WebElement element = driver.findElement(By.xpath("//input[@name='ProgramName']"));
		RC_Global.enterInput(driver, ProgramName, element  , false, true);
		
        RC_Global.clickUsingXpath(driver, "//select[@id='selectYear']", "Year", false, true);
        RC_Global.clickUsingXpath(driver, "(//select[@id='selectYear']/..//option)[4]", "2021", false, true);

        RC_Global.clickUsingXpath(driver, "//select[@id='selectMake']", "Make", false, true);

        
        List<WebElement> dropdowncnt= driver.findElements(By.xpath("//select[@id='selectMake']/..//option[@label]"));  
        int size=dropdowncnt.size();
        int RandomNumber=ThreadLocalRandom.current().nextInt(0,size);
        dropdowncnt.get(RandomNumber).click();
        
        RC_Global.clickUsingXpath(driver, "(//button[text()='Save'])[3]", "Save", false, true);
        
        Thread.sleep(1000);
        RC_Manage.waitUntilMethods(driver, "(//button[text()='Save'])[3]/../../following-sibling::div[@ng-show='isSaving']","class","ng-hide", "attribute visible");
        Thread.sleep(1000);
        RC_Global.verifyDisplayedMessage(driver, "Manufacturers' Incentive Program Successfully Saved", false);
        Thread.sleep(4000);
        RC_Global.waitElementVisible(driver, 60, "(//table/tbody/tr[1])[2]", " Ordering grid row", true,true);
        
        RC_Global.scrollById(driver, "(//span[text()='Customer #'])[1]");
        
        
        try {
			Thread.sleep(1000);
			List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("//div[contains(@class,'manufacturer-incentive-programs')]//following-sibling::table//tbody//tr"));  
			int rowcnt=Getgridrowcnt.size();
			Boolean	firstpage=false;
			
			for(int i=1; i<=rowcnt;i++) {
				WebElement sub = driver.findElement(By.xpath("//div[contains(@class,'manufacturer-incentive-programs')]//following-sibling::table//tr["+i+"]//td[3]"));
				String Cname = sub.getText();
					WebElement AvailableAction = driver.findElement(By.xpath("//div[contains(@class,'manufacturer-incentive-programs')]//following-sibling::table//tr["+i+"]//td[10]"));
					if((Cname.equals(ProgramName))) {
					Thread.sleep(2000);
					AvailableAction.click();

					queryObjects.logStatus(driver, Status.PASS, "Verified able to administration and able to deactivate the programs created at own level","succesfully" , null);	

					break;}
				}
	
			
        }
		catch (Exception e){
			queryObjects.logStatus(driver, Status.FAIL, "Verified unable to administration and unable to deactivate the programs created at own level", e.getLocalizedMessage(), e);	
			}
	
	
		RC_Global.scrollById(driver, "(//*[text()=' Customer # '])[1]");
		fleetLevel=driver.findElement(By.xpath("(//treeItem//li//div//span)[2]")).getText();
		RC_Global.clickUsingXpath(driver, "(//treeItem//li//i[1])[2]", "Expand "+fleetLevel+"", false, false);
		accountLevel=driver.findElement(By.xpath("((//treeItem//li//div//span)[2]/../following-sibling::treeItem/ul/li/div/span)[1]")).getText();
		RC_Global.clickUsingXpath(driver, "((//treeItem//li//div//span)[2]/../following-sibling::treeItem/ul/li/div/span)[1]", "Account Level "+accountLevel+"", false, true);
		RC_Global.waitElementVisible(driver, 10, "//*[text()='Create New']", "Manufacturers' Incentive Program tab is loading", false, false);
		RC_Global.scrollById(driver, "//span[text()='Program Name']");

		RC_Global.scrollById(driver, "(//*[text()=' Customer # '])[1]");
		RC_Global.clickUsingXpath(driver, "//span[text()='"+fleetLevel+"']", fleetLevel, false, true);
		RC_Global.waitElementVisible(driver, 10, "//*[text()='Create New']", "Manufacturers' Incentive Program tab is loading", false, false);
		RC_Global.scrollById(driver, "//span[text()='Program Name']");
		RC_Global.scrollById(driver, "(//span[text()='Customer Administration'])[2]");
		RC_Global.panelAction(driver, "close", "Customer Administration", false, true);
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	
	}
	
	

}
