package Manage.Administration.CustomerAdministration.Ordering;

import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_4_7_12 {
	

	
	public void OrderingProfile_EditProfile(WebDriver driver, BFrameworkQueryObjects queryObjects)throws Exception
		
	{
		RC_Global.login(driver);
		//RC_Global.enterCustomerFocus(driver, "LS008320", false);
		RC_Global.enterCustomerFocus(driver, "LS008742", false);
	
		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
		
		RC_Global.clickUsingXpath(driver, "//a[text()='Ordering']", "Ordering tab", false, true);
		
		RC_Global.clickUsingXpath(driver, "//label[text()='Ordering Profiles']", "Ordering profiles", false, true);

		Thread.sleep(2000);
		
		RC_Global.verifyScreenComponents(driver, "button", " Edit ", false);
		RC_Global.verifyScreenComponents(driver, "button", " Clone ", false);
	    RC_Global.verifyScreenComponents(driver, "button", " Deactivate ", false);
					
		RC_Global.clickUsingXpath(driver, "//*[@id='customer-attributes-vehicle-ordering-profiles']//tr[1]//button[4]", "Deactive", false, true);		
		RC_Global.verifyScreenComponents(driver, "button", " View ", false);
		RC_Global.verifyScreenComponents(driver, "button", " Clone ", false);
	    RC_Global.verifyScreenComponents(driver, "button", " Activate ", false);
			
		RC_Global.clickUsingXpath(driver, "//*[@id='customer-attributes-vehicle-ordering-profiles']//tr[1]//button[2]", " view", false, true);		
		RC_Global.clickUsingXpath(driver, "//button[text()='Collapse All']", "Collapse All", false, true);
		
		
		RC_Global.verifyScreenComponents(driver, "button", "How to Bill Order Related Fees", false);
		RC_Global.verifyScreenComponents(driver, "button", "Overhead and Risk", false);
	    RC_Global.verifyScreenComponents(driver, "button", "Capitalization Cost Calculation Formula", false);
	    RC_Global.verifyScreenComponents(driver, "button", "Lease Terms and Fees", false);
	    RC_Global.verifyScreenComponents(driver, "button", "Fleet Account Numbers", false);
	    RC_Global.verifyScreenComponents(driver, "button", "Programs", false);
	    RC_Global.verifyScreenComponents(driver, "button", "Comments", false);
	    
		RC_Global.clickUsingXpath(driver, "//*[@id='customer-attributes-vehicle-ordering-profiles']//tr[1]//button[5]", "active", false, true);		
		RC_Global.clickUsingXpath(driver, "//label[text()='Profile Status']/following-sibling::select", "select ProfileStatus", false, true);		
		RC_Global.selectDropdownOption(driver, "Profile Status", "Inactive", true,true);

		RC_Global.verifyScreenComponents(driver, "button", " View ", false);
		RC_Global.verifyScreenComponents(driver, "button", " Clone ", false);
	    RC_Global.verifyScreenComponents(driver, "button", " Activate ", false);
	    
	    RC_Global.clickUsingXpath(driver, "(//button[normalize-space(text())='Clone'])[2]", "Clone", false, true);
//	    RC_Global.clickUsingXpath(driver, "//div[span[span[normalize-space(text())='Profile Details']]]", "Profile Details section", true, true);
	    WebElement profileName = driver.findElement(By.xpath("(//div[label[normalize-space(text())='Profile Name']]/textarea)[1]"));
		String inputProfile = "Sample Draft Profile "+RandomStringUtils.randomNumeric(2);
		RC_Global.scrollById(driver, "(//div[label[normalize-space(text())='Profile Name']]/textarea)[1]");
		Thread.sleep(2000);
		RC_Global.enterInput(driver, inputProfile, profileName, true, true);
		RC_Global.clickButton(driver, "Save as Draft", false, true);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		   Thread.sleep(1000);
	executor.executeScript("document.body.style.zoom = '30%'");
		   Thread.sleep(2000);
	executor.executeScript("document.body.style.zoom = '100%'");
	Thread.sleep(2000);
		
	    RC_Global.selectDropdownOption(driver, "Profile Status", "Draft", true,true);
	    RC_Global.verifyScreenComponents(driver, "button", " Edit ", false);
		RC_Global.verifyScreenComponents(driver, "button", " Clone ", false);
		
	    if(driver.findElement(By.xpath("//*[@id='customer-attributes-vehicle-ordering-profiles']//tr//button[1]")).isDisplayed()) {
	    	RC_Global.clickUsingXpath(driver, "//*[@id='customer-attributes-vehicle-ordering-profiles']//tr//button[1]", "click edit", false, true);
	    	RC_Global.clickUsingXpath(driver, "//label[text()=' Agreement Type ']/following-sibling::select", "Agreement Type", false, true);
	    	RC_Global.clickUsingXpath(driver, "//label[text()=' Agreement Type ']/following-sibling::select/option[text()='Open End']", "Select Agreement_Type", false, true);
	    	RC_Global.clickUsingXpath(driver, "//select[@name='pricingDeterminedBy']/option[text()='Structured']", "select pricingDeterminedBy", false, true);
	    	RC_Global.clickButton(driver, "Save as Draft", false, true);}
	
	    RC_Global.logout(driver, true);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);   	
	}
}

