package Manage.Administration.CustomerAdministration.Ordering;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_4_7_08 {
	public void OrderingProfileAttributesSubLevels(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		int rowCount;String fleetLevel="";
		String ProfileName_Grid="";String accountLevel="";int newProfileRowNumber=0;
		String subAccountLevel="";int flag=0;
		String ProfileName_Input=RandomStringUtils.randomAlphabetic(10).toUpperCase();
		
		RC_Global.login(driver);
		RC_Global.enterCustomerFocus(driver, "LS010143", false);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
		RC_Global.clickUsingXpath(driver, "//a[text()='Ordering']", "Ordering", false, true);
		RC_Global.clickUsingXpath(driver, "//*[text()='Ordering Profiles']", "Ordering Profiles", false, true);
		fleetLevel=driver.findElement(By.xpath("(//treeItem//li//div//span)[1]")).getText();
		RC_Global.clickUsingXpath(driver, "(//treeItem//li//div//span)[1]", "Fleet Level "+fleetLevel+"", false, true);
		RC_Global.waitElementVisible(driver, 60, "(//*[text()=' View '])[1]", "", true, true);
		RC_Global.clickUsingXpath(driver, "(//*[text()=' View '])[1]", "View", false, true);
		RC_Global.waitElementVisible(driver, 5, "(//*[text()='Profile Name'])[1]", "Profile Details are displayed", false, false);
		if(driver.findElement(By.xpath("(//form[@name='profileForm']//fieldset)[1]")).getAttribute("disabled").equals("true"))
			queryObjects.logStatus(driver, Status.PASS, "There is view only access to the profiles that have been set up", "", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "There is view only access to the profiles that have not been set up", "", null);
		
		RC_Global.waitElementVisible(driver, 60, "(//*[text()=' Clone '])[1]", "", true, true);
		RC_Global.clickUsingXpath(driver, "(//*[text()=' Clone '])[1]", "Clone", false, true);
		RC_Global.scrollById(driver, "(//*[text()=' Profile Name '])[1]");
		Thread.sleep(2000);
		WebElement profileNameElement = driver.findElement(By.xpath("(//textarea[@name='profileName'])[1]"));
		profileNameElement.clear();
		RC_Global.enterInput(driver, ProfileName_Input, profileNameElement, false, false);
		RC_Global.scrollById(driver, "//*[text()=' Insurance ']");
		RC_Global.clickUsingXpath(driver, "(//button[text()='Save and Activate'])[1]", "Save and Activate", false, true);
		//RC_Global.waitElementVisible(driver, 5, "(//*[text()='Profile Name'])[1]", "Profile Details are displayed", false, false);
		Thread.sleep(6000);
		RC_Global.scrollById(driver, "//span[text()='Profile Name']");
		rowCount=driver.findElements(By.xpath("((//div[@ng-show='showGrid'])[1]/div/div/table)[2]/tbody/tr")).size();
		for(int i=1;i<=rowCount;i++)
		{
			ProfileName_Grid=driver.findElement(By.xpath("((//div[@ng-show='showGrid'])[1]/div/div/table)[2]/tbody/tr["+i+"]/td[3]")).getText();
			if(ProfileName_Input.equals(ProfileName_Grid))
			{
				queryObjects.logStatus(driver, Status.PASS, "New Profile is created in Fleet Level", ProfileName_Input, null);
				flag=1;
				newProfileRowNumber=i;
				break;
			}
		}
		if(flag==0)
		{
			queryObjects.logStatus(driver, Status.FAIL, "New Profile is not created in Fleet Level", "", null);
		}
		
		RC_Global.scrollById(driver, "(//*[text()=' Customer # '])[1]");
		RC_Global.clickUsingXpath(driver, "(//treeItem//li//i[1])[1]", "Expand "+fleetLevel+"", false, false);
		accountLevel=driver.findElement(By.xpath("(//treeItem//li//div//span)[1]/../following-sibling::treeItem/ul/li/div/span")).getText();
		RC_Global.clickUsingXpath(driver, "(//treeItem//li//div//span)[1]/../following-sibling::treeItem/ul/li/div/span", "Account Level "+accountLevel+"", false, true);
		RC_Global.waitElementVisible(driver, 60, "//*[text()='Add New Profile']", "Ordering Profiles tab is loading", false, false);
		RC_Global.scrollById(driver, "//span[text()='Profile Name']");
		for(int i=1;i<=rowCount;i++)
		{
			ProfileName_Grid=driver.findElement(By.xpath("((//div[@ng-show='showGrid'])[1]/div/div/table)[2]/tbody/tr["+i+"]/td[3]")).getText();
			if(ProfileName_Input.equals(ProfileName_Grid))
			{
				queryObjects.logStatus(driver, Status.PASS, "New Profile is displayed in Account Level", ProfileName_Input, null);
				flag=1;
				break;
			}
		}
		if(flag==0)
		{
			queryObjects.logStatus(driver, Status.FAIL, "New Profile is not displayed in Account Level", "", null);
		}
		RC_Global.scrollById(driver, "(//*[text()=' Customer # '])[1]");
		RC_Global.clickUsingXpath(driver, "(//treeItem//li//i[1])[2]", "Expand "+accountLevel+"", false, false);
		subAccountLevel=driver.findElement(By.xpath("((//treeItem//li//div//span)[2]/../following-sibling::treeItem/ul/li/div/span)[1]")).getText();
		RC_Global.clickUsingXpath(driver, "((//treeItem//li//div//span)[2]/../following-sibling::treeItem/ul/li/div/span)[1]", "Sub Account Level "+subAccountLevel+"", false, true);
		RC_Global.waitElementVisible(driver, 60, "//*[text()='Add New Profile']", "Ordering Profiles tab is loading", false, false);
		RC_Global.scrollById(driver, "//span[text()='Profile Name']");
		for(int i=1;i<=rowCount;i++)
		{
			ProfileName_Grid=driver.findElement(By.xpath("((//div[@ng-show='showGrid'])[1]/div/div/table)[2]/tbody/tr["+i+"]/td[3]")).getText();
			if(ProfileName_Input.equals(ProfileName_Grid))
			{
				queryObjects.logStatus(driver, Status.PASS, "New Profile is displayed in Sub Account Level", ProfileName_Input, null);
				flag=1;
				break;
			}
		}
		if(flag==0)
		{
			queryObjects.logStatus(driver, Status.FAIL, "New Profile is not displayed in Sub Account Level", "", null);
		}
		RC_Global.scrollById(driver, "(//*[text()=' Customer # '])[1]");
		RC_Global.clickUsingXpath(driver, "//span[text()='"+fleetLevel+"']", fleetLevel, false, true);
		RC_Global.waitElementVisible(driver, 60, "//*[text()='Add New Profile']", "Ordering Profiles tab is loading", false, false);
//		RC_Global.scrollById(driver, "//span[text()='Profile Name']");
		RC_Global.clickUsingXpath(driver, "((//div[@ng-show='showGrid'])[1]/div/div/table)[2]/tbody/tr["+newProfileRowNumber+"]/td[15]/button[text()=' Deactivate ']", "Deactivate", false, true);
		RC_Global.scrollById(driver, "(//span[text()='Customer Administration'])[2]");
		RC_Global.panelAction(driver, "close", "Customer Administration", false, true);
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
