package Manage.Administration.CustomerAdministration.CustomerSummary;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_4_1_01 {
	public void ValidateCustomerSummaryAttributes(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String CustNo="LS010143";
		String CustName="Patterson Companies, Inc";
		String FleetLevel="10000 - 30 - Companies";
		String AccountLevel="1830 - 100 - Corporate Companies";
		String SubAccountLevel="116 - 107-Patterson Companies";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
		RC_Global.enterCustomerNumber(driver,CustNo , "", "", true);
		RC_Global.waitElementVisible(driver, 10, "//legend[text()='Main Contact']", "Customer Administration screen opens", false, true);
		if(driver.findElements(By.xpath("//legend[text()='Main Contact']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Customer Administration' screen opens with 'Customer Summary' tab selected by default", "", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "'Customer Administration' screen opens with 'Customer Summary' tab selected by default", "", null);
		}
		RC_Global.createNode(driver, "Validate Customer Level");
		if(driver.findElement(By.xpath("(//label[text()='Customer Name'])[1]//following-sibling::div")).getText().contains(CustName))
		{
			queryObjects.logStatus(driver, Status.PASS, "The header displays the Customer Name field", CustName, null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "The header does not display the Customer Name field", "", null);
		}
		if(driver.findElement(By.xpath("(//label[text()='Customer Number'])[1]//following-sibling::div")).getText().contains(CustNo))
		{
			queryObjects.logStatus(driver, Status.PASS, "The header displays the Customer Number field", CustNo, null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "The header does not display the Customer Number field", "", null);
		}
		String LastUpdatedBy=driver.findElement(By.xpath("(//label[text()='Last Updated By'])[1]//following-sibling::div")).getText();
		if(!LastUpdatedBy.equals(""))
		{
			queryObjects.logStatus(driver, Status.PASS, "The header displays the Last Updated By field", LastUpdatedBy, null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "The header does not display the Last Updated By field", "", null);
		}
		String LastUpdatedDate=driver.findElement(By.xpath("(//label[text()='Last Updated Date'])[1]//following-sibling::div")).getText();
		if(!LastUpdatedDate.equals(""))
		{
			queryObjects.logStatus(driver, Status.PASS, "The header displays the Last Updated Date field", LastUpdatedDate, null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "The header does not display the Last Updated Date field", "", null);
		}
		String CustomerSince=driver.findElement(By.xpath("(//label[text()='Customer Since'])[1]//following-sibling::div")).getText();
		if(!CustomerSince.equals(""))
		{
			queryObjects.logStatus(driver, Status.PASS, "The header displays the Last Customer Since field", CustomerSince, null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "The header does not display the Customer Since field", "", null);
		}
		RC_Global.clickUsingXpath(driver, "//span[text()='"+FleetLevel+"']", "Fleet Level "+FleetLevel, false, true);
		RC_Global.validateHeaderName(driver, FleetLevel, false);
		RC_Global.clickUsingXpath(driver, "(//i[@ng-class='iBranchClass()'])[2]", "Expand "+FleetLevel+" Fleet Level", false, true);
		RC_Global.clickUsingXpath(driver, "//span[text()='"+AccountLevel+"']", "Account Level "+AccountLevel, false, true);
		RC_Global.validateHeaderName(driver, AccountLevel, false);
		RC_Global.clickUsingXpath(driver, "(//i[@ng-class='iBranchClass()'])[3]", "Expand "+AccountLevel+" Account Level", false, true);
		RC_Global.clickUsingXpath(driver, "//span[text()='"+SubAccountLevel+"']", "Sub-Account Level "+SubAccountLevel, false, true);
		RC_Global.validateHeaderName(driver, SubAccountLevel, false);
		RC_Global.createNode(driver, "Validate Customer Summary Tab");
		if(driver.findElements(By.xpath("//legend[text()='Main Contact']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Main contact' section is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//legend[text()='Merchants Representatives']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Merchants Representatives' section is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//legend[text()='Customer Setup']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Customer Setup' section is displayed", "", null);
		}
		RC_Global.createNode(driver, "Validate Main Contact Section");
		if(driver.findElement(By.xpath("(//legend[text()='Main Contact']//following-sibling::div/div/div/label)[1]")).getText().equals("Name"))
		{
			queryObjects.logStatus(driver, Status.PASS, "'Name' displayed in hyperlink text", "", null);
		}
		if(driver.findElement(By.xpath("(//legend[text()='Main Contact']//following-sibling::div/div/div/label)[2]")).getText().equals("Phone (Cell)"))
		{
			queryObjects.logStatus(driver, Status.PASS, "'Phone (Cell)' is displayed", "", null);
		}
		if(driver.findElement(By.xpath("(//legend[text()='Main Contact']//following-sibling::div/div/div/label)[3]")).getText().equals("Phone (Work)"))
		{
			queryObjects.logStatus(driver, Status.PASS, "'Phone (Work)' is displayed", "", null);
		}
		if(driver.findElement(By.xpath("(//legend[text()='Main Contact']//following-sibling::div/div/div/label)[5]")).getText().equals("Email"))
		{
			queryObjects.logStatus(driver, Status.PASS, "'Email' is displayed", "", null);
		}
		if(driver.findElement(By.xpath("(//legend[text()='Main Contact']//following-sibling::div/div/div/label)[6]")).getText().equals("Employee ID"))
		{
			queryObjects.logStatus(driver, Status.PASS, "'Employee ID' is displayed", "", null);
		}
		if(driver.findElement(By.xpath("(//legend[text()='Main Contact']//following-sibling::div/div/div/label)[7]")).getText().equals("Address"))
		{
			queryObjects.logStatus(driver, Status.PASS, "'Address' is displayed", "", null);
		}
		RC_Global.clickUsingXpath(driver, "(//legend[text()='Main Contact']//following-sibling::div/div/div/label//following-sibling::div)[1]", "Name hyperlink", false, true);
		RC_Global.waitElementVisible(driver, 5, "//div[@id='Edit Employee']", "Edit Employee screen opened", false, true);
		RC_Global.panelAction(driver, "close", "Edit Employee", false, true);
		RC_Global.createNode(driver, "Validate Merchants Representatives section details");
		if(driver.findElements(By.xpath("(//label[text()='Name'])[2]//following-sibling::div")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Name' is displayed for Customer Service", driver.findElement(By.xpath("(//label[text()='Name'])[2]//following-sibling::div")).getText(), null);
		}
		if(driver.findElements(By.xpath("(//label[text()='Email'])[2]//following-sibling::div/a/div")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Email' is displayed for Customer Service", driver.findElement(By.xpath("(//label[text()='Email'])[2]//following-sibling::div/a/div")).getText(), null);
		}
		if(driver.findElements(By.xpath("(//label[text()='Name'])[3]//following-sibling::div")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Name' is displayed for Sales Executive", driver.findElement(By.xpath("(//label[text()='Name'])[3]//following-sibling::div")).getText(), null);
		}
		if(driver.findElements(By.xpath("(//label[text()='Email'])[3]//following-sibling::div/a/div")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Email' is displayed for Sales Executive", driver.findElement(By.xpath("(//label[text()='Email'])[3]//following-sibling::div/a/div")).getText(), null);
		}
		RC_Global.createNode(driver, "Validate Customer Setup section details");
		if(driver.findElements(By.xpath("//label[text()='Website']//following-sibling::div/div[1]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Website' is displayed", driver.findElement(By.xpath("//label[text()='Website']//following-sibling::div/div[1]")).getText(), null);
		}
		if(driver.findElements(By.xpath("//label[text()='FEIN']//following-sibling::div/div[1]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'FEIN' is displayed", driver.findElement(By.xpath("//label[text()='FEIN']//following-sibling::div/div[1]")).getText(), null);
		}
		RC_Global.panelAction(driver, "close", "Customer Administration", false, true);
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}

}
