package Manage.Administration.CustomerAdministration.CustomerSummary;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_4_1_02 {
	public void ValidateCustomerSummaryAttributesForExternalUser(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		RC_Global.externalUserLogin(driver, "kentuckytest3", "Yes");
		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Summary");
		RC_Global.validateHeaderName(driver, "Customer Summary", false);
		queryObjects.logStatus(driver, Status.PASS, "Customer Summary screen is opened with default Customer", driver.findElement(By.xpath("(//span[text()='Customer Summary'])[2]//following-sibling::span/span[1]")).getText(), null);
		if(driver.findElements(By.xpath("//a[text()='Customer Summary']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Customer Summary tab is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//a[text()='Policies']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Policies tab is displayed", "", null);
		}
		RC_Global.createNode(driver, "Validate Customer Summary Tab");
		if(driver.findElements(By.xpath("//legend[text()='Main Contact']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Main contact' section is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//legend[text()='Merchants Representatives']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Merchants Representatives' section is displayed", "", null);
		}
		if(driver.findElements(By.xpath("//legend[text()='Customer Setup']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Customer Setup' section is displayed", "", null);
		}
		RC_Global.createNode(driver, "Validate Main Contact Section");
		if(driver.findElement(By.xpath("(//legend[text()='Main Contact']//following-sibling::div/div/div/label)[1]")).getText().equals("Name"))
		{
			queryObjects.logStatus(driver, Status.PASS, "'Name' displayed in hyperlink text", "", null);
		}
		if(driver.findElement(By.xpath("(//legend[text()='Main Contact']//following-sibling::div/div/div/label)[2]")).getText().equals("Phone (Cell)"))
		{
			queryObjects.logStatus(driver, Status.PASS, "'Phone (Cell)' is displayed", "", null);
		}
		if(driver.findElement(By.xpath("(//legend[text()='Main Contact']//following-sibling::div/div/div/label)[3]")).getText().equals("Phone (Work)"))
		{
			queryObjects.logStatus(driver, Status.PASS, "'Phone (Work)' is displayed", "", null);
		}
		if(driver.findElement(By.xpath("(//legend[text()='Main Contact']//following-sibling::div/div/div/label)[5]")).getText().equals("Email"))
		{
			queryObjects.logStatus(driver, Status.PASS, "'Email' is displayed", "", null);
		}
		if(driver.findElement(By.xpath("(//legend[text()='Main Contact']//following-sibling::div/div/div/label)[6]")).getText().equals("Employee ID"))
		{
			queryObjects.logStatus(driver, Status.PASS, "'Employee ID' is displayed", "", null);
		}
		if(driver.findElement(By.xpath("(//legend[text()='Main Contact']//following-sibling::div/div/div/label)[7]")).getText().equals("Address"))
		{
			queryObjects.logStatus(driver, Status.PASS, "'Address' is displayed", "", null);
		}
		RC_Global.clickUsingXpath(driver, "(//legend[text()='Main Contact']//following-sibling::div/div/div/label//following-sibling::div)[1]", "Name hyperlink", false, true);
		RC_Global.waitElementVisible(driver, 5, "//div[@id='Edit Employee']", "Edit Employee screen opened", false, true);
		RC_Global.panelAction(driver, "close", "Edit Employee", false, true);
		RC_Global.createNode(driver, "Validate Merchants Representatives section details");
		if(driver.findElements(By.xpath("(//label[text()='Name'])[2]//following-sibling::div")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Name' is displayed for Customer Service", driver.findElement(By.xpath("(//label[text()='Name'])[2]//following-sibling::div")).getText(), null);
		}
		if(driver.findElements(By.xpath("(//label[text()='Email'])[2]//following-sibling::div/a/div")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Email' is displayed for Customer Service", driver.findElement(By.xpath("(//label[text()='Email'])[2]//following-sibling::div/a/div")).getText(), null);
		}
		if(driver.findElements(By.xpath("(//label[text()='Name'])[3]//following-sibling::div")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Name' is displayed for Sales Executive", driver.findElement(By.xpath("(//label[text()='Name'])[3]//following-sibling::div")).getText(), null);
		}
		if(driver.findElements(By.xpath("(//label[text()='Email'])[3]//following-sibling::div/a/div")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Email' is displayed for Sales Executive", driver.findElement(By.xpath("(//label[text()='Email'])[3]//following-sibling::div/a/div")).getText(), null);
		}
		RC_Global.createNode(driver, "Validate Customer Setup section details");
		if(driver.findElements(By.xpath("//label[text()='Website']//following-sibling::div/div[1]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'Website' is displayed", driver.findElement(By.xpath("//label[text()='Website']//following-sibling::div/div[1]")).getText(), null);
		}
		if(driver.findElements(By.xpath("//label[text()='FEIN']//following-sibling::div/div[1]")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "'FEIN' is displayed", driver.findElement(By.xpath("//label[text()='FEIN']//following-sibling::div/div[1]")).getText(), null);
		}
		RC_Global.panelAction(driver, "close", "Customer Summary", false, true);
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
