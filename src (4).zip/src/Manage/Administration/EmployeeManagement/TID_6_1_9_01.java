package Manage.Administration.EmployeeManagement;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_9_01 {
	public static void EmployeeManagement_PreferredMethodOfContactField(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception {
		String name = "";
		
		RC_Global.login(driver);
		RC_Global.enterCustomerFocus(driver, "LS010143", true);
		
		RC_Global.navigateTo(driver, "Manage", "Administration", "Contacts");
		RC_Global.waitUntilPanelVisibility(driver, "Contacts", "TV", true, false);
		
		String driverName = driver.findElement(By.xpath("//div[h4[text()='Main - Customer']]//a/span[text()]")).getText();
		System.out.println(driverName);
		
		String firstName = driverName.split(" ")[0];
		System.out.println(firstName);
				
		RC_Global.panelAction(driver, "close", "Contacts", true, true);
		
		for(int iterator=0; iterator<2;iterator++) {
			RC_Global.navigateTo(driver, "Manage", "Administration", "Employee Management");
			if(iterator==0) {
				RC_Global.selectDropdownOption(driver, "Contact Type", "Main", true, true);
				RC_Global.clickButton(driver, "Search", true, true);
				
				RC_Global.waitElementVisible(driver, 40, "//tr[1]/td", "First row of Employee Management Grid", true, false);
				name = driver.findElement(By.xpath("//tr[td[normalize-space(text())='"+firstName+"']]/td[3]")).getText();
				RC_Global.clickUsingXpath(driver, "//tbody/tr[td[normalize-space(text())='"+firstName+"']]", "First Row of the Grid", true, false);
				
				RC_Global.waitUntilPanelVisibility(driver, "Edit Employee", "TV", true, false);
				RC_Global.panelAction(driver, "close", "Employee Management", true, true);
				RC_Global.panelAction(driver, "expand", "Edit Employee", true, true);
			}
			else {
				RC_Global.clickButton(driver, "Create", true, true);
				RC_Global.waitUntilPanelVisibility(driver, "Create Employee", "TV", true, false);
				RC_Global.panelAction(driver, "close", "Employee Management", true, true);
				RC_Global.panelAction(driver, "expand", "Create Employee", true, true);
				RC_Manage.editEmployeeForm(driver, "LS010143", "Sample", "Test"+RandomStringUtils.randomNumeric(2), "123 S 4th St 1909", "Miami", "FL", "23567-6760", "Email","",RandomStringUtils.randomAlphanumeric(10)+"h@sfleet.com");
			}
			
			
			RC_Global.createNode(driver, "Verify Preferred Contact Method label is located under Distribution Method ");
			if(driver.findElements(By.xpath("//div[label[text()='Distribution Method *']]/following-sibling::div/label/span[text()='Preferred Contact Method']")).size()>0)
				queryObjects.logStatus(driver, Status.PASS, "Preferred Contact Method label is located under Distribution Method", "Verification Successful", null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Preferred Contact Method label is located under Distribution Method", "Preferred Contact Method is not located as expected", null);
			
			
			RC_Global.createNode(driver, "Verify Preferred Contact Method is for Internal Users only");
			if(driver.findElements(By.xpath("//label[span[text()='Preferred Contact Method'] and contains(@class,'internal-only')]")).size()>0)
				queryObjects.logStatus(driver, Status.PASS, "Preferred Contact Method is for Internal Users only", "Verification Successful", null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify Preferred Contact Method is for Internal Users only", "Verification Failed", null);
			
			
			RC_Global.createNode(driver, "Verify Preferred Contact Method label is not Required Field");
			if(!driver.findElement(By.xpath("(//div/label/span)[6]")).getText().contains("*"))
				queryObjects.logStatus(driver, Status.PASS, "Preferred Contact Method is not a required field", "Verification Successful", null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Preferred Contact Method is not a required field", "Preferred Contact Method is required", null);
			
			
			RC_Global.createNode(driver, "Verify Preferred Contact Method field has blank value by default");
			Select select = new Select(driver.findElement(By.xpath("//div/select[@name = 'preferredContactMethod']")));
			WebElement option = select.getFirstSelectedOption();
			String defaultItem = option.getText();
			
			if(defaultItem.equalsIgnoreCase(""))
				queryObjects.logStatus(driver, Status.PASS, "Preferred Contact Method has a blank default value", "Verification Successful", null);
			else
				queryObjects.logStatus(driver, Status.INFO, "Preferred Contact Method has a blank default value", "Preferred Contact Method is not blank by default", null);
		
			
			RC_Global.createNode(driver, "Verify selection options");
			List<WebElement> preferredContactMethod = driver.findElements(By.xpath("//select[@name = 'preferredContactMethod']/option"));
			int iter = 0;
			
			String[] prefContMethd = {"", "Cell", "Work", "Email"};
			for(WebElement pcm:preferredContactMethod) {
				if(pcm.getText().equalsIgnoreCase(prefContMethd[iter])) {
					iter++;
				}
					
				else
					queryObjects.logStatus(driver, Status.FAIL, "Preferred Contact Method option ", prefContMethd[iter]+" is not available", null);
			}
			
			
			RC_Global.createNode(driver, "Verify Preferred Contact Method functionality");
			
			
			RC_Global.clickUsingXpath(driver, "//div/select[@name = 'preferredContactMethod']", "Dropdown Selection", true, false);
			RC_Global.clickUsingXpath(driver, "//div/select[@name = 'preferredContactMethod']/option[text()='Email']", "Dropdown Selection", true, false);
			
			boolean emailMandatory = driver.findElements(By.xpath("//label[text()='Email']/span[not (@class= 'ng-hide') and text()=' *']")).size()>0;
			if(emailMandatory)
				queryObjects.logStatus(driver, Status.PASS, "After Preferred Contact Method is selected, ", "email is mandatory", null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "After Preferred Contact Method is selected, ", "email should be mandatory", null);
			
			WebElement email = driver.findElement(By.xpath("//div[label[text()='Email']]/div/input"));
			String oldEmail = driver.findElement(By.xpath("//div[label[text()='Email']]/div/input")).getAttribute("value");
			RC_Global.enterInput(driver, RandomStringUtils.randomAlphanumeric(10)+"@testmail.com", email, true, false);
					
			Select selection = new Select(driver.findElement(By.xpath("//select[@name = 'distributionMethod']")));
			WebElement options = selection.getFirstSelectedOption();
			String defaultItemDisp = options.getText();
			
			if(defaultItemDisp.equalsIgnoreCase("")) {
//				queryObjects.logStatus(driver, Status.PASS, "Preferred Contact Method has a blank default value", "Verification Successful", null);
				RC_Global.selectDropdownOption(driver, "distributionMethod", "Email", true, false);
			}
			RC_Global.clickUsingXpath(driver, "(//button[text()=' Save '])[1]", "Save button", true, true);
			Thread.sleep(3000);
			if(driver.findElements(By.xpath("//h3[text()='Potential Duplicate Employee Detected']")).size()>0) {
				JavascriptExecutor executor = (JavascriptExecutor)driver;
				executor.executeScript("document.body.style.zoom = '70%'");
				executor.executeScript("arguments[0].click()", driver.findElement(By.xpath("//div[label[text()='New Employee (As Entered)']]/preceding-sibling::div[1]/input")));
				WebElement element = driver.findElement(By.xpath("//button[text()='OK']"));
				Thread.sleep(1000);
				executor.executeScript("arguments[0].click();", element);
				Thread.sleep(1000);
				executor.executeScript("document.body.style.zoom = '100%'");
				Thread.sleep(2000);
			}
			
			if(driver.findElements(By.xpath("//h3[span[text()='Invalid '] and span[text()=' address entered.']]")).size()>0) {
				RC_Global.clickButton(driver, "Save As Entered", true, false);
				Thread.sleep(1000);
			}
			if(driver.findElements(By.xpath("//h3[text()='Potential Duplicate Employee Detected']")).size()>0) {
				JavascriptExecutor executor = (JavascriptExecutor)driver;
				executor.executeScript("document.body.style.zoom = '70%'");
				executor.executeScript("arguments[0].click()", driver.findElement(By.xpath("//div[label[text()='New Employee (As Entered)']]/preceding-sibling::div[1]/input")));
				WebElement element = driver.findElement(By.xpath("//button[text()='OK']"));
				Thread.sleep(1000);
				executor.executeScript("arguments[0].click();", element);
				Thread.sleep(1000);
				executor.executeScript("document.body.style.zoom = '100%'");
				Thread.sleep(2000);
			}
			RC_Manage.waitUntilMethods(driver, "(//button[text()=' Save '])[2]/div[@ng-show='isSaving']","class","ng-hide", "attribute visible");	
			try {
				if(iterator==0)
					RC_Global.waitElementVisible(driver, 50, "//h4[text()='Employee Updated Successfully']", "Save Successful", true, false);
				else
					RC_Global.waitElementVisible(driver, 50, "//h4[text()='Employee Created Successfully']", "Save Successful", true, false);
			}
			catch(Exception e) {
				queryObjects.logStatus(driver, Status.FAIL, "Save Unsuccessful", "Save successful message not displayed", e);
			}
			
			RC_Global.createNode(driver, "Employee History Validation");
			RC_Global.clickLink(driver, "History", true, false);
			RC_Global.waitUntilPanelVisibility(driver, "Employee History", "TV", true, false);
			if(iterator==0)
				RC_Global.panelAction(driver, "close", "Edit Employee", true, false);
			else
				RC_Global.panelAction(driver, "close", "Create Employee", true, false);
			
			RC_Global.panelAction(driver, "expand", "Employee History", true, false);
			Thread.sleep(2000);
			
			if(iterator==0) {
				RC_Global.clickUsingXpath(driver, "(//td[text()='Employee Updated'])[1]", "Employee History Validation", true, emailMandatory);
				if(driver.findElement(By.xpath("((//tbody[tr[td[text()='Employee Updated']]])[1]//tr[2])[2]/td[23]")).getText().equalsIgnoreCase("Email"))
					queryObjects.logStatus(driver, Status.PASS, "Verifying Preferred Contact Method selection in Employee History", "Verification Successful", null);
				else
					queryObjects.logStatus(driver, Status.FAIL, "Verifying Preferred Contact Method selection in Employee History", "Verification Unsuccessful", null);
			}
			else {
				RC_Global.clickUsingXpath(driver, "(//td[text()='Employee Created'])[1]", "Employee History Validation", true, false);
				if(driver.findElement(By.xpath("((//tbody[tr[td[text()='Employee Created']]])[1]//tr[2])[2]/td[23]")).getText().equalsIgnoreCase("Email"))
					queryObjects.logStatus(driver, Status.PASS, "Verifying Preferred Contact Method selection in Employee History", "Verification Successful", null);
				else
					queryObjects.logStatus(driver, Status.FAIL, "Verifying Preferred Contact Method selection in Employee History", "Verification Unsuccessful", null);
			}
			RC_Global.panelAction(driver, "close", "Employee History", true, false);
			Thread.sleep(2000);
			RC_Global.createNode(driver, "Verify in Contacts - Main");
			RC_Global.navigateTo(driver, "Manage", "Administration", "Contacts");
			if(driver.findElements(By.xpath("//div[h4[text()='Main - Customer']]//a[contains(@href,'.com')]/following-sibling::span/strong[text()='(Preferred)']")).size()>0)
				queryObjects.logStatus(driver, Status.PASS, "Verify Preferred Contact Method in Contacts", "Verification Successful", null);
			else
				queryObjects.logStatus(driver, Status.INFO, "Verify Preferred Contact Method in Contacts", "Unable to verify Preferred Conatact Method in Contacts", null);
			RC_Global.panelAction(driver, "close", "Contacts", true, false);
			
			if(iterator == 0) {
				RC_Global.navigateTo(driver, "Manage", "Administration", "Employee Management");
				RC_Global.selectDropdownOption(driver, "Contact Type", "Main", true, true);
				RC_Global.clickButton(driver, "Search", true, true);
				
				RC_Global.waitElementVisible(driver, 40, "//tr[1]/td", "First row of Employee Management Grid", true, false);
				RC_Global.clickUsingXpath(driver, "//tr[td[normalize-space(text())='"+name+"']]", "Previously Selected Employee", true, false);
				
				RC_Global.waitUntilPanelVisibility(driver, "Edit Employee", "TV", true, false);
				RC_Global.panelAction(driver, "close", "Employee Management", true, false);
				RC_Global.panelAction(driver, "expand", "Edit Employee", true, false);
//				RC_Global.clickUsingXpath(driver, "//tr[td[text()='"+name+"']]", "Previously Selected Employee", false);// false for CreateNode
				
				email = driver.findElement(By.xpath("//div[label[text()='Email']]/div/input"));
				RC_Global.enterInput(driver, oldEmail, email, true, true);
				
				RC_Global.clickUsingXpath(driver, "//div/select[@name = 'preferredContactMethod']", "Dropdown Selection", true, false);
				RC_Global.clickUsingXpath(driver, "//div/select[@name = 'preferredContactMethod']/option[1]", "Dropdown Selection", true, false);
				
				RC_Global.clickUsingXpath(driver, "(//button[text()=' Save '])[1]", "Save button", true, true);
				Thread.sleep(3000);
				if(driver.findElements(By.xpath("//h3[span[text()='Invalid '] and span[text()=' address entered.']]")).size()>0) {
					RC_Global.clickButton(driver, "Save As Entered", true, false);
					Thread.sleep(3000);
				}
				if(driver.findElements(By.xpath("//h3[text()='Potential Duplicate Employee Detected']")).size()>0) {
					JavascriptExecutor executor = (JavascriptExecutor)driver;
					executor.executeScript("document.body.style.zoom = '70%'");
					executor.executeScript("arguments[0].click()", driver.findElement(By.xpath("//div[label[text()='New Employee (As Entered)']]/preceding-sibling::div[1]/input")));
					WebElement element = driver.findElement(By.xpath("//button[text()='OK']"));
					Thread.sleep(1000);
					executor.executeScript("arguments[0].click();", element);
					Thread.sleep(1000);
					executor.executeScript("document.body.style.zoom = '100%'");
					Thread.sleep(2000);
				}
				RC_Global.panelAction(driver, "close", "Edit Employee", true, false);
				
			}
		}		
		RC_Global.logout(driver, true);
		
		RC_Global.externalUserLogin(driver, "gentest", "");
		RC_Global.navigateTo(driver, "Manage", "Administration", "Employee Management");
		RC_Global.clickButton(driver, "Search", true, true);
		RC_Global.waitElementVisible(driver, 40, "//tr[1]/td", "First row of Employee Management Grid", true, false);
		
		RC_Global.clickUsingXpath(driver, "//tbody/tr[1]", "First Row of the Grid", true, false);
		
		RC_Global.waitUntilPanelVisibility(driver, "Edit Employee", "TV", true, false);
		RC_Global.panelAction(driver, "close", "Employee Management", true, false);
		RC_Global.panelAction(driver, "expand", "Edit Employee", true, false);
		
		if(driver.findElements(By.xpath("//div[label[text()='Distribution Method *']]/following-sibling::div/label/span[text()='Preferred Contact Method']")).size()==0)
			queryObjects.logStatus(driver, Status.PASS, "Preferred Contact Method label is not located under Distribution Method for External User", "Verification Successful", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Preferred Contact Method label is located under Distribution Method", "Preferred Contact Method is not as expected", null);
		
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
		
	}
}
