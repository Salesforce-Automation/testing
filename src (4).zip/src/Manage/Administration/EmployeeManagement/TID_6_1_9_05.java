package Manage.Administration.EmployeeManagement;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;
import com.gargoylesoftware.htmlunit.javascript.background.JavaScriptExecutor;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_9_05 {
	public void EmployeeManagement_AllValidationAppliesToTheEmployeeManagementScreen(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Employee Management";
		String DriverID ="";
		WebElement element = null;
		String emailID ="";
		WebElement element1=null;
		String WorkPhone ="";
		WebElement element2 =null;
		String EmailName="";
		WebElement element3=null;
		String CustomerNumber="LS010143";
		WebElement element4=null;
		WebElement element5=null;
		
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
        RC_Global.enterCustomerNumber(driver, CustomerNumber, "", "",false);
        
        RC_Global.clickButton(driver, "Search",false, true);

    //    RC_Global.clickUsingXpath(driver, "(//tr[@ng-click='employeeSelected(data)'])[1]", "select a row from grid", false);
        RC_Manage.employeeGridSelection(driver, "No", "Yes", false);
        RC_Global.panelAction(driver, "close","Employee Management",false, false);
        RC_Global.validateHeaderName(driver, "Edit Employee",true);
        RC_Global.panelAction(driver, "expand", "Edit Employee",false, false);
        
        RC_Global.waitElementVisible(driver, 60, "//legend[text()='Options']", "Options",false, false);
        
        //((JavascriptExecutor) driver).executeScript("document.body.style.zoom = '50%'");
        //Thread.sleep(1000);
        if(driver.findElements(By.xpath("//input[contains(@class,'ng-empty') and (@id='isEnrolledInFuelCheckBox')]")).size()>0)
        		{
        	RC_Global.clickUsingXpath(driver, "//input[contains(@class,'ng-empty') and (@id='isEnrolledInFuelCheckBox')]", "Enrolled In Fuel checkbox", false, true);
        	//    String DriverID= driver.findElement(By.xpath("//input[@placeholder='Fuel Driver ID']")).getText();
        	      
        	element=driver.findElement(By.xpath("//input[@placeholder='Fuel Driver ID']"));
        	     DriverID = element.getText();
        	    element.clear();
        	    
        		boolean FuelDriver=driver.findElements(By.xpath("//label[text()='Fuel Driver ID *']")).size()>0;
        		boolean EmployeeAssignment=driver.findElements(By.xpath("//legend[text()=' New Employee Assignment']//span[@class='']")).size()>0;
        		if(FuelDriver && EmployeeAssignment)
        		{
        			 queryObjects.logStatus(driver, Status.PASS, "FuelDriver & EmployeeAssignment is indicated as mandatory field ", "Successfully", null);
        		}
        		else

        	        {   
        	        	queryObjects.logStatus(driver, Status.FAIL, "FuelDriver & EmployeeAssignment is not indicated as mandatory field ", "", null);
        	        }
        		RC_Global.clickButton(driver, "Save", false, true);
        		RC_Global.verifyDisplayedMessage(driver, "Fuel Driver ID is a required field.", false);
        		}
        else if(driver.findElements(By.xpath("//input[contains(@class,'ng-not-empty') and (@id='isEnrolledInFuelCheckBox')]")).size()>0)
		{
	RC_Global.clickUsingXpath(driver, "//input[contains(@class,'ng-not-empty') and (@id='isEnrolledInFuelCheckBox')]", "Enrolled In Fuel uncheckbox", false, false);
	RC_Global.clickUsingXpath(driver, "//input[contains(@class,'ng-empty') and (@id='isEnrolledInFuelCheckBox')]", "Enrolled In Fuel checkbox", false, true);
	  //  String DriverID= driver.findElement(By.xpath("//input[@placeholder='Fuel Driver ID']")).getText();
		
	element=driver.findElement(By.xpath("//input[@placeholder='Fuel Driver ID']"));
		 DriverID = element.getText();
		element.clear();
		boolean FuelDriver=driver.findElements(By.xpath("//label[text()='Fuel Driver ID *']")).size()>0;
		boolean EmployeeAssignment=driver.findElements(By.xpath("//legend[text()=' New Employee Assignment']//span[@class='']")).size()>0;
		if(FuelDriver && EmployeeAssignment)
		{
			 queryObjects.logStatus(driver, Status.PASS, "FuelDriver & EmployeeAssignment is indicated as mandatory field ", "Successfully", null);
		}
		else

	        {   
	        	queryObjects.logStatus(driver, Status.FAIL, "FuelDriver & EmployeeAssignment is not indicated as mandatory field ", "", null);
	        }
		RC_Global.clickButton(driver, "Save", false, false);
		RC_Global.verifyDisplayedMessage(driver, "Fuel Driver ID is a required field.", false);
		}
        if(!DriverID.isEmpty())
        RC_Global.enterInput(driver, DriverID, element, false, false);
        else
        {
        	String Driver = "982314";
        	RC_Global.enterInput(driver, Driver, element, false, false);
        }
        
        if(driver.findElements(By.xpath("//label[text()='Distribution Method *']")).size()>0)
        {
        	RC_Global.clickUsingXpath(driver, "(//option[text()='Email'])[1]", "Email", false, false);
        	element1= driver.findElement(By.xpath("//input[contains(@ng-change,'EmailAddress') and (@placeholder='Email')]"));
        //	 element1=driver.findElement(By.xpath("//input[@placeholder='Fuel Driver ID']"));
    	     emailID = element1.getText();
    	    element1.clear();
	        boolean Email= driver.findElements(By.xpath("//label[text()='Email']//span[@class='']")).size()>0;
	       if(Email) 
	       {
	    	   queryObjects.logStatus(driver, Status.PASS, "Email is indicated as mandatory field ", "Successfully", null);  
	       }
	       else

	        {   
	        	queryObjects.logStatus(driver, Status.FAIL, "Email is not indicated as mandatory field ", "", null);
	        }
	       RC_Global.clickButton(driver, "Save", false, false);
   		   RC_Global.verifyDisplayedMessage(driver, "Email is a required field.", false);
   		 
   			   RC_Global.enterInput(driver, emailID, element1, false, false);
        }
        
       if(driver.findElements(By.xpath("//input[contains(@class,'ng-empty') and (@id='isEnrolledInPUCheckBox')]")).size()>0)
       {
    	   RC_Global.clickUsingXpath(driver, "//input[contains(@class,'ng-empty') and (@id='isEnrolledInPUCheckBox')]", "Enrolled In Personal Use checkbox", false, true);
    	   
    	   RC_Manage.checkBoxValidation(driver, "Create a New User Login ID ", false);
    	   
    	   element3=driver.findElement(By.xpath("//input[contains(@ng-change,'EmailAddress') and (@placeholder='Email')]"));
    	   EmailName = element3.getText();
    	   element3.clear();
    	   
  //  	   RC_Global.clickUsingXpath(driver, "//button[text()=' Clear Assignment ']", " Clear Assignment ", false);
    	   
    	   String CurrentAssigned= driver.findElement(By.xpath("(//div/span[@ng-if='originalCustomerId !== node.CustomerId'])[1]")).getText();
    	   if(CurrentAssigned.contains(CustomerNumber))
    	   {
    		   driver.findElement(By.xpath("//button[text()=' Clear Assignment ']"));
    		   RC_Global.clickButton(driver, "Save", false, false);
    		   RC_Global.verifyDisplayedMessage(driver, "Employee Assignment is a Required Field.", false);
    	   }
    	   
    	   else if(!CurrentAssigned.isEmpty())
    	   {
    		   driver.findElement(By.xpath("//button[text()=' Clear Assignment ']"));
    		   RC_Global.clickButton(driver, "Save", false, false);
    		   RC_Global.verifyDisplayedMessage(driver, "Employee Assignment is a Required Field.", false); 
    	   }
  	    
    	   boolean LoginID =driver.findElements(By.xpath("//label[text()='Create a New User Login ID ']")).size()>0;
    	   boolean EmailID =driver.findElements(By.xpath("//label[text()='Email']//span[@class='']")).size()>0;
    	   
    	   if(LoginID && EmailID)
   		{
   			 queryObjects.logStatus(driver, Status.PASS, "LoginID & EmailID is indicated as mandatory field ", "Successfully", null);
   		}
   		else

   	        {   
   	        	queryObjects.logStatus(driver, Status.FAIL, "LoginID & EmailID is not indicated as mandatory field ", "", null);
   	        }
   		RC_Global.clickButton(driver, "Save", false, false);
   		RC_Global.verifyDisplayedMessage(driver, "Email is a required field.", false);
   		
       }
       else if(driver.findElements(By.xpath("//input[contains(@class,'ng-not-empty') and (@id='isEnrolledInPUCheckBox')]")).size()>0)
       {
    	   RC_Global.clickUsingXpath(driver, "//input[contains(@class,'ng-not-empty') and (@id='isEnrolledInPUCheckBox')]", "Enrolled In Personal Use uncheckbox", false, false);
    	   RC_Global.clickUsingXpath(driver, "//input[contains(@class,'ng-empty') and (@id='isEnrolledInPUCheckBox')]", "Enrolled In Personal Use checkbox", false, false);
    	   
    	   RC_Manage.checkBoxValidation(driver, "Create a New User Login ID ", false);
    	   
    	   element3=driver.findElement(By.xpath("//input[contains(@ng-change,'EmailAddress') and (@placeholder='Email')]"));
    	   EmailName = element3.getText();
    	   element3.clear();
    	   
    //	   RC_Global.clickUsingXpath(driver, "//button[text()=' Clear Assignment ']", " Clear Assignment ", false);
    	   String CurrentAssigned= driver.findElement(By.xpath("(//div/span[@ng-if='originalCustomerId !== node.CustomerId'])[1]")).getText();

    	   if(CurrentAssigned.contains(CustomerNumber))
    	   {
    		   driver.findElement(By.xpath("//button[text()=' Clear Assignment ']"));
    		   RC_Global.clickButton(driver, "Save", false, false);
    		   RC_Global.verifyDisplayedMessage(driver, "Employee Assignment is a Required Field.", false);
    	   }
    	   
    	   else if(!CurrentAssigned.isEmpty())
    	   {
    		   driver.findElement(By.xpath("//button[text()=' Clear Assignment ']"));
    		   RC_Global.clickButton(driver, "Save", false, false);
    		   RC_Global.verifyDisplayedMessage(driver, "Employee Assignment is a Required Field.", false); 
    	   }
  	    
    	   boolean LoginID =driver.findElements(By.xpath("//label[text()='Create a New User Login ID ']")).size()>0;
    	   boolean EmailID =driver.findElements(By.xpath("//label[text()='Email']//span[@class='']")).size()>0;
    	   
    	   if(LoginID && EmailID)
   		{
   			 queryObjects.logStatus(driver, Status.PASS, "LoginID & EmailID is indicated as mandatory field ", "Successfully", null);
   		}
   		else

   	        {   
   	        	queryObjects.logStatus(driver, Status.FAIL, "LoginID & EmailID is not indicated as mandatory field ", "", null);
   	        }
   		RC_Global.clickButton(driver, "Save", false, false);
   		RC_Global.verifyDisplayedMessage(driver, "Email is a required field.", false);
   		RC_Global.verifyDisplayedMessage(driver, "Employee Assignment is a Required Field.", false); 
       }

     
        
        if(driver.findElements(By.xpath("//input[contains(@class,'ng-empty') and (@id='isEnrolledInDOCheckBox')]")).size()>0)
		{
        	RC_Global.clickUsingXpath(driver, "//input[contains(@class,'ng-empty') and (@id='isEnrolledInDOCheckBox')]", "Enrolled In Driver Ordering checkbox", false, true);
	//    String DriverID= driver.findElement(By.xpath("//input[@placeholder='Fuel Driver ID']")).getText();
	//	boolean FuelDriver=driver.findElements(By.xpath("//label[text()='Fuel Driver ID *']")).size()>0;
		boolean SelectorGroups=driver.findElements(By.xpath("//label[text()='Selector Group *']")).size()>0;
		if(SelectorGroups)
		{
			 queryObjects.logStatus(driver, Status.PASS, " SelectorGroups is indicated as required field ", "Successfully", null);
		}
		else

	        {   
	        	queryObjects.logStatus(driver, Status.FAIL, " SelectorGroups is not indicated as required field ", "", null);
	        }
		RC_Global.clickButton(driver, "Save", false, false);
		RC_Global.verifyDisplayedMessage(driver, "Selector Group is a Required Field for Employees Enrolled in Driver Ordering.", false);
		}
        else if(driver.findElements(By.xpath("//input[contains(@class,'ng-not-empty') and (@id='isEnrolledInDOCheckBox')]")).size()>0)
        {
        	RC_Global.clickUsingXpath(driver, "//input[contains(@class,'ng-not-empty') and (@id='isEnrolledInDOCheckBox')]", "Enrolled In Driver Ordering uncheckbox", false, false);
        	RC_Global.clickUsingXpath(driver, "//input[contains(@class,'ng-empty') and (@id='isEnrolledInDOCheckBox')]", "Enrolled In Driver Ordering checkbox", false, false);
      //  	String DriverID= driver.findElement(By.xpath("//input[@placeholder='Fuel Driver ID']")).getText();
      //  	boolean FuelDriver=driver.findElements(By.xpath("//label[text()='Fuel Driver ID *']")).size()>0;
        	boolean SelectorGroups =driver.findElements(By.xpath("//label[text()='Selector Group *']")).size()>0;
        	
        	if(SelectorGroups)
        	{
        		RC_Global.selectDropdownOption(driver, "SelectorGroupId", "2020 Pathfinder 24k", false, false);
        		queryObjects.logStatus(driver, Status.PASS, " SelectorGroups is indicated as required field ", "Successfully", null);
        	}
        	else

        	{   
        		queryObjects.logStatus(driver, Status.FAIL, " SelectorGroups is not indicated as required field ", "", null);
        	}
        	RC_Global.clickButton(driver, "Save", false, false);
        	RC_Global.createNode(driver, "Validation of selector group error message");
        	RC_Global.verifyDisplayedMessage(driver, "Selector Group is a Required Field for Employees Enrolled in Driver Ordering.", false);
}
         	element2 = driver.findElement(By.xpath("//input[@placeholder='Work Phone']"));
    	    WorkPhone = element2.getText();
   	        element2.clear();
   	         
   	        element4 = driver.findElement(By.xpath("//input[@placeholder='Cell Phone']"));
   	        element4.clear();
   	        
   	     element5 = driver.findElement(By.xpath("//input[@placeholder='Home Phone']"));
	     element5.clear();
   	        
    	    RC_Global.clickButton(driver, "Save", false, false);
    	    RC_Global.createNode(driver, "Validation of work phone error message");
    	    RC_Global.verifyDisplayedMessage(driver, "At least one phone number is required to enroll in driver ordering.", false);
    	    //((JavascriptExecutor) driver).executeScript("document.body.style.zoom = '100%'");
    	    RC_Global.logout(driver, false);	
			queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
    	   
          
        
	}
}
