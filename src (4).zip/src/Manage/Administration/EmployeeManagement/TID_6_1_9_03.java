package Manage.Administration.EmployeeManagement;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;


public class TID_6_1_9_03 {

	public void EmployeeManagement_EditEmployee_PreferredContactMethodTypeVerification (WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
		
		//WebElement element = null;
		String Einput = "";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Employee Management");
		RC_Global.validateHeaderName(driver, "Employee Management", true);
		RC_Global.enterCustomerNumber(driver, "LS008737", "", "",true);
		RC_Global.clickButton(driver, "Search",false, true);
		RC_Manage.employeeGridSelection(driver, "No", "Yes", false);
		RC_Global.validateHeaderName(driver, "Edit Employee", true);
		RC_Global.panelAction(driver, "close", "Employee Management", false, false);
		RC_Global.panelAction(driver, "expand", "Edit Employee", false, false);
		
		RC_Global.createNode(driver, "Preferred Contact Method drop down Values");
		List<WebElement> DropdownCnt= driver.findElements(By.xpath("(//span[text()='Preferred Contact Method']/following::div/select)[1]/option"));  
		for(int i=1; i<=DropdownCnt.size();i++) {
            WebElement Option = driver.findElement(By.xpath("(//span[text()='Preferred Contact Method']/following::div/select)[1]/option["+i+"]"));
            String Dropdown  = Option.getText();
            queryObjects.logStatus(driver, Status.PASS, "Preferred Contact Method drop down Values -->", Dropdown, null);
		}
		
		if(!(driver.findElements(By.xpath("//select[@name='distributionMethod']/option[@selected='selected' and text()='Email']")).size()==1))
		{
			RC_Global.clickUsingXpath(driver, "//select[@name='distributionMethod']/option[text()='Email']", "Preferred - cell option", false, false);
		}
		
		
		RC_Global.createNode(driver, "Validation of Preferred Contact Method - 'Cell'");
		RC_Global.clickUsingXpath(driver, "(//span[text()='Preferred Contact Method']/following::div/select)[1]/option[text()='Cell']", "Preferred - cell option", false, false);
		if(driver.findElements(By.xpath("//label[text()='Cell Phone']//span[@ng-show='isCellRequired()']")).size()>0)
		{
			String CellLabel = driver.findElement(By.xpath("//label[text()='Cell Phone']//span[@ng-show='isCellRequired()']")).getText();
			queryObjects.logStatus(driver, Status.PASS, "Cell phone label is indicated as required field "+CellLabel+"", "Successful", null);
			WebElement element = driver.findElement(By.xpath("//input[@placeholder='Cell Phone']"));
			String CPinput = element.getText();
			queryObjects.logStatus(driver, Status.INFO, "Cell phone input data --", CPinput, null);
		//	(270) 307-0465
			element.clear();
			RC_Global.clickButton(driver, "Save", false, false);
			Thread.sleep(1000);
			RC_Global.verifyDisplayedMessage(driver, "Cell Phone is a required field.", false);
				if(!CPinput.isEmpty()) {
					RC_Global.enterInput(driver, CPinput, element, false, false);
					RC_Global.clickButton(driver, "Save", false, false);		
					RC_Global.verifyDisplayedMessage(driver, "Employee Updated Successfully", false);
				}
				else {
					RC_Global.enterInput(driver, "(270) 307-0465", element, false, false);
					RC_Global.clickButton(driver, "Save", false, true);
					Thread.sleep(2000);
					if(driver.findElements(By.xpath("//span[text()=' address entered.']")).size()>0) {
						driver.findElement(By.xpath("//button[text()='Save As Entered']")).click();
						Thread.sleep(3000);
					}
					RC_Manage.waitUntilMethods(driver, "(//button[text()=' Save '])[2]/div[@ng-show='isSaving']","class","ng-hide", "attribute visible");
					RC_Global.verifyDisplayedMessage(driver, "Employee Updated Successfully", false);
				}
		}
		
		/*RC_Global.clickUsingXpath(driver, "(//span[text()='Preferred Contact Method']/following::div/select)[1]/option[text()='Work']", "Preferred - cell option", false);
		if(driver.findElements(By.xpath("//label[text()='Cell Phone']//span[@ng-show='isCellRequired()']")).size()>0)
		{
			String CellLabel = driver.findElement(By.xpath("//label[text()='Cell Phone']//span[@ng-show='isCellRequired()']")).getText();
			queryObjects.logStatus(driver, Status.PASS, "Cell phone label is indicated as required field "+CellLabel+"", "Successful", null);
			WebElement element = driver.findElement(By.xpath("//input[@placeholder='Cell Phone']"));
			String CPinput = element.getText();
			queryObjects.logStatus(driver, Status.INFO, "Cell phone input data --", CPinput, null);
		//	(270) 307-0465
			element.clear();
			RC_Global.clickButton(driver, "Save", false);
			RC_Global.verifyDisplayedMessage(driver, "Cell Phone is a required field.", false);
			
			RC_Global.enterInput(driver, CPinput, element, false);
			RC_Global.clickButton(driver, "Save", false);		
			RC_Global.verifyDisplayedMessage(driver, "Employee Updated Successfully", false);
		}
		*/
		//label[text()='Work Phone']//span[@ng-show='isWorkRequired()' and @class='']
		
		RC_Global.createNode(driver, "Validation of Preferred Contact Method - 'Work'");
		RC_Global.clickUsingXpath(driver, "(//span[text()='Preferred Contact Method']/following::div/select)[1]/option[text()='Work']", "Preferred - work option", false, false);
		if(driver.findElements(By.xpath("//label[text()='Work Phone']//span[@ng-show='isWorkRequired()' and @class='']")).size()>0)
		{
			String WorkLabel = driver.findElement(By.xpath("//label[text()='Work Phone']//span[@ng-show='isWorkRequired()' and @class='']")).getText();
			queryObjects.logStatus(driver, Status.PASS, "Work phone label is indicated as required field "+WorkLabel+"", "Successful", null);
			WebElement element = driver.findElement(By.xpath("//input[@placeholder='Work Phone']"));
			String WPinput = "(270) 307-0465";
			queryObjects.logStatus(driver, Status.INFO, "Work phone input data --", WPinput, null);
		//	(270) 307-0465
			element.clear();
			RC_Global.clickButton(driver, "Save", false, false);
			Thread.sleep(2000);
			if(driver.findElements(By.xpath("//span[text()=' address entered.']")).size()>0) {
				driver.findElement(By.xpath("//button[text()='Save As Entered']")).click();
				Thread.sleep(3000);
			}
			RC_Global.verifyDisplayedMessage(driver, "Work Phone is a required field.", false);
			
			RC_Global.enterInput(driver, WPinput, element, false, false);
			RC_Global.clickButton(driver, "Save", false, false);
			Thread.sleep(2000);
			if(driver.findElements(By.xpath("//span[text()=' address entered.']")).size()>0) {
				driver.findElement(By.xpath("//button[text()='Save As Entered']")).click();
				Thread.sleep(1000);
			}
			RC_Manage.waitUntilMethods(driver, "(//button[text()=' Save '])[2]/div[@ng-show='isSaving']","class","ng-hide", "attribute visible");
			RC_Global.verifyDisplayedMessage(driver, "Employee Updated Successfully", false);
		}
		
		
		if(driver.findElements(By.xpath("//label[text()='Cell Phone']//span[@ng-show='isCellRequired()' and @class='ng-hide']")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Cell phone label is not indicated as required field ", "Successfully", null);
		}
		else 
		{	queryObjects.logStatus(driver, Status.FAIL, "Cell phone label is indicated as required field ", "", null);
		}
		
		
		RC_Global.createNode(driver, "Validation of Preferred Contact Method - 'Email'");
		RC_Global.clickUsingXpath(driver, "(//span[text()='Preferred Contact Method']/following::div/select)[1]/option[text()='Email']", "Preferred - Email option", false, false);
		if(driver.findElements(By.xpath("//label[text()='Email']//span[@ng-show='isEmailRequired()' and @class='']")).size()>0)
		{
			String EmailLabel = driver.findElement(By.xpath("//label[text()='Email']//span[@ng-show='isEmailRequired()' and @class='']")).getText();
			queryObjects.logStatus(driver, Status.PASS, "Email label is indicated as required field "+EmailLabel+"", "Successful", null);
			WebElement element = driver.findElement(By.xpath("//input[@placeholder='Email' and @name='email']"));
			Einput = element.getAttribute("value");
			queryObjects.logStatus(driver, Status.INFO, "Email input data --", Einput, null);
		//	(270) 307-0465
			boolean cell = driver.findElements(By.xpath("//label[text()='Cell Phone']//span[@ng-show='isCellRequired()' and @class='ng-hide']")).size()>0;
			boolean work = driver.findElements(By.xpath("//label[text()='Cell Phone']//span[@ng-show='isCellRequired()' and @class='ng-hide']")).size()>0;
			if(cell && work)
		//	if((driver.findElements(By.xpath("//label[text()='Cell Phone']//span[@ng-show='isCellRequired()' and @class='ng-hide']")).size()>0) && (driver.findElements(By.xpath("//label[text()='Cell Phone']//span[@ng-show='isCellRequired()' and @class='ng-hide']")).size()>0))
			{
				queryObjects.logStatus(driver, Status.PASS, "Cell & Work phone label is not indicated as required field ", "Successfully", null);
			}
			else 
			{	queryObjects.logStatus(driver, Status.FAIL, "Cell & Work phone label is not indicated as required field ", "", null);
			}
			
			RC_Global.clickButton(driver, "Save", false, false);
			Thread.sleep(2000);
			if(driver.findElements(By.xpath("//span[text()=' address entered.']")).size()>0) {
				driver.findElement(By.xpath("//button[text()='Save As Entered']")).click();
				Thread.sleep(1000);
			}
			RC_Manage.waitUntilMethods(driver, "(//button[text()=' Save '])[2]/div[@ng-show='isSaving']","class","ng-hide", "attribute visible");
			RC_Global.verifyDisplayedMessage(driver, "Employee Updated Successfully", false);
			Thread.sleep(2000);
			
			element.clear();
			RC_Global.clickButton(driver, "Save", false, false);
			Thread.sleep(1000);
			RC_Global.verifyDisplayedMessage(driver, "Email is a required field.", false);
			
				if(!Einput.isEmpty()) {
				RC_Global.enterInput(driver, Einput, element, false, false);
				}
				else {
				RC_Global.enterInput(driver, "abc@automation.com", element, false, false);	
			}
			RC_Global.clickButton(driver, "Save", false, false);
			Thread.sleep(2000);
			if(driver.findElements(By.xpath("//span[text()=' address entered.']")).size()>0) {
				driver.findElement(By.xpath("//button[text()='Save As Entered']")).click();
				Thread.sleep(1000);
			}
			RC_Manage.waitUntilMethods(driver, "(//button[text()=' Save '])[2]/div[@ng-show='isSaving']","class","ng-hide", "attribute visible");
			RC_Global.verifyDisplayedMessage(driver, "Employee Updated Successfully", false);
		}
		else 
		{	queryObjects.logStatus(driver, Status.FAIL, "Email label is not indicated as required field ", "", null);
		}
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
		}
	}

