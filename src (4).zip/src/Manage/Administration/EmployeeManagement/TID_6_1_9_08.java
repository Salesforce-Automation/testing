package Manage.Administration.EmployeeManagement;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_9_08 {
	public void EmployeeManagement_ValidateEmployeeManagementSearchFilters(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Employee Management";
		String SearchFilters = "Customer Number;Employee First Name;Employee Last Name;Residential Address;City;State;Zip;Email;Employee ID;Contact Type;Employee Type;Employee Assignment;Status";
		String errorMsg = "Minimum of 1 search criteria is required. Please specify data in at least one field and click 'Search'.";
		
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.validateSpecifiedSearchFilters(driver, SearchFilters, false);
		RC_Global.clickButton(driver, "Search", true, true);
		
		RC_Global.verifyDisplayedMessage(driver, errorMsg, true);
		Thread.sleep(1000);
		String ContactType = "Accounts Payable;Billing;Delivery;Fuel;Main;Maintenance;Personal Use;Remarketing;Risk;Telematics;Title and Registration;Violations Management";
		RC_Global.dropdownValuesValidation(driver, ContactType, "//select[@id='contactType']", false, true);
		
		String EmployeeType ="Fleet Manager;Employee";
		RC_Global.dropdownValuesValidation(driver, EmployeeType, "//select[@id='employeeType']", false, true);
		RC_Global.panelAction(driver, "close","Employee Management",false, false);
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
