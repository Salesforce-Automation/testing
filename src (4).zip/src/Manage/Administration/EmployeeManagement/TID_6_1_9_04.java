package Manage.Administration.EmployeeManagement;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;


public class TID_6_1_9_04 {

public void UserSetup_CreateUsersFromEmployeeManagementWithDriverRole (WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
		
		String SearchFilters ="Unit Number;Customer Vehicle Number;Pool Name;Customer Number;Full VIN or Last 8;Driver First Name;Driver Last Name;Plate Number;Email Address;Plate State;Vehicle Status;Client Data Field;Client Data Value";
		String errorMsg = "Please enter a minimum of 8 characters for a VIN.";
		String DriverName = "";
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Employee Management");
		RC_Global.validateHeaderName(driver, "Employee Management", true);
		RC_Global.enterCustomerNumber(driver, "LS100200", "", "",false);
		RC_Global.clickUsingXpath(driver, "//label[text()='Status']/following-sibling::div//label[text()='Active']", "Status - Active", false, false);
        RC_Global.clickButton(driver, "Search",false, true);
        RC_Manage.employeeGridSelection(driver, "Yes", "No", false);
        DriverName = RC_Manage.driverFirstName + RC_Manage.driverLastName;
        queryObjects.logStatus(driver, Status.INFO, "DriverName from employee Management ",DriverName, null);
		RC_Global.validateHeaderName(driver, "User Detail", true);
		RC_Global.panelAction(driver, "expand", "User Detail", false, false);
		if(driver.findElements(By.xpath("//select/option[text()='Driver' and @ selected='selected']")).size()>0)
		{
			String UserRole = driver.findElement(By.xpath("//select/option[text()='Driver' and @ selected='selected']")).getText();
			queryObjects.logStatus(driver, Status.INFO, "User role for the selected username ",UserRole, null);	
			
		}
		else {
			RC_Global.panelAction(driver, "close", "User Detail", false, false);
			 RC_Global.clickButton(driver, "Reset",false, true);
			RC_Global.enterCustomerNumber(driver, "LS008320", "", "",false);
			RC_Global.clickUsingXpath(driver, "//label[text()='Status']/following-sibling::div//label[text()='Active']", "Status - Active", false, false);
	        RC_Global.clickButton(driver, "Search",false, true);
	        RC_Manage.employeeGridSelection(driver, "Yes", "No", false);
	        DriverName = RC_Manage.driverFirstName + RC_Manage.driverLastName;
	        queryObjects.logStatus(driver, Status.INFO, "DriverName from employee Management ",DriverName, null);
			RC_Global.validateHeaderName(driver, "User Detail", true);
			RC_Global.panelAction(driver, "expand", "User Detail", false, false);
			String UserRole = driver.findElement(By.xpath("//select/option[text()='Driver' and @ selected='selected']")).getText();
			queryObjects.logStatus(driver, Status.INFO, "User role for the selected username ",UserRole, null);	
			
		}
		RC_Manage.UserDetailSectionValidation(driver, "User Information", "Date Created", false);
		RC_Manage.UserDetailSectionValidation(driver, "User Information", "Date Last Updated", false);
		RC_Manage.UserDetailSectionValidation(driver, "User Information", "Last Login Date", false);
		RC_Manage.UserDetailSectionValidation(driver, "User Information", "Username", false);
		RC_Manage.UserDetailSectionValidation(driver, "User Information", "First Name", false);
		RC_Manage.UserDetailSectionValidation(driver, "User Information", "Last Name", false);
		RC_Manage.UserDetailSectionValidation(driver, "User Information", "Email", false);
		RC_Manage.UserDetailSectionValidation(driver, "User Information", "Active User", false);
		RC_Manage.UserDetailSectionValidation(driver, "User Information", "Account Locked", false);
		
		RC_Manage.UserDetailSectionValidation(driver, "Security", "Department", false);
		RC_Manage.UserDetailSectionValidation(driver, "Security", "Role", false);
		
		RC_Global.buttonStatusValidation(driver, "Advanced", "Enable", false);
		RC_Global.buttonStatusValidation(driver, "History", "Enable", false);
		
		RC_Global.clickUsingXpath(driver, "//button[text()='Advanced']", "Advanced button", false, true);
		RC_Global.clickUsingXpath(driver, "(//h4[text()='Permissions Details']/following::span[normalize-space(text())='Acquisition'])[1]", "Acquisition hyperlink", false, false);
		
		RC_Manage.PermissionDetail(driver, "Acquisition", "Acquisition Menu", "Acquisition Menu Module", false);
		
		RC_Manage.PermissionDetail(driver, "Acquisition", "Driver Order", "Driver Vehicle Order", false);
		RC_Manage.PermissionDetail(driver, "Acquisition", "Driver Order", "Driver View Orders", false);
		
		RC_Manage.PermissionDetail(driver, "Acquisition", "Factory Order", "Factory Order Base", false);
		RC_Manage.PermissionDetail(driver, "Acquisition", "Factory Order", "Initial Pricing", false);
		RC_Manage.PermissionDetail(driver, "Acquisition", "Factory Order", "Vehicle Order", false);
		RC_Manage.PermissionDetail(driver, "Acquisition", "Factory Order", "View Orders", false);
		
		String customerAss = driver.findElement(By.xpath("//input[@checked='checked']/following-sibling::span")).getText();
		if(customerAss.contains(RC_Manage.EmpAssignment))
		{
			queryObjects.logStatus(driver, Status.PASS, "Customer Assignment displays selected employee assignment on employee management screen ", "Successful", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Customer Assignment Not displays selected employee assignment on employee management screen ", "", null);
		}
		
		String EmployeeAss = driver.findElement(By.xpath("//div[@class='added-customer alert']/span")).getText();
		String Assignment = EmployeeAss.replaceAll("\\s", "");
		if(Assignment.contains(RC_Manage.Username) || Assignment.contains(DriverName))
		{
			queryObjects.logStatus(driver, Status.PASS, "Driver/Employee Assignment displayed with assigned Employee Name ", "Successful", null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Driver/Employee Assignment not displayed with assigned Employee Name  ", "", null);
		}
		RC_Global.panelAction(driver, "close", "User Detail", false, false);
		RC_Global.logout(driver, false);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
