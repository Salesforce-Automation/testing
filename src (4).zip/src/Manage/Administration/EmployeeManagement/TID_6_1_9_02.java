package Manage.Administration.EmployeeManagement;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_9_02 {
	public void EmployeeContactTypeAutoAssignment(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String firstName = RandomStringUtils.randomAlphabetic(5);
		String lastName = RandomStringUtils.randomAlphabetic(6);
		String emailID = RandomStringUtils.randomAlphanumeric(9)+"@abcd.com";
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Employee Management";

		RC_Global.login(driver);
		RC_Global.waitElementVisible(driver, 60, "//span[text()='LS000000 - Merchants Portfolio']", "", false, false);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.clickButton(driver, "Create", true, true);
		RC_Global.panelAction(driver, "close", "Employee Management", false, false);
		RC_Global.panelAction(driver, "expand", "Create Employee", false, false);
		String defaultEmployeeType = driver.findElement(By.xpath("//input[@placeholder='Employee Type']")).getAttribute("disabled");
		if(defaultEmployeeType.equals("true"))
		{
			queryObjects.logStatus(driver, Status.PASS, "There is no label or input field for 'Employee Type'", "", null);
			
			RC_Manage.editEmployeeForm(driver, "LS008474", firstName, lastName, "6209 Simpson", "Cincinnati", "TX", "45224-1837", "Email", "0123456789", emailID);
			Thread.sleep(2000);
			RC_Global.clickUsingXpath(driver, "(//button[text()=' Save '])[1]", "Save", true, true);
			Thread.sleep(2000);
			if((driver.findElements(By.xpath("//span[text()=' address entered.']")).size()>0))
			{
				RC_Global.clickButton(driver, "Save As Entered", true, false);
				RC_Manage.waitUntilMethods(driver, "(//button[text()=' Save '])[2]/div[@ng-show='isSaving']","class","ng-hide", "attribute visible");
				if(driver.findElements(By.xpath("//h4[text()='Employee Created Successfully']")).size()>0)
				{
					queryObjects.logStatus(driver, Status.PASS, "New employee is created", "", null);
				}
			}
			else 
			{
				if(driver.findElements(By.xpath("//h4[text()='Employee Created Successfully']")).size()>0)
				{
					queryObjects.logStatus(driver, Status.PASS, "New employee is created", "", null);
				}
			}
			if(driver.findElements(By.xpath("//h3[text()='Potential Duplicate Employee Detected']")).size()>0) {
				JavascriptExecutor executor = (JavascriptExecutor)driver;
				executor.executeScript("document.body.style.zoom = '70%'");
				executor.executeScript("arguments[0].click()", driver.findElement(By.xpath("//div[label[text()='New Employee (As Entered)']]/preceding-sibling::div[1]/input")));
				WebElement element = driver.findElement(By.xpath("//button[text()='OK']"));
				Thread.sleep(1000);
				executor.executeScript("arguments[0].click();", element);
				Thread.sleep(1000);
				executor.executeScript("document.body.style.zoom = '100%'");
				Thread.sleep(2000);
			}
			if(driver.findElements(By.xpath("//h4[text()='Employee Created Successfully']")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "New employee is created", "", null);
			}
			RC_Global.panelAction(driver, "close", "Create Employee", false, false);
			RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
			RC_Manage.searchEmployee(driver, "LS008474", firstName, lastName, "6209 Simpson", "Cincinnati", "TX", "45224-1837", emailID);
			RC_Global.clickButton(driver, "Search", true, false);
			RC_Global.waitElementVisible(driver, 20, "((//table/tbody/tr)[1])/td[1]", "Employee grid is displayed", true, false);
			boolean recordMatch = RC_Manage.newEmployeeValidation(driver,"LS008474", firstName, lastName, "6209 Simpson", "Cincinnati", "TX", "45224-1837");
			if(recordMatch)
			{
				queryObjects.logStatus(driver, Status.PASS, "Record Displayed", "", null);
				String employeeContactType = driver.findElement(By.xpath("((//table/tbody/tr)[1])/td[6]")).getText();
				if(employeeContactType.equals("Employee"))
				{
					queryObjects.logStatus(driver, Status.PASS, "The new employee is assigned the Employee contact type by default. ", "", null);
				}
				else
				{
					queryObjects.logStatus(driver, Status.FAIL, "The new employee is not assigned the Employee contact type by default. ", "", null);
				}
			}
			else
			{
				queryObjects.logStatus(driver, Status.FAIL, "Record Mistach", "", null);
			}
			Thread.sleep(10000);
			
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "There is label or input field for 'Employee Type'", "", null);
		}
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}


}
