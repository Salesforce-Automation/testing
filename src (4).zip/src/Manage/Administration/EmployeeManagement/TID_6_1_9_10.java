package Manage.Administration.EmployeeManagement;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_9_10 {

	public void EmployeeManagement_CreateEmployeeUsingExternalUser(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		String SearchFilters = "Customer Number;Employee First Name;Employee Last Name;Residential Address;City;State;Zip;Email;Employee ID;Contact Type;Employee Type;Employee Assignment;Status";
		String columnName ="Customer #;Customer Name;First Name;Last Name;Contact Type;Employee Type;Employee ID;Employee Assignment;Address;City;State;Zip;Email;User Name;Status;Fleet #;Fleet Name;Account #;Account Name;Sub-Account #;Sub-Account Name";
		
		// Login as External User
		RC_Global.externalUserLogin(driver, "kentuckytest", "yes");
		RC_Global.navigateTo(driver, "Manage","Administration","Employee Management");
		
		// Validate search fields
		RC_Global.validateSpecifiedSearchFilters(driver, SearchFilters, false);
		
		// Validate ContactType dropdown values
		String ContactType = "Accounts Payable;Billing;Delivery;Fuel;Main;Maintenance;Personal Use;Remarketing;Risk;Telematics;Title and Registration;Violations Management";
		RC_Global.dropdownValuesValidation(driver, ContactType, "//select[@id='contactType']", false, true);
		
		// Validate EmployeeType dropdown values
		String EmployeeType ="Fleet Manager;Employee";
		RC_Global.dropdownValuesValidation(driver, EmployeeType, "//select[@id='employeeType']", false, true);
		
		// Validate buttons present
		RC_Global.buttonStatusValidation(driver, "Search", "Enable", true);
		RC_Global.buttonStatusValidation(driver, "Reset", "Enable", true);
		RC_Global.buttonStatusValidation(driver, "Create", "Enable", true);
		
		// Validate result grid columns 
		RC_Global.clickButton(driver, "Search", true, true);
		RC_Global.waitElementVisible(driver, 60, "(//table//tr/td)[1]", "Result Grid", false, false);
		RC_Global.verifyColumnNames(driver, columnName,true);
		
		// Export to Excel
		RC_Global.downloadAndVerifyFileDownloaded(driver, "Export", "Export to Excel Functionality",true);
		
		// Create Employee
		RC_Global.clickButton(driver, "Create", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Create Employee", "TV", true, true);
		RC_Global.panelAction(driver, "close", "Employee Management", true, false);
		RC_Global.panelAction(driver, "expand", "Create Employee", true, false);
		if(driver.findElements(By.xpath("//select[@name='customer']/option[@selected='selected' and @label]")).size()>0)
		{
			String CusField = driver.findElement(By.xpath("//select[@name='customer']/option[@selected='selected' and @label]")).getText();
			queryObjects.logStatus(driver, Status.PASS, "Displays Customer # in customer Number field ", CusField, null);
		}
		String FirstNam = "Test"+ RandomStringUtils.randomAlphabetic(5).toLowerCase();
		String LastNam = "Emp" + RandomStringUtils.randomAlphabetic(5).toLowerCase()+ RandomStringUtils.randomNumeric(2);
		RC_Global.enterInput(driver, FirstNam, driver.findElement(By.xpath("//input[@name='firstName']")) , true, false);
        RC_Global.enterInput(driver, LastNam, driver.findElement(By.xpath("//input[@name='lastName']")) , true, false);
        RC_Global.enterInput(driver, "1461 Bluejay Rd"+RandomStringUtils.randomAlphanumeric(5),driver.findElement(By.xpath("//input[@name='addressLine1']")) , true, false);
        driver.findElement(By.xpath("//select[@name='state']")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//select[@name='state']//option[@label='ID']")).click(); 
        RC_Global.enterInput(driver, "Twin Falls", driver.findElement(By.xpath("//input[@name='city']")) , true, false);
        RC_Global.enterInput(driver, "83301-6025", driver.findElement(By.xpath("//input[@name='zip']")) , true, false);
        RC_Global.enterInput(driver, RandomStringUtils.randomAlphabetic(10).toLowerCase()+"@merchanttest.com", driver.findElement(By.xpath("//input[@name='email']")) , true, false);
        driver.findElement(By.xpath("//select[@name='distributionMethod']")).click();
        Thread.sleep(2000);
        
        driver.findElement(By.xpath("//select[@name='distributionMethod']//option[@label='Email']")).click();
        
        RC_Global.clickUsingXpath(driver, "(//button[text()=' Save '])[1]", "Save", true, false);
        Thread.sleep(1000);
        RC_Manage.waitUntilMethods(driver, "(//button[text()=' Save '])[2]/div[@ng-show='isSaving']","class","ng-hide", "attribute visible");
        if(driver.findElements(By.xpath("//span[text()=' address entered.']")).size()>0) {
               driver.findElement(By.xpath("//button[text()='Save As Entered']")).click();
               Thread.sleep(4000);
        }
        
        if(driver.findElements(By.xpath("//h3[text()='Potential Duplicate Employee Detected']")).size()>0) {
               JavascriptExecutor executor = (JavascriptExecutor)driver;
               executor.executeScript("document.body.style.zoom = '30%'");
               Thread.sleep(2000);
               WebElement Override= driver.findElement(By.xpath("//input[@value='override']"));
               executor.executeScript("arguments[0].scrollIntoView(true);",Override);
               executor.executeScript("arguments[0].click();", Override);
               //driver.findElement(By.xpath("//input[@value='override']")).click();
               Thread.sleep(2000); 
               WebElement Okbutton = driver.findElement(By.xpath("//button[text()='OK']"));
                  Thread.sleep(1000);
               executor.executeScript("arguments[0].click();", Okbutton);
               executor.executeScript("document.body.style.zoom = '30%'");
                  Thread.sleep(2000);
                 executor.executeScript("document.body.style.zoom = '100%'");    
        }
        if(driver.findElements(By.xpath("//span[text()=' address entered.']")).size()>0) {
            driver.findElement(By.xpath("//button[text()='Save As Entered']")).click();
            Thread.sleep(4000);
        }
        RC_Manage.waitUntilMethods(driver, "(//button[text()=' Save '])[2]/div[@ng-show='isSaving']","class","ng-hide", "attribute visible");
        RC_Global.verifyDisplayedMessage(driver, "Employee Created Successfully", true);
        Thread.sleep(5000);
        // Verify the created employee displays in history
        RC_Global.clickLink(driver, "History", true, false);
        RC_Global.panelAction(driver, "close", "Create Employee", true, false);
        RC_Global.panelAction(driver, "expand", "Employee History", true, false);
        
		RC_Global.clickUsingXpath(driver, "(//td[text()='Employee Created'])[1]", "Employee History Validation", true, false);
		if(driver.findElement(By.xpath("((//tbody[tr[td[text()='Employee Created']]])[1]//tr[2])[2]/td[4]")).getText().equalsIgnoreCase(LastNam))
		{
			queryObjects.logStatus(driver, Status.PASS, "Verifying entered Employee last name displays in Employee History", "Successfully", null);
		}
		else {
			queryObjects.logStatus(driver, Status.FAIL, "Created Employee is not displays in Employee History", " ", null);
		}
		RC_Global.panelAction(driver, "close", "Employee History", true, false);
		RC_Global.navigateTo(driver, "Manage","Administration","Employee Management");
		
		// Verify the Newly created employee displays in result grid
		RC_Global.enterInput(driver, FirstNam,driver.findElement(By.xpath("//input[@placeholder='Employee First Name']")) , true, true);
		RC_Global.enterInput(driver, LastNam,driver.findElement(By.xpath("//input[@placeholder='Employee Last Name']")) , true, true);
		RC_Global.clickButton(driver, "Search", true, true);
		RC_Global.waitElementVisible(driver, 30, "(//table//tr)[2]", "Result grid", true, false);
		String FirstNm = driver.findElement(By.xpath("(//table)[2]//tr[1]//td[3]")).getText();
		String LastNm = driver.findElement(By.xpath("(//table)[2]//tr[1]//td[4]")).getText();
		Thread.sleep(2000);
		if(FirstNm.contains(FirstNam) && LastNm.contains(LastNam))
			queryObjects.logStatus(driver, Status.PASS, "Created Employee is displayed in result grid", "Successfully", null);	
	    else {
		    queryObjects.logStatus(driver, Status.FAIL, "Created Employee is not displayed in result grid", "Failed", null);
	    }
		
		
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}

}
