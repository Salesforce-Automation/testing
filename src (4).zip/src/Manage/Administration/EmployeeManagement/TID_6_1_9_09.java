package Manage.Administration.EmployeeManagement;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_9_09 {

	 public void EmployeeManagement_ValidationOfResultGrid(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	    {
	        String menu = "Manage";
	        String firstSubMenu = "Administration";
	        String secondSubMenu = "Employee Management";
	        String columnName ="Customer #;Customer Name;First Name;Last Name;Contact Type;Employee Type;Employee ID;Employee Assignment;Address;City;State;Zip;Email;User Name;Status;Fleet #;Fleet Name;Account #;Account Name;Sub-Account #;Sub-Account Name";
	        
	        RC_Global.login(driver);
	        RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
	        RC_Global.enterCustomerNumber(driver, "LS008742", "", "",false);
	        RC_Global.clickButton(driver, "Search",false, true);
	        RC_Global.verifyColumnNames(driver, columnName,true);
	        
	 //       RC_Global.clickUsingXpath(driver,"(//tr[@ng-click='employeeSelected(data)'])[1]", "Select Row", false);
	        RC_Global.createNode(driver,"Verify a click a Row and navigate to Edit Employee page");
	        RC_Global.clickUsingXpath(driver,"(//tr[@ng-click='employeeSelected(data)'])[1]", "Select Row",false, true);
	        RC_Global.validateHeaderName(driver, "Edit Employee",true);
	        RC_Global.panelAction(driver, "close","Edit Employee",false, false);
	        RC_Global.panelAction(driver, "expand", "Employee Management",false, true);
	        
	        RC_Global.createNode(driver,"Verify Username displayed as hypertext and navigate to User Detail page");
	        RC_Manage.employeeGridSelection(driver, "Yes", "No", false);
	        
	      //  RC_Global.verifyFieldAsHyperLink(driver, "User Name", false);
	        
	        
	        RC_Global.validateHeaderName(driver, "User Detail",true);
	        RC_Global.panelAction(driver, "expand","User Detail",false, true);
	        RC_Global.panelAction(driver, "close","User Detail",false, false);
	        RC_Global.panelAction(driver, "expand", "Employee Management",false, false);
	        
	        RC_Global.downloadAndVerifyFileDownloaded(driver, "Export", "Export to Excel Functionality",true);
	      
	        RC_Global.logout(driver, false);	
			queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	        
	    }
	 
}
