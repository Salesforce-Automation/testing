package Manage.Administration.EmployeeManagement;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.LeaseWave.RC_LW_Global;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_9_07 {
	public void EmployeeManagement_CreateEmployee(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		String FirstName = RandomStringUtils.random(6, true, false).toUpperCase();
		String LastName = RandomStringUtils.random(7, true, false).toUpperCase();
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage","Administration","Employee Management");
		RC_Global.enterCustomerNumber(driver, "LS010143", "", "", true);
		RC_Global.clickButton(driver, "Create", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Create Employee", "TV", true, true);
		RC_Global.panelAction(driver, "close", "Employee Management", true, false);
		RC_Global.panelAction(driver, "expand", "Create Employee", true, false);
		RC_Manage.CreateEmployee(driver,FirstName,LastName, true);
		RC_Global.panelAction(driver, "close", "Create Employee", true, false);

		RC_Global.navigateTo(driver, "Manage","Administration","Alerts Management");
		RC_Global.enterCustomerNumber(driver, "LS010143", "", "", true);
		RC_Global.waitElementVisible(driver, 30, "//a[text()='Personal Use']","Personal Use hyperlink", true, false);
		RC_Global.clickUsingXpath(driver,"//a[text()='Personal Use']","Personal Use hyperlink", true, true);
		RC_Global.panelAction(driver, "close", "Alerts Management", true, false);
		RC_Global.panelAction(driver, "expand", "Alerts Management - Personal Use", true, true);
		RC_Global.clickUsingXpath(driver,"//tbody//tr[1]//td[5]","Alert Name Hyperlink", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Alert Setup - Missing Submissions", "TV", true, true);
		RC_Global.panelAction(driver, "close", "Alerts Management - Personal Use", true, false);
		RC_Global.panelAction(driver, "expand", "Alert Setup - Missing Submissions", true, false);
		RC_Global.clickUsingXpath(driver,"(//tbody)[2]//tr[1]//td[5]","Manage Hyperlink", true, true);
		RC_Global.waitElementVisible(driver, 30, "//h3[text()='Select Employee to Receive Alerts']","Select Employee to Receive Alerts", true, false);
		WebElement FName = driver.findElement(By.xpath("//input[@placeholder='Filter First Name']"));
		WebElement LName = driver.findElement(By.xpath("//input[@placeholder='Filter Last Name']"));
		RC_Global.enterInput(driver, FirstName,FName , true, true);
		RC_Global.enterInput(driver, LastName,LName , true, true);
		RC_Global.waitElementVisible(driver, 30, "(//table)[2]//tr[1]", "Employee details to display in grid", true, false);
		String FrsNm = driver.findElement(By.xpath("(//table)[2]//tr[1]//td[3]")).getText().toUpperCase();
		String LstNm = driver.findElement(By.xpath("(//table)[2]//tr[1]//td[4]")).getText().toUpperCase();
		Thread.sleep(2000);
		if(FrsNm.contains(FirstName) && LstNm.contains(LastName))
			queryObjects.logStatus(driver, Status.PASS, "Employee Created is displayed Alert Section", "Successfully", null);	
	    else {
		    queryObjects.logStatus(driver, Status.FAIL, "Employee Created is not displayed Alert Section", "Failed", null);
		   	RC_Global.endTestRun(driver);
	    }
		executor.executeScript("document.body.style.zoom = '30%'");
		WebElement DoneBttn= driver.findElement(By.xpath("//button[text()='Done']"));
		executor.executeScript("arguments[0].scrollIntoView(true);",DoneBttn);
		executor.executeScript("arguments[0].click();", DoneBttn);
		executor.executeScript("document.body.style.zoom = '30%'");
		Thread.sleep(2000);
		executor.executeScript("document.body.style.zoom = '100%'");
		RC_Global.logout(driver, false);
		
		RC_LW_Global.leaseWaveLogin(driver, true);  
		RC_Global.clickUsingXpath(driver,"//a[contains(text(),'Fleet Management')]","Fleet Management",true, true);
		RC_Global.waitElementVisible(driver, 50, "//span[text()='Fleet Management Menu']", "Fleet Management Menu",true, false);
	    String home =  driver.findElement(By.xpath("//span[text()='Fleet Management Menu']")).getText();
	    if(home.contains("FLEET MANAGEMENT MENU")) {
	    	queryObjects.logStatus(driver, Status.PASS, "Navigation to Fleet Management Menu", "Successfully", null);	
	    }
	    RC_Global.clickUsingXpath(driver,"//td[@accesskey='1' and text()='. Profiles']","Profiles",true, false);
	    RC_Global.clickUsingXpath(driver,"//td[@accesskey='D']","Driver",true, false);
	    RC_Global.clickUsingXpath(driver,"//tr[contains(@igurl,'DriverProfile')]/td[@accesskey='P']","Driver Profile",true, false);
		RC_Global.waitElementVisible(driver, 50, "//span[text()='Driver Profile List' and @id='ctl00_PageTitle']", "Asset List",true, true);
		driver.findElement(By.xpath("//input[contains(@name,'AccountNumber')]")).sendKeys("LS010143");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[contains(@name,'LastName')]")).sendKeys(LastName);
		Thread.sleep(2000);
		RC_Global.clickUsingXpath(driver,"//button[text()='Searc']","Search button",true, true);
		Thread.sleep(2000);
		RC_Global.clickUsingXpath(driver,"//button[text()='dit']","Edit button",true, true);
		Thread.sleep(2000);
		RC_Global.waitElementVisible(driver, 50, "//span[text()='Driver Profile Home' and @id='ctl00_PageTitle']", "Driver Profile Home",true, false);
		RC_Global.clickUsingXpath(driver,"//a[text()='Driver Profile' and @id='ctl00_NB_PH_DriverProfileNavBarUC_lnkDriverProfile']","Driver Profile",true, true);
		Thread.sleep(2000);
		RC_Global.waitElementVisible(driver, 50, "//span[text()='Personal' and @id='ctl00_F_PH_lblPersonal']", "Driver Profile page",true, false);
		RC_Global.clickUsingXpath(driver,"//button[text()='t Address']","Edit Address",true, true);
		Thread.sleep(2000);
		//RC_Global.clickButton(driver, "", true);
		WebElement Address1 =    driver.findElement(By.xpath("(//textarea[contains(@name,'ContactAddressUC1')])[1]"));
		Address1.clear();
    	Thread.sleep(1000);
    	String AddressId = "1300 Bluejay St"+RandomStringUtils.randomAlphabetic(1);
    	executor.executeScript("arguments[0].value='"+AddressId+"'", Address1);
    	Thread.sleep(2000);
 	    RC_Global.clickButton(driver, "e Contacts", true, false);
 	    RC_Global.clickButton(driver, "ave", true, true);
 	    Thread.sleep(2000);
		RC_Global.waitElementVisible(driver, 50, "//button[text()='lose']", "close button",true, false);
		RC_Global.clickUsingXpath(driver, "//button[text()='lose']", "Close", true, true);
		//RC_Global.waitElementVisible(driver, 50, "//span[text()='Fleet Management Menu']", "Fleet Management Menu",true);
		RC_LW_Global.leaseWaveLogOut(driver, false);
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage","Administration","Employee Management");
		RC_Global.enterCustomerNumber(driver, "LS010143", "", "", true);
		WebElement FirstName1 = driver.findElement(By.xpath("//input[@placeholder='Employee First Name']"));
		WebElement LastName2 = driver.findElement(By.xpath("//input[@placeholder='Employee Last Name']"));
		//WebElement Address = driver.findElement(By.xpath("//input[@placeholder='Address']"));

		RC_Global.enterInput(driver,FirstName,FirstName1 , true, true);
		RC_Global.enterInput(driver,LastName,LastName2 , true, true);
		//RC_Global.enterInput(driver,AddressId,Address , true);
		RC_Global.clickButton(driver, "Search", true, true);
		RC_Global.waitElementVisible(driver, 30, "//tbody//tr[1]", "Search Result", true, false);
		if (driver.findElements(By.xpath("//h5[span[contains(text(),'Edit Employee')]]")).size()>0) {
			RC_Global.clickUsingXpath(driver, "//tbody//tr[1]//td[1]", "Record from grid", true, true);
		}
		RC_Global.waitUntilPanelVisibility(driver, "Edit Employee", "TV", true, false);
		RC_Global.panelAction(driver, "close", "Employee Management", true, false);
		RC_Global.panelAction(driver, "expand", "Edit Employee", true, true);
		String UpdateAddress = driver.findElement(By.xpath("//input[@name='addressLine1']")).getAttribute("value").trim();
	    Thread.sleep(2000);
	    if(UpdateAddress.contains(AddressId))
	    	queryObjects.logStatus(driver, Status.PASS, "Employee Address is Updated", "Successfully", null);	
	    else {
		   queryObjects.logStatus(driver, Status.FAIL, "Employee Address failed to Updated", "Failed", null);
		   RC_Global.endTestRun(driver);
	    }
	    RC_Global.clickUsingXpath(driver,"//label[text()=' History ']","History",true, true);
		Thread.sleep(2000);
		RC_Global.waitUntilPanelVisibility(driver, "Employee History", "TV", true, false);
		RC_Global.panelAction(driver, "close", "Edit Employee", true, false);
		RC_Global.panelAction(driver, "expand", "Employee History", true, false);
		RC_Global.clickUsingXpath(driver,"//td[text()='Employee Created']","Employee Created",true, true);
		Thread.sleep(2000);
		//history check
		RC_Global.panelAction(driver, "close", "Employee History", true, false);

		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);   
	}
}
