package Manage.Administration.EmployeeManagement;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_9_06 {
	public static void EmployeeManagement_CreateANewEmployeeWithAssignedSelectorAndEmployeeAssignment(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Employee Management");
		RC_Global.enterCustomerNumber(driver, "LS010143", "", "", true);
		RC_Global.clickButton(driver, "Create", true, true);
		
		RC_Global.waitUntilPanelVisibility(driver, "Create Employee", "TV", true, false);
		RC_Global.panelAction(driver, "close", "Employee Management", true, false);
		RC_Global.panelAction(driver, "expand", "Create Employee", true, false);
		RC_Manage.editEmployeeForm(driver, "LS010143", RandomStringUtils.randomAlphabetic(5), RandomStringUtils.randomAlphanumeric(6), "123 S 4th St "+RandomStringUtils.randomNumeric(4), "Miami", "FL", "23567-6760", "Email","",RandomStringUtils.randomNumeric(9)+"@fleet.com");
		
		driver.findElement(By.xpath("//div[label[text()='Residential Address 2']]/div//input")).sendKeys("657 H 9th St "+RandomStringUtils.randomNumeric(4));
		driver.findElement(By.xpath("//div[label[text()='Cell Phone']]/div//input")).sendKeys("8"+RandomStringUtils.randomNumeric(9));
		driver.findElement(By.xpath("(//div[label[text()='Work Phone']]/div//input)[1]")).sendKeys("8"+RandomStringUtils.randomNumeric(9));
		driver.findElement(By.xpath("//div[label[text()='Home Phone']]/div//input")).sendKeys("3"+RandomStringUtils.randomNumeric(9));
		driver.findElement(By.xpath("//div[label[text()='Employee ID']]/div//input")).sendKeys("");
		RC_Global.selectDropdownOption(driver, "Status", "Active", true, true);
		RC_Global.selectDropdownOption(driver, "preferredContactMethod", "Email", true, true);
		driver.findElement(By.xpath("//div[label[text()='Employee Data Field 1']]/div//input")).sendKeys("Manager");
		driver.findElement(By.xpath("//div[label[text()='Employee Data Field 2']]/div//input")).sendKeys("Role");
		driver.findElement(By.xpath("//div[label[text()='Employee Data Field 3']]/div//input")).sendKeys("Field Status");
		//((JavascriptExecutor) driver).executeScript("document.body.style.zoom = '50%'");
		//Thread.sleep(1000);
		//Employee Assignment
		RC_Global.clickUsingXpath(driver, "//treeitem/ul/li[1]/div", "Employee Assigned to frst Fleet Level Customer Number", true, true);
		
		RC_Global.clickUsingXpath(driver, "//label[text()='Enrolled in Fuel ']/input", "Enrolled in Fuel checkbox", true, true);
		RC_Global.clickUsingXpath(driver, "//label[text()='Enrolled in Personal Use ']/input", "Enrolled in Personal Use checkbox", true, true);
//		RC_Global.clickUsingXpath(driver, "//label[text()='Enrolled in Driver Ordering ']/input", "Enrolled in Driver Ordering checkbox", true);
		
//		RC_Global.clickUsingXpath(driver, "//label[text()='Create a New User Login ID ']/input", "Create a New User Login ID checkbox", true);
//		RC_Global.clickUsingXpath(driver, "//label[text()='Email Receipt of Changes ']/input", "Email Receipt of Changes checkbox", true, true);
		
		//Email Validation cannot be automated
		
		
//		RC_Global.clickUsingXpath(driver, "//label[text()='Enrolled in Driver Ordering ']/input", "Enrolled in Driver Ordering checkbox", true);
		
		
		RC_Global.clickUsingXpath(driver, "(//button[text()=' Save '])[1]", "Save button", true, true);
		RC_Manage.waitUntilMethods(driver, "//div[contains(@class,'spinner ng-scope')]","class","ng-hide", "attribute visible");
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//h3[text()='Potential Duplicate Employee Detected']")).size()>0) {
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("document.body.style.zoom = '70%'");
			executor.executeScript("arguments[0].click()", driver.findElement(By.xpath("//div[label[text()='New Employee (As Entered)']]/preceding-sibling::div[1]/input")));
			WebElement element = driver.findElement(By.xpath("//button[text()='OK']"));
			Thread.sleep(1000);
			executor.executeScript("arguments[0].click();", element);
			Thread.sleep(1000);
			executor.executeScript("document.body.style.zoom = '100%'");
			Thread.sleep(2000);
		}

		if(driver.findElements(By.xpath("//h3[span[text()='Invalid '] and span[text()=' address entered.']]")).size()>0) {
			RC_Global.clickButton(driver, "Save As Entered", true, false);
			Thread.sleep(1000);
			RC_Manage.waitUntilMethods(driver, "//div[contains(@class,'spinner ng-scope')]","class","ng-hide", "attribute visible");
			Thread.sleep(2000);
		}
		
		if(driver.findElements(By.xpath("//h3[text()='Potential Duplicate Employee Detected']")).size()>0) {
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("document.body.style.zoom = '70%'");
			executor.executeScript("arguments[0].click()", driver.findElement(By.xpath("//div[label[text()='New Employee (As Entered)']]/preceding-sibling::div[1]/input")));
			WebElement element = driver.findElement(By.xpath("//button[text()='OK']"));
			Thread.sleep(1000);
			executor.executeScript("arguments[0].click();", element);
			Thread.sleep(1000);
			executor.executeScript("document.body.style.zoom = '100%'");
			Thread.sleep(5000);
		}
		RC_Manage.waitUntilMethods(driver, "(//button[text()=' Save '])[2]/div[@ng-show='isSaving']","class","ng-hide", "attribute visible");
		try {
			Thread.sleep(5000);
			if(driver.findElements(By.xpath("//h4[text()='Employee Created Successfully']")).size()>0)
				queryObjects.logStatus(driver, Status.PASS, "Save Successful", "Save successful message displayed", null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Save Unsuccessful", "Save successful message not displayed", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Save Unsuccessful", "Save successful message not displayed", e);
		}
		
		if(driver.findElements(By.xpath("//div[div[div[label[text()='Enrolled in Personal Use ']]]]/following-sibling::div//label[text()='Enrolled in Driver Ordering ']")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "'Enrolled in Driver Ordering' is displayed below 'Enrolled in Personal Use'", "Verification Successful", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify 'Enrolled in Driver Ordering' is displayed below 'Enrolled in Personal Use'", "Verification Failed", null);
		
		if(driver.findElements(By.xpath("//select[@name='SelectorGroupId']")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Selector Group dropdown is displayed", "Verification Successful", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Selector Group dropdown is displayed", "Verification Failed", null);
		
		RC_Global.clickUsingXpath(driver, "//label[text()='Enrolled in Driver Ordering ']/input", "Enrolled in Driver Ordering checkbox", true, true);
		Thread.sleep(3000);
//		RC_Global.clickUsingXpath(driver, "//select[@name='SelectorGroupId']", "Dropdown Selection", true);
		String selector = driver.findElement(By.xpath("//select[@name='SelectorGroupId']/option[2]")).getText();
		RC_Global.clickUsingXpath(driver, "//select[@name='SelectorGroupId']/option[2]", "Dropdown Selection", true, false);
		
		RC_Global.clickUsingXpath(driver, "(//button[text()=' Save '])[1]", "Save button", true, true);
		RC_Manage.waitUntilMethods(driver, "//div[contains(@class,'spinner ng-scope')]","class","ng-hide", "attribute visible");
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//h3[text()='Potential Duplicate Employee Detected']")).size()>0) {
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("document.body.style.zoom = '70%'");
			executor.executeScript("arguments[0].click()", driver.findElement(By.xpath("//div[label[text()='New Employee (As Entered)']]/preceding-sibling::div[1]/input")));
			WebElement element = driver.findElement(By.xpath("//button[text()='OK']"));
			Thread.sleep(1000);
			executor.executeScript("arguments[0].click();", element);
			Thread.sleep(1000);
			executor.executeScript("document.body.style.zoom = '100%'");
			Thread.sleep(2000);
		}

		if(driver.findElements(By.xpath("//h3[span[text()='Invalid '] and span[text()=' address entered.']]")).size()>0) {
			RC_Global.clickButton(driver, "Save As Entered", true, false);
			Thread.sleep(1000);
			RC_Manage.waitUntilMethods(driver, "//div[contains(@class,'spinner ng-scope')]","class","ng-hide", "attribute visible");
			Thread.sleep(2000);
		}
		
		if(driver.findElements(By.xpath("//h3[text()='Potential Duplicate Employee Detected']")).size()>0) {
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("document.body.style.zoom = '70%'");
			executor.executeScript("arguments[0].click()", driver.findElement(By.xpath("//div[label[text()='New Employee (As Entered)']]/preceding-sibling::div[1]/input")));
			WebElement element = driver.findElement(By.xpath("//button[text()='OK']"));
			Thread.sleep(1000);
			executor.executeScript("arguments[0].click();", element);
			Thread.sleep(1000);
			executor.executeScript("document.body.style.zoom = '100%'");
			Thread.sleep(2000);
		}
		
		try {
			Thread.sleep(5000);
			if(driver.findElements(By.xpath("//h4[text()='Employee Updated Successfully']")).size()>0)
				queryObjects.logStatus(driver, Status.PASS, "Save Successful", "Save successful message displayed", null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Save Unsuccessful", "Save successful message not displayed", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Save Unsuccessful", "Save successful message not displayed", e);
		}
		//((JavascriptExecutor) driver).executeScript("document.body.style.zoom = '100%'");
		
		RC_Global.createNode(driver, "Employee History Validation");
		RC_Global.clickLink(driver, "History", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Employee History", "TV", true, true);
		RC_Global.panelAction(driver, "close", "Create Employee", true, false);
		
		RC_Global.panelAction(driver, "expand", "Employee History", true, false);
		Thread.sleep(2000);
		RC_Global.clickUsingXpath(driver, "(//td[text()='Employee Created'])[1]", "Employee History Validation", true, false);
		RC_Global.clickUsingXpath(driver, "(//td[text()='Employee Updated'])[1]", "Employee History Validation", true, false);
		if(driver.findElement(By.xpath("//tbody/tr[td[text()='Employee Created']]/following-sibling::tr//tr[2]/td[23]")).getText().equalsIgnoreCase("Email"))
			queryObjects.logStatus(driver, Status.PASS, "Verifying Preferred Contact Method selection in Employee History", "Verification Successful", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verifying Preferred Contact Method selection in Employee History", "Verification Unsuccessful", null);
		
		if(driver.findElement(By.xpath("//tbody/tr[td[text()='Employee Updated']]/following-sibling::tr//tr[2]/td[26]")).getText().equalsIgnoreCase(selector))
			queryObjects.logStatus(driver, Status.PASS, "Verifying Preferred Contact Method selection in Employee History", "Verification Successful", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verifying Preferred Contact Method selection in Employee History", "Verification Unsuccessful", null);
		
		RC_Global.panelAction(driver, "close", "Employee History", true, false);
		Thread.sleep(2000);
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
		
		
	}
}
