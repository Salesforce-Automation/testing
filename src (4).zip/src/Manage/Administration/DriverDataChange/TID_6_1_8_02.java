package Manage.Administration.DriverDataChange;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_8_02 {
	public static void EmployeeAssignedToActiveVehicle_AddressChange(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		String cusNo = "LS008474";
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Driver Data Change");
		RC_Global.enterCustomerNumber(driver, cusNo, "", "", true);
		
		driver.findElement(By.xpath("//label[text()='Vehicle Status']/following-sibling::select/option[text()='Active lease']")).click();//Unselect 'Active lease'
		RC_Global.clickButton(driver, "Search", false,true);
		
		RC_Global.waitElementVisible(driver, 30, "//tr[1]/td", "First Row of Grid", false,true);
		RC_Manage.driverSelection(driver, true);
		RC_Global.waitUntilPanelVisibility(driver,"Driver Details", "TV", true,true);
		//RC_Global.panelAction(driver, "expand", "Driver Details", true,false);
		Thread.sleep(2000);
		String address1 = driver.findElement(By.xpath("//input[@name='residentialAddress1Text']")).getAttribute("value");
		String unitNumber = driver.findElement(By.xpath("(//strong[text()='Unit Number: ']/following::a[@title='Open Vehicle Details'])[1]")).getText();
		String DriverFullName = driver.findElement(By.xpath("//input[@name='driverFullName']")).getAttribute("value");
		String[] driverName = DriverFullName.split(" ");
		int count = driverName.length;
		String firstName = "";
		String lastName = "";
		if(count>2)
		{
			firstName =  driverName[0];
			 lastName = driverName[2];
		}else {
		 firstName =  driverName[0];
		 lastName = driverName[1];
		}
		RC_Global.panelAction(driver, "close", "Driver Details", true,false);
		
		RC_Global.navigateTo(driver, "Manage", "Administration", "Employee Management");
		RC_Global.panelAction(driver, "close", "Driver Data Change", true,false);
		RC_Global.enterCustomerNumber(driver, cusNo, "", "", true);
		
		WebElement wFirstName = driver.findElement(By.xpath("//div[label[text()='Employee First Name']]/input"));
		WebElement wLastName = driver.findElement(By.xpath("//div[label[text()='Employee Last Name']]/input"));
		
		RC_Global.enterInput(driver, firstName, wFirstName, false,true);
		RC_Global.enterInput(driver, lastName, wLastName, false,true);
		
		RC_Global.clickButton(driver, "Search", true,true);
		
		RC_Global.waitElementVisible(driver, 30, "//tbody/tr[1]", "First Row of the Grid", false,true);
		if(driver.findElements(By.xpath("//tbody/tr")).size()>1) {
		RC_Global.clickUsingXpath(driver, "(//tr[td[text()='"+address1+" ']]/td[contains(text(),'"+firstName+"')])[1] ", "Choosing the previously selected Driver", false,true);
		}
		RC_Global.waitUntilPanelVisibility(driver, "Edit Employee", "TV", false,true);
		
		RC_Global.panelAction(driver, "close", "Employee Management", false,false);
		RC_Global.panelAction(driver, "expand", "Edit Employee", false,false);
		
		WebElement resAddress1 = driver.findElement(By.xpath("//div[label[text()='Residential Address 1 *']]/div/input"));
		RC_Global.enterInput(driver, address1+=(" "+RandomStringUtils.randomNumeric(1)), resAddress1, false,true);
		
		RC_Global.clickUsingXpath(driver, "//select[@name='distributionMethod']", "Distribution Method", false,true);
		RC_Global.clickUsingXpath(driver, "//select[@name='distributionMethod']/option[@label='Text Message']", "Text Message selection for Distribution Method", false,true);

		WebElement cellPhone = driver.findElement(By.xpath("//div[label[text()='Cell Phone']]/div/input"));
		RC_Global.enterInput(driver, RandomStringUtils.randomNumeric(10), cellPhone, false,true);
		
		RC_Global.clickButton(driver, "Save", true,true);
		Thread.sleep(3000);
		if(driver.findElements(By.xpath("//h3[span[text()='Invalid '] and span[text()=' address entered.']]")).size()>0) {
			address1 = driver.findElement(By.xpath("//div[label]/div[label[text()='Address 1:']]")).getText();
			address1 = address1.split(": ")[1];
			RC_Global.clickButton(driver, "Select Recommended Address", false,true);
		}
			
		RC_Global.waitElementVisible(driver, 30, "//h4[text()='Employee Updated Successfully']", "Save Successful Message", false,true);
		
		RC_Global.panelAction(driver, "close", "Edit Employee", false,false);
		
		RC_Global.navigateTo(driver, "Manage", "Administration", "Driver Data Change");
		
		RC_Global.enterCustomerNumber(driver, cusNo, "", "", true);
		WebElement wUnitNumber = driver.findElement(By.xpath("//div[label[text()='Unit Number']]/input"));
		RC_Global.enterInput(driver, unitNumber, wUnitNumber, false,true);
		RC_Global.clickButton(driver, "Search", true,true);
		
		RC_Global.waitUntilPanelVisibility(driver, "Driver Details", "TV", false,true);
		
		//RC_Global.panelAction(driver, "close", "Driver Data Change", false,false);
		//RC_Global.panelAction(driver, "expand", "Driver Details", false,false);

		RC_Global.clickUsingXpath(driver, "//a[text()='Apply Address To Vehicle ']", "Apply Address to Vehicle link", false,true);
		
		RC_Global.clickButton(driver, "Save", false,true);
		
		Thread.sleep(3000);
		RC_Global.waitElementVisible(driver, 30, "(//h4[text()='Update Successful'])[2]", "Save Successful Message", false,true);
		
		RC_Global.clickButton(driver, "History", true,true);
		
		RC_Global.waitUntilPanelVisibility(driver, "Driver Change", "TV", false,true);
		RC_Global.panelAction(driver, "close", "Driver Details", false,false);
		RC_Global.panelAction(driver, "expand", "Driver Change", false,false);
		
		RC_Global.clickUsingXpath(driver, "(//tr[1]/td[1])[1]", "Latest Change in History", false,true);
		if(driver.findElement(By.xpath("(//tr[2]/td[2]/table/tbody/tr[1]/td[2])[1]")).getText().equalsIgnoreCase("Vehicle Location Street Line 1"))
			queryObjects.logStatus(driver, Status.PASS, "Verify latest change update", "Verified successfully", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify latest change update", "Expected Change is not dispalyed", null);
		
		if(driver.findElement(By.xpath("(//tr[2]/td[2]/table/tbody/tr[1]/td[4])[1]")).getText().equalsIgnoreCase(address1))
			queryObjects.logStatus(driver, Status.PASS, "Verify latest change update", "Verified successfully", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify latest change update", "Expected Change is not dispalyed", null);
		
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
		
	}
}
