package Manage.Administration.DriverDataChange;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_8_13 {
	public static String UnitNumber="";
	public static String CustomerVehicleNumber;
	public static String DriverFirstName;
	public static String DriverLastName;
	public static String VIN;
	public static String Vinfst6dig;
	public static String Plate;
	public static String Email;
	public void DriverDataChange_ValidateSearchFilters (WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
		
		String SearchFilters ="Unit Number;Customer Vehicle Number;Pool Name;Customer Number;Full VIN or Last 8;Driver First Name;Driver Last Name;Plate Number;Email Address;Plate State;Vehicle Status;Client Data Field;Client Data Value";
		String errorMsg = "Please enter a minimum of 8 characters for a VIN.";
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Driver Data Change");
		RC_Global.validateHeaderName(driver, "Driver Data Change", true);
		RC_Global.validateSpecifiedSearchFilters(driver, SearchFilters, false);
		RC_Global.enterCustomerNumber(driver, "LS010116", "", "",true);
		RC_Global.buttonStatusValidation(driver, "Search", "Enable", false);
		RC_Global.buttonStatusValidation(driver, "Reset", "Enable", false);
		RC_Global.clickButton(driver, "Search",false,true);
		
		RC_Global.createNode(driver, "Driver Data Change Screen Search Filter Data's");
		RC_Global.waitElementVisible(driver,30,"//table//tbody//tr[1]","Grid",false,false);
        List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("//table//tbody//tr"));   
      //  int rowcnt=Getgridrowcnt.size();
       
        for(int i=1; i<Getgridrowcnt.size();i++) {
            WebElement sub= driver.findElement(By.xpath("//tr["+i+"]//td[4]"));
            Thread.sleep(2000);
            String CVN = sub.getText();
            if(!CVN.isEmpty()) {
                WebElement driverclmn = driver.findElement(By.xpath("//tbody//tr["+i+"]//td[5]"));
                Thread.sleep(2000);
                String drivername = driverclmn.getText();
                Thread.sleep(1000);
                if(!(drivername.equalsIgnoreCase("Unassigned") || drivername.contains("Pool")||drivername.contains("Unknown")||drivername.contains("Catering")) ) {
                UnitNumber = driver.findElement(By.xpath("(//tbody//tr["+i+"]//td[3])[1]")).getText();
                CustomerVehicleNumber = driver.findElement(By.xpath("(//tbody//tr["+i+"]//td[4])[1]")).getText();
                String DriverName[] = driver.findElement(By.xpath("(//tbody//tr["+i+"]//td[5])[1]")).getText().split(" ");
                DriverFirstName = DriverName[0];
        		DriverLastName = DriverName[1];
                VIN = driver.findElement(By.xpath("(//tbody//tr["+i+"]//td[6])[1]")).getText();
                Vinfst6dig = VIN.substring(0,6);
                String PlateNumber[] = driver.findElement(By.xpath("(//tbody//tr["+i+"]//td[10])[1]")).getText().split(" ");
                Plate = PlateNumber[0];
                Email = driver.findElement(By.xpath("(//tbody//tr["+i+"]//td[16])[1]")).getText();
                break;
                }
              } } 
        
        queryObjects.logStatus(driver, Status.INFO, "Unit Number data---->", UnitNumber, null);    
        queryObjects.logStatus(driver, Status.INFO, "Customer Vehicle Number data---->", CustomerVehicleNumber, null);
        queryObjects.logStatus(driver, Status.INFO, "Driver First Name data---->", DriverFirstName, null);
        queryObjects.logStatus(driver, Status.INFO, "Driver Last Name data---->", DriverLastName, null);
        queryObjects.logStatus(driver, Status.INFO, "VIN Number data---->", VIN, null);
        queryObjects.logStatus(driver, Status.INFO, "Vinfst6dig Number data---->", Vinfst6dig, null);
        queryObjects.logStatus(driver, Status.INFO, "Plate Number data---->", Plate, null);
        queryObjects.logStatus(driver, Status.INFO, "Email data---->", Email, null);
        
        RC_Global.clickButton(driver, "Reset",false,false);
        
        RC_Global.createNode(driver, "Driver Data Change Screen Unit Number Search Filter Functionality Validation");
        RC_Manage.searchFilters(driver, "LS010116","Unit Number", UnitNumber, "Driver Data Change", "Driver Details", "Manage", "Administration", "Driver Data Change", false);
		
		
		RC_Global.createNode(driver, "Driver Data Change Screen Customer Vehicle Number Search Filter Functionality Validation");
	//	RC_Manage.searchFilters(driver, "Vehicle Number", CustomerVehicleNumber, "Driver Data Change", "Driver Details", "Manage", "Administration", "Driver Data Change", false);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Driver Data Change");
		RC_Global.validateHeaderName(driver, "Driver Data Change", true);
		WebElement CVNSearchFilter = driver.findElement(By.xpath("//input[@placeholder='Vehicle Number']"));
		RC_Global.enterInput(driver, CustomerVehicleNumber, CVNSearchFilter, false,true);
		RC_Global.clickButton(driver, "Search",false,true);
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//span[text()='Driver Details']")).size()>0)
		{
			RC_Global.waitElementVisible(driver,30,"//span[text()='Driver Details']","Driver Details screen",false,true);
		//	RC_Global.panelAction(driver, "close", "Driver Details", false);
			driver.findElement(By.xpath("//h5[span[text()='Driver Details']]/i[@ng-click='closePanel()']")).click();
		}
		else
			RC_Global.clickButton(driver, "Reset",false,true);
		Thread.sleep(2000);
		
		RC_Global.createNode(driver, "Driver Data Change Screen Driver First Name Search Filters Funcionality Functionality Validation");
		RC_Manage.searchFilters(driver, "LS010116","Driver First Name", DriverFirstName, "Driver Data Change", "Driver Details", "Manage", "Administration", "Driver Data Change", false);
		
		
		RC_Global.createNode(driver, "Driver Data Change Screen Driver Last Name Search Filters Funcionality Functionality Validation");
		RC_Manage.searchFilters(driver, "LS010116","Driver Last Name", DriverLastName, "Driver Data Change", "Driver Details", "Manage", "Administration", "Driver Data Change", false);
		
		
		RC_Global.createNode(driver, "Driver Data Change Screen VIN Search Filter Functionality Validation");
		RC_Manage.searchFilters(driver, "LS010116","VIN", VIN, "Driver Data Change", "Driver Details", "Manage", "Administration", "Driver Data Change", false);
		
		 executor.executeScript("document.body.style.zoom = '30%'");
         Thread.sleep(2000);
         executor.executeScript("document.body.style.zoom = '100%'");
         Thread.sleep(2000);
         
		RC_Global.createNode(driver, "Driver Data Change Screen Error Message Validation for 6 digit VIN Number");		
		
		if(driver.findElements(By.xpath("//div[@class='panel-chrome']/h5/span[text()='Driver Data Change']")).size()>0)
		{WebElement VIN6digit = driver.findElement(By.xpath("//input[@placeholder='VIN']"));	
		RC_Global.enterInput(driver, Vinfst6dig, VIN6digit,false,true);
		RC_Global.clickButton(driver, "Search",true,true);
        Thread.sleep(2000);
	        if(driver.findElements(By.xpath("//span[text()='Driver Details']]")).size()>0)
			{
	        	driver.findElement(By.xpath("//h5[span[text()='Driver Details']]/i[@ng-click='closePanel()']")).click();
				queryObjects.logStatus(driver, Status.WARNING, "6 digit VIN Number data search not displaying error message", "", null);
			}
			else if (driver.findElements(By.xpath("//div[@class='panel-chrome']/h5/span[text()='Driver Data Change']")).size()>0) {
				RC_Global.verifyDisplayedMessage(driver, errorMsg,true);
				RC_Global.clickButton(driver, "Reset",false,true);
			}
		}
		else
		{
		RC_Global.navigateTo(driver, "Manage", "Administration", "Driver Data Change");
		WebElement VIN6digit = driver.findElement(By.xpath("//input[@placeholder='VIN']"));
		RC_Global.enterInput(driver, Vinfst6dig, VIN6digit,false,true);
		RC_Global.clickButton(driver, "Search",true,true);
        Thread.sleep(2000);
	        if(driver.findElements(By.xpath("//span[text()='Driver Details']")).size()>0)
			{
	        	driver.findElement(By.xpath("//h5[span[text()='Driver Details']]/i[@ng-click='closePanel()']")).click();
				queryObjects.logStatus(driver, Status.WARNING, "6 digit VIN Number data search not displaying error message", "", null);
			}
			else {
				RC_Global.verifyDisplayedMessage(driver, errorMsg,true);
				RC_Global.clickButton(driver, "Reset",false,true);
			}
		}
       
        
        RC_Global.createNode(driver, "Driver Data Change Screen Plate Number Search Filter Functionality Validation");
        RC_Manage.searchFilters(driver, "LS010116","Plate Number", Plate, "Driver Data Change", "Driver Details", "Manage", "Administration", "Driver Data Change", false);
        
		
		RC_Global.createNode(driver, "Driver Data Change Screen Email Search Filter Functionality Validation");
		RC_Manage.searchFilters(driver, "LS010116","Email Address", Email, "Driver Data Change", "Driver Details", "Manage", "Administration", "Driver Data Change", false);
		
		
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
}
}
