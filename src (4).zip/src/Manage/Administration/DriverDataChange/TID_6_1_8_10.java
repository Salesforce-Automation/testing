package Manage.Administration.DriverDataChange;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;


public class TID_6_1_8_10 {
	
	public void StandardReport_DriverChangeHistoryDetail_ToTrackVehicleAndDriverAddressChanges (WebDriver driver,BFrameworkQueryObjects queryobjects)throws Exception{
		String Firstname= "";
		String Lastname= "";
		WebDriverWait wait = new WebDriverWait(driver,30);
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Driver Data Change");
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "",true);
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Active lease", false);
		RC_Global.clickButton(driver, "Search", true,true);
		Thread.sleep(1000);
		RC_Global.waitElementVisible(driver, 30, "//table//tbody", "Driver Data Change grid Result", true,true);
	    
		RC_Manage.driverSelection(driver, false);
		RC_Manage.updateDriverName_DriverDetails(driver, "Yes", "No", "Yes", false);
		
		RC_Global.panelAction(driver, "close", "Driver Details", false,false);
		RC_Global.panelAction(driver, "close", "Driver Data Change", false,false);
		
		/********************** Report will generate by next day*******************/
		
	/*	RC_Global.navigateTo(driver, "Reporting", "Standard Reports", "Driver Change History Detail");
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "",true);
		WebElement element = driver.findElement(By.xpath("(//input[@ng-model='param.ParameterValue'])[1]"));
		RC_Global.enterInput(driver, RC_Manage.UnitNumber, element , false,true);
		RC_Global.clickButton(driver, "Generate Report", false,true);
		//error msg displayed on driver change history screen
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@ng-show='executingReport']")));
		RC_Global.waitElementVisible(driver, 30, "//table/tbody/tr[3]", "Grid Record", false,true);
		if(driver.findElements(By.xpath("//table/tbody/tr[3]")).size()>0)
		{
			queryobjects.logStatus(driver, Status.PASS, "Report generated ------->", "Successfully", null);
			List<WebElement> gridrowcnt= driver.findElements(By.xpath("//table/tbody/tr[@valign='top']"));
			for(int i=2;i<=gridrowcnt.size();i++)
			{
			String vehicleAdd = driver.findElement(By.xpath("//table/tbody/tr[@valign='top']["+i+"]/td[16]/div")).getText();
			
				if(vehicleAdd.contains(RC_Manage.VehicleAddress))
				{
					queryobjects.logStatus(driver, Status.PASS, "Vehicle Address column displays the address added under driver data change Menu------->", "Successfully", null);
				}
				else
				{
					queryobjects.logStatus(driver, Status.FAIL, "Vehicle Address column not displays the address added under driver data change Menu------->", "", null);
				}
			break;
			}
		}
		else if(driver.findElements(By.xpath("//*[text()='Report timed out due to data size.  For assistance please contact your client service representative.']")).size()>0)
		{
			RC_Global.verifyDisplayedMessage(driver, "Report timed out due to data size.  For assistance please contact your client service representative.", false);
			queryobjects.logStatus(driver, Status.FAIL, "Report not generated displays error msg", "", null);
		}
		else
		{
			queryobjects.logStatus(driver, Status.FAIL, "No Records displayed", "", null);
		}
		*/
		RC_Global.logout(driver, false);	
		BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
