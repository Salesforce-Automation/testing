package Manage.Administration.DriverDataChange;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_8_09 {
	public void CreateMaterialRequest(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Driver Data Change";

		RC_Global.login(driver);
		String portfolio = driver.findElement(By.xpath("//span[@ng-show='allCustomers']/span")).getText();
		queryObjects.logStatus(driver, Status.PASS, "Customer Focus Is To 'Merchants Portfolio'", portfolio, null);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.enterCustomerNumber(driver, "LS008474", "", "", false);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Manage.driverNameSelection(driver, "", false);
		RC_Global.waitElementVisible(driver, 30, "//span[text()='Driver Details']", "Driver Details grid is displayed", true,true);
		RC_Global.panelAction(driver, "close", "Driver Data Change", false,false);
		RC_Global.panelAction(driver, "expand", "Driver Details", false,false);
		RC_Global.clickButton(driver, " Materials Req. ", false,true);
		RC_Global.panelAction(driver, "close", "Driver Details", false,false);
		RC_Global.panelAction(driver, "expand", "Driver Materials Request", false,false);
		driver.findElement(By.xpath("//label[text()='Request Copy of Registration']")).click();
		driver.findElement(By.xpath("//label[text()='Request New Driver Kit']")).click();
		WebElement commentElement = driver.findElement(By.xpath("//textarea[@id='comments']"));
		RC_Global.enterInput(driver, "Testing", commentElement, false,true);
		RC_Global.clickButton(driver, "Alternate", false,true);
		WebElement addressElement= driver.findElement(By.xpath("//input[@placeholder='Address 1']"));
		String address= "110 S Texas Ave";
		RC_Global.enterInput(driver, address, addressElement, false,true);
		WebElement cityElement= driver.findElement(By.xpath("//input[@placeholder='City']"));
		String city = "Fort Worth";
		RC_Global.enterInput(driver, city, cityElement, false,true);
		RC_Global.selectDropdownOption(driver, "State", "TX", false,true);
		WebElement zipElement= driver.findElement(By.xpath("//input[@placeholder='Zip']"));
		String zip = "76109";
		RC_Global.enterInput(driver, zip, zipElement, false,true);
		//		WebElement countyElement= driver.findElement(By.xpath("//input[@placeholder='County']"));
		//		String county="";
		//RC_Global.enterInput(driver, county, countyElement, false);

		//RC_Global.clickUsingXpath(driver, "//label[text()='Email Receipt of Changes ']", "Email Receipt of Changes", false);
		RC_Global.clickButton(driver, "Submit", false,true);
		Thread.sleep(5000);
		if((driver.findElements(By.xpath("//span[text()=' address entered.']")).size()>0))
		{
			RC_Global.clickButton(driver, "Save As Entered", false,true);
			RC_Global.waitElementVisible(driver, 30, "//h4[text()='Driver Materials Successfully Updated']", "Driver Materials Successfully Updated", true,true);
			if(driver.findElement(By.xpath("//h4[text()='Driver Materials Successfully Updated']")).isDisplayed())
			{
				queryObjects.logStatus(driver, Status.PASS, "'Create Material Request' is successful", "", null);
			}
			else
			{
				queryObjects.logStatus(driver, Status.FAIL, "'Create Material Request' is not successful", "", null);
			}
		}
		else 
		{
			RC_Global.waitElementVisible(driver, 30, "//h4[text()='Driver Materials Successfully Updated']", "Driver Materials Successfully Updated", true,true);
			if(driver.findElement(By.xpath("//h4[text()='Driver Materials Successfully Updated']")).isDisplayed())
			{
				queryObjects.logStatus(driver, Status.PASS, "'Create Material Request' is successful", "", null);
			}
			else
			{
				queryObjects.logStatus(driver, Status.FAIL, "'Create Material Request' is not successful", "", null);
			}
		}
		RC_Global.panelAction(driver, "close", "Driver Materials Request", false,false);
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);



	}

}
