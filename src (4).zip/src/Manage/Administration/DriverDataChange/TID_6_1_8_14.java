package Manage.Administration.DriverDataChange;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_8_14{
	public void DriverDataChange_ValidateTheResultGrid(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String menu = "Manage";
        String firstSubMenu = "Administration";
        String secondSubMenu = "Driver Data Change";
        String columnName ="Customer #;Customer Name;Unit Number;CVN;Driver/Pool Name;VIN;Year;Make;Model;Plate;Address;City;State;Zip;Vehicle Status;Email Address;Fleet #;Fleet Name;Account #;Account Name;Sub-Account #;Sub-Account Name";
        
        RC_Global.login(driver);
        RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
        RC_Global.enterCustomerNumber(driver, "LS008742", "", "",false);
        RC_Global.clickButton(driver, "Search",false,true);
        RC_Global.verifyColumnNames(driver, columnName,true);
        
        RC_Global.createNode(driver,"Verify Unit Number as hypertext and navigate to Vehicle Details page");
        RC_Global.clickUsingXpath(driver,"//tbody//tr[1]/td[3]", "Unit Number",false,false);
        RC_Global.validateHeaderName(driver, "Vehicle Details",true);
        RC_Global.panelAction(driver, "close","Vehicle Details",false,false);
        RC_Global.panelAction(driver, "expand", "Driver Data Change",false,false);
        
        RC_Global.createNode(driver,"Verify CVN displayed as hypertext and navigate to Vehicle Details page");
        RC_Global.clickUsingXpath(driver,"//tbody//tr[3]/td[4]", "CVN",false,false);
        RC_Global.validateHeaderName(driver, "Vehicle Details",true);
        RC_Global.panelAction(driver, "close","Vehicle Details",false,false);
        RC_Global.panelAction(driver, "expand", "Driver Data Change",false,false);
        
        RC_Global.createNode(driver,"Verify Driver/Pool Name displayed as hypertext and navigate to Driver Details page");
        RC_Global.clickUsingXpath(driver,"//tbody//tr[1]/td[5]", "Driver/Pool Name",false,false);
        RC_Global.validateHeaderName(driver, "Driver Details",true);
        RC_Global.panelAction(driver, "close","Driver Details",false,false);
        RC_Global.panelAction(driver, "expand", "Driver Data Change",false,false);
        
        RC_Global.downloadAndVerifyFileDownloaded(driver, "Export", "Export to Excel Functionality",true);
        
        RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
        
	}
}
