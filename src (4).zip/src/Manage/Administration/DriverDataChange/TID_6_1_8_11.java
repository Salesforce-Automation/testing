package Manage.Administration.DriverDataChange;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.LeaseWave.RC_LW_Global;
import tools.LeaseWave.RC_LW_Manage;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_8_11 {

	public void AssignNewEmployeeToaVehicleOnAnActiveLeaseAndCheckInLeaseWave(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		String email = RandomStringUtils.randomAlphabetic(4); 
		String com = "@acrtinc.com";
		String Lastname = RandomStringUtils.randomAlphabetic(4);
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Employee Management");
		//RC_Global.enterCustomerNumber(driver, "LS008742", "", "", false);
		RC_Global.clickButton(driver, "Create", false,true);
		RC_Global.panelAction(driver, "close", "Employee Management", false,false);
		RC_Global.panelAction(driver, "expand", "Create Employee", false,true);
		RC_Manage.editEmployeeForm(driver, "LS008742", "Jessica", Lastname, "4500 Courthouse Blvd Ste 150", "Stow", "OH", "44224-6837", "Email", "(576) 453-5737", email+com);
		RC_Global.clickUsingXpath(driver, "//span[@title='10447 - 11001']", "Employee Assignment", false,true);
		RC_Global.clickUsingXpath(driver, "//input[contains(@ng-model,'IsEnrolledInPersonalUse')]", "Enrolled in Personal Use Checkbox", false,true);
		RC_Global.clickUsingXpath(driver, "(//button[normalize-space(text())='Save'])[1]", "Save", false,true);
		if(driver.findElements(By.xpath("//h3[text()='Potential Duplicate Employee Detected']")).size()>0){
            RC_Global.clickUsingXpath(driver, "//input[@type='radio' and @value='override']", "Modify Selected Employee with Entered Information", false,true);
            RC_Global.clickButton(driver, "OK", false,true);
        }
		Thread.sleep(3000);
		RC_Global.panelAction(driver, "close", "Create Employee", false,false);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Driver Data Change");
		//RC_Global.panelAction(driver, "expand", "Driver Data Change", false,false);
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", false);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.waitElementVisible(driver, 30, "//table//tbody", "Driver Data Change grid Result", true,true);
		RC_Manage.driverSelection(driver, false);
		//RC_Global.panelAction(driver, "close", "Driver Data Change", false);
		//RC_Global.panelAction(driver, "expand", "Driver Details", false,false);
		RC_Manage.updateDriverName_DriverDetails(driver, "Yes", "No", "Yes", false);
//		RC_Global.clickUsingXpath(driver,"//button[contains(@id,'topDriverSaveButton')]","Top Save button", false);
//		if(driver.findElements(By.xpath("//span[text()=' address entered.']")).size()>0){
//            RC_Global.clickButton(driver, "Save As Entered", false);
//        }
		Thread.sleep(2000);
		RC_Global.verifyDisplayedMessage(driver, "Update Successful", false);
		
		RC_Global.clickButton(driver, "History", true,true);
		RC_Global.panelAction(driver, "close", "Driver Details", false,true);
		RC_Global.panelAction(driver, "expand", "Driver Change - History", false,true);
		//String Username = driver.findElement(By.xpath("//span[@id='Span1']")).getText();
		String Modifiedby = driver.findElement(By.xpath("(//table/tbody/tr[1]/td[5])[1]")).getText().toUpperCase();
		
		if(driver.findElements(By.xpath("//table/tbody[1]/tr[1]/td[text()='"+RC_Manage.drivername+"']")).size()>0)
		{
			if(Modifiedby.contains(RC_Global.userLogged))
			{
				RC_Global.clickUsingXpath(driver, "(//table/tbody/tr[1]/td[1])[2]", "Changes", false,true);
				//----------------------------------
				String OldFirstName = driver.findElement(By.xpath("(//table/tbody/tr[1]/td[2][text()='First Name'])[1]/../td[3]")).getText();
				String OldLasttName = driver.findElement(By.xpath("(//table/tbody/tr[2]/td[2][text()='Last Name'])[1]/../td[3]")).getText();
				String NewFirstName = driver.findElement(By.xpath("(//table/tbody/tr[1]/td[2][text()='First Name'])[1]/../td[4]")).getText();
				String NewLastName = driver.findElement(By.xpath("(//table/tbody/tr[2]/td[2][text()='Last Name'])[1]/../td[4]")).getText();
				
				queryObjects.logStatus(driver, Status.INFO, "Old Driver First Name", OldFirstName, null);
				queryObjects.logStatus(driver, Status.INFO, "Old Driver Last Name", OldLasttName, null);
				queryObjects.logStatus(driver, Status.INFO, "New Driver First Name", NewFirstName, null);
				queryObjects.logStatus(driver, Status.INFO, "New Driver Last Name", NewLastName, null);
				//----------------------------------
				queryObjects.logStatus(driver, Status.INFO, "New Driver Address Modified By", Modifiedby, null);
				if(NewFirstName.contains(RC_Manage.Firstname))
				{
					queryObjects.logStatus(driver, Status.PASS, "Changed New employee "+NewFirstName+" is displayed in history", "Successfully", null);
				}
			
		RC_Global.navigateTo(driver, "Manage", "Administration", "Employee Management");
		RC_Global.panelAction(driver, "close", "Driver Data Change", false,false);
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", false);
		WebElement element=driver.findElement(By.xpath("//input[@placeholder='Employee Last Name']"));
		RC_Global.enterInput(driver, NewLastName, element, false,true);
			}
		}
		RC_Global.logout(driver, false);
		
		RC_LW_Global.leaseWaveLogin(driver,true);
		RC_LW_Manage.leaseWaveDriverAssignment(driver, false);
		RC_LW_Manage.leasewaveDriverDataChangeValidation(driver,"no", false);
		RC_LW_Global.leaseWaveLogOut(driver,false);
	}
}
