package Manage.Administration.DriverDataChange;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.RandomUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.LeaseWave.RC_LW_FleetServices;
import tools.LeaseWave.RC_LW_Global;
import tools.LeaseWave.RC_LW_Manage;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_8_04 {
	
	public void DriverDataChange_DriverAssignmentChange(WebDriver driver, BFrameworkQueryObjects queryObjects)throws Exception  {
		String Firstname= ""; String Lastname= "";
		String custNo = "8742"; String stAddress = ""; String verifyDate = ""; String setDate = "";
		System.out.println(RC_Manage.RandomSelection(driver));
		WebDriverWait wait = new WebDriverWait(driver,30);
		JavascriptExecutor executor = (JavascriptExecutor) driver;		
		RC_Global.login(driver);
		RC_Global.enterCustomerFocus(driver, custNo, true);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Driver Data Change");
		RC_Global.clickButton(driver, "Search", true,true);
		RC_Global.waitElementVisible(driver, 5, "//table//tbody", "Driver Data Change grid Result", true,true);
		//RC_Global.clickUsingXpath(driver, "//div[@table-scroll]", "Select the Vehicle Status column header", true,true);
		stAddress = RC_Manage.getAddress_DriverSelection(driver,"Address Change", true);
		
		
		RC_Manage.VehicleAddress = stAddress;
		if (stAddress!="") {
			RC_Global.waitElementVisible(driver, 5, "//h3[text()='Vehicle Information']", "Driver Details page", true,true);
			try {
				driver.findElement(By.xpath("//h5[span[contains(text(),'Driver Data Change')]]/i[@ng-click='closePanel()']")).click();
			} catch (Exception e) {}
			try {
				driver.findElement(By.xpath("//h5[span[contains(text(),'Driver Details')]]/i[contains(@ng-click,'maximize')]")).click();
			} catch (Exception e) {}
			
			RC_Global.enterInput(driver, stAddress, driver.findElement(By.xpath("//h3[text()='Vehicle Address']/..//input[@placeholder='Address 1']")), true,true);
			//Fill the mandatory fields
			setDate = RC_Manage.AddDateStr(0, "MM/dd/yyyy hh:mm", "", null, "");
			try {
				driver.findElement(By.xpath("//input[contains(@id,'dateTime')]")).clear();
				driver.findElement(By.xpath("//input[contains(@id,'dateTime')]")).sendKeys(setDate);
			} catch (Exception e) {}
			try {
				driver.findElement(By.xpath("//label[text()='test']/..//button[text()='Yes']")).click();
			} catch (Exception e) {}
			//RC_Global.enterInput(driver, setDate, driver.findElement(By.xpath("//input[contains(@id,'dateTime')]")), true,true);		
			//RC_Global.clickUsingXpath(driver, "//label[text()='test']/..//button[text()='Yes']", "Select the test field button", true,true);
			 try {
				 driver.findElement(By.xpath("//label[text()='Text']/..//input[@ng-model='data.clientDataValue.FieldValueText' and @required='required']")).sendKeys(RandomStringUtils.randomAlphabetic(5));
			} catch (Exception e) {}
			 try {
				 driver.findElement(By.xpath("//label[text()='Date']/..//input[@ng-model='data.clientDataValue.FieldValueText' and @required='required']")).sendKeys(setDate.substring(0, 10));
				} catch (Exception e) {}
			
			//label[text()='Date']/..//input[@ng-model="data.clientDataValue.FieldValueText" and @required="required"]
			RC_Global.clickButton(driver, "Save", true,true);
			if(driver.findElement(By.xpath("(//button[text()=' Save '])[1]")).getAttribute("class").contains("ng-hide")) {
				RC_Manage.waitUntilMethods(driver, "(//button[text()=' Save '])[2]/div[@ng-show='isSaving']","class","ng-hide", "attribute visible");
			} else {
            	if(driver.findElement(By.xpath("(//button[text()=' Save '])[2]")).getAttribute("class").contains("ng-hide")){
					RC_Manage.waitUntilMethods(driver, "(//button[text()=' Save '])[1]/div[@ng-show='isSaving']","class","ng-hide", "attribute visible"); }
			}
//			try {
//				RC_Manage.selectFromDropdown(driver, "Fuel Only", driver.findElement(By.xpath("//label[text()='Vehicle Segment']/..//select")));
//				RC_Global.clickButton(driver, "Save", true);
//			} catch (Exception e) {}
//			try {
//				RC_Global.clickButton(driver, "Select Recommended Address", true);
//				RC_Global.clickButton(driver, "Save", true);
//			} catch (Exception e) {}
			if(driver.findElements(By.xpath("//span[text()=' address entered.']")).size()>0) {
				driver.findElement(By.xpath("//button[text()='Save As Entered']")).click();
				Thread.sleep(5000);
			}
			Thread.sleep(2000);
			RC_Global.verifyDisplayedMessage(driver, "Update Successful", false);
			RC_Global.clickButton(driver, "History", true,true);
			RC_Global.panelAction(driver, "close", "Driver Details", false,false);
			RC_Global.panelAction(driver, "expand", "Driver Change - History", false,false);
			String Modifiedby = driver.findElement(By.xpath("(//table/tbody/tr[1]/td[5])[1]")).getText().toUpperCase();
			String[] name = new String[2];
			if(Modifiedby.contains(RC_Global.userLogged)) {
				verifyDate = RC_Manage.AddDateStr(0, "MMM d, yyyy", "", null, "CST");
				if(driver.findElements(By.xpath("//table/tbody/tr[1]/td[text()='"+RC_Manage.drivername+"']")).size()>0 && driver.findElements(By.xpath("//table/tbody/tr[1]//td[contains(text(),'"+verifyDate+"')]")).size()>0) {
					name = RC_Manage.drivername.split(" ");					
					queryObjects.logStatus(driver, Status.PASS, "User changes have been captured in a new line to history", "with the the driver "+name+" and Username,"+Modifiedby, null);
				} else {
					queryObjects.logStatus(driver, Status.FAIL, "User changes are not reflecting in the history", "Verification failed", null);
				}
			}
			RC_Global.logout(driver, false);
			RC_LW_Global.leaseWaveLogin(driver,true);
			RC_LW_Manage.leasewaveDriverDataChangeValidation(driver,"yes", true);
			RC_LW_Global.leaseWaveLogOut(driver,false);
		}		
	}

}
