package Manage.Administration.DriverDataChange;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.LeaseWave.RC_LW_Global;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;


public class TID_6_1_8_07 {
	public static void DriverDataChange_ModifyPoolAddress(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		RC_Global.login(driver);
		RC_Global.enterCustomerFocus(driver, "LS010143", true);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Driver Data Change");
		RC_Global.clickButton(driver, "Search", true,true);
		
		RC_Global.waitElementVisible(driver, 30, "//tbody/tr[1]", "First Row Grid Load", true,true);
		RC_Global.clickUsingXpath(driver, "//th/div[@class='th']/span[text()='Driver/Pool Name']", "Driver/Pool Name Column sort", false,true);
		Thread.sleep(2000);
		String unitNumber = "";
		int rowSelection = Integer.parseInt(RandomStringUtils.randomNumeric(1));
		if(rowSelection==0)rowSelection = 2;
//		if(driver.findElements(By.xpath("//tr["+rowSelection+"]/td[contains(text(),'Pool')]")).size()>0) {
//			RC_Global.clickUsingXpath(driver, "//tr["+rowSelection+"]/td[contains(text(),'Pool')]", "Driver/Pool Name", false,true);
//			unitNumber = driver.findElement(By.xpath("//tr["+rowSelection+"]/td[3]")).getText();
//		}
//		else {
//			RC_Global.clickUsingXpath(driver, "//tr[1]/td[contains(text(),'Pool')]", "Driver/Pool Name", false,true);
//			unitNumber = driver.findElement(By.xpath("//tr[1]/td[3]")).getText();
//		}
		
		if(driver.findElements(By.xpath("//tr["+rowSelection+"]/td[contains(text(),'Pool')]")).size()>0) {
			RC_Global.clickUsingXpath(driver, "//tr["+rowSelection+"]/td[contains(text(),'Pool')]", "Driver/Pool Name", true,true);
			unitNumber = driver.findElement(By.xpath("//tr["+rowSelection+"]/td[3]")).getText();
		}
		else {
			RC_Global.clickUsingXpath(driver, "(//tr[contains(., 'Pool')]//td[5])[1]", "Driver/Pool Name", true,true);
			unitNumber = driver.findElement(By.xpath("(//tr[contains(., 'Pool')]//td[3])[1]")).getText();
		}
		
		RC_Global.waitUntilPanelVisibility(driver, "Driver Details", "TV", false,true);
		RC_Global.panelAction(driver, "close", "Driver Data Change", false,false);
		RC_Global.panelAction(driver, "expand", "Driver Details", false,false);
		
		Thread.sleep(2000);
		RC_Global.clickButton(driver, "Manage Pool(s)", true,true);
		RC_Global.waitUntilPanelVisibility(driver, "Pool Management", "TV", false,true);
		RC_Global.panelAction(driver, "close", "Driver Details", false,false);
		RC_Global.panelAction(driver, "expand", "Pool Management", false,false);
		Thread.sleep(2000);
		
		RC_Global.clickButton(driver, "Edit", true,true);
		Thread.sleep(2000);
		
		String address = RandomStringUtils.randomNumeric(3)+" "+RandomStringUtils.randomAlphabetic(1)+" 8th St "+RandomStringUtils.randomAlphabetic(3)+" "+RandomStringUtils.randomNumeric(4);
		WebElement webAddress = driver.findElement(By.xpath("(//input[@name='garagingLocation'])[1]"));
		RC_Global.enterInput(driver, address, webAddress, true,true);
		Thread.sleep(2000);
		RC_Global.clickUsingXpath(driver, "(//button[text()=' Save '])[1]", "Save button", true,true);
		Thread.sleep(1000);
		if(driver.findElements(By.xpath("//h3[span[text()='Invalid '] and span[text()=' address entered.']]")).size()>0)
			RC_Global.clickButton(driver, "Save As Entered", true,true);
		Thread.sleep(1000);
		if(driver.findElement(By.xpath("(//button[text()=' Save '])[1]")).getAttribute("class").contains("ng-hide")) {
			RC_Manage.waitUntilMethods(driver, "(//button[text()=' Save '])[2]/div[@ng-show='isSaving']","class","ng-hide", "attribute visible");
		} else {
        	if(driver.findElement(By.xpath("(//button[text()=' Save '])[2]")).getAttribute("class").contains("ng-hide")){
				RC_Manage.waitUntilMethods(driver, "(//button[text()=' Save '])[1]/div[@ng-show='isSaving']","class","ng-hide", "attribute visible"); }
		}
		RC_Global.waitElementVisible(driver, 35, "//h4[text()='Save Successful']", "Save Successful", true,true);
		RC_Global.panelAction(driver, "close", "Pool Management", true,false);
		
		RC_Global.navigateTo(driver, "Manage", "Administration", "Driver Data Change");
		
		RC_Global.clickButton(driver, "Search", true,true);
		
		RC_Global.waitElementVisible(driver, 30, "//tbody/tr[1]", "First Row Grid Load", true,true);
		RC_Global.clickUsingXpath(driver, "//th/div[@class='th']/span[text()='Driver/Pool Name']", "Driver/Pool Name Column sort", false,true);
		Thread.sleep(2000);
		
		RC_Global.clickUsingXpath(driver, "//tr[td[text()=' "+unitNumber+" ']]/td[contains(text(),'Pool')]", "Driver/Pool Name", false,true);
		
		RC_Global.waitUntilPanelVisibility(driver, "Driver Details", "TV", false,true);
		RC_Global.panelAction(driver, "close", "Driver Data Change", false,false);
		RC_Global.panelAction(driver, "expand", "Driver Details", true,false);
		
		RC_Global.clickButton(driver, "History", true,true);
		RC_Global.waitUntilPanelVisibility(driver, "Driver Change", "TV", false,true);
		RC_Global.panelAction(driver, "close", "Driver Details", true,false);
		RC_Global.panelAction(driver, "expand", "Driver Change", true,false);
		// TV History not updated - Bug
		RC_Global.clickUsingXpath(driver, "(//tr[1]/td[1])[1]", "Latest Change in History", false,true);
		if(driver.findElement(By.xpath("(//tr[2]/td[2]/table/tbody/tr[1]/td[2])[1]")).getText().equalsIgnoreCase("Vehicle Location Street Line 1"))
			queryObjects.logStatus(driver, Status.PASS, "Verify latest change update", "Verified successfully", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify latest change update", "Expected Change is not displayed", null);
		
		if(driver.findElement(By.xpath("(//tr[2]/td[2]/table/tbody/tr[1]/td[4])[1]")).getText().equalsIgnoreCase(address))
			queryObjects.logStatus(driver, Status.PASS, "Verify latest change update", "Verified successfully", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify latest change update", "Expected Change is not displayed", null);
		

		//LeaseWave Validation
		RC_LW_Global.leaseWaveLogin(driver, true);
		RC_Global.clickUsingXpath(driver,"//a[contains(text(),'Portfolio Management')]","Portfolio Management",true, false);
		RC_Global.waitElementVisible(driver, 50, "//a[contains(text(),'Portfolio Management')]", "Portfolio Management",true, false);
		RC_Global.clickUsingXpath(driver, "//td[text()='.Asset']", "Asset Menu", true,true);
		RC_Global.clickUsingXpath(driver, "(//td[@accesskey='P']/div[text()='rofile'])[2]", "Profile Option", true,true);
		Thread.sleep(3000);
		
		WebElement eleUnitNumber = driver.findElement(By.xpath("//td[@lw_columnname='UnitNumber']/input"));
		RC_Global.enterInput(driver, unitNumber, eleUnitNumber, true,true);
		
		RC_Global.clickUsingXpath(driver, "//button[text()='Searc' and @accesskey='H']", "Search Button", true,true);
		
		Thread.sleep(3000);
		RC_Global.clickUsingXpath(driver, "//button[@accesskey='E' and text()='dit']", "Edit Button", true,true);
		RC_Global.clickUsingXpath(driver, "//a[text()='Location History']", "Location History", true,true);
		//LW History not updated - Bug
		
		
		Thread.sleep(2000);
		RC_Global.clickUsingXpath(driver, "(//button[@accesskey='C' and text()='lose'])[2]", "Close button", true,true);
		Thread.sleep(3000);
		
		RC_Global.clickUsingXpath(driver, "//button[@accesskey='C' and text()='lose']", "Close Button", true,true);
		RC_LW_Global.leaseWaveLogOut(driver, true);
	}
}