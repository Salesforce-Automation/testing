package Manage.Administration.DriverDataChange;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;


public class TID_6_1_8_03 {
	public void EmployeeAssignedToInactiveVehicle_AddressChange(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage","Administration","Driver Data Change");
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Closed;Sold;Terminated lease;Terminated services only", true);
		RC_Global.clickButton(driver, "Search", true,true);
		RC_Global.waitElementVisible(driver, 30, "//tbody//tr[1]", "Grid Load", true,true);
		RC_Manage.driverSelection(driver, true);
		RC_Global.waitUntilPanelVisibility(driver,"Driver Details", "TV", true,true);
		//RC_Global.panelAction(driver, "close", "Driver Data Change", true);
		//RC_Global.panelAction(driver, "expand", "Driver Details", true,false);
		Thread.sleep(2000);
		String Address = driver.findElement(By.xpath("//input[@name='residentialAddress1Text']")).getAttribute("value");
		String Country = driver.findElement(By.xpath("//input[@name='residentialCounty']")).getAttribute("value");
		String CityName = driver.findElement(By.xpath("//input[@name='residentialCityName']")).getAttribute("value");
		String UnitNumber = driver.findElement(By.xpath("(//strong[text()='Unit Number: ']/following::a[@title='Open Vehicle Details'])[1]")).getText();
		String DriverFullName = driver.findElement(By.xpath("//input[@name='driverFullName']")).getAttribute("value");
		String[] Name = DriverFullName.split(" ");
		String DriverFName =  Name[0];
		String DriverLName = Name[1];
		RC_Global.panelAction(driver, "close", "Driver Details", true,false);

		RC_Global.navigateTo(driver, "Manage","Administration","Employee Management");
		RC_Global.panelAction(driver, "close", "Driver Data Change", true,false);
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		WebElement EmplyFrName = driver.findElement(By.xpath("//input[@placeholder='Employee First Name']"));
		WebElement EmplyLsName = driver.findElement(By.xpath("//input[@placeholder='Employee Last Name']"));
		RC_Global.enterInput(driver, Name[0], EmplyFrName, true,true);
		RC_Global.enterInput(driver, Name[1], EmplyLsName, true,true);
		RC_Global.clickButton(driver, "Search", true,true);
		//RC_Global.clickUsingXpath(driver,"//tbody//tr[1]","Select record from grid", true);
		RC_Global.waitUntilPanelVisibility(driver,"Edit Employee", "TV", true,true);
		RC_Global.panelAction(driver, "close", "Employee Management", true,false);
		RC_Global.panelAction(driver, "expand", "Edit Employee", true,false);
		String EdEmpAddress = driver.findElement(By.xpath("//input[@name='addressLine1']")).getAttribute("value");
		driver.findElement(By.xpath("//input[@name='addressLine1']")).clear();
		driver.findElement(By.xpath("//input[@name='addressLine1']")).sendKeys("New Address");
		RC_Global.clickUsingXpath(driver, "(//div[@class='tree-label ']//span)[1]", "Customer tree", true,true);
		Thread.sleep(2000);
		RC_Global.clickUsingXpath(driver,"(//button[text()=' Save '])[1]","Save Button", true,true);
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//span[text()=' address entered.']")).size()>0) {
			driver.findElement(By.xpath("//button[text()='Save As Entered']")).click();
			Thread.sleep(2000);
		}
		RC_Global.verifyDisplayedMessage(driver,"Employee Updated Successfully", true);
		RC_Global.panelAction(driver, "close", "Edit Employee", true,false);
		
		RC_Global.navigateTo(driver, "Manage","Administration","Driver Data Change");
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		WebElement DrvFName1 = driver.findElement(By.xpath("//input[@placeholder='Driver First Name']"));
		WebElement DrvLName1 = driver.findElement(By.xpath("//input[@placeholder='Driver Last Name']"));
		WebElement UnitNum = driver.findElement(By.xpath("//input[@placeholder='Unit Number']"));
		RC_Global.enterInput(driver, DriverFName, DrvFName1, true,true);
		RC_Global.enterInput(driver, DriverLName, DrvLName1, true,true);
		RC_Global.enterInput(driver, UnitNumber, UnitNum, true,true);
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Closed;Sold;Terminated lease;Terminated services only", true);
		RC_Global.clickButton(driver, "Search", true,true);
		RC_Global.waitUntilPanelVisibility(driver,"Driver Details", "TV", true,true);
		Thread.sleep(2000);
		String DDchAddress = driver.findElement(By.xpath("//input[@name='residentialAddress1Text']")).getAttribute("value");
		if(!(DDchAddress.equalsIgnoreCase("New Address")))
			queryObjects.logStatus(driver, Status.PASS, "Address is not Updated in the Driver Data Change Page for Inactive Employee", "", null);
		else
		{	
			queryObjects.logStatus(driver, Status.FAIL, "Address is Updated in the Driver Data Change Page for Inactive Employee", "", null);
			RC_Global.endTestRun(driver);
		}
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	
	}
}
