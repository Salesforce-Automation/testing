package Manage.Administration.DriverDataChange;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_8_08 {
	public void SelectEmployeeFromDifferentStateAndApplyAddressToVehicle(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Driver Data Change";

		RC_Global.login(driver);
		RC_Global.waitElementVisible(driver, 10, "//span[text()='LS000000 - Merchants Portfolio']", "", false,true);
		String loggedUser = driver.findElement(By.xpath("//div[@class='bottom-nav bottom-right-menu']//div/ul[@class='nav-right list-unstyled pull-right user-menu']/li/a")).getText();
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.enterCustomerNumber(driver, "LS010112", "", "", false);
		RC_Global.waitElementVisible(driver, 3, "//select[@id='clientDataFieldInput']", "Client Data Field", true,true);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Manage.driverNameSelection(driver, "", false);
		RC_Global.waitElementVisible(driver, 30, "//span[text()='Driver Details']", "Driver Details grid is displayed", true,true);
		RC_Global.panelAction(driver, "close", "Driver Data Change", false,false);
		RC_Global.panelAction(driver, "expand", "Driver Details", false,false);
		RC_Global.scrollById(driver, "//h3[text()='Driver Information']");
		List<String> driverInfo = RC_Manage.getDriverInformation(driver, false);
		List<String> vehicleInfo = RC_Manage.getVehicleAddress(driver, false);

			RC_Global.clickUsingXpath(driver, "//button[@id='driverSearch']", "Search", true,true);
			RC_Global.clickButton(driver, "Search", false,true);
				RC_Manage.driverSelectionFromDifferentState(driver, vehicleInfo.get(2) , false);
				RC_Global.clickUsingXpath(driver, "//a[text()='Apply Address To Vehicle ']", "Apply Address To Vehicle", true,true);
				RC_Global.clickUsingXpath(driver, "(//button[@ng-model='updateOdometer'])[1]", "Yes", true,true);
				if(driver.findElements(By.xpath("(//input[@placeholder='Odometer'])[1]")).size()>0)
				{
					queryObjects.logStatus(driver, Status.PASS, "'Odometer field' is shown", "", null);
				}
				RC_Global.clickUsingXpath(driver, "(//button[@ng-model='updateOdometer'])[2]", "No", true,true);
				if(driver.findElements(By.xpath("(//select[@ng-model='odometerReasonOption'])[1]")).size()>0)
				{
					queryObjects.logStatus(driver, Status.PASS, "'Reason field' is shown", "", null);
					RC_Global.selectDropdownOption(driver, "Reason", "Temporary", true,true);
				}
				Thread.sleep(5000);
				RC_Global.scrollById(driver, "//h3[text()='Client Data Definitions']");
			
				RC_Global.clickButton(driver, "Save", true,true);
				if(driver.findElement(By.xpath("(//button[text()=' Save '])[1]")).getAttribute("class").contains("ng-hide")) {
					RC_Manage.waitUntilMethods(driver, "(//button[text()=' Save '])[2]/div[@ng-show='isSaving']","class","ng-hide", "attribute visible");
				} else {
	            	if(driver.findElement(By.xpath("(//button[text()=' Save '])[2]")).getAttribute("class").contains("ng-hide")){
						RC_Manage.waitUntilMethods(driver, "(//button[text()=' Save '])[1]/div[@ng-show='isSaving']","class","ng-hide", "attribute visible"); }
				}
				Thread.sleep(3000);
				if((driver.findElements(By.xpath("//span[text()=' address entered.']")).size()>0))
				{
					RC_Global.clickButton(driver, "Save As Entered", true,true);
				}
				if(driver.findElements(By.xpath("//h4[text()='Update Successful']")).size()>0)
				{
					queryObjects.logStatus(driver, Status.PASS, "'Update Successful' message is received", "", null);
				}
				RC_Global.clickButton(driver, "History", true,true);
				RC_Global.panelAction(driver, "close", "Driver Details", false,false);
				RC_Global.panelAction(driver, "expand", "Driver Change", false,false);
				RC_Global.waitElementVisible(driver, 5, "//table//tbody", "Driver Data Change History grid Result", true,true);
				Thread.sleep(2000);
				String modifiedBy = driver.findElement(By.xpath("((//table/tbody/tr)[1]/td)[5]")).getText();
				if(modifiedBy.equals(loggedUser))
				{
					queryObjects.logStatus(driver, Status.PASS, "User's name is displayed in the first row", modifiedBy, null);
					RC_Global.clickUsingXpath(driver, "(//table/tbody/tr)[1]/td[1]", " Name, Address, Assign to Driver ", true,true);
					queryObjects.logStatus(driver, Status.PASS, "The details of this change are displayed", "", null);
				}
				else
				{
					queryObjects.logStatus(driver, Status.FAIL, "User's name is not displayed in the first row", "", null);
				}				
//		
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}

}
