package Manage.Administration.DriverDataChange;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.LeaseWave.RC_LW_Global;
import tools.LeaseWave.RC_LW_Manage;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_8_05 {
	public void  ChangeVehicleAddressInDriverDetailsAndVerifyLeaseWave_AssetProfile (WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Driver Data Change");
		RC_Global.validateHeaderName(driver, "Driver Data Change", true);
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "",true);
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Active lease", false);
		RC_Global.clickButton(driver, "Search", true,true);
		RC_Global.waitElementVisible(driver, 30, "//table//tbody", "Driver Data Change grid Result", true,true);
	//	RC_FleetServices.driverSelection(driver,"No", true);
		//update address
		//save
		RC_Manage.driverSelection(driver, false);
		RC_Manage.updateDriverName_DriverDetails(driver, "Yes", "Yes", "No", false);
		RC_Global.verifyDisplayedMessage(driver, "Update Successful", false);
		
		//verify the history for the changes
		RC_Global.clickButton(driver, "History", true,true);
		RC_Global.panelAction(driver, "close", "Driver Details", false,false);
		RC_Global.panelAction(driver, "expand", "Driver Change - History", false,false);
		//String Username = driver.findElement(By.xpath("//span[@id='Span1']")).getText();
		String Modifiedby = driver.findElement(By.xpath("(//table/tbody/tr[1]/td[5])[2]")).getText().toUpperCase();
		
		if(driver.findElements(By.xpath("(//tbody/tr//a[text()='View']//ancestor::tr)[1]//td[text()='"+RC_Manage.drivernameUpdated+"']")).size()>0)
		{
			if(Modifiedby.contains(RC_Global.userLogged))
			{
				RC_Global.clickUsingXpath(driver, "(//table/tbody/tr[1]/td[1])[2]", "Changes", false,true);
				String Old = driver.findElement(By.xpath("(//table/tbody/tr[3]/td[2][text()='Vehicle Location Street Line 1'])[1]/../td[3]")).getText();
                String New = driver.findElement(By.xpath("(//table/tbody/tr[3]/td[2][text()='Vehicle Location Street Line 1'])[1]/../td[4]")).getText();
				
				queryObjects.logStatus(driver, Status.INFO, "Old Vehicle Address", Old, null);
				queryObjects.logStatus(driver, Status.INFO, "New Vehicle Address", New, null);
				queryObjects.logStatus(driver, Status.INFO, "New Vehicle Address Modified By", Modifiedby, null);
				if(New.toUpperCase().contains(RC_Manage.VehicleAddress.toUpperCase()))
				{
					queryObjects.logStatus(driver, Status.PASS, "Changed vehicle Address "+New+" is displayed in history", "Successfully", null);
				} else {
					queryObjects.logStatus(driver, Status.FAIL, "Changed vehicle Address "+New+" is not displayed in history", "Failed", null);
				}
			}
		}
		RC_Global.logout(driver, false);
		
		RC_LW_Global.leaseWaveLogin(driver,true);
		RC_LW_Manage.leasewaveVehicleAddressValidation(driver,true);
		RC_LW_Global.leaseWaveLogOut(driver,false);
		 queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}

}
