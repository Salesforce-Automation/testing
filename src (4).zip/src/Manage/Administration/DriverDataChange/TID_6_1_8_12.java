package Manage.Administration.DriverDataChange;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.LeaseWave.RC_LW_FleetServices;
import tools.LeaseWave.RC_LW_Global;
import tools.LeaseWave.RC_LW_Manage;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_8_12 {
	
	public void DriverDataChange_ChangeDriverandupdateshowninLeaseWave(WebDriver driver, BFrameworkQueryObjects queryObjects)throws Exception  {
		
		String Firstname= ""; String Lastname= "";
		String custNo = "LS010143"; String newDriver = ""; String verifyDate = ""; String setDate = "";
		WebDriverWait wait = new WebDriverWait(driver,30);
		JavascriptExecutor executor = (JavascriptExecutor) driver;		
		RC_Global.login(driver);
		RC_Global.enterCustomerFocus(driver, custNo, true);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Driver Data Change");
		RC_Global.clickButton(driver, "Search", true,true);
		RC_Global.waitElementVisible(driver, 50, "//table//tbody", "Driver Data Change grid Result", true,true);
		//RC_Global.clickUsingXpath(driver, "//div[@table-scroll]", "Select the Vehicle Status column header", true,true);
		RC_Manage.getAddress_DriverSelection(driver,"Driver Change", true);
		RC_Global.waitElementVisible(driver, 30, "//span[text()='Driver Details']", "Driver Details grid is displayed", true,true);
		RC_Global.panelAction(driver, "close", "Driver Data Change", false,false);
		RC_Global.panelAction(driver, "expand", "Driver Details", false,false);

		RC_Manage.updateDriverName_DriverDetails(driver, "Yes", "No", "", false);
		RC_Global.verifyDisplayedMessage(driver, "Update Successful", false);
		RC_Global.clickButton(driver, "History", true,true);
		RC_Global.panelAction(driver, "close", "Driver Details", false,false);
		RC_Global.panelAction(driver, "expand", "Driver Change - History", false,true);
		//String Username = driver.findElement(By.xpath("//span[@id='Span1']")).getText();
		String Modifiedby = driver.findElement(By.xpath("(//table/tbody/tr[1]/td[5])[1]")).getText().toUpperCase();
		String[] name = new String[2];
		if(Modifiedby.contains(RC_Global.userLogged)) {
			verifyDate = RC_Manage.AddDateStr(0, "MMM d, yyyy", "", null, "CST");
			if(driver.findElements(By.xpath("(//tbody/tr//a[text()='View']//ancestor::tr)[1]//td[text()='"+RC_Manage.drivernameUpdated+"']")).size()>0 && driver.findElements(By.xpath("//table/tbody/tr[1]//td[contains(text(),'"+verifyDate+"')]")).size()>0) {
				name = RC_Manage.drivernameUpdated.split(" ");
				queryObjects.logStatus(driver, Status.PASS, "User changes have been captured in a new line to history", "with the the driver "+ RC_Manage.drivername+" and Username,"+Modifiedby, null);
			} else {
				queryObjects.logStatus(driver, Status.FAIL, "User changes are not reflecting in the history", "Verification failed", null);
			}
		} else {
			queryObjects.logStatus(driver, Status.FAIL, "User changes are not reflecting in the history", "Verification failed", null);
		}
		
		RC_Global.logout(driver, false);
		 RC_LW_Global.leaseWaveLogin(driver,true);
		 RC_LW_Manage.leaseWaveDriverAssignment(driver,true);
		 RC_LW_Global.leaseWaveLogOut(driver,false);

		
	}

}
