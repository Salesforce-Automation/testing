package Manage.Administration.DriverDataChange;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.LeaseWave.RC_LW_Global;
import tools.LeaseWave.RC_LW_Manage;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_8_06 {
	public void VehicleDetails_NewDriverInLeasewave(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
	    JavascriptExecutor executor = (JavascriptExecutor)driver;
		
		  RC_Global.login(driver); RC_Global.navigateTo(driver,
		  "Manage","Administration","Driver Data Change");
		  RC_Global.enterCustomerNumber(driver, "LS010140", "", "", true);
		  RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Active lease;Active services only", true);
		  RC_Global.clickButton(driver, "Search", true,true);
		  RC_Global.waitElementVisible(driver, 30, "//tbody//tr[1]", "Grid Load", true,true); RC_Manage.driverSelection(driver, true);
		  RC_Global.waitUntilPanelVisibility(driver,"Driver Details", "TV", true,true);
		  //RC_Global.panelAction(driver, "close", "Driver Data Change", true);
		  //RC_Global.panelAction(driver, "expand", "Driver Details", true,false);
		  Thread.sleep(2000);
		  String UnitNumber = driver.findElement(By.xpath("(//strong[text()='Unit Number: ']/following::a[@title='Open Vehicle Details'])[1]")).getText();
		 
		  //String UnitNumber = "602633";
		RC_LW_Global.leaseWaveLogin(driver, true);
		
		  String[] DriverDet = RC_LW_Manage.addDriverInLeaseWave(driver, "LS010140",true);
		  RC_Global.clickButton(driver, "lose", true,true);
		 
		//RC_Global.waitElementVisible(driver, 50, "//a[text()='Fleet Management']", "Fleet Management Menu",true);
		driver.findElement(By.xpath("//a[text()='Fleet Management']")).click();
		Thread.sleep(2000);
		RC_Global.waitElementVisible(driver, 90, "//a[text()='Fleet Management']", "Fleet Management Menu",true,true);
		 String home =  driver.findElement(By.xpath("//span[text()='Fleet Management Menu']")).getText();
		    if(home.contains("FLEET MANAGEMENT MENU")) {
		    	queryObjects.logStatus(driver, Status.PASS, "Navigation to Fleet Management Menu", "Successfully", null);	
		    }
		    RC_Global.clickUsingXpath(driver,"//td[@accesskey='1' and text()='. Profiles']","Profiles",true,true);
		    RC_Global.clickUsingXpath(driver,"//td[@accesskey='D']","Driver",true,true);
		    RC_Global.clickUsingXpath(driver,"//tr[contains(@igurl,'AssignDriverToAsset')]/td[@accesskey='A']","AssignDriver to Asset",true,true);
			RC_Global.waitElementVisible(driver, 90, "//span[text()='Asset List' and @id='ctl00_PageTitle']", "Asset List",true,true);
		    driver.findElement(By.xpath("//td[@lw_friendlyname='Unit Number']//input")).sendKeys(UnitNumber);
		    RC_Global.clickUsingXpath(driver,"//button[text()='Searc']","Search button",true,true);
		    Thread.sleep(3000);
		    RC_Global.clickUsingXpath(driver,"//button[text()='elect']","Select button",true,true);
		    Thread.sleep(2000);
		    try {
		    	driver.findElement(By.xpath("//button[text()='elect']")).click();
		    } catch (Exception e) {}
		    try {
		    	   Thread.sleep(2000);
		           driver.switchTo().alert().accept(); 
		           Thread.sleep(2000);
		           driver.findElement(By.xpath("//img[@alt='Hide Message Window']")).click();
		         }
		    catch(Exception e){}
			RC_Global.waitElementVisible(driver, 90, "//span[text()='Assign Driver to Asset' and @id='ctl00_PageTitle']", "Assign Driver to Asset",true,true);
			WebElement DriverCode = driver.findElement(By.xpath("(//input[contains(@name,'DriverCode')])[1]"));
			
			  RC_Global.enterInput(driver,DriverDet[0] ,DriverCode, true,true);
			  Thread.sleep(3000); RC_Global.clickUsingXpath(driver, "//input[contains(@name,'DriverName')]","Select Tab",true,true);
			  RC_Global.waitElementVisible(driver, 90, "//button[text()='dd']", "Add Button",true,true);
			  RC_Global.clickUsingXpath(driver,"//button[text()='dd']","Add button",true, true);
			  
			  RC_Global.waitElementVisible(driver, 90,  "(//nobr[text()='"+DriverDet[0]+"'])[1]", "Driver row added",true,true);
			  WebElement driverCreated = driver.findElement(By.xpath("(//nobr[text()='"+DriverDet[0]+"'])[1]"));
			  Thread.sleep(2000);
			 
			WebElement eleChk = driver.findElement(By.xpath("//td//input[@type='checkbox' and @checked]/../.."));
			executor.executeScript("arguments[0].click();", eleChk);
			try {
				eleChk.click();
			} catch (Exception e) {}
			eleChk.getLocation();
			executor.executeScript("arguments[0].click();", driver.findElement(By.xpath("//td//input[@type='checkbox' and @checked]/../..//nobr")));
			driver.findElement(By.xpath("//td//input[@type='checkbox' and @checked]/../..//nobr")).click();
			/*
			 * executor.executeScript("arguments[0].scrollIntoView(true);",driverCreated);
			 */
			
			/*WebElement ele = driver.findElement(By.xpath("//td//input[@type='checkbox' and @checked]"));

			JavascriptExecutor js = (JavascriptExecutor) driver;

			js.executeScript("window.scrollTo(650, 400)");
			ele.click();*/
			/*
			 *  Actions act = new Actions(driver);
			 * act.moveToElement(driver.findElement(By.tagName("body")), 0, 0);
			 * act.moveByOffset(xAx+300, yAx+300).click(); act.build().perform();
			 */
			RC_Global.clickUsingXpath(driver,"//td//input[@type='checkbox' and @checked]","Unselect checkbox",false,true);
		    RC_Global.clickUsingXpath(driver,"//td[@allowedit='yes']//input[@type='checkbox']","Primary Checkbox",true,true);
		    /*WebElement Checkbox = driver.findElement(By.xpath("//td[@chkboxstate='1']/nobr[@title]/input[@type='checkbox']"));
		    executor.executeScript("arguments[0].scrollIntoView(true);",Checkbox);
		    executor.executeScript("arguments[0].click();", Checkbox);*/
		    RC_Global.clickUsingXpath(driver,"//button[text()='ave']","Save button",true,true);
			RC_Global.waitElementVisible(driver, 90, "//span[text()='Asset List' and @id='ctl00_PageTitle']", "Asset List",true,true);
			RC_LW_Global.leaseWaveLogOut(driver, true);

			RC_Global.login(driver);
			RC_Global.navigateTo(driver, "Manage","Administration","Driver Data Change");
			WebElement UnitNum = driver.findElement(By.xpath("//input[@placeholder='Unit Number']"));
			RC_Global.enterInput(driver,UnitNumber ,UnitNum, true,true);
			RC_Global.clickButton(driver, "Search", true,true);
			RC_Global.waitUntilPanelVisibility(driver,"Driver Details", "TV", true,true);
			String DriverFullName = driver.findElement(By.xpath("//input[@name='driverFullName']")).getAttribute("value");
			Thread.sleep(2000);
			String[] DriverNam = DriverFullName.split(" ");
			String Fname = DriverNam[0];
			String Lname = DriverNam[1];	
			Thread.sleep(2000);
			
			  if(Fname.contains(DriverDet[1]) && Lname.contains(DriverDet[2]))
			  queryObjects.logStatus(driver, Status.PASS,"Driver First and Last name are updated according to the LeaseWave", "Successful", null);
			  else { queryObjects.logStatus(driver, Status.FAIL, "Driver First and Last name is not updated according to the LeaseWave", "Failed", null); RC_Global.endTestRun(driver); }
			 
			Thread.sleep(2000);
			String DDchAddress = driver.findElement(By.xpath("//input[@name='residentialAddress1Text']")).getAttribute("value");
			if(DDchAddress.contains(RC_LW_Manage.newAddress))
				queryObjects.logStatus(driver, Status.PASS, "Address is Updated in the Driver Data Change Page according to the LeaseWave ", "Successful", null);
			else
			{	
				queryObjects.logStatus(driver, Status.FAIL, "Address is not Updated in the Driver Data Change Page according to the LeaseWave", "", null);
				RC_Global.endTestRun(driver);
			}
			RC_Global.logout(driver, false);	
			queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
		
			
	}
}
