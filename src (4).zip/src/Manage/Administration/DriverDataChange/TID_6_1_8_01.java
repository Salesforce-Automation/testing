package Manage.Administration.DriverDataChange;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_6_1_8_01 {
	public void DriverDataChange_ModifyClientData(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Driver Data Change";
		RC_Global.login(driver);
		String loggedUser = driver.findElement(By.xpath("//div[@class='bottom-nav bottom-right-menu']//div/ul[@class='nav-right list-unstyled pull-right user-menu']/li/a")).getText();
		RC_Global.waitElementVisible(driver, 10, "//span[text()='LS000000 - Merchants Portfolio']", "", false,false);
		queryObjects.logStatus(driver, Status.PASS, "Customer Focus Is To 'Merchants Portfolio'", "", null);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.enterCustomerNumber(driver, "LS010112", "", "", false);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Manage.driverNameSelection(driver, "", false);
		RC_Global.panelAction(driver, "close", "Driver Data Change", false,false);
		RC_Global.panelAction(driver, "expand", "Driver Details", false,false);
		String oldOwnerDropDownValue = RC_Manage.getOwnerDropdownValue(driver, false);
		RC_Manage.changeOwner(driver, oldOwnerDropDownValue, false);
		String newOwnerDropDownValue = RC_Manage.getOwnerDropdownValue(driver, false);
		Thread.sleep(2000);
		//RC_Global.clickUsingXpath(driver, "//label[text()='Email Receipt of Changes ']", "Email Receipt of Changes", false);
		if (driver.findElement(By.xpath("(//button[@type='submit'])[3]")).getAttribute("class").contains("ng-hide")) {
			RC_Global.clickUsingXpath(driver, "(//button[@type='submit'])[4]", "Save", false,true);
		} else {
			RC_Global.clickUsingXpath(driver, "(//button[@type='submit'])[3]", "Save", false,true);
		}
		Thread.sleep(5000);
		if(driver.findElements(By.xpath("//span[text()=' address entered.']")).size()>0){
            RC_Global.clickButton(driver, "Save As Entered", true,true);
            Thread.sleep(5000);
        }
		RC_Global.clickButton(driver, "History", false,true);
		RC_Global.panelAction(driver, "close", "Driver Details", false,true);
		RC_Global.panelAction(driver, "expand", "Driver Change", false,true);
		RC_Manage.historyValidation(driver, loggedUser, false);
		String oldDriverVal = driver.findElement(By.xpath("((//table[@class='table table-hover table-condensed table-striped'])[1]/tbody/tr/td)[3]")).getText();
		String newDriverVal = driver.findElement(By.xpath("((//table[@class='table table-hover table-condensed table-striped'])[1]/tbody/tr/td)[4]")).getText();
		RC_Global.createNode(driver, "Verify the Driver Data Change");
		if(oldDriverVal.equals(oldOwnerDropDownValue) && newDriverVal.equals(newOwnerDropDownValue))
		{
			queryObjects.logStatus(driver, Status.PASS, "'Driver Data Change' is successful", "Expected "+oldOwnerDropDownValue+ ", "+newOwnerDropDownValue+" Actual "+newDriverVal+","+oldDriverVal, null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "'Driver Data Change' not is successful", "Expected "+oldOwnerDropDownValue+ ", "+newOwnerDropDownValue+" Actual "+newDriverVal+","+oldDriverVal, null);
		}
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}

}
