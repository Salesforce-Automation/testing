package Manage.Administration.Contacts;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_3_02 {
	public void  SaveUpdatesToContactAssignment (WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		List<WebElement> CurrConClmn = null;
		String CustomerNumber = "LS008742";
		RC_Global.login(driver);
		RC_Global.enterCustomerFocus(driver, CustomerNumber, true);
		RC_Global.navigateTo(driver,"Manage","Administration","Contacts");
		RC_Global.waitUntilPanelVisibility(driver, "Contacts", "TV", true,false);
		RC_Global.clickButton(driver, "Assign Contact", true,true);
		RC_Global.waitUntilPanelVisibility(driver, "Assign Contact", "TV", true,false);
		RC_Global.panelAction(driver, "close", "Contacts", true,false);
		Thread.sleep(2000);
		RC_Global.panelAction(driver, "expand", "Assign Contact", true,false);
		RC_Global.clickButton(driver, "Search", true,true);
		RC_Global.waitElementVisible(driver, 30, "//tbody//tr[1]", "Grid Load", true,false);
		RC_Global.clickUsingXpath(driver, "//tbody//tr[1]//td[4]", "Select Record", true,false);
		RC_Global.clickButton(driver, "Select Contact", true,true);
		RC_Global.waitUntilPanelVisibility(driver, "Assign Contact", "TV", true,false); 
		RC_Global.selectDropdownOption(driver, "Contact Type to Assign", "Title and Registration", true,true);
		RC_Global.waitElementVisible(driver, 30, "(//tbody//tr[1])[2]/td[1]//label[contains(text(),'"+CustomerNumber+"')]", "Assign contact", true,true);
		String SelectedContactNam = driver.findElement(By.xpath("//input[@placeholder='Selected Contact']")).getAttribute("value");
		List<WebElement> CheckBoxs = driver.findElements(By.xpath("//input[contains(@id,'checkbox-')]"));
		for(int i=1; i < CheckBoxs.size();) {
			RC_Global.clickUsingXpath(driver, "(//input[contains(@id,'checkbox-"+i+"')])[1]", "Select check box", true,true);
			Thread.sleep(2000);
			if(!(driver.findElements(By.xpath("//td[contains(text(),'"+SelectedContactNam+"')]")).size()==1))
				i++;
			else {
				Thread.sleep(2000);
				CurrConClmn = driver.findElements(By.xpath("//td[contains(text(),'"+SelectedContactNam+"')]"));
				RC_Global.clickButton(driver, "Save", true,true);
				RC_Global.verifyDisplayedMessage(driver, "Updated Successfully", true);
				break;}
		}
		
		if(CurrConClmn.size()>0) 
            queryObjects.logStatus(driver, Status.PASS, "Current Contact Column", "Current Contact Column has updated with the assigned contact for selected node", null);
		else {
            queryObjects.logStatus(driver, Status.FAIL, "Current Contact Column", "Current Contact Column has failed to updated with the assigned contact for selected node", null);
            RC_Global.endTestRun(driver);
		}
		List<WebElement> ConTAssClmn = driver.findElements(By.xpath("//span[contains(text(),'Contact to Assign')]"));
		if(ConTAssClmn.size()==0) 
            queryObjects.logStatus(driver, Status.PASS, "Contact To Assign Column", "Contact To Assign Column disappered after the successful save", null);
		else {
            queryObjects.logStatus(driver, Status.FAIL, "Contact To Assign Column", "Contact To Assign Column failed to disappered after the successful save", null);
            RC_Global.endTestRun(driver);
		}
		
		RC_Global.panelAction(driver, "close", "Assign Contact", true,false);
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}
}
