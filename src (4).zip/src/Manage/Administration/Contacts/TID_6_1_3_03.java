package Manage.Administration.Contacts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_3_03 {
	public static void ContactCardInheritanceAtSubLevels_InternalUser(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Contacts");
		RC_Global.waitUntilPanelVisibility(driver, "Contacts", "TV", true, true);
		
		
		String mainContacts = "";
		String accountsPayable = "";
		String billingContacts = "";
		String deliveryContacts = "";
		String fuelContacts = "";
		String maintenanceContacts = "";
		String personalUseContacts = "";
		String remarketingContacts = "";
		String riskContacts = "";
		String telematicsContacts = "";
		String titleAndRegistrationContacts = "";
		String violationManagementContacts = "";
		
		String mainContactsFL = "";
		String accountsPayableFL = "";
		String billingContactsFL = "";
		String deliveryContactsFL = "";
		String fuelContactsFL = "";
		String maintenanceContactsFL = "";
		String personalUseContactsFL = "";
		String remarketingContactsFL = "";
		String riskContactsFL = "";
		String telematicsContactsFL = "";
		String titleAndRegistrationContactsFL = "";
		String violationManagementContactsFL = "";
		
		String mainContactsCus = "";
		String accountsPayableCus = "";
		String billingContactsCus = "";
		String deliveryContactsCus = "";
		String fuelContactsCus = "";
		String maintenanceContactsCus = "";
		String personalUseContactsCus = "";
		String remarketingContactsCus = "";
		String riskContactsCus = "";
		String telematicsContactsCus = "";
		String titleAndRegistrationContactsCus = "";
		String violationManagementContactsCus = "";
		
		String accountLevel = "";
		for(int iterator=0; iterator<2; iterator++) {
		RC_Global.enterCustomerNumber(driver, "LS010143", "", "Account level", true);
		Thread.sleep(3000);
		if(iterator==0)
			accountLevel = driver.findElement(By.xpath("//div[@class='tree-label  tree-selected']/span")).getText().split(" - ")[0];
		Thread.sleep(2000);
		if(driver.findElements(By.xpath("//div[h4[text()='Main - Account']]//b/a/span")).size()>0)
			mainContacts = driver.findElement(By.xpath("//div[h4[text()='Main - Account']]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Main - Account']]/div[1]//h4[text()='Pending Contact Assignment']")).size()>0)
			mainContacts = "Pending Contact Assignment";
		
		if(driver.findElements(By.xpath("//div[h4[text()='Accounts Payable']]//b/a/span")).size()>0)
			accountsPayable = driver.findElement(By.xpath("//div[h4[text()='Accounts Payable']]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Accounts Payable']]/div[1]//h4[text()='Pending Contact Assignment']")).size()>0)
			accountsPayable = "Pending Contact Assignment";
		
		if(driver.findElements(By.xpath("//div[h4[text()='Billing']]//b/a/span")).size()>0)
			billingContacts = driver.findElement(By.xpath("//div[h4[text()='Billing']]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Billing']]/div[1]//h4[text()='Pending Contact Assignment']")).size()>0)
			billingContacts = "Pending Contact Assignment";
		
		if(iterator==1)
			if(driver.findElements(By.xpath("//div[div[h4[text()='Delivery']]]//label[text()='2nd']")).size()>0)
				RC_Global.clickUsingXpath(driver, "//div[div[h4[text()='Delivery']]]//label[text()='2nd']", "2nd button of 'Delivery'", true, true);
		if(driver.findElements(By.xpath("//div[h4[text()='Delivery']]/div["+(iterator+1)+"]//b/a/span")).size()>0)
			deliveryContacts = driver.findElement(By.xpath("//div[h4[text()='Delivery']]/div["+(iterator+1)+"]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Delivery']]/div["+(iterator+1)+"]//h4[text()='Pending Contact Assignment']")).size()>0)
			deliveryContacts = "Pending Contact Assignment";
		
		if(iterator==1)
			if(driver.findElements(By.xpath("//div[div[h4[text()='Fuel']]]//label[text()='2nd']")).size()>0)
				RC_Global.clickUsingXpath(driver, "//div[div[h4[text()='Fuel']]]//label[text()='2nd']", "2nd button of 'Delivery'", true, true);
		if(driver.findElements(By.xpath("//div[h4[text()='Fuel']]/div["+(iterator+1)+"]//b/a/span")).size()>0)
			fuelContacts = driver.findElement(By.xpath("//div[h4[text()='Fuel']]/div["+(iterator+1)+"]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Fuel']]/div["+(iterator+1)+"]//h4[text()='Pending Contact Assignment']")).size()>0)
			fuelContacts = "Pending Contact Assignment";
		
		if(iterator==1)
			if(driver.findElements(By.xpath("//div[div[h4[text()='Maintenance']]]//label[text()='2nd']")).size()>0)
				RC_Global.clickUsingXpath(driver, "//div[div[h4[text()='Maintenance']]]//label[text()='2nd']", "2nd button of 'Delivery'", true, true);
		if(driver.findElements(By.xpath("//div[h4[text()='Maintenance']]/div["+(iterator+1)+"]//b/a/span")).size()>0)
			maintenanceContacts = driver.findElement(By.xpath("//div[h4[text()='Maintenance']]/div["+(iterator+1)+"]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Maintenance']]/div["+(iterator+1)+"]//h4[text()='Pending Contact Assignment']")).size()>0)
			maintenanceContacts = "Pending Contact Assignment";
		
		if(driver.findElements(By.xpath("//div[h4[text()='Personal Use']]//b/a/span")).size()>0)
			personalUseContacts = driver.findElement(By.xpath("//div[h4[text()='Personal Use']]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Personal Use']]/div[1]//h4[text()='Pending Contact Assignment']")).size()>0)
			personalUseContacts = "Pending Contact Assignment";
		
		if(driver.findElements(By.xpath("//div[h4[text()='Remarketing']]//b/a/span")).size()>0)
			remarketingContacts = driver.findElement(By.xpath("//div[h4[text()='Remarketing']]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Remarketing']]/div[1]//h4[text()='Pending Contact Assignment']")).size()>0)
			remarketingContacts = "Pending Contact Assignment";
		
		if(driver.findElements(By.xpath("//div[h4[text()='Risk']]//b/a/span")).size()>0)
			riskContacts = driver.findElement(By.xpath("//div[h4[text()='Billing']]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Risk']]/div[1]//h4[text()='Pending Contact Assignment']")).size()>0)
			riskContacts = "Pending Contact Assignment";
		
		if(iterator==1)
			if(driver.findElements(By.xpath("//div[div[h4[text()='Telematics']]]//label[text()='2nd']")).size()>0)
				RC_Global.clickUsingXpath(driver, "//div[div[h4[text()='Telematics']]]//label[text()='2nd']", "2nd button of 'Telematics'", true, true);
		if(driver.findElements(By.xpath("//div[h4[text()='Telematics']]/div["+(iterator+1)+"]//b/a/span")).size()>0)
			telematicsContacts = driver.findElement(By.xpath("//div[h4[text()='Telematics']]/div["+(iterator+1)+"]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Telematics']]/div["+(iterator+1)+"]//h4[text()='Pending Contact Assignment']")).size()>0)
			telematicsContacts = "Pending Contact Assignment";
		
		if(iterator==1)
			if(driver.findElements(By.xpath("//div[div[h4[text()='Title and Registration']]]//label[text()='2nd']")).size()>0)
				RC_Global.clickUsingXpath(driver, "//div[div[h4[text()='Title and Registration']]]//label[text()='2nd']", "2nd button of 'Delivery'", true, true);
		if(driver.findElements(By.xpath("//div[h4[text()='Title and Registration']]/div["+(iterator+1)+"]//b/a/span")).size()>0)
			titleAndRegistrationContacts = driver.findElement(By.xpath("//div[h4[text()='Title and Registration']]/div["+(iterator+1)+"]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Title and Registration']]/div["+(iterator+1)+"]//h4[text()='Pending Contact Assignment']")).size()>0)
			titleAndRegistrationContacts = "Pending Contact Assignment";
		
		if(iterator==1)
			if(driver.findElements(By.xpath("//div[div[h4[text()='Violations Management']]]//label[text()='2nd']")).size()>0)
				RC_Global.clickUsingXpath(driver, "//div[div[h4[text()='Violations Management']]]//label[text()='2nd']", "2nd button of 'Delivery'", true, true);
		if(driver.findElements(By.xpath("//div[h4[text()='Violations Management']]/div["+(iterator+1)+"]//b/a/span")).size()>0)
			violationManagementContacts = driver.findElement(By.xpath("//div[h4[text()='Violations Management']]/div["+(iterator+1)+"]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Violations Management']]/div["+(iterator+1)+"]//h4[text()='Pending Contact Assignment']")).size()>0)
			violationManagementContacts = "Pending Contact Assignment";
		
		RC_Global.panelAction(driver, "close", "Contacts", true, true);
		Thread.sleep(2000);
		
		RC_Global.navigateTo(driver, "Manage", "Administration", "Contacts");
		
		RC_Global.enterCustomerNumber(driver, "LS010143", "", "Fleet level", true);
		
		Thread.sleep(3000);
		if(driver.findElements(By.xpath("//div[h4[text()='Main - Fleet']]//b/a/span")).size()>0)
			mainContactsFL = driver.findElement(By.xpath("//div[h4[text()='Main - Fleet']]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Main - Fleet']]/div[1]//h4[text()='Pending Contact Assignment']")).size()>0)
			mainContactsFL = "Pending Contact Assignment";
		
		if(driver.findElements(By.xpath("//div[h4[text()='Accounts Payable']]//b/a/span")).size()>0)
			accountsPayableFL = driver.findElement(By.xpath("//div[h4[text()='Accounts Payable']]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Accounts Payable']]/div[1]//h4[text()='Pending Contact Assignment']")).size()>0)
			accountsPayableFL = "Pending Contact Assignment";
		
		if(driver.findElements(By.xpath("//div[h4[text()='Billing']]//b/a/span")).size()>0)
			billingContactsFL = driver.findElement(By.xpath("//div[h4[text()='Billing']]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Billing']]/div[1]//h4[text()='Pending Contact Assignment']")).size()>0)
			billingContactsFL = "Pending Contact Assignment";
		
		if(iterator==1)
			if(driver.findElements(By.xpath("//div[div[h4[text()='Delivery']]]//label[text()='2nd']")).size()>0)
				RC_Global.clickUsingXpath(driver, "//div[div[h4[text()='Delivery']]]//label[text()='2nd']", "2nd button of 'Delivery'", true, true);
		if(driver.findElements(By.xpath("//div[h4[text()='Delivery']]/div["+(iterator+1)+"]//b/a/span")).size()>0)
			deliveryContactsFL = driver.findElement(By.xpath("//div[h4[text()='Delivery']]/div["+(iterator+1)+"]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Delivery']]/div["+(iterator+1)+"]//h4[text()='Pending Contact Assignment']")).size()>0)
			deliveryContactsFL = "Pending Contact Assignment";
		
		if(iterator==1)
			if(driver.findElements(By.xpath("//div[div[h4[text()='Fuel']]]//label[text()='2nd']")).size()>0)
				RC_Global.clickUsingXpath(driver, "//div[div[h4[text()='Fuel']]]//label[text()='2nd']", "2nd button of 'Delivery'", true, true);
		if(driver.findElements(By.xpath("//div[h4[text()='Fuel']]/div["+(iterator+1)+"]//b/a/span")).size()>0)
			fuelContactsFL = driver.findElement(By.xpath("//div[h4[text()='Fuel']]/div["+(iterator+1)+"]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Fuel']]/div["+(iterator+1)+"]//h4[text()='Pending Contact Assignment']")).size()>0)
			fuelContactsFL = "Pending Contact Assignment";
		
		if(iterator==1)
			if(driver.findElements(By.xpath("//div[div[h4[text()='Maintenance']]]//label[text()='2nd']")).size()>0)
				RC_Global.clickUsingXpath(driver, "//div[div[h4[text()='Maintenance']]]//label[text()='2nd']", "2nd button of 'Delivery'", true, true);
		if(driver.findElements(By.xpath("//div[h4[text()='Maintenance']]/div["+(iterator+1)+"]//b/a/span")).size()>0)
			maintenanceContactsFL = driver.findElement(By.xpath("//div[h4[text()='Maintenance']]/div["+(iterator+1)+"]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Maintenance']]/div["+(iterator+1)+"]//h4[text()='Pending Contact Assignment']")).size()>0)
			maintenanceContactsFL = "Pending Contact Assignment";
		if(driver.findElements(By.xpath("//div[h4[text()='Personal Use']]//b/a/span")).size()>0)
			personalUseContactsFL = driver.findElement(By.xpath("//div[h4[text()='Personal Use']]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Personal Use']]/div[1]//h4[text()='Pending Contact Assignment']")).size()>0)
			personalUseContactsFL = "Pending Contact Assignment";
		
		if(driver.findElements(By.xpath("//div[h4[text()='Remarketing']]//b/a/span")).size()>0)
			remarketingContactsFL = driver.findElement(By.xpath("//div[h4[text()='Remarketing']]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Remarketing']]/div[1]//h4[text()='Pending Contact Assignment']")).size()>0)
			remarketingContactsFL = "Pending Contact Assignment";
		
		if(driver.findElements(By.xpath("//div[h4[text()='Risk']]//b/a/span")).size()>0)
			riskContactsFL = driver.findElement(By.xpath("//div[h4[text()='Billing']]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Risk']]/div[1]//h4[text()='Pending Contact Assignment']")).size()>0)
			riskContactsFL = "Pending Contact Assignment";
		
		if(iterator==1)
			if(driver.findElements(By.xpath("//div[div[h4[text()='Telematics']]]//label[text()='2nd']")).size()>0)
				RC_Global.clickUsingXpath(driver, "//div[div[h4[text()='Telematics']]]//label[text()='2nd']", "2nd button of 'Telematics'", true, true);
		if(driver.findElements(By.xpath("//div[h4[text()='Telematics']]/div["+(iterator+1)+"]//b/a/span")).size()>0)
			telematicsContactsFL = driver.findElement(By.xpath("//div[h4[text()='Telematics']]/div["+(iterator+1)+"]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Telematics']]/div["+(iterator+1)+"]//h4[text()='Pending Contact Assignment']")).size()>0)
			telematicsContactsFL = "Pending Contact Assignment";
		
		if(iterator==1)
			if(driver.findElements(By.xpath("//div[div[h4[text()='Title and Registration']]]//label[text()='2nd']")).size()>0)
				RC_Global.clickUsingXpath(driver, "//div[div[h4[text()='Title and Registration']]]//label[text()='2nd']", "2nd button of 'Delivery'", true, true);
		if(driver.findElements(By.xpath("//div[h4[text()='Title and Registration']]/div["+(iterator+1)+"]//b/a/span")).size()>0)
			titleAndRegistrationContactsFL = driver.findElement(By.xpath("//div[h4[text()='Title and Registration']]/div["+(iterator+1)+"]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Title and Registration']]/div["+(iterator+1)+"]//h4[text()='Pending Contact Assignment']")).size()>0)
			titleAndRegistrationContactsFL = "Pending Contact Assignment";
		
		if(iterator==1)
			if(driver.findElements(By.xpath("//div[div[h4[text()='Violations Management']]]//label[text()='2nd']")).size()>0)
				RC_Global.clickUsingXpath(driver, "//div[div[h4[text()='Violations Management']]]//label[text()='2nd']", "2nd button of 'Delivery'", true, true);
		if(driver.findElements(By.xpath("//div[h4[text()='Violations Management']]/div["+(iterator+1)+"]//b/a/span")).size()>0)
			violationManagementContactsFL = driver.findElement(By.xpath("//div[h4[text()='Violations Management']]/div["+(iterator+1)+"]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Violations Management']]/div["+(iterator+1)+"]//h4[text()='Pending Contact Assignment']")).size()>0)
			violationManagementContactsFL = "Pending Contact Assignment";
		
		RC_Global.panelAction(driver, "close", "Contacts", true, true);
		Thread.sleep(2000);
		
		RC_Global.navigateTo(driver, "Manage", "Administration", "Contacts");
		
		RC_Global.enterCustomerNumber(driver, "LS010143", "", "", true);
		
		Thread.sleep(3000);
		if(driver.findElements(By.xpath("//div[h4[text()='Main - Customer']]//b/a/span")).size()>0)
			mainContactsCus = driver.findElement(By.xpath("//div[h4[text()='Main - Customer']]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Main - Customer']]/div[1]//h4[text()='Pending Contact Assignment']")).size()>0)
			mainContactsCus = "Pending Contact Assignment";
		
		if(driver.findElements(By.xpath("//div[h4[text()='Accounts Payable']]//b/a/span")).size()>0)
			accountsPayableCus = driver.findElement(By.xpath("//div[h4[text()='Accounts Payable']]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Accounts Payable']]/div[1]//h4[text()='Pending Contact Assignment']")).size()>0)
			accountsPayableCus = "Pending Contact Assignment";
		
		if(driver.findElements(By.xpath("//div[h4[text()='Billing']]//b/a/span")).size()>0)
			billingContactsCus = driver.findElement(By.xpath("//div[h4[text()='Billing']]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Billing']]/div[1]//h4[text()='Pending Contact Assignment']")).size()>0)
			billingContactsCus = "Pending Contact Assignment";
		
		if(iterator==1)
			if(driver.findElements(By.xpath("//div[div[h4[text()='Delivery']]]//label[text()='2nd']")).size()>0)
				RC_Global.clickUsingXpath(driver, "//div[div[h4[text()='Delivery']]]//label[text()='2nd']", "2nd button of 'Delivery'", true, true);
		if(driver.findElements(By.xpath("//div[h4[text()='Delivery']]/div["+(iterator+1)+"]//b/a/span")).size()>0)
			deliveryContactsCus = driver.findElement(By.xpath("//div[h4[text()='Delivery']]/div["+(iterator+1)+"]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Delivery']]/div["+(iterator+1)+"]//h4[text()='Pending Contact Assignment']")).size()>0)
			deliveryContactsCus = "Pending Contact Assignment";
		
		if(iterator==1)
			if(driver.findElements(By.xpath("//div[div[h4[text()='Fuel']]]//label[text()='2nd']")).size()>0)
				RC_Global.clickUsingXpath(driver, "//div[div[h4[text()='Fuel']]]//label[text()='2nd']", "2nd button of 'Fuel'", true, true);
		if(driver.findElements(By.xpath("//div[h4[text()='Fuel']]/div["+(iterator+1)+"]//b/a/span")).size()>0)
			fuelContactsCus = driver.findElement(By.xpath("//div[h4[text()='Fuel']]/div["+(iterator+1)+"]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Fuel']]/div["+(iterator+1)+"]//h4[text()='Pending Contact Assignment']")).size()>0)
			fuelContactsCus = "Pending Contact Assignment";
		
		if(iterator==1)
			if(driver.findElements(By.xpath("//div[div[h4[text()='Maintenance']]]//label[text()='2nd']")).size()>0)
				RC_Global.clickUsingXpath(driver, "//div[div[h4[text()='Maintenance']]]//label[text()='2nd']", "2nd button of 'Maintenance'", true, true);
		if(driver.findElements(By.xpath("//div[h4[text()='Maintenance']]/div["+(iterator+1)+"]//b/a/span")).size()>0)
			maintenanceContactsCus = driver.findElement(By.xpath("//div[h4[text()='Maintenance']]/div["+(iterator+1)+"]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Maintenance']]/div["+(iterator+1)+"]//h4[text()='Pending Contact Assignment']")).size()>0)
			maintenanceContactsCus = "Pending Contact Assignment";
		if(driver.findElements(By.xpath("//div[h4[text()='Personal Use']]//b/a/span")).size()>0)
			personalUseContactsCus = driver.findElement(By.xpath("//div[h4[text()='Personal Use']]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Personal Use']]/div[1]//h4[text()='Pending Contact Assignment']")).size()>0)
			personalUseContactsCus = "Pending Contact Assignment";
		
		if(driver.findElements(By.xpath("//div[h4[text()='Remarketing']]//b/a/span")).size()>0)
			remarketingContactsCus = driver.findElement(By.xpath("//div[h4[text()='Remarketing']]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Remarketing']]/div[1]//h4[text()='Pending Contact Assignment']")).size()>0)
			remarketingContactsCus = "Pending Contact Assignment";
		
		if(driver.findElements(By.xpath("//div[h4[text()='Risk']]//b/a/span")).size()>0)
			riskContactsCus = driver.findElement(By.xpath("//div[h4[text()='Billing']]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Risk']]/div[1]//h4[text()='Pending Contact Assignment']")).size()>0)
			riskContactsCus = "Pending Contact Assignment";
		
		if(iterator==1)
			if(driver.findElements(By.xpath("//div[div[h4[text()='Telematics']]]//label[text()='2nd']")).size()>0)
				RC_Global.clickUsingXpath(driver, "//div[div[h4[text()='Telematics']]]//label[text()='2nd']", "2nd button of 'Telematics'", true, true);
		if(driver.findElements(By.xpath("//div[h4[text()='Telematics']]/div["+(iterator+1)+"]//b/a/span")).size()>0)
			telematicsContactsCus = driver.findElement(By.xpath("//div[h4[text()='Telematics']]/div["+(iterator+1)+"]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Telematics']]/div["+(iterator+1)+"]//h4[text()='Pending Contact Assignment']")).size()>0)
			telematicsContactsCus = "Pending Contact Assignment";
		
		if(iterator==1)
			if(driver.findElements(By.xpath("//div[div[h4[text()='Title and Registration']]]//label[text()='2nd']")).size()>0)
				RC_Global.clickUsingXpath(driver, "//div[div[h4[text()='Title and Registration']]]//label[text()='2nd']", "2nd button of 'Delivery'", true, true);
		if(driver.findElements(By.xpath("//div[h4[text()='Title and Registration']]/div["+(iterator+1)+"]//b/a/span")).size()>0)
			titleAndRegistrationContactsCus = driver.findElement(By.xpath("//div[h4[text()='Title and Registration']]/div["+(iterator+1)+"]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Title and Registration']]/div["+(iterator+1)+"]//h4[text()='Pending Contact Assignment']")).size()>0)
			titleAndRegistrationContactsCus = "Pending Contact Assignment";
		
		if(iterator==1)
			if(driver.findElements(By.xpath("//div[div[h4[text()='Violations Management']]]//label[text()='2nd']")).size()>0)
				RC_Global.clickUsingXpath(driver, "//div[div[h4[text()='Violations Management']]]//label[text()='2nd']", "2nd button of 'Delivery'", true, true);
		if(driver.findElements(By.xpath("//div[h4[text()='Violations Management']]/div["+(iterator+1)+"]//b/a/span")).size()>0)
			violationManagementContactsCus = driver.findElement(By.xpath("//div[h4[text()='Violations Management']]/div["+(iterator+1)+"]//b/a/span")).getText();
		else if(driver.findElements(By.xpath("//div[h4[text()='Violations Management']]/div["+(iterator+1)+"]//h4[text()='Pending Contact Assignment']")).size()>0)
			violationManagementContactsCus = "Pending Contact Assignment";
		
		String pendingContactAssignment = "";
		String contactNotAssigned="";
		
		String[] contactType= {mainContacts,accountsPayable,billingContacts,deliveryContacts,fuelContacts,maintenanceContacts, personalUseContacts, remarketingContacts, riskContacts, telematicsContacts, titleAndRegistrationContacts, violationManagementContacts};
		String[] contactTypeFL= {mainContactsFL,accountsPayableFL,billingContactsFL,deliveryContactsFL,fuelContactsFL,maintenanceContactsFL, personalUseContactsFL, remarketingContactsFL, riskContactsFL, telematicsContactsFL, titleAndRegistrationContactsFL, violationManagementContactsFL};
		String[] contactTypeCus= {mainContactsCus,accountsPayableCus,billingContactsCus,deliveryContactsCus,fuelContactsCus,maintenanceContactsCus, personalUseContactsCus, remarketingContactsCus, riskContactsCus, telematicsContactsCus, titleAndRegistrationContactsCus, violationManagementContactsCus};
		String[] contactTypeXpath= {"Main - Account","Accounts Payable","Billing","Delivery","Fuel","Maintenance","Personal Use","Remarketing","Risk","Telematics","Title and Registration","Violations Management"};
		int i=0;
		String toRemove ="";
		String toRemoveFL ="";
		String contactToRemove = "";
		
		for(int iter = 0;iter<contactType.length;iter++ ) {
			if(contactType[iter].equalsIgnoreCase("Pending Contact Assignment")) {
				contactType[iter] = "Pending Contact Assignment";
				queryObjects.logStatus(driver, Status.PASS, "Contact for '"+contactTypeXpath[iter]+"'", "No Contact assigned at any level for Main", null);
			}
			else if(!contactType[iter].equalsIgnoreCase(contactTypeFL[iter])) {
				toRemove = contactType[iter];
				toRemoveFL = contactTypeFL[iter];
				contactToRemove = contactTypeXpath[iter];
				queryObjects.logStatus(driver, Status.PASS, "Contact for '"+contactTypeXpath[iter]+"'", "Contact is assigned at account level. The Contact is: "+contactType[iter], null);
			}
			else if(contactType[iter].equalsIgnoreCase(contactTypeFL[iter])&& !(contactTypeFL[iter].equalsIgnoreCase(contactTypeCus[iter]))) {
				if(!contactTypeXpath[iter].equalsIgnoreCase("Main - Account")&&!contactTypeXpath[iter].equalsIgnoreCase("Accounts Payable")&&!contactTypeXpath[iter].equalsIgnoreCase("Billing")) {
					pendingContactAssignment=contactType[iter];
					contactNotAssigned = contactTypeXpath[iter];
				}
				queryObjects.logStatus(driver, Status.PASS, "Contact for '"+contactTypeXpath[iter]+"'", "Contact is assigned at fleet level. The Contact is: "+contactTypeFL[iter], null);
			}
			else if(contactType[iter].equalsIgnoreCase(contactTypeFL[iter])&&(contactTypeFL[iter].equalsIgnoreCase(contactTypeCus[iter])))
				queryObjects.logStatus(driver, Status.PASS, "Contact for '"+contactTypeXpath[iter]+"'", "Contact is assigned at customer level. The Contact is: "+contactTypeCus[iter], null);
		}
		for(int iter = 0;iter<contactType.length;iter++ ) {
			if(contactType[iter].equalsIgnoreCase("Pending Contact Assignment")) {
				pendingContactAssignment=contactType[iter];
				contactNotAssigned = contactTypeXpath[iter];
				break;
			}
		}
		
		RC_Global.panelAction(driver, "close", "Contacts", true, true);
		Thread.sleep(2000);
		
		RC_Global.navigateTo(driver, "Manage", "Administration", "Contacts");
		RC_Global.waitUntilPanelVisibility(driver, "Contacts", "TV", true, false);
		
		RC_Global.enterCustomerNumber(driver, "LS010143", "", "Account level", true);
		
		Thread.sleep(3000);
		String newContactFN ="";
		String newContactLN = "";
		String newlyAssignedContact = "";
		String[] assignOrRemove = {contactNotAssigned,contactToRemove};
		String[] arContactType = {pendingContactAssignment,toRemove};
		String[] arContactTypeFL = {"",toRemoveFL};
		for(int j=1;j<=2;j++) {
		
			RC_Global.clickButton(driver, "Assign Contact", true, true);
			RC_Global.waitUntilPanelVisibility(driver, "Assign Contact", "TV", true, true);
			
			//
			RC_Global.panelAction(driver, "expand", "Assign Contact", true, false);
			
			
			if(j==2)
				RC_Global.selectDropdownOption(driver, "Contact Type", assignOrRemove[j-1], true, false);
			RC_Global.clickButton(driver, "Search", true, true);
			RC_Global.waitElementVisible(driver, 30, "//table/tbody/tr[1]", "First Row of the Grid", true, false);
			
			if(j==2) {
				newContactFN = arContactType[j-1].split(" ")[0];
				newContactLN = arContactType[j-1].split(" ")[1];
				RC_Global.clickUsingXpath(driver, "//table/tbody/tr[td[text()='"+newContactFN+"'] and td[text()='"+newContactFN+"']]", "First Row of the Grid", true, false);
			}
			else {
				newContactFN = driver.findElement(By.xpath("//table/tbody/tr[1]/td[1]")).getText();
				newContactLN = driver.findElement(By.xpath("//table/tbody/tr[1]/td[2]")).getText();
				newlyAssignedContact = newContactFN+" "+newContactLN;
				RC_Global.clickUsingXpath(driver, "//table/tbody/tr[1]", "First Row of the Grid", true, false);
			}
		
			RC_Global.clickButton(driver, "Select Contact", true, true);
			Thread.sleep(2000);
			if(iterator==1)
				RC_Global.clickUsingXpath(driver, "//label[text()='2nd']", "2nd button of 'Maintenance'", true, true);
			if((!(assignOrRemove[j-1].equalsIgnoreCase(""))))
				RC_Global.selectDropdownOption(driver, "Contact Type to Assign", assignOrRemove[j-1], true, true);
			else if(j==2&&assignOrRemove[j-1].equalsIgnoreCase("")) {
				queryObjects.logStatus(driver, Status.INFO, "Contacts assigned at Account level", "No contacts are assigned at Account level", null);
				continue;
			}
			else if(j==1&&assignOrRemove[j-1].equalsIgnoreCase("")) {
				queryObjects.logStatus(driver, Status.INFO, "Contacts assigned at Account level", "No contacts available to assign at Account level", null);
				RC_Global.panelAction(driver, "close", "Assign Contact", true, false);
				continue;
			}
			if(j==1)
				RC_Global.clickUsingXpath(driver, "//label[contains(text(),'"+accountLevel+"')]/input", "Assign account level with contact for "+assignOrRemove[j-1], true, true);
			else
				RC_Global.clickUsingXpath(driver, "//label[contains(text(),'"+accountLevel+"')]/input", "Remove account level with contact for "+assignOrRemove[j-1], true, true);
			Thread.sleep(2000);
			
			RC_Global.clickUsingXpath(driver, "(//button[normalize-space(text())='Save'])[2]", "Save button", true, true);
			
			try {
				RC_Global.waitElementVisible(driver, 30, "(//h4[text()='Update Successful'])[1]", "Successful Save Message", false, true);
				queryObjects.logStatus(driver, Status.PASS, "Verify Success Message", "The expected message appeared", null);
			}
			catch(Exception e) {
				queryObjects.logStatus(driver, Status.FAIL, "Verify Success Message", "The expected message did not appear", null);
			}
			
			RC_Global.panelAction(driver, "close", "Assign Contact", true, true);
			RC_Global.panelAction(driver, "close", "Contacts", true, false);
			
			RC_Global.navigateTo(driver, "Manage", "Administration", "Contacts");
			if(j==2) {
				RC_Global.enterCustomerNumber(driver, "LS010143", "", "Fleet level", true);
				
				Thread.sleep(3000);
				
				if(iterator==1)
					RC_Global.clickUsingXpath(driver, "//div[div[h4[text()='"+assignOrRemove[j-1]+"']]]//label[text()='2nd']", "2nd button of '"+assignOrRemove[j-1]+"'", true, true);
				if(driver.findElements(By.xpath("//div[h4[text()='"+assignOrRemove[j-1]+"']]//b/a/span")).size()>0)
					arContactTypeFL[j-1] = driver.findElement(By.xpath("//div[h4[text()='"+assignOrRemove[j-1]+"']]//b/a/span")).getText();
				
				else if(driver.findElements(By.xpath("//div[h4[text()='"+assignOrRemove[j-1]+"']]/div[1]//h4[text()='Pending Contact Assignment']")).size()>0) {
					arContactTypeFL[j-1] = "Pending Contact Assignment";
					
					if(j==1)
						queryObjects.logStatus(driver, Status.FAIL, "Verify contact assignment was successful", "Contact was not assigned", null);
				}
				RC_Global.panelAction(driver, "close", "Contacts", true, false);
				
				RC_Global.navigateTo(driver, "Manage", "Administration", "Contacts");
			}
			RC_Global.enterCustomerNumber(driver, "LS010143", "", "Account level", true);
			
			Thread.sleep(3000);
			
			if(iterator==1)
				RC_Global.clickUsingXpath(driver, "//div[div[h4[text()='"+assignOrRemove[j-1]+"']]]//label[text()='2nd']", "2nd button of '"+assignOrRemove[j-1]+"'", true, true);
			if(driver.findElements(By.xpath("//div[h4[text()='"+assignOrRemove[j-1]+"']]//b/a/span")).size()>0) {
				arContactType[j-1] = driver.findElement(By.xpath("//div[h4[text()='"+assignOrRemove[j-1]+"']]//b/a/span")).getText();
				if(j==1) {
					if(arContactType[j-1].trim().equalsIgnoreCase(newlyAssignedContact))
						queryObjects.logStatus(driver, Status.PASS, "Contact Assignment updated successfully", "Assigned Contact is "+arContactType[j-1], null);
					else
						queryObjects.logStatus(driver, Status.FAIL, "Contact Assignment not updated successfully", "Assigned Contact is "+arContactType[j-1], null);
				}
				
			}
			if(j==2) {
				if(iterator==1)
					RC_Global.clickUsingXpath(driver, "//div[div[h4[text()='"+assignOrRemove[j-1]+"']]]//label[text()='2nd']", "2nd button of '"+assignOrRemove[j-1]+"'", true, true);
				if(driver.findElements(By.xpath("//div[h4[text()='"+assignOrRemove[j-1]+"']]/div[1]//h4[text()='Pending Contact Assignment']")).size()>0)
					queryObjects.logStatus(driver, Status.PASS, "Contact Assignment removed successfully", "No contacts are assigned. Card reads 'Pending Contact Assignment'", null);	
				else if(arContactType[j-1].equalsIgnoreCase(arContactTypeFL[j-1]))
					queryObjects.logStatus(driver, Status.PASS, "Contact Assignment removed successfully", "No contacts are assigned at Account level. Card reads contact assigned at Fleet level", null);
				else
					queryObjects.logStatus(driver, Status.FAIL, "Contact Assignment removed successfully", "Contact was not removed", null);
				
			}
			
		}
		}
		
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
