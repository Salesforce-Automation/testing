package Manage.Administration.Contacts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_6_1_3_04 {
	public void EmployeeManagement_ContactCardNameLinkedToEditEmployee(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String menu = "Manage";
		String firstSubMenu = "Administration";
		String secondSubMenu = "Contacts";
		String FirstName="";
		WebElement element=null;
		
		String CustomerName ="";
//		WebElement element1=null;
		
		RC_Global.login(driver);
		RC_Global.enterCustomerFocus(driver, "LS008742", false);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
	//	RC_Global.clickUsingXpath(driver, "(//span[@class='edit-employee ng-binding'])[1]", "Customer Name", false);
		
		RC_Global.createNode(driver,"Verify a customer name and navigate to Edit Employee page");
        RC_Global.clickUsingXpath(driver,"(//span[@class='edit-employee ng-binding'])[1]", "Customer Name",false,true);
        RC_Global.validateHeaderName(driver, "Edit Employee",true);
        RC_Global.panelAction(driver, "expand", "Edit Employee",false,true);
		
        element=driver.findElement(By.xpath("//input[@placeholder='First Name']"));
        FirstName=element.getText();
		element.clear();
		if(!FirstName.isEmpty())
	        RC_Global.enterInput(driver, FirstName, element, false,true);
	        else
	        {
	        	String Name = "Becoz";
	        	RC_Global.enterInput(driver, Name, element, false,true);
	        }
		
		 RC_Global.clickButton(driver, " Save ", false,true);
		 Thread.sleep(2000);
		 if(driver.findElements(By.xpath("//h3[span[text()='Invalid '] and span[text()=' address entered.']]")).size()>0) {
			 RC_Global.clickButton(driver, "Save As Entered", true, false);
			 Thread.sleep(6000);
			 }
		 
	     RC_Global.verifyDisplayedMessage(driver, "Employee Updated Successfully", false);
	     
	     RC_Global.panelAction(driver, "close","Edit Employee",false,true);
	     
	     RC_Global.validateHeaderName(driver, "Contacts",true);
	     
	     CustomerName=driver.findElement(By.xpath("(//span[@class='edit-employee ng-binding'])[1]")).getText();
	     queryObjects.logStatus(driver, Status.PASS, "Contacts screen opened and details updated with Customer Name", CustomerName, null);

	     
	     RC_Global.panelAction(driver, "close", "Contacts",false,true);
	     RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	     
	}
}
