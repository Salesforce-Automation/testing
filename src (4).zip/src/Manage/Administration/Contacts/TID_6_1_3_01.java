package Manage.Administration.Contacts;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;


public class TID_6_1_3_01 {
	public void  AssignContactCustomerStructureSelection(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		
		String CustomerNumber = "LS008742";
		RC_Global.login(driver);
		RC_Global.enterCustomerFocus(driver, CustomerNumber, true);
		RC_Global.navigateTo(driver,"Manage","Administration","Contacts");
		RC_Global.waitUntilPanelVisibility(driver, "Contacts", "TV", true,false);
		RC_Global.clickButton(driver, "Assign Contact", true,true);
		RC_Global.waitUntilPanelVisibility(driver, "Assign Contact", "TV", true,true);
		RC_Global.panelAction(driver, "close", "Contacts", true,false);
		Thread.sleep(2000);
		RC_Global.panelAction(driver, "expand", "Assign Contact", true,false);
		RC_Global.clickButton(driver, "Search", true,true);
		RC_Global.waitElementVisible(driver, 30, "//tbody//tr[1]", "Grid Load", true,false);
		RC_Global.clickUsingXpath(driver, "//tbody//tr[1]//td[3]", "Select Record", true,false);
		if(driver.findElements(By.xpath("//h3[text()='Contact Types']")).size()>0)
            RC_Global.clickButton(driver, "OK", true, false);
		RC_Global.clickButton(driver, "Select Contact", true,true);
		RC_Global.waitUntilPanelVisibility(driver, "Assign Contact", "TV", true,true);
	//	RC_Global.selectDropdownOption(driver, "contactType", "Fuel", true,true);
		RC_Global.clickUsingXpath(driver, "(//select[@id='contactType'])[2]", "Contact Type selection", true, false);
		RC_Global.clickUsingXpath(driver, "(//select[@id='contactType'])[2]/option[text()='Fuel']", "Contact Type selection", true, false);

		RC_Global.waitElementVisible(driver, 30, "(//tbody//tr[1])[2]/td[1]//label[contains(text(),'"+CustomerNumber+"')]", "Assign contact", true,true);
		String SelectedContactNam = driver.findElement(By.xpath("//input[@placeholder='Selected Contact']")).getAttribute("value");
		Thread.sleep(2000);
		//select level  
		RC_Global.clickUsingXpath(driver, "(//input[contains(@id,'checkbox-1')])[1]", "Select check box", true,true);
		List<WebElement> CntctAssClmn = driver.findElements(By.xpath("//span[text()='Contact to Assign']"));
		if(CntctAssClmn.size()>0) 
            queryObjects.logStatus(driver, Status.PASS, "Contact to Assign", "Contact to Assign column appears on the page after clicking on checkbox", null);
		else {
            queryObjects.logStatus(driver, Status.FAIL, "Contact to Assign", "Contact to Assign column does not appears on the page after clicking on checkbox", null);
            RC_Global.endTestRun(driver);
		}
		List<WebElement> ContactName = driver.findElements(By.xpath("//span[text()='Contact to Assign']"));
		if(ContactName.size()>0) 
            queryObjects.logStatus(driver, Status.PASS, "Contact to Assign", "Contact�s name is appearing in the �Contact to Assign� column for the current checked level", null);
		else {
            queryObjects.logStatus(driver, Status.FAIL, "Contact to Assign", "Contact�s name is not appearing in the �Contact to Assign� column for the current checked level", null);
            RC_Global.endTestRun(driver);
		}
		
		RC_Global.clickUsingXpath(driver, "//label[contains(text(),'"+CustomerNumber+"')]/input", "Select All check box", true,true);
		List<WebElement> AlContactName = driver.findElements(By.xpath("//td[text()='"+SelectedContactNam+"']"));
		if(AlContactName.size()>0) 
            queryObjects.logStatus(driver, Status.PASS, "Contact Name", "Contact�s name is appearing in the �Contact to Assign� column for entire Customer hirarchy", null);
		else {
            queryObjects.logStatus(driver, Status.FAIL, "Contact Name", "Contact�s name is not appearing in the �Contact to Assign� column for entire Customer hirarchy", null);
            RC_Global.endTestRun(driver);
		}
		RC_Global.logout(driver, false);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}
}
