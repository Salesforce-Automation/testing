package tools.LeaseWave;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import MF.Source.Cred;
import tools.TotalView.RC_Global;

public class RC_LW_Global {
	static BFrameworkQueryObjects queryObjects = new BFrameworkQueryObjects();
	
	public static void leaseWaveLogin(WebDriver driver,boolean endRun) throws Exception{
		RC_Global.createNode(driver, "Login to Leasewave Application");
		try {
			String username = Cred.UserName; 
			String password =Cred.PassWord;
			String env = Cred.ENV;
			String urlEnv = "";
			
			switch(env) {
			case "QA": urlEnv = "q"; break;
			case "UAT": urlEnv = "u";break;
			case "DEV": urlEnv = "d";break;
			}
			if (Cred.isVMRun) {
				driver.get("http://m1wapplw02-"+urlEnv+".corp.local/LogOnPage.aspx?CompanyName=Merchants&Culture=en-US&IsLogInAsAnotherUser=Y&VersionNumber=4.2.3.30");
	            Thread.sleep(1000);
	            driver.findElement(By.xpath("//input[contains(@name, 'txtUserName')]")).clear();
	            Thread.sleep(1000);
	            driver.findElement(By.xpath("//input[contains(@name, 'txtUserName')]")).sendKeys(username);
	            Thread.sleep(1000);
	            driver.findElement(By.xpath("//input[contains(@name, 'txtPassword')]")).sendKeys(password);
			} else {
				driver.get("http://"+username+":"+password+"@m1wapplw02-"+urlEnv+".corp.local/LogOnPage.aspx?CompanyName=Merchants&Culture=en-US&IsLogInAsAnotherUser=Y&VersionNumber=4.2.3.30");
			}
			//driver.get("http://"+username+":"+password+"@m1wapplw02-"+urlEnv+"/LogOnPage.aspx?CompanyName=Merchants&Culture=en-US&IsLogInAsAnotherUser=Y&VersionNumber=4.2.3.20");
			//driver.get("http://"+username+":"+password+"@m1wapplw02-"+urlEnv+".corp.local/LogOnPage.aspx?CompanyName=Merchants&Culture=en-US&IsLogInAsAnotherUser=Y&VersionNumber=4.2.3.30");
			Thread.sleep(2000);
			driver.findElement(By.xpath("//button[@accesskey='L']")).click();
		    RC_Global.waitElementVisible(driver, 50, "//span[@class='header-portfolio']", "LeaseWave header-portfolio",endRun, true);
		    String home =  driver.findElement(By.xpath("//span[@class='header-portfolio']")).getText();
		    if(home.contains("Portfolio: Merchants Environment : Merchants")) {
		    	queryObjects.logStatus(driver, Status.PASS, "Login to LeaseWave", "Successfully", null);	
		    }
		}
		catch(Exception e) {
			BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Login to LeaseWave Failed",e.getLocalizedMessage(), e);	
			if(endRun)
				RC_Global.endTestRun(driver);
		}	
	}

	public static void leaseWaveLogOut(WebDriver driver,boolean endRun) throws Exception {
		RC_Global.createNode(driver, "Logging out of Leasewave Application");
		try {
		driver.findElement(By.xpath("//a[@title='Log Out from LeaseWave']")).click();
		Thread.sleep(2000);
	    RC_Global.waitElementVisible(driver, 50, "//span[text()='You have successfully logged out']", "Successfully logged out",endRun,false);
	    queryObjects.logStatus(driver, Status.PASS, "Logged out of LeaseWave", "Successfully", null);}
		catch(Exception e) {
			BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Logging out of LeaseWave Failed",e.getLocalizedMessage(), e);
			if(endRun)
				RC_Global.endTestRun(driver);
		}	
	}
	
}
