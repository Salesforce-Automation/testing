package tools.LeaseWave;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import MF.Source.Cred;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;

public class RC_LW_FleetServices {
	static BFrameworkQueryObjects queryObjects = new BFrameworkQueryObjects();
	
	public static void leaseWaveRepairOrderNumberValidation(WebDriver driver, String PO_Number, String[] CreateRoPageValues,boolean endRun) throws Exception {
		RC_Global.createNode(driver, "Repair Order Details Validation in LeaseWave Application");
        try {
		   driver.findElement(By.xpath("//a[contains(text(),'Fleet Management')]")).click();
		   RC_Global.waitElementVisible(driver, 50, "//span[text()='Fleet Management Menu']", "Fleet Management Menu",endRun, false);
           String home =  driver.findElement(By.xpath("//span[text()='Fleet Management Menu']")).getText();
           if(home.contains("FLEET MANAGEMENT MENU")) {
               BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Navigation to Fleet Management Menu", "Successfully", null);   
           }
           driver.findElement(By.xpath("//td[@accesskey='2' and text()='. Charges/Services']")).click();
           Thread.sleep(500);
           driver.findElement(By.xpath("(//td[@accesskey='M']/div[text()='aintenance PO'])[1]")).click();
           Thread.sleep(500);
           driver.findElement(By.xpath("//tr[contains(@igurl,'MaintenancePO')]/td[@accesskey='R']")).click();
           Thread.sleep(100);
		   RC_Global.waitElementVisible(driver, 50, "//span[text()='Maintenance PO List' and @id='ctl00_PageTitle']", "Maintenance PO List",endRun, false);
           driver.findElement(By.xpath("//td[@lw_friendlyname='PO Number']//input")).sendKeys(PO_Number);
           Thread.sleep(1000);
           driver.findElement(By.xpath("//button[text()='Searc']")).click();
		   RC_Global.waitElementVisible(driver, 50, "//tbody/tr/th", "Search Results",endRun, false);
           driver.findElement(By.xpath("//button[text()='dit']")).click();
           Thread.sleep(1000);
           try {
           driver.switchTo().alert().accept(); 
           }
           catch(Exception e){
        	   if(endRun)
					RC_Global.endTestRun(driver);
           }
		   RC_Global.waitElementVisible(driver, 50, "//a[text()='Generic PO Details']", "Generic PO Details",endRun, false);
           String LWVendorName =  driver.findElement(By.xpath("(//span[text()='Vendor Name :']/following::span//input)[1]")).getAttribute("value");
           Thread.sleep(500);
           String LWPOCreatedBy = driver.findElement(By.xpath("(//span[text()='PO Created By']/following::span//input)[1]")).getAttribute("value");
           Thread.sleep(500);
         
           String LWGLtemplate = driver.findElement(By.xpath("//select[contains(@name,'GLTransaction')]/option[@selected='selected']")).getText();
           Thread.sleep(500);
           String LWBillProduct = driver.findElement(By.xpath("//select[contains(@name,'BillProductName')]/option[@selected='selected']")).getText();
           Thread.sleep(500);
           String LWBillInvoice = driver.findElement(By.xpath("//select[contains(@name,'BillBackInvoice')]/option[@selected='selected']")).getText();
           Thread.sleep(500);
           
           		if(CreateRoPageValues[0] != null) {
                   if(LWVendorName.contains(CreateRoPageValues[0]) || CreateRoPageValues[0].contains(LWVendorName))
                	   queryObjects.logStatus(driver, Status.PASS, "Vendor Name Validation in LeaseWave and TotalView is", "Successful", null);
                   else
                	   queryObjects.logStatus(driver, Status.FAIL, "Vendor Name Validation in LeaseWave and TotalView is", "Failed", null);
           		}
           		if(CreateRoPageValues[1] != null) {
                   if(LWPOCreatedBy.contains(CreateRoPageValues[1]))
                	   queryObjects.logStatus(driver, Status.PASS, "RO Created Validation in LeaseWave and TotalView is", "Successful", null);
                   else
                	   queryObjects.logStatus(driver, Status.FAIL, "RO Created Validation in LeaseWave and TotalView is", "Failed", null);
           		}
           		if(CreateRoPageValues[2] != null) {
                   if(LWGLtemplate.contains(CreateRoPageValues[2]))
                	   queryObjects.logStatus(driver, Status.PASS, "GL Template Validation in LeaseWave and TotalView is", "Successful", null);
                   else
                	   queryObjects.logStatus(driver, Status.FAIL, "GL Template Validation in LeaseWave and TotalView is", "Failed", null);
           		}
           		if(CreateRoPageValues[3] != null) {
                   if(LWBillProduct.contains(CreateRoPageValues[3]))
                	   queryObjects.logStatus(driver, Status.PASS, "Bill Product Name Validation in LeaseWave and TotalView is", "Successful", null);
                   else
                	   queryObjects.logStatus(driver, Status.FAIL, "Bill Product Name Validation in LeaseWave and TotalView is", "Failed", null);
           		}
           		if(CreateRoPageValues[4] != null) {
                   if(LWBillInvoice.contains(CreateRoPageValues[4]))
                	   queryObjects.logStatus(driver, Status.PASS, "Bill Back Invoice Validation in LeaseWave and TotalView is", "Successful", null);
                   else
                	   queryObjects.logStatus(driver, Status.FAIL, "Bill Back Invoice Validation in LeaseWave and TotalView is", "Failed", null);    
           		}
            Thread.sleep(1000);
           		RC_Global.clickUsingXpath(driver, "//button[2][text()='lose']","Close button",endRun, false);
           		if(driver.findElement(By.xpath("//*[@value='Save']")).isEnabled())
           			RC_Global.clickUsingXpath(driver, "//*[@value='Save']","Save button",endRun, false);
           		else if (driver.findElement(By.xpath("//*[@value='Cancel']")).isEnabled())
           			RC_Global.clickUsingXpath(driver, "//*[@value='Cancel']","Close button",endRun, false);
           		else if (driver.findElement(By.xpath("//*[@value='Close']")).isEnabled())
           			RC_Global.clickUsingXpath(driver, "//*[@value='Close']","Close button",endRun, false);
	}catch(TimeoutException te) {
		queryObjects.logStatus(driver, Status.FAIL, "Navigate to the required screen failed -> Unable to load the current/previous screen", te.getLocalizedMessage(), te);
		 if(endRun)
				RC_Global.endTestRun(driver);
	} 
    catch(Exception e) {        
    	BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Repair Order Number Validation In LeaseWave Failed ", e.getLocalizedMessage(), e);   
    	 if(endRun)
				RC_Global.endTestRun(driver);
    }
}
	
	public static void createPoProfileInLeaseWave(WebDriver driver,boolean endRun) throws Exception {
		
		RC_Global.createNode(driver, "Creating Po Profile in LeaseWave");
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		String currentwindow = driver.getWindowHandle();
		WebDriverWait wait = new WebDriverWait(driver,50);

        try {
		   driver.findElement(By.xpath("//a[contains(text(),'Fleet Management')]")).click();
		   RC_Global.waitElementVisible(driver, 50, "//span[text()='Fleet Management Menu']", "Fleet Management Menu",endRun, false);
           String home =  driver.findElement(By.xpath("//span[text()='Fleet Management Menu']")).getText();
           if(home.contains("FLEET MANAGEMENT MENU")) {
        	   queryObjects.logStatus(driver, Status.PASS, "Navigation to Fleet Management Menu", "Successfully", null);   
           }
           driver.findElement(By.xpath("//td[@accesskey='3' and text()='. Templates']")).click();
           Thread.sleep(500);
           driver.findElement(By.xpath("//td[@accesskey='U']/div[text()='ser Profile']")).click();
           Thread.sleep(500);
		   RC_Global.waitElementVisible(driver, 50, "(//span[text()='PO User Profile List'])[1]", "PO User Profile List",endRun, false);
           driver.findElement(By.xpath("//td[@lw_columnname='LoginName']/input")).sendKeys(Cred.UserName);
           Thread.sleep(500);
           RC_Global.clickButton(driver, "Searc",endRun, false);
           Thread.sleep(2000);
           if(driver.findElements(By.xpath("//img[@imgtype='tri']")).size()>0) {
        	   RC_Global.clickButton(driver, "dit",endRun, false);
    		   RC_Global.waitElementVisible(driver, 50, "//span[text()='PO User Profile Details']", "PO User Profile List",endRun, false);
               WebElement POLimit =  driver.findElement(By.xpath("(//span[text()='PO Approval Limit']/following::input[@type='text'])[1]"));
               POLimit.clear();
               Thread.sleep(1000);
               POLimit.sendKeys("10000");
               POLimit.clear();
               POLimit.sendKeys("10000");
//               JS.executeScript("arguments[0].value='10000';", POLimit);
               driver.findElement(By.xpath("(//td[@valign='middle']/img)[1]")).click();
               Thread.sleep(2000);
           }
           else {
        	   RC_Global.clickButton(driver, "dd",endRun, false);
    		   RC_Global.waitElementVisible(driver, 50, "//span[text()='PO User Profile Details']", "PO User Profile List",endRun, false);
               RC_Global.clickUsingXpath(driver, "//button[@url='/UserManagement/UserProfile/UserList.aspx?PPL=Y&ChildWindowMode=Y&CallBackFunction=PO_UP_RefreshPage();&ParentControlsIDCSV=ctl00_F_PH_hidUserCode,ctl00_F_PH_hidUserName,ctl00_F_PH_hidUserId,']","User Profile",endRun, false);
               for(String winHandle : driver.getWindowHandles()){
            	    driver.switchTo().window(winHandle);
            	}
    		   RC_Global.waitElementVisible(driver, 50, "(//span[text()='User Profile List'])[1]", "User Profile List",endRun, false);
               driver.findElement(By.xpath("//td[@lw_friendlyname='Login Name']/input")).sendKeys(Cred.UserName);
               Thread.sleep(500);
               RC_Global.clickButton(driver, "Searc",endRun, false);
               wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//img[@imgtype='tri']")));
               RC_Global.clickButton(driver, "elect",endRun, false);
               driver.switchTo().window(currentwindow);
    		   RC_Global.waitElementVisible(driver, 50, "//span[text()='PO User Profile Details']", "PO User Profile Details",endRun, false);
               WebElement POLimit =  driver.findElement(By.xpath("(//span[text()='PO Approval Limit']/following::input[@type='text'])[1]"));
               POLimit.clear();
               Thread.sleep(500);
               POLimit.sendKeys("10000");
               POLimit.clear();
               POLimit.sendKeys("10000");
               
               
               WebElement InvoiceApprovalLimit =   driver.findElement(By.xpath("(//span[text()='Invoice Approval Differential ($ value)']/following::input[@type='text'])[1]"));
               InvoiceApprovalLimit.clear();
               Thread.sleep(500);
               InvoiceApprovalLimit.sendKeys("10000");
               InvoiceApprovalLimit.clear();
               InvoiceApprovalLimit.sendKeys("10000");
               //JS.executeScript("arguments[0].value='10000';", InvoiceApprovalLimit);
               
               WebElement InvoiceApprovalDifferential = driver.findElement(By.xpath("(//span[text()='Invoice Approval Differential (% value)']/following::input[@type='text'])[1]"));
               InvoiceApprovalDifferential.clear();
               Thread.sleep(500);
               InvoiceApprovalDifferential.sendKeys("100");
               InvoiceApprovalDifferential.clear();
               InvoiceApprovalDifferential.sendKeys("100");
               //JS.executeScript("arguments[0].value='100';", InvoiceApprovalDifferential);
  
               Thread.sleep(500);
               driver.findElement(By.xpath("//input[@type='checkbox' and not(@disabled='disabled')]")).click();
               Thread.sleep(2000);
           }
           Thread.sleep(1000);
           RC_Global.clickButton(driver, "ave",endRun, false);
           RC_Global.waitElementVisible(driver, 50, "(//span[text()='PO User Profile List'])[1]", "PO User Profile List",endRun, false);
           RC_Global.clickButton(driver, "lose",endRun, false);
           RC_Global.waitElementVisible(driver, 50, "//span[text()='Fleet Management Menu']", "Fleet Management Menu",endRun, false);
   		   BFrameworkQueryObjects.logStatus(driver, Status.PASS, "PO Profile Created In LeaseWave","Successfully", null);   

        }catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "Navigate to the required screen failed -> Unable to load the current/previous screen", te.getLocalizedMessage(), te);
			 if(endRun)
					RC_Global.endTestRun(driver);
	    } catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver, Status.FAIL, "PO Profile Creation In LeaseWave Failed ---> Required fields are not available to perform any action at the moment", nse.getLocalizedMessage(), nse);
			 if(endRun)
					RC_Global.endTestRun(driver);
		}
        catch(Exception e) {
        	BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "PO Profile Creation In LeaseWave Failed", e.getLocalizedMessage(), e);
        	 if(endRun)
					RC_Global.endTestRun(driver);
        }
	}

	public static void leaseWaveDriverAssignment(WebDriver driver,boolean endRun) throws Exception{
	RC_Global.createNode(driver, "Assigning Driver in LeaseWave");
	try {
		
		RC_Global.clickUsingXpath(driver,"//a[contains(text(),'Fleet Management')]","Fleet Management",endRun, false);
		RC_Global.waitElementVisible(driver, 50, "//span[text()='Fleet Management Menu']", "Fleet Management Menu",endRun, false);
	    String home =  driver.findElement(By.xpath("//span[text()='Fleet Management Menu']")).getText();
	    if(home.contains("FLEET MANAGEMENT MENU")) {
	    	queryObjects.logStatus(driver, Status.PASS, "Navigation to Fleet Management Menu", "Successfully", null);	
	    }
	    
	    RC_Global.clickUsingXpath(driver,"//td[@accesskey='1' and text()='. Profiles']","Profiles",endRun, false);
	    RC_Global.clickUsingXpath(driver,"//td[@accesskey='D']","Driver",endRun, false);
	    RC_Global.clickUsingXpath(driver,"//tr[contains(@igurl,'AssignDriverToAsset')]/td[@accesskey='A']","AssignDriver to Asset",endRun, false);
		RC_Global.waitElementVisible(driver, 50, "//span[text()='Asset List' and @id='ctl00_PageTitle']", "Asset List",endRun, false);
	    driver.findElement(By.xpath("//td[@lw_friendlyname='Unit Number']//input")).sendKeys(RC_FleetServices.UnitNumber);
	    RC_Global.clickUsingXpath(driver,"//button[text()='Searc']","Search button",endRun, false);
	    RC_Global.clickUsingXpath(driver,"//button[text()='elect']","Select button",endRun, false);
	    Thread.sleep(2000);
	    try {
	    	   Thread.sleep(2000);
	           driver.switchTo().alert().accept(); 
	           Thread.sleep(2000);
	           driver.findElement(By.xpath("//img[@alt='Hide Message Window']")).click();
	         }
	    catch(Exception e){
	    	if(endRun)
				RC_Global.endTestRun(driver);
	    }
		RC_Global.waitElementVisible(driver, 50, "//span[text()='Assign Driver to Asset']", "Assign Driver to Asset",endRun, false);
	    String DriverName = driver.findElement(By.xpath("//tbody/tr/td[contains(@uv,'"+RC_FleetServices.drivername+"')]/nobr")).getText();
	    WebElement checkbox = driver.findElement(By.xpath("//table/tbody/tr[1][td[contains(@uv,'"+RC_FleetServices.drivername+"')]]/td[12]/nobr/input[contains(@type,'checkbox')]"));
	    
	    if(checkbox.isSelected()) {
			queryObjects.logStatus(driver, Status.PASS, "The new assigned driver", " as "+DriverName+", and IS Primary is selected "+checkbox+" ", null);
		}
		else if(!checkbox.isSelected()) {
			queryObjects.logStatus(driver, Status.PASS, "The new assigned driver", " as "+DriverName+", and IS Primary is not selected "+checkbox+" ", null);
		}
	}

	catch(Exception e) {
		queryObjects.logStatus(driver, Status.FAIL, "Fleet Management Failed", e.getLocalizedMessage(), e);	
		if(endRun)
			RC_Global.endTestRun(driver);
		}
	}
    
	public static void leasewaveDriverDataChangeValidation(WebDriver driver,boolean endRun)throws Exception{
	RC_Global.createNode(driver, "Driver data Change validation in LeaseWave");
	String Fleet_Management="";
	try {
		
		RC_Global.clickUsingXpath(driver,"//a[contains(text(),'Portfolio Management')]","Portfolio Management",endRun, false);
		RC_Global.waitElementVisible(driver, 50, "//a[contains(text(),'Portfolio Management')]", "Portfolio Management",endRun, false);
	    String home =  driver.findElement(By.xpath("//a[contains(text(),'Portfolio Management')]")).getText();
	    if(home.contains("Portfolio Management")) {
	    	queryObjects.logStatus(driver, Status.PASS, "Navigation to Fleet Management Menu", "Successfully", null);	
	    }
	    RC_Global.clickUsingXpath(driver,"//td[@accesskey='3' and text()='.Asset']","Asset option",endRun, false);
	    RC_Global.clickUsingXpath(driver,"//tr[contains(@igurl,'InventoryProfile/AssetList')]/td[@accesskey='P']","Inventory Profile option",endRun, false);
		RC_Global.waitElementVisible(driver, 50, "//span[text()='Asset List' and @id='ctl00_PageTitle']", "Asset List",endRun, false);
	    
	    driver.findElement(By.xpath("//td//input[contains(@name,'UnitNumber')]")).sendKeys(RC_FleetServices.UnitNumber);
	    RC_Global.clickUsingXpath(driver,"//button[text()='Searc']","Search button",endRun, false);
	    Thread.sleep(2000);
	    //check for drivername change
	    String LWdriverNm = driver.findElement(By.xpath("//td[10]//nobr")).getText();
	    String [] name =LWdriverNm.split("/");
	    RC_FleetServices.Firstname= name[1];
	    RC_FleetServices.Lastname= name[0];
	    String LWDriverFrstname = name[1].concat(" ");
	    String LWDriverFullname = LWDriverFrstname.concat(name[0]);
	    
	    if(RC_FleetServices.drivername.contains(LWDriverFullname)) {
	    	queryObjects.logStatus(driver, Status.PASS, "Driver Data change is done", "Successfully", null);	
	    }
	    else {
	    	queryObjects.logStatus(driver, Status.FAIL, "Driver Data change is not","reflected in Leasewave", null);	
	    }
	    JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true)",driver.findElement(By.xpath("//h2/span[text()='Asset List']")));
	
		RC_Global.clickUsingXpath(driver,"//button[text()='dit']","Edit button",endRun, false);
		RC_Global.waitElementVisible(driver, 50, "//span[text()='Asset Profile Home']", "Asset Profile Home",endRun, false);
	   	String Asset_status =driver.findElement(By.xpath("//input[contains(@name,'Status')]")).getAttribute("value");
	   
	   	RC_Global.clickUsingXpath(driver,"//a[text()='Location History']","Location History",endRun, false);
		RC_Global.waitElementVisible(driver, 50, "//span[text()='Location History']", "Location History",endRun, false);

	   	String address =  driver.findElement(By.xpath("//tbody/tr[1]/td[8][contains(@id,'grdLocationHistory')]/nobr")).getText();
	   if(address.equals(RC_FleetServices.DriverAddress))			    
		   queryObjects.logStatus(driver, Status.PASS, "The most recent address is the new Employee Address", address, null);
	   else
		   queryObjects.logStatus(driver, Status.FAIL, "The most recent address is not matches with new Employee Address", address, null);
	
	   	RC_Global.clickUsingXpath(driver,"(//button[@accesskey='C' and text()='lose'])[2]","Close button",endRun, false);
	   	RC_Global.clickUsingXpath(driver,"(//button[@accesskey='C' and text()='lose'])[1]","Close button",endRun, false);
		RC_Global.waitElementVisible(driver, 50, "//span[text()='Asset List' and @id='ctl00_PageTitle']", "Asset List",endRun, false);

	    }
	catch(Exception e) {
		queryObjects.logStatus(driver, Status.FAIL, "Portfolio Management Failed", e.getLocalizedMessage(), e);	
		if(endRun)
			RC_Global.endTestRun(driver);
	}
}
	
	
}
