package tools.LeaseWave;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeoutException;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class RC_LW_Manage {
	
	static BFrameworkQueryObjects queryObjects = new BFrameworkQueryObjects();
	static String DriverCode = null;
	static String Fname = null;
	static String Lname = null;
	public static String newAddress = null;
	
	public static void leaseWaveDriverAssignment(WebDriver driver,boolean endRun) throws Exception{
		RC_Global.createNode(driver, "Assigning Driver in LeaseWave");
		try {
			
			RC_Global.clickUsingXpath(driver,"//a[contains(text(),'Fleet Management')]","Fleet Management",endRun, false);
			RC_Global.waitElementVisible(driver, 50, "//span[text()='Fleet Management Menu']", "Fleet Management Menu",endRun, false);
		    String home =  driver.findElement(By.xpath("//span[text()='Fleet Management Menu']")).getText();
		    if(home.contains("FLEET MANAGEMENT MENU")) {
		    	queryObjects.logStatus(driver, Status.PASS, "Navigation to Fleet Management Menu", "Successfully", null);	
		    }
		    
		    RC_Global.clickUsingXpath(driver,"//td[@accesskey='1' and text()='. Profiles']","Profiles",endRun, false);
		    RC_Global.clickUsingXpath(driver,"//td[@accesskey='D']","Driver",endRun, false);
		    RC_Global.clickUsingXpath(driver,"//tr[contains(@igurl,'AssignDriverToAsset')]/td[@accesskey='A']","AssignDriver to Asset",endRun, false);
			RC_Global.waitElementVisible(driver, 50, "//span[text()='Asset List' and @id='ctl00_PageTitle']", "Asset List",endRun, true);
		    driver.findElement(By.xpath("//td[@lw_friendlyname='Unit Number']//input")).sendKeys(RC_Manage.UnitNumber);
		    RC_Global.clickUsingXpath(driver,"//button[text()='Searc']","Search button",endRun, true);
		    Thread.sleep(4000);
		    driver.findElement(By.xpath("//button[text()='elect']")).click();
		    Thread.sleep(2000);
		    try {
		    	   Thread.sleep(2000);
		           driver.switchTo().alert().accept(); 
		           Thread.sleep(2000);
		           driver.findElement(By.xpath("//img[@alt='Hide Message Window']")).click();
		         }
		    catch(Exception e){}
			RC_Global.waitElementVisible(driver, 80, "//span[text()='Assign Driver to Asset']", "Assign Driver to Asset",endRun, false);
			String DriverName = ""; String DriverName2 = ""; WebElement checkbox = null; WebElement checkbox2 = null;
			/*
			 * try { DriverName =
			 * driver.findElement(By.xpath("//tbody/tr/td[contains(@uv,'"+RC_Manage.
			 * drivername+"')]/nobr")).getText(); checkbox =
			 * driver.findElement(By.xpath("//table/tbody/tr[1][td[contains(@uv,'"+RC_Manage
			 * .drivername+"')]]/td[12]/nobr/input[contains(@type,'checkbox')]")); } catch
			 * (Exception e) {}
			 */
			try {
				DriverName2 = driver.findElement(By.xpath("//tbody/tr/td[contains(@uv,'"+RC_Manage.drivernameUpdated+"')]/nobr")).getText();			    
			} catch (Exception e) {
				queryObjects.logStatus(driver, Status.FAIL, "The new assigned driver", " as "+DriverName2+", is not displayed in the Leasewave - Assign Driver to Asset", null);
			}
			try {
			checkbox2 = driver.findElement(By.xpath("//table/tbody/tr[1][td[contains(@uv,'"+RC_Manage.drivernameUpdated+"')]]/td[12]/nobr/input[contains(@type,'checkbox')]"));
			} catch (Exception e) {
				queryObjects.logStatus(driver, Status.FAIL, "The new assigned driver", " as "+DriverName2+", and IS Primary checkbox is not selected for the driver", null);
			}
			/*
			 * if(checkbox!=null) { if(checkbox.isSelected()) {
			 * queryObjects.logStatus(driver, Status.PASS, "The new assigned driver",
			 * " as "+DriverName+", and IS Primary is selected "+checkbox+" ", null); } else
			 * { queryObjects.logStatus(driver, Status.PASS, "The new assigned driver",
			 * " as "+DriverName+", and IS Primary is not selected "+checkbox+" ", null); }
			 * }
			 */
		    if(checkbox2!=null) {
		    	if(checkbox2.isSelected()) {
		    		queryObjects.logStatus(driver, Status.PASS, "The new assigned driver", " as "+DriverName2+", and IS Primary is selected "+checkbox2+" ", null);
		    	} else {
		    		queryObjects.logStatus(driver, Status.FAIL, "The new assigned driver", " as "+DriverName2+", and IS Primary is not selected "+checkbox2+" ", null);
		    	}
		    }
		}

		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Fleet Management Failed", e.getLocalizedMessage(), e);	
			if(endRun)
				RC_Global.endTestRun(driver);  
			}
		}

	public static void leasewaveDriverDataChangeValidation(WebDriver driver, String VehicleAddr, boolean endRun)throws Exception{
		RC_Global.createNode(driver, "Driver data Change validation in LeaseWave");
		String Fleet_Management="";
		try {
			
			RC_Global.clickUsingXpath(driver,"//a[contains(text(),'Portfolio Management')]","Portfolio Management",endRun, false);
			RC_Global.waitElementVisible(driver, 50, "//a[contains(text(),'Portfolio Management')]", "Portfolio Management",endRun, false);
		    String home =  driver.findElement(By.xpath("//a[contains(text(),'Portfolio Management')]")).getText();
		    if(home.contains("Portfolio Management")) {
		    	queryObjects.logStatus(driver, Status.PASS, "Navigation to Portfolio Management Menu", "Successfully", null);	
		    }
		    RC_Global.clickUsingXpath(driver,"//td[@accesskey='3' and text()='.Asset']","Asset option",endRun, false);
		    RC_Global.clickUsingXpath(driver,"//tr[contains(@igurl,'InventoryProfile/AssetList')]/td[@accesskey='P']","Inventory Profile option",endRun, false);
			RC_Global.waitElementVisible(driver, 50, "//span[text()='Asset List' and @id='ctl00_PageTitle']", "Asset List",endRun, true);
		    
		    driver.findElement(By.xpath("//td//input[contains(@name,'UnitNumber')]")).sendKeys(RC_Manage.UnitNumber);
		    RC_Global.clickUsingXpath(driver,"//button[text()='Searc']","Search button",endRun, true);
		    Thread.sleep(2000);
		    //check for drivername change
		    String LWdriverNm = driver.findElement(By.xpath("//td[10]//nobr")).getText();
		    String [] name =LWdriverNm.split("/");
		    RC_Manage.Firstname= name[1];
		    RC_Manage.Lastname= name[0];
		    String LWDriverFrstname = name[1].concat(" ");
		    String LWDriverFullname = LWDriverFrstname.concat(name[0]);
		    
		    if(RC_Manage.drivernameUpdated.contains(LWDriverFullname)) {
		    	queryObjects.logStatus(driver, Status.PASS, "Driver Data change is updated successfully", "Expected name is "+RC_Manage.drivernameUpdated+". Actual name is "+LWDriverFullname, null);	
		    }
		    else {
		    	queryObjects.logStatus(driver, Status.FAIL, "Driver Data change is not reflected in Leasewave", "Expected name is "+RC_Manage.drivernameUpdated+". Actual name is "+LWDriverFullname, null);	
		    }
		    JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].scrollIntoView(true)",driver.findElement(By.xpath("//h2/span[text()='Asset List']")));
		
			RC_Global.clickUsingXpath(driver,"//button[text()='dit']","Edit button",endRun, true);
			RC_Global.waitElementVisible(driver, 50, "//span[text()='Asset Profile Home']", "Asset Profile Home",endRun, true);
		   	String Asset_status =driver.findElement(By.xpath("//input[contains(@name,'Status')]")).getAttribute("value");
		   
		   	RC_Global.clickUsingXpath(driver,"//a[text()='Location History']","Location History",endRun, true);
			RC_Global.waitElementVisible(driver, 50, "//span[text()='Location History']", "Location History",endRun, false);

		   	String address =  driver.findElement(By.xpath("//tbody/tr[1]/td[8][contains(@id,'grdLocationHistory')]/nobr")).getText();
		   	if (VehicleAddr.equalsIgnoreCase("yes") ) {
		   		if(address.equalsIgnoreCase(RC_Manage.VehicleAddress))			    
					   queryObjects.logStatus(driver, Status.PASS, "The most recent address is the new Vehicle Address", "Expected is "+RC_Manage.VehicleAddress+". Actual is "+address, null);
				   else
					   queryObjects.logStatus(driver, Status.FAIL, "The most recent address is not matches with new Vehicle Address", "Expected is "+RC_Manage.VehicleAddress+". Actual is "+address, null);
			} else {
				if(address.equalsIgnoreCase(RC_Manage.DriverAddress))			    
					   queryObjects.logStatus(driver, Status.PASS, "The most recent address is the new Employee Address", "Expected is "+RC_Manage.DriverAddress+". Actual is "+address, null);
				   else
					   queryObjects.logStatus(driver, Status.FAIL, "The most recent address is not matches with new Employee Address", "Expected is "+RC_Manage.DriverAddress+". Actual is "+address, null);
				}
		   	RC_Global.clickUsingXpath(driver,"(//button[@accesskey='C' and text()='lose'])[2]","Close button",endRun, false);
		   	RC_Global.clickUsingXpath(driver,"(//button[@accesskey='C' and text()='lose'])[1]","Close button",endRun, false);
			RC_Global.waitElementVisible(driver, 50, "//span[text()='Asset List' and @id='ctl00_PageTitle']", "Asset List",endRun, false);

		    }
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Portfolio Management Failed", e.getLocalizedMessage(), e);	
			if(endRun)
				RC_Global.endTestRun(driver);  
		}
	}
	
	public static void leasewaveVehicleAddressValidation(WebDriver driver,boolean endRun)throws Exception{
		RC_Global.createNode(driver, "Driver data Change validation in LeaseWave");
		String Fleet_Management="";
		try {
			
			RC_Global.clickUsingXpath(driver,"//a[contains(text(),'Portfolio Management')]","Portfolio Management",endRun, false);
			RC_Global.waitElementVisible(driver, 50, "//a[contains(text(),'Portfolio Management')]", "Portfolio Management",endRun, false);
		    String home =  driver.findElement(By.xpath("//a[contains(text(),'Portfolio Management')]")).getText();
		    if(home.contains("Portfolio Management")) {
		    	queryObjects.logStatus(driver, Status.PASS, "Navigation to Portfolio Management Menu", "Successfully", null);	
		    }
		    RC_Global.clickUsingXpath(driver,"//td[@accesskey='3' and text()='.Asset']","Asset option",endRun, false);
		    RC_Global.clickUsingXpath(driver,"//tr[contains(@igurl,'InventoryProfile/AssetList')]/td[@accesskey='P']","Inventory Profile option",endRun, false);
			RC_Global.waitElementVisible(driver, 50, "//span[text()='Asset List' and @id='ctl00_PageTitle']", "Asset List",endRun, true);
		    
		    driver.findElement(By.xpath("//td//input[contains(@name,'UnitNumber')]")).sendKeys(RC_Manage.UnitNumber);
		    RC_Global.clickUsingXpath(driver,"//button[text()='Searc']","Search button",endRun, true);
		    Thread.sleep(2000);
		    //check for drivername change
		    String LWdriverNm = driver.findElement(By.xpath("//td[10]//nobr")).getText();
		    String [] name =LWdriverNm.split("/");
		    RC_Manage.Firstname= name[1];
		    RC_Manage.Lastname= name[0];
		    String LWDriverFrstname = name[1].concat(" ");
		    String LWDriverFullname = LWDriverFrstname.concat(name[0]);
		    
		    if(RC_Manage.drivernameUpdated.toUpperCase().contains(LWDriverFullname.toUpperCase())) {
		    	queryObjects.logStatus(driver, Status.PASS, "Driver Data change is done", "Successfully", null);	
		    }
		    else {
		    	queryObjects.logStatus(driver, Status.FAIL, "Driver Data change is not","reflected in Leasewave", null);	
		    }
		    JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].scrollIntoView(true)",driver.findElement(By.xpath("//h2/span[text()='Asset List']")));
		
			RC_Global.clickUsingXpath(driver,"//button[text()='dit']","Edit button",endRun, true);
			RC_Global.waitElementVisible(driver, 50, "//span[text()='Asset Profile Home']", "Asset Profile Home",endRun, false);
		   	String Asset_status =driver.findElement(By.xpath("//input[contains(@name,'Status')]")).getAttribute("value");
		   
		   	RC_Global.clickUsingXpath(driver,"//a[text()='Asset Profile']","Asset Profile",endRun, true);
			RC_Global.waitElementVisible(driver, 50, "//span[text()='Asset Profile']", "Asset Profile",endRun, false);
			
			RC_Global.waitElementVisible(driver, 50, "//span[text()='Location Detail']", "Location Detail", endRun, false);
		   	String address =  driver.findElement(By.xpath("//table[contains(@id,'grdLocation')]/tbody/tr/td[5]/nobr")).getText();
		   if(address.toUpperCase().equals(RC_Manage.VehicleAddress.toUpperCase()))			    
			   queryObjects.logStatus(driver, Status.PASS, "The most recent address is the updated Address", address, null);
		   else
			   queryObjects.logStatus(driver, Status.FAIL, "The most recent address is not matches with updated Address", address, null);
		
		   	RC_Global.clickUsingXpath(driver,"(//button[@accesskey='C' and text()='lose'])[2]","Close button",endRun, false);
		   	RC_Global.clickUsingXpath(driver,"(//button[@accesskey='C' and text()='lose'])[1]","Close button",endRun, false);
			RC_Global.waitElementVisible(driver, 50, "//span[text()='Asset List' and @id='ctl00_PageTitle']", "Asset List",endRun, false);

		    }
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Portfolio Management Failed", e.getLocalizedMessage(), e);	
			if(endRun)
				RC_Global.endTestRun(driver);  
		}
	}
	
	public static void navigateLeaseList_Leasewave(WebDriver driver, boolean endRun) throws Exception {
		RC_Global.createNode(driver, "Driver Data Changes upload validations in LeaseWave - Lease Profile");
        try {
        	RC_Global.createNode(driver, "Driver details validation in LeaseWave - Lease Option");
            RC_Global.clickUsingXpath(driver,"//a[contains(text(),'Portfolio Management')]","Portfolio Management",endRun, false);
            RC_Global.waitElementVisible(driver, 50, "//a[contains(text(),'Portfolio Management')]", "Portfolio Management",endRun, false);
            RC_Global.clickUsingXpath(driver,"//td[@accesskey='2' and text()='.Lease']","Lease option",endRun, false);
            RC_Global.clickUsingXpath(driver,"(//td[@accesskey='O'])[2]","Open",endRun, false);
            RC_Global.waitElementVisible(driver, 50, "//span/span[text()='Lease List']", "Lease List",endRun, false);                                
        } catch(Exception e) {
    			queryObjects.logStatus(driver, Status.FAIL, "Navigate to LeaseList page Failed", e.getLocalizedMessage(), e);	
    			RC_Global.endTestRun(driver);
        }
	}
	
	public static void unitNoSearchLeaseProfile_Leasewave(WebDriver driver, String unitNum, String selStatus, boolean endRun) throws Exception {
		
		try {
			driver.findElement(By.xpath("//td//input[contains(@name,'UnitNumber')]")).clear();
            driver.findElement(By.xpath("//td//input[contains(@name,'UnitNumber')]")).sendKeys(unitNum);
            //RC_Manage.selectFromDropdown(driver, selStatus, driver.findElement(By.xpath("//select[contains(@id,'StatusName')]")));
            driver.findElement(By.xpath("(//td//input[contains(@name,'ContractNumber')])[2]")).sendKeys(Keys.TAB);
            RC_Global.clickUsingXpath(driver,"//button[text()='Searc']","Search button",endRun, true);
            RC_Global.waitElementVisible(driver, 50, "//td[contains(@id,'ListxgrdList')]//tbody/tr", "Lease List",endRun, false);
            RC_Global.clickUsingXpath(driver,"//button[text()='elect']","Select button",endRun, true);
            Thread.sleep(5000);
            if (driver.findElements(By.xpath("//span[text()='Inventory In Lease']")).size()>0) {
            	driver.findElement(By.xpath("//button[text()='lose']")).click();
            	Thread.sleep(1000);
			}
            RC_Global.waitElementVisible(driver, 30, "//span[text()='Lease Entry Home']", "Lease Entry Home",false, false);
            RC_Global.clickUsingXpath(driver,"//a[text()='Lease Profile']","Lease Profile tab",endRun, true);
        } catch(Exception e) {
    			queryObjects.logStatus(driver, Status.FAIL, "Navigate to Asset Client page Failed", e.getLocalizedMessage(), e);	
    			RC_Global.endTestRun(driver);
        }
	}
	
	public static void validateDriverDetails_Leasewave(WebDriver driver, String colName, String expectedVal) throws Exception {

        try {
            
            if (colName.equalsIgnoreCase("cvn") || colName.equalsIgnoreCase("customer vehicle number")) {
                if (driver.findElement(By.xpath("//span[text()='CVN']/../following-sibling::span/input")).getAttribute("value").equals(expectedVal)) {
                    queryObjects.logStatus(driver, Status.PASS, "Customer Vehicle Number Validation in LeaseWave is ", "Successful", null);
                } else {
                    queryObjects.logStatus(driver, Status.FAIL, "Customer Vehicle Number Validation in LeaseWave ", "Failed", null);
                }
            } else if ("year;make;model".contains(colName.toLowerCase())) {
                if (driver.findElement(By.xpath("//span[text()='Year/Make/Model :']/../following-sibling::span/input")).getAttribute("value").toLowerCase().contains(expectedVal.toLowerCase())) {
                    queryObjects.logStatus(driver, Status.PASS, colName+" Validation in LeaseWave is", "Successful", null);
                } else {
                    queryObjects.logStatus(driver, Status.FAIL, colName+" Validation in LeaseWave is", "Failed", null);
                }
              
            } else if (colName.equalsIgnoreCase("vin")) {
                if (driver.findElement(By.xpath("//span[text()='VIN :']/../following-sibling::span/input")).getAttribute("value").trim().equalsIgnoreCase(expectedVal)) {
                    queryObjects.logStatus(driver, Status.PASS, "Vehicle Identification Number Validation in LeaseWave is", "Successful", null);
                }  else {
                    queryObjects.logStatus(driver, Status.FAIL, "Vehicle Identification Number Validation in LeaseWave is", "Failed", null);
                }              
            }
        }
        catch(Exception e) {
            queryObjects.logStatus(driver, Status.FAIL, "Driver Data Changes upload validations in LeaseWave - Lease Profile failed", e.getLocalizedMessage(), e);
        }
    }
	
	public static void navigateAssetList_Leasewave(WebDriver driver, boolean endRun) throws Exception {
		RC_Global.createNode(driver, "Client Data Changes upload validations in LeaseWave - Asset Profile");
        try {
        	
			RC_Global.clickUsingXpath(driver,"//a[contains(text(),'Portfolio Management')]","Portfolio Management",endRun, false);
			RC_Global.waitElementVisible(driver, 50, "//a[contains(text(),'Portfolio Management')]", "Portfolio Management",endRun, false);
			RC_Global.clickUsingXpath(driver,"//td[@accesskey='3' and text()='.Asset']","Asset option",endRun, false);
			RC_Global.clickUsingXpath(driver,"(//td[@accesskey='P'])[4]","Profile",endRun, false);
			RC_Global.waitElementVisible(driver, 50, "//span/span[text()='Asset List']", "Asset List",endRun, false);
            
        } catch(Exception e) {
    			queryObjects.logStatus(driver, Status.FAIL, "Navigate to AssetList page Failed", e.getLocalizedMessage(), e);	
    			RC_Global.endTestRun(driver);
        }
	}
	
	public static void unitNoSearchAssetList_Leasewave(WebDriver driver, String unitNum, boolean endRun) throws Exception {
		try {
        	driver.findElement(By.xpath("//td//input[contains(@name,'UnitNumber')]")).clear();
			driver.findElement(By.xpath("//td//input[contains(@name,'UnitNumber')]")).sendKeys(unitNum);
		    RC_Global.clickUsingXpath(driver,"//button[text()='Searc']","Search button",endRun, true);
		    RC_Global.waitElementVisible(driver, 50, "//td[contains(@id,'ListxgrdList')]//tbody/tr", "Asset List",endRun, false);
		    RC_Global.clickUsingXpath(driver,"//button[text()='dit']","Edit button",endRun, true);
		    RC_Global.waitElementVisible(driver, 50, "//span[text()='Asset Profile Home']", "Asset Profile Home",endRun, false);
		    RC_Global.clickUsingXpath(driver,"//a[text()='Client Data Fields']","Client Data Fields",endRun, true);
		    RC_Global.waitElementVisible(driver, 50, "//span[text()='Asset Client Data Fields']", "Asset Client Data Fields",endRun, false);
        } catch(Exception e) {
    			queryObjects.logStatus(driver, Status.FAIL, "Navigate to Asset Client page Failed", e.getLocalizedMessage(), e);	
    			RC_Global.endTestRun(driver);
        }
	}
	
	public static void validateClientDatas_Leasewave(WebDriver driver, String colName, String expectedVal, boolean endRun) throws Exception {
		try {
			
			String staticPath = "//span[text()='clientdatafield']/../following-sibling::span/input";
			staticPath =staticPath.replace("clientdatafield", colName);//Data Field1
			
			if (driver.findElement(By.xpath(staticPath)).getAttribute("value").trim().equalsIgnoreCase(expectedVal)) {
				queryObjects.logStatus(driver, Status.PASS, "Client Data fields Validation in LeaseWave for the "+colName+" column is ", "Successful", null);
            }  else {
                queryObjects.logStatus(driver, Status.FAIL, "Client Data fields Validation in LeaseWave for the "+colName+" column is ", "Failed", null);
            }
		} catch(Exception e) {
            queryObjects.logStatus(driver, Status.FAIL, "Client Data Changes upload validations in LeaseWave - Asset Profile failed", e.getLocalizedMessage(), e);
            if(endRun)
                RC_Global.endTestRun(driver);          
        }
	}
	
	public static String[] addDriverInLeaseWave(WebDriver driver, String CustomerNumber, boolean endRun) throws Exception {		
		RC_Global.createNode(driver, "Create driver in leasewave");
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;  
        try {
        	List<String> addressListNew = null;
        	 driver.findElement(By.xpath("//a[contains(text(),'Fleet Management')]")).click();
  		   	 RC_Global.waitElementVisible(driver, 50, "//span[text()='Fleet Management Menu']", "Fleet Management Menu",endRun, false);
             String home =  driver.findElement(By.xpath("//span[text()='Fleet Management Menu']")).getText();
             if(home.contains("FLEET MANAGEMENT MENU")) {
                 BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Navigation to Fleet Management Menu", "Successfully", null);   
             }
             RC_Global.clickUsingXpath(driver,"//td[@accesskey='1' and text()='. Profiles']","Profiles",endRun, false);
             RC_Global.clickUsingXpath(driver,"//td[@accesskey='D']","Driver",endRun, false);
             RC_Global.clickUsingXpath(driver,"//tr[contains(@igurl,'DriverProfile')]/td[@accesskey='P']","Driver Profile",true, false);
     		RC_Global.waitElementVisible(driver, 50, "//span[text()='Driver Profile List' and @id='ctl00_PageTitle']", "Asset List",true, true);
     		 RC_Global.clickUsingXpath(driver,"//button[text()='dd']","Add button",endRun, true);
             RC_Global.waitElementVisible(driver, 50, "//span[text()='Customer List' and @id='ctl00_PageTitle']", "Customer List",endRun, false);
             driver.findElement(By.xpath("//td[@lw_friendlyname='Account Number']//input")).sendKeys(CustomerNumber);
     	     RC_Global.clickUsingXpath(driver,"//button[text()='Searc']","Search button",endRun, true);
     	     RC_Global.clickUsingXpath(driver,"//button[text()='elect']","Select button",endRun, true);
             RC_Global.waitElementVisible(driver, 50, "//span[text()='Driver Profile' and @id='ctl00_PageTitle']", "Driver Profile Page",endRun, false);
             DriverCode = driver.findElement(By.xpath("//input[contains(@name,'DriverCode')]")).getAttribute("value");
     	     RC_Global.clickUsingXpath(driver,"//select[contains(@name,'DriverType')]","Driver Type dropdown",endRun, false);
     	     driver.findElement(By.xpath("//select[contains(@name,'DriverType')]/option[text()='Driver']")).click();
     	     Thread.sleep(1000);
     	     RC_Global.clickUsingXpath(driver,"//button[text()='Add Cont']","Add Contacts",endRun, true);
     	     Fname ="David"+RandomStringUtils.randomAlphabetic(3);
     	     Lname ="Crespo"+RandomStringUtils.randomAlphabetic(2);
     	    driver.findElement(By.xpath("//input[contains(@name,'FirstName')]")).sendKeys(Fname);
     	    Thread.sleep(1000);
     	    driver.findElement(By.xpath("(//input[contains(@name,'ContactPersonAssignment')])[7]")).sendKeys(Lname);
     	    Thread.sleep(1000);
     	    driver.findElement(By.xpath("(//nobr[text()='Driver']/preceding::input[@type='checkbox'])[14]")).click();
     	    Thread.sleep(1000);
    	     RC_Global.clickUsingXpath(driver,"//button[text()='dd Address']","Add Address",endRun, true);
    	     WebElement AddressId =   driver.findElement(By.xpath("(//input[contains(@name,'ContactAddressUC1')])[5]"));
        	  Thread.sleep(1000);
        	   WebElement Address1 =   driver.findElement(By.xpath("(//textarea[contains(@name,'ContactAddressUC1')])[1]"));
        	   addressListNew = (List<String>) RC_Manage.RandomSelection(driver);
        	  Thread.sleep(1000);
     	     driver.findElement(By.xpath("(//input[contains(@name,'City')])[1]")).sendKeys(addressListNew.get(1));
     	    Thread.sleep(1000);
     	     RC_Global.clickUsingXpath(driver,"//select[contains(@name,'cboStateLongName')]","Driver Type dropdown",endRun, false);
    	     Thread.sleep(2000);
    	     driver.findElement(By.xpath("//select[contains(@name,'cboStateLongName')]//option[text()='"+addressListNew.get(2)+"']")).click();
    	     
    	     RC_Global.clickUsingXpath(driver,"//select[contains(@name,'cboCountryName')]","Driver Type dropdown",endRun, false);
     	     Thread.sleep(2000);
     	     driver.findElement(By.xpath("//select[contains(@name,'cboCountryName')]//option[text()='"+addressListNew.get(5)+"']")).click();
     	     WebElement ZipCode =    driver.findElement(By.xpath("//input[contains(@editid,'ZIP')]"));
     	     jsExecutor.executeScript("arguments[0].value='"+addressListNew.get(3)+"'", ZipCode);
     	    driver.findElement(By.xpath("(//input[contains(@name,'County')])[1]")).sendKeys(addressListNew.get(4));
     	     Thread.sleep(4000);
     	     try {
     	    	Address1.click();
     	    	AddressId.click();
     	    	ZipCode.click();
     	    	driver.findElement(By.xpath("(//input[contains(@name,'City')])[1]")).click();
			} catch (Exception e) {}
     	    try {
     	    	Address1.clear();
     	    	AddressId.clear();
     	    	ZipCode.clear();
     	    	driver.findElement(By.xpath("(//input[contains(@name,'City')])[1]")).clear();
			} catch (Exception e) {}
     	    Thread.sleep(2000);
     	    String addrVal = "1461 Bluejay "+RandomStringUtils.randomAlphabetic(5);
     	    newAddress = addrVal;
     	    jsExecutor.executeScript("arguments[0].value='"+addrVal+"'", AddressId);
     	    jsExecutor.executeScript("arguments[0].value='"+addressListNew.get(0)+"'", Address1);
     	    if(driver.findElements(By.xpath("//button[text()='ave' and @disabled]")).size()>0) {
     	    	jsExecutor.executeScript("arguments[0].value='"+addrVal+"'", AddressId);
         	    jsExecutor.executeScript("arguments[0].value='"+addressListNew.get(0)+"'", Address1);
         	   jsExecutor.executeScript("arguments[0].value='"+addressListNew.get(1)+"'", driver.findElement(By.xpath("(//input[contains(@name,'City')])[1]")));
         	   jsExecutor.executeScript("arguments[0].value=''", ZipCode);
         	  jsExecutor.executeScript("arguments[0].value='"+addressListNew.get(3)+"'", ZipCode);
         	 AddressId.clear();
         	AddressId.sendKeys(addrVal);
     	    }
     	   Thread.sleep(1000);
     	   try {
    	    	ZipCode.click();
    	    } catch (Exception e) {}
     	  Thread.sleep(3000);
    	    RC_Global.clickButton(driver, "e Contacts", true, false);
    	    RC_Global.waitElementVisible(driver, 50, "//button[text()='ave']", "Save",true, false);
     	    RC_Global.clickButton(driver, "ave", false, true);
     	    Thread.sleep(2000);
    		queryObjects.logStatus(driver, Status.PASS, "Driver is created Successfully","in LeaseWave",null);																																																				   
        	}        
        catch(TimeoutException te) {
    		queryObjects.logStatus(driver, Status.FAIL, "Navigate to the required screen failed -> Unable to load the current/previous screen", te.getLocalizedMessage(), te);																																  
    		 if(endRun)
    		RC_Global.endTestRun(driver);   
    	}																																							 
        catch(Exception e) {        
        	BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Failed to create Driver in leasewave", e.getLocalizedMessage(), e);   
        	 if(endRun)
    				RC_Global.endTestRun(driver);
        }
        String [] DriverDetails = {DriverCode,Fname,Lname};
        return DriverDetails;
									
        }
	
	public static void employeeUploadUpdate(WebDriver driver, String UnitNumber, String upAddress, boolean endRun) throws Exception {		
		RC_Global.createNode(driver, "Validate Vehicle address in LW");
		try {
        	 driver.findElement(By.xpath("//a[contains(text(),'Fleet Management')]")).click();
  		   	 RC_Global.waitElementVisible(driver, 50, "//span[text()='Fleet Management Menu']", "Fleet Management Menu",endRun, false);
             String home =  driver.findElement(By.xpath("//span[text()='Fleet Management Menu']")).getText();
             if(home.contains("FLEET MANAGEMENT MENU")) {
                 BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Navigation to Fleet Management Menu", "Successfully", null);   
             }
             RC_Global.clickUsingXpath(driver,"//td[@accesskey='1' and text()='. Profiles']","Profiles",endRun, false);
             RC_Global.clickUsingXpath(driver,"//td[@accesskey='D']","Driver",endRun, false);
             RC_Global.clickUsingXpath(driver,"//tr[contains(@igurl,'DriverProfile')]/td[@accesskey='P']","Driver Profile",true, false);
             WebElement unitNum = driver.findElement(By.xpath("//td//input[contains(@name,'UnitNumber')]"));
             RC_Global.enterInput(driver, UnitNumber, unitNum, true, true);
             RC_Global.clickUsingXpath(driver,"//button[text()='Searc']","Search button",endRun, true);
 		    Thread.sleep(4000);
 		    driver.findElement(By.xpath("//button[text()='dit']")).click();
 		    Thread.sleep(2000);
 		   	RC_Global.waitElementVisible(driver, 50, "//span[text()='Asset Profile Home']", "Asset Profile Home",endRun, false);
            RC_Global.clickUsingXpath(driver,"//a[text()='Asset Profile']","Asset Profile",true, false);
            String effDate = driver.findElement(By.xpath("//td//input[contains(@name,'LocationEffectiveFromDate')]")).getAttribute("value");
            String address = driver.findElement(By.xpath("//td[contains(@id,'Location_rc_0_4')]//nobr")).getText();
            String getTime = RC_Global.getDateTime(driver,"MM/dd/yyyy",0,false);
            if(effDate.contains(getTime) && address.contains(upAddress))
        		queryObjects.logStatus(driver, Status.PASS, "Effective Date and Address","Effective Date and Address are updated successfully",null);																																																				   
            
            else {
         		queryObjects.logStatus(driver, Status.FAIL, "Effective Date and Address", "Effective Date and Address changes are failed to update in Leasewave", null);																																  
         		RC_Global.endTestRun(driver);   
            }
            RC_Global.clickUsingXpath(driver,"(//button[text()='lose'])[2]","Close button",endRun, true);
 		   	Thread.sleep(3000);
            RC_Global.clickUsingXpath(driver,"//a[text()='Location History']","Location History",endRun, true);
            
            String locHisEffDate = driver.findElement(By.xpath("//td//input[contains(@name,'LocationEffectiveFromDate')]")).getAttribute("value");
            String locHisaddress = driver.findElement(By.xpath("//td[contains(@id,'Location_rc_0_4')]//nobr")).getText();
           
            if(locHisEffDate.contains(getTime) && locHisaddress.contains(upAddress))
        		queryObjects.logStatus(driver, Status.PASS, "Effective Date and Address","Effective Date and Address are updated successfully in Location History page",null);																																																				   
            
            else {
         		queryObjects.logStatus(driver, Status.FAIL, "Effective Date and Address", "Effective Date and Address changes are failed  in Location History page", null);																																  
         		RC_Global.endTestRun(driver);   
            }

        
        } catch(TimeoutException te) {
         		queryObjects.logStatus(driver, Status.FAIL, "Navigate to the required screen failed -> Unable to load the current/previous screen", te.getLocalizedMessage(), te);																																  
         		 if(endRun)
         		RC_Global.endTestRun(driver);   
         	}	
        }
	
	
}
