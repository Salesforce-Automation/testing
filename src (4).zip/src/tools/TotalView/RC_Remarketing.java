package tools.TotalView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import Remarketing.TerminateVehicle.TID_4_1_1_17;

public class RC_Remarketing {
	
	static String OdometerReading = "";
	static String[] TerminationOption = {null,null,null};				   
	public static String unitnumber = "";
	static BFrameworkQueryObjects queryObjects = new BFrameworkQueryObjects();
	
	public static void validateAgreementType(WebDriver driver, String AgreementType) throws Exception {
		try {
		String Agreementtype = driver.findElement(By.xpath("//label[text()='Agreement Type']/following::span[text()='"+AgreementType+"']")).getText();
		if(Agreementtype.equalsIgnoreCase(AgreementType)) 
			queryObjects.logStatus(driver, Status.PASS, "Agreement Type Displayed", "Correctly",null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Agreement Type Displayed", "is not correct",null);
		}	catch(Exception ce) {
			queryObjects.logStatus(driver, Status.FAIL, "Agreement Type Displayed", ce.getLocalizedMessage(), ce);
			RC_Global.endTestRun(driver);
		}		
	}
	public static void selectRowWithAgreementTypeFromGrid(WebDriver driver,String AgreementType ,boolean endRun)throws Exception{
        RC_Global.createNode(driver, "selecting a row with agreement type " +AgreementType);
        boolean nextButton = false;
        String lastPg = ""; int pgNos = 1;
        WebDriverWait wait = new WebDriverWait(driver,60);
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//tbody//tr)[1]")));
            List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("//table//tbody//tr")); 
			Thread.sleep(2000);
			driver.findElement(By.xpath("//a[text()='Last']")).click();
			Thread.sleep(1000);
			lastPg = driver.findElement(By.xpath("//li[@class='pagination-page ng-scope active']/a")).getText().trim();
			pgNos = Integer.parseInt(lastPg)-1;
			driver.findElement(By.xpath("//a[text()='First']")).click();
			for (int p = 1; p <= pgNos; p++) {
				int rowcnt=Getgridrowcnt.size();
				boolean firstpage=false;
				Thread.sleep(2000);
				try {
		            for(int i=1; i<=rowcnt;i++) {
		                WebElement sub= driver.findElement(By.xpath("//tr["+i+"]//td[10]"));
		                WebElement viewsub = driver.findElement(By.xpath("//tr["+i+"]//td[6]"));
		                WebElement CVNrow = driver.findElement(By.xpath("//tr["+i+"]//td[3]"));
		                String CVN = CVNrow.getText();
		                WebElement Driverrow = driver.findElement(By.xpath("//tr["+i+"]//td[9]"));
		                String drivername = Driverrow.getText();
		                if(!(drivername.contains("Pool")||drivername.contains("Default") || drivername.contains("Unassigned"))) {
		                if(sub.getText().equalsIgnoreCase(AgreementType)) {
		                    Thread.sleep(2000);
		                    driver.findElement(By.xpath("//tbody//tr["+i+"]//td[1]")).click();
		                    firstpage = true;
		                    break;
		                }
		                if(viewsub.getText().equalsIgnoreCase(AgreementType)) {
		                    Thread.sleep(2000);
		                    driver.findElement(By.xpath("//tbody//tr["+i+"]//td[7]")).click();
		                    firstpage = true;
		                    break;
		                } 
		             }
		            }
		            if(firstpage) {
						queryObjects.logStatus(driver, Status.PASS, "Searching Required grid record from Webtable", "Successful", null);
						break;
					} else {
						driver.findElement(By.xpath("//li/a[text()='Next']")).click();
					}
				} catch (Exception e) {
					queryObjects.logStatus(driver, Status.FAIL, "Searching "+AgreementType+" grid record from Webtable failed", e.getLocalizedMessage(), e);
				}
				
			} 
		
           }
        catch(TimeoutException te) {
            queryObjects.logStatus(driver, Status.FAIL, "Failed to Search "+AgreementType+" grid record -> Unable to Search Required grid record screen", te.getLocalizedMessage(), te);
            if(endRun)
                RC_Global.endTestRun(driver);
            }
        catch(Exception e) {
            queryObjects.logStatus(driver, Status.FAIL, "Searching "+AgreementType+" grid record from Webtable", e.getLocalizedMessage(), e);
                  if(endRun)
                           RC_Global.endTestRun(driver);
            }
    }
	
	public static String[] vehicleProgramTermination(WebDriver driver ,String Driverstatus, String Fuel, String Personaluse, boolean endRun)throws Exception{
        RC_Global.createNode(driver, "Vehicle Program Termination selection ");
        try {
            List<WebElement> programDriver = driver.findElements(By.xpath("//label[contains(@ng-model,'IsDriverStillActiveIndicator') and @disabled='disabled']"));
            List<WebElement> programFuel = driver.findElements(By.xpath("//label[contains(@ng-model,'DriverInFuelIndicator') and @disabled='disabled']"));
            List<WebElement> programPersonaluse = driver.findElements(By.xpath("//label[contains(@ng-model,'DriverInPersonalUseIndicator') and @disabled='disabled']"));
            Thread.sleep(2000);
            if(!(programDriver.size()>0))
            {
                    if(!(programDriver.size()>0))
                    {
                            if(Driverstatus.equalsIgnoreCase("Yes")) {
                            driver.findElement(By.xpath("//label[contains(@name,'EmployeeActiveWithCompanyIndicatorYes')]")).click();
                            TerminationOption[0] = "Yes";
                            }
                            else if(Driverstatus.equalsIgnoreCase("No")) {
                                driver.findElement(By.xpath("//label[contains(@name,'EmployeeActiveWithCompanyIndicatorNo')]")).click();
                            TerminationOption[0] = "No";
                           }
                    }
                    else
                    	TerminationOption[0] = "N/A";
                    Thread.sleep(1000);
			
                    if(!(programFuel.size()>0)) {
                             if(Fuel.equalsIgnoreCase("Yes")) {
                                driver.findElement(By.xpath("//label[contains(@name,'FuelIndicatorYes')]")).click();
                                TerminationOption[1] = "Yes";
                                }
                            else if(Fuel.equalsIgnoreCase("No")) {
                                    driver.findElement(By.xpath("//label[contains(@name,'FuelIndicatorNo')]")).click();
                                    TerminationOption[1] = "No";
                                    }
                    }
                    else
                    	TerminationOption[1] = "N/A";
                    Thread.sleep(1000);
                    if(!(programPersonaluse.size()>0)) {
                            if(Personaluse.equalsIgnoreCase("Yes")) {
                                driver.findElement(By.xpath("//label[contains(@name,'PersonalUseIndicatorYes')]")).click();
                                TerminationOption[2] = "Yes";
                                }
                            else if(Personaluse.equalsIgnoreCase("No")) {
                                driver.findElement(By.xpath("//label[contains(@name,'PersonalUseIndicatorNo')]")).click();
                                TerminationOption[2] = "No";
                                }
                        }
                    else
                    	TerminationOption[2] = "N/A";
   
                    queryObjects.logStatus(driver, Status.PASS, "Vehicle Program Termination selection for fields", "Successful",null );
                }
            else {
            	TerminationOption[0] = "N/A";
            	TerminationOption[1] = "N/A";
            	TerminationOption[2] = "N/A";
            }
        }catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver, Status.FAIL, "Navigate to the required screen failed -> Kindly provide right fields for navigation", nse.getLocalizedMessage(), nse);
			RC_Global.endTestRun(driver);
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "Navigate to the required screen failed -> Unable to load the current/previous screen", te.getLocalizedMessage(), te);
			RC_Global.endTestRun(driver);
		}
        catch(Exception e){
            queryObjects.logStatus(driver, Status.FAIL, "Not found Vehicle Program Termination selection for fields", e.getLocalizedMessage(), e);
            if(endRun)
            RC_Global.endTestRun(driver); }
                
		return TerminationOption;
            }
	
	public static void damageDisclosure(WebDriver driver ,String DrivableIndicator,String DamageIndicator, String StolenIndicator,String FloodDamageIndicator,String BeenSalvagedIndicator,String AirbagAlterationsIndicator,String EnOdometerReading, boolean endRun)throws Exception{
            RC_Global.createNode(driver, "Damage Disclosure selection");
            OdometerReading = EnOdometerReading;
			Thread.sleep(2000);
            try {
                              
		          List<WebElement> vehicleDrivable = driver.findElements(By.xpath("//label[contains(@ng-model,'VehicleDrivableIndicator')]"));
		          List<WebElement> heavyDamage = driver.findElements(By.xpath("//label[contains(@ng-model,'HasHeavyDamageIndicator')]"));
		          List<WebElement> stolenIndicator = driver.findElements(By.xpath("//label[contains(@ng-model,'HasBeenStolenIndicator')]"));
		          List<WebElement> floodDamage = driver.findElements(By.xpath("//label[contains(@ng-model,'HasFloodDamageIndicator')]"));
		          List<WebElement> salvegeIndicator = driver.findElements(By.xpath("//label[contains(@ng-model,'HasBeenSalvagedIndicator')]"));
		          List<WebElement> airbagIndicator = driver.findElements(By.xpath("//label[contains(@ng-model,'HasAirbagAlterationsIndicator')]"));
		          Thread.sleep(2000);
                  WebElement element = driver.findElement(By.xpath("//input[@placeholder='Odometer']"));
                  RC_Global.enterInput(driver, OdometerReading, element, true,false);
                  Thread.sleep(2000);
                  	if((vehicleDrivable.size()>0)){
                        if(DrivableIndicator.equalsIgnoreCase("Yes")) {
                            driver.findElement(By.xpath("//label[contains(@name,'VehicleDrivableIndicatorYes')]")).click();
                        }
                                      
                        else if(DrivableIndicator.equalsIgnoreCase("No")) {
                            driver.findElement(By.xpath("//label[contains(@name,'VehicleDrivableIndicatorNo')]")).click();
                        }
                  	}
                  	if((heavyDamage.size()>0)) {
                         if(DamageIndicator.equalsIgnoreCase("Yes")) {
                                driver.findElement(By.xpath("//label[contains(@name,'HeavyDamageIndicatorYes')]")).click();
                         }
                         else if(DamageIndicator.equalsIgnoreCase("No")) {
                                driver.findElement(By.xpath("//label[contains(@name,'HeavyDamageIndicatorNo')]")).click();
                         }
                  	}
		            if((stolenIndicator.size()>0)) {
		                    if(StolenIndicator.equalsIgnoreCase("Yes")) {
		                        driver.findElement(By.xpath("//label[contains(@name,'BeenStolenIndicatorYes')]")).click();
		                        }
		                    else if(StolenIndicator.equalsIgnoreCase("No")) {
		                        driver.findElement(By.xpath("//label[contains(@name,'BeenStolenIndicatorNo')]")).click();
		                        }
		                }
		            if((floodDamage.size()>0)) {
		                if(FloodDamageIndicator.equalsIgnoreCase("Yes")) {
		                   driver.findElement(By.xpath("//label[contains(@name,'FloodDamageIndicatorYes')]")).click();
		                }
		                else if(FloodDamageIndicator.equalsIgnoreCase("No")) {
		                       driver.findElement(By.xpath("//label[contains(@name,'FloodDamageIndicatorNo')]")).click();
		                }
		            }
		            if((salvegeIndicator.size()>0)) {
		            	if(BeenSalvagedIndicator.equalsIgnoreCase("Yes")) {
		            		driver.findElement(By.xpath("//label[contains(@name,'BeenSalvagedIndicatorYes')]")).click();
		            	}
		            	else if(BeenSalvagedIndicator.equalsIgnoreCase("No")) {
		            		driver.findElement(By.xpath("//label[contains(@name,'BeenSalvagedIndicatorNo')]")).click();
		            	}
		            }
		            if((airbagIndicator.size()>0)) {
		            	if(AirbagAlterationsIndicator.equalsIgnoreCase("Yes")) {
		            		driver.findElement(By.xpath("//label[contains(@name,'AirbagAlterationsIndicatorYes')]")).click();
		            	}
		            	else if(AirbagAlterationsIndicator.equalsIgnoreCase("No")) {
		            		driver.findElement(By.xpath("//label[contains(@name,'AirbagAlterationsIndicatorNo')]")).click();
		            	}
		            }
                               
                      
		            queryObjects.logStatus(driver, Status.PASS, "Damage Disclosure selection", "Successful",null );
            }
            catch(Exception e) {
            	queryObjects.logStatus(driver, Status.FAIL, "Not found Damage Disclosure selection", e.getLocalizedMessage(), e);
            	if(endRun)
            		RC_Global.endTestRun(driver);
            }
	}
 
	public static void enterBuyerInformation(WebDriver driver, String[] buyerInfoLabel, String[] buyerInformation, boolean endRun) throws Exception {
		try {
			WebElement buyerName = RC_Global.accessInputBoxViaLabel(driver, buyerInfoLabel[1], true);
			WebElement contactFirstName = RC_Global.accessInputBoxViaLabel(driver, buyerInfoLabel[2], true);
			WebElement contactLastName = RC_Global.accessInputBoxViaLabel(driver, buyerInfoLabel[3], true);
			WebElement address1 = RC_Global.accessInputBoxViaLabel(driver, buyerInfoLabel[4], true);
			WebElement city = RC_Global.accessInputBoxViaLabel(driver, buyerInfoLabel[5], true);
			WebElement zipCode = RC_Global.accessInputBoxViaLabel(driver, buyerInfoLabel[7], true);
			WebElement phone = RC_Global.accessInputBoxViaLabel(driver, buyerInfoLabel[8], true);
			
			if(!buyerInfoLabel[0].equalsIgnoreCase(""))
				RC_Global.selectDropdownOption(driver, buyerInfoLabel[0], buyerInformation[0], true,false);//Buyer Type
			RC_Global.enterInput(driver,buyerInformation[1],buyerName,  true,false);
			RC_Global.enterInput(driver, buyerInformation[2], contactFirstName, true,false);
			RC_Global.enterInput(driver,buyerInformation[3], contactLastName,  true,false);
			RC_Global.enterInput(driver, buyerInformation[4], address1, true,false);
			RC_Global.enterInput(driver,buyerInformation[5], city,  true,false);
			RC_Global.selectDropdownOption(driver, buyerInfoLabel[6], buyerInformation[6], true,false);
			RC_Global.enterInput(driver,buyerInformation[7], zipCode,  true,false);
			RC_Global.enterInput(driver, buyerInformation[8], phone, true,false);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Not found Damage Disclosure selection", e.getLocalizedMessage(), e);
            if(endRun)
                     RC_Global.endTestRun(driver);
		}
	}
	public static void validateFormLabel(WebDriver driver, String formName, String[] formLabel, boolean endRun) throws Exception{
		
		RC_Global.createNode(driver, formName+" Form label validation");
		try {
			List<String> formLabels = new ArrayList();
			List<WebElement> wFormLabels = driver.findElements(By.xpath("//div[div[div[legend[normalize-space(text())='"+formName+"']]]]/div/div//label[contains(@class,'control-label')]"));
			
			for(WebElement fl:wFormLabels) {
				formLabels.add(fl.getText());
			}
			for(int iterator=0;iterator<formLabel.length;iterator++) {
				if(formLabel[iterator].equalsIgnoreCase(formLabels.get(iterator)))
					queryObjects.logStatus(driver, Status.INFO, "", "Success", null);
				else if(formLabel[iterator].contains(formLabels.get(iterator)))
					queryObjects.logStatus(driver, Status.INFO, "", "Success", null);
				else if(formLabels.get(iterator).contains(formLabel[iterator]))
					queryObjects.logStatus(driver, Status.INFO, "", "Success", null);
			}
		}
		catch(Exception e) {
			
		}
	}
	public static void enterVehiclePickupLocationAndContactInformation(WebDriver driver, String[] contactInfoLabel, String[] contactInfo,boolean endRun) throws Exception {
		try {

			WebElement pickupLocation = RC_Global.accessInputBoxViaLabel(driver, contactInfoLabel[0],true);
			WebElement Address1 = driver.findElement(By.xpath("(//input[@placeholder='Address 1'])[1]"));
			WebElement City = driver.findElement(By.xpath("(//input[@name='city'])[1]"));
			//WebElement state = driver.findElement(By.xpath("(//input[@placeholder='Address 1'])[1]"));
			WebElement zipCode =driver.findElement(By.xpath("(//input[@name='zipCode'])[4]"));
			WebElement firstName = driver.findElement(By.xpath("(//input[@name='firstName'])[1]"));
			WebElement lastName =driver.findElement(By.xpath("(//input[@name='lastName'])[1]"));
			WebElement email  = driver.findElement(By.xpath("(//input[@name='email'])[1]"));
			WebElement phone  = driver.findElement(By.xpath("(//input[@name='phone'])[4]"));

			RC_Global.selectDropdownOption(driver, contactInfoLabel[0], contactInfo[0], false,false);
			RC_Global.enterInput(driver, contactInfo[1], Address1, false,false);
			RC_Global.enterInput(driver,contactInfo[2], City, false,false);
			driver.findElement(By.xpath("(//select[@name='state'])[4]")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("(//select[@name='state'])[4]/option[text()='"+contactInfo[3]+"']")).click();
			RC_Global.enterInput(driver,contactInfo[4], zipCode, false,false);
			RC_Global.enterInput(driver,contactInfo[5],firstName , false,false);
			RC_Global.enterInput(driver,contactInfo[6], lastName, false,false);
			RC_Global.enterInput(driver, contactInfo[7], email, false,false);
			RC_Global.enterInput(driver, contactInfo[8], phone, false,false);	   
			queryObjects.logStatus(driver, Status.PASS, "Vehicle Pickup Location and Contact Information section data enter", "Successful",null );
	  
		
		}
		 catch(Exception e) {
						   
	         queryObjects.logStatus(driver, Status.FAIL, "Vehicle Pickup Location and Contact Information section filling failed", e.getLocalizedMessage(), e);
	               if(endRun)
	                        RC_Global.endTestRun(driver);
	         }
		
		}
	
	public static void terminateConfirmationSectionValidation(WebDriver driver,String[] TerminationOption,String[] SectionsToValidate,boolean endRun)throws Exception{
        
		RC_Global.createNode(driver, "Terminate Vehicle Confirmation Screen Validation");
        try {	
        	  List<WebElement> TitleAddress = driver.findElements(By.xpath("//legend[text()='Title Address']"));
              List<WebElement> VehicleProgramTermination = driver.findElements(By.xpath("//legend[text()='Vehicle Program Termination']"));
              List<WebElement> VehicleConDetails = driver.findElements(By.xpath("//legend[text()='Vehicle Pickup Location & Contact Details']"));
              List<WebElement> DisclosureAgreement = driver.findElements(By.xpath("//legend[text()='Disclosure Agreement']"));
             //TitleAddress 
              if(TitleAddress.size()>0 && SectionsToValidate[0]=="TitleAddress") {
                  queryObjects.logStatus(driver, Status.PASS, "Title Address Section is displaying", "Title Address",null );
                  
                  String RequestSubmittedOn = driver.findElement(By.xpath("//label[text()='Request Submitted On: ']/following::span[1]")).getText();
                  String SysDate = (new SimpleDateFormat("MM/dd/yyyy")).format(new Date());
                  if(RequestSubmittedOn.contains(SysDate))
                         queryObjects.logStatus(driver, Status.PASS, "Request Submitted On:", ""+RequestSubmittedOn,null );
                  else
                	  	queryObjects.logStatus(driver, Status.FAIL, "Request Submitted On: Diplayed", "is not correct"+RequestSubmittedOn,null );
              
                  Thread.sleep(1000);
                  String  ConfirmationNum= driver.findElement(By.xpath("//label[text()='Request Submitted On: ']/following::span[2]")).getText();
                  queryObjects.logStatus(driver, Status.PASS, "Confirmation Number: ", ""+ConfirmationNum,null );
                  
                  if(driver.findElements(By.xpath("//label[text()='Request Submitted On: ']/following::span[3]")).size()>0) {
                  String  OptionalDriverMessageSent = driver.findElement(By.xpath("//label[text()='Request Submitted On: ']/following::span[3]")).getText();
                  queryObjects.logStatus(driver, Status.PASS, "Optional Driver Message Sent:", ""+OptionalDriverMessageSent,null );}
                  
                  Thread.sleep(1000);
                  String  RequestSubmittedBy = driver.findElement(By.xpath("//label[text()='Request Submitted On: ']/following::span[4]")).getText();
                  String userName = ((WebElement)(driver.findElement(By.xpath("//div[@class='bottom-nav bottom-right-menu']//div/ul[@class='nav-right list-unstyled pull-right user-menu']/li/a")))).getText();
                  Thread.sleep(1000);
                 /* if(RequestSubmittedBy.contains(userName))
                  queryObjects.logStatus(driver, Status.PASS, "Request Submitted By:", ""+RequestSubmittedBy,null );
                  else
                  queryObjects.logStatus(driver, Status.FAIL, "Request Submitted By:", RequestSubmittedBy+"is displaying incorrect",null );*/

                  String  Driver_PoolName = driver.findElement(By.xpath("//label[text()='Request Submitted On: ']/following::span[5]")).getText();
                  queryObjects.logStatus(driver, Status.PASS, "Driver/Pool Name:", ""+Driver_PoolName,null );
                  
              }
             // Vehicle Program Termination
              if(VehicleProgramTermination.size()>0 && SectionsToValidate[1]=="VehicleProgramTermination") {
                  queryObjects.logStatus(driver, Status.PASS, "Vehicle Program Termination Section is displaying", "Vehicle Program Termination",null );
                  String  DriverActiveStatus = driver.findElement(By.xpath("//label[contains(text(),'Driver still an active Employee')]/following::span[1]")).getText();
                  String  FuelEnrolled = driver.findElement(By.xpath("//label[contains(text(),'enrolled in Fuel')]/following::span[1]")).getText();
                  String  PersonalUseEnrolled = driver.findElement(By.xpath("//label[contains(text(),'enrolled in Personal Use')]/following::span[1]")).getText();
                 Thread.sleep(2000);
                 String[] TerminationFields = {"Driver still an active Employee with the Company","Enrolled in Fuel","Erolled in Personal Use"};
                 String[] VehicleTermination = {DriverActiveStatus,FuelEnrolled,PersonalUseEnrolled};
                 for(int i=0; i< TerminationOption.length;i++) {
                	 if(VehicleTermination[i].equalsIgnoreCase(TerminationOption[i]))
                     queryObjects.logStatus(driver, Status.PASS, TerminationFields[i]+" has the value", VehicleTermination[i]+"",null );
                     else
                     queryObjects.logStatus(driver, Status.FAIL, TerminationFields[i]+" have wrong the value", VehicleTermination[i]+"",null );
							  
                 }
              }
																																					   
              
              Thread.sleep(2000);
              //Vehicle Pickup Location & Contact Details
              if(VehicleConDetails.size()>0 && SectionsToValidate[2]=="VehicleConDetails") {
                  queryObjects.logStatus(driver, Status.PASS, "Vehicle Pickup Location & Contact Details Section is displaying", "Vehicle Pickup Location & Contact Details",null );
                  for(int i=1;i<=9;i++) {
                      String  VehicleCntctlabels = driver.findElement(By.xpath("//legend[text()='Vehicle Pickup Location & Contact Details']/following::label["+i+"]")).getText();
                      String  VehicleCntctdata = driver.findElement(By.xpath("//legend[text()='Vehicle Pickup Location & Contact Details']/following::label[1]/following::span["+i+"]")).getText();
                      Thread.sleep(1000);
                      queryObjects.logStatus(driver, Status.INFO, ""+VehicleCntctlabels, ""+VehicleCntctdata,null );
                  }
																													  
              }
              Thread.sleep(2000);
              //Disclosure Agreement 
              if(DisclosureAgreement.size()>0 && SectionsToValidate[3]=="DisclosureAgreement") {
                  queryObjects.logStatus(driver, Status.PASS, "Disclosure Agreement Section is displaying", "Vehicle Pickup Location & Contact Details",null );
                  String  OdometerReadin = driver.findElement(By.xpath("//label[text()='Disclosed Odometer:']/following::span[1]")).getText();
                  if(OdometerReading.contains(OdometerReadin))
                  queryObjects.logStatus(driver, Status.PASS, "Disclosed Odometer:", ""+OdometerReadin,null );
                  else
                  queryObjects.logStatus(driver, Status.FAIL, "Disclosed Odometer displayed is incorrect", ""+OdometerReadin,null );
           }
					  
        	
        }catch(Exception e) {
            queryObjects.logStatus(driver, Status.FAIL, "Not found Damage Disclosure selection", e.getLocalizedMessage(), e);
            if(endRun)
                     RC_Global.endTestRun(driver);
      }
        }
	public static void requesttypeToggleOption (WebDriver driver,String Sectionname, boolean endRun) throws Exception{
	    RC_Global.createNode(driver, "'"+Sectionname+"' Toggle Option validation ");
	    try {
	        String Values = "";
	            List<WebElement> options = driver.findElements(By.xpath("//label[text()='Request Type']/../label[contains(@ng-class,'displayCourtesyAuctionSaleFields')]/label"));
	            String Activebutton = driver.findElement(By.xpath("//label[contains(@class,'active disabled-active-button')]")).getText();
	            for(int i=1; i< options.size(); i++) {
	             Values = driver.findElement(By.xpath("//label[contains(@ng-class,'displayCourtesyAuctionSaleFields')]//label["+i+"]")).getText();
								
																					  
	            queryObjects.logStatus(driver, Status.INFO, "Toggle option values are ", Values, null);
	              
	            }
	            if(Activebutton.length()>0)
	            {
																															   
						  
																																				 
	  
	            queryObjects.logStatus(driver, Status.PASS, "By Deafult selected Option ", Activebutton, null);
	            }
	    }
	    catch(Exception e) {
	            queryObjects.logStatus(driver, Status.FAIL, "No Toggle Options are found", e.getLocalizedMessage(), e);
	                  if(endRun)
	                           RC_Global.endTestRun(driver);
	            }
	    }
	public static void screenSectionDetailsValidation(WebDriver driver, String sectioName, String labelText,boolean endRun) throws Exception {
		try {
			String dataDetails = "";
			switch (sectioName) {
		//Title Information
			case "Title Information":
			      if (driver.findElements(By.xpath("//div[normalize-space(text())='" + sectioName+ "']//ancestor::div//div//label[normalize-space(text())='" + labelText.trim()+ "']")).size() > 0) {
			    	  dataDetails = driver.findElement(By.xpath("//div[normalize-space(text())='" + sectioName+ "']//ancestor::div//div//label[normalize-space(text())='" + labelText+ "']/../following-sibling::div")).getText();
		              queryObjects.logStatus(driver, Status.PASS,"Section :" + sectioName + " has label " + labelText + " with value", dataDetails, null);
		          } 
			      else {
			    	  queryObjects.logStatus(driver, Status.FAIL,"The lable :" + labelText + " is not found in section " + sectioName, null, null);
		          }
		          break;
		//Client Directed Sale - History
			case "Client Directed Sale - History":
			       if(driver.findElements(By.xpath("//span[text()='"+sectioName+"']/..//following::div//label[text()='"+labelText+"']/../a")).size()>0)
			              {
			                     dataDetails = driver.findElement(By.xpath("//span[text()='"+sectioName+"']/..//following::div//label[text()='"+labelText+"']/../a")).getText();
			                     if(dataDetails.length()==0)
			                     {      
			                     queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with ", "empty value",null);                  
			                     }
			                     else
			                     {
			                     queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with value",dataDetails, null);
			                     }
			              }
			              else if(driver.findElements(By.xpath("//span[text()='"+sectioName+"']/..//following::div//label[text()='"+labelText+"']/../span")).size()>0)
			              {
			                     dataDetails = driver.findElement(By.xpath("//span[text()='"+sectioName+"']/..//following::div//label[text()='"+labelText+"']/../span")).getText();
			                     if(dataDetails.length()==0)
			                     {      
			                     queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with ", "empty value",null);                  
			                     }
			                     else
			                     {
			                     queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with value",dataDetails, null); 
			                     }
			              }
			              break;

		//Termination Request Summary
			case "Termination Request Summary":
				   if(driver.findElements(By.xpath("//legend[text()='"+sectioName+"']/..//following::div//div//div//label[normalize-space(text())='"+labelText+"']")).size()>0)
			       {
			          dataDetails = driver.findElement(By.xpath("(//legend[text()='"+sectioName+"']/..//following::div//div//div//label[normalize-space(text())='"+labelText+"']/../following-sibling::div/span)[2]")).getText();      
			          queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with value",dataDetails, null);
			       }
				   else if(driver.findElements(By.xpath("(//legend[contains(text(),'"+sectioName+"')][1]/../following::label[contains(text(),'"+labelText+"')]/../following::span)[1]")).size()>0)
			        {
			          dataDetails = driver.findElement(By.xpath("(//legend[contains(text(),'"+sectioName+"')][1]/../following::label[contains(text(),'"+labelText+"')]/../following::span)[1]")).getText();
			          queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with value",dataDetails, null);
			        }
			      else
			       {
			          queryObjects.logStatus(driver,Status.FAIL,"The lable :"+labelText+" is not found in section "+sectioName, null,null);
			       }
			      break;
         
            case "Title Mailing Information":
            if(driver.findElements(By.xpath("(//div/legend[text()='"+sectioName+"']/../following::div/label[normalize-space(text())='"+labelText+"'])[1]//ancestor::div[2]")).size()>0)
                   {
                   dataDetails = driver.findElement(By.xpath("(//div/legend[text()='"+sectioName+"']/../following::div/label[normalize-space(text())='"+labelText+"'])[1]//ancestor::div[2]//span")).getText();
                         if(dataDetails.contains(TID_4_1_1_17.Name))
                         queryObjects.logStatus(driver,Status.PASS," Entered Title Mailing Information value displays in confirmation screen: label "+labelText+" with value",dataDetails , null);
                         else 
                         queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with value",dataDetails, null);
                   }
                   else
                   {
                   queryObjects.logStatus(driver,Status.FAIL,"The lable :"+labelText+" is not found in section "+sectioName, null,null);
                   }
                   break;

		 //Vehicle Program Termination    
		   case "Vehicle Program Termination":
			    if(driver.findElements(By.xpath("(//legend[text()='"+sectioName+"']/..//following::div//div//div//label[normalize-space(text())='"+labelText+"'])[2]")).size()>0)
		         {
		           dataDetails = driver.findElement(By.xpath("(//legend[text()='"+sectioName+"']/..//following::div//div//div//label[normalize-space(text())='"+labelText+"']/../following-sibling::div)[2]")).getText();      
		           queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with value",dataDetails, null);
		         }
			    else if(driver.findElements(By.xpath("(//legend[contains(text(),'"+sectioName+"')]/../following::label[contains(text(),'"+labelText+"')]/../following::span)[1]")).size()>0)
		         {
		           dataDetails = driver.findElement(By.xpath("(//legend[contains(text(),'"+sectioName+"')]/../following::label[contains(text(),'"+labelText+"')])[1]/../following::span[1]")).getText();
		           queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with value",dataDetails, null);
		         }
		       
		       else
		         {
		           queryObjects.logStatus(driver,Status.FAIL,"The lable :"+labelText+" is not found in section "+sectioName, null,null);
		         }
		      break;
		//Vehicle Pickup Location & Contact Details(Request Summary)     
		   case "Vehicle Pickup Location & Contact Details":
	             if(driver.findElements(By.xpath("(//legend[text()='"+sectioName+"']/..//following::div//div//label[text()='"+labelText+"'])[1]")).size()>0)
	                 {
	                       dataDetails = driver.findElement(By.xpath("(//legend[text()='"+sectioName+"']/..//following::div//div//label[text()='"+labelText+"']/following::span)[1]")).getText();      
	                       queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with value",dataDetails, null);
	                 }
	                 else
	                 {
	                      queryObjects.logStatus(driver,Status.FAIL,"The lable :"+labelText+" is not found in section "+sectioName, null,null);
	                 }
	             break;
	    //Vehicle Pickup Location and Contact(Manage Sale)
		   case "Vehicle Pickup Location and Contact":
		       if(driver.findElements(By.xpath("(//legend[contains(text(),'Vehicle Pickup Location and Contact')])[2]/../following::div//div")).size()>0)
		        {
		          dataDetails = driver.findElement(By.xpath("(//legend[contains(text(),'Vehicle Pickup Location and Contact')])[2]/../following::div//div")).getText();
		          queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has text",dataDetails, null);
		        }
		      if(driver.findElements(By.xpath("(//legend[contains(text(),'"+sectioName+"')]/../following::div//label[contains(text(),'"+labelText+"')])[2]")).size()>0)
		        {
		      if(labelText.equalsIgnoreCase("Pickup Location Type"))
		        {
		          dataDetails = driver.findElement(By.xpath("(//legend[contains(text(),'"+sectioName+"')]/../following::div//label[contains(text(),'"+labelText+"')])[2]/../following::select[1]//option[contains(@selected,'selected')]")).getText();
		        }
		      else if(labelText.equalsIgnoreCase("State"))
		        {
		         dataDetails = driver.findElement(By.xpath("(//legend[contains(text(),'"+sectioName+"')]/../following::div//label[contains(text(),'"+labelText+"')])[2]/../following::select[1]//option[contains(@selected,'selected')][2]")).getText();
		        }
		      else if(labelText.equalsIgnoreCase("Default Contact & Location"))
		        {
		        	 dataDetails = driver.findElement(By.xpath("(//legend[contains(text(),'Vehicle Pickup Location and Contact')]/../following::div//label[contains(text(),'Default Contact & Location')])[2]/../following::label[1]")).getText()
		 +"/"+ driver.findElement(By.xpath("(//legend[contains(text(),'Vehicle Pickup Location and Contact')]/../following::div//label[contains(text(),'Default Contact & Location')])[2]/../following::label[2]")).getText();
		        }
		      else if(driver.findElements(By.xpath("(//legend[contains(text(),'"+sectioName+"')]/../following::div//label[contains(text(),'"+labelText+"')])[2]/../following::input[1]")).size()>0)
		        {
		         dataDetails = driver.findElement(By.xpath("(//legend[contains(text(),'"+sectioName+"')]/../following::div//label[contains(text(),'"+labelText+"')])[2]/../following::input[1]")).getAttribute("value");
		        }
		      }
		        queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with value",dataDetails, null);
		    switch(labelText)
		      {
		//Pickup Contact Phone
		 case "Pickup Contact Phone":
		 if(driver.findElements(By.xpath("(//legend[contains(text(),'Vehicle Pickup Location and Contact')]/../following::div//label[contains(text(),'Ext')])[5]/../following::input[1]")).size()>0)
		 {
		 dataDetails = driver.findElement(By.xpath("(//legend[contains(text(),'Vehicle Pickup Location and Contact')]/../following::div//label[contains(text(),'Ext')])[5]/../following::input[1]")).getAttribute("value");
		 queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label Ext with value",dataDetails, null);
		 }
		 if(driver.findElements(By.xpath("(//legend[contains(text(),'Vehicle Pickup Location and Contact')]/../following::div//label[contains(text(),'Alternate Phone')])[3]/../following::input[1]")).size()>0)
		 {
		 dataDetails = driver.findElement(By.xpath("(//legend[contains(text(),'Vehicle Pickup Location and Contact')]/../following::div//label[contains(text(),'Alternate Phone')])[3]/../following::input[1]")).getAttribute("value");
		 queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label Alternate Phone with value",dataDetails, null);
		 }
		 if(driver.findElements(By.xpath("(//legend[contains(text(),'Vehicle Pickup Location and Contact')]/../following::div//label[contains(text(),'Ext')])[6]/../following::input[1]")).size()>0)
		 {
		 dataDetails = driver.findElement(By.xpath("(//legend[contains(text(),'Vehicle Pickup Location and Contact')]/../following::div//label[contains(text(),'Ext')])[6]/../following::input[1]")).getAttribute("value");

		 queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label Ext with value",dataDetails, null);

		 }
		 break;
     //Secondary Phone
		 case "Secondary Phone ":
		 if(driver.findElements(By.xpath("(//legend[contains(text(),'Vehicle Pickup Location and Contact')]/../following::div//label[contains(text(),'Ext')])[7]/../following::input[1]")).size()>0)
		 {
		 dataDetails = driver.findElement(By.xpath("(//legend[contains(text(),'Vehicle Pickup Location and Contact')]/../following::div//label[contains(text(),'Ext')])[7]/../following::input[1]")).getAttribute("value");
		 queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label Ext with value",dataDetails, null);
		 }
		 if(driver.findElements(By.xpath("(//legend[contains(text(),'Vehicle Pickup Location and Contact')]/../following::div//label[contains(text(),'Alternate Phone')])[4]/../following::input[1]")).size()>0)
		 {
		 dataDetails = driver.findElement(By.xpath("(//legend[contains(text(),'Vehicle Pickup Location and Contact')]/../following::div//label[contains(text(),'Alternate Phone')])[4]/../following::input[1]")).getAttribute("value");
		 queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label Alternate Phone with value",dataDetails, null);
		 }
		 if(driver.findElements(By.xpath("(//legend[contains(text(),'Vehicle Pickup Location and Contact')]/../following::div//label[contains(text(),'Ext')])[8]/../following::input[1]")).size()>0)
		 {
		 dataDetails = driver.findElement(By.xpath("(//legend[contains(text(),'Vehicle Pickup Location and Contact')]/../following::div//label[contains(text(),'Ext')])[8]/../following::input[1]")).getAttribute("value");
		 queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label Ext with value",dataDetails, null);
		 }
		 break;
		 }
		 break;
	//Consign Vehicle
		 case "Consign Vehicle":
		 if(driver.findElements(By.xpath("(//legend[contains(text(),'Consign Vehicle')]/../following::div//p)[1]")).size()>0)
		 {
		 dataDetails = driver.findElement(By.xpath("(//legend[contains(text(),'Consign Vehicle')]/../following::div//p)[1]")).getText();
		 queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has header text",dataDetails, null);
		 }
		 if(driver.findElements(By.xpath("(//legend[text()='"+sectioName+"']/..//following::div//div//div//label[text()='"+labelText+"'])[1]")).size()>0)
		 {
		 dataDetails = driver.findElement(By.xpath("(//legend[text()='"+sectioName+"']/..//following::div//div//div//label[text()='"+labelText+"'])[1]/../following-sibling::div")).getText();
		 queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with value",dataDetails, null);
		 }
		 else
		 {
		 queryObjects.logStatus(driver,Status.FAIL,"The lable :"+labelText+" is not found in section "+sectioName, null,null);
		 }
		 break;
	//Disclosure Agreement
		  case "Disclosure Agreement":
		              if(driver.findElements(By.xpath("(//legend[text()='"+sectioName+"']/..//following::div//div//div[contains(text(),'"+labelText+"')])[1]")).size()>0)
		                  {
		                        dataDetails = driver.findElement(By.xpath("(//legend[text()='"+sectioName+"']/..//following::div//div//div[contains(text(),'"+labelText+"')]/following::span)[1]")).getText();      
		                        queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with value",dataDetails, null);
		                  }
		                  else
		                  {
		                       queryObjects.logStatus(driver,Status.FAIL,"The lable :"+labelText+" is not found in section "+sectioName, null,null);
		                  }
		              break;
     //Vendor Search
		 case "Vendor Search":
		 if(driver.findElements(By.xpath("//h4[contains(text(),'"+sectioName+"')]/../following::label[contains(text(),'"+labelText+"')]")).size()>0)
		 {
		 if(labelText.equalsIgnoreCase("Enter an Address, Zip Code, City, State to find a Vendor Near You"))
		 {
		 dataDetails =driver.findElement(By.xpath("//h4[contains(text(),'Vendor Search')]/../following::label[contains(text(),'Enter an Address, Zip Code, City, State to find a Vendor Near You')]/../input")).getText();
		 queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with previously entered address ",dataDetails, null);
		 }
		 else if(labelText.equalsIgnoreCase("Within X Miles"))
		 {
		 dataDetails =driver.findElement(By.xpath("//h4[contains(text(),'"+sectioName+"')]/../following::label[contains(text(),'"+labelText+"')]/../select/option[@selected='selected']")).getText();
		 queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with value",dataDetails, null);
		 }
		 else if(labelText.equalsIgnoreCase("Vendor Rating"))
		 {
		 dataDetails =driver.findElement(By.xpath("//h4[contains(text(),'"+sectioName+"')]/../following::label[contains(text(),'"+labelText+"')]/../select/option")).getText();
		 queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with value",dataDetails, null);
		 }
		 else
		 {
		 dataDetails =driver.findElement(By.xpath("//h4[contains(text(),'"+sectioName+"')]/../following::label[contains(text(),'"+labelText+"')]/../input")).getText();
		 queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with value",dataDetails, null);
		 }
		 }
		 break;
		 }
		 }
		 catch(NullPointerException npe) {
		 queryObjects.logStatus(driver, Status.FAIL, "The lable :"+labelText+" is not found in section "+sectioName, npe.getLocalizedMessage(), npe);
		 if(endRun)
		 RC_Global.endTestRun(driver);
		 }
		 }
	 
	public static void selectRowWithSalesStatusFromGrid(WebDriver driver,String SalesStatus, boolean endRun) throws Exception{
        WebDriverWait wait = new WebDriverWait(driver,60);
                try {
                    Thread.sleep(1000);
                    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tbody//tr")));
                    List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("//table//tbody//tr"));
                    int rowcnt=Getgridrowcnt.size();
                    boolean firstpage=false;
                    boolean pagination=false;
                   
                    for(int i=1; i<rowcnt;i++) {
                        WebElement sub = driver.findElement(By.xpath("//tr["+i+"]//td[4]"));
                        String CVN = sub.getText();
                        if(!CVN.isEmpty()) {
                    WebElement unitclmn = driver.findElement(By.xpath("//tbody//tr["+i+"]//td[3]"));
                            WebElement clmn = driver.findElement(By.xpath("//tbody/tr[1]/td[7]/a[text() ='"+SalesStatus+"']"));
                            unitnumber = unitclmn.getText();
                            Thread.sleep(2000);
                            clmn.click();
                            firstpage = false;
                            break;
                        }
                        firstpage = true;
                    }      
                  
                    if(firstpage)
                    {  
                        String NextBttn = driver.findElement(By.xpath("//a[text()='Next']")).getAttribute("ng-disabled");
                        while(!NextBttn.equals("ngDisabled")) {
                            driver.findElement(By.xpath("//a[text()='Next']")).click();
                            Thread.sleep(3000);
                            for(int j=1; j<rowcnt;j++) {
                                WebElement sub = driver.findElement(By.xpath("//tr["+j+"]//td[4]"));
                                String CVN = sub.getText();
                                if(!CVN.isEmpty()) {
                            WebElement unitclmn = driver.findElement(By.xpath("//tbody//tr["+j+"]//td[3]"));
                                    WebElement clmn = driver.findElement(By.xpath("//tbody/tr[1]/td[7]/a[text() ='"+SalesStatus+"']"));
                                    unitnumber = unitclmn.getText();
                                    Thread.sleep(2000);
                                    clmn.click();                              
                                    pagination=false;
                                    break;                        
                                }
                                else     
                                    pagination=true;}
                        if(pagination){
                            NextBttn =  driver.findElement(By.xpath("//a[text()='Next']")).getAttribute("ng-disabled");
                        }
                        else {
                        break;
                        }}
                }  
                    queryObjects.logStatus(driver, Status.PASS, "Searching Required grid record from Webtable", "Successful", null);
                                                                                                                                 
                }
                catch(TimeoutException te) {
                    queryObjects.logStatus(driver, Status.FAIL, "Failed to Search Required grid record -> Unable to Search Required grid record screen", te.getLocalizedMessage(), te);
                    if(endRun)
                        RC_Global.endTestRun(driver);
                    }
                catch (Exception e){
                  
                    queryObjects.logStatus(driver, Status.FAIL, "Searching Required grid record from Webtable", e.getLocalizedMessage(), e);
                    if(endRun)
                        RC_Global.endTestRun(driver);
                    }
            }

	public static void validateTabNames(WebDriver driver, String Tab, boolean endRun)throws Exception {
		RC_Global.createNode(driver, "Validate the Tabs");
		String[] TabNames = Tab.split(";");
		String sTab = "";
		try {
              List<WebElement> GetTabcnt = driver.findElements(By.xpath("//div[@active='tabToSelect']/ul/li/a"));
              int tabcnt=GetTabcnt.size();
              
              for(int i=1; i<=tabcnt;i++) {
            	  sTab = driver.findElement(By.xpath("(//div[@active='tabToSelect']/ul/li/a)["+i+"]")).getText();
           
            	  if((sTab).equalsIgnoreCase (TabNames[i-1])) {
            		  queryObjects.logStatus(driver, Status.PASS, "Diplays the "+sTab+" Tab", "Successful", null);
            	  }
              }      
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, " Tab is Not Displayed ", "unable to find the Tab", null);
			if(endRun)
				RC_Global.endTestRun(driver);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, " Tab is Not found ", e.getLocalizedMessage(), e);
			if(endRun)
				RC_Global.endTestRun(driver);
		}
	}
	
	public static boolean isValidDateFormat(WebDriver driver, String format, String value,boolean endRun) throws Exception {

		Date date = null;
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			date = sdf.parse(value);
			if (!value.equals(sdf.format(date))) {
				queryObjects.logStatus(driver, Status.PASS, "Submission Date is in valid Format", ""+value+" - MM/DD/YYYY ", null);
				date = null;
			}
		} catch (Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Submission Date is in Invalid Format", e.getLocalizedMessage(), e);
            if(endRun)
                     RC_Global.endTestRun(driver);
		}	
		return true;
	}
	
	public static void multiSelectValues (WebDriver driver ,String Field,boolean endRun)throws Exception{
        RC_Global.createNode(driver, "'"+Field+"' Multiselect Field Values ");
        try {
            WebElement multiselect= driver.findElement(By.xpath("//select[@name='"+Field+"']"));
            Select s=new Select(multiselect);
            List<WebElement> values = s.getOptions();
            for (WebElement options: values){
                queryObjects.logStatus(driver, Status.PASS, ""+Field+"- Multiselect Field Options are ", options.getText(), null);
          }
            WebElement sel = s.getFirstSelectedOption();
                queryObjects.logStatus(driver, Status.INFO, " By Default selected '"+Field+"' option is: ", sel.getText(), null);
        
        }
        catch(Exception e) {
                queryObjects.logStatus(driver, Status.FAIL, " Not found Multiselect Field Options ", e.getLocalizedMessage(), e);
              if(endRun)
                       RC_Global.endTestRun(driver);  
        }

 

    }
	
	public static boolean dateOpenCount(WebDriver driver,String submissionDate,String openDays,boolean endRun) throws Exception {

		int Days = Integer.parseInt(openDays);
		try {
			@SuppressWarnings("deprecation")
			int currentDate = new Date().getDate();
			int sub = new Date(submissionDate).getDate();
			int tot = (currentDate - sub); 
				if(tot==Days) {
				 queryObjects.logStatus(driver, Status.PASS, "Current Date minus Submission Date count equals to", "Days Open Count ", null);
			 }	
		}
		catch (Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to fetch Date Count", e.getLocalizedMessage(), e);
			if(endRun)
                RC_Global.endTestRun(driver);
		}
		
		return true;
	}		
	public static void toggleOptionValues (WebDriver driver,String Sectionname, boolean endRun) throws Exception{
		RC_Global.createNode(driver, "'"+Sectionname+"' Toggle Option validation ");
		try {
			String Values = "";
				List<WebElement> options = driver.findElements(By.xpath("//label[text()='"+Sectionname+"']/../label[contains(@ng-class,'displayCourtesyAuctionSaleFields')]/label"));
				String Activebutton = driver.findElement(By.xpath("//label[contains(@class,'active disabled-active-button')]")).getText();
				for(int i=1; i<= options.size(); i++) {
				 Values = driver.findElement(By.xpath("//label[contains(@ng-class,'displayCourtesyAuctionSaleFields')]//label["+i+"]")).getText();
				queryObjects.logStatus(driver, Status.INFO, "Toggle option values are ", Values, null);
					
				}
				if(Activebutton.length()>0)
				{
		
				queryObjects.logStatus(driver, Status.PASS, "By Deafult selected Option ", Activebutton, null);
				}
		}
		catch(Exception e) {
	            queryObjects.logStatus(driver, Status.FAIL, "No Toggle Options are found", e.getLocalizedMessage(), e);
	                  if(endRun)
	                           RC_Global.endTestRun(driver);
	            }
	    }
	public static void verifyHistoryGridColumns(WebDriver driver, String ColumnNames, boolean endRun )throws Exception {
	       
	 	   String[] ColNames = ColumnNames.split(";");
	 	   List<WebElement> colCount = null;
	           try{             
			colCount = driver.findElements(By.xpath("//grid-history[@panel='vm.panel']//div[@role='button']/span[contains(@class,'ng-binding')]"));
	                        	                        	
	                     	   for (int i = 0; i<colCount.size(); i++) {
	         				 String data = driver.findElement(By.xpath("(//grid-history[@panel='vm.panel']//div[@role='button']/span[contains(@class,'ng-binding')])[1+"+i+"]")).getText();
	                                  queryObjects.logStatus(driver, Status.PASS, "Column Validation for '"+data+"' ", " Column is verified", null);
	                               }
	                               Thread.sleep(1000);
	                              

	           }
	           catch(TimeoutException te) {
			        queryObjects.logStatus(driver, Status.FAIL, "Grid column data validation failed","No record found", null);
			if (endRun)
				RC_Global.endTestRun(driver);
			}
			catch(Exception e) {
			        queryObjects.logStatus(driver, Status.FAIL, "Grid column data validation Not Found","", e);
			if (endRun)
				RC_Global.endTestRun(driver);
			}
		}
	public static void selectNonAutoImsRecord(WebDriver driver,boolean endRun) throws Exception {
		RC_Global.createNode(driver, "Select NonAutoIms Record from Grid");
		try {
			RC_Global.waitElementVisible(driver, 30, "((//div[@role='rowgroup'])[14]//div[@role='row'])[1]", "Grid Results", false, false);
			
		List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("(//div[@role='rowgroup'])[14]//div[@role='row']"));  
        Thread.sleep(2000);
        int rowcnt=Getgridrowcnt.size();
        boolean	firstpage=false;
    	boolean pagination=false;
        for(int i=1; i<rowcnt;i++) {
        
                WebElement VendorNameRecord =	driver.findElement(By.xpath("((//div[@role='rowgroup'])[14]//div[@role='row']//div[contains(@ng-bind,'grid.appScope.vm.checkAutoIms')])["+i+"]"));
                Thread.sleep(1000);
                String NonAutoIms =	VendorNameRecord.getText();
                Thread.sleep(1000);
                if(!NonAutoIms.equalsIgnoreCase("x")) {
                  driver.findElement(By.xpath("((//div[@role='rowgroup'])[14]//div[@role='row']/div[8]/div)["+i+"]")).click();
                  Thread.sleep(1000);
                  firstpage = false;
  				queryObjects.logStatus(driver, Status.PASS, "The Non-AutoIms record is selected from grid", "Succesful", null);
                break;}
                firstpage = true;
        }
        if(firstpage) 
		{	
			String NextBttn = driver.findElement(By.xpath("//a[text()='Next']")).getAttribute("ng-disabled");
			while(!NextBttn.equals("ngDisabled")) {
				driver.findElement(By.xpath("//a[text()='Next']")).click();
				Thread.sleep(3000);
				for(int j=1; j<=rowcnt;j++) {
					WebElement VendorNameRecord =	driver.findElement(By.xpath("((//div[@role='rowgroup'])[14]//div[@role='row']/div[8]/div)["+j+"]"));
	                Thread.sleep(1000);
	                String NonAutoIms =	VendorNameRecord.getText();
	                Thread.sleep(1000);
	                if(!NonAutoIms.equalsIgnoreCase("x")) {
	                  driver.findElement(By.xpath("((//div[@role='rowgroup'])[14]//div[@role='row']/div[8]/div)["+j+"]")).click();
	                  Thread.sleep(1000);
	                  pagination=false;
	                  queryObjects.logStatus(driver, Status.PASS, "The Non-AutoIms record is selected from grid", "Succesful", null);
	                  break;
				}else
					pagination=true;
				}
			if(pagination){ 
				NextBttn =  driver.findElement(By.xpath("//a[text()='Next']")).getAttribute("ng-disabled");
			}
			else {
			break;}
			
		}
	}
		} catch(TimeoutException te) {
            queryObjects.logStatus(driver, Status.FAIL, "Failed to Select Non-AutoIms record -> Unable to Search Required grid record screen", te.getLocalizedMessage(), te);
            if(endRun)
                RC_Global.endTestRun(driver);
            }
        catch(Exception e) {
            queryObjects.logStatus(driver, Status.FAIL, "Failed to Select Non-AutoIms record -> Unable to Search Required grid record screen", e.getLocalizedMessage(), e);
                  if(endRun)
                           RC_Global.endTestRun(driver);
            }
}
	}
   

