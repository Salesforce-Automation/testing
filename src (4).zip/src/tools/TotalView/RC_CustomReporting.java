package tools.TotalView;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;

public class RC_CustomReporting {
	static BFrameworkQueryObjects queryObjects = new BFrameworkQueryObjects();
	
	public static void selectAReportingDomain(WebDriver driver, String reportingDemo) throws Exception{
		RC_Global.createNode(driver, "Select "+reportingDemo+" Domain");
		switch(reportingDemo) {
			case "Fuel": driver.findElement(By.xpath("//a[div[text()='Fuel']]")).click(); break;
			case "List of Fleet": driver.findElement(By.xpath("//a[div[text()='List of Fleet']]")).click(); break;
			case "Maintenance": driver.findElement(By.xpath("//a[div[text()='Maintenance']]")).click(); break;
		}
	}

	public static void switchFrame(WebDriver driver, WebElement toFrame){
		driver.switchTo().frame(toFrame);
		
	}
	
	public static void selectPowerBIIcon(WebDriver driver, String iconName) throws Exception{
		RC_Global.createNode(driver, "Select "+iconName+" Icon");
		try {	
			WebDriverWait wait = new WebDriverWait(driver, 120);
			WebElement pbiIcon = driver.findElement(By.xpath("//button[@aria-label='"+iconName+"']"));
			wait.until(ExpectedConditions.elementToBeClickable(pbiIcon));
			pbiIcon.click();
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Select the Power BI icon: ", iconName, e);
		}
	}
	
	public static void selectFields(WebDriver driver, String ListTitle, String selectionFieldListTitle, String[] fieldNames) throws Exception{
		try {	
			expandList(driver,ListTitle);
			expandList(driver,selectionFieldListTitle);
			for(String fn:fieldNames) {
				driver.findElement(By.xpath("//li[@aria-label='"+fn+"']//input")).click();
			}
			queryObjects.logStatus(driver, Status.PASS, "Selection to be made", "Selection successful", null);

		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Failed to select Fields", e.getLocalizedMessage(), e);
		}
		
	}
	
	public static void expandList(WebDriver driver, String tableName) throws Exception{
		try {
			if(driver.findElements(By.xpath("//h1[@aria-label='"+tableName+" Table']/i[1]")).size()>0) {
				if(driver.findElements(By.xpath("//h1[@aria-label='"+tableName+" Table']/i[contains(@class,'expanded')][1]")).size()==0)
					driver.findElement(By.xpath("//h1[@aria-label='"+tableName+" Table']/i[1]")).click();
			}
			else if(driver.findElements(By.xpath("//li[@aria-label='"+tableName+"']//pbi-icon")).size()>0) {
				if(driver.findElements(By.xpath("//li[@aria-label='"+tableName+"']//pbi-icon[contains(@class,'expanded')]")).size()==0)
					driver.findElement(By.xpath("//li[@aria-label='"+tableName+"']//pbi-icon")).click();
			}
			Thread.sleep(3000);
			
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Failed to Expand List", e.getLocalizedMessage(), e);
		}
	}
	
	public static void saveReport(WebDriver driver, String reportName) throws Exception{
		try {	
			WebElement reportInput = driver.findElement(By.xpath("//input[@placeholder='Report Name']"));
			RC_Global.enterInput(driver, reportName, reportInput,true, true);
			
			RC_Global.clickButton(driver, "Save",true, true);
			
			queryObjects.logStatus(driver, Status.PASS, "Report to be saved", "Report Saved Successfully", null);
		}
		catch(Exception e) {	
			queryObjects.logStatus(driver, Status.FAIL, "Report to be saved", "Report not Saved", null);
		}
	}
	
	public static void reportGridActionsClick(WebDriver driver, String actions, String ReportName) throws Exception{
		RC_Global.createNode(driver, "Perform the grid action: "+actions);
		WebElement clickableElement = null;
		if(!actions.equalsIgnoreCase("Deactivate"))
			clickableElement= driver.findElement(By.xpath("//div[div[text()='"+actions+"']]/following-sibling::div[2]//i[@title='View']"));
		else if(actions.equalsIgnoreCase("Deactivate")) {
			if(driver.findElement(By.xpath("//div[div[text()='"+actions+"']]/following-sibling::div[2]//i[@title='Deactivate']")).isEnabled()) {
				driver.findElement(By.xpath("//div[div[text()='"+actions+"']]/following-sibling::div[2]//i[@title='Deactivate']")).click();
			}
			else
				queryObjects.logStatus(driver, Status.FAIL, "Check if Deactive option is available", "Deactive option not active", null);
		}
			

	}
    
	public static void CustomerNodeLevel(WebDriver driver) throws Exception{
    WebDriverWait wait = new WebDriverWait(driver,50);
	try {				
		//wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[@id='customReportingPortal']//treecontrol/ul/li/treeitem/ul"))));
		Thread.sleep(100);
		List <WebElement> checkBoxElement = driver.findElements(By.xpath("(//input[(@ng-model='node.isChecked') and (@checked='checked')])[1]"));
		if(checkBoxElement.size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Selected Customer-Node is the highest available node", "as per the Permission", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Selected Customer-Node is not the highest available node","as per the Permission", null);
				
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Failed to list node structure", e.getLocalizedMessage(), e);
		}
	}

    public static void SearchReport(WebDriver driver, String reportName) throws Exception{
    	RC_Global.createNode(driver, "Search report");
    	driver.findElement(By.xpath("//input[@aria-label='Filter for column']")).sendKeys(reportName);
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[text()='Sample Report436']")));

    	
	}
}