package tools.TotalView;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.RandomAccess;
import java.util.TimeZone;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.SpreadsheetVersion;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DataValidation;
import org.apache.poi.ss.usermodel.DataValidationConstraint;
import org.apache.poi.ss.usermodel.Name;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.AreaReference;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.CellRangeAddressList;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import MF.Source.Cred;
public class RC_Manage {
	
	public static String Department = "";
	public static String Role = "";
	public static String drivername = "";
	public static String unitNum ;
	public static String DriverAddress ="";
	public static String drivernameUpdated = "";
	public static String UnitNumber = "";
	public static String VehicleStatus= "";
	public static String Firstname= "";
	public static String Lastname= "";
	//public static String inputAddress = "";
	public static String data = "";
	public static String Username = "";
	public static String EmpAssignment = "";
	public static String VehicleAddress = "";
	public static String UnitNumberAOY = "";
	public static String UnitNumberAON = "";
	public static String zipCode = "";
	public static String Addressupdated = "";
	public static String updatdcurrentStatus = "";
	public static WebElement CDStatus = null;
	public static String Name = "";
	public static String driverFirstName = "";
	public static String driverLastName = "";
	
	static BFrameworkQueryObjects queryObjects = new BFrameworkQueryObjects();
	
	
	public static void selectRowWithUserNameFromGrid(WebDriver driver, boolean endRun) throws Exception{
		
		WebDriverWait wait = new WebDriverWait(driver,60);
	try {
		Thread.sleep(1000);
		List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("//table//tbody//tr"));  
		int rowcnt=Getgridrowcnt.size();
		boolean	firstpage=false;
		
		for(int i=1; i<=rowcnt;i++) {
			WebElement sub = driver.findElement(By.xpath("//tr["+i+"]//td[14]"));
			String Role = sub.getText();
			if(!Role.isEmpty()) {
				WebElement Username = driver.findElement(By.xpath("//tbody//tr["+i+"]//td[1]"));
				WebElement clmn = driver.findElement(By.xpath("//tbody//tr["+i+"]//td[13]"));
				Department = clmn.getText();
				if((Department.equalsIgnoreCase("Administration")|| Role.contains("Administrator / Super Admin"))) {
				Thread.sleep(2000);
				Username.click();
				firstpage = false;
				break;}
			}
		}
	}
	catch(TimeoutException te) {
		queryObjects.logStatus(driver, Status.FAIL, "Failed to Search User Name", te.getLocalizedMessage(), te);
		 if(endRun)
             RC_Global.endTestRun(driver);
		}
	catch (Exception e){
		queryObjects.logStatus(driver, Status.FAIL, "User Name hyperlink clicking unsuccesful", e.getLocalizedMessage(), e);
		 if(endRun)
             RC_Global.endTestRun(driver);
		}
	}
	
	public static void dropDownListBox(WebDriver driver, boolean endRun) throws Exception {
		RC_Global.createNode(driver, "Drop Down List");
		try {
			List<WebElement> gridrowcnt= driver.findElements(By.xpath("//standard-grid//div[2]//div[1]//div[8]//input"));
			
			for(int i=1; i<=gridrowcnt.size();i++) {
				WebElement row = driver.findElement(By.xpath("(//standard-grid//div[2]//div[1]//div[8]//input)["+i+"]"));
				if(gridrowcnt.size()>0) {
						 
					driver.findElement(By.xpath("//standard-grid//div[2]//div[1]//div[8]//input")).click();
					 queryObjects.logStatus(driver, Status.PASS, "Row Contains a Dropdown:"," List Box" , null);
				}
			}
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Drop Down list is not Displayed", e.getLocalizedMessage(), e);
			  																																																											 
			 if(endRun)
	              RC_Global.endTestRun(driver);
		}
	}
	
	public static void dropDownValuesSortedAlphabetically(WebDriver driver,boolean endRun) throws Exception {		   
		 
		RC_Global.createNode(driver, "Drop Down List Segment Sorted Alphabetically");
		try {
			driver.findElement(By.xpath("//standard-grid//div[2]//div[1]//div[8]//input")).clear();
			driver.findElement(By.xpath("(//standard-grid//div[2]//div[1]//div[8]//input)[1]")).click();
	        ArrayList<String> obtainedList = new ArrayList<>();
	        List<WebElement> element= driver.findElements(By.xpath("//standard-grid//div[2]//div[1]//div[8]//input//..//a"));
	        for(WebElement we:element) {
	        	 obtainedList.add(we.getText());
	        	 ArrayList<String> sortedList = new ArrayList<>();   
	        	 for(String s:obtainedList){
	        	 sortedList.add(s);
	        	 
	        	 }
	        	 Collections.sort(sortedList);
	        	 if (sortedList.equals(obtainedList)) {
			 }
	        	 queryObjects.logStatus(driver, Status.PASS, "Segment Drop Down list is Sorted Alphabetically",""+obtainedList , null);
	        }
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Segment Drop Down list is not Sorted Alphabetically", e.getLocalizedMessage(), e);
		}						  
			 if(endRun)																   
	              RC_Global.endTestRun(driver);																																 
						  
	}
	
	public static void validateCascadeSegment (WebDriver driver, String eleName, boolean endRun)throws Exception {
		RC_Global.createNode(driver, "Cascade segment assignment");
        try{
        	driver.findElement(By.xpath("(//label[text()='Make']/following-sibling::input)[1]")).sendKeys("Volvo");
        	driver.findElement(By.xpath("(//button[text()='Search'])[1]")).click();
        	Thread.sleep(3000);
         String Make= driver.findElement(By.xpath("(//standard-grid//div[2]//div[1]//div//div[2]/div)[1]")).getText();
         String Model= driver.findElement(By.xpath("(//standard-grid//div[2]//div[1]//div//div[3]/div)[1]")).getText();
         String Trim= driver.findElement(By.xpath("(//standard-grid//div[2]//div[1]//div//div[4]/div)[1]")).getText();
         List<WebElement> gridrowcnt= driver.findElements(By.xpath("//standard-grid/div/div/div/div/div[1]/div[2]/div/div"));
       for(int i=2; i<=gridrowcnt.size();i++) {
           String MakeC = driver.findElement(By.xpath("(//standard-grid//div[2]//div[1]//div//div[2]/div)["+i+"]")).getText();
           String ModelC = driver.findElement(By.xpath("(//standard-grid//div[2]//div[1]//div//div[3]/div)["+i+"]")).getText();
           String TrimC = driver.findElement(By.xpath("(//standard-grid//div[2]//div[1]//div//div[4]/div)["+i+"]")).getText();
      
           if(Make.equals(MakeC) &&Model.equals(ModelC) && Trim.equals(TrimC) )
           {
        	driver.findElement(By.xpath("//standard-grid//div[2]//div[1]//div[8]//input")).clear();
   			driver.findElement(By.xpath("(//standard-grid//div[2]//div[1]//div[8]//input)[1]")).click();
            RC_Global.clickUsingXpath(driver, "//standard-grid//div[2]//div[1]//div[8]//input//..//a[text()='"+eleName+"']", eleName, false,false);
              queryObjects.logStatus(driver, Status.PASS, "Cascade segment assignment: ","segment selected from dropdown", null);
              break;
           }
           }        
        }        
        catch(Exception e) {
            queryObjects.logStatus(driver, Status.FAIL, "segment is not selected from dropdown", e.getLocalizedMessage(), e);
            if(endRun)
                RC_Global.endTestRun(driver);    
     }
    }
	
	public static void segmentValidation (WebDriver driver, String Segment,boolean endRun)throws Exception {
        WebDriverWait wait = new WebDriverWait(driver,60);
       try{
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//vehicle-segment-mapping-rules//standard-grid//div[4]/div/input")));
              List<WebElement> gridrowcnt= driver.findElements(By.xpath("//vehicle-segment-mapping-rules//standard-grid//div[4]/div/input"));
        for(int i=1; i<=gridrowcnt.size();i++) {
            WebElement row = driver.findElement(By.xpath("(//vehicle-segment-mapping-rules//standard-grid//div[4]/div/input)["+i+"]"));
          String sub = row.getText();
            if(sub.equals(Segment))
            {
                queryObjects.logStatus(driver, Status.INFO, "Merchants segment values displayed in Mapping Rules-Merchants Segment column:", Segment, null);
            }break;
            }       
          }       
          catch(Exception e) {
             queryObjects.logStatus(driver, Status.WARNING, "Merchants segment values not displayed in Mapping Rules-Merchants Segment column", e.getLocalizedMessage(), e);
             if(endRun)
                      RC_Global.endTestRun(driver);    
          }
	}
      
	
	public static String[] getData_AreaReference(AreaReference areaRefer, XSSFSheet xlssh) {
        
        DataFormatter dataFormatter = new DataFormatter();
        XSSFWorkbook wbk = xlssh.getWorkbook();
        CellReference[] cellRefer = areaRefer.getAllReferencedCells();
        String[] listValues = new String[cellRefer.length];
        
        for (int i = 0 ; i < cellRefer.length; i++) {
               CellReference cellReference = cellRefer[i];
               if (cellReference.getSheetName() == null) {
                     listValues[i] = dataFormatter.formatCellValue(xlssh.getRow(cellReference.getRow()).getCell(cellReference.getCol()));
               } else {
                     listValues[i] = dataFormatter.formatCellValue(wbk.getSheet(cellReference.getSheetName()).getRow(cellReference.getRow()).getCell(cellReference.getCol()));
               }
        }
        
        return listValues;
	}
	
	public static void updateDriverName_DriverDetails(WebDriver driver, String DriverNameChange,String vhclAddressChange,String applyAddressToVehicle,boolean endRun) throws Exception{
		//String DriverNameChange="";
	 RC_Global.createNode(driver, "Update Driver Name_Driver Details");
		JavascriptExecutor executor = (JavascriptExecutor) driver;
	try {
    
     if(DriverNameChange.equalsIgnoreCase("Yes")) {
      
     RC_Global.clickUsingXpath(driver,"//button[@id='driverSearch']", "Driver Search button", endRun,false);
     RC_Global.waitElementVisible(driver, 30, "//h3[text()='Select Driver']", "Select Driver pop up", endRun,false);
     RC_Global.clickUsingXpath(driver,"(//button[@id='driver-change-search'])[1]", "Driver Change Search button", endRun,false);
     Thread.sleep(3000);
     RC_Global.waitElementVisible(driver, 60, "//table//tbody//tr[1]", "Driver Names List", endRun,false);
     List<WebElement> selectdriver= driver.findElements(By.xpath("//table//tbody//tr"));
     drivername = driver.findElement(By.xpath("//input[@name='driverFullName']")).getAttribute("value");
     for(int i=1; i<=selectdriver.size(); i++) {
     List<WebElement> fullname= driver.findElements(By.xpath("//td[contains(@ng-if,'FullName')]"));
     executor.executeScript("document.body.style.zoom = '30%'");
     Thread.sleep(2000);
     executor.executeScript("document.body.style.zoom = '100%'");
     if(!(driver.findElement(By.xpath("(//td[contains(@ng-if,'FullName')])["+i+"]")).getText()).equalsIgnoreCase(drivername)) {
    	 driver.findElement(By.xpath("(//td[contains(@ng-if,'FullName')])["+i+"]")).click(); 
         Thread.sleep(3000);
     if(!applyAddressToVehicle.equalsIgnoreCase("")) {
         WebElement element = driver.findElement(By.xpath("//h3[1][text()='Driver Information']"));
         
         String driverState = driver.findElement(By.xpath("(//select[contains(@ng-options,'state.AddressStateCode')])[2]/option[@selected='selected']")).getText();
         String VehicleState = driver.findElement(By.xpath("(//select[contains(@ng-options,'state.AddressStateCode')])[3]//option[@selected='selected' and @label]")).getText();
         
         executor.executeScript("arguments[0].scrollIntoView();", element);
             
          RC_Global.clickUsingXpath(driver, "//a[normalize-space(text())='Apply Address To Vehicle']", "Apply Address to Vehicle link", endRun,false);
         executor.executeScript("document.body.style.zoom = '30%'");
         Thread.sleep(2000);
         executor.executeScript("document.body.style.zoom = '100%'");
         Thread.sleep(2000);
         RC_Global.waitElementVisible(driver, 30, "//input[@name='driverFullName']", "Driver Full Name", endRun,false);
        if(!driverState.equalsIgnoreCase(VehicleState)) {
         if(applyAddressToVehicle.equalsIgnoreCase("Yes")){
             RC_Global.clickUsingXpath(driver, "(//button[normalize-space(text())='Yes'])[1]", "Yes button", endRun,false);
             WebElement odometer = driver.findElement(By.xpath("(//div[label[text()='Odometer']]/input)[1]"));
             RC_Global.enterInput(driver, "1000", odometer, endRun,false);
         }
         else if(applyAddressToVehicle.equalsIgnoreCase("No"))
             RC_Global.clickUsingXpath(driver, "(//button[normalize-space(text())='No'])[1]", "No button", endRun,false);
         try {
        	driver.findElement(By.xpath("(//select[@name='odometerReasonDropdown'])[1]")).click();
 			driver.findElement(By.xpath("(//select[@name='odometerReasonDropdown'])[1]/option[text()='Temporary']")).click();
        	 //RC_Global.selectDropdownOption(driver, "Reason", "Temporary", true);
		} catch (Exception e) {}
         	
         }
     }
     break;
     }
     }
     if(vhclAddressChange.equalsIgnoreCase("Yes")){
     	String Address = driver.findElement(By.xpath("//input[@ng-required='GaragingLocation' and @placeholder='Address 1']")).getText();
     	String inputAddress = "203 4th Ave W";
     	String Address1 = "260 Shell Rd";
     	WebElement element = driver.findElement(By.xpath("//input[@ng-required='GaragingLocation' and @placeholder='Address 1']"));
     	if(!(inputAddress.equals(Address))) {
			
			RC_Global.enterInput(driver, inputAddress, element, false,false);
			queryObjects.logStatus(driver, Status.PASS, "Updated Driver address", inputAddress,null);
     	}
     	else if (!(Address1.equals(Address))) {
     		
     	RC_Global.enterInput(driver, Address1, element, false,false);
     	 queryObjects.logStatus(driver, Status.PASS, "Updated Driver address", inputAddress,null);
     	}
     	else
     		queryObjects.logStatus(driver, Status.FAIL, "Not Updated Driver address", "",null);
     }
     	
//          
//	     DriverAddress = driver.findElement(By.xpath("//input[@name='residentialAddress1Text']")).getAttribute("value");
     	try {
     		Select select = new Select(driver.findElement(By.xpath("//label[text()='Owner']/..//select[@ng-model='data.clientDataValue.FieldValueText']")));
			select.selectByIndex(3);
     	} catch (Exception e) {}
     	try {
     		Select select = new Select(driver.findElement(By.xpath("//label[text()='Region']/..//select")));
			select.selectByIndex(3);
     	} catch (Exception e) {}
     	try {
     		Select select = new Select(driver.findElement(By.xpath("//label[text()='store number']/..//select")));
			select.selectByIndex(3);
     	} catch (Exception e) {}
     	try {
     		driver.findElement(By.xpath("//label[text()='Truck Number']/..//input")).sendKeys(RandomStringUtils.randomNumeric(3));
     	} catch (Exception e) {}
     	
     	Thread.sleep(2000);
	     driver.findElement(By.xpath("//button[contains(@id,'topDriverSaveButton')]")).click();
	     Thread.sleep(5000);
	     if(driver.findElements(By.xpath("//div[@data-ng-repeat='errorMessage in errorList | limitTo:5' and @ng-show='topSave']//h4")).size()>0) {
	     String errorMsg =     driver.findElement(By.xpath("//div[@data-ng-repeat='errorMessage in errorList | limitTo:5' and @ng-show='topSave']//h4")).getText();
	     Thread.sleep(2000);
	     RC_Global.verifyDisplayedMessage(driver, errorMsg, endRun);
	     String[] mssg = errorMsg.split(" ");
	     WebElement button = driver.findElement(By.xpath("//button[contains(@id,'topDriverSaveButton')]"));
	     if(!button.isEnabled() || button.isEnabled()) {
	    	 try {
	    		 driver.findElement(By.xpath("//label[text()='"+mssg[0]+"']/following::div[2]//input")).sendKeys("abc");
			} catch (Exception e) {}
	    	
	    	 try {
	    		 driver.findElement(By.xpath("//label[text()='Date']/..//input[@required='required']")).sendKeys(RC_Manage.AddDateStr(0, "MM/dd/yyyy", "", null, ""));
			} catch (Exception e) {}
	     Thread.sleep(1000);
	     RC_Global.clickUsingXpath(driver,"//button[contains(@id,'topDriverSaveButton')]","Top Save button", endRun,false);
	     Thread.sleep(5000);
	     }
	   }
	     Thread.sleep(5000);
	      if((driver.findElements(By.xpath("//span[text()=' address entered.']")).size()>0) || driver.findElements(By.xpath("//span[text()='Invalid vehicle address entered.']")).size()>0){
	    	  RC_Global.clickButton(driver, "Save As Entered", endRun,false);
	             Thread.sleep(5000);
	         }
	      if(driver.findElement(By.xpath("(//button[text()=' Save '])[1]")).getAttribute("class").contains("ng-hide")) {
				RC_Manage.waitUntilMethods(driver, "(//button[text()=' Save '])[2]/div[@ng-show='isSaving']","class","ng-hide", "attribute visible");
			} else {
	        	if(driver.findElement(By.xpath("(//button[text()=' Save '])[2]")).getAttribute("class").contains("ng-hide")){
					RC_Manage.waitUntilMethods(driver, "(//button[text()=' Save '])[1]/div[@ng-show='isSaving']","class","ng-hide", "attribute visible"); }
			}
	      //drivername = driver.findElement(By.xpath("//input[@name='driverFullName']")).getAttribute("value");
	      drivernameUpdated = driver.findElement(By.xpath("//input[@name='driverFullName']")).getAttribute("value");
	      DriverAddress = driver.findElement(By.xpath("//input[@name='residentialAddress1Text']")).getAttribute("value");
	      VehicleAddress = driver.findElement(By.xpath("//input[@name='vehicleAddressLine1']")).getAttribute("value");
	     Thread.sleep(2000);
	     RC_Global.waitElementVisible(driver, 60, "//div[@id='driver-change-top-success']//h4[text()='Update Successful']", "Update Successful message", endRun,false);
	     //queryObjects.logStatus(driver, Status.PASS, "Driver Name change is"," Successful with updated "+drivername+","+DriverAddress+" ", null);
	     queryObjects.logStatus(driver, Status.PASS, "Driver Name change is"," Successful with updated "+drivernameUpdated+","+DriverAddress+" ", null);
	     }}
	catch (Exception e) {
	         queryObjects.logStatus(driver, Status.FAIL, "Driver Name change Failed", e.getLocalizedMessage(), e);
	         if(endRun)
	              RC_Global.endTestRun(driver);
	 }
	     
	}	

	public static void checkBoxValidation(WebDriver driver,String CheckboxLabel,boolean endRun) throws Exception{
	      try {
	    	  String[] LabelName = CheckboxLabel.split(";");
	    	  for(int i=0; i< LabelName.length; i++) {
	       WebElement checkbox = driver.findElement(By.xpath("//label[text()='"+LabelName[i]+"']"));
	       boolean isSelected = checkbox.isSelected();
	       if(!isSelected)
	       queryObjects.logStatus(driver, Status.PASS,"The checkbox selection state is - " + checkbox.isSelected(), null, null);
	       else if (checkbox.isSelected())
	       queryObjects.logStatus(driver, Status.FAIL,"The checkbox not selection state is - " + checkbox.isSelected(), null, null);
	      }
	      }
	      catch(Exception e) {
	         queryObjects.logStatus(driver, Status.FAIL, "Unable to validate the checkbox----> The checkbox selection state is not found",e.getLocalizedMessage() , e);
	         if(endRun)
	              RC_Global.endTestRun(driver);    
	      }
	   }

	public static String[] getDataValidationListValues(XSSFSheet xlsh, XSSFCell cell) {
        List<? extends DataValidation> dataValidations = xlsh.getDataValidations();
   
        for (DataValidation dataValidation : dataValidations) {
               CellRangeAddressList addressList = dataValidation.getRegions();
               CellRangeAddress[] addresses = addressList.getCellRangeAddresses();
    
               for (CellRangeAddress addr : addresses) {
                     if (addr.isInRange(cell)) {
                            DataValidationConstraint constraint = dataValidation.getValidationConstraint();
      
                            if (constraint.getValidationType() == DataValidationConstraint.ValidationType.LIST) {
                                   String[] explicitListValues = constraint.getExplicitListValues();
                                   
                                   if (explicitListValues != null) return explicitListValues; 
                                   String formula1 = constraint.getFormula1();
                                   Workbook workbook = xlsh.getWorkbook();
                                   AreaReference areaReference = null;

                                   try {
                                         areaReference = new AreaReference(formula1, (workbook instanceof XSSFWorkbook)?SpreadsheetVersion.EXCEL2007:SpreadsheetVersion.EXCEL97);
                                         String[] listValues = getData_AreaReference(areaReference, xlsh);
                                         return listValues;
                                  } catch (Exception ex) {}

                                  List<? extends Name> names = workbook.getNames(formula1);
                                  for (Name name : names) {
                                         String refersToFormula = name.getRefersToFormula();
                                         areaReference = new AreaReference(refersToFormula,(workbook instanceof XSSFWorkbook)?SpreadsheetVersion.EXCEL2007:SpreadsheetVersion.EXCEL97);
                                         String[] listValues = getData_AreaReference(areaReference, xlsh);
                                         return listValues;
                                  } 
                            }  
                     	}
               } 
        }
        return new String[]{};
	}
	
	public static String modifyCells_MandatoryColumns(WebDriver driver, String filePath, String selCol, int delSize, String UnitNos, String act) throws Exception {
		
		String colorSel = ""; String unitNums = ""; String getData = ""; String currentVal = ""; String oldData = ""; String newData = "";
		String getCols = ""; String multiRows_old = ""; String multiRows_new = "";
		ArrayList<Integer> endLoop = new ArrayList<Integer>();
		RC_Global.createNode(driver, act+ "few column values in Downloaded Excel file");
		List<Integer> rowChange = null;
		if (selCol.equalsIgnoreCase("red")) {
			colorSel = "ffc00000";
		} else if (selCol.equalsIgnoreCase("blue")) {
			colorSel = "FF00B0F0";
		} else if (selCol.equalsIgnoreCase("grey")) {
			colorSel = "FF454546";
		}
        try {
               FileInputStream fis = new FileInputStream(filePath);
               XSSFWorkbook wb = new XSSFWorkbook(fis);
               XSSFSheet sh = wb.getSheetAt(1);
               int rows = sh.getLastRowNum();
               int cols= sh.getRow(2).getLastCellNum();  
               rowChange = RandomNumbers(driver, 5, rows, delSize+10);
               for (int j : rowChange) {
            	   for (int i = 3; i < cols; i++) {
	            	   XSSFCellStyle cs = sh.getRow(4).getCell(i).getCellStyle();
	                   XSSFColor color = cs.getFillForegroundColorColor();
	                   if (color.getARGBHex().equalsIgnoreCase(colorSel)) {
                                 XSSFCell ccell = sh.getRow(j).getCell(i);
                                 currentVal = ""; getData = "";
                                 try {
                                	 if (!(sh.getRow(j).getCell(4).getStringCellValue().isEmpty() || sh.getRow(j).getCell(4).getStringCellValue()==null)) {//updated
                                		 if (!(UnitNos.contains(sh.getRow(j).getCell(2).getStringCellValue()))) {
                                 	 		if (!(ccell.getStringCellValue().isEmpty()) || act.equalsIgnoreCase("Update")) {
                                 	 			if (getCols=="") {
                                 	 				getCols = sh.getRow(2).getCell(2).getStringCellValue()+";"+sh.getRow(2).getCell(i).getStringCellValue();
 												} else if (getCols.contains(sh.getRow(2).getCell(i).getStringCellValue())) {
 													//do nothing
 												} else {
 													getCols = getCols+";"+sh.getRow(2).getCell(i).getStringCellValue();
 												}
                                 	 			currentVal = ccell.getStringCellValue();
                                             	if (act.equalsIgnoreCase("Update")) {//Update
                                             		String[] ListValues = getDataValidationListValues(sh, ccell);
                                             		if (ListValues.length>1) {
                                             			if (ListValues.length==2) {
                                             				ccell.setCellValue(ListValues[1]);
 														} else {
 															ccell.setCellValue(ListValues[ThreadLocalRandom.current().nextInt(1, ListValues.length-1)]);
 														}
                                             			getData = ccell.getStringCellValue();
                                 					} else {                                						
                                 						//////Get different value for the given column to change the current cell value/////////////
                                 						for (int k = 5; k < rows; k++) {
                                 							getData = "";
                                 							if (!(sh.getRow(k).getCell(i).getStringCellValue().isEmpty() || sh.getRow(k).getCell(i).getStringCellValue()==null)) {
 	                                							if (!(sh.getRow(k).getCell(i).getStringCellValue().equalsIgnoreCase(currentVal))) {
 	    															getData = sh.getRow(k).getCell(i).getStringCellValue();
 	    															break;
 	    														}
                                 							}
     													}
                                 						if (getData=="" || getData.isEmpty()) {
                                 							getData = RandomStringUtils.random(4, true, false);
     													}
                                 						ccell.setCellValue(getData);
                                 					}
     											} else {//Delete the values
     												ccell.setCellValue("");
     												getData = " ";
     											}
                                             	endLoop.add(1);
                                             	unitNums = sh.getRow(j).getCell(2).getStringCellValue();
                                             	if (currentVal.isEmpty()) {
                                               		currentVal= " ";
                             					}
                                                 if (oldData=="") {                                             	   	
                                              	   	oldData = unitNums+";"+currentVal;
                                          	   		newData = unitNums+";"+getData;
     											} else {
     												oldData = oldData+";"+currentVal;
                                            	   		newData = newData+";"+getData;
     											}                                                
                                             }
 										}
                                	 }  
                                 } catch (Exception e1) {
                                	 queryObjects.logStatus(driver, Status.FAIL, "Mandatory column values update failed", e1.getLocalizedMessage(), e1);
                         	        RC_Global.endTestRun(driver);
                                 }
                          }
                   }
                   if (oldData.contains(";")) {
                	   if (multiRows_new!="") {
                      		multiRows_old = multiRows_old+"__"+oldData;
                      		multiRows_new = multiRows_new+"__"+newData;
       	   				} else {
       	   					multiRows_old = oldData;
       	   					multiRows_new = newData;
       	   				}
                   }                   
                   oldData = ""; newData="";
                   if (endLoop.size()==delSize) {
                  	 break;									
                   }
               }
               fis.close();
               FileOutputStream fos = new FileOutputStream(filePath);
               wb.write(fos);
               wb.close();
               fos.close();
        } catch (Exception e) {
        	queryObjects.logStatus(driver, Status.FAIL, "Mandatory column values update failed", e.getLocalizedMessage(), e);
	        RC_Global.endTestRun(driver);
        }
		return getCols+"~~"+multiRows_old+"~~"+multiRows_new;	        
	}
		
	public static String modifyCells_ColumnName(WebDriver driver, String filePath, String ColName, int delSize, String UnitNos, String act) throws Exception {
		RC_Global.createNode(driver, "Modify few values in the "+ColName+" Column");
		int colNo = 0; String unitNums = ""; String getData = ""; String currentVal = ""; String oldData = ""; String newData = ""; String getCols = "";
		RC_Global.createNode(driver, act+ "few "+ColName+" column values in Downloaded Excel file");
		String tempColNm = "";
		List<Integer> rowChange = null;
		ArrayList<Integer> endLoop = new ArrayList<Integer>();
        try {
               FileInputStream fis = new FileInputStream(filePath);
               XSSFWorkbook wb = new XSSFWorkbook(fis);
               XSSFSheet sh = wb.getSheetAt(1);
               int rows = sh.getLastRowNum();
               int cols= sh.getRow(2).getLastCellNum();
               rowChange = RandomNumbers(driver, 5, rows, delSize+10);
               for (int i = 0; i < cols; i++) {
            	   tempColNm = sh.getRow(2).getCell(i).getStringCellValue();
            	  if (tempColNm.contains("-")) {
            		  if (tempColNm.substring(tempColNm.indexOf("-")+1).equalsIgnoreCase(ColName)) {
            			  colNo = i;
            			  break;
            		  }            		  
            	  } else if (tempColNm.equalsIgnoreCase(ColName)) {
            		  colNo = i;
            		  break;
            	  }
               }               
               for (int j : rowChange) {
                   XSSFCell ccell = sh.getRow(j).getCell(colNo);
                   try {
                	   currentVal = "" ; getData = "";
                	   if (!(sh.getRow(j).getCell(4).getStringCellValue().isEmpty() || sh.getRow(j).getCell(4).getStringCellValue()==null)) {//updated
                		   if (!(UnitNos.contains(sh.getRow(j).getCell(2).getStringCellValue()))) {
                               if ((!ccell.getStringCellValue().isEmpty() || act.equalsIgnoreCase("Update")) && (!ccell.getStringCellValue().toLowerCase().contains("default"))) {
                             	  currentVal = ccell.getStringCellValue();
                             	  if (getCols=="") {
                   	 				getCols = sh.getRow(2).getCell(2).getStringCellValue()+";"+sh.getRow(2).getCell(colNo).getStringCellValue();
               					} else {
               						getCols = getCols+";"+sh.getRow(2).getCell(colNo).getStringCellValue();
               					}
                               	if (act.equalsIgnoreCase("Update")) {//Update
                               		String[] ListValues = getDataValidationListValues(sh, ccell);
                               		if (ListValues.length>1) {
                               			if (ListValues.length==2) {
                             				ccell.setCellValue(ListValues[1]);
     									} else {
     										ccell.setCellValue(ListValues[ThreadLocalRandom.current().nextInt(1, ListValues.length-1)]);
     									}
                               			getData = ccell.getStringCellValue();
                   					} else {
                   						//////Get different value for the given column to change the current cell value/////////////
                   						for (int k = 5; k < rows; k++) {
                   							getData = "";
                   							if (!(sh.getRow(k).getCell(colNo).getStringCellValue().isEmpty() || sh.getRow(k).getCell(colNo).getStringCellValue()==null)) {
                   								if (!(sh.getRow(k).getCell(colNo).getStringCellValue().equalsIgnoreCase(currentVal))) {
     												getData = sh.getRow(k).getCell(colNo).getStringCellValue();
     												break;
     											}														
     										}
     									}
                   							
                   						if (getData==""|| getData.isEmpty()) {
                   							getData = RandomStringUtils.random(4, true, false);
     									}
                   						ccell.setCellValue(getData);
                   						getData = ccell.getStringCellValue();
                   					}
     							} else {//Delete the values
     								ccell.setCellValue("");
     								getData = " ";
     							}
                               	endLoop.add(1);
                               	unitNums = sh.getRow(j).getCell(2).getStringCellValue();
                               	if (currentVal.isEmpty()) {
                               		currentVal= " ";
             					}
                               	if (oldData=="") {                       	   		
                            	   		oldData = unitNums+";"+currentVal;
                            	   		newData = unitNums+";"+getData;
     							} else {
     								oldData = oldData+"__"+unitNums+";"+currentVal;
                            	   		newData = newData+"__"+unitNums+";"+getData;
     							} 
                               }
                     	   }
                	   }
                   } catch (Exception e1) {
                          System.out.println(e1);
                   }
                   if (endLoop.size()==delSize) {
                    	 break;									
                     }
            }

               fis.close();
               FileOutputStream fos = new FileOutputStream(filePath);
               wb.write(fos);
               wb.close();
               fos.close();
        } catch (Exception e) {
        	queryObjects.logStatus(driver, Status.FAIL, ColName+" values update failed", e.getLocalizedMessage(), e);
	        RC_Global.endTestRun(driver);
        }
		return getCols+"~~"+oldData+"~~"+newData;	        
	}
	
	public static String updateSelectedRows(WebDriver driver, String filePath, String fileName, int size) throws Exception {
		RC_Global.createNode(driver, "Update few row values for all the Columns");
		String rowVals = ""; String multiRows = ""; String tempVar = "";
		String rowVals_new = ""; String multiRows_new = ""; String unitNums = "";
		String currentVal = ""; String getData = ""; String getCols="";
		try {
			ArrayList<Integer> endLoop = new ArrayList<Integer>();
			List<Integer> rowsChange = null;
			ArrayList<Integer> rowsChange2 = new ArrayList<Integer>();
            FileInputStream fis = new FileInputStream(filePath);
            XSSFWorkbook wb = new XSSFWorkbook(fis);
            XSSFSheet sh = wb.getSheetAt(1);
            int rows = sh.getLastRowNum();
            int cols= sh.getRow(2).getLastCellNum();
            rowsChange = RandomNumbers(driver, 5, rows, size+20);
            
            //Get the values from excel
            for (int j : rowsChange) {
            	if (!(sh.getRow(j).getCell(4).getStringCellValue().isEmpty() || sh.getRow(j).getCell(4).getStringCellValue()==null)) {
	            	for (int i = 2; i < cols; i++) {
	            		try {
	            			tempVar = sh.getRow(j).getCell(i).getStringCellValue();
						} catch (Exception e) {
							tempVar = "";
						}
	            		if (tempVar.isEmpty()) {
	            			tempVar= " ";
						}          		
	            		if (rowVals!="") {
	            			rowVals = rowVals+";"+tempVar;
						} else {
							rowVals = tempVar;
						}
	                }
	            	if (multiRows!="") {
	            		multiRows = multiRows+"__"+rowVals;
					} else {
						multiRows = rowVals;
					}
	            	rowVals = "";
	            	endLoop.add(1);
	            	rowsChange2.add(j);
            	}
            	if (endLoop.size()==size) {
               	 break;									
                }
			}
            
            ///Update the rows
            for (int j : rowsChange2) {
            	for (int i = 3; i < cols; i++) {            		
            		if (getCols=="") {
    	 				getCols = sh.getRow(2).getCell(2).getStringCellValue()+";"+sh.getRow(2).getCell(i).getStringCellValue();
					} else if (getCols.contains(sh.getRow(2).getCell(i).getStringCellValue())) {
						//do nothing
					} else {
						getCols = getCols+";"+sh.getRow(2).getCell(i).getStringCellValue();
					}
            		XSSFCell cCell = sh.getRow(j).getCell(i);            		
            		String[] ListValues = getDataValidationListValues(sh, cCell);
            		if (ListValues.length>1) {
            			if (ListValues.length==2) {
            				cCell.setCellValue(ListValues[1]);
						} else {
							cCell.setCellValue(ListValues[ThreadLocalRandom.current().nextInt(1, ListValues.length-1)]);
						}
            			getData = cCell.getStringCellValue();
					} else {
						currentVal = cCell.getStringCellValue();
						//////Get different value for the given column to change the current cell value/////////////
						for (int k = 5; k < rows; k++) {
							getData = "";
							if (!(sh.getRow(k).getCell(i).getStringCellValue().isEmpty() || sh.getRow(k).getCell(i).getStringCellValue()==null)) {
								if (!(sh.getRow(k).getCell(i).getStringCellValue().equalsIgnoreCase(currentVal))) {
									getData = sh.getRow(k).getCell(i).getStringCellValue();
									break;
								}
							}
						}
						if (getData=="" || getData.isEmpty()) {
							getData = RandomStringUtils.random(4, true, false);
						}
						cCell.setCellValue(getData);
					}//
            		unitNums = sh.getRow(j).getCell(2).getStringCellValue();
            		if (rowVals_new!="") {
            			rowVals_new = rowVals_new+";"+getData;
					} else {
						rowVals_new = unitNums+";"+getData;
					}            	
                }
            	if (rowVals_new.contains(";")) {
	            	if (multiRows_new!="") {
	            		multiRows_new = multiRows_new+"__"+rowVals_new;
					} else {
						multiRows_new = rowVals_new;
					}
            	rowVals_new = "";
            	}
			} 
            fis.close();
            FileOutputStream fos = new FileOutputStream(filePath);
            wb.write(fos);
            wb.close();
            fos.close();
            if (!multiRows.isEmpty() && !multiRows_new.isEmpty()) {
				queryObjects.logStatus(driver, Status.PASS, "Update few rows for the selected Unit Numbers", "Rows values are updated ", null);
			} else {
				queryObjects.logStatus(driver, Status.FAIL, "Update few rows for the selected Unit Numbers", "Update Rows failed", null);
			}
     } catch (Exception e) {
    	 queryObjects.logStatus(driver, Status.FAIL, "Rows values update failed", e.getLocalizedMessage(), e);
	     RC_Global.endTestRun(driver);
     }
	return getCols+"~~"+multiRows+"~~"+multiRows_new;
	        
	 }
	
	public static void validateColumnNames(WebDriver driver, String filePath, String fileName, String columns) throws Exception {
		try {
			RC_Global.createNode(driver, "Validate the columns display in the application with Downloaded Excel");
			String colArr[] = columns.split(";"); String colNA = ""; String xlColumns = ""; String colName = "";
            FileInputStream fis = new FileInputStream(filePath);
            XSSFWorkbook wb = new XSSFWorkbook(fis);
            XSSFSheet sh = wb.getSheetAt(1);
            int cols= sh.getRow(2).getLastCellNum();
            for (int j = 0; j < colArr.length; j++) {
            	for (int i = 0; i < cols; i++) {
            		colName = "";
                	XSSFCell ccell = sh.getRow(2).getCell(i);
                    try {
                           if (!ccell.getStringCellValue().isEmpty()) {
                        	   colName = ccell.getStringCellValue();
                        	   if (colName.contains("-")) {
                        		   colName = colName.substring(colName.indexOf("-")+1);								
                        	   }
                        	   if (colArr[j].contains(colName)) {
                    			   if (xlColumns=="") {
                    				   xlColumns = colName;								
    								} else {
    									xlColumns = xlColumns+";"+colName;
    								}                        			   
                        		   break;								
                        	   } else if (i==(cols-1)) {
                        		   if (colNA=="") {
                        			   colNA = colArr[j];								
    								} else {
    									colNA = colNA+";"+colArr[j];
    								}                        		    
                        	   }
                           }
                    } catch (Exception e1) {}
                }
			}
            fis.close();
            if (colNA.isEmpty()) {
				queryObjects.logStatus(driver, Status.PASS, "Columns availability in Excels", "All the given columns are available in the "+fileName+"\n"+" Columns Validated are - "+xlColumns, null);
			} else {
				queryObjects.logStatus(driver, Status.FAIL, "Columns availability in Excels", "Few columns are not available in the "+fileName+"\n"+" Columns Names are - "+colNA, null);
			}
     } catch (Exception e) {
    	 queryObjects.logStatus(driver, Status.FAIL, "Column names validation failed", e.getLocalizedMessage(), e);
	     RC_Global.endTestRun(driver);
     }
	        
	}
	
	public static String fillBlankCellValues(WebDriver driver, String filePath, String selCol) throws Exception {
	//public static void fillBlankCellValues(WebDriver driver, String filePath, String selCol, String selCase) throws Exception {
		RC_Global.createNode(driver, "Fill all the blank cell values in the Mandatory Columns");
		String colorSel = ""; String unitNums = ""; String getData = "";String multiRows_new = ""; String newData = "";
		if (selCol.equalsIgnoreCase("red")) {
			colorSel = "ffc00000";
		} else if (selCol.equalsIgnoreCase("blue")) {
			colorSel = "FF00B0F0";
		}//FF454546 - grey
        try {
               FileInputStream fis = new FileInputStream(filePath);
               XSSFWorkbook wb = new XSSFWorkbook(fis);
               XSSFSheet sh = wb.getSheetAt(1);
               int rows = sh.getLastRowNum();
               int cols= sh.getRow(2).getLastCellNum();
               
               for (int i = 0; i < cols; i++) {
            	   XSSFCellStyle cs = sh.getRow(4).getCell(i).getCellStyle();
                   XSSFColor color = cs.getFillForegroundColorColor();
                   if (color.getARGBHex().equalsIgnoreCase(colorSel)) {
                	   
                          for (int j = 5; j < rows; j++) {
                                 XSSFCell ccell = sh.getRow(j).getCell(i);
                                 try {
                                        if (ccell.getStringCellValue().isEmpty()) {
                                               ccell = sh.getRow(j).createCell(i);
                                               String[] ListValues = getDataValidationListValues(sh, ccell);
                                               if (ListValues.length==2) {
                                            	   ccell.setCellValue(ListValues[1]);
	                       						} else {
	                       							ccell.setCellValue(ListValues[ThreadLocalRandom.current().nextInt(1, ListValues.length-1)]);
	                       						}
                                               
                                               getData = ccell.getStringCellValue();
                                               unitNums = sh.getRow(j).getCell(2).getStringCellValue();
                                               if (newData=="") {                                             	   	
	       					                	   	newData = getData;
	       										} else {
	       											newData = newData+";"+getData;
	       										}
                                        }
                                 } catch (Exception e1) {
                                	 queryObjects.logStatus(driver, Status.FAIL, "Unable to update few Mandatory cells ", e1.getLocalizedMessage(), e1);
                                 }                                               
                          }
                   }
                   if (newData.contains(";")) {
	                   if (multiRows_new!="") {
	                	   	multiRows_new = multiRows_new+"__"+unitNums+";"+newData;
			   			} else {
			   				multiRows_new = unitNums+";"+newData;
			   			}
		                newData="";
                   }
               }
               fis.close();
               FileOutputStream fos = new FileOutputStream(filePath);
               wb.write(fos);
               wb.close();
               fos.close();
        } catch (Exception e) {
        	queryObjects.logStatus(driver, Status.FAIL, "Mandatory cells update failed", e.getLocalizedMessage(), e);
   	     RC_Global.endTestRun(driver);
        }
		return unitNums;        
	}
 
	public static String moveFileFromDownloads(WebDriver driver, String fileName, String folderName, boolean stopRun) throws Exception {
		try {
			RC_Global.createNode(driver, "Move the File from Downloads to Project Directory");
			String Rand = RandomStringUtils.random(5, false, true);
			String curPath = ""; String DestDir = "";
			String newFileName = fileName.replace(".xlsx", "_1.xlsx");
			curPath = System.getProperty("user.home")+"\\Downloads\\"+fileName;
			DestDir = String.valueOf(String.valueOf(String.valueOf(System.getProperty("user.dir")))) + File.separator + folderName + File.separator + fileName.replace(".xlsx", "")+"_"+Rand;
			Path cur = Paths.get(curPath);
			Path newFile = Paths.get((DestDir+"\\"+newFileName));
			Thread.sleep(1000);
			File dir = new File(DestDir);
			if (!dir.exists()) {
				dir.mkdir();
	        }
			Thread.sleep(1000);
			File eFile = new File(curPath);		
			if (eFile.exists()) {
				Files.move(cur, newFile);
				eFile.delete();
			}
			Thread.sleep(1000);
			
			if (dir.exists()) {
				queryObjects.logStatus(driver, Status.PASS, "Move file from Downloads to Project Directory","File moved successfully to path - "+DestDir , null);
				return DestDir+";"+newFileName;
	        }			
		} 	catch (Exception e){
			queryObjects.logStatus(driver, Status.FAIL, "Move file from Downloads to Project Directory is not successful", e.getLocalizedMessage(), e);
			if(stopRun)
				RC_Global.endTestRun(driver);
			}
		return "";
		
	}
			
	public static void validateUploadChanges(WebDriver driver, String filePath, String unitNums, String msg) throws Exception {	
		String getResults= ""; String getReasons= ""; boolean isUnitNums = false; String curUnitNum = ""; String getUnitNo = "";
		String sptUnitNos[] = null;
		if (!unitNums.contains(";")) {
			unitNums = unitNums+";";
		}
		sptUnitNos = unitNums.split(";");
		RC_Global.createNode(driver, "Validate the status for the updated Unit Numbers in the Downloaded Results File");
		try {
            FileInputStream fis = new FileInputStream(filePath);
            XSSFWorkbook wb = new XSSFWorkbook(fis);
            XSSFSheet sh = wb.getSheetAt(1);
            int rows = sh.getLastRowNum();
            int cols= sh.getRow(2).getLastCellNum();
            for (int i = 0; i < sptUnitNos.length; i++) {
            	for (int j = 5; j < rows; j++) {
                    XSSFCell ccell = sh.getRow(j).getCell(2);
                    getUnitNo = ccell.getStringCellValue();
                    if (sptUnitNos[i].trim().equalsIgnoreCase(getUnitNo.trim())) {
                    	isUnitNums = false;
                    	getResults = sh.getRow(j).getCell(0).getStringCellValue();
                    	getReasons = sh.getRow(j).getCell(1).getStringCellValue();
                    	if (msg.equalsIgnoreCase("No changes")) {
                    		if (getResults.equalsIgnoreCase("No changes") && getReasons.contains("No action or update was requested")) {
                    			isUnitNums = true;
                    		}
    					} else if (getResults!= "No changes") {
                      	   if (!getReasons.contains("No action or update was requested")) {
                      		  isUnitNums = true;
                      	   }
                         }
                    	if (isUnitNums) {
                			  if (msg.equalsIgnoreCase(getResults)) {
                				  queryObjects.logStatus(driver, Status.PASS, "Verfiy '"+msg+"' is displayed in the result column for the unit number -"+getUnitNo , "Reason displayed -"+getReasons, null);								
    						} else {
    							queryObjects.logStatus(driver, Status.FAIL, "'"+getResults+"' message displayed in the result column for the unit number -"+getUnitNo+". Expected message is '"+msg+"'" , "Reason displayed -"+getReasons, null);
    						}
                		  }
                    	if (!isUnitNums) {
    						if (curUnitNum=="") {
    							curUnitNum = ccell.getStringCellValue();
    						} else {
    							curUnitNum = curUnitNum+";"+ccell.getStringCellValue();
    						}
    					}
                    	break;
    				}                
                }
			}
                      
            fis.close();
            FileOutputStream fos = new FileOutputStream(filePath);
            wb.write(fos);
            wb.close();
            fos.close();
            if (!curUnitNum.isEmpty()) {
				queryObjects.logStatus(driver, Status.FAIL, "Validate the Changes are captured in Results and Reasons columns", "Changes are not captured for some of the updated fields"+" Those Columns unit numbers are - "+curUnitNum+" and the reason is "+getReasons, null);
			}
	     } catch(TimeoutException te) {
	 		queryObjects.logStatus(driver, Status.FAIL, "Failed to Validate the Download Results file", te.getLocalizedMessage(), te);
	     }
	}
	
	public static void deleteFolder(WebDriver driver, String curDir) throws Exception {
		RC_Global.createNode(driver, "Delete the temporary folder from Project Directory");
		File delFile = new File(curDir);
		String[] allFiles = delFile.list();
		for(String del: allFiles){
		    File currentFile = new File(delFile.getPath(),del);
		    currentFile.delete();
		}
		delFile.delete();
		if (!delFile.exists()) {
			queryObjects.logStatus(driver, Status.PASS, "Delete the Folder","Temporary folder is deleted successfully", null);
		}
	}
	
	public static void deleteFile_Downloads(WebDriver driver, String fileName) throws Exception {
		RC_Global.createNode(driver, "Delete the downloaded excel from Downloads Directory");
		File curPath = new File(System.getProperty("user.home")+"\\Downloads");
		String[] getFiles = curPath.list();
		for(String del: getFiles){
			File cFile = new File(curPath.getPath(),del);
			if (cFile.getName().startsWith(fileName)) {
				cFile.delete();
			}			
		}		
	}
	
	public static void deleteAllFolder_Files(WebDriver driver) throws Exception {
		try {
			String fPaths[] = "MassDownload;DownloadedFiles".split(";");
			String folderPath = String.valueOf(String.valueOf(System.getProperty("user.dir")));
			for (int i = 0; i < fPaths.length; i++) {
				File delFile = new File(folderPath + File.separator+fPaths[i]);
				String[] allFiles = delFile.list();
				for(String del: allFiles){
					try {
						File delFile2 = new File(folderPath + File.separator +fPaths[i]+"\\"+del);
						String[] dirFiles = delFile2.list();
						for(String delete: dirFiles){
							File currentFile = new File(delFile2.getPath(),delete);
							currentFile.delete();
						}
						delFile2.delete();
					} catch (Exception e) {
						File currentFile = new File(delFile.getPath(),del);
						currentFile.delete();
						//delFile.delete();
					}
				}
			}
		} catch (Exception e) {}
		
	}
	
	public static void waitUntilDownloadingDisappears(WebDriver driver) {
		try {
			RC_Global.createNode(driver, "waitUntilDownloadingDisappears");
			waitUntilMethods(driver, "//div[contains(@class,'divprogressbar col')]","class","ng-hide", "attribute visible");
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	public static void waitUntilCustomerFocus(WebDriver driver) {
		try {
			waitUntilMethods(driver, "//li[@ng-show='loadingCustomerFocus']","class","ng-hide", "attribute visible");
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	
	public static void waitUntilMethods(WebDriver driver, String pObject, String attr, String val, String selAction) {
		WebDriverWait wait = new WebDriverWait(driver,90);
		try {
			if (selAction.contains("attribute")) {
				RC_Global.createNode(driver, "Wait until the attribute -"+attr+" value "+val+" is visible for the element '"+pObject);
			} else {
				RC_Global.createNode(driver, "Wait until element '"+pObject+"' is " +selAction);
			}
			
			switch(selAction) {
			case "visible":
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(pObject)));
				break;
			case "invisible":
				wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(pObject)));
				break;
			case "clickable":
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(pObject)));
				break;
			case "attribute visible" :
				wait.until(ExpectedConditions.attributeContains(By.xpath(pObject), attr, val));
				break;
				
			case "attribute available" :
				wait.until(ExpectedConditions.attributeToBeNotEmpty(driver.findElement(By.xpath(pObject)), attr));
				break;
			}
		} catch (Exception e) {}
				
	}

	
	public static void checkCustomerNumberDisplayInField(WebDriver driver, String custName) throws Exception {
		try {
			RC_Global.createNode(driver, "Verify Customer Number displayed in the Customer Number Field");
			if (driver.findElement(By.xpath("//div[@class='input-group']/input[@name='customerInput']")).getAttribute("value").equalsIgnoreCase(custName)) {
				queryObjects.logStatus(driver, Status.PASS, "Check the Customer Displayed in the field","Customer Number is displayed in the Customer name field", null);
			} else {
				queryObjects.logStatus(driver, Status.FAIL, "Check the Customer Displayed in the field", "Customer Number is not displayed in the Customer name field", null);
			}
			
		} catch (Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Customer number display validation failed", e.getLocalizedMessage(), e);
		    RC_Global.endTestRun(driver);
		}
	}
	
	public static void selectFromDropdown(WebDriver driver, String selValue, WebElement webElement) throws Exception {
		try {
			RC_Global.createNode(driver, "Select the "+selValue+ " from dropdown list");
			Thread.sleep(500);
			Select select = new Select(webElement);
			select.selectByVisibleText(selValue);
			RC_Global.createNode(driver, "Verify the "+selValue+ " is displayed as selected in dropdown list");
			if (select.getFirstSelectedOption().getText().equalsIgnoreCase(selValue)) {
			} else {
				queryObjects.logStatus(driver, Status.FAIL, "Check the value displayed in the field", selValue+" is not displayed in the field", null);
			}
			Thread.sleep(100);
		} catch (Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Selecting value from drop down failed", e.getLocalizedMessage(), e);
		    RC_Global.endTestRun(driver);
		}
	}
	
	public static void uploadFileWithRobot (WebDriver driver, String imagePath) throws AWTException, InterruptedException {
		
//		 String currentWindow = driver.getWindowHandle();
//	     driver.switchTo().window(currentWindow);
		Thread.sleep(5000);
		Keys.chord(Keys.CONTROL, "C");
		Keys.chord(Keys.CONTROL, "V");
		Keys.chord(Keys.CONTROL, "C");
		Keys.chord(Keys.CONTROL, "V");
		 StringSelection stringSelection = new StringSelection(imagePath);
	     Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
	     clipboard.setContents(stringSelection, null);
	     robotActions();
	     stringSelection = null;	     
	 }
	
	
	public static void robotActions() throws AWTException {
	   Robot robot = null;
	   robot = new Robot();
       robot.keyPress(KeyEvent.VK_DELETE);
       robot.keyRelease(KeyEvent.VK_DELETE);
       robot.keyPress(KeyEvent.VK_ENTER);
       robot.keyRelease(KeyEvent.VK_ENTER);
       robot.delay(3000);
       robot.keyPress(KeyEvent.VK_CONTROL);
       robot.keyPress(KeyEvent.VK_V);
       robot.delay(1500);
       robot.keyRelease(KeyEvent.VK_V);
       robot.keyRelease(KeyEvent.VK_CONTROL);
       robot.delay(1500);
       robot.keyPress(KeyEvent.VK_ENTER);
       robot.keyRelease(KeyEvent.VK_ENTER);
       
       //close in case of open window
       robot.delay(1000);
       robot.keyPress(KeyEvent.VK_ESCAPE);
       robot.keyRelease(KeyEvent.VK_ESCAPE);
     //close in case of open window
       robot.delay(1500);
       robot.keyPress(KeyEvent.VK_ESCAPE);
       robot.keyRelease(KeyEvent.VK_ESCAPE);
     //close in case of open window
       robot.delay(1500);
       robot.keyPress(KeyEvent.VK_ESCAPE);
       robot.keyRelease(KeyEvent.VK_ESCAPE);
	}
	
	public static final String AddDateStr(int addval, String Dateformat, String Datetype, Date DateVal, String timeZone) throws Exception {
		if (timeZone.isEmpty()) {
			timeZone = java.util.TimeZone.getDefault().getID();
		}
		TimeZone.setDefault(TimeZone.getTimeZone(timeZone));
		Calendar calendar = Calendar.getInstance();
		if (DateVal==null) {
			Date currentDate = new Date();			
			calendar.setTime(currentDate);
		} else {
			calendar.setTime(DateVal);
		}		
		if (Datetype.contains("day")) {
			int day = calendar.get(Calendar.DATE);
			calendar.set(Calendar.DATE, day + addval);
		}else if (Datetype.contains("hour")) {
			int hour = calendar.get(Calendar.HOUR_OF_DAY);
			calendar.set(Calendar.HOUR_OF_DAY, hour + addval);
		}else if (Datetype.contains("minute")) {
			int min = calendar.get(Calendar.MINUTE);
			calendar.set(Calendar.MINUTE, min + addval); 
		}else if (Datetype.contains("second")) {
			int sec = calendar.get(Calendar.SECOND);
			calendar.set(Calendar.SECOND, sec + addval);
		}else if (Datetype.contains("month")) {
			int mon = calendar.get(Calendar.MONTH);
			calendar.set(Calendar.MONTH, mon + addval);
		}	
		
		SimpleDateFormat DateFrmt = new SimpleDateFormat(Dateformat);
		return DateFrmt.format(calendar.getTime());
	}
	
	public static void driverSelection (WebDriver driver,boolean endRun) throws Exception{		   
        RC_Global.createNode(driver, "Driver Selection");
        String CustomerName="";
        String DriverNameChange="";
        String message = "Changing states requires entering an accurate valid odometer. Most states require you to update your address on file within 30 days. Do you want to process a state change with this request?";
        JavascriptExecutor executor = (JavascriptExecutor) driver;
        WebDriverWait wait = new WebDriverWait(driver,30);
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table//tbody//tr[1]")));
            List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("//table//tbody//tr"));  
            Thread.sleep(2000);
            int rowcnt=Getgridrowcnt.size();
            boolean firstpage=false;
            Thread.sleep(2000);
            for(int i=1; i<rowcnt;i++) {
                WebElement sub= driver.findElement(By.xpath("//tr["+i+"]//td[4]"));
                Thread.sleep(2000);
                String CVN = sub.getText();
                if(CVN.isEmpty()) {
                    WebElement driverclmn = driver.findElement(By.xpath("//tbody//tr["+i+"]//td[5]"));
                    Thread.sleep(2000);
                    drivername = driverclmn.getText();
                    Thread.sleep(1000);
                    if(!(drivername.equalsIgnoreCase("Unassigned") || drivername.contains("Pool")||drivername.contains("Unknown")||drivername.contains("Catering")) ) {
                    //    driver.findElement(By.xpath("//tbody//tr["+i+"]//td[5]")).click();
                    executor.executeScript("arguments[0].click();", driverclmn);
                    Thread.sleep(1000);
                    firstpage = false;
                    break;}
                  }  
                else if(!CVN.isEmpty()) {
                    WebElement driverclmn = driver.findElement(By.xpath("//tbody//tr["+i+"]//td[5]"));
                    Thread.sleep(2000);
                    drivername = driverclmn.getText();
                    Thread.sleep(1000);
                    if(!(drivername.equalsIgnoreCase("Unassigned") || drivername.contains("Pool")||drivername.contains("Unknown")||drivername.contains("Catering")) ) {
                    //    driver.findElement(By.xpath("//tbody//tr["+i+"]//td[5]")).click();
                    executor.executeScript("arguments[0].click();", driverclmn);
                    Thread.sleep(1000);
                    firstpage = false;
                    break;}
                  }  
                firstpage = true;
            }
            if(firstpage)
            queryObjects.logStatus(driver, Status.PASS, "Searching Required grid record from Webtable", "Successful", null);
            
            Thread.sleep(2000);
            RC_Global.waitElementVisible(driver, 30, "//h5//span[text()='Driver Details']", "Driver Details panel", endRun,false);
            RC_Global.clickUsingXpath(driver,"(//i[contains(@ng-class,' !panel.maximized')])[2]", "Expand DDriver Details panel", endRun,false);
            
            
            CustomerName =    driver.findElement(By.xpath("//span[@id='driver-change-header-customer-name']")).getText();
            UnitNumber =    driver.findElement(By.xpath("//a[@id='driver-change-header-vehicle-id']")).getText();
            VehicleStatus = driver.findElement(By.xpath("//span[contains(@id,'vehicle-status')]")).getText();
            queryObjects.logStatus(driver, Status.PASS, "Vehicle status is",""+VehicleStatus, null);
        }catch (Exception e){
            queryObjects.logStatus(driver, Status.FAIL, "Searching Required grid record from Webtable", e.getLocalizedMessage(), e);
             if(endRun)
            	 RC_Global.endTestRun(driver);
		   
        }
    }
	
	public static String getAddress_DriverSelection(WebDriver driver, String selVal,boolean endRun) throws Exception{
		String dCity = ""; String dCity2=""; String dAddr = ""; String dAddr2=""; String vehiclestat = "";
		boolean nextButton = false; boolean firstpage=false; boolean selected = false; String retVal = "";
		RC_Manage.drivername = ""; RC_Manage.UnitNumber = ""; String UnitNum2 = "";
		RC_Global.createNode(driver, "Driver Selection - "+selVal);
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		WebDriverWait wait = new WebDriverWait(driver,30);
		int itr = 1;
		try {
			selectFromDropdown(driver, "50", driver.findElement(By.xpath("//select[@data-ng-model='numPerPage']")));
			
			executor.executeScript("document.body.style.zoom = '70%'");
			Thread.sleep(500);
			executor.executeScript("arguments[0].click();", driver.findElement(By.xpath("//span[contains(@class,'column-header') and contains(text(),'City')]/..")));
			//RC_Global.clickUsingXpath(driver, "//span[contains(@class,'column-header') and contains(text(),'City')]/..", "City column header", true);
			Thread.sleep(1000);
			executor.executeScript("document.body.style.zoom = '100%'");
			
			do {
				if (itr>1) {
					nextButton = driver.findElements(By.xpath("//a[text()='Next' and @disabled = 'disabled']")).size()>0;
				}
				List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("//table//tbody//tr"));				
	            int rowcnt=Getgridrowcnt.size();
	            for(int i=1; i<rowcnt;i++) {
	            	if (selVal.equalsIgnoreCase("Address Change")) {
	            		dCity= driver.findElement(By.xpath("//tr["+i+"]//td[12]")).getText();
		            	dCity2= driver.findElement(By.xpath("//tr["+(i+1)+"]//td[12]")).getText();
		            	dAddr= driver.findElement(By.xpath("//tr["+i+"]//td[11]")).getText();
		            	dAddr2= driver.findElement(By.xpath("//tr["+(i+1)+"]//td[11]")).getText();
		                if(dCity.equalsIgnoreCase(dCity2)) {
		                	if (!(dAddr.trim().equalsIgnoreCase(dAddr2.trim()))) {
		                		selected = true;
		                		retVal = dAddr2;
		                	}
		                }
					} else if (selVal.equalsIgnoreCase("Driver Change")) {
						selected = true;
					} else if (selVal.equalsIgnoreCase("Pool Change")) {
						selected = true;
					} else if (selVal.contains("DiffUnitNum")) {
						if (!unitNum.isEmpty()) {
							if (!(unitNum.equalsIgnoreCase(driver.findElement(By.xpath("//tbody//tr["+i+"]//td[3]")).getText()))) {
								selected = true;
							}
						}
					}
	                if(selected) {
	                	vehiclestat = driver.findElement(By.xpath("//tbody//tr["+i+"]//td[15]")).getText();
                		if (vehiclestat.equalsIgnoreCase("Active lease") || vehiclestat.equalsIgnoreCase("Active services only")) {
                			unitNum = RC_Manage.UnitNumber = driver.findElement(By.xpath("//tbody//tr["+i+"]//td[3]")).getText();
                			WebElement driverclmn =driver.findElement(By.xpath("//tbody//tr["+i+"]//td[5]"));
                			RC_Manage.drivernameUpdated = RC_Manage.drivername =driverclmn.getText();
                            if (selVal.contains("Pool")){
                            	if((RC_Manage.drivername.contains("Store")|| RC_Manage.drivername.contains("Pool")) || !(RC_Manage.drivername.equalsIgnoreCase("Unassigned") ||RC_Manage.drivername.contains("Unknown")||RC_Manage.drivername.contains("Catering")) ) {
                                    executor.executeScript("arguments[0].click();", driverclmn);
                                    firstpage = true;	                            
                                    break;}
                            } else {
                            	if(!(RC_Manage.drivername.contains("Store")|| RC_Manage.drivername.equalsIgnoreCase("Unassigned") || RC_Manage.drivername.contains("Pool")||RC_Manage.drivername.contains("Unknown")||RC_Manage.drivername.contains("Catering")) ) {
                                    executor.executeScript("arguments[0].click();", driverclmn);
                                    firstpage = true;	                            
                                    break;}
                            }
                            
						}                    
					  }  
	            }
	            if (firstpage) {
	            	Thread.sleep(2000);
	            	RC_Global.waitUntilPanelVisibility(driver, "Driver Details", "TV", true, false);
		            nextButton = true;
		            break;
				} else {
					driver.findElement(By.xpath("//a[text()='Next']")).click();
		            itr = itr+1;
				}
			} while (nextButton);
			
            if(firstpage)
            queryObjects.logStatus(driver, Status.PASS, "Searching Required grid record from Webtable", "Successful", null);
            
		}catch (Exception e){
			queryObjects.logStatus(driver, Status.FAIL, "Searching Required grid record from Webtable", e.getLocalizedMessage(), e);
			 if(endRun)
	   				RC_Global.endTestRun(driver);
		}
		return dAddr2;		
	}
	
	public static void leasewave_DriverDataChangeValidation(WebDriver driver,String selAct, boolean endRun)throws Exception{
		RC_Global.createNode(driver, "Driver data Change validation in LeaseWave");
		String Fleet_Management="";
		try {
			
			RC_Global.clickUsingXpath(driver,"//a[contains(text(),'Portfolio Management')]","Portfolio Management",endRun,false);
			RC_Global.waitElementVisible(driver, 50, "//a[contains(text(),'Portfolio Management')]", "Portfolio Management",endRun,false);
		    String home =  driver.findElement(By.xpath("//a[contains(text(),'Portfolio Management')]")).getText();
		    if(home.contains("Portfolio Management")) {
		    	queryObjects.logStatus(driver, Status.PASS, "Navigation to Portfolio Management Menu", "Successfully", null);	
		    }
		    RC_Global.clickUsingXpath(driver,"//td[@accesskey='3' and text()='.Asset']","Asset option",endRun,false);
		    RC_Global.clickUsingXpath(driver,"//tr[contains(@igurl,'InventoryProfile/AssetList')]/td[@accesskey='P']","Inventory Profile option",endRun,false);
			RC_Global.waitElementVisible(driver, 50, "//span[text()='Asset List' and @id='ctl00_PageTitle']", "Asset List",endRun,false);
		    
		    driver.findElement(By.xpath("//td//input[contains(@name,'UnitNumber')]")).sendKeys(RC_Manage.UnitNumber);
		    RC_Global.clickUsingXpath(driver,"//button[text()='Searc']","Search button",endRun,false);
		    Thread.sleep(2000);
		    //check for drivername change
		    String LWdriverNm = driver.findElement(By.xpath("//td[10]//nobr")).getText();
		    String [] name =LWdriverNm.split("/");
		    RC_Manage.Firstname= name[1];
		    RC_Manage.Lastname= name[0];
		    String LWDriverFrstname = name[1].concat(" ");
		    String LWDriverFullname = LWDriverFrstname.concat(name[0]);
		    
		    if(RC_Manage.drivername.contains(LWDriverFullname)) {
		    	queryObjects.logStatus(driver, Status.PASS, "Driver Data change is done", "Successfully", null);	
		    }
		    else {
		    	queryObjects.logStatus(driver, Status.FAIL, "Driver Data change is not","reflected in Leasewave", null);	
		    }
		    if (selAct.equalsIgnoreCase("Address")) {
		    	JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("arguments[0].scrollIntoView(true)",driver.findElement(By.xpath("//h2/span[text()='Asset List']")));
			
				RC_Global.clickUsingXpath(driver,"//button[text()='dit']","Edit button",endRun,false);
				RC_Global.waitElementVisible(driver, 50, "//span[text()='Asset Profile Home']", "Asset Profile Home",endRun,false);
			   	String Asset_status =driver.findElement(By.xpath("//input[contains(@name,'Status')]")).getAttribute("value");
			   
			   	RC_Global.clickUsingXpath(driver,"//a[text()='Location History']","Location History",endRun,false);
				RC_Global.waitElementVisible(driver, 50, "//span[text()='Location History']", "Location History",endRun,false);

			   	String address =  driver.findElement(By.xpath("//tbody/tr[1]/td[8][contains(@id,'grdLocationHistory')]/nobr")).getText();
			   if(address.equals(RC_Manage.DriverAddress))			    
				   queryObjects.logStatus(driver, Status.PASS, "The most recent address is the new Employee Address", address, null);
			   else
				   queryObjects.logStatus(driver, Status.FAIL, "The most recent address is not matches with new Employee Address", address, null);
			}
		
		   	RC_Global.clickUsingXpath(driver,"(//button[@accesskey='C' and text()='lose'])[2]","Close button",endRun,false);
		   	RC_Global.clickUsingXpath(driver,"(//button[@accesskey='C' and text()='lose'])[1]","Close button",endRun,false);
			RC_Global.waitElementVisible(driver, 50, "//span[text()='Asset List' and @id='ctl00_PageTitle']", "Asset List",endRun,false);

		    }
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Portfolio Management Failed", e.getLocalizedMessage(), e);	
			if(endRun)
				RC_Global.endTestRun(driver);
		}
	}
	
	public static String getClientDataCols(WebDriver driver) throws Exception {
		String cols = ""; String colName = "";
		try {
			RC_Global.createNode(driver, "Client Data Columns");
			List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("//table//tbody//tr"));				
	        int rowcnt=Getgridrowcnt.size();
	        for (int i = 1; i <= rowcnt; i++) {
	        	colName = driver.findElement(By.xpath("//table//tbody//tr["+i+"]//td[2]")).getText();
	        	if (cols!="") {
	        		cols = cols+";"+colName;
				} else {
					cols = colName;
				}			
			}
		} catch (Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Unab;e to get the Client Data columns", e.getLocalizedMessage(), e);
		    RC_Global.endTestRun(driver);
		}		
		return cols;		
	}
	
	public static void verifyGridColumnNames(WebDriver driver, String ColumnNames,boolean endRun)throws Exception {
		RC_Global.createNode(driver, "Verify the Grid Column Names");   
		WebDriverWait wait = new WebDriverWait(driver,30);
		try{
	              String[] aColNames = ColumnNames.split(";");
	              wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//vehicle-segment-mapping-rules//standard-grid//div[2]/div/div[1])[2]")));
	              Thread.sleep(2000);
	     //   	  int colCount=aColNames.length;
	              JavascriptExecutor e = (JavascriptExecutor) driver;
	              
	              for(int i=0;i<aColNames.length;i++)
                  {
                        if(driver.findElements(By.xpath("//vehicle-segment-mapping-rules//standard-grid//div[1]//span[text()='"+aColNames[i]+"']")).size()>0)
                         {
                            driver.findElement(By.xpath("//vehicle-segment-mapping-rules//standard-grid//div[1]//span[text()='"+aColNames[i]+"']"));
                                queryObjects.logStatus(driver, Status.PASS, "Column Validation for", aColNames[i]+" Column is verified", null);
                         }
                        else
                        {
                               queryObjects.logStatus(driver, Status.FAIL, "Column Validation for ", " Column"+aColNames[i]+" is not available", null);
                        }
                  }
	       }
	              catch(Exception e) {
	                     queryObjects.logStatus(driver, Status.FAIL, "Grid column validation failed", e.getLocalizedMessage(), e);
	                     if(endRun)
	       	              RC_Global.endTestRun(driver);     
	              }
	}
	
	//To generate the random numbers within the given index
	public static List<Integer> RandomNumbers(WebDriver driver,int BeginIndex, int EndIndex, int size) {		
		int randomInt = 0;
		ArrayList<Integer> rand = new ArrayList<Integer>();
		for (int i = 0; i < EndIndex+EndIndex; i++) {
			randomInt = ThreadLocalRandom.current().nextInt(BeginIndex, EndIndex);
			if (!rand.contains(randomInt)) {
				rand.add(randomInt);			}
			
			Collections.shuffle(rand);
			if (rand.size()==size) {
				break;
			}
		}		
		return rand;		
	}
	
	public static Object RandomSelection(WebDriver driver) {
		List<String> addressLists = new ArrayList<String>(Arrays.asList("3306 Bermuda Ct",	"West Sacramento",	"CA",	"95691-5907",	"YOLO",	"USA"));
		List<String> addressLists1 = new ArrayList<String>(Arrays.asList("504 Alaska St",	"Staunton",	"IL",	"62088-1674",	"MACOUPIN",	"USA"));		
		List<String> addressLists2 = new ArrayList<String>(Arrays.asList("125 Little Pl",	"South Bound Brook",	"NJ",	"08880-1113",	"SOMERSET",	"USA"));		
		List<String> addressLists3 = new ArrayList<String>(Arrays.asList("5087 Commercial Cir Ste 20",	"Concord",	"CA",	"94520-1268",	"CONTRA COSTA",	"USA"));		
		List<String> addressLists4 = new ArrayList<String>(Arrays.asList("17849 Edison Ave",	"Chesterfield",	"MO",	"63005-1251",	"ST LOUIS",	"USA"));		
		List<String> addressLists5 = new ArrayList<String>(Arrays.asList("12625 Wetmore Rd Ste 103",	"San Antonio",	"TX",	"78247-3609",	"BEXAR",	"USA"));
		List<String> addressLists6 = new ArrayList<String>(Arrays.asList("4212 Lambert Rd",	"Louisville",	"KY",	"40219-3812",	"JEFFERSON",	"USA"));		
		List<String> addressLists7 = new ArrayList<String>(Arrays.asList("22522 29th Dr SE Ste 102",	"Bothell",	"WA",	"98021-4443",	"SNOHOMISH",	"USA"));		
		List<String> addressLists8 = new ArrayList<String>(Arrays.asList("2128 Citygate Dr",	"Columbus",	"OH",	"43219-3566",	"FRANKLIN",	"USA"));
		List<String> addressLists9 = new ArrayList<String>(Arrays.asList("3390 W Jones Ave",	"Garden City",	"KS",	"67846-9726",	"",	"USA"));
		List allAddresses = new ArrayList(Arrays.asList(addressLists,addressLists1,addressLists2,addressLists3,addressLists4,addressLists5,addressLists6,addressLists7,addressLists8));
		Random rand = new Random();
		return allAddresses.get(rand.nextInt(allAddresses.size()));
		
	}
	
	public static String selectDownloadResults(WebDriver driver, String userNm, String submitTime, String tmZone) throws Exception {
		int rows = 0; String rowText = ""; String getDate = "";	String addOneMin = ""; String addTwoMins = "";
		String formatTime1[] = null; String formatTime2[] = null; String uploadTime = "";
		
		try {
			RC_Global.createNode(driver, "Download Result File");
			rows = driver.findElements(By.xpath("(//div[@class='ui-grid-row ng-scope'])")).size();
			getDate = AddDateStr(0, "MM/dd/yyyy", "", null, tmZone);
			addOneMin = RC_Manage.AddDateStr(1, "MM/dd/yyyy hh:mm:ss a", "minute", new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a").parse(submitTime), tmZone);
			addTwoMins = RC_Manage.AddDateStr(2, "MM/dd/yyyy hh:mm:ss a", "minute", new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a").parse(submitTime), tmZone);
			formatTime1 = addOneMin.split(" ");
			if (formatTime1[1].substring(0, 1).contains("0")) {
				formatTime1[1] = formatTime1[1].substring(1, formatTime1[1].length());
			}
			addOneMin = formatTime1[0]+" "+formatTime1[1]+" "+formatTime1[2];
			formatTime2 = addTwoMins.split(" ");
			if (formatTime2[1].substring(0, 1).contains("0")) {
				formatTime2[1] = formatTime2[1].substring(1, formatTime2[1].length());
			}
			addTwoMins = formatTime2[0]+" "+formatTime2[1]+" "+formatTime2[2];
			for (int i = 1; i <= rows; i++) {
				rowText = driver.findElement(By.xpath("(//div[@class='ui-grid-row ng-scope'])["+i+"]")).getText();
				if (rowText.toLowerCase().contains(userNm.toLowerCase()) && rowText.contains(getDate) && rowText.contains("Completed with") && 
						(rowText.contains(submitTime.substring(0, submitTime.length()-6)) || rowText.contains(addOneMin.substring(0, addOneMin.length()-6)) || 
								rowText.contains(addTwoMins.substring(0, addTwoMins.length()-6))) 
						&& rowText.contains(submitTime.substring(submitTime.length()-2,submitTime.length()))) {
					RC_Global.clickUsingXpath(driver, "(//div[@class='ui-grid-row ng-scope'])["+i+"]//button[text()='Download Results']", "Select the Download Results button", true,false);
					queryObjects.logStatus(driver, Status.PASS, "Download results file selection ", "", null);
					waitUntilMethods(driver, "(//div[@class='ui-grid-row ng-scope'])["+i+"]//div[10]//button[text()='Download Results']", "","","visible");
					uploadTime = driver.findElement(By.xpath("(//div[@class='ui-grid-row ng-scope'])["+i+"]//div[8]/div")).getText();
					Thread.sleep(5000);
					break;
				}
			}
		} catch (Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Download results file selection failed", e.getLocalizedMessage(), e);
		    RC_Global.endTestRun(driver);
		}
		return uploadTime;
		
	}
	
	public static String driverHistory_DateFormat(WebDriver driver, BFrameworkQueryObjects queryObjects, String uploadTime, String timeChange) throws Exception {
		String newTime = ""; Date uploadDate = null;
		String retTime = "";
		
    	try {
    		if (timeChange.equalsIgnoreCase("yes")) {
    			newTime = new SimpleDateFormat("MMM d, yyyy hh:mm:ss a").format(new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a").parse(uploadTime));
    			uploadDate = new SimpleDateFormat("MMM d, yyyy h:mm:ss a").parse(newTime);
    			retTime = AddDateStr(0, "MMM d, yyyy h:mm:ss a", "", uploadDate, "CST");
			} else {
				retTime = new SimpleDateFormat("MMM d, yyyy h:mm:ss a").format(new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a").parse(uploadTime));
			}
    		
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			queryObjects.logStatus(driver, Status.FAIL, "Date Conversion failed", "", null);
		}
		return retTime;
    	
	}
	
	public static void selectHistoryView(WebDriver driver, String usernm, String drivernm, String valTime) throws Exception {
		int cntRows = 0; String getRwText = ""; String curDate="";
		//Aug 17, 2021 12:13:35 PM
		Thread.sleep(3000);
		curDate = AddDateStr(0, "MMM d, yyyy", "", null, "CST");
		cntRows = driver.findElements(By.xpath("(//tbody/tr//a[text()='View']//ancestor::tr)")).size();
		for (int i = 1; i <= cntRows; i++) {
			getRwText = "";
			getRwText = driver.findElement(By.xpath("(//tbody/tr//a[text()='View']//ancestor::tr)["+i+"]")).getText();
			if (getRwText.contains(usernm) && getRwText.contains(curDate) && getRwText.contains(drivernm) && getRwText.contains(valTime.substring(0, valTime.length()-5))) {
				driver.findElement(By.xpath("(//tbody/tr//a[text()='View'])["+i+"]")).click();
				Thread.sleep(1000);
				break;
			}
		}
	}
	
	public static void viewHistory_DriverChange(WebDriver driver, BFrameworkQueryObjects queryObjects, String custNo, String unitNo, String user , String valTime) throws IOException {
		try {
			RC_Global.navigateTo(driver, "Manage", "Administration", "Driver Data Change");
			RC_Global.enterCustomerNumber(driver, custNo, "", "", false);
			RC_Global.enterInput(driver, unitNo, driver.findElement(By.xpath("//input[@placeholder='Unit Number']")), false,false);
	    	RC_Global.clickButton(driver, "Search", false,false);
	    	RC_Global.waitElementVisible(driver, 10, "//span[contains(text(),'Driver Details')]", "Driver Details", false,false);
	    	Thread.sleep(5000);
	    	RC_Global.clickButton(driver, "History", false,false);
	    	RC_Global.waitElementVisible(driver, 20, "//h5[span[contains(text(),'Driver Change')]]", "Driver Change", false,false);
	    	driver.findElement(By.xpath("//h5[span[contains(text(),'Driver Details')]]/i[@ng-click='closePanel()']")).click();
	    	try {
	    		driver.findElement(By.xpath("//i[contains(@ng-click,'maximize')]")).click();
			} catch (Exception e) {}
	    	Thread.sleep(500);
	    	try {
				WebDriverWait wait = new WebDriverWait(driver,20);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//tbody/tr//a[text()='View']//ancestor::tr)[1]")));
			}
			catch(Exception e) {}
	    	RC_Manage.selectHistoryView(driver, user, "", valTime);	    	
		} catch (Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Driver Details - History", "Navigation failed", e);
		}
		
	}
	
	public static void compareExpected_Actual(WebDriver driver, String oldVals, String newVals, String colVal) throws Exception{
		String oldXpath = ""; String newXpath ="" ; String drivername[] = null; String yearMkModel = ""; String sptyr[] = null; String getVal = "";
		String colName = ""; String lastnmXpath = ""; String lastnmXpath1 ="";
		String unchangedNames = "cvn;customervehiclenumber;unitnumber;vin";
		String yearModel = "year;make;model";
		String Addresses= "address1;address2;city;state;zipcode;country;county";
		colName = StringUtils.deleteWhitespace(colVal).toLowerCase();
		try {
			if (colName.contains("driver/poolname")) {
				if (driver.findElement(By.xpath("//h4[text()='Old ']/../..//div[text()='Pool Name:']/..")).getAttribute("class").contains("ng-hide")) {
					drivername = oldVals.split(" ");
					oldXpath = "//h4[text()='Old ']/../..//div[text()='First Name:']/following-sibling::div";
					newXpath = "//h4[text()='New ']/../..//div[text()='First Name:']/following-sibling::div";
					lastnmXpath = "//h4[text()='Old ']/../..//div[text()='Last Name:']/following-sibling::div";
					lastnmXpath1 = "//h4[text()='New ']/../..//div[text()='Last Name:']/following-sibling::div";
					//h4[text()='New ']/../..//div[text()='Last Name:']/following-sibling::div
				} else {
					oldXpath = "//h4[text()='Old ']/../..//div[text()='Pool Name:']/following-sibling::div";
					newXpath = "//h4[text()='New ']/../..//div[text()='Pool Name:']/following-sibling::div";
				}				
			}
			if (colName.contains("address1")) {
				oldXpath = "//h4[text()='Old ']/../..//div[text()='Address 1:']/following-sibling::div";
				newXpath = "//h4[text()='New ']/../..//div[text()='Address 1:']/following-sibling::div";
			}
			if (colName.contains("address2")) {
				oldXpath = "//h4[text()='Old ']/../..//div[text()='Address 2:']/following-sibling::div";
				newXpath = "//h4[text()='New ']/../..//div[text()='Address 2:']/following-sibling::div";
			}
			if (colName.contains("city")) {
				oldXpath = "//h4[text()='Old ']/../..//div[text()='City:']/following-sibling::div";
				newXpath = "//h4[text()='New ']/../..//div[text()='City:']/following-sibling::div";
			}
			if (colName.contains("state")) {
				oldXpath = "//h4[text()='Old ']/../..//div[text()='State:']/following-sibling::div";
				newXpath = "//h4[text()='New ']/../..//div[text()='State:']/following-sibling::div";
			}
			if (colName.contains("zipcode")) {
				oldXpath = "//h4[text()='Old ']/../..//div[text()='Zip:']/following-sibling::div";
				newXpath = "//h4[text()='New ']/../..//div[text()='Zip:']/following-sibling::div";
			}
			if (colName.contains("county")) {
				oldXpath = "//h4[text()='Old ']/../..//div[text()='County:']/following-sibling::div";
				newXpath = "//h4[text()='New ']/../..//div[text()='County:']/following-sibling::div";
			}
			if (colName.contains("country")) {
				oldXpath = "//h4[text()='Old ']/../..//div[text()='Country:']/following-sibling::div";
				newXpath = "//h4[text()='New ']/../..//div[text()='Country:']/following-sibling::div";
			}
			if (colName.contains("country")) {
				oldXpath = "//h4[text()='Old ']/../..//div[text()='Country:']/following-sibling::div";
				newXpath = "//h4[text()='New ']/../..//div[text()='Country:']/following-sibling::div";
			}
			if (colName.contains("clientdata")) {//h4[text()='New ']/../..//div[text()='Client Data 1:']/following-sibling::div
				oldXpath = "//h4[text()='Old ']/../..//div[text()='"+colVal+":']/following-sibling::div";
				newXpath = "//h4[text()='New ']/../..//div[text()='"+colVal+":']/following-sibling::div";
			}
			if (colName.contains("unitnumber")) {
				oldXpath = "//div/strong[text()='Unit Number: ']/..//a";
			}
			if (colName.contains("cvn") || colName.contains("customervehiclenumber")) {
				oldXpath = "//div/strong[text()='Customer Vehicle Number: ']/..//a";
			}
			if (colName.contains("vin")) {
				oldXpath = "//div/strong[text()='VIN: ']/..//span";
			}
			if ("year;make;model".contains(colName)) {
				oldXpath = "//div/strong[text()='Year/Make/Model: ']/..//span";
			}			
			if (unchangedNames.contains(colName) && !colName.equals("cvn")) {
				RC_Manage.expected_actual(driver, oldXpath, oldVals, "", "Verify the value updated in column -"+colName+ " is not reflected in the application");
			} else if(colName.contains("driver/poolname")) {
				if (driver.findElement(By.xpath("//h4[text()='Old ']/../..//div[text()='Pool Name:']/..")).getAttribute("class").contains("ng-hide")) {
					RC_Manage.expected_actual(driver, oldXpath, drivername[0], "", "Verify the existing value in old column -"+colName+ " remains the same");
					RC_Manage.expected_actual(driver, lastnmXpath, drivername[1], "", "Verify the value updated in column -"+colName+ " is not reflected in the application");
					RC_Manage.expected_actual(driver, newXpath, drivername[0], "", "Verify the existing value in old column -"+colName+ " remains the same");
					RC_Manage.expected_actual(driver, lastnmXpath1, drivername[1], "", "Verify the value updated in column -"+colName+ " is not reflected in the application");
				} else {
					RC_Manage.expected_actual(driver, oldXpath, oldVals, "", "Verify the existing value in old column -"+colName+ " remains the same");
					RC_Manage.expected_actual(driver, newXpath, oldVals, "", "Verify the existing value in old column -"+colName+ " remains the same");
				}
				
			} else if (yearModel.contains(colName)) {
				yearMkModel = driver.findElement(By.xpath(oldXpath)).getText();
				sptyr = yearMkModel.split(" / ");
				if (colName.contains("year")) {
					getVal = sptyr[0];
				} else if(colName.contains("make")){
					getVal = sptyr[1];
				} else if(colName.contains("model")){
					getVal = sptyr[2];
				}
				RC_Manage.expected_actual(driver, "", oldVals, getVal, "Verify the existing value in old column -"+colName+ " remains the same");
			} else if (Addresses.contains(colName)) {
				RC_Manage.expected_actual(driver, oldXpath, oldVals, "", "Verify the existing value in old column -"+colName+ " remains the same");
				RC_Manage.expected_actual(driver, newXpath, oldVals, "", "Verify the value updated in column -"+colName+ " is not reflected in the application");
				//expected_actual(driver, oldXpath, newVals, "Verify the value updated in column -"+colName+ " is reflected in application");
			} else if (colName.contains("clientdata")) {
				if (oldVals.trim().isEmpty()) {
					oldVals = "-";
				}
				RC_Manage.expected_actual(driver, oldXpath, oldVals, "", "Verify the existing value in old column -"+colVal+ " remains same");
				RC_Manage.expected_actual(driver, newXpath, newVals, "", "Verify the value updated in column -"+colVal+ " is reflected in the application");
			}  else if (colName.equals("cvn") || colName.equals("customervehiclenumber")) {
				RC_Manage.expected_actual(driver, oldXpath, newVals, "", "Verify the value updated in column -"+colName+ " is reflected in the application");
			} else if (colName!="cvn" && colName!="customervehiclenumber") {
				RC_Manage.expected_actual(driver, oldXpath, newVals, "", "Verify the value updated in column -"+colName+ " is reflected in the application");
			}
		} catch (Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Expected and Actual values comparison failed", e.getLocalizedMessage(), e);
		    RC_Global.endTestRun(driver);
		}		
	}
	
	public static void expected_actual(WebDriver driver, String xPath, String expectedval, String value, String validationmsg) throws Exception{
		try {
			if (xPath.isEmpty()) {
				if (value.equalsIgnoreCase(expectedval)) {
					queryObjects.logStatus(driver, Status.PASS, validationmsg, "Verification successful", null);
				} else {
					queryObjects.logStatus(driver, Status.FAIL, validationmsg, "Verification failed. Expected -"+expectedval, null);
				}
			} else {
				if (validationmsg.contains("-driver/poolname")) {
					if (driver.findElement(By.xpath(xPath)).getText().toLowerCase().contains(expectedval.toLowerCase())) {
						queryObjects.logStatus(driver, Status.PASS, validationmsg, "Verification successful", null);
					} else {
						queryObjects.logStatus(driver, Status.FAIL, validationmsg, "Verification failed. Expected -"+expectedval, null);
					}
				} else {
					if (driver.findElement(By.xpath(xPath)).getText().equalsIgnoreCase(expectedval)) {
						queryObjects.logStatus(driver, Status.PASS, validationmsg, "Verification successful", null);
					} else {
						queryObjects.logStatus(driver, Status.FAIL, validationmsg, "Verification failed. Expected -"+expectedval, null);
					}
				}				
			}
		} catch (Exception e) {
			if (xPath.contains("Client Data") && xPath.contains("Old")) {
				if (driver.findElements(By.xpath("(//span[text()='No client data'])[1]")).size()>0) {
					String vStatus = driver.findElement(By.xpath("(//span[contains(@id,'vehicle-status')])[1]")).getText();
					queryObjects.logStatus(driver, Status.WARNING, "No Client Data displayed for the Vehicle status '"+vStatus+"'", "Old Client Data fields are not displayed", null);
//					if (driver.findElements(By.xpath("(//span[contains(@id,'vehicle-status') and text()='On Order'])[1]")).size()>0) {				
//						queryObjects.logStatus(driver, Status.WARNING, "No Client Data displayed for the Vehicle status 'On Order'", "Old Client Data fields are not displayed", null);
//					} else {
//						queryObjects.logStatus(driver, Status.ERROR, "No Client Data displayed but the Vehicle status is not 'On Order'", "Old Client Data fields are not displayed", e);
//					}
				} else {
					queryObjects.logStatus(driver, Status.FAIL, "Comparison failed", e.getLocalizedMessage(), e);
				}
			} else {
				queryObjects.logStatus(driver, Status.FAIL, "Comparison failed", e.getLocalizedMessage(), e);
			}
		}
	}
	
	public static String fileDownload(WebDriver driver, String selTemplate, String fileName) throws Exception{
		try {
			RC_Global.createNode(driver, "Download File");
			String filePath = "";
	        RC_Global.selectDropdownOption(driver, "I want to", "Download Template", false,false);
	        RC_Global.selectDropdownOption(driver, "Select Template", selTemplate, false,false);
	        RC_Global.clickButton(driver, "Download Template", true,false);
	        RC_Manage.waitUntilDownloadingDisappears(driver);
	        Thread.sleep(5000);
	        filePath = RC_Manage.moveFileFromDownloads(driver, fileName, "MassDownload", true);
	        return filePath;
		} catch (Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Download "+fileName+" file failed", e.getLocalizedMessage(), e);
		    RC_Global.endTestRun(driver);
		}
		return "";		
	}
	
	public static void waitUntilUploadProcessing_MassUpload(WebDriver driver, String userNm, String subTime) throws Exception {
		int rows = 0; String rowText = "";
		try {
			WebDriverWait wait = new WebDriverWait(driver,40);
			if (driver.findElement(By.xpath("(//div[@class='ui-grid-row ng-scope'])[1]")).getText().contains("Pending")) {
				Thread.sleep(3000);
				rows = driver.findElements(By.xpath("(//div[@class='ui-grid-row ng-scope'])")).size();
				for (int p = 0; p < 2; p++) {
					for (int i = 1; i <= rows; i++) {
						rowText = driver.findElement(By.xpath("(//div[@class='ui-grid-row ng-scope'])["+i+"]")).getText();
						if (rowText.contains("Pending") && rowText.contains(subTime.substring(0, 11)) && rowText.contains(userNm)) {
							if (driver.findElements(By.xpath("(//div[@class='ui-grid-row ng-scope'])["+i+"]//div[9]/div[text()='"+userNm+"']/../preceding-sibling::div[4]/div[text()='Pending']")).size()>0) {
								try {
									wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("(//div[@class='ui-grid-row ng-scope'])["+i+"]//div[text()='Pending']")));
								} catch (Exception e) {}
							}
							break;
						}
					}
				}
			}
			if (driver.findElement(By.xpath("(//div[@class='ui-grid-row ng-scope'])[1]")).getText().contains("Processing")) {
				Thread.sleep(3000);
				rows = driver.findElements(By.xpath("(//div[@class='ui-grid-row ng-scope'])")).size();
				for (int p = 0; p < 2; p++) {
					for (int i = 1; i <= rows; i++) {						
						rowText = driver.findElement(By.xpath("(//div[@class='ui-grid-row ng-scope'])["+i+"]")).getText();						
						if (rowText.contains("Processing") && rowText.contains(subTime.substring(0, 11)) && rowText.contains(userNm)) {
							wait = new WebDriverWait(driver,40);
							if (driver.findElements(By.xpath("(//div[@class='ui-grid-row ng-scope'])["+i+"]//div[9]/div[text()='"+userNm+"']/../preceding-sibling::div[4]/div[text()='Processing']")).size()>0) {
								try {
									wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("(//div[@class='ui-grid-row ng-scope'])["+i+"]//div[4]//div[text()='Time remaining: ']")));
								} catch (Exception e) {}
							}
							
							break;
						}
					}
				}
			}
			
		} catch (Exception e) {}	
		
	}
	
	public static String fileUpload(WebDriver driver, String dir, String filePath, String selTemplate, String tmZone, String defTimeZone, String usrName, String uploadType) throws Exception{
		String getDate = ""; String formatDate = ""; String sptDate[] = null;
		String curDate = ""; String curTime = ""; String getHour = ""; String getMins = ""; String getAMPM = "";
		String convertedDate = ""; String sptConvtDt[] = null; String newDate = "";
		String rowText = ""; String cellVal = ""; String getVal = ""; boolean err = false;
		String cusNum = driver.findElement(By.xpath("//div[@ng-show='customerChosen']/input[@name='customerInput']")).getAttribute("value");
		RC_Global.createNode(driver, "Upload File from the Directory Filepath");
		cellVal = driver.findElement(By.xpath("(//div[@class='ui-grid-row ng-scope'])[1]//div[@role='gridcell'][7]/div")).getText();
		try {
			String currentWindow = driver.getWindowHandle();
		    driver.switchTo().window(currentWindow);
		    driver.manage().window().maximize();
		    RC_Global.selectDropdownOption(driver, "I want to", "Upload Template", false,false);
			Thread.sleep(1000);
			RC_Manage.selectFromDropdown(driver, selTemplate, driver.findElement(By.xpath("//div[contains(@class,'upload')]/div/label[text()='Select Template']/following-sibling::Select")));
			RC_Global.clickButton(driver, "Select File", true,false);
			Thread.sleep(1000);
	        RC_Manage.uploadFileWithRobot(driver, filePath);
	        RC_Global.waitElementVisible(driver, 60, "//div[@class='uploaded-file']", "Uploaded file", true,true);
			if (uploadType.equalsIgnoreCase("schedule")) {
				RC_Manage.selectFromDropdown(driver, "Scheduled", driver.findElement(By.xpath("//select[@ng-model='vm.uploadTimeOption']")));
				RC_Manage.selectFromDropdown(driver, selTimeZoneNames(driver, tmZone), driver.findElement(By.xpath("//select[@ng-model='vm.scheduledTimeZone']")));
				getDate = AddDateStr(1, "MM/dd/yyyy hh:mm:ss a", "minute", null, tmZone);
				newDate = AddDateStr(1, "MM/dd/yyyy hh:mm:ss a", "minute", null, "IST");
				convertedDate = RC_Manage.AddDateStr(0, "MM/dd/yyyy hh:mm:ss a", "", new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a").parse(getDate), defTimeZone);
				sptConvtDt = convertedDate.split(" ");
				sptDate = getDate.split(" ");
				curDate = sptDate[0]; curTime = sptDate[1]; getHour = sptDate[1].substring(0, 2); getMins = sptDate[1].substring(3, 5); getAMPM = sptDate[2];
				driver.findElement(By.xpath("//input[@ng-model='vm.scheduledDate']")).clear();
				driver.findElement(By.xpath("//input[@ng-model='vm.scheduledDate']")).sendKeys(curDate);
				driver.findElement(By.xpath("//input[@ng-model='hours']")).clear();
				driver.findElement(By.xpath("//input[@ng-model='hours']")).sendKeys(getHour);
				driver.findElement(By.xpath("//input[@ng-model='minutes']")).clear();
				driver.findElement(By.xpath("//input[@ng-model='minutes']")).sendKeys(getMins);
				if (!((driver.findElement(By.xpath("//td[@class='uib-time am-pm']/button")).getText()).toUpperCase()).equals(getAMPM.toUpperCase())) {
					driver.findElement(By.xpath("//td[@class='uib-time am-pm']/button")).click();
				}
			} else {
				getDate = AddDateStr(0, "MM/dd/yyyy hh:mm:ss a", "", null, tmZone);
				newDate= getDate;
				convertedDate = RC_Manage.AddDateStr(0, "MM/dd/yyyy hh:mm:ss a", "", new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a").parse(getDate), defTimeZone);
				sptConvtDt = convertedDate.split(" ");
				sptDate = getDate.split(" ");
				curDate = sptDate[0]; curTime = sptDate[1];
			}
			//RC_Manage.waitUntilMethods(driver, "//i[@ng-click='vm.removeFile()']","","", "visible");
			Thread.sleep(5000);
			RC_Global.clickButton(driver, "Upload Template", true,false);
			if (sptConvtDt[1].substring(0, 1).contains("0")) {
				sptConvtDt[1] = sptConvtDt[1].substring(1, sptConvtDt[1].length());				
			}
			for (int i = 0; i < 10000; i++) {
				getVal = "";
				getVal = driver.findElement(By.xpath("(//div[@class='ui-grid-row ng-scope'])[1]//div[@role='gridcell'][7]/div")).getText();
				if (!(getVal.equals(cellVal)) && getVal.contains(newDate.substring(0, 10))) {
					break;
				}				
				if (driver.findElements(By.xpath("//div[contains(@data-ng-repeat,'errorMessage')]")).size()>0) {
					err = true;
					break;
				}
			}
			if (!err) {
				if (uploadType.equalsIgnoreCase("schedule")) {
					if (driver.findElements(By.xpath("//div[text() ='Scheduled']")).size()>0) {
						queryObjects.logStatus(driver, Status.PASS, "Upload is Scheduled successfully", "", null);
					}
				TimeUnit.MINUTES.sleep(1);			
				} else {
					TimeUnit.SECONDS.sleep(20);
					waitUntilUploadProcessing_MassUpload(driver, usrName, getDate);
				}
				
				//Verify the upload is successful
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",driver.findElement(By.xpath("//div[@title='Customer Number']/following-sibling::div//input[@ng-model='colFilter.term']")));
				driver.findElement(By.xpath("//div[@title='Customer Number']/following-sibling::div//input[@ng-model='colFilter.term']")).clear();
				driver.findElement(By.xpath("//div[@title='Customer Number']/following-sibling::div//input[@ng-model='colFilter.term']")).sendKeys(cusNum);
				driver.findElement(By.xpath("//div[@title='Template Name']/following-sibling::div//input[@ng-model='colFilter.term']")).clear();
				driver.findElement(By.xpath("//div[@title='Template Name']/following-sibling::div//input[@ng-model='colFilter.term']")).sendKeys(selTemplate);
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",driver.findElement(By.xpath("//div[@title='User Uploaded']/following-sibling::div//input[@ng-model='colFilter.term']")));
				driver.findElement(By.xpath("//div[@title='User Uploaded']/following-sibling::div//input[@ng-model='colFilter.term']")).clear();
				driver.findElement(By.xpath("//div[@title='User Uploaded']/following-sibling::div//input[@ng-model='colFilter.term']")).sendKeys(usrName);
				boolean isUpload = false; String curStatus = "";
				int rows = driver.findElements(By.xpath("(//div[@class='ui-grid-row ng-scope'])")).size();
				for (int i = 1; i <= rows; i++) {
					rowText = driver.findElement(By.xpath("(//div[@class='ui-grid-row ng-scope'])["+i+"]")).getText();
					if (rowText.contains(getDate.substring(0, 11)) && rowText.contains(usrName)) {
						curStatus = driver.findElement(By.xpath("(//div[@class='ui-grid-row ng-scope'])["+i+"]//div[9]/div[text()='"+usrName+"']/../preceding-sibling::div[4]/div")).getText();
						if (driver.findElements(By.xpath("(//div[@class='ui-grid-row ng-scope'])["+i+"]//div[9]/div[text()='"+usrName+"']/../preceding-sibling::div[4]/div[contains(text(),'Completed')]")).size()>0) {
							isUpload = true;
							break;
						}						
					}
				}
				if (isUpload) {
					queryObjects.logStatus(driver, Status.PASS, "Upload is successful", "Status of the uploaded file is "+curStatus, null);
				} else {
					queryObjects.logStatus(driver, Status.FAIL, "Upload failed or not yet completed", "Current status of the uploaded file is "+curStatus, null);
					RC_Global.endTestRun(driver);
				}
				
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",driver.findElement(By.xpath("//div[@ng-show='customerChosen']/input[@name='customerInput']")));
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",driver.findElement(By.xpath("//h5/span[text()='Mass Upload Portal']")));
			} else {
				try {
					queryObjects.logStatus(driver, Status.INFO, "Upload failed with error message", driver.findElement(By.xpath("//div[contains(@data-ng-repeat,'errorMessage')]/h4")).getText(), null);
				} catch (Exception e) {}				
			}		
			//RC_Manage.waitUntilMethods(driver, "//i[@ng-click='vm.removeFile()']","","", "invisible");
			RC_Manage.deleteFolder(driver, dir);
			return formatDate = sptConvtDt[0]+" "+sptConvtDt[1]+" "+sptConvtDt[2];
		} catch (Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Upload "+filePath+" file failed", e.getLocalizedMessage(), e);
		    RC_Global.endTestRun(driver);
		}
		return "";
	}
	
	public static String selTimeZoneNames(WebDriver driver, String timeZone) {
		String retVal = "";
		switch (timeZone) {
		case "America/New_York":
			retVal = "Eastern Standard Time (EST)";
			break;
		case "CST":
			retVal = "Central Standard Time (CST)";
			break;
		case "America/Denver":
			retVal = "Mountain Standard Time (MST)";
			break;
		case "PST":
			retVal = "Pacific Standard Time (PST)";
			break;
		case "HST":
			retVal = "Hawaii-Aleutian Standard Time (HAST)";
			break;
		
		}
		return retVal; 
	}
	
	public static void editEmployeeForm(WebDriver driver, String customer, String firstName, String lastName, String address1, String city, String state, String zipCode, String distributionMethod, String cellNumber, String email) throws Exception {
		try {

			WebElement eleCustomer = null;
	        if(driver.findElements(By.xpath("//div/label/../input[@name='customerInput']")).size()>0)
	               eleCustomer = driver.findElement(By.xpath("//div/label/../input[@name='customerInput']"));
	        else if(driver.findElements(By.xpath("//div[ul]//div[ul]/input[@name='customerInput']")).size()>0)
	               eleCustomer = driver.findElement(By.xpath("//div[ul]//div[ul]/input[@name='customerInput']"));
	        WebElement eleFirstName = driver.findElement(By.xpath("//div[label[text()='First Name *']]/div//input"));
	        WebElement eleLastName = driver.findElement(By.xpath("//div[label[text()='Last Name *']]/div//input"));
	        WebElement eleAddress1 = driver.findElement(By.xpath("//div[label[text()='Residential Address 1 *']]/div//input"));
	        WebElement eleCity = driver.findElement(By.xpath("//div[label[text()='City *']]/div//input"));
	        WebElement eleZipCode = driver.findElement(By.xpath("//div[label[text()='Zip Code *']]/div//input"));
	        WebElement eleCellNumber = driver.findElement(By.xpath("//div[label[text()='Cell Phone']]/div//input"));
	        WebElement eleEmail = driver.findElement(By.xpath("//div[label[text()='Email']]/div//input"));
	        
	        if(!(eleCustomer.getAttribute("value").contains(customer))) {
	               RC_Global.enterInput(driver, customer, eleCustomer, true,false);
	               Thread.sleep(500);
	               RC_Global.clickUsingXpath(driver, "//a[contains(@title,'"+customer+"')]", "Customer Selection", true,false);
	        }
	        RC_Global.enterInput(driver, firstName, driver.findElement(By.xpath("//div[label[text()='First Name *']]/div//input")), true,false);
	        RC_Global.enterInput(driver, lastName, eleLastName, true,false);
	        RC_Global.enterInput(driver, address1, eleAddress1, true,false);
	        RC_Global.enterInput(driver, city, eleCity, true,false);
	        RC_Global.selectDropdownOption(driver, "state", state, true,false);
	        RC_Global.enterInput(driver, zipCode, eleZipCode, true,false);
	        RC_Global.selectDropdownOption(driver, "distributionMethod", distributionMethod, true,false);
	        
	       if(distributionMethod.equalsIgnoreCase("Email")||distributionMethod.equalsIgnoreCase("Email & Text Message"))
	               RC_Global.enterInput(driver, email, eleEmail, true,false);
	        else if(distributionMethod.equalsIgnoreCase("Text Message")||distributionMethod.equalsIgnoreCase("Email & Text Message"))
	               RC_Global.enterInput(driver, cellNumber, eleCellNumber, true,false);
		} catch (Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Edit Employee Form is not successful", e.getLocalizedMessage(), e);
		    RC_Global.endTestRun(driver);
		}
	}
	
	public static void driverNameSelection(WebDriver driver, String cVNValue, boolean endTest) throws Exception{
		RC_Global.createNode(driver, "Driver Selection");
		String CustomerName="";
		String DriverNameChange="";
		String lastPg = ""; int pgNos = 1;
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		WebDriverWait wait = new WebDriverWait(driver,30);
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table//tbody//tr[1]")));
			List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("//table//tbody//tr")); 
			Thread.sleep(2000);
			driver.findElement(By.xpath("//a[text()='Last']")).click();
			Thread.sleep(1000);
			lastPg = driver.findElement(By.xpath("//li[@class='pagination-page ng-scope active']/a")).getText().trim();
			pgNos = Integer.parseInt(lastPg)-1;
			driver.findElement(By.xpath("//a[text()='First']")).click();
			for (int p = 1; p <= pgNos; p++) {
				int rowcnt=Getgridrowcnt.size();
				boolean firstpage=false;
				Thread.sleep(2000);
				for(int i=1; i<rowcnt;i++) {				
					WebElement sub= driver.findElement(By.xpath("//tr["+i+"]//td[4]"));
					Thread.sleep(2000);
					String CVN = sub.getText();
					if(CVN.isEmpty() && cVNValue.equalsIgnoreCase("blank")) {
						WebElement driverclmn =driver.findElement(By.xpath("//tbody//tr["+i+"]//td[5]"));
						Thread.sleep(2000);
						drivername =driverclmn.getText();
						Thread.sleep(1000);
						if(!(drivername.equalsIgnoreCase("Unassigned") || drivername.contains("Pool")||drivername.contains("Unknown")||drivername.contains("Catering")) ) {
							//    driver.findElement(By.xpath("//tbody//tr["+i+"]//td[5]")).click();
							executor.executeScript("arguments[0].click();", driverclmn);
							Thread.sleep(1000);
							firstpage = true;
							break;
						}}
						else if(!CVN.isEmpty() && !(cVNValue.equalsIgnoreCase("blank"))) {
							
								WebElement driverclmn =driver.findElement(By.xpath("//tbody//tr["+i+"]//td[5]"));
								Thread.sleep(2000);
								drivername =driverclmn.getText();
								Thread.sleep(1000);
							if(!(drivername.equalsIgnoreCase("Unassigned") || drivername.contains("Pool")||drivername.contains("Unknown")||drivername.contains("Catering")) ) {
								//    driver.findElement(By.xpath("//tbody//tr["+i+"]//td[5]")).click();
								executor.executeScript("arguments[0].click();", driverclmn);
								Thread.sleep(1000);
								firstpage = true;
								break;
							}
						}
					}
				if(firstpage) {
					queryObjects.logStatus(driver, Status.PASS, "Searching Required grid record from Webtable", "Successful", null);
					break;
				} else {
					driver.findElement(By.xpath("//li/a[text()='Next']")).click();
				}
			}
			  
			
			

		}catch (Exception e){
			queryObjects.logStatus(driver, Status.FAIL, "Searching Required grid record from Webtable", e.getLocalizedMessage(), e);
			if(endTest)
				RC_Global.endTestRun(driver);
		}
	}
	
	public static void historyValidation(WebDriver driver,String loggedUser, boolean endTest) throws Exception
	{
		try {
			String modifiedBy = driver.findElement(By.xpath("(//table/tbody/tr/td)[5]")).getText();
			if(modifiedBy.equals(loggedUser))
			{
				RC_Global.clickUsingXpath(driver, "(//table/tbody/tr)[1]/td[1]", "Client Data", false,false);
			}
		}
		catch (Exception e){
			queryObjects.logStatus(driver, Status.FAIL, "Histroy validation Failed", e.getLocalizedMessage(), e);
			if(endTest)
				RC_Global.endTestRun(driver);
		}
		
	}
	
	
	public static String getOwnerDropdownValue(WebDriver driver, boolean endTest) throws Exception
		{
			Select s=new Select(driver.findElement(By.xpath("(//select[@ng-model='data.clientDataValue.FieldValueText'])[1]")));
			System.out.println(s.getFirstSelectedOption().getText());
			return s.getFirstSelectedOption().getText();
		}
	
	public static void changeOwner(WebDriver driver, String oldOwnerDropdownValue,boolean endTest) throws Exception {
		try {
			Select s=new Select(driver.findElement(By.xpath("(//select[@ng-model='data.clientDataValue.FieldValueText'])[1]")));
			List<WebElement> owners = s.getOptions();
			
			for(WebElement ele:owners)
			{
				if(!ele.getText().equals(oldOwnerDropdownValue) && !ele.getText().equals(""))
				{
					s.selectByVisibleText(ele.getText());
					break;
				}
			}
		}
	
		catch (Exception e){
			queryObjects.logStatus(driver, Status.FAIL, "Owner change Failed", e.getLocalizedMessage(), e);
			if(endTest)
				RC_Global.endTestRun(driver);
		}
	}
	
	public static List<String> getDriverInformation(WebDriver driver,boolean endCaseAbruptlyIfExceptionOrFail) throws Exception
	{
		try {
			Thread.sleep(1000);
			String Address1 = driver.findElement(By.xpath("//input[@name='residentialAddress1Text']")).getAttribute("value");
			String city = driver.findElement(By.xpath("//input[@name='residentialCityName']")).getAttribute("value");
			Select stateDropDown = new Select(driver.findElement(By.xpath("(//select[@name='garagingState'])[1]")));
			String state=stateDropDown.getFirstSelectedOption().getText();
			String zip = driver.findElement(By.xpath("//input[@name='residentialZip']")).getAttribute("value");
			String county = driver.findElement(By.xpath("//input[@name='residentialCounty']")).getAttribute("value");
			Select countryDropDown = new Select(driver.findElement(By.xpath("//select[@name='residentialCountry']")));
			String country=countryDropDown.getFirstSelectedOption().getText();
			List<String> driverInfo=new ArrayList<String>();
			driverInfo.add(Address1);
			driverInfo.add(city);
			driverInfo.add(state);
			driverInfo.add(zip);
			/*
			 * driverInfo.add(county); driverInfo.add(country);
			 */
			return driverInfo;
		} catch (Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Get Driver Data is not successful", e.getLocalizedMessage(), e);
		    RC_Global.endTestRun(driver);
		}
		return  null;
		
	}
	public static List<String> getVehicleAddress(WebDriver driver,boolean endCaseAbruptlyIfExceptionOrFail) throws Exception
	{
		try {
			String Address1 = driver.findElement(By.xpath("//input[@name='vehicleAddressLine1']")).getAttribute("value");
			String city = driver.findElement(By.xpath("//input[@name='vehicleCity']")).getAttribute("value");
			Select stateDropDown = new Select(driver.findElement(By.xpath("//select[@name='vehicleState']")));
			String state=stateDropDown.getFirstSelectedOption().getText();
			String zip = driver.findElement(By.xpath("//input[@name='vehicleZip']")).getAttribute("value");
			String county = driver.findElement(By.xpath("//input[@name='vehicleCounty']")).getAttribute("value");
			Select countryDropDown = new Select(driver.findElement(By.xpath("//select[@name='vehicleCountry']")));
			String country=countryDropDown.getFirstSelectedOption().getText();
			List<String> vehicleAddress=new ArrayList<String>();
			vehicleAddress.add(Address1);
			vehicleAddress.add(city);
			vehicleAddress.add(state);
			vehicleAddress.add(zip);
			/*
			 * vehicleAddress.add(county); vehicleAddress.add(country);
			 */
			return vehicleAddress;
		} catch (Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Get Vehicle address info is not successful", e.getLocalizedMessage(), e);
		    RC_Global.endTestRun(driver);
		}
		return  null;
	}
	
	public static void searchEmployee(WebDriver driver, String customer, String firstName, String lastName, String address1, String city, String state, String zipCode, String email) throws Exception
	{
		try {
			WebElement eleFirstName = driver.findElement(By.xpath("//input[@placeholder='Employee First Name']"));
	        WebElement eleLastName = driver.findElement(By.xpath("//input[@placeholder='Employee Last Name']"));
	        WebElement eleAddress1 = driver.findElement(By.xpath("//input[@placeholder='Address']"));
	        WebElement eleCity = driver.findElement(By.xpath("//input[@placeholder='City']"));
	        WebElement eleZipCode = driver.findElement(By.xpath("//input[@placeholder='Zip']"));
	        WebElement eleEmail = driver.findElement(By.xpath("//input[@placeholder='Email']"));
	        
	        RC_Global.enterCustomerNumber(driver, customer, "","", false);
	        RC_Global.enterInput(driver, firstName, eleFirstName, true,false);
	        RC_Global.enterInput(driver, lastName, eleLastName, true,false);
	        RC_Global.enterInput(driver, address1, eleAddress1, true,false);
	        RC_Global.enterInput(driver, city, eleCity, true,false);
	        RC_Global.selectDropdownOption(driver, "State", state, true,false);
	        RC_Global.enterInput(driver, zipCode, eleZipCode, true,false);
	        RC_Global.enterInput(driver, email, eleEmail, true,false);
		} catch (Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Search Employee is not successful", e.getLocalizedMessage(), e);
		    RC_Global.endTestRun(driver);
		}
	}
	
	public static boolean newEmployeeValidation(WebDriver driver,String customer, String firstName, String lastName, String address1, String city, String state, String zipCode) throws Exception
	{
		try {
		String rowCustomerNo = driver.findElement(By.xpath("((//table/tbody/tr)[1])/td[1]")).getText();
		String rowFirstName = driver.findElement(By.xpath("((//table/tbody/tr)[1])/td[3]")).getText();
		String rowLastName = driver.findElement(By.xpath("((//table/tbody/tr)[1])/td[4]")).getText();
		String rowAddress = driver.findElement(By.xpath("((//table/tbody/tr)[1])/td[9]")).getText();
		String rowCity = driver.findElement(By.xpath("((//table/tbody/tr)[1])/td[10]")).getText();
		String rowState = driver.findElement(By.xpath("((//table/tbody/tr)[1])/td[11]")).getText();
		String rowZip = driver.findElement(By.xpath("((//table/tbody/tr)[1])/td[12]")).getText();
		
		if(rowCustomerNo.equals(customer) && rowFirstName.equals(firstName) && rowLastName.equals(lastName) && 
				rowAddress.equals(address1) && rowCity.equals(city) && rowState.equals(state) && rowZip.equals(zipCode))
			return true;
		else
			return false;
		} catch (Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "New Employee validation failed", e.getLocalizedMessage(), e);
		    RC_Global.endTestRun(driver);
		}
		return false;
		
	}
	
	public static void employeeGridSelection (WebDriver driver, String UserName, String Record, boolean endRun) throws Exception{
		RC_Global.createNode(driver, "Employee Selection");
		String CustomerName="";
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		WebDriverWait wait = new WebDriverWait(driver,60);
		try {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table//tbody//tr[1]")));
		List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("//table//tbody//tr"));
		Thread.sleep(2000);
		int rowcnt=Getgridrowcnt.size();
		boolean firstpage=false;
		Thread.sleep(2000);
		for(int i=1; i<rowcnt;i++) {
		WebElement userclm= driver.findElement(By.xpath("//tr["+i+"]//td[14]/a"));
		String Contact = driver.findElement(By.xpath("//tr["+i+"]//td[5]")).getText();
		Thread.sleep(2000);
		Username = userclm.getText();
		if (UserName.equalsIgnoreCase("Yes")) {
		if(!Username.isEmpty()) {
			if(Contact.isEmpty()) {
			WebElement emp = driver.findElement(By.xpath("//tbody//tr["+i+"]//td[8]"));
			EmpAssignment = emp.getText();
			WebElement driverF = driver.findElement(By.xpath("(//tbody/tr["+i+"]/td[3])[1]"));
			WebElement driverL = driver.findElement(By.xpath("(//tbody/tr["+i+"]/td[4])[1]"));
			driverFirstName = driverF.getText();
			driverLastName = driverL.getText();
			executor.executeScript("arguments[0].click();", userclm);
			Thread.sleep(1000);
			firstpage = false;
			break;
		}
		} }
		firstpage = true;
		if (Record.equalsIgnoreCase("Yes")) {
		WebElement driverclmn = driver.findElement(By.xpath("//tbody//tr["+i+"]//td[3]"));

		executor.executeScript("arguments[0].click();", driverclmn);
		Thread.sleep(1000);
		firstpage = false;
		break;
		}
		}
		if(firstpage)
		queryObjects.logStatus(driver, Status.PASS, "Searching Required grid record from Webtable", "Successful", null);

		}catch (Exception e){
		queryObjects.logStatus(driver, Status.FAIL, "Searching Required grid record from Webtable", e.getLocalizedMessage(), e);
		if(endRun)
		RC_Global.endTestRun(driver);
		}
	}
	
	public static void UserDetailSectionValidation(WebDriver driver, String sectioName, String labelText, boolean endCaseAbruptlyIfExceptionOrFail) throws Exception{
		RC_Global.createNode(driver, "User Detail Screen Validation");
		 try {
			 String dataDetails = "";
				switch (sectioName) {
				case "User Information":
					//label[text()='Date Created']/../following-sibling::div/span
					//label[text()='"+labelText+"']/../following-sibling::div/span
				       if(driver.findElements(By.xpath("//label[text()='"+labelText+"']/../following-sibling::div/span")).size()>0)
				              {
				                     dataDetails = driver.findElement(By.xpath("//label[text()='"+labelText+"']/../following-sibling::div/span")).getText();
				                     if(dataDetails.length()==0)
				                     {      
				                     queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with ", "empty value",null);                  
				                     }
				                     else
				                     {
				                     queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with value",dataDetails, null);
				                     }
				              }
				     //label[normalize-space(text())='"+labelText+"]/../following-sibling::input
				              else if(driver.findElements(By.xpath("//label[normalize-space(text())='"+labelText+"']/../following-sibling::input")).size()>0)
				              {
				                     dataDetails = driver.findElement(By.xpath("//label[normalize-space(text())='"+labelText+"']/../following-sibling::input")).getText();
				                     if(dataDetails.length()==0)
				                     {      
				                     queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with ", "empty value",null);                  
				                     }
				                     else
				                     {
				                     queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with value",dataDetails, null); 
				                     }
				              }
				              else if(driver.findElements(By.xpath("//label[normalize-space(text())='"+labelText+"']/../following-sibling::div/label[contains(@class,'active')]")).size()>0)
				              {
				                     dataDetails = driver.findElement(By.xpath("//label[normalize-space(text())='"+labelText+"']/../following-sibling::div/label[contains(@class,'active')]")).getText();
				                     if(dataDetails.length()==0)
				                     {      
				                     queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with ", "empty value",null);                  
				                     }
				                     else
				                     {
				                     queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with value",dataDetails, null); 
				                     }
				              }
				       break;
				case "Security":
				     //label[normalize-space(text())='Role']/following-sibling::select/option[@selected='selected']
					if(driver.findElements(By.xpath("//label[normalize-space(text())='"+labelText+"']/following-sibling::select/option[@selected='selected']")).size()>0)
		              {
		                     dataDetails = driver.findElement(By.xpath("//label[normalize-space(text())='"+labelText+"']/following-sibling::select/option[@selected='selected']")).getText();
		                     if(dataDetails.length()==0)
		                     {      
		                     queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with ", "empty value",null);                  
		                     }
		                     else
		                     {
		                     queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with value",dataDetails, null);
		                     }
		              }
				              break;
				}
		 	}
		 catch(NullPointerException npe) {
			 queryObjects.logStatus(driver, Status.FAIL, "The lable :"+labelText+" is not found in section "+sectioName, npe.getLocalizedMessage(), npe);
			 if(endCaseAbruptlyIfExceptionOrFail)
			 RC_Global.endTestRun(driver);
		}
			
	}
	
	public static void PermissionDetail(WebDriver driver, String Module, String Menu, String subMenu, boolean endCaseAbruptlyIfExceptionOrFail) throws Exception{
		RC_Global.createNode(driver, "Validation of Permission Detail");		
		 try {
			 String data = "";			
				//	RC_Global.clickUsingXpath(driver, "(//h4[text()='Permissions Details']/following::span[normalize-space(text())='"+Module+"'])[1]", ""+Module+" hyperlink", endCaseAbruptlyIfExceptionOrFail);
				switch (Menu) {
				
				case "Acquisition Menu":
					
					if(driver.findElements(By.xpath("//span[normalize-space(text())='"+subMenu+"']/../following::div[2]/select/option[@selected='selected']")).size()>0)
		              {
																																									  
		                     data = driver.findElement(By.xpath("//span[normalize-space(text())='"+subMenu+"']/../following::div[2]/select/option[@selected='selected']")).getText();
		                     if(data.length()==0)
		                     {      
		                     queryObjects.logStatus(driver,Status.PASS,"Module :"+Module+" has submenu label "+subMenu+" with ", "empty value",null);                  
		                     }
		                     else
		                     {
		                     queryObjects.logStatus(driver,Status.PASS,"Module :"+Module+" has submenu label "+subMenu+" with value",data, null);
		                     }
		              }
				      break;
				case "Driver Order":
					
					if(driver.findElements(By.xpath("//span[normalize-space(text())='"+subMenu+"']/../following::div[2]/select/option[@selected='selected']")).size()>0)
		              {
		                     data = driver.findElement(By.xpath("//span[normalize-space(text())='"+subMenu+"']/../following::div[2]/select/option[@selected='selected']")).getText();
		                     if(data.length()==0)
		                     {      
		                     queryObjects.logStatus(driver,Status.PASS,"Module :"+Module+" has submenu label "+subMenu+" with ", "empty value",null);                  
																																																									   
		                     }
		                     else
		                     {
		                     queryObjects.logStatus(driver,Status.PASS,"Module :"+Module+" has submenu label "+subMenu+" with value",data, null);
		                     }
		              }
					break;
				case "Factory Order":
					if(driver.findElements(By.xpath("//span[normalize-space(text())='"+subMenu+"']/../following::div[2]/select/option[@selected='selected']")).size()>0)
		              {
		                     data = driver.findElement(By.xpath("//span[normalize-space(text())='"+subMenu+"']/../following::div[2]/select/option[@selected='selected']")).getText();
		                     if(data.length()==0)
		                     {      
		                     queryObjects.logStatus(driver,Status.PASS,"Module :"+Module+" has submenu label "+subMenu+" with ", "empty value",null);                  
		                     }
		                     else
		                     {
		                     queryObjects.logStatus(driver,Status.PASS,"Module :"+Module+" has submenu label "+subMenu+" with value",data, null);
		                     }
		              }
					break;
		 		}
		 	}
		 catch(NullPointerException npe) {
			 queryObjects.logStatus(driver, Status.FAIL, "The lable :"+subMenu+" is not found in section "+Module, npe.getLocalizedMessage(), npe);
			 if(endCaseAbruptlyIfExceptionOrFail)
			 RC_Global.endTestRun(driver);
		 }
	}
	
	public static void searchFilters (WebDriver driver,String custNum, String Filtername,String Input,String Searchscreen,String ResultScreen, String Navigation1,String Navigation2,String Navigation3, boolean endRun) throws Exception{
		// WebElement SearchFilter = driver.findElement(By.xpath("//input[@placeholder='"+Filtername+"']"));	
		try {
	    	//
			
	    	if(driver.findElements(By.xpath("//div[@class='panel-chrome']/h5/span[text()='"+Searchscreen+"']")).size()>0) {
	    		RC_Global.enterCustomerNumber(driver, custNum, "", "",true);
	    //	WebElement SearchFilter = driver.findElement(By.xpath("//input[@placeholder='"+Filtername+"']"));
	  		RC_Global.enterInput(driver, Input, driver.findElement(By.xpath("//input[@placeholder='"+Filtername+"']")), false,false);
	  	//	RC_Global.clickButton(driver, "Search",false);
	  		RC_Global.clickUsingXpath(driver, "//button[text()='Search']", "Search button", endRun,false);
			Thread.sleep(1000);
			try {
				WebDriverWait wait = new WebDriverWait(driver,30);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'"+ResultScreen+"')]")));
			} catch (Exception e) {}
			
			
			 if(driver.findElements(By.xpath("//span[contains(text(),'"+ResultScreen+"')]")).size()>0)
				{
					 //RC_Global.waitElementVisible(driver,30,"//span[text()='"+ResultScreen+"']",""+ResultScreen+" screen",false);
				// RC_Global.panelAction(driver, "close", ""+ResultScreen+"", false);
				 	queryObjects.logStatus(driver, Status.PASS, Filtername+" Search data displayed - Driver Details", "Successfully", null);
					 driver.findElement(By.xpath("//h5[span[contains(text(),'"+ResultScreen+"')]]/i[@ng-click='closePanel()']")).click();
				}
				else if(driver.findElements(By.xpath("//div[@class='panel-chrome']/h5/span[text()='"+Searchscreen+"']")).size()>0)																				  
				{
					if (driver.findElements(By.xpath("//table/tbody/tr")).size()>0) {
						queryObjects.logStatus(driver, Status.PASS, Filtername+" Search grid results displayed", "Successfully", null);
					} else {
						queryObjects.logStatus(driver, Status.FAIL, Filtername+" Search grid results is not displayed for Driver -"+Input, "Failed", null);
					}
			//	RC_Global.clickButton(driver, "Reset",false);
				RC_Global.clickUsingXpath(driver, "//button[text()='Reset']", "Reset button", endRun,false);
																															
				}
	    	}
	    	
	  		else 
	  		{
	  		RC_Global.navigateTo(driver, ""+Navigation1+"", ""+Navigation2+"", ""+Navigation3+"");
	  	//	WebElement SearchFilter = driver.findElement(By.xpath("//input[@placeholder='"+Filtername+"']"));
	  		RC_Global.enterCustomerNumber(driver, custNum, "", "",true);
	  		RC_Global.enterInput(driver, Input, driver.findElement(By.xpath("//input[@placeholder='"+Filtername+"']")), false, false);
	  		RC_Global.clickButton(driver, "Search",false, false);	  		
			Thread.sleep(3000);
			try {
				WebDriverWait wait = new WebDriverWait(driver,30);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'"+ResultScreen+"')]")));
			} catch (Exception e) {}
				if(driver.findElements(By.xpath("//span[text()='"+ResultScreen+"']")).size()>0)
				{
//					RC_Global.panelAction(driver, "close", ""+ResultScreen+"", false);
					queryObjects.logStatus(driver, Status.PASS, Filtername+" Search value displayed - Driver Details", "Successfully", null);
					 driver.findElement(By.xpath("//h5[span[text()='"+ResultScreen+"']]/i[@ng-click='closePanel()']")).click();
				}
				else if(driver.findElements(By.xpath("//div[@class='panel-chrome']/h5/span[text()='"+Searchscreen+"']")).size()>0)
					{	
					if (driver.findElements(By.xpath("//table/tbody/tr")).size()>0) {
						queryObjects.logStatus(driver, Status.PASS, Filtername+" Search grid results displayed", "Successfully", null);
					} else {
						queryObjects.logStatus(driver, Status.FAIL, Filtername+" Search grid results is not displayed for Driver -"+Input, "Failed", null);
					}
				//	RC_Global.clickButton(driver, "Reset",false);
					RC_Global.clickUsingXpath(driver, "//button[text()='Reset']", "Reset button", endRun, false);
					}
	  		}
	    	  queryObjects.logStatus(driver, Status.PASS, "Search Results are", "Found", null);
	      }
	      
	      catch(Exception e) {
	            queryObjects.logStatus(driver, Status.FAIL, "Unable to validate Search Filters", e.getLocalizedMessage(), e);
	            if(endRun)
	            	RC_Global.endTestRun(driver);
	        }
	}
	
	public static void selectUserName(WebDriver driver) throws Exception {
	     List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("//tr[@ng-click='employeeSelected(data)']//td[@class='ng-binding'][1]"));
	     Thread.sleep(2000);
	     int rowcnt=Getgridrowcnt.size();
	     boolean firstpage=false;
	     boolean pagination=false;
	     for(int i=1; i<rowcnt;i++) {
	   
	             WebElement VendorNameRecord =    driver.findElement(By.xpath("(//tr[@ng-click='employeeSelected(data)']//td[contains(@ng-if,'UserSetup')])["+i+"]"));
	             Thread.sleep(1000);
	             String NonAutoIms =    VendorNameRecord.getText();
	             Thread.sleep(1000);
	             if(!NonAutoIms.equalsIgnoreCase(" ")) {
	               driver.findElement(By.xpath("(//tr[@ng-click='employeeSelected(data)']//td[contains(@ng-if,'UserSetup')])[\"+i+\"]")).click();
	               Thread.sleep(1000);
	               firstpage = false;
	             break;}
	             firstpage = true;
	     }
	     if(firstpage)
	     {  
	         String NextBttn = driver.findElement(By.xpath("//a[text()='Next']")).getAttribute("ng-disabled");
	         while(!NextBttn.equals("ngDisabled")) {
	             driver.findElement(By.xpath("(//a[text()='Next'])[1]")).click();
	             Thread.sleep(3000);
	             for(int j=1; j<=rowcnt;j++) {
	                 WebElement VendorNameRecord =    driver.findElement(By.xpath("(//tr[@ng-click='employeeSelected(data)']//td[contains(@ng-if,'UserSetup')])["+j+"]"));
	                 Thread.sleep(1000);
	                 String NonAutoIms =    VendorNameRecord.getText();
	                 Thread.sleep(1000);
	                 if(!NonAutoIms.equalsIgnoreCase(" ")) {
	                   driver.findElement(By.xpath("(//tr[@ng-click='employeeSelected(data)']//td[contains(@ng-if,'UserSetup')])["+j+"]")).click();
	                   Thread.sleep(1000);
	                   pagination=false;
	                   break;
	             }else
	                 pagination=true;
	         if(pagination){
	             NextBttn =  driver.findElement(By.xpath("//a[text()='Next']")).getAttribute("ng-disabled");
	         }
	         else {
	         break;}
	         }
	     }
	     }}
	 public static void employeeGridSelection (WebDriver driver,boolean endRun) throws Exception{
	     RC_Global.createNode(driver, "UserName Selection");
	     String CustomerName="";
	     String DriverNameChange="";
	     String message = "Changing states requires entering an accurate valid odometer. Most states require you to update your address on file within 30 days. Do you want to process a state change with this request?";
	     JavascriptExecutor executor = (JavascriptExecutor) driver;
	     WebDriverWait wait = new WebDriverWait(driver,30);
	     try {
	         wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table//tbody//tr[1]")));
	         List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("//table//tbody//tr"));  
	         Thread.sleep(2000);
	         int rowcnt=Getgridrowcnt.size();
	         boolean  firstpage=false;
	         Thread.sleep(2000);
	         for(int i=1; i<rowcnt;i++) {
	             WebElement sub= driver.findElement(By.xpath("//tr["+i+"]//td[14]"));
	             Thread.sleep(2000);
	             String Username = sub.getText();
	             if(!Username.isEmpty()) {
	                 WebElement driverclmn = driver.findElement(By.xpath("//tbody//tr["+i+"]//td[3]"));
	                 Thread.sleep(2000);
	                 drivername = driverclmn.getText();
	                 Thread.sleep(1000);
	                 if(!(drivername.equalsIgnoreCase("Unassigned") || drivername.contains("Pool")||drivername.contains("Unknown")||drivername.contains("Catering")) ) {
	              //    driver.findElement(By.xpath("//tbody//tr["+i+"]//td[5]")).click();
	           //      executor.executeScript("arguments[0].click();", driverclmn);
	                 Thread.sleep(1000);
	                 firstpage = false;
	                 break;}
	               }  

	             firstpage = true;
	         }
	         if(firstpage)
	         queryObjects.logStatus(driver, Status.PASS, "Searching Required grid record from Webtable", "Successful", null);   
	     }catch (Exception e){
	         queryObjects.logStatus(driver, Status.FAIL, "Searching Required grid record from Webtable", e.getLocalizedMessage(), e);
	          if(endRun)
	                    RC_Global.endTestRun(driver);
	     }
	     Thread.sleep(2000);       
	 }
	 
	 public static String ClientDataGridSelection(WebDriver driver, String getStatus, boolean endRun) throws Exception {
		 String clientDataNm = "" ;
			RC_Global.createNode(driver, "Client  Data  Grid row selection");
			try {
				List<WebElement> Gridrowcnt = driver.findElements(By.xpath("//table/tbody/tr"));
				for (int i=1; i<=Gridrowcnt.size();i++) {
					WebElement row = driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td[6]/span"));
					String cStatus = driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td[7]/span")).getText().trim();
					if(cStatus.equals(getStatus)){
						clientDataNm = driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td[2]")).getText().trim();
						row.click();
						queryObjects.logStatus(driver, Status.PASS, "Searching required grid record from webtable", "Successful", null);
						break;
					}
				}
			}		
			catch (Exception e){
				queryObjects.logStatus(driver, Status.FAIL, "Searching required grid record from webtable", e.getLocalizedMessage(), e);
				if(endRun)
					RC_Global.endTestRun(driver);
				}
			return clientDataNm;
	}
	 
	 public static String ResetClientDataSelection(WebDriver driver, String selName, boolean endRun) throws Exception {
		 String clientDataNm = "" ;
			RC_Global.createNode(driver, "Client  Data  Grid row selection");
			try {
				List<WebElement> Gridrowcnt = driver.findElements(By.xpath("//table/tbody/tr"));
				for (int i=1; i<=Gridrowcnt.size();i++) {
					WebElement row = driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td[6]/span"));
					String cellName = driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td[2]")).getText().trim();
							
					if(cellName.equalsIgnoreCase(selName)){
						clientDataNm = driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td[2]")).getText().trim();
						row.click();						
						break;
					}
				}
				queryObjects.logStatus(driver, Status.PASS, "Searching required grid record from webtable", "Successful", null);
			}		
			catch (Exception e){
				queryObjects.logStatus(driver, Status.FAIL, "Searching required grid record from webtable", e.getLocalizedMessage(), e);
				if(endRun)
					RC_Global.endTestRun(driver);
				}
			return clientDataNm;
	}
	 public static void VerifyUsernameCreatedDate(WebDriver driver, boolean endRun) throws Exception
		{
			RC_Global.createNode(driver, "Username and Created date verification in Client Data History page");
			try {
				String currentDate = AddDateStr(0, "MMM d, yyyy", "", null, "CST");//updated
				String modifiedBy=driver.findElement(By.xpath("((//table/tbody/tr)[1]/td)[5]")).getText();
				String recordDateTime=driver.findElement(By.xpath("((//table/tbody/tr)[1]/td)[2]")).getText().substring(0, 12).trim();

				if(modifiedBy.toUpperCase().contains(RC_Global.userLogged))
				{
					queryObjects.logStatus(driver, Status.PASS, "User's name is displayed in the first row", modifiedBy, null);
				}
				else
				{
					queryObjects.logStatus(driver, Status.FAIL, "User's name is not displayed in the first row", "", null);
				}
				if(recordDateTime.trim().equals(currentDate.trim()))
				{
					queryObjects.logStatus(driver, Status.PASS, "Current date is displayed as created date", "Current date"+currentDate+" Created date"+recordDateTime, null);
				}
				else
				{
					queryObjects.logStatus(driver, Status.FAIL, "Current date is not displayed as created date", "Current date"+currentDate+" Created date"+recordDateTime, null);
				}
				queryObjects.logStatus(driver, Status.PASS, "Username and Created date verification in Client Data History page", "Successful", null);
			}
			catch (Exception e){
				queryObjects.logStatus(driver, Status.FAIL, "Username and created date verification failed", e.getLocalizedMessage(), e);
				if(endRun)
					RC_Global.endTestRun(driver);
			}
		}
	 public static void driverSelectionFromDifferentState(WebDriver driver,String State, boolean endTest) throws Exception{
	        RC_Global.createNode(driver, "Driver Selection From Different State");
	        String CustomerName="";
	        String DriverNameChange="";
	        JavascriptExecutor executor = (JavascriptExecutor) driver;
	        WebDriverWait wait = new WebDriverWait(driver,60);
	        try {
	            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table//tbody//tr[1]")));
	            List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("//table//tbody//tr"));  
	            Thread.sleep(2000);
	            int rowcnt=Getgridrowcnt.size();
	            boolean firstpage=false;
	            Thread.sleep(2000);
	            for(int i=1; i<rowcnt;i++) {
	                WebElement sub= driver.findElement(By.xpath("//tr["+i+"]//td[7]"));
	                Thread.sleep(2000);
	                String employeeState = sub.getText();
	                if(!(employeeState.equals(State))) 
	                {    
	                    Thread.sleep(2000);
	                    executor.executeScript("arguments[0].click();", sub);
	                    Thread.sleep(1000);
	                    firstpage = true;
	                    break;
	                }
	            }
	            if(firstpage)
	                queryObjects.logStatus(driver, Status.PASS, "Searching Required grid record from Webtable", "Successful", null);

	        }catch (Exception e){
	            queryObjects.logStatus(driver, Status.FAIL, "Searching Required grid record from Webtable", e.getLocalizedMessage(), e);
	            if(endTest)
	                RC_Global.endTestRun(driver);
	        }
	    }
	 	
	 public static ArrayList<String> sorting_ColumnNames(WebDriver driver, String filePath, String columnName) throws Exception {
         try {
                RC_Global.createNode(driver, "Validate the "+columnName+"r column is sorted in ascending order in Downloaded Excel");
                String colNA = ""; String colName = ""; String tempColNm = ""; int colNo = 0; 
	       FileInputStream fis = new FileInputStream(filePath);
	       XSSFWorkbook wb = new XSSFWorkbook(fis); 
	       ArrayList<String> UnitNumList=new ArrayList<String>();
	       XSSFSheet sh = wb.getSheetAt(1);
	       int roww = sh.getLastRowNum(); 
	       int cols= sh.getRow(2).getLastCellNum();
	       for (int c = 0; c < cols; c++) {
        	   tempColNm = sh.getRow(2).getCell(c).getStringCellValue();
        	   if (tempColNm.equalsIgnoreCase(columnName)) {
         		  colNo = c;
         		  break;
         	  } 
           }
        	   
	       boolean columnValue = false;
	       for (int i = 5; i < roww+1; i++) {
	               XSSFCell ccell = sh.getRow(i).getCell(colNo);
	               colName = ccell.getStringCellValue();  
	               UnitNumList.add(colName);
	               }
	       
	       if (UnitNumList.isEmpty() || UnitNumList.size() == 1) {
	               columnValue = true;
	           }
	           Iterator<String> iter = UnitNumList.iterator();
	           String current, previous = iter.next();
	           while (iter.hasNext()) {
	               current = iter.next();
	               if(!current.isEmpty()){
	               if (previous.compareTo(current) <= 0) {
	                    columnValue = true;
	               }
	               else {
	                    columnValue = false;      
	                    break;}
	               previous = current;}
	           }
	          
	       fis.close();
	       if (columnValue) {
	                queryObjects.logStatus(driver, Status.PASS, columnName+" in Excel", "are sorted in Ascending Order", null);
	                } else {
	                queryObjects.logStatus(driver, Status.FAIL, columnName+" in Excel", "are not sorted in Ascending Order", null);
	                }
	       return UnitNumList;
		}
		         
		         catch (Exception e) {
		   queryObjects.logStatus(driver, Status.FAIL, columnName+" Column sort validation failed", e.getLocalizedMessage(), e);
		       RC_Global.endTestRun(driver);
		}
	  
	  return null;
	  }

	 public static void SearchEmployee_EmployeeManagement(WebDriver driver, String empFName, String empLName, String empID, String emailID, String resAddr) throws Exception{
		 RC_Global.createNode(driver, "Search Employee from Employee Management");
		 driver.findElement(By.xpath("//input[@id='employeeFirstName']")).sendKeys(empFName);
		 driver.findElement(By.xpath("//input[@id='employeeLastName']")).sendKeys(empLName);
		 driver.findElement(By.xpath("//input[@id='employeeID']")).sendKeys(empID);
		 driver.findElement(By.xpath("//input[@id='email']")).sendKeys(emailID);
		 driver.findElement(By.xpath("//input[@id='addressLine1']")).sendKeys(resAddr);
		 driver.findElement(By.xpath("//button[text()='Search']")).click();
		 RC_Manage.waitUntilMethods(driver, "//div[@ng-show='tableDataLoading']","class","ng-hide", "attribute visible");
		 if (driver.findElements(By.xpath("//table//tr[contains(@ng-click,'employeeSelected')]")).size()>0) {
			 RC_Global.clickUsingXpath(driver, "//tbody//tr[1]//td[1]", "Record from grid", true, true);			 
		 }
		 if (driver.findElements(By.xpath("//h5/span[text()='Edit Employee']")).size()>0) {				 
			 queryObjects.logStatus(driver, Status.PASS, " Column sort validation failed", "", null);
			 RC_Global.panelAction(driver, "expand", "Edit Employee", true, true);
		 } else {
			 queryObjects.logStatus(driver, Status.FAIL, " Column sort validation failed", "", null);
		 }
		
	 }
	 
	 public static void SetPinPool_Search(WebDriver driver, String empFName, String empLName, String empID, String emailID, String resAddr) throws Exception{
		 RC_Global.createNode(driver, "Search Employee from Employee Management");
		 driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys(empFName);
		 driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys(empLName);
		 driver.findElement(By.xpath("//input[@placeholder='Employee ID']")).sendKeys(empID);
		 
		 if (driver.findElements(By.xpath("//table//tr[contains(@ng-click,'employeeSelected')]")).size()>0) {
			 RC_Global.clickUsingXpath(driver, "//tbody//tr[1]//td[1]", "Record from grid", true, true);			 
		 }
		 if (driver.findElements(By.xpath("//h5/span[text()='Edit Employee']")).size()>0) {				 
			 queryObjects.logStatus(driver, Status.PASS, " Column sort validation failed", "", null);
			 RC_Global.panelAction(driver, "expand", "Edit Employee", true, true);
		 } else {
			 queryObjects.logStatus(driver, Status.FAIL, " Column sort validation failed", "", null);
		 }
		
	 }

	 public static void CreateEmployee(WebDriver driver,String FirstNam,String LastNam, boolean endRun) throws Exception{
		 RC_Global.createNode(driver, "Create new Employee from Employee Management");
	       try {
	              WebElement FirstName = driver.findElement(By.xpath("//input[@name='firstName']"));
	              WebElement LastName = driver.findElement(By.xpath("//input[@name='lastName']"));
	              WebElement Address = driver.findElement(By.xpath("//input[@name='addressLine1']"));
	              WebElement City = driver.findElement(By.xpath("//input[@name='city']"));
	              WebElement ZipCode = driver.findElement(By.xpath("//input[@name='zip']"));
	              WebElement Cellphone = driver.findElement(By.xpath("//input[@name='cellPhone']"));
	              WebElement Email = driver.findElement(By.xpath("//input[@name='email']"));
	              
	              RC_Global.enterInput(driver, FirstNam,FirstName , true, false);
	              RC_Global.enterInput(driver, LastNam,LastName , true, false);
	              RC_Global.enterInput(driver, "1461 Bluejay Rd",Address , true, false);
	              driver.findElement(By.xpath("//select[@name='state']")).click();
	              Thread.sleep(2000);
	              driver.findElement(By.xpath("//select[@name='state']//option[@label='PA']")).click(); 
	              RC_Global.enterInput(driver, "Panama",City , true, false);
	              RC_Global.enterInput(driver, "19001-2207",ZipCode , true, false);
	              RC_Global.enterInput(driver, "9876543210",Cellphone , true, false);
	              RC_Global.enterInput(driver, "yy567@gmail.com",Email , true, false);
	              driver.findElement(By.xpath("//select[@name='distributionMethod']")).click();
	              Thread.sleep(2000);
	              driver.findElement(By.xpath("//select[@name='distributionMethod']//option[@label='Text Message']")).click();
	              driver.findElement(By.xpath("//input[@ng-model='employee.IsEnrolledInPersonalUse']")).click();
	              Thread.sleep(2000);
	              driver.findElement(By.xpath("//input[@ng-model='SendEmailReceipt']")).click();
	              RC_Global.clickUsingXpath(driver, "(//div[@class='tree-label ']//span)[1]", "Customer tree", true, false);
	              Thread.sleep(2000);
	              RC_Global.clickUsingXpath(driver, "(//button[text()=' Save '])[1]", "Save", true, false);
	              Thread.sleep(5000);
	              if(driver.findElements(By.xpath("//span[text()=' address entered.']")).size()>0) {
	                     driver.findElement(By.xpath("//button[text()='Save As Entered']")).click();
	                     Thread.sleep(5000);
	              }
	              Thread.sleep(3000);
	              WebDriverWait wait = new WebDriverWait(driver,30);
	              //wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='Potential Duplicate Employee Detected']")));
	              Thread.sleep(2000);
	              if(driver.findElements(By.xpath("//h3[text()='Potential Duplicate Employee Detected']")).size()>0) {
	                     JavascriptExecutor executor = (JavascriptExecutor)driver;
	                     executor.executeScript("document.body.style.zoom = '30%'");
	                     Thread.sleep(2000);
	                     WebElement Override= driver.findElement(By.xpath("//input[@value='override']"));
	                     executor.executeScript("arguments[0].scrollIntoView(true);",Override);
	                     executor.executeScript("arguments[0].click();", Override);
	                     //driver.findElement(By.xpath("//input[@value='override']")).click();
	                     Thread.sleep(2000); 
	                     WebElement Okbutton = driver.findElement(By.xpath("//button[text()='OK']"));
	                        Thread.sleep(1000);
	                     executor.executeScript("arguments[0].click();", Okbutton);
	                     executor.executeScript("document.body.style.zoom = '30%'");
	                        Thread.sleep(2000);
	                       executor.executeScript("document.body.style.zoom = '100%'");
	                     
	              }
	              if(driver.findElements(By.xpath("//span[text()=' address entered.']")).size()>0) {
	                     driver.findElement(By.xpath("//button[text()='Save As Entered']")).click();
	                     Thread.sleep(5000);
	              }
	              RC_Global.verifyDisplayedMessage(driver, "Employee Created Successfully", true);
	              queryObjects.logStatus(driver, Status.PASS, "Employee Creation", "Employee Creation Successfull", null);

	       } catch(TimeoutException te) {
	              queryObjects.logStatus(driver, Status.FAIL, "Navigate to the required screen failed -> Unable to load the current/previous screen", te.getLocalizedMessage(), te);
	              if(endRun)
	              RC_Global.endTestRun(driver);}
	       catch(Exception e) {
	              queryObjects.logStatus(driver, Status.FAIL, "Employee Creation Failed", e.getLocalizedMessage(), e);
	            RC_Global.endTestRun(driver);
	       }
	       }

	
	public static List<String> uniqueUnitNumberSelection(WebDriver driver, boolean endTest) throws Exception {
		 boolean nextButton = false; boolean firstpage=false;
		 String lastPg = ""; int pgNos = 1;
		 RC_Global.createNode(driver, "Unique Unit Number selection from Vehicle Segment Management");
		 JavascriptExecutor executor = (JavascriptExecutor) driver;
		 WebDriverWait wait = new WebDriverWait(driver,30);
		 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='ui-grid-row ng-scope'][1]")));
		 driver.findElement(By.xpath("//a[text()='Last']")).click();
		 Thread.sleep(2000);
		 lastPg = driver.findElement(By.xpath("//li[@class='pagination-page ng-scope active']/a")).getText().trim();
		 pgNos = Integer.parseInt(lastPg)-1;
		 driver.findElement(By.xpath("//a[text()='First']")).click();
		 Thread.sleep(2000);
		 List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("//div[@class='ui-grid-row ng-scope']"));
		 List<String> uniqueUnitDetails = new ArrayList<String>();

		 try {
		 
		 for (int p = 1; p <= pgNos; p++) {
			int rowcnt=Getgridrowcnt.size();
			firstpage=false;
			Thread.sleep(2000);
			for(int i=1; i<rowcnt;i++) {
				String make = driver.findElement(By.xpath("(//div[@class='ui-grid-row ng-scope']["+i+"]/div/div/div)[2]")).getText();
				String model = driver.findElement(By.xpath("(//div[@class='ui-grid-row ng-scope']["+i+"]/div/div/div)[3]")).getText();
				String nextRowMake = driver.findElement(By.xpath("(//div[@class='ui-grid-row ng-scope']["+(i+1)+"]/div/div/div)[2]")).getText();
				String nextRowModel = driver.findElement(By.xpath("(//div[@class='ui-grid-row ng-scope']["+(i+1)+"]/div/div/div)[3]")).getText();
				if(make.equals(nextRowMake) && model.equals(nextRowModel))
				{
					i+=2;			   
				}
				else
				{
					String trim = driver.findElement(By.xpath("(//div[@class='ui-grid-row ng-scope']["+i+"]/div/div/div)[4]")).getText();
					String unitNumber = driver.findElement(By.xpath("(//div[@class='ui-grid-row ng-scope']["+i+"]/div/div/div)[7]")).getText();
					uniqueUnitDetails.add(make);
					uniqueUnitDetails.add(model);
					uniqueUnitDetails.add(trim);
					uniqueUnitDetails.add(unitNumber);
					firstpage = true;
					break;
				}
			}
			if(firstpage) {
				queryObjects.logStatus(driver, Status.PASS, "Searching Required grid record from Webtable", "Successful", null);
				break;
			} else {
				driver.findElement(By.xpath("//li/a[text()='Next']")).click();
				Thread.sleep(2000);
			}
		 }
		 if(firstpage)
				queryObjects.logStatus(driver, Status.PASS, "Searching Required grid record from Webtable", "Successful", null);
		
		}catch (Exception e){
			queryObjects.logStatus(driver, Status.FAIL, "Searching Required grid record from Webtable", e.getLocalizedMessage(), e);
			if(endTest)
				RC_Global.endTestRun(driver);
	 	}
		return uniqueUnitDetails;		
	 }
	
	public static List<String> getExcelData(String excelFilePath,String excelopFilePath, String excelSheetName, int startRow, int endRow)throws Exception {
		List<String> ret = new ArrayList();
//		if(excelFilePath!=null && !"".equals(excelFilePath.trim()) && excelSheetName!=null && !"".equals(excelSheetName.trim()))
//		{
			try{
				/* Open the file input stream. */
				FileInputStream fis = new FileInputStream(excelFilePath);
	
				/* Get workbook. */
				XSSFWorkbook excelWookBook = new XSSFWorkbook(fis);
	
				/* Get sheet by name. */
				XSSFSheet copySheet = excelWookBook.getSheet(excelSheetName);
				
				int fRowNum = copySheet.getFirstRowNum();
				int lRowNum = copySheet.getLastRowNum();
				
				/*  First row is excel file header, so read data from row next to it. */
				for(int i=fRowNum+1; i<lRowNum+1; i++)
				{
					/* Only get desired row data. */
					if(i>=startRow && i<=endRow)
					{
						XSSFRow row = copySheet.getRow(i);
						
						int fCellNum = row.getFirstCellNum();
						int lCellNum = row.getLastCellNum();
						
						/* Loop in cells, add each cell value to the list.*/
						List<String> rowDataList = new ArrayList<String>();
						for(int j = fCellNum; j < lCellNum; j++)
						{
							String cValue = row.getCell(j).getStringCellValue();
							rowDataList.add(cValue);
						}
						
//						ret.addAll(rowDataList);
						FileOutputStream fOut = new FileOutputStream(excelopFilePath);
						excelWookBook.write(fOut);
//						fOut.close();
						
						System.out.println("New sheet added in excel file " + excelopFilePath + " successfully. ");
					}
				}
				
			}catch(Exception ex){
				ex.printStackTrace();
			}
		
		return ret;
	}
	
	public static String columnColorDriverPoolAssignment(String columnName) { //Can extend to other excels by using switch case and extending parameters
        
        String selColumnGray = "Results;Reason;Unit Number;CVN;VIN;Year;Make;Model;Fleet Number;Fleet Name;Account Number;Account Name;Sub-Account Number;Sub-Account Name";
        String selColumnBlue = "Vehicle Address 2;Vehicle Address County";
        String selColumnRed = "Driver/Pool Name;Apply Driver Address to Vehicle Address;Address Validation Override;Vehicle Address 1;Vehicle Address City;Vehicle Address State;Vehicle Address Zip Code;Vehicle Address Country;"
        		+ "First Name;Last Name;Address Validation Override;Residential Address 1;Residential Address City;Residential Address State;Residential Address Zip Code;Residential Address Country;Distribution Method;Enrolled in Fuel;Enrolled in Personal Use;Enrolled in Driver Ordering;Create a New User Login ID;Status";
 

        String colorSel = "";
        String[] grayHighlightedCol = selColumnGray.split(";");
        String[] blueHighlightedCol = selColumnBlue.split(";");
        String[] redHighlightedCol = selColumnRed.split(";");
        
        boolean colorSelection = false;
        
        ArrayList<String> grayHighlight = new ArrayList<String>();
        
        String colorSelGray = "FF454546";
        String colorSelGray1 = "FF000000";
        String colorSelBlue = "FF00B0F0";
        String colorSelRed = "FFC00000";
                       
        for(int i=0; i<grayHighlightedCol.length;i++) {
               if(columnName.equalsIgnoreCase(grayHighlightedCol[i])) {
                     colorSel = colorSelGray+";"+colorSelGray1;
                     colorSelection = true;
                     break;
               }
        }
        if(!colorSelection) {
               for(int i=0; i<blueHighlightedCol.length;i++) {
                     if(columnName.equalsIgnoreCase(blueHighlightedCol[i])) {
                            colorSel = colorSelBlue;
                            colorSelection = true;
                            break;
                     }
               }
        }
        if(!colorSelection) {
               for(int i=0; i<redHighlightedCol.length;i++) {
                     if(columnName.equalsIgnoreCase(redHighlightedCol[i])) {
                            colorSel = colorSelRed;
                            colorSelection = true;                                                               
                            break;
                     }                                 
               }
        }
        return colorSel;
	}


	public static void columnHeadingBGColorValidation(WebDriver driver, String filePath, String columnNames) throws Exception {
        RC_Global.createNode(driver, "Validate Heading Cell background Color");
        String[] arrayColumnNames = new String[50];
        Thread.sleep(200);
        if(columnNames.contains(";"))
               arrayColumnNames = columnNames.split(";");
        
        
		  try {
		     FileInputStream fis = new FileInputStream(filePath);
		     XSSFWorkbook wb = new XSSFWorkbook(fis);
		     XSSFSheet sh = wb.getSheetAt(1);
		     int cols= sh.getRow(2).getLastCellNum();
		     
		     for (int i = 0; i < cols; i++) {
		          XSSFCellStyle cs = sh.getRow(2).getCell(i).getCellStyle();
		         XSSFColor color = cs.getFillForegroundColorColor();
		         
		         String colorSel = columnColorDriverPoolAssignment(arrayColumnNames[i]);
		         if (colorSel.contains(";")) {
		         String clr = color.getARGBHex();
		         if (colorSel.contains(clr)) {
		                 XSSFCell ccell = sh.getRow(2).getCell(i);
		                queryObjects.logStatus(driver, Status.PASS, "Validate Column Heading Background Color", "Background color for "+arrayColumnNames[i]+" is "+colorSel+" as expected", null);
		             }
		             else
		                 queryObjects.logStatus(driver, Status.FAIL, "Validate Column Heading Background Color", "Background color for "+arrayColumnNames[i]+" is "+colorSel+" --- Not as expected", null);
		         } else {
		         if (color.getARGBHex().equalsIgnoreCase(colorSel)) {
		                 XSSFCell ccell = sh.getRow(2).getCell(i);
		                queryObjects.logStatus(driver, Status.PASS, "Validate Column Heading Background Color", "Background color for "+arrayColumnNames[i]+" is "+colorSel+" as expected", null);
		             }
		             else
		                 queryObjects.logStatus(driver, Status.FAIL, "Validate Column Heading Background Color", "Background color for "+arrayColumnNames[i]+" is "+colorSel+" --- Not as expected", null);
		         }
		            
		     }
		     fis.close();
		     FileOutputStream fos = new FileOutputStream(filePath);
		     wb.write(fos);
		     wb.close();
		     fos.close();
		  }
		  catch (Exception e) {
		       queryObjects.logStatus(driver, Status.FAIL, "Mandatory cells update failed", e.getLocalizedMessage(), e);
		       RC_Global.endTestRun(driver);
		  }
	   
	}

	
	public static String modifyCells_ColumnName_UnitNum(WebDriver driver, String filePath, String ColName, int delSize, String UnitNos, String act, String newVal) throws Exception {
		RC_Global.createNode(driver, "Modify few values in the "+ColName+" Column");
		int colNo = 0; String unitNums = ""; String getData = ""; String currentVal = ""; String oldData = ""; String newData = ""; String getCols = "";
		RC_Global.createNode(driver, act+ "few "+ColName+" column values in Downloaded Excel file");
		String tempColNm = "";
		int[] iter=new int[10];
		List<Integer> rowChange = null;
		ArrayList<Integer> endLoop = new ArrayList<Integer>();
	    try {
	           FileInputStream fis = new FileInputStream(filePath);
	           XSSFWorkbook wb = new XSSFWorkbook(fis);
	           XSSFSheet sh = wb.getSheetAt(1);
	           int rows = sh.getLastRowNum();
	           int cols= sh.getRow(2).getLastCellNum();
	           for (int i = 0; i < cols; i++) {
	        	   tempColNm = sh.getRow(2).getCell(i).getStringCellValue();
	        	  if (tempColNm.contains("-") && filePath.contains("ClientDataAndCVNUpload")) {
	        		  if (tempColNm.substring(tempColNm.indexOf("-")+1).equalsIgnoreCase(ColName)) {
	        			  colNo = i;
	        			  break;
	        		  }            		  
	        	  } else if (tempColNm.equalsIgnoreCase(ColName)) {
	        		  colNo = i;
	        		  break;
	        	  }
	           }
	           for (int u = 0; u < delSize; u++) {
	        	   for (int j = 5; j < rows; j++) {
	        		   
		               XSSFCell ccell = sh.getRow(j).getCell(colNo);
		               try {
		            	   currentVal = "" ; getData = "";
		            	   if ((UnitNos.contains(sh.getRow(j).getCell(2).getStringCellValue()))&&((iter[0]!=j)&&(iter[1]!=j)&&(iter[2]!=j)&&(iter[3]!=j))) {
		                      if (!ccell.getStringCellValue().isEmpty() || act.equalsIgnoreCase("Update")) {
		                    	  currentVal = ccell.getStringCellValue();
		                    	  if (getCols=="") {
		          	 				getCols = sh.getRow(2).getCell(2).getStringCellValue()+";"+sh.getRow(2).getCell(colNo).getStringCellValue();
		      					} else {
		      						getCols = getCols+";"+sh.getRow(2).getCell(colNo).getStringCellValue();
		      					}
		                      	if (act.equalsIgnoreCase("Update")) {//Update
		                      		String newVals[] = new String[10];
	                      			if(newVal.contains(";")) {
	                      				newVals = newVal.split(";");                      			
	                      				getData = newVals[u];                     			
	                      			} else {
	                      			 getData=newVal;
	                      			}
		                      		ccell.setCellValue(getData.trim());
		                      		
								} else {//Delete the values
									ccell.setCellValue("");
									getData = " ";
								}
		                      	
		                      	unitNums = sh.getRow(j).getCell(2).getStringCellValue();
		                      }
		                      
		                      	if (currentVal.isEmpty()) {
		                      		currentVal= " ";
		    					}
		                      	if (oldData=="") {                       	   		
		                   	   		oldData = unitNums+";"+currentVal;
		                   	   		newData = unitNums+";"+getData;
								} else {
									oldData = oldData+"__"+unitNums+";"+currentVal;
		                   	   		newData = newData+"__"+unitNums+";"+getData;
								} 
		                      	iter[u]=j;
		                      	break;		                      	
		                   }            	   
		            	   
		               } catch (Exception e1) {
		            	   queryObjects.logStatus(driver, Status.FAIL, "Unable to update few column values ", e1.getLocalizedMessage(), e1);
		               }
	        	   }
	        	   
	           }
	           
	           fis.close();
	           FileOutputStream fos = new FileOutputStream(filePath);
	           wb.write(fos);
	           wb.close();
	           fos.close();
	    } catch (Exception e) {
	    	queryObjects.logStatus(driver, Status.FAIL, ColName+" values update failed", e.getLocalizedMessage(), e);
	        RC_Global.endTestRun(driver);
	    }
	return getCols+"~~"+oldData+"~~"+newData;	        
	}
	
	public static void verifyGridColumnsByName(WebDriver driver, String ColumnNames,String ModuleName,boolean endRun)throws Exception {
		try {
			String[] aColNames = ColumnNames.split(";");
	        int colCount=aColNames.length;
	        JavascriptExecutor executor = (JavascriptExecutor) driver;
	        switch(ModuleName) 
	              {
	                 case "DocumentCenter":
	                           for(int iter=0;iter<colCount;iter++)
	                           {
	                                 if(driver.findElements(By.xpath("//div//span[contains(text(),'"+aColNames[iter]+"')]")).size()>0 && aColNames[iter].length()>0)
	                                  {
	                                	 executor.executeScript("window.scrollTo(0,1300)");
	                                	 executor.executeScript("window.scrollTo(0,-1300)");
	                                         queryObjects.logStatus(driver, Status.PASS, "Column Validation", aColNames[iter]+" Column is verified", null);
	                                  }
	                                 else if(driver.findElements(By.xpath("//tr//th[contains(text(),'"+aColNames[iter]+"')]")).size()>0 && aColNames[iter].length()>0)
	                                  {
	                                	 executor.executeScript("window.scrollTo(0,1300)");
	                                	 executor.executeScript("window.scrollTo(0,-1300)");
	                                         queryObjects.logStatus(driver, Status.PASS, "Column Validation", aColNames[iter]+" Column is verified", null);
	                                  }
	                                  else
	                                  {
	                                         queryObjects.logStatus(driver, Status.FAIL, "Column Validation ", " Column"+aColNames[iter]+" is not available", null);
	                                  }
	                                  Thread.sleep(900);
	                           }
	                     break;
	              }
	                     
	           }catch(Exception e) {
	        	   queryObjects.logStatus(driver, Status.FAIL, "Grid column validation failed", e.getLocalizedMessage(), e);
	               if(endRun)
	            	   RC_Global.endTestRun(driver);  
	           }	
	}
	
	public static void clientDataFieldValidationforAddValOvr(WebDriver driver, String ClientdataField,String UnitNum) throws Exception {
		
		WebElement zip = driver.findElement(By.xpath("//tbody//td[contains(text(),'"+UnitNum+"')]/following::td[11]"));
		WebElement address = driver.findElement(By.xpath("//tbody//td[contains(text(),'"+UnitNum+"')]/following::td[8]"));
		
		
		if(ClientdataField.contains("zipcode")) {
			String zipp =zip.getText();
		if(!RC_Manage.zipCode.contains(zipp) || zipp.contains("1111")) 
			 queryObjects.logStatus(driver, Status.INFO, "ZipCode is not updated in Driver Data change page", "for records with Address Validation Override field set as No", null);
	         else 
	         queryObjects.logStatus(driver, Status.FAIL, "ZipCode is updated in Driver Data change page","for records with Address Validation Override field set as No", null);}
		
		if(ClientdataField.contains("Address")) {
			if(!address.getText().contains(RC_Manage.Addressupdated) || zip.getText().contains("")) 
				 queryObjects.logStatus(driver, Status.INFO, "Address field is not updated successfully in Driver Data change page", "for records with Address Validation Override field set as No", null);
		         else 
		         queryObjects.logStatus(driver, Status.FAIL, "Address field is updated successfully in Driver Data change page","for records with Address Validation Override field set as No", null);}
		
	}
	
	public static void clientDataFieldValidation(WebDriver driver, String ClientdataField,String UnitNum) throws Exception {
		
		if(ClientdataField.contains("zipcode")) {
			WebElement zip = driver.findElement(By.xpath("//tbody//td[contains(text(),'"+UnitNum+"')]/following::td[11]"));
			WebElement address = driver.findElement(By.xpath("//tbody//td[contains(text(),'"+UnitNum+"')]/following::td[8]"));
			String zipp =zip.getText();
		if(RC_Manage.zipCode.contains(zipp) || zipp.contains("1111")) 
			 queryObjects.logStatus(driver, Status.INFO, "ZipCode is updated successfully in Driver Data change page", "for records with Address Validation Override field set as Yes", null);
	         else 
	         queryObjects.logStatus(driver, Status.FAIL, "ZipCode failed to update in Driver Data change page","for records with Address Validation Override field set as Yes", null);}
		
		if(ClientdataField.contains("Address")) {
			WebElement zip = driver.findElement(By.xpath("//tbody//td[contains(text(),'"+UnitNum+"')]/following::td[11]"));
			WebElement address = driver.findElement(By.xpath("//tbody//td[contains(text(),'"+UnitNum+"')]/following::td[8]"));
			if(address.getText().contains(RC_Manage.Addressupdated) || zip.getText().contains("")) 
				 queryObjects.logStatus(driver, Status.INFO, "Address field is updated successfully in Driver Data change page","for records with Address Validation Override field set as Yes", null);
		         else 
		         queryObjects.logStatus(driver, Status.FAIL, "Address field failed to updated in Driver Data change page","for records with Address Validation Override field set as Yes", null);}
		
		if(ClientdataField.contains("NonMandatoryclient")) {
			String address1 = driver.findElement(By.xpath("//input[@name='vehicleAddressLine1']")).getAttribute("value");
	    	String address2 = driver.findElement(By.xpath("//input[@name='vehicleAddressLine2']")).getAttribute("value");
	    	String City = driver.findElement(By.xpath("//input[@name='vehicleCity']")).getAttribute("value");
	    	String country = driver.findElement(By.xpath("//input[@name='vehicleCounty']")).getAttribute("value");
	    	String zip1 = driver.findElement(By.xpath("//input[@name='vehicleZip']")).getAttribute("value");
	    	
			if(zip1.contains("19063-5620") && address1.contains("260 W Baltimore Pike") && address2.contains("260 W Baltimore Pike") && City.contains("Media")  && country.contains("Delaware"))
       		 BFrameworkQueryObjects.logStatus(driver, Status.PASS, "Non Manadatory Client fields are updated", "Successfully", null);
	        else 
	        	 BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Non Manadatory Client fields are not updated","Failed", null);
       	
		}
		
	}
	
	public static String ModifyMandatoryFields(WebDriver driver, String filePath,int RowNum, int NoOfColumnsTobeModified, boolean endRun) throws Exception{
		RC_Global.createNode(driver, "Modify MandatoryClient Data in Excel");
		try {
	         FileInputStream fis = new FileInputStream(filePath);String colval = ""; String[] Zipcode = {};
	         XSSFWorkbook wb = new XSSFWorkbook(fis);
	         XSSFSheet sh = wb.getSheetAt(1);String Unum = "";
	         int rows = sh.getLastRowNum();String Address1 = "";
	         int cols= sh.getRow(2).getLastCellNum();  
	        //[118, 117, 82, 231, 227]
	         Thread.sleep(2000);
	         List<Integer> rowsChange = null;String DriverPoolName ="";
	         rowsChange = RC_Manage.RandomNumbers(driver,RowNum, rows,NoOfColumnsTobeModified);
	        for(int i=0;i<rowsChange.size();i++) {
	        	XSSFCell ccell = sh.getRow(rowsChange.get(i)).getCell(10);
	     		ccell.setCellValue("Yes");
	     		ccell = sh.getRow(i).getCell(17);
	     		String VAcOUNTRY = ccell.getStringCellValue();
	     		if(VAcOUNTRY.isEmpty()) {
	          		ccell.setCellValue("USA");}
	     		XSSFCell ccell1 = sh.getRow(rowsChange.get(i)).getCell(2);
	     		Unum = ccell1.getStringCellValue();	
	     		ccell = sh.getRow(rowsChange.get(i)).getCell(11);
	     		ccell.setCellValue("260 W Baltimore Pike");
	     		ccell = sh.getRow(rowsChange.get(i)).getCell(12);
	     		ccell.setCellValue("260 W Baltimore Pike");
	     		ccell = sh.getRow(rowsChange.get(i)).getCell(13);
	     		ccell.setCellValue("Media");
	     		ccell = sh.getRow(rowsChange.get(i)).getCell(14);
	     		ccell.setCellValue("PA");
	     		ccell = sh.getRow(rowsChange.get(i)).getCell(15);
	     		ccell.setCellValue("19063-5620");
	     		ccell = sh.getRow(rowsChange.get(i)).getCell(16);
	     		ccell.setCellValue("Delaware");
	     		//CVN VIN Make Year Model
	     		ccell = sh.getRow(rowsChange.get(i)).getCell(3);
	     		ccell.setCellValue("16INT");
	     		ccell = sh.getRow(rowsChange.get(i)).getCell(4);
	     		ccell.setCellValue("1HTMMMML4GH266136");
	     		ccell = sh.getRow(rowsChange.get(i)).getCell(5);
	     		ccell.setCellValue("2016");
	     		ccell = sh.getRow(rowsChange.get(i)).getCell(6);
	     		ccell.setCellValue("International");
	     		ccell = sh.getRow(rowsChange.get(i)).getCell(7);
	     		ccell.setCellValue("4300");
	     		//read unitNumber
	     		ccell = sh.getRow(i).getCell(2);
	     		Unum = ccell1.getStringCellValue();	
	     		if (UnitNumber=="") {
	     			UnitNumber = Unum;
				} else {
					UnitNumber = UnitNumber+";"+Unum;}
		}	
	     		
	     	
	         fis.close();
		     FileOutputStream fos = new FileOutputStream(filePath);
	         wb.write(fos);
	         wb.close();
	         fos.close(); 
		     queryObjects.logStatus(driver, Status.PASS, "Non Manadatory Client data fields in excel","Non Manadatory Client data fields in excel are updated Successfully", null);

	         }
			 catch (Exception e) {
		        	queryObjects.logStatus(driver, Status.FAIL, "Non Manadatory Client data fields in excel are failed to update", e.getLocalizedMessage(), e);
		        	if(endRun)
			        RC_Global.endTestRun(driver);
		        }

	return UnitNumber;
		}
		public static String addressValidationOverrideColumnsData(WebDriver driver, String filePath,int RowNum, int NoOfColumnsTobeModified,String AddressValidationOverrideValue,String ZipCodeValue,String Addresscounty,String AddressCol, boolean endRun) throws Exception{
			RC_Global.createNode(driver, "Update ZipCode and Address Validation Override Column from downloaded excel");
			try {
	             FileInputStream fis = new FileInputStream(filePath);String colval = ""; String[] Zipcode = {};
	             XSSFWorkbook wb = new XSSFWorkbook(fis);
	             XSSFSheet sh = wb.getSheetAt(1);String Unum = "";
	             int rows = sh.getLastRowNum();String Address1 = "";
	             int cols= sh.getRow(2).getLastCellNum();  
	             int maxCnt = RowNum+NoOfColumnsTobeModified;
	             Thread.sleep(2000);
	             
	             //update Address validate override value
	             for (int i = RowNum; i < maxCnt ; i++) {
	         		XSSFCell ccell = sh.getRow(i).getCell(10);
	         		ccell.setCellValue(AddressValidationOverrideValue);
	         		XSSFCell ccell1 = sh.getRow(i).getCell(2);
	         		Unum = ccell1.getStringCellValue();	
	         		ccell = sh.getRow(i).getCell(14);
	         		String VehAdSta = ccell.getStringCellValue();
	         		ccell = sh.getRow(i).getCell(15);
	         		String zipcode = ccell.getStringCellValue();
	         		ccell = sh.getRow(i).getCell(17);
	         		String VAcOUNTRY = ccell.getStringCellValue();
	         		if(VAcOUNTRY.isEmpty()) {
	              		ccell.setCellValue("USA");}
	         		if(VehAdSta.isEmpty()) {
	          		ccell.setCellValue("PA");}
	         		if(AddressValidationOverrideValue.contains("Yes")) {
	         		//	UnitNumbers with AddressValidationOverrideValue set to Yes
	         		if (UnitNumberAOY=="") 
	         			UnitNumberAOY = Unum;
	    			 else 
	    				UnitNumberAOY = UnitNumberAOY+";"+Unum;}
//	         		UnitNumbers with AddressValidationOverrideValue set to Yes
	         		else {
	         			if (UnitNumberAON=="") 
	         				UnitNumberAON = Unum;
	        			else 
	        				UnitNumberAON = UnitNumberAON+";"+Unum;}
	         	
	             //Adrees 1 and Address2 column update
	             Thread.sleep(2000);
	             if(AddressCol.contains("Yes")) {
	           		 ccell = sh.getRow(i).getCell(11);
	           		 ccell1 = sh.getRow(i).getCell(12);
	           		Address1 = ccell.getStringCellValue();	
	           		if(Address1.isEmpty()) {
	           		String[] Address = Address1.split(" ");
	           		ccell.setCellValue(Address[0]+" "+Address[1]);
	           		ccell1.setCellValue(Address[2]);
	           		if (Addressupdated=="") 
	           			Addressupdated = Address[2];
	        			else
	        			Addressupdated = Addressupdated+";"+Address[2];}
	           		else {
	           			ccell.setCellValue("1222 abc");
	               		ccell1.setCellValue("");
	           		}
	           		} 
	             
	             //update Country code
	             if(!Addresscounty.isEmpty()) {
	             Thread.sleep(2000);
	          		 ccell = sh.getRow(i).getCell(16);
	          		ccell.setCellValue(Addresscounty);
	             }
	             //update Zipcode
	             Thread.sleep(2000);
	             if(!ZipCodeValue.isEmpty()) {
	          		 ccell = sh.getRow(i).getCell(15);
	        		colval = ccell.getStringCellValue();	
	        		if(ZipCodeValue.contains("SPLIT")) {
	        			Zipcode = colval.split("-");
	        			ccell.setCellValue(Zipcode[0]);
	        			if (zipCode=="") 
	        			zipCode = Zipcode[0];
	        			else
	        			zipCode = zipCode+";"+Zipcode[0];}
	        		else
	        			ccell.setCellValue(ZipCodeValue);
	        			
	          		}}
		     fis.close();
		     FileOutputStream fos = new FileOutputStream(filePath);
	         wb.write(fos);
	         wb.close();
	         fos.close(); 
		     queryObjects.logStatus(driver, Status.PASS, "Zipcode and Address Validation Override Columnss update","Zipcode and Address Validation Override Columnss update Successfull", null);

	         }
			 catch (Exception e) {
		        	queryObjects.logStatus(driver, Status.FAIL, "Zipcode and Address Validation Override Columnss update Failed", e.getLocalizedMessage(), e);
		        	if(endRun)
			        RC_Global.endTestRun(driver);
		        }
			return UnitNumber;
		}
		
		public static String ModifyNonMandatoryClientData(WebDriver driver, String filePath,int RowNum, int NoOfColumnsTobeModified, boolean endRun) throws Exception{
			RC_Global.createNode(driver, "Modify Non MandatoryClient Data in Excel");
			try {
		         FileInputStream fis = new FileInputStream(filePath);String colval = ""; String[] Zipcode = {};
		         XSSFWorkbook wb = new XSSFWorkbook(fis);
		         XSSFSheet sh = wb.getSheetAt(1);String Unum = "";
		         int rows = sh.getLastRowNum();String Address1 = "";
		         int cols= sh.getRow(2).getLastCellNum();  
		        //[118, 117, 82, 231, 227]
		         Thread.sleep(2000);
		         List<Integer> rowsChange = null;String DriverPoolName ="";
		         rowsChange = RC_Manage.RandomNumbers(driver,RowNum, rows,NoOfColumnsTobeModified);
		        for(int i=0;i<rowsChange.size();i++) {
		        	XSSFCell ccell = sh.getRow(rowsChange.get(i)).getCell(8);
		            DriverPoolName = ccell.getStringCellValue();
		            if(!DriverPoolName.contains("Pool")) {
		     		ccell = sh.getRow(rowsChange.get(i)).getCell(10);
		     		ccell.setCellValue("Yes");
		     		XSSFCell ccell1 = sh.getRow(rowsChange.get(i)).getCell(2);
		     		Unum = ccell1.getStringCellValue();	
		     		ccell = sh.getRow(rowsChange.get(i)).getCell(11);
		     		ccell.setCellValue("260 W Baltimore Pike");
		     		ccell = sh.getRow(rowsChange.get(i)).getCell(12);
		     		ccell.setCellValue("260 W Baltimore Pike");
		     		ccell = sh.getRow(rowsChange.get(i)).getCell(13);
		     		ccell.setCellValue("Media");
		     		ccell = sh.getRow(rowsChange.get(i)).getCell(14);
		     		ccell.setCellValue("PA");
		     		ccell = sh.getRow(rowsChange.get(i)).getCell(15);
		     		ccell.setCellValue("19063-5620");
		     		ccell = sh.getRow(rowsChange.get(i)).getCell(16);
		     		ccell.setCellValue("Delaware");
					
					//read unitNumber 
		     		ccell = sh.getRow(i).getCell(2);
		     		Unum = ccell1.getStringCellValue();
					  
//					  if (UnitNumber=="") { UnitNumber = Unum; } else { UnitNumber =
//					  UnitNumber+";"+Unum;}
					 }
			}		
		         fis.close();
			     FileOutputStream fos = new FileOutputStream(filePath);
		         wb.write(fos);
		         wb.close();
		         fos.close(); 
			     queryObjects.logStatus(driver, Status.PASS, "Non Manadatory Client data fields in excel","Non Manadatory Client data fields in excel are updated Successfully", null);

		         }
				 catch (Exception e) {
			        	queryObjects.logStatus(driver, Status.FAIL, "Non Manadatory Client data fields in excel are failed to update", e.getLocalizedMessage(), e);
			        	if(endRun)
				        RC_Global.endTestRun(driver);
			        }

			return UnitNumber;
	}
		
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	public static void dropdownValuesValidation(WebDriver driver, List<String> dropDownValues,String searchFilterName, String Xpath,boolean endRun) throws Exception {
          RC_Global.createNode(driver,"Validate dropdown values for "+searchFilterName);
          try {
          driver.findElement(By.xpath("" + Xpath + "")).click();
          Thread.sleep(2000);
          List<String> dropvalues = dropDownValues;
          boolean flag = false;
          for (String valDrop : dropvalues) {
        	  String Drpdwn = "";
              if(driver.findElements(By.xpath(Xpath + "/following::a[@title='"+valDrop+"']")).size()>0) {
                    Drpdwn = driver.findElement(By.xpath(Xpath + "/following::a[@title='"+valDrop+"']")).getText();
              }
              else if(driver.findElements(By.xpath(Xpath + "/option[text()='"+valDrop+"']")).size()>0)
              { Drpdwn = driver.findElement(By.xpath(Xpath + "/option[text()='"+valDrop+"']")).getText();
              }
                
                 if (Drpdwn.equalsIgnoreCase(valDrop))
                        flag = true;
          }
          if (flag)
                queryObjects.logStatus(driver, Status.PASS, "Dropdown Values validation", "Successful", null);
          else
                queryObjects.logStatus(driver, Status.FAIL, "Dropdown Values validation", "Failed", null);

          driver.findElement(By.xpath("" + Xpath + "")).click();
          Thread.sleep(2000);

}
            catch(NullPointerException npe) {
                   queryObjects.logStatus(driver, Status.FAIL, "Unable to validate dropdown values -> The expected options are not present in the selection box - Verify the xpath", npe.getLocalizedMessage(), npe);
                     if(endRun)
                           RC_Global.endTestRun(driver);
            }
            catch(NoSuchElementException nse) {
                   queryObjects.logStatus(driver, Status.FAIL, "Unable to validate dropdown values -> The expected dropdown values are not present on the selection box.", nse.getLocalizedMessage(), nse);
                     if(endRun)
                           RC_Global.endTestRun(driver);
            }
            catch(TimeoutException te) {
                   queryObjects.logStatus(driver, Status.FAIL, "Unable to validate dropdown values -> Wait time expired before the expected dropdown values were validated", te.getLocalizedMessage(), te);
                     if(endRun)
                           RC_Global.endTestRun(driver);
            }
            catch(Exception e) {
                   queryObjects.logStatus(driver, Status.FAIL, "Unable to validate dropdown values", e.getLocalizedMessage(), e);
                     if(endRun)
                           RC_Global.endTestRun(driver);
            }

     }
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		public static void dropDownSearchFilterValidation(WebDriver driver, List<String> dropDownValues,String searchFilterName,String filterName, boolean endRun) throws Exception {
            RC_Global.createNode(driver,searchFilterName+" filter search results validation");
            try {
            WebDriverWait wait = new WebDriverWait(driver,20);
            boolean results = false;
            	List<String> dropDownValue = dropDownValues;
                   driver.findElement(By.xpath("//input[@id='"+filterName+"']")).click();
                   Thread.sleep(2000);
                   for (String newVal : dropDownValue) {
                	   driver.findElement(By.xpath("//input[@id='"+filterName+"']")).click();
                       Thread.sleep(1000);
                       try {
                    	   driver.findElement(By.xpath("//input[@id='"+filterName+"']/following::a[@title='"+newVal+"']")).click();
                           Thread.sleep(2000);
                           driver.findElement(By.xpath("(//button[text()='Search'])[1]")).click();
                           Thread.sleep(3000);}
                    	   catch(Exception e){
                    	   queryObjects.logStatus(driver, Status.INFO, newVal+" search filter is not available in the dropdown", "", null);}
                       
                 
                       try {
                   wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@role='row'])[2]")));
                       List<WebElement> SearchGrid = driver.findElements(By.xpath("//div[@role='row']"));
                       if(SearchGrid.size()>0) {
                              results = true;
                              queryObjects.logStatus(driver, Status.PASS, "Result grid displays based on "+filterName+" search filter", "", null);}
                       }
                       catch(Exception e){
                              queryObjects.logStatus(driver, Status.INFO, "No Results found for "+filterName+" search filter", "", null);}
                       
                 if(!results) {      
                       driver.findElement(By.xpath("(//button[text()='Reset'])[1]")).click();
                        Thread.sleep(3000);
                       }
                 else {
                       break;
                 }
            }
            }
            catch(Exception e) {
                  queryObjects.logStatus(driver, Status.FAIL, "Failed to Validate the Search filter validation", e.getLocalizedMessage(), e);
          }
     }
		
		public static void selectRowWithVehicleStatusFromGrid(WebDriver driver,String VehicleStatus ,boolean endRun)throws Exception{
	        RC_Global.createNode(driver, "selecting a row with Vehicle Status " +VehicleStatus);
	        WebDriverWait wait = new WebDriverWait(driver,60);
	        JavascriptExecutor executor = (JavascriptExecutor) driver;
	        try {
	            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tbody//tr")));															
	            List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("//table//tbody//tr"));
	            int rowcnt=Getgridrowcnt.size();
	            Boolean    firstpage=false;
	            Boolean    pagination=false;
	            for(int i=1; i<=rowcnt;i++) {  
	                WebElement sub= driver.findElement(By.xpath("//tr["+i+"]//td[15]"));
	                WebElement viewsub = driver.findElement(By.xpath("//tr["+i+"]//td[6]"));																		
	                WebElement CVNrow = driver.findElement(By.xpath("//tr["+i+"]//td[4]"));
	                WebElement Unitnorow = driver.findElement(By.xpath("//tr["+i+"]//td[3]"));
	                String Unitnumber = Unitnorow.getText();
	                Thread.sleep(2000);
	                String CVN = sub.getText();									 
	                if(!CVN.isEmpty()) {
	                    WebElement driverclmn =driver.findElement(By.xpath("//tbody//tr["+i+"]//td[5]"));										   
	                    Thread.sleep(2000);
	                    drivername =driverclmn.getText();
	                    Thread.sleep(1000);
	                    if(!(drivername.equalsIgnoreCase("Unassigned") || drivername.contains("Pool")||drivername.contains("Unknown")||drivername.contains("Catering")) ) {
	                        driver.findElement(By.xpath("//tbody//tr["+i+"]//td[3]")).click();
	                    Thread.sleep(1000);
	                    firstpage = true;
	                    break;}
	                if(sub.getText().equalsIgnoreCase(VehicleStatus)) {					
	                    Thread.sleep(2000);																																											 
	                    driver.findElement(By.xpath("//tbody//tr["+i+"]//td[3]")).click();
	                    firstpage = false;
	                    break;			  
	                } 
	             }
	                firstpage = true;							
	            } 
	                queryObjects.logStatus(driver, Status.PASS, "Searching "+VehicleStatus+" grid record from Webtable", "Successful", null);
	           }
	        catch(TimeoutException te) {
	            queryObjects.logStatus(driver, Status.FAIL, "Failed to Search "+VehicleStatus+" grid record -> Unable to Search Required grid record screen", te.getLocalizedMessage(), te);
	            if(endRun)
	                RC_Global.endTestRun(driver);
	            }
	        catch(Exception e) {
	            queryObjects.logStatus(driver, Status.FAIL, "Searching "+VehicleStatus+" grid record from Webtable", e.getLocalizedMessage(), e);
	                  if(endRun)
	                           RC_Global.endTestRun(driver);
	            }
	    }
		
		public static void clientdataStatusChange(WebDriver driver, String custNum, String custLevel, String status, String DataName, boolean endRun) throws Exception {
	        try {
	        	RC_Global.createNode(driver, "Validate Inactivated existing client Data at "+custLevel+" ");
	 //       	WebElement CDStatus = null;
	        	String currentStatus = "";
	 //  
	        	if(custLevel.equalsIgnoreCase("Customer level")) 
	        	{ 
	        		//RC_Global.navigateTo(driver,"Manage","Administration","Client Data Setup");
	        		driver.findElement(By.xpath("//div[@class='input-group']/input[@name='customerInput']")).clear();
	        		RC_Global.enterCustomerNumber(driver, custNum, "", "", endRun);
	        		List<WebElement> Gridrowcnt = driver.findElements(By.xpath("//table/tbody/tr"));
					for (int i=1; i<=Gridrowcnt.size();i++) {
						CDStatus = driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td[7]/span"));
						Name = driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td[2]")).getText();
					currentStatus = CDStatus.getText();
						
						if(status.contains(currentStatus) && DataName.contains(Name)) {
							queryObjects.logStatus(driver, Status.INFO, "Client Data Name in grid -->", Name, null);
							
							CDStatus.click();
							Thread.sleep(3000);
							updatdcurrentStatus = CDStatus.getText();
							queryObjects.logStatus(driver, Status.PASS, "Client Data status is changed as -- "+updatdcurrentStatus+" ", "Successfully", null);
							break;
						}	
						
					}
					//RC_Global.panelAction(driver, "close", "Client Data Setup", false, false);
	        	}
	        	
	        	else if(custLevel.equalsIgnoreCase("Fleet level")) 
	        	{
	        		//RC_Global.navigateTo(driver,"Manage","Administration","Client Data Setup");
	        		driver.findElement(By.xpath("//div[@class='input-group']/input[@name='customerInput']")).clear();
	        		RC_Global.enterCustomerNumber(driver, custNum, "Customer", "Fleet level", false);
	        		Thread.sleep(2000);
	        		List<WebElement> Gridrowcnt = driver.findElements(By.xpath("//table/tbody/tr"));
	        		for (int i=1; i<=Gridrowcnt.size();i++) {
					String UpdatedStatus = driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td[7]/span")).getText();
					String CDName = driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td[2]")).getText();
					Thread.sleep(2000);
		        		if(updatdcurrentStatus.contains(UpdatedStatus) && DataName.contains(CDName))
		        		{
		        			queryObjects.logStatus(driver, Status.PASS, "Changed Client Data status displays for customer ", custLevel, null);
		        			break;
		        		}
	        		}
	        		//RC_Global.panelAction(driver, "close", "Client Data Setup", false, false);
	        	}
	        	
	        	else if(custLevel.equalsIgnoreCase("Account level")) 
	        	{
	        		//RC_Global.navigateTo(driver,"Manage","Administration","Client Data Setup");
	        		driver.findElement(By.xpath("//div[@class='input-group']/input[@name='customerInput']")).clear();
	        		RC_Global.enterCustomerNumber(driver, custNum, "Customer", "Account level", false);
	        		Thread.sleep(4000);
	        		List<WebElement> Gridrowcnt = driver.findElements(By.xpath("//table/tbody/tr"));
	        		for (int i=1; i<=Gridrowcnt.size();i++) {
					String UpdatedStatus = driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td[7]/span")).getText();
					String CDName = driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td[2]")).getText();
					Thread.sleep(2000);
		        		if(updatdcurrentStatus.contains(UpdatedStatus) && DataName.contains(CDName))
		        		{
		        			queryObjects.logStatus(driver, Status.PASS, "Changed Client Data status displays for customer ", custLevel, null);
		        			break;
		        		}
	        		}
	        		//RC_Global.panelAction(driver, "close", "Client Data Setup", false, false);
	        	}
	        	
	        	else if(custLevel.equalsIgnoreCase("SubAccount level")) 
	        	{
	        		//RC_Global.navigateTo(driver,"Manage","Administration","Client Data Setup");
	        		driver.findElement(By.xpath("//div[@class='input-group']/input[@name='customerInput']")).clear();
	        		RC_Global.enterCustomerNumber(driver, custNum, "Customer", "Sub-account level", false);
	        		Thread.sleep(2000);
	        		List<WebElement> Gridrowcnt = driver.findElements(By.xpath("//table/tbody/tr"));
	        		for (int i=1; i<=Gridrowcnt.size();i++) {
					String UpdatedStatus = driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td[7]/span")).getText();
					String CDName = driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td[2]")).getText();
					Thread.sleep(2000);
	        		if(updatdcurrentStatus.contains(UpdatedStatus) && DataName.contains(CDName))
	        		{
	        			queryObjects.logStatus(driver, Status.PASS, "Changed Client Data status displays for customer ", custLevel, null);
	        			break;
	        		}
	        		}
	        		//RC_Global.panelAction(driver, "close", "Client Data Setup", false, false);
	        	}
	        	
	        	else if(custLevel.equalsIgnoreCase("RevertChange"))
				{
	        		
	        		//RC_Global.navigateTo(driver,"Manage","Administration","Client Data Setup");
	        		driver.findElement(By.xpath("//div[@class='input-group']/input[@name='customerInput']")).clear();
	        		RC_Global.enterCustomerNumber(driver, custNum, "", "", endRun);
	        		Thread.sleep(1000);
	        		WebElement datastatus =	driver.findElement(By.xpath("(//td[2][text()='"+DataName+"']/../td[7]/span)[1]"));
	        		datastatus.click();
		
				Thread.sleep(3000);
				String revertedStatus = datastatus.getText();
					if(revertedStatus.equals("Active"))
					{
						queryObjects.logStatus(driver, Status.INFO, "Client Data status is reverted from "+updatdcurrentStatus+" to ", revertedStatus, null);
					}
				
				//RC_Global.panelAction(driver, "close", "Client Data Setup", false, false);
				}
					
	        }
	        catch(Exception e) {
	       		queryObjects.logStatus(driver, Status.FAIL, "Unable to change Client Data status ", e.getLocalizedMessage(), e);	
	       		if(endRun)
	       				RC_Global.endTestRun(driver);
	       		}
	       	}
		
		public static void validateAddedCDCusStructurelevel(WebDriver driver,String custNum, String custLevel, String CDName, boolean endRun) throws Exception {
	        try {
	        	RC_Global.createNode(driver, "Validate Added client Data at "+custLevel+" ");
	        	if(custLevel.equalsIgnoreCase("Fleet level")) 
	        	{
	        		RC_Global.navigateTo(driver,"Manage","Administration","Client Data Setup");
		        	RC_Global.enterCustomerNumber(driver, custNum, "Customer", "Fleet level", false);
		    		RC_Global.waitElementVisible(driver, 30, "//table//tbody//tr", "Client Setup grid is displayed", true, false);
		    		driver.findElement(By.xpath("(//td[2][text()='"+CDName+"']/../td[6]/span)[1]")).click();
		    		RC_Global.waitElementVisible(driver, 30, "//span[text()='Client Data Values']", "Client Data Values",false, false);
		    		String AddedName = driver.findElement(By.xpath("//input[@name='name']")).getAttribute("value");
			        	if(AddedName.equals(CDName))
			        	{
			        		queryObjects.logStatus(driver, Status.PASS, "Newly added Client Data field displays for customer ", custLevel, null);
			        	}
	        	}
	        	else if(custLevel.equalsIgnoreCase("Account level"))
	        	{
	        		//RC_Global.navigateTo(driver,"Manage","Administration","Client Data Setup");
	        		driver.findElement(By.xpath("//div[@class='input-group']/input[@name='customerInput']")).clear();
	        		RC_Global.enterCustomerNumber(driver, custNum, "Customer", "Account level", false);
	        		RC_Global.waitElementVisible(driver, 30, "//table//tbody//tr", "Client Setup grid is displayed", true, false);
	        		Thread.sleep(2000);
	        		driver.findElement(By.xpath("(//td[2][text()='"+CDName+"']/../td[6]/span)[1]")).click();
	        		RC_Global.waitElementVisible(driver, 30, "//span[text()='Client Data Values']", "Client Data Values",false, false);
	        		String AddedName = driver.findElement(By.xpath("//input[@name='name']")).getAttribute("value");
	    	        	if(AddedName.equals(CDName))
	    	        	{
	    	        		queryObjects.logStatus(driver, Status.PASS, "Newly added Client Data field displays for customer ", custLevel, null);
	    	        	}
	        	}
	        	else if(custLevel.equalsIgnoreCase("SubAccount level"))
	        	{
	        		//RC_Global.navigateTo(driver,"Manage","Administration","Client Data Setup");
	        		driver.findElement(By.xpath("//div[@class='input-group']/input[@name='customerInput']")).clear();
	        		RC_Global.enterCustomerNumber(driver, custNum, "Customer", "Sub-account level", false);
	        		RC_Global.waitElementVisible(driver, 30, "//table//tbody//tr", "Client Setup grid is displayed", true, false);
	        		Thread.sleep(2000);
	        		driver.findElement(By.xpath("(//td[2][text()='"+CDName+"']/../td[6]/span)[1]")).click();
	        		RC_Global.waitElementVisible(driver, 30, "//span[text()='Client Data Values']", "Client Data Values",false, false);
	        		String AddedName = driver.findElement(By.xpath("//input[@name='name']")).getAttribute("value");
	    	        	if(AddedName.equals(CDName))
	    	        	{
	    	        		queryObjects.logStatus(driver, Status.PASS, "Newly added Client Data field displays for customer ", custLevel, null);
	    	        	}
	        	}
	    		
	        }
	        catch(Exception e) {
	       		queryObjects.logStatus(driver, Status.FAIL, "Unable to validate Client Data status ", e.getLocalizedMessage(), e);	
	       		if(endRun)
	       				RC_Global.endTestRun(driver);
	       		}
	       	}
		
		public static void validateEditedCDCusStructurelevel(WebDriver driver,String custNum, String custLevel, String Name, String UpdateddataTypeValue, boolean endRun) throws Exception {
	        try {
	        	RC_Global.createNode(driver, "Validate Editing client Data at "+custLevel+" ");
	        	
	        	if(custLevel.equalsIgnoreCase("Fleet level")) 
	        	{
	        		RC_Global.navigateTo(driver,"Manage","Administration","Client Data Setup");
	        		RC_Global.enterCustomerNumber(driver, custNum, "Customer", "Fleet level", false);
	        	    driver.findElement(By.xpath("(//td[2][text()='"+Name+"']/../td[6]/span)[1]")).click();
	        	    RC_Global.waitElementVisible(driver, 60, "//span[text()='Client Data Values']", "Client Data Values",false, false);
	        	    
	        	    String EditedName = driver.findElement(By.xpath("//input[@name='name']")).getAttribute("value");
	        	    String Value = "";
	        	    for(int i=1;i<=9;i++)
	        		{
	        			if(driver.findElement(By.xpath("//input[@value='"+i+"']")).isSelected())
	        			{
	        				Value = driver.findElement(By.xpath("//div[input[@value='"+i+"']]")).getText();
	        				queryObjects.logStatus(driver, Status.INFO, "Existing DataType value ", Value, null);
	        			
	        				if(EditedName.equals(Name) && UpdateddataTypeValue.equals(Value) )
	    		        	{
	    		        		queryObjects.logStatus(driver, Status.PASS, "Edited Client Data field displays for customer ", custLevel, null);
	    		        	}	
	        				
	        				break;
	        			}
	        		}
			        	 RC_Global.clickButton(driver, "Cancel",true, true);
			        	 //RC_Global.panelAction(driver, "close", "Client Data Setup", false, false);
	        	}
	        	
	        	else if(custLevel.equalsIgnoreCase("Account level"))
	        	{
	        		//RC_Global.navigateTo(driver,"Manage","Administration","Client Data Setup");
	        		driver.findElement(By.xpath("//div[@class='input-group']/input[@name='customerInput']")).clear();
	        		RC_Global.enterCustomerNumber(driver, custNum, "Customer", "Account level", false);
	        		Thread.sleep(2000);
	        	    driver.findElement(By.xpath("(//td[2][text()='"+Name+"']/../td[6]/span)[1]")).click();
	        	    RC_Global.waitElementVisible(driver, 60, "//span[text()='Client Data Values']", "Client Data Values",false, false);
	        	    
	        	    String EditedName = driver.findElement(By.xpath("//input[@name='name']")).getAttribute("value");
	        	    String Value = "";
	        	    for(int i=1;i<=9;i++)
	        		{
	        			if(driver.findElement(By.xpath("//input[@value='"+i+"']")).isSelected())
	        			{
	        				Value = driver.findElement(By.xpath("//div[input[@value='"+i+"']]")).getText();
	        				queryObjects.logStatus(driver, Status.INFO, "Existing DataType value ", Value, null);
	        			
	        				if(EditedName.equals(Name) && UpdateddataTypeValue.equals(Value) )
	    		        	{
	    		        		queryObjects.logStatus(driver, Status.PASS, "Edited Client Data field displays for customer ", custLevel, null);
	    		        	}	
	        				
	        				break;
	        			}
	        		}
			        	
			        	 RC_Global.clickButton(driver, "Cancel",true, true);
			        	 //RC_Global.panelAction(driver, "close", "Client Data Setup", false, false);
	        	}
	        	else if(custLevel.equalsIgnoreCase("SubAccount level"))
	        	{
	        		//RC_Global.navigateTo(driver,"Manage","Administration","Client Data Setup");
	        		driver.findElement(By.xpath("//div[@class='input-group']/input[@name='customerInput']")).clear();
	        		RC_Global.enterCustomerNumber(driver, custNum, "Customer", "Sub-account level", false);
	        		Thread.sleep(2000);
	        	    driver.findElement(By.xpath("(//td[2][text()='"+Name+"']/../td[6]/span)[1]")).click();
	        	    RC_Global.waitElementVisible(driver, 60, "//span[text()='Client Data Values']", "Client Data Values",false, false);
	        	    
	        	    String EditedName = driver.findElement(By.xpath("//input[@name='name']")).getAttribute("value");
	        	    String Value = "";
	        	    for(int i=1;i<=9;i++)
	        		{
	        			if(driver.findElement(By.xpath("//input[@value='"+i+"']")).isSelected())
	        			{
	        				Value = driver.findElement(By.xpath("//div[input[@value='"+i+"']]")).getText();
	        				queryObjects.logStatus(driver, Status.INFO, "Existing DataType value ", Value, null);
	        			
	        				if(EditedName.equals(Name) && UpdateddataTypeValue.equals(Value) )
	    		        	{
	    		        		queryObjects.logStatus(driver, Status.PASS, "Edited Client Data field displays for customer ", custLevel, null);
	    		        	}
	        				
	        				break;
	        			}
	        		}
			        
			        	 RC_Global.clickButton(driver, "Cancel",true, true);
			        	 RC_Global.panelAction(driver, "close", "Client Data Setup", false, false);
	        	}
	    		
	        }
	        catch(Exception e) {														  
	       		queryObjects.logStatus(driver, Status.FAIL, "Unable to change Client Data status ", e.getLocalizedMessage(), e);	
	       		if(endRun)																																	
	       				RC_Global.endTestRun(driver);
	       		}
		
	       	}											
		   
		
		public static boolean isValidDateFormat(WebDriver driver, String format,String Sectionfieldname,  String value,boolean endRun) throws Exception {
            RC_Global.createNode(driver, ""+Sectionfieldname+" Data Type Validation For Date");
            Date date = null;
            try {
                  if(!(value.length()==0))
                  {
                  SimpleDateFormat sdf = new SimpleDateFormat(format);
                  date = sdf.parse(value);
                  
                  if (value.equals(sdf.format(date))) {
                         queryObjects.logStatus(driver, Status.PASS, "The "+Sectionfieldname+" value displayed in","Valid Date Format", null);
                         date = null;
                  }
                  }
                  else if(value.length()==0)
       {
              queryObjects.logStatus(driver, Status.PASS, "The "+Sectionfieldname+" is available with ", "empty value", null);
       }
                  
            } catch (Exception e) {
                  
                  queryObjects.logStatus(driver, Status.FAIL, "The "+Sectionfieldname+" is in Invalid Format Or Null", e.getLocalizedMessage(), e);
          if(endRun)
                   RC_Global.endTestRun(driver);
            }      
            return true;
     }
     

public static void validateDataType(WebDriver driver,String SectionName,String Sectionfieldname,String DataType ,String Data,boolean endRun)throws Exception{
      RC_Global.createNode(driver, ""+SectionName+" Data Type Validation For " +DataType);
      WebDriverWait wait = new WebDriverWait(driver,60);
      JavascriptExecutor executor = (JavascriptExecutor) driver;
      try {
           boolean isAlphaNumeric = false;
           boolean isNumeric = false;
           boolean isText = false;
           boolean isDate = false;
           boolean isCurrency = false;
           boolean isboolean = false;
            switch(DataType)
           {
           case "AlphaNumeric":
                  isAlphaNumeric = Data != null &&
                                       Data.chars().allMatch(Character::isLetterOrDigit);
                  isAlphaNumeric = true;
                  if (isAlphaNumeric) {
                   queryObjects.logStatus(driver, Status.PASS, "The "+Sectionfieldname+" value displayed as","Alphanumeric", null);}
                  else if(Data.length()==0)
              {
                     queryObjects.logStatus(driver, Status.PASS, "The "+Sectionfieldname+" is available with ", "empty value", null);
              }
                  else {
                  queryObjects.logStatus(driver, Status.FAIL, "The "+Sectionfieldname+" value not displayed as","Alphanumeric Or Null", null);}
           
                  break;
           case "Numeric":
                  isNumeric = Data != null &&
                                       Data.chars().allMatch(Character::isDigit);
                  isNumeric = true;
                  if (isNumeric) {
                   queryObjects.logStatus(driver, Status.PASS, "The "+Sectionfieldname+" value displayed as","Numeric", null);}
                  else if(Data.length()==0)
              {
                     queryObjects.logStatus(driver, Status.PASS, "The "+Sectionfieldname+" is available with ", "empty value", null);
              }
                  else {
           queryObjects.logStatus(driver, Status.FAIL, "The "+Sectionfieldname+" value not displayed as","Numeric Or Null", null);}
    
                  break;
           case "Text":
                  isText = Data != null &&
                                       Data.chars().allMatch(Character::isLetter);
                  isText = true;
                  if (isText) {
                   queryObjects.logStatus(driver, Status.PASS, "The "+Sectionfieldname+" value displayed as","Text", null);}
                  else if(Data.length()==0)
              {
                     queryObjects.logStatus(driver, Status.PASS, "The "+Sectionfieldname+" is available with ", "empty value", null);
              }
                  else {
           queryObjects.logStatus(driver, Status.FAIL, "The "+Sectionfieldname+" value not displayed as","Text Or Null", null);}
            
                  break;

           case "Currency":
                  if(Data.startsWith("$") || Data.endsWith("$") || Data.startsWith("-$") )  {
                    queryObjects.logStatus(driver, Status.PASS, "The "+Sectionfieldname+" value displayed is","Currency Format", null);
                 }
                  else if(Data.length()==0)
              {
                     queryObjects.logStatus(driver, Status.PASS, "The "+Sectionfieldname+" is available with ", "empty value", null);
              }
                  else {
                  queryObjects.logStatus(driver, Status.FAIL, "The "+Sectionfieldname+" value Not displayed is","Currency Format Or Null", null);}
     
           break;
           case "Percentage":
                  
           //     String str = new BigDecimal(Data).setScale(2, BigDecimal.ROUND_HALF_UP).toString();
                  
                  if(Data.endsWith("%"))  {
                  queryObjects.logStatus(driver, Status.PASS, "The "+Sectionfieldname+" value displayed is","Percentage Format", null);
                  }
                  else if(Data.length()==0)
                  {
                         queryObjects.logStatus(driver, Status.PASS, "The "+Sectionfieldname+" is available with ", "empty value", null);
                  }
                  else {
                  queryObjects.logStatus(driver, Status.FAIL, "The "+Sectionfieldname+" value Not displayed is","Percentage Format Or Null", null);}
           break;
           
           case "Boolean":
                  if(Data.equals("Yes") || Data.equals("No"))  {
                   queryObjects.logStatus(driver, Status.PASS, "The "+Sectionfieldname+" value displayed as","Boolean", null);}
                  else if(Data.length()==0)
              {
                     queryObjects.logStatus(driver, Status.PASS, "The "+Sectionfieldname+" is available with ", "empty value", null);
              }
                  else {
           queryObjects.logStatus(driver, Status.FAIL, "The "+Sectionfieldname+" value Not displayed as","Boolean Or Null", null);}
  
                  break;
           
           }
      }
      catch(Exception e) {
           queryObjects.logStatus(driver, Status.FAIL, "Failed to validate Data type value", e.getLocalizedMessage(), e);
          if(endRun)
                   RC_Global.endTestRun(driver);
      }    
     }


		
		public static void validateSectionFieldDatas(WebDriver driver,String Xpath,String SectionName, String Sectionfieldname ,boolean endRun)throws Exception{
	        
			try {
				String Value = driver.findElement(By.xpath(Xpath)).getText(); 
				queryObjects.logStatus(driver, Status.PASS,"The " + SectionName + " Value of " + Sectionfieldname + " ---->", Value, null);
	   
			}
			 catch (Exception e) {
		            if(endRun)
		                RC_Global.endTestRun(driver);
			}			 
		}						 

		public static String getDriverFleetManager_ReportScheduler(WebDriver driver, BFrameworkQueryObjects queryObjects, String filePath) throws Exception {
			FileInputStream fis = new FileInputStream(filePath);
	        XSSFWorkbook wb = new XSSFWorkbook(fis);
	        XSSFSheet sh = wb.getSheetAt(0);
	        int rows = sh.getLastRowNum();
	        int cols= sh.getRow(2).getLastCellNum();
	        List<String> fmNameList = new ArrayList<String>();
	        List<String> fmFirstNameList = new ArrayList<String>();
	        List<String> fmLastNameList = new ArrayList<String>();
	        List<String> driNameList = new ArrayList<String>();
	        List<String> driFirstNameList = new ArrayList<String>();
	        List<String> driLastNameList = new ArrayList<String>();
	        
	        int fmCount = 0;
	        int driverCount = 0;
	        int iter=0;
	        for(int i=1; i<=rows;i++) {
	        	try {
		        	if(sh.getRow(i).getCell(0).getStringCellValue().equalsIgnoreCase("Yes")) {
		        		fmNameList.add(sh.getRow(i).getCell(1).getStringCellValue());
		        		iter++;
		        	}
	        	}
	        	catch(NullPointerException npe) {
	        		//To be left blank so as to handle Blank cells
	        	}
	        }
	        
	        return Integer.toString(iter);

		}
		
		public static String getDriverFleetManager_UserSetup(WebDriver driver, BFrameworkQueryObjects queryObjects, String filePath) throws Exception {
			FileInputStream fis = new FileInputStream(filePath);
	        XSSFWorkbook wb = new XSSFWorkbook(fis);
	        XSSFSheet sh = wb.getSheetAt(0);
	        int rows = sh.getLastRowNum();
	        int cols= sh.getRow(2).getLastCellNum();
	        List<String> fmNameList = new ArrayList<String>();
	        List<String> fmFirstNameList = new ArrayList<String>();
	        List<String> fmLastNameList = new ArrayList<String>();
	        
	        List<String> driNameList = new ArrayList<String>();
	        List<String> driFirstNameList = new ArrayList<String>();
	        List<String> driLastNameList = new ArrayList<String>();
	        
	        int fmCount = 0;
	        int driverCount = 0;
	        int iter=0;
	        for(int i=1; i<=rows;i++) {
	        	try {
		        	if(sh.getRow(i).getCell(13).getStringCellValue().equalsIgnoreCase("Fleet Manager")&&sh.getRow(i).getCell(11).getStringCellValue().equalsIgnoreCase("Yes")) {
		        		fmFirstNameList.add(sh.getRow(i).getCell(2).getStringCellValue());
		        		fmLastNameList.add(sh.getRow(i).getCell(1).getStringCellValue());
		        		fmNameList.add(fmFirstNameList.get(iter)+" "+fmLastNameList.get(iter++));
//		        		}
		        	}
	        	}
	        	catch(NullPointerException npe) {
	        	}
	        }
	        
	        fmCount = iter;
	        
	        iter=0;
	        for(int i=1; i<=rows;i++) {
	        	try {
		        	if(sh.getRow(i).getCell(13).getStringCellValue().equalsIgnoreCase("Driver")&&sh.getRow(i).getCell(11).getStringCellValue().equalsIgnoreCase("Yes")) {
		        		driFirstNameList.add(sh.getRow(i).getCell(2).getStringCellValue());
		        		driLastNameList.add(sh.getRow(i).getCell(1).getStringCellValue());
		        		driNameList.add(driFirstNameList.get(iter)+" "+driLastNameList.get(iter++));
		        	}
	        	}
	        	catch(NullPointerException npe) {
	        	}
	        }
	        
	        driverCount=iter;
	        
	        String returnValue = Integer.toString(fmCount)+";"+Integer.toString(driverCount);
	        
	        return returnValue;
		}										 
																														
		
		 public static void screenSectionDetailsValidation(WebDriver driver,String sectioName,String labelText,String dataDetails, boolean endRun) throws Exception {
		    	try{
		    		switch (sectioName)
		        {
		        case "License, Title & Insurance":
			        if(driver.findElements(By.xpath("//strong[text()='"+sectioName+"']/../following::div//div//div//div[text()='"+labelText+"']")).size()>0)
			            {
			                  dataDetails = driver.findElement(By.xpath("//strong[text()='\"+sectioName+\"']/../following::div//div//div//div[text()='\"+labelText+\"']/following-sibling::div")).getText();       
			                  queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with value",dataDetails, null);
			            }
			            else
			            {
		                     queryObjects.logStatus(driver,Status.FAIL,"The lable :"+labelText+" is not found in section "+sectioName, null,null);
			            }
			        break;
		        
		        }
		    	}
		        catch(NullPointerException npe) {
					queryObjects.logStatus(driver, Status.FAIL, "The lable :"+labelText+" is not found in section "+sectioName, npe.getLocalizedMessage(), npe);
					if(endRun)
						RC_Global.endTestRun(driver);
				}
				catch(TimeoutException te) {
					queryObjects.logStatus(driver, Status.FAIL, "The lable :"+labelText+" is not found in section "+sectioName, te.getLocalizedMessage(), te);
					if(endRun)
						RC_Global.endTestRun(driver);
				}
				catch(Exception e) {
					queryObjects.logStatus(driver, Status.FAIL, "The lable :"+labelText+" is not found in section "+sectioName, e.getLocalizedMessage(), e);
					if(endRun)
						RC_Global.endTestRun(driver);
				}
		        
		    }
		 
	public static void validationOfDocumentAttributesReInherit_Documents(WebDriver driver,boolean endRun) throws Exception //TID_6_1_4_2_03
		{
				String OverwrittenAttr="";
				
				RC_Global.createNode(driver, "Validation Of Document Attributes ReInherit");
				try {
					RC_Global.waitElementVisible(driver, 15, "//legend[text()='Customer Originated']", "Documents tab loading", false, false);
					if(driver.findElement(By.xpath("(//button[text()='No'])[1]")).getAttribute("class").contains("active"))
					{
						queryObjects.logStatus(driver, Status.PASS, "'Inherit Attributes' toggle is set to 'No'", "", null);
					}
					RC_Global.clickUsingXpath(driver, "(//button[text()='Yes'])[1]", "Yes", false, false);
					RC_Global.clickUsingXpath(driver, "(//button[text()='Cancel'])[1]", "Cancel", false, false);
					if(driver.findElement(By.xpath("(//button[text()='No'])[1]")).getAttribute("class").contains("active"))
					{
						queryObjects.logStatus(driver, Status.PASS, "No change is made to 'Inherit Attributes' toggle and the toggle is set to 'No'", "", null);
					}
					if(driver.findElement(By.xpath("//span[text()='Customer Document']/../following-sibling::div/div/label[2]")).getAttribute("class").contains("active"))
					{
						OverwrittenAttr="Customer";
						queryObjects.logStatus(driver, Status.PASS, "'Customer Document' is set to 'Customer' by default", "", null);
						RC_Global.clickUsingXpath(driver, "//span[text()='Customer Document']/../following-sibling::div/div/label[1]", "None", false, false);
						queryObjects.logStatus(driver, Status.PASS, "Now 'Customer Document' is set to 'None'", "", null);
					}
					else if(driver.findElement(By.xpath("//span[text()='Customer Document']/../following-sibling::div/div/label[1]")).getAttribute("class").contains("active"))
					{
						OverwrittenAttr="None";
						queryObjects.logStatus(driver, Status.PASS, "'Customer Document' is set to 'None' by default", "", null);
						RC_Global.clickUsingXpath(driver, "//span[text()='Customer Document']/../following-sibling::div/div/label[2]", "Customer", false, false);
						queryObjects.logStatus(driver, Status.PASS, "Now 'Customer Document' is set to 'Customer'", "", null);
					}
					else
					{
						OverwrittenAttr="Driver";
						queryObjects.logStatus(driver, Status.PASS, "'Customer Document' is set to 'Driver' by default", "", null);
						RC_Global.clickUsingXpath(driver, "//span[text()='Customer Document']/../following-sibling::div/div/label[1]", "None", false, false);
						queryObjects.logStatus(driver, Status.PASS, "Now 'Customer Document' is set to 'None'", "", null);
					}
					RC_Global.clickUsingXpath(driver, "(//button[text()='Yes'])[1]", "Yes", false, false);
					RC_Global.clickButton(driver, "Ok", false, false);
					RC_Global.waitElementVisible(driver, 15, "//legend[text()='Customer Originated']", "Documents tab loading", false, false);
					if(driver.findElement(By.xpath("//span[text()='Customer Document']/../following-sibling::div/div/label[text()='"+OverwrittenAttr+"']")).getAttribute("class").contains("active"))
					{
						queryObjects.logStatus(driver, Status.PASS, "'Customer Document' attribute is overwritten", OverwrittenAttr, null);
					}
					else
					{
						queryObjects.logStatus(driver, Status.FAIL, "'Customer Document' attribute is not overwritten", "", null);
					}
					if(driver.findElement(By.xpath("(//legend[text()='Customer Originated']//..)[1]")).getAttribute("disabled").equals("true"))
					{
						queryObjects.logStatus(driver, Status.PASS, "All groups under Customer Originated are disabled", "", null);
					}
					if(driver.findElement(By.xpath("(//legend[text()='Vehicle Files']//..)[1]")).getAttribute("disabled").equals("true"))
					{
						queryObjects.logStatus(driver, Status.PASS, "All groups under Vehicle Files are disabled", "", null);
					}
					if(driver.findElement(By.xpath("(//legend[text()='Charge Supporting Documents']//..)[1]")).getAttribute("disabled").equals("true"))
					{
						queryObjects.logStatus(driver, Status.PASS, "All groups under Charge Supporting Documents are disabled", "", null);
					}
					if(driver.findElement(By.xpath("(//legend[text()='Plates']//..)[1]")).getAttribute("disabled").equals("true"))
					{
						queryObjects.logStatus(driver, Status.PASS, "All groups under Plates are disabled", "", null);
					}
					try {
						String attrValue = driver.findElement(By.xpath("(//legend[text()='Inheritance']//..)[1]")).getAttribute("disabled");
						if(attrValue==null)
							queryObjects.logStatus(driver, Status.PASS, "'Inheritance' group is able to modify", "", null);
					}
					catch (NullPointerException e)
					{
					}
				}

				catch (Exception e)
				{
					queryObjects.logStatus(driver, Status.FAIL, "Validation Of Document Attributes ReInherit failed", e.getLocalizedMessage(), e);
					if(endRun)
					RC_Global.endTestRun(driver);
				}
	}	 
	
	
public static void toggleButtonStatusValidation(WebDriver driver,String labelName,String toggleName, String toggleStatus ,boolean endRun)throws Exception{
        
		try {
			switch (toggleStatus) {
		    case "Enable":
		    	List<WebElement> ToggleEn = driver.findElements(By.xpath("//div//label[text()='"+labelName+"']//following::div[2]//label[normalize-space(text())='"+toggleName+"']"));
		    
		    	if(ToggleEn.size()>0) {
					queryObjects.logStatus(driver,Status.PASS,""+labelName+" Label "+toggleName+" Toggle is", "Enabled", null);}
		    	break;
		    case "Disable":		
			    List<WebElement> ToggleD = driver.findElements(By.xpath("//label[text()='"+labelName+"']//following::div[2]//label[(text()='"+toggleName+"') and (@disabled = 'disabled')]"));
			    if(ToggleD.size()==0) 
						queryObjects.logStatus(driver,Status.PASS,""+labelName+" Label "+toggleName+" Toggle is", "Disabled", null);
			break;	
		    case "DefaultSelection":		
			    List<WebElement> ToggleDefault = driver.findElements(By.xpath("//div//label[text()='"+labelName+"']//following::div[2]//label[normalize-space(text())='"+toggleName+"']"));
			    if(ToggleDefault.size()>0) 
						queryObjects.logStatus(driver,Status.PASS,""+labelName+" Label "+toggleName+" Toggle is", "Selected By Default", null);
			break;
			}
   
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver,Status.FAIL,"Toggle Status Validation Failed -> Unable to verify the Toggle status", te.getLocalizedMessage(), te);
			if(endRun)
							RC_Global.endTestRun(driver);
		}
		catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver,Status.FAIL,"Toggle Status Validation Failed -> The Toggle could not be found", nse.getLocalizedMessage(), nse);
			if(endRun)
				RC_Global.endTestRun(driver);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver,Status.FAIL,"Toggle Status Validation Failed", e.getLocalizedMessage(), e);
			if(endRun)
				RC_Global.endTestRun(driver);
		}
	}
	
public static void inputBoxFormatValidation(WebDriver driver,String webElementName,String input, String inputFormat ,boolean endRun)throws Exception{
        
		try {
			switch (inputFormat) {
		    case "FormatType":
		    	driver.findElement(By.xpath("//input[@name='"+webElementName+"']")).click();
		    	driver.findElement(By.xpath("//input[@name='"+webElementName+"']")).clear();
		    	driver.findElement(By.xpath("//input[@name='"+webElementName+"']")).sendKeys(""+input+"");
		    	driver.findElement(By.xpath("(//button[text()='Save'])[2]")).isEnabled();//6_1_4_5_02
		    	queryObjects.logStatus(driver,Status.PASS,"The Format Type of "+webElementName+" is", ""+input+" So the Save button is Enabled", null);
		    	break;
		    case "MaxLimit":		
		    	driver.findElement(By.xpath("//input[@name='"+webElementName+"']")).click();
		    	driver.findElement(By.xpath("//input[@name='"+webElementName+"']")).clear();
		    	driver.findElement(By.xpath("//input[@name='"+webElementName+"']")).sendKeys(""+input+"");
		    	driver.findElement(By.xpath("(//button[text()='Save'])[2]")).isEnabled();//6_1_4_5_02
		    	queryObjects.logStatus(driver,Status.PASS,"The Maximum Limit of "+webElementName+" is", ""+input+" So the Save button is Enabled", null);
			break;	
		    case "NegativeValue":		
		    	driver.findElement(By.xpath("//input[@name='"+webElementName+"']")).click();
		    	driver.findElement(By.xpath("//input[@name='"+webElementName+"']")).clear();
		    	driver.findElement(By.xpath("//input[@name='"+webElementName+"']")).sendKeys(""+input+"");
		    	List<WebElement> DisSlctordr = driver.findElements(By.xpath("(//button[text()='Save'])[2]"));//6_1_4_5_02
		    	if(DisSlctordr.size()>0) {
		    	queryObjects.logStatus(driver,Status.PASS,"The Entered Negative Value of "+webElementName+" is ", " "+input+" a InValid Format So the Save button is Disabled", null);
		    	}
			break;
			}
   
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver,Status.FAIL,"Input failed to enter -> Unable to load the the element or the current/previous screen", te.getLocalizedMessage(), te);
			if(endRun)
				RC_Global.endTestRun(driver);
		}
		catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver,Status.FAIL,"Input failed to enter -> Unable to find the correct inputbox to enter the value", nse.getLocalizedMessage(), nse);
			if(endRun)
				RC_Global.endTestRun(driver);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver,Status.FAIL,"Input failed to enter -> Enter the right input", e.getLocalizedMessage(), e);
			if(endRun)
				RC_Global.endTestRun(driver);
		}
	}
     
	

	public static void validateNoSectionFieldDatas(WebDriver driver, String SectionName, String Fieldxpath , boolean endRun)throws Exception{
	String Field= "";
	try {
	if(driver.findElements(By.xpath("//div[@class='hidden-data-set']"+Fieldxpath+"")).size()>0)
	{
	Field = driver.findElement(By.xpath(Fieldxpath)).getText();
	queryObjects.logStatus(driver, Status.PASS,"Verified "+SectionName+" section field "+ Field + " is not available", "Successfully", null);
	} else if(driver.findElements(By.xpath("//div[@class]"+Fieldxpath+"")).size()>0)
	{
	Field = driver.findElement(By.xpath(Fieldxpath)).getText();
	queryObjects.logStatus(driver, Status.PASS,"Verified "+SectionName+" section field "+ Field + " is available", "Successfully", null);
	}
	}
	catch (Exception e) {
	queryObjects.logStatus(driver, Status.FAIL,"Unable to find "+SectionName+" section field "+ Field + " ", "", null);
	if(endRun)
	RC_Global.endTestRun(driver);
	}
	}


	public static void deleteAlert(WebDriver driver, String AlertName, boolean endRun) throws Exception{
		RC_Global.createNode(driver, "Delete Alert");
		WebDriverWait wait = new WebDriverWait(driver,60);
		try {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tbody//tr[1]")));
		List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("//table//tbody//tr"));
		int rowcnt=Getgridrowcnt.size();
		for(int i=1; i<rowcnt;i++) {
		WebElement Alert= driver.findElement(By.xpath("//tbody//tr["+i+"]/td[5]"));
		String AlertNm = Alert.getText();
		if(AlertNm.equalsIgnoreCase(AlertName))
		{
		WebElement AlertDelete = driver.findElement(By.xpath("//tbody//tr["+i+"]/td[5]/../td[17]//a[2][text()='Delete']"));
		AlertDelete.click();
		queryObjects.logStatus(driver, Status.PASS, ""+AlertName+" alert is deleted from alert grid", "Successful", null);
		break;
		}

		}

		}

		catch (Exception e) {
		queryObjects.logStatus(driver, Status.FAIL,"Unable to find "+AlertName+" under alert grid ", "", null);
		if(endRun)
		RC_Global.endTestRun(driver);
		}
		}
	
	public static void verifyCustomerLevelDefinedOrderingProfilesInSubLevels(WebDriver driver,List<String> profileNames,String level,boolean endRun) throws Exception //TID_6_1_4_7_07
	{
	int rowCount; String profileName="";



	RC_Global.createNode(driver, "Validation Of Customer Level defined profiles in "+level+"");
	RC_Global.waitElementVisible(driver, 10, "//*[text()='Add New Profile']", "Ordering Profiles tab is loading", false, false);
	try {
	RC_Global.scrollById(driver, "//span[text()='Profile Name']");
	rowCount=driver.findElements(By.xpath("((//div[@ng-show='showGrid'])[1]/div/div/table)[2]/tbody/tr")).size();
	for(int i=1;i<=rowCount;i++)
	{
	profileName=driver.findElement(By.xpath("((//div[@ng-show='showGrid'])[1]/div/div/table)[2]/tbody/tr["+i+"]/td[3]")).getText();
	int j=i-1;
	if(profileName.equals(profileNames.get(j)))
	{
	queryObjects.logStatus(driver, Status.PASS, "Customer level defined default profile propagated to "+level+"", profileName, null);
	}
	else
	{
	queryObjects.logStatus(driver, Status.FAIL, "Customer level defined default profile propagated to "+level+"", profileName, null);
	}
	}
	}
	catch (Exception e)
	{
	queryObjects.logStatus(driver, Status.FAIL, "Validation Of Customer Level defined profiles in "+level+"is failed", e.getLocalizedMessage(), e);
	if(endRun)
	RC_Global.endTestRun(driver);
	}
	}
	
		public static void validateMaintenanceAgreementType(WebDriver driver, String MaintenanceAgreementType) throws Exception {
	        try {
	        String MaintenanceAgreementtype = driver.findElement(By.xpath("//label[text()='Maintenance Agreement Type']/following::option[text()='"+MaintenanceAgreementType+"']")).getText();
	        if(MaintenanceAgreementtype.equalsIgnoreCase(MaintenanceAgreementType)) 
	              queryObjects.logStatus(driver, Status.PASS, "Maintenance Agreement Type Displayed", "Correctly",null);
	        else
	              queryObjects.logStatus(driver, Status.FAIL, "Maintenance Agreement Type Displayed", "is not correct",null);
	        }      catch(Exception ce) {
	              queryObjects.logStatus(driver, Status.FAIL, "Maintenance Agreement Type Displayed", ce.getLocalizedMessage(), ce);
	              RC_Global.endTestRun(driver);
	        }
		}
 
 
		public static void validateNoSectionFieldDatas(WebDriver driver, String SectionName, String FieldName, String Fieldxpath , boolean endRun)throws Exception{
//            String Field = null;
              try {
                     
                            if(driver.findElements(By.xpath("//div[@class='hidden-data-set']"+Fieldxpath+"")).size()>0)
                            {
                     //            Field = driver.findElement(By.xpath(Fieldxpath)).getText();
                            queryObjects.logStatus(driver, Status.PASS,"Verified "+SectionName+" section field "+ FieldName + " is not available", "Successfully", null);                         
                            }      

                            else if(driver.findElements(By.xpath("//div[@class]"+Fieldxpath+"")).size()>0)
                            {
                     //            Field = driver.findElement(By.xpath(Fieldxpath)).getText();
                            queryObjects.logStatus(driver, Status.PASS,"Verified "+SectionName+" section field "+ FieldName + " is available", "Successfully", null);                      
                            }                    
              }
              catch (Exception e) {
                     queryObjects.logStatus(driver, Status.FAIL,"Unable to find "+SectionName+" section field "+ FieldName + " ", "", null);
                    if(endRun)
                        RC_Global.endTestRun(driver);
              }                    
        }      
  
  	public static void multipleSelectSearchFilter(WebDriver driver, String multSelection, String selectionValue,boolean endRun) throws Exception{
              RC_Global.createNode(driver,"Select Multiple options from "+multSelection+" search filter");
              try {
                     String[] sSelectionValue = null;
              
                     if(selectionValue.contains(";")) {                   //The selections of each multiSelection value is separated by ";" 
                            sSelectionValue = selectionValue.split(";");
                     }
                     WebElement ele = driver.findElement(By.xpath("//select[@id='"+multSelection+"']"));
                     List<WebElement> lElem = driver.findElements(By.xpath("//select[@id='"+multSelection+"']/option"));
                     Select SelectionValue = new Select(driver.findElement(By.xpath("//select[@id='"+multSelection+"']")));
                     
                   driver.findElement(By.xpath("//select[@id='"+multSelection+"']/option[@value][1]")).click();
                     
                     
                     SelectionValue.deselectAll();
                     JavascriptExecutor executor = (JavascriptExecutor)driver;
                        Thread.sleep(1000);
              executor.executeScript("document.body.style.zoom = '30%'");
                        Thread.sleep(2000);
              executor.executeScript("document.body.style.zoom = '100%'");
                     for(int i=0;i<lElem.size()-1;i++){                                        
                            if(sSelectionValue[i].equalsIgnoreCase(lElem.get(i+1).getText())) { 
                                   
                                   SelectionValue.selectByVisibleText(sSelectionValue[i]);                                       
                                   queryObjects.logStatus(driver, Status.PASS, "Vehicle Status", sSelectionValue[i], null);
                     
                            }      
                     }
                     
              }
              catch(Exception e) {
                     queryObjects.logStatus(driver, Status.FAIL, "Unable to select the required options", e.getLocalizedMessage(), e);
                     if(endRun)
                            RC_Global.endTestRun(driver);
              }
 
  }
 
 
  	public static void orderingProfilevalueselection(WebDriver driver, String Section, String Field, String Value, boolean endRun) throws Exception{
        RC_Global.createNode(driver,"'"+Section+"' section - value selection for "+Field+" " );
              
              try {
                     
                     if("courtesyDeliveryFees".equals(Field)) {
                          RC_Global.clickUsingXpath(driver, "//select[@name='"+Field+"']/option[text()='"+Value+"']", ""+Value+" selection", false, false);
                     }
                     else {
                            RC_Global.clickUsingXpath(driver, "(//select[@name='"+Field+"'])[1]", ""+Field+" Field click", false, false);
                          RC_Global.clickUsingXpath(driver, "(//select[@name='"+Field+"'])[1]/option[text()='"+Value+"']", ""+Value+" dropdown selection", false, false);                                      
                     }
                                                                     
                     queryObjects.logStatus(driver, Status.PASS,""+Value+" Selected for the "+Field+" ", "Successfully", null);
              }
              
              catch (Exception e) {
                  queryObjects.logStatus(driver, Status.FAIL,"Unable to find the "+Field+" ", "", null);
                 if(endRun)
                     RC_Global.endTestRun(driver);
              }   
        }
 
	  public static void orderingProfileColumnValidation(WebDriver driver, String ColumnNames, String ProfileName, boolean endRun) throws Exception{
	 try {
	      String[] ColNames = ColumnNames.split(";");
	      String UserName = ""; String oXpath = ""; boolean isUser = false;
	int colmnCnt=ColNames.length;
	JavascriptExecutor js = (JavascriptExecutor) driver;
	        Thread.sleep(1000);
	        try {
	        	driver.findElement(By.xpath("//input[@ng-model='filter.ProfileName']")).sendKeys(ProfileName);
		        driver.findElement(By.xpath("//input[@ng-model='filter.ProfileName']")).sendKeys(Keys.TAB);
		    } catch (Exception e) {}
	        
	for(int i=0;i<colmnCnt;i++)
	{
      if(driver.findElements(By.xpath("(//span[contains(text(),'"+ColNames[i]+"')])[1]")).size()>0)
       {
              js.executeScript("arguments[0].scrollIntoView();", ((WebElement)driver.findElement(By.xpath("(//span[contains(text(),'"+ColNames[i]+"')])[1]"))));
       }
      else if(driver.findElements(By.xpath("(//span[contains(text(),'"+ColNames[i]+"')])[2]")).size()>0)
      {
          js.executeScript("arguments[0].scrollIntoView();", ((WebElement)driver.findElement(By.xpath("(//span[contains(text(),'"+ColNames[i]+"')])[2]"))));
      }
       else
       {
              queryObjects.logStatus(driver, Status.FAIL, "Column Validation for", " Column"+ColNames[i]+" is not available", null);
       }               
	}
	if (driver.findElements(By.xpath("//div[contains(@id,'manufacturer-incentive-programs')]//following-sibling::table//tbody//tr")).size()>0) {
		oXpath = "(//div[contains(@id,'manufacturer-incentive-programs')]//following-sibling::table//tbody//tr)";
	} else {
		oXpath = "(//div[contains(@class,'vehicle-order-profile')]//following-sibling::table//tbody//tr)";
	}
	
              List<WebElement> Gridrowcnt= driver.findElements(By.xpath(oXpath));
              
              for(int i=1; i<=Gridrowcnt.size();i++) {
            	  	 isUser = false;
                     WebElement sub = driver.findElement(By.xpath(oXpath+"["+i+"]//td[3]"));
                     String Pname = sub.getText();
                     WebElement status = driver.findElement(By.xpath(oXpath+"["+i+"]//td[4]"));
                     String Pstatus = status.getText();
                     WebElement Cretd = driver.findElement(By.xpath(oXpath+"["+i+"]//td[5]"));
                     String createdBy = Cretd.getText();                     
                     String BottomUN = driver.findElement(By.xpath("//span[@id='Span1']")).getText();
                     if(BottomUN.equals(createdBy)) {
                     UserName = BottomUN; }
                     else { UserName = Cred.UserName; }
                     if (driver.findElements(By.xpath("//div[contains(@id,'manufacturer-incentive-programs')]//following-sibling::table//tbody//tr")).size()>0) {
                    	 isUser = true;
                 	 } else {
                 		if (createdBy.equals(UserName)) {
                 			isUser = true;
                 		}
                 	 }
                     if((Pname.equals(ProfileName)) && (Pstatus.equals("Active")) && isUser) {
                     queryObjects.logStatus(driver, Status.INFO, "Verified the Newly created profile details as - ProfileName->"+Pname+", ProfileStatus->"+Pstatus+", ProfilecreatedBy->"+Cred.UserName+" under grid","Succesfully" , null);
                     queryObjects.logStatus(driver, Status.PASS, "Verified the Newly created profile under grid","Succesfully" , null);
                     break;}
              }                             
  	}
        catch (Exception e){
              queryObjects.logStatus(driver, Status.FAIL, "Unable to find the newly created profile under grid", e.getLocalizedMessage(), e);  
              if(endRun)
                     RC_Global.endTestRun(driver);   
        }
  	}
	  
	  public static void selectFleetMetricesDashboardAdminstration(WebDriver driver,String option,boolean endRun) throws Exception
		{
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			Thread.sleep(1000);
			try {
				executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//h3[text()='Fleet Metrics']/../div/div/span[text()='"+option+"']/../../div[2]/input")));
				RC_Global.clickUsingXpath(driver, "//h3[text()='Fleet Metrics']/../div/div/span[text()='"+option+"']/../../div[2]/input", option, false, false);
				
			}
			catch (Exception e)
			{
				queryObjects.logStatus(driver, Status.FAIL, "Checkbox is not clicked", option, null);
				if(endRun)
				RC_Global.endTestRun(driver);
			}
		}
		
		public static void selectFleetExceptionsAndAlertsDashboardAdminstration(WebDriver driver,String option,boolean endRun) throws Exception
		{
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			Thread.sleep(1000);
			try {
				executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//h3[text()='Fleet Exceptions and Alerts']/../div/div/span[text()='"+option+"']/../../div[2]/input")));
				RC_Global.clickUsingXpath(driver, "//h3[text()='Fleet Exceptions and Alerts']/../div/div/span[text()='"+option+"']/../../div[2]/input", option, false, false);
			}
			catch (Exception e)
			{
				queryObjects.logStatus(driver, Status.FAIL, "Checkbox is not clicked", option, null);
				if(endRun)
				RC_Global.endTestRun(driver);
			}
		}

		public static void selectFleetFactsDashboardAdminstration(WebDriver driver,String option,boolean endRun) throws Exception
		{
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			Thread.sleep(1000);
			try {
				executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//h3[text()='Fleet Facts']/../div/div/span[text()='"+option+"']/../../div[2]/input")));
				if(option.equals("Average Price per Gallon"))
				{
					RC_Global.clickUsingXpath(driver, "(//h3[text()='Fleet Facts']/../div/div/span[text()='"+option+"']/../../div[2]/input)[1]", option, false, false);
				}
				else
					RC_Global.clickUsingXpath(driver, "//h3[text()='Fleet Facts']/../div/div/span[text()='"+option+"']/../../div[2]/input", option, false, false);
			}
			catch (Exception e)
			{
				queryObjects.logStatus(driver, Status.FAIL, "Checkbox is not clicked", option, null);
				if(endRun)
				RC_Global.endTestRun(driver);
			}
		}
		public static void selectGraphicsDashboardAdminstration(WebDriver driver,String option,boolean endRun) throws Exception
		{
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			Thread.sleep(1000);
			try {
				executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//h3[text()='Graphics']/../div/div/span[text()='"+option+"']/../../div[2]/input")));
				RC_Global.clickUsingXpath(driver, "//h3[text()='Graphics']/../div/div/span[text()='"+option+"']/../../div[2]/input", option, false, false);
			}
			catch (Exception e)
			{
				queryObjects.logStatus(driver, Status.FAIL, "Checkbox is not clicked", option, null);
				if(endRun)
				RC_Global.endTestRun(driver);
			}
		}
		
		public static void validateFleetMetricesSectionDataLink_DashboardAdminstration(WebDriver driver,boolean endRun) throws Exception
		{
			int rowCount;String data="";String dataLink="";
			RC_Global.createNode(driver, "Validate Fleet Metrics section");
			Thread.sleep(1000);
			try {
				RC_Global.clickUsingXpath(driver, "(//*[text()='Fleet Metrics'])[1]/../span[2]/i", "Expand Fleet Metrics", false, false);
				RC_Global.waitElementVisible(driver, 30, "(//*[text()='Total Fleet Size'])[2]", "Fleet Metrics data are displayed", false, false);
				rowCount=driver.findElements(By.xpath("(//*[text()='Fleet Metrics'])[2]/../../div[2]/div/div[contains(@class,'dashboard-widget')]")).size();
				for(int i=1;i<=rowCount;i++)
				{
					data=driver.findElement(By.xpath("(//*[text()='Fleet Metrics'])[2]/../../div[2]/div/div[contains(@class,'dashboard-widget')]["+i+"]/div/div/span[1]")).getText();
					dataLink=driver.findElement(By.xpath("(//*[text()='Fleet Metrics'])[2]/../../div[2]/div/div[contains(@class,'dashboard-widget')]["+i+"]/div/div/a/span[2]")).getText();
					RC_Global.clickUsingXpath(driver, "(//*[text()='Fleet Metrics'])[2]/../../div[2]/div/div[contains(@class,'dashboard-widget')]["+i+"]/div/div/a/span[2]", data+" respective hyperlink", false, false);
					Thread.sleep(1000);
					if(driver.findElements(By.xpath("(//h5)[2]/span[1]")).size()>0)
					{
						queryObjects.logStatus(driver, Status.PASS, driver.findElement(By.xpath("(//h5)[2]/span[1]")).getText()+" screen is opened for", data, null);
					}
					if(dataLink.equals("0"))
					{
						queryObjects.logStatus(driver, Status.PASS, "No Records Found for", data, null);
					}
					else
					{
						RC_Global.waitElementVisible(driver, 30, "//td[text()='Customer Name']", "Data's are displayed in the grid", false, false);
						if(driver.findElements(By.xpath("//td[text()='Customer Name']")).size()>0)
						{
							queryObjects.logStatus(driver, Status.PASS, "Data's are displayed in the grid for", data, null);
						}
					}
					RC_Global.panelAction(driver, "close", driver.findElement(By.xpath("(//h5)[2]/span[1]")).getText(), false, false);
					RC_Global.clickUsingXpath(driver, "(//*[text()='Fleet Metrics'])[1]/../span[2]/i", "Expand Fleet Metrics", false, false);
					RC_Global.waitElementVisible(driver, 30, "(//*[text()='Total Fleet Size'])[2]", "Fleet Metrics data are displayed", false, false);
				}
				RC_Global.clickUsingXpath(driver, "(//div[@class='ng-modal-close'])[2]/div/i", "Close Fleet Metrics", false, false);
			}
			catch (Exception e)
			{
				queryObjects.logStatus(driver, Status.FAIL, "Failed to validate Fleet Metrics section", "", null);
				if(endRun)
				RC_Global.endTestRun(driver);
			}
		}
		
		public static void validateExceptionsAndAlertsSectionDataLinkDashboardAdminstration(WebDriver driver,boolean endRun) throws Exception
		{
	
			RC_Global.createNode(driver, "Validate Exceptions And Alerts section");
			Thread.sleep(1000);
			try {
				RC_Global.clickUsingXpath(driver, "(//*[text()='Exceptions & Alerts'])[1]/../span[2]/i", "Expand Exceptions And Alerts", false, false);
				RC_Global.waitElementVisible(driver, 60, "(//*[text()='Open Maintenance POs'])[2]", "Exceptions And Alerts data are displayed", false, false);
				int rowCount=driver.findElements(By.xpath("(//*[text()='Exceptions & Alerts'])[2]/../../div[2]/div/div[contains(@class,'dashboard-widget')]")).size();
				for(int i=1;i<=rowCount;i++)
				{
					String data=driver.findElement(By.xpath("(//*[text()='Exceptions & Alerts'])[2]/../../div[2]/div/div[contains(@class,'dashboard-widget')]["+i+"]/div/div/span[1]")).getText();
					String dataLink=driver.findElement(By.xpath("(//*[text()='Exceptions & Alerts'])[2]/../../div[2]/div/div[contains(@class,'dashboard-widget')]["+i+"]/div/div/a/span[2]")).getText();
					RC_Global.clickUsingXpath(driver, "(//*[text()='Exceptions & Alerts'])[2]/../../div[2]/div/div[contains(@class,'dashboard-widget')]["+i+"]/div/div/a/span[2]", data+" respective hyperlink", false, false);
					Thread.sleep(1000);
					if(driver.findElements(By.xpath("(//h5)[2]/span[1]")).size()>0)
					{
						queryObjects.logStatus(driver, Status.PASS, driver.findElement(By.xpath("(//h5)[2]/span[1]")).getText()+" screen is opened for", data, null);
					}
					if(dataLink.equals("0"))
					{
						queryObjects.logStatus(driver, Status.PASS, "No Records Found for", data, null);
					}
					else
					{
						RC_Global.waitElementVisible(driver, 60, "//td[text()='Customer Name']", "Grid is Displayed", false, false);
						if(driver.findElements(By.xpath("//tbody//tr[3]//td[1]//div")).size()>0)
						{
							queryObjects.logStatus(driver, Status.PASS, "Data's are displayed in the grid for", data, null);
						}
						else {
							queryObjects.logStatus(driver, Status.FAIL, "Data's are Not displayed in the grid for", data, null);
						}
					}
					RC_Global.panelAction(driver, "close", driver.findElement(By.xpath("(//h5)[2]/span[1]")).getText(), false, false);
					RC_Global.clickUsingXpath(driver, "(//*[text()='Exceptions & Alerts'])[1]/../span[2]/i", "Expand Exceptions & Alerts", false, false);
					RC_Global.waitElementVisible(driver, 60, "//*[text()='Open Maintenance POs']", "Exceptions & Alerts data are displayed", false, false);
				}
				RC_Global.clickUsingXpath(driver, "(//div[@class='ng-modal-close'])[1]/div/i", "Close Exceptions & Alerts", false, false);
			}
			catch (Exception e)
			{
				queryObjects.logStatus(driver, Status.FAIL, "Failed to validate Exceptions & Alerts section", "", null);
				if(endRun)
				RC_Global.endTestRun(driver);
			}
		}
		
		public static void validateFleetFactsSectionDataLinkDashboardAdminstration(WebDriver driver,boolean endRun) throws Exception
		{
	
			RC_Global.createNode(driver, "Validate Fleet Facts section");
			Thread.sleep(1000);
			try {
				RC_Global.clickUsingXpath(driver, "(//*[text()='Fleet Facts'])[1]/../span[2]/i", "Expand Fleet Facts", false, false);
				RC_Global.waitElementVisible(driver, 60, "//*[text()='Average Maintenance Cost per Unit']", "Fleet Facts data are displayed", false, false);
				int rowCount=driver.findElements(By.xpath("(//*[text()='Fleet Facts'])[2]/../../div[2]/div/div[contains(@class,'dashboard-widget')]")).size();
				for(int i=1;i<=rowCount;i++)
				{
					String data=driver.findElement(By.xpath("(//*[text()='Fleet Facts'])[2]/../../div[2]/div/div[contains(@class,'dashboard-widget')]["+i+"]/div/div/span[1]")).getText();
					String dataLink=driver.findElement(By.xpath("(//*[text()='Fleet Facts'])[2]/../../div[2]/div/div[contains(@class,'dashboard-widget')]["+i+"]/div/div/a/span[2]")).getText();
					RC_Global.clickUsingXpath(driver, "(//*[text()='Fleet Facts'])[2]/../../div[2]/div/div[contains(@class,'dashboard-widget')]["+i+"]/div/div/a/span[2]", data+" respective hyperlink", false, false);
					Thread.sleep(1000);
					if(driver.findElements(By.xpath("(//h5)[2]/span[1]")).size()>0)
					{
						queryObjects.logStatus(driver, Status.PASS, driver.findElement(By.xpath("(//h5)[2]/span[1]")).getText()+" screen is opened for", data, null);
					}
					if(dataLink.equals("0"))
					{
						queryObjects.logStatus(driver, Status.PASS, "No Records Found for", data, null);
					}
					else
					{
						RC_Global.waitElementVisible(driver, 60, "//td[text()='Customer Name']", "Grid is Displayed", false, false);
						if(driver.findElements(By.xpath("//tbody//tr[3]//td[1]//div")).size()>0)
						{queryObjects.logStatus(driver, Status.PASS, "Data's are displayed in the grid for", data, null);}
						else {
							queryObjects.logStatus(driver, Status.FAIL, "Data's are Not displayed in the grid for", data, null);
						}
					}
					RC_Global.panelAction(driver, "close", driver.findElement(By.xpath("(//h5)[2]/span[1]")).getText(), false, false);
					RC_Global.clickUsingXpath(driver, "(//*[text()='Fleet Facts'])[1]/../span[2]/i", "Expand Fleet Facts", false, false);
					RC_Global.waitElementVisible(driver, 60, "//*[text()='Average Maintenance Cost per Unit']", "Fleet Facts data are displayed", false, false);
				}
				RC_Global.clickUsingXpath(driver, "(//div[@class='ng-modal-close'])[1]/div/i", "Close Fleet Facts", false, false);
			}
			catch (Exception e)
			{
				queryObjects.logStatus(driver, Status.FAIL, "Failed to validate Fleet Facts section", "", null);
				if(endRun)
				RC_Global.endTestRun(driver);
			}
		}

		public static void optionFieldSelectionandOrderValidation(WebDriver driver, String FieldName, String checkbox, String order,String ordervalue, boolean endRun) throws Exception{
			 try {
				 JavascriptExecutor executor = (JavascriptExecutor) driver;
				 //checkbox validate
				 if("Yes".equals(checkbox))
				 {
					 executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//div[div/span[text()='"+FieldName+"']]")));
					 if(driver.findElements(By.xpath("//div[div/span[text()='"+FieldName+"']]/div/input[contains(@class,'ng-not-empty') and @type='checkbox']")).size()>0)
					 {	
						 queryObjects.logStatus(driver, Status.PASS, " '"+FieldName+"' checkbox is selected","Succesfully" , null);
					 }
					 else {
						 queryObjects.logStatus(driver, Status.FAIL, " '"+FieldName+"' checkbox is not selected"," " , null);
					 }					 
				 }					
			
				 //order
				 if("Yes".equals(order))
				 {
					 executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//div/span[text()='"+FieldName+"']")));
					 if(driver.findElements(By.xpath("//div/span[text()='"+FieldName+"']/following::div[2]/input[contains(@class,'ng-not-empty')]")).size()==1)
					 {	String OrderValue = driver.findElement(By.xpath("//div/span[text()='"+FieldName+"']/following::div[2]/input[contains(@class,'ng-not-empty')]")).getAttribute("value");			 
					 	if(ordervalue.equals(OrderValue)) {
						 queryObjects.logStatus(driver, Status.PASS, " '"+FieldName+"' Order is displayed and Ordervalue '"+ordervalue+"' is matched","Succesfully" , null);
					 	}
					 	else{
							 queryObjects.logStatus(driver, Status.FAIL, " '"+FieldName+"' Ordervalue is not matched","" , null);
						 	} 
					 }
					 else if(driver.findElements(By.xpath("//div/span[text()='"+FieldName+"']/following::div[5]/input[contains(@class,'ng-not-empty')]")).size()==1)
					 {	String OrderValue = driver.findElement(By.xpath("//div/span[text()='"+FieldName+"']/following::div[5]/input[contains(@class,'ng-not-empty')]")).getAttribute("value");			 	
					 	if(ordervalue.equals(OrderValue)) {
						 queryObjects.logStatus(driver, Status.PASS, " '"+FieldName+"' Order is displayed and Ordervalue '"+ordervalue+"' is matched","Succesfully" , null);
					 	}
					 	else{
							 queryObjects.logStatus(driver, Status.FAIL, " '"+FieldName+"' Ordervalue is not matched","" , null);
						 	}
					 }
					 else if(driver.findElements(By.xpath("//div/span[text()='"+FieldName+"']/following::div[8]/input[contains(@class,'ng-not-empty')]")).size()==1)
					 {	String OrderValue = driver.findElement(By.xpath("//div/span[text()='"+FieldName+"']/following::div[8]/input[contains(@class,'ng-not-empty')]")).getAttribute("value");			 	
					 	if(ordervalue.equals(OrderValue)) {
						 queryObjects.logStatus(driver, Status.PASS, " '"+FieldName+"' Order is displayed and Ordervalue '"+ordervalue+"' is matched","Succesfully" , null);
					 	}
					 	else{
							 queryObjects.logStatus(driver, Status.FAIL, " '"+FieldName+"' Ordervalue is not matched","" , null);
						 	}
					 }
					 else if(driver.findElements(By.xpath("//div/span[text()='"+FieldName+"']/following::div[10]/input[contains(@class,'ng-not-empty')]")).size()==1)
					 {	String OrderValue = driver.findElement(By.xpath("//div/span[text()='"+FieldName+"']/following::div[10]/input[contains(@class,'ng-not-empty')]")).getAttribute("value");			 	
					 	if(ordervalue.equals(OrderValue)) {
						 queryObjects.logStatus(driver, Status.PASS, " '"+FieldName+"' Order is displayed and Ordervalue '"+ordervalue+"' is matched","Succesfully" , null);
					 	}
					 	else{
							 queryObjects.logStatus(driver, Status.FAIL, " '"+FieldName+"' Ordervalue is not matched","" , null);
						 	}
					 }
					 else {
						 queryObjects.logStatus(driver, Status.FAIL, " '"+FieldName+"' Order is not displayed"," " , null);
					 }	
				 }
				 }
			 catch (Exception e){
				  queryObjects.logStatus(driver, Status.FAIL, "Unable to find '"+FieldName+"' under dashboard Administration", e.getLocalizedMessage(), e);  
				  if(endRun)
				  RC_Global.endTestRun(driver);   
			      }
			 }
			 
			 
			 public static void selectFleetMetrices_DashboardAdminstration(WebDriver driver,String option,boolean endRun) throws Exception
				{
					JavascriptExecutor executor = (JavascriptExecutor) driver;
					Thread.sleep(1000);
					try {
						executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//h3[text()='Fleet Metrics']/../div/div/span[text()='"+option+"']/../../div[2]/input")));
						RC_Global.clickUsingXpath(driver, "//h3[text()='Fleet Metrics']/../div/div/span[text()='"+option+"']/../../div[2]/input", option, false, false);
						
					}
					catch (Exception e)
					{
						queryObjects.logStatus(driver, Status.FAIL, "Checkbox is not clicked", option, null);
						if(endRun)
						RC_Global.endTestRun(driver);
					}
				}
			 
			 public static void selectFleetExceptionsAndAlerts_DashboardAdminstration(WebDriver driver,String option,boolean endRun) throws Exception
				{
					JavascriptExecutor executor = (JavascriptExecutor) driver;
					Thread.sleep(1000);
					try {
						executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//h3[text()='Fleet Exceptions and Alerts']/../div/div/span[text()='"+option+"']/../../div[2]/input")));
						RC_Global.clickUsingXpath(driver, "//h3[text()='Fleet Exceptions and Alerts']/../div/div/span[text()='"+option+"']/../../div[2]/input", option, false, false);
					}
					catch (Exception e)
					{
						queryObjects.logStatus(driver, Status.FAIL, "Checkbox is not clicked", option, null);
						if(endRun)
						RC_Global.endTestRun(driver);
					}
				}

				public static void selectFleetFacts_DashboardAdminstration(WebDriver driver,String option,boolean endRun) throws Exception
				{
					JavascriptExecutor executor = (JavascriptExecutor) driver;
					Thread.sleep(1000);
					try {
						executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//h3[text()='Fleet Facts']/../div/div/span[text()='"+option+"']/../../div[2]/input")));
						if(option.equals("Average Price per Gallon"))
						{
							RC_Global.clickUsingXpath(driver, "(//h3[text()='Fleet Facts']/../div/div/span[text()='"+option+"']/../../div[2]/input)[1]", option, false, false);
						}
						else
							RC_Global.clickUsingXpath(driver, "//h3[text()='Fleet Facts']/../div/div/span[text()='"+option+"']/../../div[2]/input", option, false, false);
					}
					catch (Exception e)
					{
						queryObjects.logStatus(driver, Status.FAIL, "Checkbox is not clicked", option, null);
						if(endRun)
						RC_Global.endTestRun(driver);
					}
				}
				public static void selectGraphics_DashboardAdminstration(WebDriver driver,String option,boolean endRun) throws Exception
				{
					JavascriptExecutor executor = (JavascriptExecutor) driver;
					Thread.sleep(1000);
					try {
						executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//h3[text()='Graphics']/../div/div/span[text()='"+option+"']/../../div[2]/input")));
						RC_Global.clickUsingXpath(driver, "//h3[text()='Graphics']/../div/div/span[text()='"+option+"']/../../div[2]/input", option, false, false);
					}
					catch (Exception e)
					{
						queryObjects.logStatus(driver, Status.FAIL, "Checkbox is not clicked", option, null);
						if(endRun)
						RC_Global.endTestRun(driver);
					}
				}

				public static void selectCheckBoxesDashboardAdminstration(WebDriver driver,String option_Chkbx,String sectionName,boolean endRun) throws Exception
				{
					JavascriptExecutor executor = (JavascriptExecutor) driver;
					Thread.sleep(1000);
					try {
						executor.executeScript("arguments[0].scrollIntoView(true)", driver.findElement(By.xpath("//h3[text()='"+sectionName+"']/../div/div/span[text()='"+option_Chkbx+"']/../../div[2]/input")));
						if(option_Chkbx.equals("Average Price per Gallon") && sectionName.equals("Fleet Facts"))
						{
							RC_Global.clickUsingXpath(driver, "(//h3[text()='Fleet Facts']/../div/div/span[text()='"+option_Chkbx+"']/../../div[2]/input)[1]", option_Chkbx, false, false);
						}
						else if(option_Chkbx.equals("National Account Utilization") && sectionName.equals("Graphics"))
						{
							RC_Global.clickUsingXpath(driver, "//h3[text()='"+sectionName+"']/../div/div/span[text()='"+option_Chkbx+"']/../../div[2]/input", option_Chkbx, false, false);
							Thread.sleep(1000);
							Select timeframe=new Select(driver.findElement(By.xpath("(//h3[text()='Graphics']/../div/div/span[text()='National Account Utilization']/../../div[4]/div/div/select)[1]")));
							timeframe.selectByVisibleText("LTD");
						}
						else
						RC_Global.clickUsingXpath(driver, "//h3[text()='"+sectionName+"']/../div/div/span[text()='"+option_Chkbx+"']/../../div[2]/input", option_Chkbx, false, false);
					}
					catch (Exception e)
					{
						queryObjects.logStatus(driver, Status.FAIL, "Checkbox is not clicked", option_Chkbx+"from "+sectionName, null);
						if(endRun)
						RC_Global.endTestRun(driver);
					}
				}
				
				public static void validateDashboardGroup1GraphSection(WebDriver driver,String graphName,boolean endRun) throws Exception
				{
					String colNames="";String tCount="";
					try {
					RC_Global.waitElementVisible(driver, 15, "//span[text()='"+graphName+"']/../..//div[@class='highcharts-container']//*[name()='g']/*[name()='path' and contains(@fill,'953735')][5]", "Graph is displayed", false, false);
					RC_Global.clickUsingXpath(driver, "//span[text()='"+graphName+"']/../..//div[@class='highcharts-container']//*[name()='g']/*[name()='path' and contains(@fill,'953735')][5]", "A point on "+graphName+" graph", false, true);
					if( driver.findElements(By.xpath("//h5/span[1]")).size()>0)
					{
						queryObjects.logStatus(driver, Status.PASS, driver.findElement(By.xpath("//h5/span[1]")).getText()+" screen is displayed", "", null);
					}
					if(graphName.equals("Total Monthly Maintenance Spend"))
					{
						colNames="Timeframe;Total Monthly Spend;Vehicle Count;Transaction Count";
						RC_Global.verifyColumnNames(driver, colNames, endRun);
						//step 19 skipped
						
//						tCount=driver.findElement(By.xpath("//table/tbody/tr[2]/td[4]/span/a/span")).getText();
//						RC_Global.clickUsingXpath(driver, "//table/tbody/tr[2]/td[1]/span/a/span", driver.findElement(By.xpath("//table/tbody/tr[2]/td[1]/span/a/span")).getText()+" from the Timeframe column", false, true);
//						RC_Global.waitElementVisible(driver, 10, "//table/tbody", "Grid is displayed", false, false);
//						RC_Global.scrollById(driver, "//div[@class='col-xs-12']/div[3]/span");
//						Thread.sleep(5000);
//						String noOfResult[]=driver.findElement(By.xpath("//div[@class='col-xs-12']/div[3]/span")).getText().split("of");
//						if(noOfResult[1].trim().split(" ")[0].contains(tCount))
//						{
//							queryObjects.logStatus(driver, Status.PASS, "Number Of transaction Matches the Number of data rows loaded in the new grid", tCount, null);
//						}
//						else
//						{
//							queryObjects.logStatus(driver, Status.FAIL, "Number Of transaction does not match the Number of data rows loaded in the new grid", "", null);
//						}
//						RC_Global.scrollById(driver, "//h5/span[1]");
//						RC_Global.clickButton(driver, "Back", false, true);
						
						
						RC_Global.clickUsingXpath(driver, "//table/tbody/tr[1]/td[2]/span/a/span", "Data of Total Monthly Spend Column", false, true);
						Thread.sleep(1000);
						if(driver.findElements(By.xpath("//h5/span[text()='Maintenance History Summary (E)']")).size()>0)
						{
							queryObjects.logStatus(driver, Status.PASS, "Maintenance History Summary (E) screen is displayed", "", null);
							RC_Global.panelAction(driver, "close", "Maintenance History Summary (E)", false, true);
						}
					}
					else if(graphName.equals("Total Monthly Fuel Spend"))
					{
						colNames="Timeframe;Total Monthly Spend;Vehicle Count;Transaction Count";
						RC_Global.verifyColumnNames(driver, colNames, endRun);
						//step 24 skipped
						
//						tCount=driver.findElement(By.xpath("//table/tbody/tr[2]/td[4]/span/a/span")).getText();
//						RC_Global.clickUsingXpath(driver, "//table/tbody/tr[2]/td[1]/span/a/span", driver.findElement(By.xpath("//table/tbody/tr[2]/td[1]/span/a/span")).getText()+" from the Timeframe column", false, true);
//						RC_Global.waitElementVisible(driver, 10, "//table/tbody/tr[1]", "Grid is displayed", false, false);
//						RC_Global.scrollById(driver, "//div[@class='col-xs-12']/div[3]/span");
//						Thread.sleep(5000);
//						String noOfResult[]=driver.findElement(By.xpath("//div[@class='col-xs-12']/div[3]/span")).getText().split("of");
//						if(noOfResult[1].trim().split(" ")[0].contains(tCount))
//						{
//							queryObjects.logStatus(driver, Status.PASS, "Number Of transaction Matches the Number of data rows loaded in the new grid", tCount, null);
//						}
//						else
//						{
//							queryObjects.logStatus(driver, Status.FAIL, "Number Of transaction does not match the Number of data rows loaded in the new grid", "", null);
//						}
//						RC_Global.scrollById(driver, "//h5/span[1]");
//						RC_Global.clickButton(driver, "Back", false, true);
						
						
						RC_Global.clickUsingXpath(driver, "//table/tbody/tr[1]/td[2]/span/a/span", "Data of Total Monthly Spend Column", false, true);
						Thread.sleep(1000);
						if(driver.findElements(By.xpath("//h5/span[text()='Fuel Summary By Vehicle (E)']")).size()>0)
						{
							queryObjects.logStatus(driver, Status.PASS, "Fuel Summary By Vehicle (E) screen is displayed", "", null);
							RC_Global.panelAction(driver, "close", "Fuel Summary By Vehicle (E)", false, true);
						}
					}
					else if(graphName.equals("Total Monthly Lease Spend"))
					{
						colNames="Timeframe;Lease Spend";
						RC_Global.verifyColumnNames(driver, colNames, endRun);
						RC_Global.clickUsingXpath(driver, "//table/tbody/tr[1]/td[2]/span/a/span", "Data of Lease Spend Column", false, true);
						Thread.sleep(1000);
						if(driver.findElements(By.xpath("//h5/span[text()='Units On Lease (E)']")).size()>0)
						{
							queryObjects.logStatus(driver, Status.PASS, "Units On Lease (E) screen is displayed", "", null);
							RC_Global.panelAction(driver, "close", "Units On Lease (E)", false, true);
						}
					}
					RC_Global.panelAction(driver, "close", driver.findElement(By.xpath("//h5/span[1]")).getText(), false, true);
					}
					catch (Exception e)
					{
						queryObjects.logStatus(driver, Status.FAIL, "Failed to validate DashboardGroup1 graph section", e.getLocalizedMessage(), null);
						if(endRun)
						RC_Global.endTestRun(driver);
					}
				}
				
				public static void validateDashboardGroup2GraphSection(WebDriver driver,String graphName,boolean endRun) throws Exception
				{
					String colNames="";String uServed="";
					try {
					if(graphName.equals("National Account Utilization"))
					{
						RC_Global.clickUsingXpath(driver, "(//span[text()='National Account Utilization'])[1]/../span[2]/i", "Expand "+graphName, false, false);
					}
					if(graphName.equals("Average Maintenance Cost per Unit"))
					{
						RC_Global.waitElementVisible(driver, 60, "//span[text()='Average Maintenance Cost per Unit']/../..//div[@class='highcharts-container']//*[name()='g']/*[name()='rect' and contains(@fill,'#A6A6A6')][1]", "Graph is displayed", false, false);
						RC_Global.clickUsingXpath(driver, "//span[text()='Average Maintenance Cost per Unit']/../..//div[@class='highcharts-container']//*[name()='g']/*[name()='rect' and contains(@fill,'#A6A6A6')][1]", "A point on "+graphName+" graph", false, true);
					}
					else
					{
						RC_Global.waitElementVisible(driver, 60, "//span[text()='"+graphName+"']/../..//div[@class='highcharts-container']//*[name()='g']/*[name()='path' and contains(@fill,'953735')][5]", "Graph is displayed", false, false);
						RC_Global.clickUsingXpath(driver, "//span[text()='"+graphName+"']/../..//div[@class='highcharts-container']//*[name()='g']/*[name()='path' and contains(@fill,'953735')][5]", "A point on "+graphName+" graph", false, true);
					}
					if( driver.findElements(By.xpath("//h5/span[1]")).size()>0)
					{
						queryObjects.logStatus(driver, Status.PASS, driver.findElement(By.xpath("//h5/span[1]")).getText()+" screen is displayed", "", null);
					}
					if(graphName.equals("National Account Utilization"))
					{
						colNames="Timeframe;National Account;Non-National Acount;Number of Units Serviced";
						RC_Global.verifyColumnNames(driver, colNames, endRun);
						//step 19 skipped
						
//						uServed=driver.findElement(By.xpath("//table/tbody/tr[2]/td[4]/span/a/span")).getText();
//						RC_Global.clickUsingXpath(driver, "//table/tbody/tr[2]/td[1]/span/a/span", driver.findElement(By.xpath("//table/tbody/tr[2]/td[1]/span/a/span")).getText()+" from the Timeframe column", false, true);
//						RC_Global.waitElementVisible(driver, 10, "//table/tbody/tr[1]", "Grid is displayed", false, false);
//						RC_Global.scrollById(driver, "//div[@class='col-xs-12']/div[3]/span");
//						Thread.sleep(5000);
//						String noOfResult[]=driver.findElement(By.xpath("//div[@class='col-xs-12']/div[3]/span")).getText().split("of");
//						if(noOfResult[1].trim().split(" ")[0].contains(uServed))
//						{
//							queryObjects.logStatus(driver, Status.PASS, "Number Of Unit Served Matches the Number of data rows loaded in the new grid", uServed, null);
//						}
//						else
//						{
//							queryObjects.logStatus(driver, Status.FAIL, "Number Of Unit Served does not match the Number of data rows loaded in the new grid", "", null);
//						}
//						RC_Global.scrollById(driver, "//h5/span[1]");
//						RC_Global.clickButton(driver, "Back", false, true);
						
						RC_Global.clickUsingXpath(driver, "//table/tbody/tr[1]/td[3]/span/a/span", "Data of Non-National Acount Column", false, true);
						Thread.sleep(1000);
						if(driver.findElements(By.xpath("//h5/span[text()='Preferred Vendor Utilization (E)']")).size()>0)
						{
							queryObjects.logStatus(driver, Status.PASS, "Preferred Vendor Utilization (E) screen is displayed", "", null);
							RC_Global.panelAction(driver, "close", "Preferred Vendor Utilization (E)", false, true);
						}
					}
					else if(graphName.equals("Average Fuel Price per Gallon"))
					{
						colNames="Timeframe;Average PPG;High PPG;Low PPG;Vehicle Count";
						RC_Global.verifyColumnNames(driver, colNames, endRun);
						RC_Global.clickUsingXpath(driver, "//table/tbody/tr[1]/td[2]/span/a/span", "Data of Average PPG Column", false, true);
						Thread.sleep(1000);
						if(driver.findElements(By.xpath("//h5/span[text()='Fuel Summary By Vehicle (E)']")).size()>0)
						{
							queryObjects.logStatus(driver, Status.PASS, "Fuel Summary By Vehicle (E) screen is displayed", "", null);
							RC_Global.panelAction(driver, "close", "Fuel Summary By Vehicle (E)", false, true);
							RC_Global.panelAction(driver, "expand", driver.findElement(By.xpath("//h5/span[1]")).getText(), false, true);
						}
						RC_Global.clickUsingXpath(driver, "//table/tbody/tr[1]/td[3]/span/a/span", "Data of High PPG Column", false, true);
						Thread.sleep(1000);
						if(driver.findElements(By.xpath("//h5/span[text()='Fuel Transaction Detail (E)']")).size()>0)
						{
							queryObjects.logStatus(driver, Status.PASS, "Fuel Transaction Detail (E) screen is displayed", "", null);
							RC_Global.panelAction(driver, "close", "Fuel Transaction Detail (E)", false, true);
							RC_Global.panelAction(driver, "expand", driver.findElement(By.xpath("//h5/span[1]")).getText(), false, true);
						}
						RC_Global.clickUsingXpath(driver, "//table/tbody/tr[1]/td[4]/span/a/span", "Data of Low PPG Column", false, true);
						Thread.sleep(1000);
						if(driver.findElements(By.xpath("//h5/span[text()='Fuel Transaction Detail (E)']")).size()>0)
						{
							queryObjects.logStatus(driver, Status.PASS, "Fuel Transaction Detail (E) screen is displayed", "", null);
							RC_Global.panelAction(driver, "close", "Fuel Transaction Detail (E)", false, true);
						}
						
					}
					else if(graphName.equals("Average Maintenance Cost per Unit"))
					{
						colNames="Timeframe;Average Cost per Unit;High Cost per unit;Low Cost per Unit;Vehicle Count";
						RC_Global.verifyColumnNames(driver, colNames, endRun);
						//step 30 skipped
						
						
						RC_Global.clickUsingXpath(driver, "//table/tbody/tr[1]/td[2]/span/a/span", "Data of Average Cost per Unit Column", false, true);
						Thread.sleep(1000);
						if(driver.findElements(By.xpath("//h5/span[text()='Maintenance History Summary (E)']")).size()>0)
						{
							queryObjects.logStatus(driver, Status.PASS, "Maintenance History Summary (E) screen is displayed", "", null);
							RC_Global.panelAction(driver, "close", "Maintenance History Summary (E)", false, true);
						}
					}

					RC_Global.panelAction(driver, "close", driver.findElement(By.xpath("//h5/span[1]")).getText(), false, true);
					}
					catch (Exception e)
					{
						queryObjects.logStatus(driver, Status.FAIL, "Failed to validate DashboardGroup2 graph section", e.getLocalizedMessage(), null);
						if(endRun)
						RC_Global.endTestRun(driver);
					}
				}
				
				public static void validateDashboardGroup3GraphSection(WebDriver driver,String graphName,boolean endRun) throws Exception
				{
					String colNames="";String tCount="";
					try {
					RC_Global.waitElementVisible(driver, 60, "//span[text()='"+graphName+"']/../..//div[@class='highcharts-container']//*[name()='g']/*[name()='rect' and contains(@fill,'#A6A6A6')][1]", "Graph is displayed", false, false);
					RC_Global.clickUsingXpath(driver, "//span[text()='"+graphName+"']/../..//div[@class='highcharts-container']//*[name()='g']/*[name()='rect' and contains(@fill,'#A6A6A6')][1]", "A point on "+graphName+" graph", false, true);
					if( driver.findElements(By.xpath("//h5/span[1]")).size()>0)
					{
						queryObjects.logStatus(driver, Status.PASS, driver.findElement(By.xpath("//h5/span[1]")).getText()+" screen is displayed", "", null);
					}
					if(graphName.equals("Average Fuel Cost per Unit"))
					{
						colNames="Timeframe;Average Cost per Unit;Vehicle Count;High Cost per unit;Low Cost per Unit";
						RC_Global.verifyColumnNames(driver, colNames, endRun);
						
						RC_Global.clickUsingXpath(driver, "//table/tbody/tr[1]/td[2]/span/a/span", "Data of Average Cost per Unit", false, true);
						Thread.sleep(1000);
						if(driver.findElements(By.xpath("//h5/span[text()='Fuel Summary By Vehicle (E)']")).size()>0)
						{
							queryObjects.logStatus(driver, Status.PASS, "Fuel Summary By Vehicle (E) screen is displayed", "", null);
							RC_Global.panelAction(driver, "close", "Fuel Summary By Vehicle (E)", false, true);
							RC_Global.panelAction(driver, "expand", driver.findElement(By.xpath("//h5/span[1]")).getText(), false, true);
						}
						
						RC_Global.clickUsingXpath(driver, "//table/tbody/tr[1]/td[4]/span/a/span", "Data of High Cost per unit", false, true);
						Thread.sleep(1000);
						if(driver.findElements(By.xpath("//h5/span[text()='Fuel Transaction Detail (E)']")).size()>0)
						{
							queryObjects.logStatus(driver, Status.PASS, "Fuel Transaction Detail (E) screen is displayed", "", null);
							RC_Global.panelAction(driver, "close", "Fuel Transaction Detail (E)", false, true);
							RC_Global.panelAction(driver, "expand", driver.findElement(By.xpath("//h5/span[1]")).getText(), false, true);
						}
						
						RC_Global.clickUsingXpath(driver, "//table/tbody/tr[1]/td[5]/span/a/span", "Data of Low Cost per unit", false, true);
						Thread.sleep(1000);
						if(driver.findElements(By.xpath("//h5/span[text()='Fuel Transaction Detail (E)']")).size()>0)
						{
							queryObjects.logStatus(driver, Status.PASS, "Fuel Transaction Detail (E) screen is displayed", "", null);
							RC_Global.panelAction(driver, "close", "Fuel Transaction Detail (E)", false, true);
						}
					}
					else if(graphName.equals("Average Non-PM Cost per Unit"))
					{
						colNames="Timeframe;Average Cost per Unit;Vehicle Count;High Cost per Unit;Low Cost per Unit";
						RC_Global.verifyColumnNames(driver, colNames, endRun);
						
						RC_Global.clickUsingXpath(driver, "//table/tbody/tr[1]/td[2]/span/a/span", "Data of Average Cost per Unit", false, true);
						Thread.sleep(1000);
						if(driver.findElements(By.xpath("//h5/span[text()='Maintenance Repairs By Type (E)']")).size()>0)
						{
							queryObjects.logStatus(driver, Status.PASS, "Maintenance Repairs By Type (E) screen is displayed", "", null);
							RC_Global.panelAction(driver, "close", "Maintenance Repairs By Type (E)", false, true);
							RC_Global.panelAction(driver, "expand", driver.findElement(By.xpath("//h5/span[1]")).getText(), false, true);
						}
						
						RC_Global.clickUsingXpath(driver, "//table/tbody/tr[1]/td[4]/span/a/span", "Data of High Cost per unit", false, true);
						Thread.sleep(1000);
						if(driver.findElements(By.xpath("//h5/span[text()='Maintenance Repairs By Type (E)']")).size()>0)
						{
							queryObjects.logStatus(driver, Status.PASS, "Maintenance Repairs By Type (E) screen is displayed", "", null);
							RC_Global.panelAction(driver, "close", "Maintenance Repairs By Type (E)", false, true);
							RC_Global.panelAction(driver, "expand", driver.findElement(By.xpath("//h5/span[1]")).getText(), false, true);
						}
						
						RC_Global.clickUsingXpath(driver, "//table/tbody/tr[1]/td[5]/span/a/span", "Data of Low Cost per unit", false, true);
						Thread.sleep(1000);
						if(driver.findElements(By.xpath("//h5/span[text()='Maintenance Repairs By Type (E)']")).size()>0)
						{
							queryObjects.logStatus(driver, Status.PASS, "Maintenance Repairs By Type (E) screen is displayed", "", null);
							RC_Global.panelAction(driver, "close", "Maintenance Repairs By Type (E)", false, true);
						}
					}
					else if(graphName.equals("Maintenance Spend by Category"))
					{
						colNames="Category;Total Spend;Vehicle Count;Transaction Count";
						RC_Global.verifyColumnNames(driver, colNames, endRun);
						
						tCount=driver.findElement(By.xpath("//table/tbody/tr[2]/td[4]/span/a/span")).getText();
						RC_Global.clickUsingXpath(driver, "//table/tbody/tr[2]/td[1]/span/a/span", driver.findElement(By.xpath("//table/tbody/tr[2]/td[1]/span/a/span")).getText()+" from the Category column", false, true);
						RC_Global.waitElementVisible(driver, 10, "//table/tbody", "Grid is displayed", false, false);
						RC_Global.scrollById(driver, "//div[@class='col-xs-12']/div[3]/span");
						Thread.sleep(5000);
						String noOfResult[]=driver.findElement(By.xpath("//div[@class='col-xs-12']/div[3]/span")).getText().split("of");
						System.out.println(noOfResult[1].trim().split(" ")[0]);
						if(noOfResult[1].trim().split(" ")[0].equals(tCount))
						{
							queryObjects.logStatus(driver, Status.PASS, "Number Of transaction Matches the Number of data rows loaded in the new grid", tCount, null);
						}
						else
						{
							queryObjects.logStatus(driver, Status.FAIL, "Number Of transaction does not match the Number of data rows loaded in the new grid", "", null);
						}
						RC_Global.scrollById(driver, "//h5/span[1]");
						RC_Global.clickButton(driver, "Back", false, true);
						
						RC_Global.clickUsingXpath(driver, "//table/tbody/tr[1]/td[2]/span/a/span", "Data of Total Spend", false, true);
						Thread.sleep(1000);
						if(driver.findElements(By.xpath("//h5/span[text()='Maintenance Repairs By Type (E)']")).size()>0)
						{
							queryObjects.logStatus(driver, Status.PASS, "Maintenance Repairs By Type (E) screen is displayed", "", null);
							RC_Global.panelAction(driver, "close", "Maintenance Repairs By Type (E)", false, true);
						}
					}
					RC_Global.panelAction(driver, "close", driver.findElement(By.xpath("//h5/span[1]")).getText(), false, true);
					}
					catch (Exception e)
					{
						queryObjects.logStatus(driver, Status.FAIL, "Failed to validate DashboardGroup3 graph section", e.getLocalizedMessage(), null);
						if(endRun)
						RC_Global.endTestRun(driver);
					}
				}
				public static void validateDashboardGroupSection(WebDriver driver,String sectionName,String data,String reportName,String rowNum,boolean endRun) throws Exception
				{
					String dataLink=""; String genReportXpath="//button[text()='Generate Report']";WebElement genReportBtn =null;
					WebDriverWait wait = new WebDriverWait(driver, 60);
					
					RC_Global.createNode(driver, "Validate Section "+sectionName+" - "+data);
					try {
					RC_Global.clickUsingXpath(driver, "(//span[text()='"+sectionName+"'])[1]/../span[2]/i", "Expand "+sectionName, false, false);
					RC_Manage.waitUntilMethods(driver, "(//span[text()='"+sectionName+"'])[2]/../..//div[@class='spinner ng-scope']/..","class","ng-hide", "attribute visible");
					//RC_Global.waitElementNotVisible(driver, 60, "(//span[text()='"+sectionName+"'])[2]/../../div[2]/div/div[1]/div/i", "Spinning after expanding "+sectionName, false, false);
					RC_Global.waitElementVisible(driver, 60, "(//span[text()='"+sectionName+"'])[2]/../../div[2]/div/div[contains(@class,'dashboard-widget')][1]", "All hyperlinks are displayed in "+sectionName, false, false);
					Thread.sleep(3000);
					if(sectionName.equals("Exceptions & Alerts"))
					{
						if(!rowNum.equals(""))
						{
							RC_Global.scrollById(driver, "((//span[text()='Exceptions & Alerts'])[2]/../../div[2]/div/div[contains(@class,'dashboard-widget')]/div/div)["+rowNum+"]/span[1]");
						}
						if(driver.findElements(By.xpath("((//span[text()='"+sectionName+"'])[1]/following::span[text()='"+data+"']/following-sibling::a)[2]")).size()==1)
						{
							dataLink=driver.findElement(By.xpath("((//span[text()='"+sectionName+"'])[1]/following::span[text()='"+data+"']/following-sibling::a)[2]/span[2]")).getText();
							RC_Global.clickUsingXpath(driver, "((//span[text()='"+sectionName+"'])[1]/following::span[text()='"+data+"']/following-sibling::a)[2]", "Respective link of "+data, false, false);
						}
						else
						{
							dataLink=driver.findElement(By.xpath("((//span[text()='"+sectionName+"'])[1]/following::span[text()='"+data+"']/following-sibling::a)/span[2]")).getText();
							RC_Global.clickUsingXpath(driver, "((//span[text()='"+sectionName+"'])[1]/following::span[text()='"+data+"']/following-sibling::a)", "Respective link of "+data, false, false);
						}

					}
					else if(sectionName.equals("Fleet Facts"))
					{
						if(!rowNum.equals(""))
						{
							RC_Global.scrollById(driver, "(//span[text()='Fleet Facts'])[2]/../following-sibling::div/div/div[contains(@class,'dashboard-widget')]["+rowNum+"]");
						}
						if(driver.findElements(By.xpath("((//span[text()='Fleet Facts'])[1]/following::h4[text()='"+data+"'])[2]")).size()==1)
						{
							RC_Global.clickUsingXpath(driver, "((//span[text()='Fleet Facts'])[1]/following::h4[text()='"+data+"'])[2]", "Respective link of "+data, false, false);
						}
						else
						{
							RC_Global.clickUsingXpath(driver, "((//span[text()='Fleet Facts'])[1]/following::h4[text()='"+data+"'])", "Respective link of "+data, false, false);
						}
					}
					else
					{
						if(driver.findElements(By.xpath("((//span[text()='"+sectionName+"'])[1]/following::span[text()='"+data+"']/following-sibling::a)[2]")).size()==1)
						{
							RC_Global.scrollById(driver, "((//span[text()='"+sectionName+"'])[1]/following::span[text()='"+data+"']/following-sibling::a)[2]");
							dataLink=driver.findElement(By.xpath("((//span[text()='"+sectionName+"'])[1]/following::span[text()='"+data+"']/following-sibling::a)[2]/span[2]")).getText();
							RC_Global.clickUsingXpath(driver, "((//span[text()='"+sectionName+"'])[1]/following::span[text()='"+data+"']/following-sibling::a)[2]", "Respective link of "+data, false, false);
						}
						else
						{
							RC_Global.scrollById(driver, "((//span[text()='"+sectionName+"'])[1]/following::span[text()='"+data+"']/following-sibling::a)");
							dataLink=driver.findElement(By.xpath("(//span[text()='"+sectionName+"'])[1]/following::span[text()='"+data+"']/following-sibling::a/span[2]")).getText();
							RC_Global.clickUsingXpath(driver, "((//span[text()='"+sectionName+"'])[1]/following::span[text()='"+data+"']/following-sibling::a)", "Respective link of "+data, false, false);
						}
					}
					Thread.sleep(1000);
					RC_Global.scrollById(driver, "//h5/span");
					if(driver.findElement(By.xpath("//h5/span")).getText().contains(reportName))
					{
						queryObjects.logStatus(driver, Status.PASS, reportName+" screen is opened for", data, null);
					}
					else
					{
						queryObjects.logStatus(driver, Status.FAIL, reportName+" screen is not opened for", data, null);
					}
					Thread.sleep(3000);
					genReportBtn = driver.findElement(By.xpath(genReportXpath));
					wait.until(ExpectedConditions.elementToBeClickable(genReportBtn));
					if(sectionName.equals("Fleet Facts"))
					{	
						if(driver.findElements(By.xpath("//td[text()='Customer Name']")).size()>0)
						{
							queryObjects.logStatus(driver, Status.PASS, "Data's are displayed in the grid for", data, null);
						}
						else
						{
							queryObjects.logStatus(driver, Status.PASS, "No Records Found for", data, null);
						}
					}
					else {
	  
						queryObjects.logStatus(driver, Status.INFO, "Number of Records for "+data+" is ", dataLink, null);	
						if(dataLink.equals("0"))
						{
							if(driver.findElement(By.xpath("//div[text()='No Records Found']")).isDisplayed())
								queryObjects.logStatus(driver, Status.PASS, "No Records Found for", data, null);
							else
								queryObjects.logStatus(driver, Status.FAIL, "Records displayed for", data, null);
						}
						else
						{
							if(driver.findElement(By.xpath("//td[text()='Customer Name']")).isDisplayed())
								queryObjects.logStatus(driver, Status.PASS, "Records displayed for", data, null);
							else
								queryObjects.logStatus(driver, Status.FAIL, "No Records Found for", data, null);
						}
					}
					RC_Global.panelAction(driver, "close", driver.findElement(By.xpath("(//h5)[2]/span[1]")).getText(), false, false);
					}
					catch (Exception e)
					{
						queryObjects.logStatus(driver, Status.FAIL, "Failed to validate "+data+" from "+sectionName, e.getLocalizedMessage(), null);
						if(endRun)
						RC_Global.endTestRun(driver);
					}
				}
				
	public static void removePolicyRecord(WebDriver driver, boolean endRun) throws Exception {
		try {
			boolean flag = false;
			String policystatus = "";
			String policytype = "";

			List<WebElement> Gridrowcnt = driver.findElements(By.xpath("(//thead/tr)[12]/following::div//div/table//tr"));
			if(driver.findElements(By.xpath("(//thead/tr)[12]/following::div//span[text()='No Results' and @class='']")).size()>0) {
				queryObjects.logStatus(driver, Status.INFO," No Policy record found from the grid", " ", null);
			}else {
			for (int i = 1; i <= Gridrowcnt.size(); i++) {
				WebElement PolicyType = driver.findElement(By.xpath("((//thead/tr)[12]/following::div//div/table//td[4])[" + i + "]"));
				WebElement PolicyStatus = driver.findElement(By.xpath("((//thead/tr)[12]/following::div//div/table//td[5])[" + i + "]"));
				policystatus = PolicyStatus.getText();
				policytype = PolicyType.getText();
				if (policystatus.equals("Active")) {
					if ((policytype.equalsIgnoreCase("General")) || (policytype.equalsIgnoreCase("Acquisition")) || (policytype.equalsIgnoreCase("Mobile"))) {
						RC_Global.clickUsingXpath(driver,"//td[text()='" + policytype + "']/following::button[text()=' Deactivate ']","Deactivate", false, false);
						flag = true;
					}
				}
			}
			}
			if (flag) {
				queryObjects.logStatus(driver, Status.PASS," " + policystatus + " - " + policytype + " Policy record is deleted from the grid","Successfully", null);
			} 
		} catch (Exception e) {
			queryObjects.logStatus(driver, Status.INFO, "Unable to find the record", "", null);
			if (endRun)
				RC_Global.endTestRun(driver);
		}
	}
	
	
	public static void validateDashboardGroupTopSections(WebDriver driver,String sectionName,String data,String reportName,boolean endRun) throws Exception
	{
		String dataLink="";String genReportXpath="//button[text()='Generate Report']";WebElement genReportBtn =null;
		WebDriverWait wait = new WebDriverWait(driver, 60);
		
		RC_Global.createNode(driver, "Validate Section "+sectionName+" - "+data);
		try {
		if(!(sectionName.equals("Fleet Facts")))
		{
			dataLink=driver.findElement(By.xpath("(//span[text()='"+sectionName+"'])[1]/following::span[text()='"+data+"']/following-sibling::a/span[2]")).getText();
			RC_Global.clickUsingXpath(driver, "(//span[text()='"+sectionName+"'])[1]/following::span[text()='"+data+"']/following-sibling::a/span[2]", "Respective link of "+data, false, false);
		}
		else {
			RC_Global.clickUsingXpath(driver, "(//span[text()='Fleet Facts'])[1]/../../div[2]/div/div/div/div/h4[text()='"+data+"']", "Respective link of "+data, false, false);
		}
		Thread.sleep(1000);
		if(driver.findElement(By.xpath("//h5/span[1]")).getText().contains(reportName))
		{
			queryObjects.logStatus(driver, Status.PASS, reportName+" screen is opened for", data, null);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, reportName+" screen is not opened for", data, null);
		}
		Thread.sleep(3000);
		genReportBtn = driver.findElement(By.xpath(genReportXpath));
		wait.until(ExpectedConditions.elementToBeClickable(genReportBtn));
		
		if(!(sectionName.equals("Fleet Facts")))
		{
			queryObjects.logStatus(driver, Status.INFO, "Number of Records for "+data+" is ", dataLink, null);	
			if(dataLink.equals("0"))
			{
				if(driver.findElement(By.xpath("//div[text()='No Records Found']")).isDisplayed())
					queryObjects.logStatus(driver, Status.PASS, "No Records Found for", data, null);
				else
					queryObjects.logStatus(driver, Status.FAIL, "Records displayed for", data, null);
			}
			else
			{
				if(driver.findElement(By.xpath("//td[text()='Customer Name']")).isDisplayed())
					queryObjects.logStatus(driver, Status.PASS, "Records displayed for", data, null);
				else
					queryObjects.logStatus(driver, Status.FAIL, "No Records Found for", data, null);
			}
		}
		else
		{
			if(driver.findElements(By.xpath("//td[text()='Customer Name']")).size()>0)
			{
				queryObjects.logStatus(driver, Status.PASS, "Data's are displayed in the grid for", data, null);
			}
			else
			{
				queryObjects.logStatus(driver, Status.PASS, "No Records Found for", data, null);
			}
		}
		RC_Global.panelAction(driver, "close", driver.findElement(By.xpath("(//h5)[2]/span[1]")).getText(), false, false);
		}
		catch (Exception e)
		{
			queryObjects.logStatus(driver, Status.FAIL, "Failed to validate "+data+" from "+sectionName, e.getLocalizedMessage(), null);
			if(endRun)
			RC_Global.endTestRun(driver);
		}
	}
	
	
	public static void columnNames_BGColorValidation(WebDriver driver, String filePath, String columnNames) throws Exception {
		RC_Global.createNode(driver, "Validate Heading Cell background Color");
        String[] sptColumns = null;
        int colNo=0; String tempColNm = "";
        try {		    
		  	FileInputStream fis = new FileInputStream(filePath);
		    XSSFWorkbook wb = new XSSFWorkbook(fis);
		    XSSFSheet sh = wb.getSheetAt(1);
		    int cols= sh.getRow(2).getLastCellNum();
	        if(columnNames.contains(";"))
	        	sptColumns = columnNames.split(";");
		        for (int j = 0; j < sptColumns.length; j++) {
		        	for (int k = 0; k < sptColumns.length; k++) {
			        	colNo=0; tempColNm = "";
			        	tempColNm = sh.getRow(2).getCell(k).getStringCellValue();
			        	if (tempColNm.equalsIgnoreCase(sptColumns[j])) {
			        		colNo = k;
			        		break;
				     	}
		        	}
		        	if (colNo>0) {  
		        		 XSSFCellStyle cs = sh.getRow(2).getCell(colNo).getCellStyle();
				         XSSFColor color = cs.getFillForegroundColorColor();				         
				         String colorSel = columnColorDriverPoolAssignment(sptColumns[j]);
				         if (color.getARGBHex().equalsIgnoreCase(colorSel)) {
			                queryObjects.logStatus(driver, Status.PASS, "Validate Column Heading Background Color", "Background color for "+sptColumns[j]+" is "+colorSel+" as expected", null);
			             }
			             else
			                 queryObjects.logStatus(driver, Status.FAIL, "Validate Column Heading Background Color", "Background color for "+sptColumns[j]+" is "+colorSel+" --- Not as expected", null);   
					} else {

					}
		        }
		  fis.close();
	  }
	  catch (Exception e) {
	       queryObjects.logStatus(driver, Status.FAIL, "Mandatory cells update failed", e.getLocalizedMessage(), e);
	       RC_Global.endTestRun(driver);
	  }
	}	
	
	public static List<Integer> Get_insertRow_Excel(WebDriver driver, String filePath, String actPerform, int rwsSize, String templateType) throws Exception {
		int addedRw = 0; List<Integer> rowChange = null;List<Integer> validRows =  new ArrayList<Integer>(); String tempVals= "";
		int k=0;
		try {			
            FileInputStream fis = new FileInputStream(filePath);
            XSSFWorkbook wb = new XSSFWorkbook(fis);
            XSSFSheet sh = wb.getSheetAt(1);
            int rows = sh.getLastRowNum();
            int cols= sh.getRow(2).getLastCellNum(); 
            rowChange = RandomNumbers(driver, 5, rows, rwsSize);
            if (actPerform.contains("insert")) {
            	rowChange = RandomNumbers(driver, 5, rows, rwsSize);
            	for (int j : rowChange) {
            		addedRw = rowChange.get(0);
            		XSSFRow row = sh.createRow(addedRw);
                	for (int i = 0; i < cols; i++) {
                		row.createCell(i);
    				}
                	k = k+1;
				}            	
			} else {
				rowChange = RandomNumbers(driver, 5, rows, rwsSize+100);
				for (int j : rowChange) {
					if (templateType.equalsIgnoreCase("Employee Upload")) {
						if (!(sh.getRow(j).getCell(18).getStringCellValue()==null || sh.getRow(j).getCell(18).getStringCellValue().isEmpty()) && sh.getRow(j).getCell(cols-1).getStringCellValue().equalsIgnoreCase("Active")) {
							if (tempVals=="") {
								tempVals = sh.getRow(j).getCell(18).getStringCellValue();
								validRows.add(j);
							} else {
								if (!tempVals.contains(sh.getRow(j).getCell(18).getStringCellValue())) {
									tempVals = tempVals+";"+sh.getRow(j).getCell(18).getStringCellValue();
									validRows.add(j);
								}
							}
						}
						
					} else if (templateType.equalsIgnoreCase("Pool Management Upload")) {
						if (tempVals=="") {
							tempVals = sh.getRow(j).getCell(3).getStringCellValue();
							validRows.add(j);
						} else {
							if (!tempVals.contains(sh.getRow(j).getCell(3).getStringCellValue())) {
								tempVals = tempVals+";"+sh.getRow(j).getCell(3).getStringCellValue();
								validRows.add(j);
							}
						}
					}
					if (validRows.size()==rwsSize) {
						break;
					}
				}
				rowChange = validRows;
			}            
            fis.close();
            FileOutputStream fos = new FileOutputStream(filePath);
            wb.write(fos);
            wb.close();
            fos.close();
		  }
		  catch (Exception e) {
		       queryObjects.logStatus(driver, Status.FAIL, "Mandatory cells update failed", e.getLocalizedMessage(), e);
		       RC_Global.endTestRun(driver);
		  }
		return rowChange;		
	}
	
	public static String getColumnVals_SpecificRow(WebDriver driver, String filePath, String columnNames, int rowNum) throws Exception {
		
		String uniqueID = ""; String getData = ""; String currentVal = ""; String oldData = ""; String curCol = "";
		String getCols = ""; String tempColNm = ""; String sptColNames[] = null;
		boolean isValid = true;
		
		List<Integer> colsNum =  new ArrayList<Integer>();
		RC_Global.createNode(driver, "Get Rows with valid data");
		if (!columnNames.equalsIgnoreCase("All")) {
			if (!columnNames.contains(";")) {
			columnNames = columnNames+";";}
			sptColNames = columnNames.split(";");
		}
        try {
               FileInputStream fis = new FileInputStream(filePath);
               XSSFWorkbook wb = new XSSFWorkbook(fis);
               XSSFSheet sh = wb.getSheetAt(1);
               int rows = sh.getLastRowNum();
               int cols= sh.getRow(2).getLastCellNum();
               if (columnNames.equalsIgnoreCase("All")) {
            	   for (int c = 3; c < cols; c++) {
            		   colsNum.add(c); 
                   }
               } else {
            	   for (int cn = 0; cn < sptColNames.length; cn++) {
                	   for (int c = 0; c < cols; c++) {
                    	   tempColNm = sh.getRow(2).getCell(c).getStringCellValue();
                    	   if (tempColNm.equalsIgnoreCase(sptColNames[cn])) {
                    		   colsNum.add(c);
                     		  break;
                     	  } 
                       }
                   }
               }
        	   for (int i : colsNum) {  
        		   XSSFCell cCell = sh.getRow(rowNum).getCell(i);
        		   curCol = sh.getRow(2).getCell(i).getStringCellValue();
        		   if (getCols=="") {
   	 					getCols = sh.getRow(2).getCell(2).getStringCellValue()+";"+sh.getRow(2).getCell(i).getStringCellValue();
        		   } else if (getCols.contains(sh.getRow(2).getCell(i).getStringCellValue())) {
							//do nothing
        		   } else {
							getCols = getCols+";"+sh.getRow(2).getCell(i).getStringCellValue();
        		   }
        		   if (curCol.equalsIgnoreCase("TotalView Pool ID") || curCol.equalsIgnoreCase("TotalView Person ID") || curCol.equalsIgnoreCase("Fuel Driver ID")) {
        			   currentVal = cCell.getNumericCellValue()+"";
        		   } else {
        			   try {
        				   currentVal = cCell.getStringCellValue();
        			   } catch (Exception e) {
							currentVal = " ";
        			   }
        		   }
        		   if (oldData=="") {                                             	   	
             	   		oldData = currentVal;
        		   } else {
        			   oldData = oldData+";"+currentVal;
        		   }
               }
               fis.close();               
        } catch (Exception e) {
        	queryObjects.logStatus(driver, Status.FAIL, "Column values update failed", e.getLocalizedMessage(), e);
	        RC_Global.endTestRun(driver);
        }
		return getCols+"__"+oldData;	        
	}

	public static String getValidDataRows(WebDriver driver, String filePath, String columnNames) throws Exception {
		
		String uniqueID = ""; String getData = ""; String currentVal = ""; String oldData = ""; String newData = "";
		String getCols = ""; int rowNum = 0; String tempColNm = ""; String sptColNames[] = null;
		boolean isValid = true;
		
		List<Integer> colsNum =  new ArrayList<Integer>();
		RC_Global.createNode(driver, "Get Rows with valid data");
		if (!columnNames.contains(";")) {
			columnNames = columnNames+";";
		}
        try {
               FileInputStream fis = new FileInputStream(filePath);
               XSSFWorkbook wb = new XSSFWorkbook(fis);
               XSSFSheet sh = wb.getSheetAt(1);
               int rows = sh.getLastRowNum();
               int cols= sh.getRow(2).getLastCellNum();
               List<Integer> rowsChange = RandomNumbers(driver, 5, rows, 5);
               for (int cn = 0; cn < sptColNames.length; cn++) {
            	   for (int c = 0; c < cols; c++) {
                	   tempColNm = sh.getRow(2).getCell(c).getStringCellValue();
                	   if (tempColNm.equalsIgnoreCase(sptColNames[cn])) {
                		   colsNum.add(c);
                 		  break;
                 	  } 
                   }
               }
               for (int j : rowsChange) {
            	   isValid = true; currentVal = ""; getData = ""; getCols = ""; oldData= "";
            	   for (int i : colsNum) {  
            		   XSSFCell cCell = sh.getRow(j).getCell(i);
	                   if (cCell.getStringCellValue().isEmpty() || cCell.getStringCellValue()==null){
	                	   isValid = false;
	                   } else {
	                	   currentVal = cCell.getStringCellValue();
	                	   if (getCols=="") {
             	 				getCols = sh.getRow(2).getCell(2).getStringCellValue()+";"+sh.getRow(2).getCell(i).getStringCellValue();
								} else if (getCols.contains(sh.getRow(2).getCell(i).getStringCellValue())) {
									//do nothing
								} else {
									getCols = getCols+";"+sh.getRow(2).getCell(i).getStringCellValue();
							}
	                	   if (oldData=="") {                                             	   	
                          	   	oldData = currentVal;
                      	   } else {
								oldData = oldData+";"+currentVal;
                    	   }
	                   }
	                   if (colsNum.get(sptColNames.length-1)==i) {
	                	   if (isValid) {
	                		   if (filePath.contains("EmployeeCreateEdit")) {
                          		 uniqueID = sh.getRow(j).getCell(18).getStringCellValue();
                          	 } else if(filePath.contains("PoolCreateEdit")) {
                          		 uniqueID = sh.getRow(j).getCell(3).getStringCellValue();
                          	 }
	                	   }
	                   }
                   }
            	   if (isValid) {
            		   rowNum = j;
            		   break;
            	   }
               }
               fis.close();               
        } catch (Exception e) {
        	queryObjects.logStatus(driver, Status.FAIL, "Column values update failed", e.getLocalizedMessage(), e);
	        RC_Global.endTestRun(driver);
        }
		return rowNum+"__"+getCols+"__"+oldData;	        
	}
	
	public static String updateAllColumns_Employee_PoolUpload(WebDriver driver, String filePath, List<Integer> rowsChng) throws Exception {
		
		String colorSel = ""; String uniqueID = ""; String getData = ""; String currentVal = ""; String oldData = ""; String newData = "";
		String multiRows_old = ""; String multiRows_new = ""; String getCols = "";
		String fuelEnroll = ""; String perUseEnroll = ""; String drOrdEnroll = ""; String curCol = "";
		RC_Global.createNode(driver, "Update few column values in Downloaded Excel file");
        try {
               FileInputStream fis = new FileInputStream(filePath);
               XSSFWorkbook wb = new XSSFWorkbook(fis);
               XSSFSheet sh = wb.getSheetAt(1);
               int rows = sh.getLastRowNum();
               int cols= sh.getRow(2).getLastCellNum(); 
               for (int j : rowsChng) {
            	   for (int i = 3; i < cols; i++) {            		   
	                   if (!(sh.getRow(2).getCell(i).getStringCellValue().equalsIgnoreCase("TotalView Person ID") || sh.getRow(2).getCell(i).getStringCellValue().equalsIgnoreCase("Employee Type")
	                		   || sh.getRow(2).getCell(i).getStringCellValue().equalsIgnoreCase("User Name") || sh.getRow(2).getCell(i).getStringCellValue().equalsIgnoreCase("Residential Address 2") 
	                		   || sh.getRow(2).getCell(i).getStringCellValue().equalsIgnoreCase("Employee ID") || sh.getRow(2).getCell(i).getStringCellValue().contains("Employee Data Field"))
	                		   || sh.getRow(2).getCell(i).getStringCellValue().equalsIgnoreCase("TotalView Pool ID")) {
                                                                    
                                 try {
                                	 currentVal = ""; getData = "";
                                     try {
                                    	 if (filePath.contains("EmployeeCreateEdit")) {
                                    		 uniqueID = sh.getRow(j).getCell(18).getStringCellValue();
                                    	 } else if(filePath.contains("PoolCreateEdit")) {
                                    		 uniqueID = sh.getRow(j).getCell(3).getStringCellValue();
                                    	 }
                                    	 if (uniqueID=="") {
                                    		 uniqueID = " ";
										}
    								 } catch (Exception e) {
    									 uniqueID = " ";
    								 }
                                     
                                     XSSFCell cCell = sh.getRow(j).getCell(i);
                                     
                                	 curCol = sh.getRow(2).getCell(i).getStringCellValue();
                                	 if (getCols=="") {
                                		 if (filePath.contains("EmployeeCreateEdit")) {
                                			 getCols = sh.getRow(2).getCell(18).getStringCellValue()+";"+sh.getRow(2).getCell(i).getStringCellValue();
                                    	 } else if(filePath.contains("PoolCreateEdit")) {
                                    		 getCols = sh.getRow(2).getCell(3).getStringCellValue()+";"+sh.getRow(2).getCell(i).getStringCellValue();
                                    	 }                      	 				
										} else if (getCols.contains(sh.getRow(2).getCell(i).getStringCellValue())) {
											//do nothing
										} else {
											getCols = getCols+";"+sh.getRow(2).getCell(i).getStringCellValue();
									 }
                                	 if (curCol.equalsIgnoreCase("TotalView Pool ID") || curCol.equalsIgnoreCase("TotalView Person ID") || curCol.equalsIgnoreCase("Fuel Driver ID")) {
                            			 currentVal = Double.toString(cCell.getNumericCellValue());
                            		} else {
                            			try {
                            				currentVal = cCell.getStringCellValue();
										} catch (Exception e) {
											currentVal = " ";
										}
                            		}                          	 			
                                  		//if (act.equalsIgnoreCase("Update")) {//Update
                                	 	String[] ListValues = {};
	                                	 try {
	                                		 ListValues = getDataValidationListValues(sh, cCell);
										} catch (Exception e) {}
                                  		if (ListValues.length>0) {
                                  			if (ListValues.length==1) {
                                  				cCell.setCellValue(ListValues[0]);
											} else {
												cCell.setCellValue(ListValues[ThreadLocalRandom.current().nextInt(0, ListValues.length-1)]);
											}
                                  			getData = cCell.getStringCellValue();
                                  			if (curCol.equalsIgnoreCase("Distribution Method")) {
                                  				cCell.setCellValue("Email & Text Message");
											}
                                  			if (curCol.equalsIgnoreCase("Preferred Contact Method")) {
                                  				cCell.setCellValue("Work");
											}
                                  			if (curCol.equalsIgnoreCase("fuelEnroll")) {
                                  				fuelEnroll = getData;
											}
                                  			if (curCol.equalsIgnoreCase("Enrolled in Personal Use")) {
												perUseEnroll = getData;
											}
                                  			if (curCol.equalsIgnoreCase("Enrolled in Driver Ordering")) {
												drOrdEnroll = getData;
											}
                                  			if (curCol.equalsIgnoreCase("Create a New User Login ID")) {
                                  				if (perUseEnroll.equalsIgnoreCase("yes")) {
                                  					cCell.setCellValue("Yes");
												}
											}
                                  			if (curCol.equalsIgnoreCase("Status")) {
                                  				cCell.setCellValue("Active");
											}
                                  			if (curCol.equalsIgnoreCase("Alert Distribution Method")) {
                                  				cCell.setCellValue("Email");
                                  			}
                                  			if (curCol.equalsIgnoreCase("Address Validation Override")) {
                                  				cCell.setCellValue("No");
                                  			}
                      					} else {                                						
                      						//////Get different value for the given column to change the current cell value/////////////
                      						for (int k = 5; k < rows; k++) {
                      							getData = "";
                      							if (curCol.equalsIgnoreCase("TotalView Pool ID") || curCol.equalsIgnoreCase("TotalView Person ID") || curCol.equalsIgnoreCase("Fuel Driver ID")) {
                      								if (!(((int) sh.getRow(k).getCell(i).getNumericCellValue()+"").isEmpty() || ((int) sh.getRow(k).getCell(i).getNumericCellValue()+"")==null)) {
                              							if (!(((int) sh.getRow(k).getCell(i).getNumericCellValue()+"").equalsIgnoreCase(currentVal))) {
    															getData = ((int) sh.getRow(k).getCell(i).getNumericCellValue()+"");
    															break;
    														}
                          							}
                      							} else {
                      								if (!(sh.getRow(k).getCell(i).getStringCellValue().isEmpty() || sh.getRow(k).getCell(i).getStringCellValue()==null)) {
                              							if (!(sh.getRow(k).getCell(i).getStringCellValue().equalsIgnoreCase(currentVal))) {
    															getData = sh.getRow(k).getCell(i).getStringCellValue();
    															break;
    														}
                          							}
												}
											}
                      						if (getData=="" || getData.isEmpty()) {
                      							getData = RandomStringUtils.random(4, true, false);
											}
                      						if (curCol.equalsIgnoreCase("Pool Name")) {
												getData = RandomStringUtils.randomNumeric(3).toUpperCase()+" - Automation Testing_"+RandomStringUtils.randomAlphabetic(5).toLowerCase();
											}
                      						if (curCol.equalsIgnoreCase("First Name")) {
												getData = RandomStringUtils.randomAlphabetic(5).toUpperCase();
											}
                      						if (curCol.equalsIgnoreCase("Last Name")) {
												getData = RandomStringUtils.randomAlphabetic(6).toUpperCase();
											}
                      						if (curCol.equalsIgnoreCase("Cell Phone")) {
												getData =  RandomStringUtils.random(10, false, true);
											}
                      						if (curCol.equalsIgnoreCase("Work Phone")) {
                      							getData =  RandomStringUtils.random(10, false, true);
											}
                      						if (curCol.equalsIgnoreCase("Extension")) {
                      							getData =  RandomStringUtils.random(3, false, true);
											}
                      						if (curCol.equalsIgnoreCase("Email")) {
												getData = RandomStringUtils.randomAlphabetic(10).toUpperCase()+RandomStringUtils.randomNumeric(3)+"@merchants.com";
											}
                      						if (curCol.equalsIgnoreCase("Fuel Driver ID")) {
												getData = RandomStringUtils.randomNumeric(6);
											}
                      						cCell.setCellValue(getData);
                      					}
									//}
                                  	
                                  	if (currentVal.isEmpty()) {
                                    		currentVal= " ";
                  					}
                                  	if (oldData=="") {                                             	   	
                                   	   	oldData = uniqueID+";"+currentVal;
                               	   		newData = uniqueID+";"+getData;
									} else {
										oldData = oldData+";"+currentVal;
                             	   		newData = newData+";"+getData;
									}  
                                 } catch (Exception e1) {
                                	 queryObjects.logStatus(driver, Status.FAIL, "Mandatory column values update failed", e1.getLocalizedMessage(), e1);
                         	        RC_Global.endTestRun(driver);
                                 }
                          }
                   }
                   if (oldData.contains(";")) {
                	   if (multiRows_new!="") {
                      		multiRows_old = multiRows_old+"__"+oldData;
                      		multiRows_new = multiRows_new+"__"+newData;
       	   				} else {
       	   					multiRows_old = oldData;
       	   					multiRows_new = newData;
       	   				}
                   }                   
                   oldData = ""; newData="";
               }
               fis.close();
               FileOutputStream fos = new FileOutputStream(filePath);
               wb.write(fos);
               wb.close();
               fos.close();
        } catch (Exception e) {
        	queryObjects.logStatus(driver, Status.FAIL, "Column values update failed", e.getLocalizedMessage(), e);
	        RC_Global.endTestRun(driver);
        }
		return getCols+"~~"+multiRows_old+"~~"+multiRows_new;	        
	}
	
	public static String columnsValueEdit_Employee_Pool(WebDriver driver, String filePath, String colNames, String colVals, List<Integer> rowsChng) throws Exception {
		
		String colorSel = ""; String uniqueID = ""; String getData = ""; String currentVal = ""; String oldData = ""; String newData = "";
		String multiRows_old = ""; String multiRows_new = ""; String getCols = ""; String distribtrType = ""; String prefrdContact = "";
		String fuelEnroll = ""; String perUseEnroll = ""; String drOrdEnroll = ""; int colNo = 0;
		RC_Global.createNode(driver,  "Update few column with the given values in Downloaded Excel file");
		String sptColNames[] = null; String sptColVals[] = null; String tempColNm = "";
		if (!colNames.contains(";")) {
			colNames = colNames+";";
		}
		if (!colVals.contains(";")) {
			colVals = colVals+";";
		}
		sptColNames = colNames.split(";");
		sptColVals = colVals.split(";");
        try {
               FileInputStream fis = new FileInputStream(filePath);
               XSSFWorkbook wb = new XSSFWorkbook(fis);
               XSSFSheet sh = wb.getSheetAt(1);
               int rows = sh.getLastRowNum();
               int cols= sh.getRow(2).getLastCellNum();
               for (int j : rowsChng) {
            	   for (int cn = 0; cn < sptColNames.length; cn++) {
                	   for (int c = 0; c < cols; c++) {
                    	   tempColNm = sh.getRow(2).getCell(c).getStringCellValue();
                    	  if (tempColNm.contains("-")) {
                    		  if (tempColNm.substring(tempColNm.indexOf("-")+1).equalsIgnoreCase(sptColNames[cn])) {
                    			  colNo = c;
                    			  break;
                    		  }            		  
                    	  } else if (tempColNm.equalsIgnoreCase(sptColNames[cn])) {
                    		  colNo = c;
                    		  break;
                    	  }
                       }            	   
            		   XSSFCell cCell = sh.getRow(j).getCell(colNo);
            		   XSSFCell colCell = sh.getRow(2).getCell(colNo);
                       currentVal = ""; getData = "";
                       if (filePath.contains("EmployeeCreateEdit")) {
                  		 uniqueID = sh.getRow(j).getCell(18).getStringCellValue();
                       } else if(filePath.contains("PoolCreateEdit")) {
	                  		 uniqueID = sh.getRow(j).getCell(3).getStringCellValue();
                       }
                       try {
                      	 if (getCols=="") {
            	 				getCols = sh.getRow(2).getCell(2).getStringCellValue()+";"+colCell.getStringCellValue();
								} else if (getCols.contains(colCell.getStringCellValue())) {
									//do nothing
								} else {
									getCols = getCols+";"+colCell.getStringCellValue();
							 }
                      	 if (colCell.getStringCellValue().equalsIgnoreCase("TotalView Pool ID") || colCell.getStringCellValue().equalsIgnoreCase("TotalView Person ID") || colCell.getStringCellValue().equalsIgnoreCase("Fuel Driver ID")) {
                  			 currentVal = Double.toString(cCell.getNumericCellValue());
                      	 } else {
                  			 currentVal = cCell.getStringCellValue();
                      	 }                          	 			
                  		String[] ListValues = getDataValidationListValues(sh, cCell);
                    		if (ListValues.length>0) {
                    			if (sptColVals[cn].equalsIgnoreCase("selListVal")) {
                    				if (ListValues.length==1) {
                    					cCell.setCellValue(ListValues[0]);
									} else {
										cCell.setCellValue(ListValues[ThreadLocalRandom.current().nextInt(0, ListValues.length-1)]);
									}
								} else {
									try {
										if (colCell.getStringCellValue().equalsIgnoreCase("TotalView Pool ID") || colCell.getStringCellValue().equalsIgnoreCase("TotalView Person ID") || colCell.getStringCellValue().equalsIgnoreCase("Fuel Driver ID")) {
											if (Integer.parseInt(sptColVals[cn].trim())>0) {
											cCell.setCellValue(Integer.parseInt(sptColVals[cn].trim()));
											}
										} else {
											cCell.setCellValue(sptColVals[cn].trim());
										}
									} catch (Exception e) {
										cCell.setCellValue(sptColVals[cn].trim());
									}									
								}                          			
                    			getData = cCell.getStringCellValue();
                    			
        					} else {
        						cCell.setCellValue(sptColVals[cn].trim());
        						getData = sptColVals[cn];
        					}                                  	
                        	if (currentVal.isEmpty()) {
                          		currentVal= " ";
        					}
                        	if (oldData=="") {                                             	   	
                         	   	oldData = uniqueID+";"+currentVal;
                     	   		newData = uniqueID+";"+getData;
							} else {
								oldData = oldData+";"+currentVal;
                   	   		newData = newData+";"+getData;
							}  
                       } catch (Exception e1) {
                      	 queryObjects.logStatus(driver, Status.FAIL, "Mandatory column values update failed", e1.getLocalizedMessage(), e1);
               	        RC_Global.endTestRun(driver);
                       }                       
                   }
            	   if (oldData.contains(";")) {
                	   if (multiRows_new!="") {
                      		multiRows_old = multiRows_old+"__"+oldData;
                      		multiRows_new = multiRows_new+"__"+newData;
       	   				} else {
       	   					multiRows_old = oldData;
       	   					multiRows_new = newData;
       	   				}
                   }                   
                   oldData = ""; newData="";
               }               
               
               fis.close();
               FileOutputStream fos = new FileOutputStream(filePath);
               wb.write(fos);
               wb.close();
               fos.close();
        } catch (Exception e) {
        	queryObjects.logStatus(driver, Status.FAIL, "Column values update failed", e.getLocalizedMessage(), e);
	        RC_Global.endTestRun(driver);
        }
		return getCols+"~~"+multiRows_old+"~~"+multiRows_new;	        
	}
	
	
	public static String columnsFormatValidation_Employee_Pool(WebDriver driver, String filePath, String colNames, String colListVals, String defaultVals, List<Integer> rowsChng) throws Exception {
		
		String colorSel = ""; double personID = 0; String getData = ""; String currentVal = ""; String oldData = ""; String newData = "";
		String multiRows_old = ""; String multiRows_new = ""; String getCols = ""; String distribtrType = ""; String prefrdContact = "";
		String fuelEnroll = ""; String perUseEnroll = ""; String drOrdEnroll = ""; int colNo = 0; boolean isListVals = false;
		RC_Global.createNode(driver,  "Validate the columns data type with values in few columns in Downloaded Excel file");
		String sptColNames[] = null; String sptColVals[] = null; String tempColNm = ""; String sptColsList[] = null; boolean isDefault = false;
		String sptDefault[] = null;
		if (!defaultVals.isEmpty()) {
			isDefault = true;
			sptDefault = defaultVals.split(";");
		}
		if (!colNames.contains(";")) {
			colNames = colNames+";";
		}
		if (!colListVals.contains(";")) {
			colListVals = colListVals+";";
		}
		sptColNames = colNames.split(";");
		sptColVals = colListVals.split(";");
        try {
               FileInputStream fis = new FileInputStream(filePath);
               XSSFWorkbook wb = new XSSFWorkbook(fis);
               XSSFSheet sh = wb.getSheetAt(1);
               int rows = sh.getLastRowNum();
               int cols= sh.getRow(2).getLastCellNum();
               for (int cn = 0; cn < sptColNames.length; cn++) {
            	   for (int c = 0; c < cols; c++) {
                	   tempColNm = sh.getRow(2).getCell(c).getStringCellValue();
                	  if (tempColNm.contains("-")) {
                		  if (tempColNm.substring(tempColNm.indexOf("-")+1).equalsIgnoreCase(sptColNames[cn])) {
                			  colNo = c;
                			  break;
                		  }            		  
                	  } else if (tempColNm.equalsIgnoreCase(sptColNames[cn])) {
                		  colNo = c;
                		  break;
                	  }
                   }
            	   
            	   for (int j : rowsChng) {
            		   XSSFCell cCell = sh.getRow(j).getCell(colNo);            		  
                       try {                      	                           	 			
                  		String[] ListValues = getDataValidationListValues(sh, cCell);
                    		if (ListValues.length>=0) {
                    			isListVals = true;
                    			if (!sptColVals[cn].contains("-")) {
                    				sptColVals[cn] = sptColVals[cn]+"-";
                    			}
                    			sptColsList = sptColVals[cn].split("-");
                    			for (int sc = 0; sc < sptColsList.length; sc++) {
									if (!ListValues[sc].equalsIgnoreCase(sptColsList[sc])) {
										queryObjects.logStatus(driver, Status.FAIL, sptColsList[sc]+" dropdown value is not present in the "+sptColNames[cn]+ " column", "Expected picklist values are "+sptColVals[cn], null);
										isListVals = false;
									}
								}
                    			if (isDefault) {
                    				queryObjects.logStatus(driver, Status.PASS, "All the dropdown values are present in the "+sptColNames[cn]+ " column", "Picklist values are "+sptColVals[cn], null);
								}
                    			if (isDefault) {
									if (!sptDefault[cn].trim().isEmpty()) {
										if (cCell.getStringCellValue().equalsIgnoreCase(sptDefault[cn])) {
											queryObjects.logStatus(driver, Status.PASS, "Verify the default value - "+sptDefault[cn]+" is present in the "+sptColNames[cn]+ " column", "Validation is Successful", null);
										} else {
											queryObjects.logStatus(driver, Status.INFO, "Verify the default value - "+sptDefault[cn]+" is present in the "+sptColNames[cn]+ " column", "Default value is not present. Actual value displayed is "+cCell.getStringCellValue(), null);
										}
									}
								}
        					} else {
        						queryObjects.logStatus(driver, Status.FAIL, sptColNames[cn]+" data type format is not a picklist", "", null);
        					}                                  	
                        	  
                       } catch (Exception e1) {
                      	 queryObjects.logStatus(driver, Status.FAIL, "Mandatory column values update failed", e1.getLocalizedMessage(), e1);
               	        RC_Global.endTestRun(driver);
                       }
                   }
               }               
               
               fis.close();
               FileOutputStream fos = new FileOutputStream(filePath);
               wb.write(fos);
               wb.close();
               fos.close();
        } catch (Exception e) {
        	queryObjects.logStatus(driver, Status.FAIL, "Column values update failed", e.getLocalizedMessage(), e);
	        RC_Global.endTestRun(driver);
        }
		return getCols+"~~"+multiRows_old+"~~"+multiRows_new;	        
	}


	public static void validateResults_RowNumbers(WebDriver driver, String filePath, List<Integer> rowNums, String rwResults, String rwReasons) throws Exception {	
		String getResults= ""; String getReasons= ""; boolean isResults = false; String curUnitNum = ""; String getUnitNo = "";
		
		RC_Global.createNode(driver, "Validate the status for the updated Unit Numbers in the Downloaded Results File");
		try {
            FileInputStream fis = new FileInputStream(filePath);
            XSSFWorkbook wb = new XSSFWorkbook(fis);
            XSSFSheet sh = wb.getSheetAt(1);
            int rows = sh.getLastRowNum();
            int cols= sh.getRow(2).getLastCellNum();
            for (int j : rowNums) {
            	XSSFCell ccell = sh.getRow(j).getCell(2);
            	getResults = sh.getRow(j).getCell(0).getStringCellValue();
            	getReasons = sh.getRow(j).getCell(1).getStringCellValue();
            	if (rwResults.equalsIgnoreCase("No changes")) {
            		if (getResults.equalsIgnoreCase("No changes") && getReasons.contains("No action or update was requested")) {
            			isResults = true;
            		}
            	} else if (rwResults == "Error") {
            		if (getResults.equalsIgnoreCase("Error") && getReasons.contains(rwReasons)) {
                        isResults = true;
            		}
                } else if (getResults!= "No changes") {
              	   if (!getReasons.contains("No action or update was requested")) {
              		 isResults = true;
              	   }
                 }
            	if (isResults) {
        			  if (rwResults.equalsIgnoreCase(getResults)) {
        				  queryObjects.logStatus(driver, Status.PASS, "Verfiy '"+rwResults+"' is displayed in the result column for the unit number -"+getUnitNo , "Reason displayed -"+getReasons, null);
        				  if (!rwReasons.isEmpty()) {
        					  if (getReasons.contains(rwReasons)) {
                				  queryObjects.logStatus(driver, Status.PASS, "Verfiy '"+rwReasons+"' is displayed in the reasons column for the unit number -"+getUnitNo , "Reason displayed -"+getReasons, null);
        					  } else {
        						  queryObjects.logStatus(driver, Status.FAIL, "'"+getReasons+"' message displayed in the reasons column for the unit number -"+getUnitNo+"." , "Reason displayed -"+getReasons, null);
        					  }
        				  }
        			  } else {
        				  queryObjects.logStatus(driver, Status.FAIL, "'"+getResults+"' message displayed in the result column for the unit number -"+getUnitNo+". Expected message is '"+rwResults+"'" , "Reason displayed -"+getReasons, null);
        			  }
        		}
            	if (!isResults) {
					if (curUnitNum=="") {
						curUnitNum = ccell.getNumericCellValue()+"";
					} else {
						curUnitNum = curUnitNum+";"+ccell.getNumericCellValue();
					}
				}
			}     
            fis.close();
            if (!curUnitNum.isEmpty()) {
				queryObjects.logStatus(driver, Status.FAIL, "Validate the Changes are captured in Results and Reasons columns", "Changes are not captured for some of the updated fields"+" Those Columns Total View Person Id's are - "+curUnitNum+" and the reason is "+getReasons, null);
			}
	     } catch(TimeoutException te) {
	 		queryObjects.logStatus(driver, Status.FAIL, "Failed to Validate the Download Results file", te.getLocalizedMessage(), te);
	     }
	}
	
	public static String verifyExcelData(WebDriver driver, String filePath, String column, String expCellValue) throws Exception{
		String employee = "";
		try {
            FileInputStream fis = new FileInputStream(filePath);
            XSSFWorkbook wb = new XSSFWorkbook(fis);
            XSSFSheet sh = wb.getSheetAt(1);
            int rows = sh.getLastRowNum();
            int cols= sh.getRow(2).getLastCellNum(); 
            String employeeStatus = "";
            int activeCount = 0;
            int inactiveCount = 0;
            boolean present = false;
            
            
            switch(column) {
	            case "Status":
	            	int colNo = -1;
	            	for(int it=2;it<cols;it++) {
	            		if(sh.getRow(2).getCell(it).getStringCellValue().equalsIgnoreCase(column)) {
	            			colNo = it;
	            			break;
	            		}
	            	}
		            for(int it=5;it<rows;it++) {
		            	if(sh.getRow(it).getCell(34).getStringCellValue().equalsIgnoreCase("Active"))//Status
		            		activeCount++;
		            	else if(sh.getRow(it).getCell(34).getStringCellValue().equalsIgnoreCase("Inactive"))//Status
		            		inactiveCount++;
		            }
		            
		            if(activeCount>0 && inactiveCount>0)
		            	queryObjects.logStatus(driver, Status.PASS, "Verify Active and Inactive Status are present in the downloaded template", "Both the status are present", null);
		            else if(activeCount>0 && inactiveCount==0)
		            	queryObjects.logStatus(driver, Status.FAIL, "Verify Active and Inactive Status are present in the downloaded template", "Only Active employees are present in the downloaded template", null);
		            else if(activeCount==0 && inactiveCount>0)
		            	queryObjects.logStatus(driver, Status.FAIL, "Verify Active and Inactive Status are present in the downloaded template", "Only Inactive employees are present in the downloaded template", null);
	            break;
	           
	            case "Employee Assignment":
	            	colNo = -1;
	            	for(int it=2;it<cols;it++) {
	            		if(sh.getRow(2).getCell(it).getStringCellValue().equalsIgnoreCase(column)) {
	            			colNo = it;
	            			break;
	            		}
	            	}
	            	if(expCellValue.equalsIgnoreCase(""))//Verify that Employee Assignment value consists of blank values as well 
	            		for(int it=5;it<rows;it++) {
			            	if(sh.getRow(it).getCell(colNo).getStringCellValue().equalsIgnoreCase(expCellValue)){//Employee Assignment
			            		present=true;
			            		break;
			            	}
			            }
	            	else {
		            	for(int it=5;it<rows;it++) {//Verify all values under Employee Assignment column are the Node of Structure values
		            		present = false;
			            	if(sh.getRow(it).getCell(colNo).getStringCellValue().equalsIgnoreCase(expCellValue))//Employee Assignment
			            		present=true;
			            	else
			            		break;
			            }
		            	employee = sh.getRow(6).getCell(3).getStringCellValue()+" "+sh.getRow(6).getCell(4).getStringCellValue();
	            	}
	            	if(present)
	            		queryObjects.logStatus(driver, Status.PASS, "Verify "+expCellValue+" are present in the downloaded template as expected", expCellValue+" are present in the downloaded template as expected", null);
	            	else
	            		queryObjects.logStatus(driver, Status.FAIL, "Verify "+expCellValue+" are present in the downloaded template as expected", expCellValue+" are not present in the downloaded template as expected", null);
	            break;
            }    
            fis.close();
            FileOutputStream fos = new FileOutputStream(filePath);
            wb.write(fos);
            wb.close();
            fos.close();
	     } catch (Exception e) {
		     queryObjects.logStatus(driver, Status.FAIL, "Mandatory column values update failed", e.getLocalizedMessage(), e);
			 RC_Global.endTestRun(driver);
	     }
		return employee;
	}
	
	public static String verifyFieldType(WebDriver driver, String sectionType, String sectionToVerify,boolean endRun) throws Exception{
		String strValue ="";
		String fieldName = driver.findElement(By.xpath("//div[@id='"+sectionToVerify+"']/../div")).getText();
		String strXpath ="//div[@id='"+sectionToVerify+"']/div";
		
		strXpath ="//div[@id='"+sectionToVerify+"']/div";
		if(driver.findElements(By.xpath(strXpath+"/button")).size()>0)
		{
			strValue = driver.findElement(By.xpath(strXpath+"/button")).getText().trim();
			if(strValue.length()==0) {
				queryObjects.logStatus(driver, Status.PASS, "The "+fieldName+" field type is Hyperlink and its value is blank ", "", null);
			} else {
				queryObjects.logStatus(driver, Status.PASS, "The "+fieldName+" field type is Hyperlink and its value is" , strValue, null);
			}
		}
		else if(driver.findElements(By.xpath(strXpath+"/div")).size()>0)
		{
		strValue = driver.findElement(By.xpath(strXpath+"/div")).getText().trim();
			if(strValue.length()==0) {
				queryObjects.logStatus(driver, Status.PASS, "The "+fieldName+" field type is not Hyperlink and its value is blank ", "", null);
			} else {
				queryObjects.logStatus(driver, Status.PASS, "The "+fieldName+" field type is not Hyperlink and its value is" , strValue, null);
			}
		}
		return strValue;
	}
	
	public static void addValuesToAllColumnsExcept(WebDriver driver, String filePath, String UnitNos, String expCellValue, String ignoreColumns) throws Exception{

		try {
            FileInputStream fis = new FileInputStream(filePath);
            XSSFWorkbook wb = new XSSFWorkbook(fis);
            XSSFSheet sh = wb.getSheetAt(1);
            int rows = sh.getLastRowNum();
            int cols= sh.getRow(2).getLastCellNum();
            int row=0;
            for (int j = 5; j < rows; j++) {
            	if (UnitNos.contains(sh.getRow(j).getCell(2).getStringCellValue())) {
            		row = j;
            		break;
            	}
            }
            
            String format = "";
            for(int it=3;it<cols;it++) {
            	XSSFCell ccell = sh.getRow(row).getCell(it);
            	if(!ignoreColumns.contains(sh.getRow(2).getCell(it).getStringCellValue())){
            		if(expCellValue.equalsIgnoreCase(""))
            			ccell.setCellValue("");
            		else if(expCellValue.equalsIgnoreCase("Random")) {
            			format = sh.getRow(4).getCell(it).getStringCellValue().split(": ")[1];
	            		if(format.contains("N/A") || format.contains("Alphanumeric")){
	            			ccell.setCellValue(RandomStringUtils.randomAlphanumeric(5));
	            		}
	            		else if(format.contains("Numeric"))
	            			ccell.setCellValue(RandomStringUtils.randomNumeric(4));
            		}
            	}
            }
            
            fis.close();
            FileOutputStream fos = new FileOutputStream(filePath);
            wb.write(fos);
            wb.close();
            fos.close();
	     } catch (Exception e) {
		     queryObjects.logStatus(driver, Status.FAIL, "Mandatory column values update failed", e.getLocalizedMessage(), e);
			 RC_Global.endTestRun(driver);
	     }
	}
	
	public static void viewHistory_Employee(WebDriver driver, BFrameworkQueryObjects queryObjects, String custNo, String FirstN, String LastN, String user, String valTime) throws IOException {
		try {
		RC_Global.navigateTo(driver, "Manage", "Administration", "Employee Management");
		RC_Global.validateHeaderName(driver, "Employee Management", true);
		RC_Global.enterCustomerNumber(driver, custNo, "", "",true);
		WebElement element = driver.findElement(By.xpath("//input[@placeholder='Employee First Name']"));
		RC_Global.enterInput(driver, FirstN, element , false, true);
		WebElement element1 = driver.findElement(By.xpath("//input[@placeholder='Employee Last Name']"));
		RC_Global.enterInput(driver, LastN, element1, false, true);
		RC_Global.clickButton(driver, "Search",false, true);
		RC_Global.waitElementVisible(driver, 60, "//h5/span[text()='Edit Employee']", "Edit Employee Header", false, false);
		RC_Global.panelAction(driver, "close", "Employee Management", true, false);
		RC_Global.clickLink(driver, "History", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Employee History", "TV", true, true);
		RC_Global.panelAction(driver, "close", "Edit Employee", true, false);

		RC_Global.waitElementVisible(driver, 20, "//h5[span[contains(text(),'Driver Change')]]", "Driver Change", false,false);
		driver.findElement(By.xpath("//h5[span[contains(text(),'Driver Details')]]/i[@ng-click='closePanel()']")).click();
		try {
		driver.findElement(By.xpath("//i[contains(@ng-click,'maximize')]")).click();
		} catch (Exception e) {}
		Thread.sleep(500);
		try {
		WebDriverWait wait = new WebDriverWait(driver,20);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//tbody/tr//a[text()='View']//ancestor::tr)[1]")));
		}
		catch(Exception e) {}
		RC_Manage.selectHistoryView(driver, user, "", valTime);

		} catch (Exception e) {
		queryObjects.logStatus(driver, Status.FAIL, "Driver Details - History", "Navigation failed", e);
		}

		}
	

	public static List<Integer> updateRowData(WebDriver driver,String filePath, int BeginIndex,int NoOfColumnsTobeModified,String act,String AddressValidationOverrideValue,String addressToUpdate) throws Exception {
		String currentVal = "";String emailId = RandomStringUtils.randomAlphabetic(10).toUpperCase()+RandomStringUtils.randomNumeric(3)+"@merchants.com";
		String addressValue  = RandomStringUtils.randomAlphabetic(6)+RandomStringUtils.randomAlphabetic(3);
		String CityCode  = RandomStringUtils.randomAlphabetic(5);
		RC_Global.createNode(driver, act+ "few column values in Downloaded Excel file");
		List<Integer> rowChange = new ArrayList<Integer>();		
        try {
               FileInputStream fis = new FileInputStream(filePath);
               XSSFWorkbook wb = new XSSFWorkbook(fis);
               XSSFSheet sh = wb.getSheetAt(1);
               int rows = sh.getLastRowNum();
               int cols= sh.getRow(2).getLastCellNum();  
               rowChange.add(new Integer(BeginIndex));
               rowChange.add(new Integer(BeginIndex+1));
               for (int j : rowChange) {
                                 try {
                                	 //update address validation		 
                                	 XSSFCell cell = sh.getRow(j).getCell(12);   
                                	 cell.setCellValue(AddressValidationOverrideValue);     
                                	 
                                	 cell = sh.getRow(j).getCell(6);   
                                	 String Email = cell.getStringCellValue();
                                	 if(Email.isEmpty())
                                		 cell.setCellValue(emailId);
                                	 
                                	 if(!addressToUpdate.isEmpty()) {
                                		 cell = sh.getRow(j).getCell(13);   
                                		 cell.setCellValue(addressValue);
                                		 cell = sh.getRow(j).getCell(15);   
                                		 cell.setCellValue(CityCode);
                                	 }
                    
                                queryObjects.logStatus(driver, Status.PASS, "Column values update", "Column values are updated Successfully",null);     	       	 
                                 } catch (Exception e1) {
                                	 queryObjects.logStatus(driver, Status.FAIL, "Mandatory column values update failed", e1.getLocalizedMessage(), e1);
                         	        RC_Global.endTestRun(driver);
                                 }
               }
               fis.close();
               FileOutputStream fos = new FileOutputStream(filePath);
               wb.write(fos);
               wb.close();
               fos.close();
        } catch (Exception e) {
        	queryObjects.logStatus(driver, Status.FAIL, "Mandatory column values update failed", e.getLocalizedMessage(), e);
	        RC_Global.endTestRun(driver);
        }
		return rowChange;        		
	}	
	
	public static String modifyPoolManagementRowData(WebDriver driver, String filePath,int RowNum, int NoOfColumnsTobeModified, boolean endRun) throws Exception{
		RC_Global.createNode(driver, "Modify MandatoryClient Data in Pool Management Excel");
		try {
	         FileInputStream fis = new FileInputStream(filePath);String colval = ""; String[] Zipcode = {};
	         XSSFWorkbook wb = new XSSFWorkbook(fis);
	         XSSFSheet sh = wb.getSheetAt(1);String Unum = "";
	         int rows = sh.getLastRowNum();String Address1 = "";
	         int cols= sh.getRow(2).getLastCellNum();  
	         Thread.sleep(2000);
	         List<Integer> rowsChange = null;String DriverPoolName ="";
	         rowsChange = RC_Manage.RandomNumbers(driver,RowNum, rows,NoOfColumnsTobeModified);
	         for(int i=0;i<rowsChange.size();i++) {
	        	
	        	
	         }
	         fis.close();
		     FileOutputStream fos = new FileOutputStream(filePath);
	         wb.write(fos);
	         wb.close();
	         fos.close(); 
		     queryObjects.logStatus(driver, Status.PASS, "Non Manadatory Client data fields in excel","Non Mandatory Client data fields in excel are updated Successfully", null);

	         }
			 catch (Exception e) {
		        	queryObjects.logStatus(driver, Status.FAIL, "Non Manadatory Client data fields in excel are failed to update", e.getLocalizedMessage(), e);
		        	if(endRun)
			        RC_Global.endTestRun(driver);
		        }

		return UnitNumber;
		}
	
	public static void validateResultsOfRowNumbers(WebDriver driver, String curFilePath, Integer[] rowChanged, String rwResults, String[] reasons) throws Exception {
		
		String getResults= ""; String getReasons= ""; boolean isResults = false; String curUnitNum = ""; String getUnitNo = "";
		String[] Results = rwResults.split(";");		
		RC_Global.createNode(driver, "Validate the status for the updated Unit Numbers in the Downloaded Results File");
		try {
            FileInputStream fis = new FileInputStream(curFilePath);
            XSSFWorkbook wb = new XSSFWorkbook(fis);
            XSSFSheet sh = wb.getSheetAt(1);
            int rows = sh.getLastRowNum();
            int cols= sh.getRow(2).getLastCellNum();
					  
            for(int i=0; i<rowChanged.length;i++) {
            	XSSFCell ccell = sh.getRow(rowChanged[i]).getCell(2);
            	getResults = sh.getRow(rowChanged[i]).getCell(0).getStringCellValue();										 
            	getReasons = sh.getRow(rowChanged[i]).getCell(1).getStringCellValue();									  
            	if (Results[i].equalsIgnoreCase("No changes")) {
            		if (getResults.equalsIgnoreCase("No changes") && getReasons.contains("No action or update was requested")) {
            			isResults = true;							   
            		}
				} 
            	if(Results[i].equalsIgnoreCase("Success")) {
            		isResults = true;
            	}
            	
            	 else if (Results[i] == "Error") {
	              	   if (getResults.equalsIgnoreCase("Error") && getReasons.contains(reasons[i])) {
	              		   isResults = true;
	              	   }
	                 }
            	 else if (getResults!= "No changes") {
				   if (!getReasons.contains("No action or update was requested")) {
              		 isResults = true;
              	   }
                 }
				
            	if (isResults) {
        			  if (Results[i].equalsIgnoreCase(getResults)) {
        				  queryObjects.logStatus(driver, Status.PASS, "Verfiy '"+Results[i]+"' is displayed in the result column" , "Reason displayed -"+getReasons, null);
        				  if (!reasons[i].isEmpty() || !getReasons.isEmpty()) {
        					  if (reasons[i].contains(getReasons)) {
                				  queryObjects.logStatus(driver, Status.PASS, "Verfiy '"+reasons[i]+"' is displayed in the reasons column for the unit number -", "Reason displayed -"+getReasons, null);
        					  } else {
        						  queryObjects.logStatus(driver, Status.FAIL, "'"+getReasons+"' message displayed in the reasons column" , "Reason displayed -"+getReasons, null);
        					  }
        				  }
        			  } else {
        				  queryObjects.logStatus(driver, Status.FAIL, "'"+getResults+"' message displayed in the result column  Expected message is '"+rwResults+"'" , "Reason displayed -"+getReasons, null);
        			  }
        		}
            	if (!isResults) {
					if (curUnitNum=="") {
						curUnitNum = ccell.getNumericCellValue()+"";
					} else {
						curUnitNum = curUnitNum+";"+ccell.getNumericCellValue();
					}
				}
            	break;
            }     
	        fis.close();
	        if (!curUnitNum.isEmpty()) {
				queryObjects.logStatus(driver, Status.FAIL, "Validate the Changes are captured in Results and Reasons columns", "Changes are not captured for some of the updated fields"+" Those Columns Total View Person Id's are - "+curUnitNum+" and the reason is "+getReasons, null);
			}
	     } catch(TimeoutException te) {
	 		queryObjects.logStatus(driver, Status.FAIL, "Failed to Validate the Download Results file", te.getLocalizedMessage(), te);
	     }
	}
				
}
