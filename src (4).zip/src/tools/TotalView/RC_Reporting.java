package tools.TotalView;

import java.io.File;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;

public class RC_Reporting {
	
	static BFrameworkQueryObjects queryObjects = new BFrameworkQueryObjects();
	
	public static void navigateTo(WebDriver driver, String menu, String frstSubMenu, String scndSubMenu) throws Exception {
		try {
			RC_Global.createNode(driver, "Navigate To: "+menu+">"+frstSubMenu+">"+scndSubMenu+"");
	
	
	
			Thread.sleep(2000);
			driver.findElement(By.xpath("//span[text()='"+menu+"']")).click();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//a[span[text()='"+menu+"']]/following-sibling::div//span[text()='"+frstSubMenu+"']")).click();//First click does
	
	
	
			if(!scndSubMenu.equals("")) {
				driver.findElement(By.xpath("//a[span[text()='"+menu+"']]/following-sibling::div//span[text()='"+frstSubMenu+"']")).click();//First click does
				Thread.sleep(1000);
				if(driver.findElements(By.xpath("(//span[contains(text(),'"+scndSubMenu+"')])[1]")).size()>0)
					driver.findElement(By.xpath("(//span[contains(text(),'"+scndSubMenu+"')])[1]")).click();
				else if(driver.findElements(By.xpath("//span[contains(text(),'"+scndSubMenu+"')]")).size()>0)
					driver.findElement(By.xpath("//span[contains(text(),'"+scndSubMenu+"')]")).click();
				Thread.sleep(2000);
			}
			Thread.sleep(2000);
			queryObjects.logStatus(driver, Status.PASS, "Navigation to module ", "Navigation Successfull",null);

		}
		catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver, Status.FAIL, "Navigate to the required screen failed -> Kindly provide right fields for navigation", nse.getLocalizedMessage(), nse);
			RC_Global.endTestRun(driver);
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "Navigate to the required screen failed -> Unable to load the current/previous screen", te.getLocalizedMessage(), te);
			RC_Global.endTestRun(driver);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Navigation to Screen Failed", e.getLocalizedMessage(),e);
			RC_Global.endTestRun(driver);
		}
	}
	
	
	public static void panelAction(WebDriver driver, String action, String headerORXpath,boolean endRun,boolean createND)throws Exception {
		if(createND)
			RC_Global.createNode(driver, "Panel Action-->"+action+"-->"+headerORXpath); String actionType = "";
			try {
				Thread.sleep(2000);
				switch(action) {
				case "compress":
					actionType = action;
					if(driver.findElements(By.xpath("//h5[span[text()='"+headerORXpath+"']]/i[contains(@class,'fa-compress') and @ng-click='maximize(panel)']")).size()==1)
						driver.findElement(By.xpath("//h5[span[text()='"+headerORXpath+"']]/i[contains(@class,'fa-compress') and @ng-click='maximize(panel)']")).click(); 
					else if(driver.findElements(By.xpath("//h5[span[contains(text(),'"+headerORXpath+"')]]/i[contains(@class,'fa-compress') and @ng-click='maximize(panel)']")).size()==1)
						driver.findElement(By.xpath("//h5[span[contains(text(),'"+headerORXpath+"')]]/i[contains(@class,'fa-compress') and @ng-click='maximize(panel)']")).click();
					break;
				case "expand":
					actionType = action;
					if(driver.findElements(By.xpath("//h5[span[text()='"+headerORXpath+"']]/i[contains(@class,'fa-expand') and @ng-click='maximize(panel)']")).size()==1)
						driver.findElement(By.xpath("//h5[span[text()='"+headerORXpath+"']]/i[contains(@class,'fa-expand') and @ng-click='maximize(panel)']")).click(); 
					else if(driver.findElements(By.xpath("//h5[span[contains(text(),'"+headerORXpath+"')]]/i[contains(@class,'fa-expand') and @ng-click='maximize(panel)']")).size()==1)
						driver.findElement(By.xpath("//h5[span[contains(text(),'"+headerORXpath+"')]]/i[contains(@class,'fa-expand') and @ng-click='maximize(panel)']")).click();
					break; 
					case "close":
						actionType = action;
						if(driver.findElements(By.xpath("//h5[span[text()='"+headerORXpath+"']]/i[@ng-click='closePanel()']")).size()==1)
							driver.findElement(By.xpath("//h5[span[text()='"+headerORXpath+"']]/i[@ng-click='closePanel()']")).click(); 
						else if(driver.findElements(By.xpath("//h5[span[contains(text(),'"+headerORXpath+"')]]/i[@ng-click='closePanel()']")).size()==1)
							driver.findElement(By.xpath("//h5[span[contains(text(),'"+headerORXpath+"')]]/i[@ng-click='closePanel()']")).click();
						break;
					case "xpathcompress":
						actionType = "compress";
						if(driver.findElements(By.xpath(headerORXpath+"/i[contains(@class,'fa-compress') and @ng-click='maximize(panel)']")).size()==1)
							driver.findElement(By.xpath(headerORXpath+"/i[contains(@class,'fa-compress') and @ng-click='maximize(panel)']")).click();
						break;
					case "xpathexpand":
						actionType = "expand";
						if(driver.findElements(By.xpath(headerORXpath+"/i[contains(@class,'fa-expand') and @ng-click='maximize(panel)']")).size()==1)
							driver.findElement(By.xpath(headerORXpath+"/i[contains(@class,'fa-expand') and @ng-click='maximize(panel)']")).click();
						break;
					case "xpathclose":
						actionType = "close";
						if(driver.findElements(By.xpath(headerORXpath+"/i[@ng-click='closePanel()']")).size()==1)
							driver.findElement(By.xpath(headerORXpath+"/i[@ng-click='closePanel()']")).click();
						else if(driver.findElements(By.xpath(headerORXpath+"//i[@ng-click='closePanel()']")).size()==1)
							driver.findElement(By.xpath(headerORXpath+"//i[@ng-click='closePanel()']")).click();
						break;
				}
				Thread.sleep(3000);
				queryObjects.logStatus(driver, Status.INFO, "Panel Action to be performed", "Panel Action Successful", null);
			}
			catch(ElementNotInteractableException enie) {
				queryObjects.logStatus(driver, Status.FAIL, "Unable to click on the "+actionType+" icon", enie.getLocalizedMessage(), enie);
				if(endRun)
					RC_Global.endTestRun(driver);
			}
			catch(TimeoutException te) {
				queryObjects.logStatus(driver, Status.FAIL, "Unable to locate the "+actionType+" icon", te.getLocalizedMessage(), te);
				if(endRun)
					RC_Global.endTestRun(driver);
			}
			catch(Exception e) {
				queryObjects.logStatus(driver, Status.FAIL, "Unable to "+actionType+" the panel", e.getLocalizedMessage(), e);
				if(endRun)
					RC_Global.endTestRun(driver);
			}
	}


	
	public static void reportErrorValidation(WebDriver driver, String errorSelector) throws Exception{
		try {
			RC_Global.waitElementVisible(driver, 30, errorSelector, "Error Message", true, false);
			queryObjects.logStatus(driver, Status.PASS, "Verify error message is displayed", "Error message is displayed", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify error message is displayed", "Error message is not displayed", null);
		}
	}
	
	public static void generateReportValidateResults(WebDriver driver) throws Exception{
		RC_Global.createNode(driver, "Generate Report and Validate Report Results Displayed");
		
		String errorSelector = "//*[@id='ssrsReportViewer']//div[contains(@class, 'bg-danger text-center')]//h4";				
		RC_Global.clickButton(driver, "Generate Report", true, false);		
		Thread.sleep(3000);
		
		if(driver.findElements(By.xpath(errorSelector)).size()>0) {			
			String errorContent = driver.findElement(By.xpath(errorSelector)).getText();
			queryObjects.logStatus(driver, Status.FAIL, "Generate Report Results Failed", "Error: " +errorContent, null);
			RC_Global.endTestRun(driver); //driver.close();
		}	
		else if(driver.findElements(By.xpath("//div[text()='No Records Found']")).size()>0){
			queryObjects.logStatus(driver, Status.WARNING, "No Records Found", null , null);
			RC_Global.endTestRun(driver);
		}
		if(RC_Global.waitElementVisible(driver, 90, "//td[@id='oReportCell']", "Report Results Grid",true, false)==false)
			RC_Global.endTestRun(driver);
	}
	
	public static boolean validateReportColumnNames(WebDriver driver, String columnNames) throws Exception{
		RC_Global.createNode(driver, "Validate Report Column Names");
		boolean flag = true;
		String [] expColName = columnNames.split(";");

		for(int i=0; i<expColName.length; i++) {
			try {
				driver.findElement(By.xpath("(//*[@id='oReportCell']//td[contains(.,'"+expColName[i]+"')])[1]"));				
			}
			catch(Exception e) {
				queryObjects.logStatus(driver, Status.FAIL, "Validate Report Column Names--->Column: " + expColName[i] + "--->Was NOT Found", e.getLocalizedMessage(), e);
				flag = false;
			}
		}
		if(flag)
			queryObjects.logStatus(driver, Status.PASS, "Validate Report"," Column Names", null);
		return flag;
	}

	public static void clickReportCellHyperLink(WebDriver driver, String linkName, String panelTitle) throws Exception{
		RC_Global.createNode(driver, "Click Report Cell Link & Validate Panel Title-->" +panelTitle);
		String selector = null;
		
		
		try {
			List<WebElement> reportTableHeader = driver.findElements(By.xpath("//table[@style='border-collapse:collapse;']//tr[2]//tr/td[1]"));
			int c = reportTableHeader.size();
				for(int i=0; i<c; i++) {
					String colName = reportTableHeader.get(i).getText().trim();
									
						if(colName.equalsIgnoreCase(linkName)) {
							String linkXpath="//tbody//tr[3]//td["+(i+1)+"]/div/a";

							if(driver.findElements(By.xpath(linkXpath)).size()>0)
							{
								Thread.sleep(1000);
								queryObjects.logStatus(driver, Status.PASS, "Verify "+linkName+" is a link", linkName+" is a link", null);
								driver.findElement(By.xpath(linkXpath)).click();
								Thread.sleep(2000);
								//RC_Global.waitUntilPanelVisibility(driver, panelTitle, "TV");
								RC_Global.waitElementVisible(driver, 30, "//h5/span[text()='"+panelTitle+"']", panelTitle,true, false);
								break;
							}
							
							else if(driver.findElements(By.xpath("//tbody//tr[3]//td["+(i+1)+"]//div")).size()>0)
							{
								Thread.sleep(1000);
								queryObjects.logStatus(driver, Status.PASS, "Verify "+linkName+" is a link", linkName+" is a link", null);
								linkXpath = "//tbody//tr[3]//td["+(i+1)+"]//div";
								driver.findElement(By.xpath(linkXpath)).click();
								Thread.sleep(2000);
								//RC_Global.waitUntilPanelVisibility(driver, panelTitle, "TV");
								RC_Global.waitElementVisible(driver, 30, "//h5/span[text()='"+panelTitle+"']", panelTitle,true, false);
								break;
							}
							else
							{
								queryObjects.logStatus(driver, Status.FAIL, "Verify "+linkName+" is a link", linkName+" is not a link", null);
							}
						}

				}		
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Click Report Cell Link-->Validate Panel Title Failed-->"+panelTitle, e.getLocalizedMessage(), e);
		}
	}
	public static void reportParametersNavigate(WebDriver driver) throws Exception{
		
		RC_Global.createNode(driver, "Navigate to Report Parameters Table");
		
		try {
			driver.findElement(By.xpath("//button[@ng-click='lastPage()']")).click();
			Thread.sleep(5000);
			if(driver.findElements(By.xpath("//*[@id='oReportCell']//tr[2]//div[contains(., 'Report run at')]")).size()==0) {
				driver.findElement(By.xpath("//button[@ng-click='previousReportPage()']")).click();
				Thread.sleep(2000);
			}
			RC_Global.waitElementVisible(driver, 90, "//*[@id='oReportCell']//tr[2]//div[contains(., 'Report run at')]", "ParametersTable",true, true);		
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "NavigateTo-->Report Paramaters Table-->Failed", e.getLocalizedMessage(), e);
		}
}

	public static void validateReportParameterData(WebDriver driver, String expParamName, String expParamValue) throws Exception{
		RC_Global.createNode(driver, "Validate Report Parametrs Data-->"+expParamName);
		
		String tempValue = "";
		String actValue = null;
		String Xpath = "";
		if(expParamName.contains("'")) {
			tempValue = expParamName;
			expParamName = expParamName.split("'")[0];
			Xpath = "//div[contains(text(),'"+expParamName+"')]";
		}
		else
			Xpath = "//div[text()='"+expParamName+"']";
			
		if(driver.findElements(By.xpath(Xpath)).size()<1)
		{
			
			if(!driver.findElement(By.xpath("//button[@ng-click='lastPage()']")).isEnabled()) {
				driver.findElement(By.xpath("//button[@ng-click='previousReportPage()']")).click();
				RC_Global.waitElementNotVisible(driver, 30, "//div[@ng-show='executingReport']/i", "Spinner", true, false);
				if(driver.findElements(By.xpath(Xpath)).size()<1) {
					queryObjects.logStatus(driver, Status.FAIL, "Verify "+expParamName+" is available", expParamName+" is not available", null);
					return;
				}
			}
			else {
				driver.findElement(By.xpath("//button[@ng-click='nextReportPage()']")).click();
				RC_Global.waitElementNotVisible(driver, 30, "//div[@ng-show='executingReport']/i", "Spinner", true, false);
				if(driver.findElements(By.xpath(Xpath)).size()<1) {
					queryObjects.logStatus(driver, Status.FAIL, "Verify "+expParamName+" is available", expParamName+" is not available", null);
					return;
				}
			}
			
//			}
//			catch(Exception e) {
//				driver.findElement(By.xpath("//button[@ng-click='nextReportPage()']")).click();
//				Thread.sleep(2000);
//			}
		}
		if(!tempValue.equalsIgnoreCase(""))
			expParamName = tempValue;
		List<WebElement> paramNames = driver.findElements(By.xpath("//table[@style='border-collapse:collapse;']//tr//td[1]/div"));
		for(int i = 0; i<paramNames.size(); i++) {
			String name = paramNames.get(i).getText().trim();
			if(paramNames.get(i).getText().trim().equalsIgnoreCase(expParamName)) {
				
				if(driver.findElements(By.xpath("//table[@style='border-collapse:collapse;']//tr//td[1]"+Xpath+"/../../td[2]/div")).size()>0) {
					actValue = driver.findElement(By.xpath("//table[@style='border-collapse:collapse;']//tr//td[1]"+Xpath+"/../../td[2]/div")).getText().trim();
					break;
				}
				else {
						queryObjects.logStatus(driver, Status.FAIL, "Verify the values of the parameter: "+expParamName, "No values present for the parameter", null);
					}
				}
		}
		if(!actValue.contains(expParamValue)) {
		//queryObjects.logStatus(driver, Status.PASS, "For Parameter-->"+expParamName+", Value Expected-->"+expParamValue, " Actual-->"+expValue, null);
			queryObjects.logStatus(driver, Status.FAIL, "For Parameter-->"+expParamName, "Value Expected-->"+expParamValue+", Actual-->"+actValue, null);
		}
		else
			queryObjects.logStatus(driver, Status.PASS, "For Parameter-->"+expParamName+", Value Expected-->"+expParamValue, " Actual-->"+actValue, null);
	}
	
	public static void validateCustomerNumberParamData(WebDriver driver, String customerNumber) throws Exception {
		RC_Global.createNode(driver, "Validate Report Parametrs Data--> Customer Number");
		
		String expParamValue = "";
		String actParamValue = driver.findElement(By.xpath("//table[@style='border-collapse:collapse;']//tr//td[1]/div[text()='Customer Number']/../../td[2]/div")).getText().trim();
		
		try {
//												DECLARE @AccountName VARCHAR(5000) SELECT @AccountName = COALESCE(@AccountName + ', ', '') + AccountName FROM [TotalView].[dbo].[Customer] WHERE AccountName IS NOT NULL and MerchantsCustomerId in (select MerchantsCustomerId from [TotalView].[dbo].[Customer] where AccountName = '"+customerNumber+"') select distinct @AccountName
			expParamValue = RC_Global.database("DECLARE @AccountName VARCHAR(8000)\r\n" + 
					"             SELECT @AccountName = COALESCE(@AccountName + ', ', '') + AccountName " + 
					"             FROM dbo.Customer " + 
					"             WHERE AccountName IS NOT NULL " + 
					"             and MerchantsCustomerId in (select MerchantsCustomerId from dbo.Customer where AccountName = '"+customerNumber+"') " + 
					"             select distinct @AccountName as [AccountName]");
			

			String[] actualValues = actParamValue.split(", ");
			
			String[] expectedValues = expParamValue.split(", ");
			
			if(!(actualValues.length == expectedValues.length))
				queryObjects.logStatus(driver, Status.FAIL, "Verify the count of the Expected and Actual parameter values", "Expected value: "+expectedValues.length+" Actual value: "+actualValues.length, null);
			
			boolean flag=false;
			boolean finalFlag = true;
			for(int iter1=0; iter1<expectedValues.length; iter1++) {
				for(int iter2=0;iter2<actualValues.length; iter2++) {
					if(actualValues[iter2].equalsIgnoreCase(expectedValues[iter1])) {
						flag=true;
						break;
					}
				}
				if(!flag) {
					queryObjects.logStatus(driver, Status.FAIL, "Verify the Expected and Actual parameter value", expectedValues[iter1]+" is not displayed", null);
					finalFlag = false;
				}
			}	
			if(finalFlag)
				queryObjects.logStatus(driver, Status.PASS, "Verify the Expected and Actual parameter values", "All values are displayed as expected", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify Customer Number validation in the parameter table", "Customer Value Expected-->"+expParamValue+", Actual-->"+actParamValue, null);
		}
	}
	
	public static void fromToDateErrorValidation(WebDriver driver, WebElement fromDateElement, WebElement toDateElement) throws Exception{
		String fromDate = RC_Global.getDateTime(driver, "MM/dd/yyyy", 0, true);
		String toDate = RC_Global.getDateTime(driver, "MM/dd/yyyy", -3, true);
		try {
			RC_Global.enterInput(driver, fromDate, fromDateElement, true, true);
			RC_Global.enterInput(driver, toDate, toDateElement, true, true);
			
			RC_Global.clickButton(driver, "Generate Report", true, true);
			
			reportErrorValidation(driver, "//h4[text()='From Date cannot be greater than To Date']");
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify Error Message", e.getLocalizedMessage(), e);
		}
	}
	
	public static void verifySortFunction(WebDriver driver, String columnName, boolean createND) throws Exception{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		WebElement eElement = driver.findElement(By.xpath("//button[text()='Excel']"));
		try {
			if(createND)
			{
				RC_Global.createNode(driver, "Ascending Order Sort ---> "+columnName);
				queryObjects.logStatus(driver, Status.INFO, "Ascending order sort", "",null);
			}
			RC_Global.waitElementVisible(driver, 30, "//td/a[img]/span", "Grid row", false, false);
			RC_Global.clickUsingXpath(driver, "//td[text()='"+columnName+"']/following-sibling::td/a[img]/span", "Column Sort button", false, false);
			wait.until(ExpectedConditions.elementToBeClickable(eElement));
			if(createND)
			{	
				RC_Global.createNode(driver, "Descending Order Sort ---> "+columnName);
				queryObjects.logStatus(driver, Status.INFO, "Descending order sort", "",null);
			}
			RC_Global.waitElementVisible(driver, 30, "//td/a[img]/span", "Grid row", false, false);
			RC_Global.clickUsingXpath(driver, "//td[text()='"+columnName+"']/following-sibling::td/a[img]/span", "Column Sort button", false, false);
			wait.until(ExpectedConditions.elementToBeClickable(eElement));
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify Sort Functionality ---> Validation Unsuccessful", e.getLocalizedMessage(), e);
		}
	}
	
	public static void downloadAndVerifyFileDownloaded(WebDriver driver, String DwnFileNm,String CreateNodeMessage, boolean endRun) throws Exception {
		RC_Global.createNode(driver, CreateNodeMessage);
		WebElement eElement = null;
		try {
			boolean flag = false;
			String home = System.getProperty("user.home");
			File listofFiles = new File(home + "/Downloads/");
			WebDriverWait wait = new WebDriverWait(driver, 120);
			Thread.sleep(500);
	
			RC_Global.clickButton(driver, "Excel", true, false);
			eElement=driver.findElement(By.xpath("//button[text()='Excel']"));
			wait.until(ExpectedConditions.elementToBeClickable(eElement));
	
			Thread.sleep(5000);
			// Check for the files available
			for (File file : listofFiles.listFiles()) {
				String filename = file.getName();
				if (filename.contains(DwnFileNm)) {
					flag = true;
					file.delete();
					break;
				}
			}
			if (flag)
				queryObjects.logStatus(driver, Status.PASS, "" + CreateNodeMessage + "", "Successfully", null);
			else
				queryObjects.logStatus(driver, Status.FAIL, ""+CreateNodeMessage+"", "Failed", null);
		}
		catch(ElementNotInteractableException enie) {
			queryObjects.logStatus(driver, Status.FAIL, "Download and verify failed -> Failed to click on the button to download", enie.getLocalizedMessage(),enie);
			if (endRun)
				RC_Global.endTestRun(driver);
		} 
		catch (TimeoutException te) {
		queryObjects.logStatus(driver, Status.FAIL, "Download and verify failed -> The button has not loaded",te.getLocalizedMessage(), te);
		if (endRun)
		RC_Global.endTestRun(driver);
		} catch (Exception e) {
		queryObjects.logStatus(driver, Status.FAIL, "Download and verify failed", e.getLocalizedMessage(), e);
		if (endRun)
		RC_Global.endTestRun(driver);
		}
	}
	
	public static void selectMultipleOptionsFromSelection(WebDriver driver, String multSelection, String selectionValue,boolean endRun) throws Exception{
		RC_Global.createNode(driver,"Select Multiple options from "+multSelection+" search filter");
		try {
			int flag = 0;
			int flags = 0;
			String[] sSelectionValue = new String[10];
			String[] ssSelectionValue = new String[20];
			
			String attributeType = "";
			
			if(selectionValue.contains(";")) {			//The selections of each multiSelection value is separated by ";" 
				sSelectionValue = selectionValue.split(";");
			}
			else {
				sSelectionValue[0] = selectionValue;
				flags = 1;
			}
			String multiSelection = new String();
			String[] aMultiSelection = new String[20];
			if(multSelection.contains(";")) {
				aMultiSelection = multSelection.split(";");
			}
			else {
				aMultiSelection[0] = multSelection;
				flag = 1;
			}
				
			for(int index=0; index<aMultiSelection.length;index++) {
				if(index==1 && flag==1)break;	
				multSelection = aMultiSelection[index];
				
				Thread.sleep(3000);
				
				WebElement ele = driver.findElement(By.xpath("//div[label[text()='"+multSelection+":']]//select"));
				List<WebElement> lElem = driver.findElements(By.xpath("//div[label[text()='"+multSelection+":']]//select/option"));
				
				Select iSelectionValue = new Select(ele);
				iSelectionValue = new Select(ele);
				
				
				driver.findElement(By.xpath("//div[label[text()='"+multSelection+":']]//select/option[@value][1]")).click();

				iSelectionValue.deselectAll();
				
				JavascriptExecutor executor = (JavascriptExecutor)driver;
					   Thread.sleep(1000);
				executor.executeScript("document.body.style.zoom = '30%'");
					   Thread.sleep(2000);
				executor.executeScript("document.body.style.zoom = '100%'");
				ssSelectionValue = new String[20];
				if(sSelectionValue[index].contains("--")) {			//The selections within each multiSelection value is separated by "," 
					ssSelectionValue = sSelectionValue[index].split("--");
				}
				else {
					ssSelectionValue[0] = sSelectionValue[index];
				}
				
				for(int iter=0;iter<ssSelectionValue.length;iter++) {
					if(!sSelectionValue[index].contains("--")&&iter==1) break;
					for(int i=0;i<lElem.size();i++){
						if(iSelectionValue.isMultiple()) {
							if(ssSelectionValue[iter].equalsIgnoreCase(lElem.get(i).getText())) { 
								iSelectionValue.selectByVisibleText(ssSelectionValue[iter]);
								queryObjects.logStatus(driver, Status.INFO, "Vehicle Status", ssSelectionValue[iter], null);
								break;
							}
						} 
					}
				}
			}
		}
		catch(NullPointerException npe) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to select the required options -> The expected options are not present in the selection box - Verify the xpath", npe.getLocalizedMessage(), npe);
			if(endRun)
				RC_Global.endTestRun(driver);
		}
		catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to select the required options -> The expected options are not present in the selection box.", nse.getLocalizedMessage(), nse);
			if(endRun)
				RC_Global.endTestRun(driver);
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to select the required options -> The expected options were not selected", te.getLocalizedMessage(), te);
			if(endRun)
				RC_Global.endTestRun(driver);
		}
		catch(ElementNotInteractableException enie) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to select the required options -> The expected options could not be selected", enie.getLocalizedMessage(), enie);
			if(endRun)
				RC_Global.endTestRun(driver);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to select the required options", e.getLocalizedMessage(), e);
			if(endRun)
				RC_Global.endTestRun(driver);
		}
	}
	
	public static String retrieveClientData(WebDriver driver, String customerNumber, int count) throws Exception{
		String columnClientData = "";
		try {	
			RC_Global.navigateTo(driver, "Manage", "Administration", "Client Data Setup");
			RC_Global.enterCustomerNumber(driver, customerNumber, "", "", true);
			Thread.sleep(2000);
			RC_Global.waitElementVisible(driver, 30, "//tr[td[span[normalize-space(text())='Active']]]/td[2]", "Client Data Fields", true, false);
			List<WebElement> clientData = driver.findElements(By.xpath("//tr[td[span[normalize-space(text())='Active']]]/td[2]"));
			
			List<String> sClientData = new ArrayList<String>();
			for(WebElement cd:clientData) {
				sClientData.add(cd.getText());
			}
			
	
			if(count==0)count=sClientData.size();
			else if(count>sClientData.size())count = sClientData.size();
					
			for(int iter=0; iter<count; iter++) {
				if(iter==0)
					columnClientData = sClientData.get(iter);
				else
					columnClientData = columnClientData+";"+sClientData.get(iter);
			}
			
			RC_Global.panelAction(driver, "close", "Client Data Setup", true, false);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Retrieve Client Data Fields from 'Client Data Setup'", e.getLocalizedMessage(), e);
		}
		return columnClientData;
	}
	
	public static boolean waitElementVisible(WebDriver driver, int sec, String xpath, String Element, boolean endRun, boolean createND)throws Exception{
		if(createND)
			RC_Global.createNode(driver, "Wait Element is Visible-->"+Element);
		
		try {
			WebDriverWait wait = new WebDriverWait(driver,sec);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.INFO, "", "", null);
			return false;		
		}
		return true;
	}
}
		


