package tools.TotalView;

	
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;

public class RC_FleetServices {
	
	public static String ROReferenceNum ="";
	public static String VendorNearYou = null;
	public static String VendorNameFromTV = null;
	public static String RoCreatedBy = null;
	public static String GLtemplatefromTV = null;
	public static String BillproductfromTV = null;
	public static String BillinvoicefromTV = null;
	public static String drivername = "";
	public static String UnitNumber = "";
	public static String VehicleStatus = "";
	public static String Firstname= "";
	public static String Lastname= "";
	public static String DriverAddress = "";
	static BFrameworkQueryObjects queryObjects = new BFrameworkQueryObjects();
	
	public static void selectRecordOrValueFromGrid(WebDriver driver, String RecordOrGridValueToSelect,boolean endRun) throws Exception {
		RC_Global.createNode(driver, "Selecting "+RecordOrGridValueToSelect+" From the Grid Result");
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		try {
			boolean	firstpage=false;
			boolean pagination=false;
			
			if(RecordOrGridValueToSelect.equalsIgnoreCase("Pending Invoice")) {
				RC_Global.waitElementVisible(driver, 30, "(//div[contains(@class,'ui-grid-row')])[1]", "Add RO Line Items Service Code", endRun,false);
				List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("//div[contains(@class,'ui-grid-row')]"));  
				int rowcnt=Getgridrowcnt.size();
				for(int i=1; i<=rowcnt;i++) {
					String sub=driver.findElement(By.xpath("(//div[contains(@class,'ui-grid-row')]//div[text()='"+RecordOrGridValueToSelect+"'])["+i+"]")).getText();
					
					if(!sub.equalsIgnoreCase("ROStatus")) {
						driver.findElement(By.xpath("(//div[contains(@class,'ui-grid-row')]//div[text()='"+RecordOrGridValueToSelect+"'])["+i+"]")).click();
						firstpage = false;
						break;
					}
					firstpage = true;
				}
				//Pagination-To loop through the pages to search 
				if(firstpage) 
				{	
					String NextBttn = driver.findElement(By.xpath("//a[text()='Next']")).getAttribute("ng-disabled");
					while(!NextBttn.equals("ngDisabled")) {
						driver.findElement(By.xpath("//a[text()='Next']")).click();
						Thread.sleep(3000);
						for(int j=1; j<=rowcnt;j++) {
							WebElement sub= driver.findElement(By.xpath("(//div[contains(@class,'ui-grid-row')]//div[text()='"+RecordOrGridValueToSelect+"'])["+j+"]"));
							
							if(!sub.getText().equalsIgnoreCase("ROStatus")) {
								driver.findElement(By.xpath("(//div[contains(@class,'ui-grid-row')]//div[text()='"+RecordOrGridValueToSelect+"'])["+j+"]")).click();
								pagination=false;
								break;
							} else       
								pagination=true;}
					if(pagination){ 
						NextBttn =  driver.findElement(By.xpath("//a[text()='Next']")).getAttribute("ng-disabled");
					}
					else {
					break;}
					}
				}
				//Pagination-To loop through the pages to search
			}	
			else if (RecordOrGridValueToSelect.equalsIgnoreCase("Last4digit")) {
				List<WebElement> Getgridrowcnt = driver.findElements(By.xpath("//table//tbody//tr"));
				int rowcnt = Getgridrowcnt.size();
				for (int i = 1; i <= rowcnt; i++) {
					String sub = driver.findElement(By.xpath("//tr[" + i + "]//td[3]//span[@title='Order Fuel Card']")).getText();
					String EnrolledInFuel = driver.findElement(By.xpath("//table/tbody/tr["+i+"]//td[19]")).getText();
					Thread.sleep(2000);
					if (!sub.equalsIgnoreCase("Order Fuel Card") && (EnrolledInFuel.equalsIgnoreCase("Yes"))) {
						//driver.findElement(By.xpath("//tr[" + i + "]//td[3]//span[1]")).click();
						WebElement SearchGridRecord = driver.findElement(By.xpath("//tr[" + i + "]//td[3]//span[1]"));
						executor.executeScript("arguments[0].click();", SearchGridRecord);
						firstpage = false;
						break;
					
					}
					firstpage = true;
				}
				//Pagination-To loop through the pages to search 
				if(firstpage)
				{	
					String NextBttn = driver.findElement(By.xpath("//a[text()='Next']")).getAttribute("ng-disabled");
					while(!NextBttn.equals("ngDisabled")) {
						driver.findElement(By.xpath("//a[text()='Next']")).click();
						Thread.sleep(3000);
						for(int j=1; j<=rowcnt;j++) {
							WebElement sub= driver.findElement(By.xpath("//tr["+j+"]//td[3]//span[@title='Order Fuel Card']"));
							String EnrolledInFuel = driver.findElement(By.xpath("//table/tbody/tr["+j+"]//td[19]")).getText();
							Thread.sleep(2000);
							if (!sub.getText().equalsIgnoreCase("Order Fuel Card") && (EnrolledInFuel.equalsIgnoreCase("Yes"))) {
								//driver.findElement(By.xpath("//tr["+j+"]//td[3]//span[1]")).click();
								WebElement SearchGridRecord = driver.findElement(By.xpath("//tr["+j+"]//td[3]//span[1]"));
								executor.executeScript("arguments[0].click();", SearchGridRecord);
								pagination=false;
								break;}
							 else       
								pagination=true;}
					if(pagination){ 
						NextBttn =  driver.findElement(By.xpath("//a[text()='Next']")).getAttribute("ng-disabled");
					}
					else {
					break;}
					}
				}
			}
   
			else if(RecordOrGridValueToSelect.equalsIgnoreCase("Order Fuel Card")){
                List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("//table//tbody//tr"));  
                int rowcnt=Getgridrowcnt.size();
                for(int i=1; i<=rowcnt;i++) {
                      String sub=driver.findElement(By.xpath("//tr["+i+"]//td[3]//span[@title='Order Fuel Card']")).getText();
                      Thread.sleep(2000);
                      if(sub.equalsIgnoreCase("Order Fuel Card")) {
                          //   driver.findElement(By.xpath("//tr["+i+"]//td[3]//span[2]")).click();
                    	  WebElement SearchGridRecord = driver.findElement(By.xpath("//tr[" + i + "]//td[3]//span[2]"));
                    	  executor.executeScript("arguments[0].click();", SearchGridRecord);
                    	  firstpage = false;
                    	  break;
                     }
                     firstpage = true;
                                 
         }

				//Pagination-To loop through the pages to search 
				if(firstpage)
				{	
					String NextBttn = driver.findElement(By.xpath("//a[text()='Next']")).getAttribute("ng-disabled");
					while(!NextBttn.equals("ngDisabled")) {
						driver.findElement(By.xpath("//a[text()='Next']")).click();
						Thread.sleep(3000);
						for(int j=1; j<=rowcnt;j++) {
							WebElement sub= driver.findElement(By.xpath("//tr["+j+"]//td[3]//span[@title='Order Fuel Card']"));
							String EnrolledInFuel = driver.findElement(By.xpath("//table/tbody/tr["+j+"]//td[19]")).getText();
							Thread.sleep(2000);
							if (!sub.getText().equalsIgnoreCase("Order Fuel Card") && (EnrolledInFuel.equalsIgnoreCase("Yes"))) {
								//driver.findElement(By.xpath("//tr["+j+"]//td[3]//span[1]")).click();
								WebElement SearchGridRecord = driver.findElement(By.xpath("//tr["+j+"]//td[3]//span[1]"));
								executor.executeScript("arguments[0].click();", SearchGridRecord);
								pagination=false;
								break;}
							else if(sub.getText().equalsIgnoreCase("Order Fuel Card")) {
                                //driver.findElement(By.xpath("//tr["+j+"]//td[3]//span[2]")).click();
								WebElement SearchGridRecord = driver.findElement(By.xpath("//tr["+j+"]//td[3]//span[2]]"));
								executor.executeScript("arguments[0].click();", SearchGridRecord);
								pagination=false;
								break;
							} else       
								pagination=true;}
					if(pagination){ 
						NextBttn =  driver.findElement(By.xpath("//a[text()='Next']")).getAttribute("ng-disabled");
					}
					else {
					break;}
					}
				}
				//Pagination-To loop through the pages to search
	}			
			else if(RecordOrGridValueToSelect.equalsIgnoreCase("Open")) {
				RC_Global.waitElementVisible(driver, 30, "(//div[contains(@class,'ui-grid-row')])[1]", "Add RO Line Items Service Code", endRun,false);
				List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("//div[contains(@class,'ui-grid-row')]"));  
				int rowcnt=Getgridrowcnt.size();
				for(int i=1; i<=rowcnt;i++) {
					String sub=driver.findElement(By.xpath("(//div[contains(@class,'ui-grid-row')]//div[text()='"+RecordOrGridValueToSelect+"'])["+i+"]")).getText();
					
					if(!sub.equalsIgnoreCase("ROStatus")) {
						driver.findElement(By.xpath("(//div[contains(@class,'ui-grid-row')]//div[text()='"+RecordOrGridValueToSelect+"'])["+i+"]")).click();
						firstpage = false;
						break;
					}
					firstpage = true;
				}
				//Pagination-To loop through the pages to search 
				if(firstpage) 
				{	
					String NextBttn = driver.findElement(By.xpath("//a[text()='Next']")).getAttribute("ng-disabled");
					while(!NextBttn.equals("ngDisabled")) {
						driver.findElement(By.xpath("//a[text()='Next']")).click();
						Thread.sleep(3000);
						for(int j=1; j<= rowcnt;j++) {
							WebElement sub= driver.findElement(By.xpath("(//div[contains(@class,'ui-grid-row')]//div[text()='"+RecordOrGridValueToSelect+"'])["+j+"]"));
							
							if(!sub.getText().equalsIgnoreCase("ROStatus")) {
								driver.findElement(By.xpath("(//div[contains(@class,'ui-grid-row')]//div[text()='"+RecordOrGridValueToSelect+"'])["+j+"]")).click();
								pagination=false;
								break;
							} else       
								pagination=true;}
					if(pagination){ 
						NextBttn =  driver.findElement(By.xpath("//a[text()='Next']")).getAttribute("ng-disabled");
					}
					else {
					break;}
					}
				}
				//Pagination-To loop through the pages to search
			}	
			queryObjects.logStatus(driver, Status.INFO, "Select Record Or Value from Grid Hyperlink value", "Successful", null);
		}catch (Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Desire RO Record Not Found ", e.getLocalizedMessage(), e);
			if(endRun)
				RC_Global.endTestRun(driver);
		}
		
	}
	
	public static void verifyEntryOfRequiredFieldInForm(WebDriver driver,boolean endRun) throws Exception{
		try {
    	List<WebElement> requiredList = driver.findElements(By.xpath("//div[input[contains(@class,'ng-invalid-required')] or select[contains(@class,'ng-invalid-required')]]"));
    	int noOfRequiredValues = requiredList.size();
    	if(noOfRequiredValues!=0) {
    		queryObjects.logStatus(driver, Status.PASS, "Required Values have not been filled for "+noOfRequiredValues+" fields", "Enter the required values", null);
    	}
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to find required values ----> No Required values found in field", e.getLocalizedMessage(), e);
			if(endRun)
				RC_Global.endTestRun(driver);
		}
    }
	
	public static String createRepairOrderPageOptions(WebDriver driver, String date, String HyperlinkValidation, String HyperlinkFieldsValidation, String AddOrEditROLineItems, String vendorSearchOrCreate,String VendorName,String VendorStoreNumber,String GoogleValidation,boolean vmrs, boolean endRun) throws Exception{
		
		
		WebDriverWait wait = new WebDriverWait(driver,30);
		RC_Global.createNode(driver, "Creating Or Editing Repair Order Number");																  
		String errormsg = "\"Service Date\" should not be grater than Current Date.";
		String RONumber = null;
	    JavascriptExecutor executor = (JavascriptExecutor)driver;
	    try {
	    	try {
	    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h5//span[text()='Create RO']"))); 
	    	}
	    	catch(Exception e) {
	    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h5//span[text()='Edit RO']"))); 
	    	}
	        // Generic RO Details
	        Thread.sleep(2000);
	        RC_Global.clickLink(driver, "Generic RO Details",endRun,false);
	        Thread.sleep(1000);
	        // Vendor Details
	        driver.findElement(By.xpath("//button[@ng-click='vm.searchVendor()']")).click();
	          RC_Global.waitElementVisible(driver, 30, "(//h4[text()='Vendor Search'])[1]", "Vendor Search pop up", endRun,false);
	        if(HyperlinkValidation.equalsIgnoreCase("Vendor Details")) {
	            RC_FleetServices.vendorDetailsFunctionalityValidationInCreateorEditROPage(driver,endRun);
	       	}
	        vendorSearchOrCreateInRepairOrderScreen(driver,vendorSearchOrCreate, VendorName, VendorStoreNumber, GoogleValidation,endRun);
	        VendorNameFromTV = driver.findElement(By.xpath("//input[@name='vendorName']")).getAttribute("value");
	        Thread.sleep(1000);
	        RC_Global.clickLink(driver, "Vendor Details",endRun,false);	
	        // RO Details
	        WebElement serviceDate = null;
	        Thread.sleep(2000);
	        if(driver.findElements(By.xpath("//input[@name='serviceDate']")).size()>0) {
	        	serviceDate = driver.findElement(By.xpath("//input[@name='serviceDate']"));
	        	RC_Global.enterInput(driver, date, serviceDate,endRun,false);
	        }
	        if(HyperlinkFieldsValidation.equalsIgnoreCase("Yes"))
	    	{
	    		String InputFields= "RO Number;Service Date;Input Date;RO Status;Driver Name;Reference RO Number;Driver Code;Receivable Ids";
	    		RC_Global.validateSpecifiedSearchFilters(driver, InputFields,endRun);
	    	}
	    	if(HyperlinkValidation.equalsIgnoreCase("RO_Details_Hyperlink")) {
	         RC_FleetServices.repairOrderDetailsHyperlinkValidationInCreateorEditRoPage(driver, HyperlinkValidation,endRun);
	    	}
	        RC_Global.clickLink(driver, "RO Details",endRun,false);
	        Thread.sleep(500);
	        // Tread Depth
	        if(!driver.findElement(By.xpath("//input[contains(@ng-model,'treadDepthApplicable')]")).isSelected())
                driver.findElement(By.xpath("//input[contains(@ng-model,'treadDepthApplicable')]")).click();  
	        RC_Global.clickLink(driver, "Tread Depth",endRun,false);
	        Thread.sleep(500);
	        // Service Advisor Details
	        if(driver.findElements(By.xpath("//input[contains(@ng-model,'serviceAdvisor.Name')]")).size()>0) {
//                driver.findElement(By.xpath("//input[contains(@ng-model,'serviceAdvisor.Name')]")).sendKeys(RandomStringUtils.randomAlphabetic(4));
	        	WebElement nameElement = driver.findElement(By.xpath("//input[contains(@ng-model,'serviceAdvisor.Name')]"));
	        	RC_Global.enterInput(driver, RandomStringUtils.randomAlphabetic(4), nameElement,endRun,false);
	        }
	        RC_Global.clickLink(driver, "Service Advisor Details",endRun,false);
	        Thread.sleep(500);
	        // ODOMETER READINGS
	        RC_Global.clickLink(driver, "ODOMETER READINGS",endRun,false);
	        Thread.sleep(500);
	        // RO Line Items
	        if(AddOrEditROLineItems.equalsIgnoreCase("")||AddOrEditROLineItems.equalsIgnoreCase("Add")||AddOrEditROLineItems.equalsIgnoreCase("AddAndEdit")) {
	        	RC_Global.clickButton(driver, "Add Line Items",endRun,false);
	  	        RC_Global.waitElementVisible(driver, 30, "//h4[text()='Add Line Items']", "Add Line Items pop up", endRun,false);
	  	        addOrEditRoLineItem(driver,"Add",vmrs, endRun);
	  	        Thread.sleep(2000);
	  	        //RC_Global.clickButton(driver, "Add & Close",endRun);
	  	        driver.findElement(By.xpath("//form[@id='vm.addLineItemForm']//button[text()='Add & Close']")).click();
		        
	        }
	        
	        if(AddOrEditROLineItems.equalsIgnoreCase("Edit")||AddOrEditROLineItems.equalsIgnoreCase("AddAndEdit")) {
	        	RC_Global.clickButton(driver,"Edit",endRun,false);
		        RC_Global.waitElementVisible(driver, 30, "//h4[text()='Edit Line Items']", "Edit Line Items pop up", endRun,false);		       
				addOrEditRoLineItem(driver,"Edit", vmrs, endRun);
		        RC_Global.clickButton(driver,"Update",endRun,false);
	        }
	        RC_Global.clickLink(driver, "RO Line Items",endRun,false);
	        RoCreatedBy = driver.findElement(By.xpath("//input[@name='userFullname']")).getAttribute("value");
	        driver.findElement(By.xpath("(//button[text()='Save'])[1]")).click();
	        Thread.sleep(2000);
	
	        if(driver.findElements(By.xpath("//*[normalize-space(text())='"+errormsg+"']")).size()>0) {
	        	RC_Global.clickButton(driver, "OK",endRun,false);
	        	RC_Global.clickLink(driver, "RO Details",endRun,false);
	        	serviceDate = driver.findElement(By.xpath("//input[@name='serviceDate']"));
	        	String serviceDateInput = RC_Global.getDateTime(driver, "MM/dd/yyyy",0,endRun);
	        	RC_Global.enterInput(driver, serviceDateInput, serviceDate,endRun,false);
	        	driver.findElement(By.xpath("(//button[text()='Save'])[1]")).click();
	        	Thread.sleep(2000);
	        }
	        RC_Global.clickButton(driver, "Yes",endRun,false);
	        wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[text()=' Success! Your information is saved. ']"))));
	    	executor.executeScript("document.body.style.zoom = '30%'");
			executor.executeScript("document.body.style.zoom = '100%'");
			Thread.sleep(2000);
	        RONumber = driver.findElement(By.xpath("//label[text()='RO Number:']/following::div[1]")).getText();
	        Thread.sleep(1000);
	        if(!RONumber.isEmpty()) {
				queryObjects.logStatus(driver, Status.PASS, "Repair Order Created", "Successfully", null);
	        }
	        else
				queryObjects.logStatus(driver, Status.FAIL, "Repair Order Creation", "Failed", null);
        }
	    catch(TimeoutException te) {
            queryObjects.logStatus(driver, Status.FAIL, "Failed to Create Repair Order -> Unable to load the current/previous screen", te.getLocalizedMessage(), te);
        	if(endRun)
				RC_Global.endTestRun(driver);
            
	    }//Nosuch
	    catch (Exception e) {
	        queryObjects.logStatus(driver, Status.FAIL, "Failed to Create Repair Orde", e.getLocalizedMessage(), e);
	    	if(endRun)
				RC_Global.endTestRun(driver);
	        
        }
	    return RONumber;
	}
 
	private static void vendorDetailsFunctionalityValidationInCreateorEditROPage(WebDriver driver,boolean endRun) throws Exception {
		try {
		//Radio Button Validation on Vendor Search
		List<WebElement> radioButton1 =driver.findElements(By.xpath("//input[@value='gpsearch']"));
		List<WebElement> radioButton2 =driver.findElements(By.xpath("//input[@value='lwsearch']"));
		if(radioButton1.size()>0 && radioButton2.size()>0)
			queryObjects.logStatus(driver, Status.INFO, "Vendor Detail Search and Vendor Search (LeaseWave) Radio Buttons are present in", "Vendor Search Page", null);
		//Filters Name Validation On Vendor Search
		String InputFields= "Enter an Address, Zip Code, City, State to find a Vendor Near You;Within X Miles;Vendor Name;Vendor Phone Number;Vendor Code;Services Offered;Vehicles Serviced;Vehicles Serviced";
 		RC_Global.validateSpecifiedSearchFilters(driver, InputFields,endRun); 
 		
 		//Check Box Validation On Vendor Search
 		List<WebElement> CheckBox1 =driver.findElements(By.xpath("//input[@ng-model='vm.nationalAccountOnly']"));
		List<WebElement> CheckBox2 =driver.findElements(By.xpath("//input[@ng-model='vm.preferredVendors']"));
		if(CheckBox1.size()>0 && CheckBox2.size()>0)
			queryObjects.logStatus(driver, Status.INFO, "National Accounts and Preferred Vendors Check Box are present in", "Vendor Search Page", null);
		
 	    //Vendor Search Buttons Validation
 		RC_Global.buttonStatusValidation(driver, "Search", "Enable",endRun);
		RC_Global.buttonStatusValidation(driver, "Reset", "Enable",endRun);
		RC_Global.buttonStatusValidation(driver, "Create Vendor", "Enable",endRun);
		RC_Global.buttonStatusValidation(driver, "Close", "Enable",endRun);
		Thread.sleep(1000);
		 List<WebElement> IconElement = driver.findElements(By.xpath("(//i[@ng-click='closeModal()'])[1]"));
			if(IconElement.size()>0) 
				queryObjects.logStatus(driver,Status.PASS,""+IconElement+" Icon is", "displayed", null);
			else
				queryObjects.logStatus(driver,Status.FAIL,""+IconElement+" Icon is", "Notdisplayed", null);
		 Thread.sleep(1000);
		 VendorNearYou ="Chicago, Illinois";
		 WebElement Vendor =driver.findElement(By.xpath("//input[contains(@placeholder,'Vendor Near You')]"));
		 Vendor.sendKeys(VendorNearYou);
		 Thread.sleep(2000);
		 Vendor.sendKeys(Keys.ENTER);
		 if(!(driver.findElements(By.xpath("//select[@disabled='disabled' and @name='withinXMiles']")).size()>0)) 
			 queryObjects.logStatus(driver,Status.PASS,"WithinXmiles is Enables", "After Entering Vendor Name", null);
		 Thread.sleep(1000);
		
		}catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver, Status.FAIL, "Validation of Vedor Search Page Failed ---> Required fields are not available to perform any action at the moment", nse.getLocalizedMessage(), nse);
			if(endRun)
				RC_Global.endTestRun(driver);
		}catch (Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Validation of Vedor Search Page Failed", e.getLocalizedMessage(), e);
			if(endRun)
				RC_Global.endTestRun(driver);
		}
		
	}
	
	public static void repairOrderDetailsHyperlinkValidationInCreateorEditRoPage(WebDriver driver, String hyperlinkValidation,boolean endRun) throws Exception {
		
		try {
			     String SearchFilters ="Customer Number;Unit Number;CVN;Full VIN or Last 8;RO Number;RO Status;RO Created By;Plate Number;Driver Last Name;Driver First Name;Driver Phone Number;Plate State;Vendor WorkOrder Number";
		    	 driver.findElement(By.xpath("//input[@name='isOverrideRepairOrderStatusCalculation']")).click();
		    	 Thread.sleep(1000);
		    	 //Ro_Status dropdown Validation
		    	 String DropDownValues ="Open;Pending Customer Approval;Pending Invoice;Disputed;Declined;Deleted";
		    	 RC_Global.dropdownValuesValidation(driver, DropDownValues,"//select[@name='roStatus']",endRun,false);
		    	 driver.findElement(By.xpath("//input[@name='isOverrideRepairOrderStatusCalculation']")).click();
		    	 Thread.sleep(1000);
		    	 //Reference RO Assignment and new Popup Validation
		    	 driver.findElement(By.xpath("//button[@ng-click='vm.searchReferenceRONumber()']")).click();
		     	 RC_Global.waitElementVisible(driver, 30, "(//form[@name='mroSearchForm'])[1]", "Reference RO Number Search form", endRun,false);
		         RC_Global.buttonStatusValidation(driver, "Search", "Enable",endRun);
				 RC_Global.buttonStatusValidation(driver, "Reset", "Enable",endRun);
				 Thread.sleep(2000);
				 RC_Global.buttonStatusValidation(driver, "Close", "Enable",endRun);
				 RC_Global.buttonStatusValidation(driver, "Select", "Disable",endRun);
				 Thread.sleep(1000);
				 List<WebElement> IconElement = driver.findElements(By.xpath("(//i[@ng-click='closeModal()'])[1]"));
					if(IconElement.size()>0) 
						queryObjects.logStatus(driver,Status.PASS,""+IconElement+" Icon is", "displayed", null);
					else
						queryObjects.logStatus(driver,Status.FAIL,""+IconElement+" Icon is", "Notdisplayed", null);
					
				 RC_Global.validateSpecifiedSearchFilters(driver, SearchFilters,endRun);
				 RC_Global.clickButton(driver, "Search",endRun,false);
		     	 RC_Global.waitElementVisible(driver, 30, "(//div[@ng-style='Viewport.rowStyle(rowRenderIndex)'])[1]", "First Record of grid for Reference RO Number", endRun,false);
		       	 Thread.sleep(2000);
		     	 List<WebElement> ReferenceRoSelection = driver.findElements(By.xpath("//div[@ng-style='Viewport.rowStyle(rowRenderIndex)']"));
		     	 Thread.sleep(3000);
		     	 ROReferenceNum = driver.findElement(By.xpath("(//div[@ng-show='grid.appScope.vm.isReferenceRoSearch'])[1]")).getText();
		     	 //ReferenceRoSelection.get(0).click();
		         driver.findElement(By.xpath("(//div[@ng-style='Viewport.rowStyle(rowRenderIndex)'])[1]")).click();
				 RC_Global.clickButton(driver, "Select",endRun,false);
				 
				 queryObjects.logStatus(driver, Status.PASS, "RO_Details Hyperlink Functionality Validation", "RO_Details Hyperlink Functionality Validation Successful", null);
	 
		  }catch(TimeoutException te) {
				queryObjects.logStatus(driver, Status.FAIL, "Navigate to the required screen failed -> Unable to load the current/previous screen", te.getLocalizedMessage(), te);
				if(endRun)
					RC_Global.endTestRun(driver);
		  }
		  catch(NoSuchElementException nse) {
				queryObjects.logStatus(driver, Status.FAIL, "RO_Details Hyperlink Functionality Validation failed ---> Required fields are not available to perform any action at the moment", nse.getLocalizedMessage(), nse);
				if(endRun)
					RC_Global.endTestRun(driver);
		  }
		  catch (Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "RO_Details Hyperlink Functionality Validation failed", e.getLocalizedMessage(), e);
			if(endRun)
				RC_Global.endTestRun(driver);
			
		  }
	}
	
	public static void verifyDriverSelection(WebDriver driver,int ColumnNum, String Header,boolean endRun) throws Exception {//VerifyDriverSelection
		RC_Global.createNode(driver, "Update Driver for Existing Or Unassigned driver");
		try {
			driver.findElement(By.xpath("//button[@id='driverSearch']")).click();
			RC_Global.waitElementVisible(driver, 30, "//div[1]/div/div/div/div[1]/h3[text()='"+Header+"']", "Driver pop-up title", endRun,false);
			driver.findElement(By.xpath("//button[@id='driver-change-search']")).click();
			RC_Global.waitElementVisible(driver, 30, "//tbody/tr", "Driver Change Search grid", endRun,false);
			if(driver.findElements(By.xpath("//tbody/tr[" + ColumnNum + "]")).size() > 0) {
				driver.findElement(By.xpath("//tbody/tr[" + ColumnNum + "]")).click();      // update driver
				RC_Global.waitElementVisible(driver, 30, "//section/div[1]/div[7]/div/div[1]/div", "Update Driver Screen", endRun,false);
			}
		 driver.findElement(By.xpath("//div[5]/div/div/div/div[2]/button[1]")).click();//save button
		 Thread.sleep(3000);
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "Navigate to the required screen failed -> Unable to load the current/previous screen", te.getLocalizedMessage(), te);
			if(endRun)
				RC_Global.endTestRun(driver);
		}
		catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver, Status.FAIL, "Driver selection for update is failed ---> Required fields are not available to perform any action at the moment", nse.getLocalizedMessage(), nse);
			if(endRun)
				RC_Global.endTestRun(driver);
		}
		catch (Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Driver selection for update is failed", e.getLocalizedMessage(), e);
			if(endRun)
				RC_Global.endTestRun(driver);
		}
	}	
	
	public static void createOrEditRepairOrderPageInputsValidation(WebDriver driver,boolean endRun) throws Exception {//RODetailsValidation
		  RC_Global.createNode(driver, " Create/Edit Repair Order Fields Validation");
		  
		  try {
	    	RC_Global.waitElementVisible(driver, 30, "//h5//span[text()='Edit RO']", "Edit RO Screen", endRun,false);
	    	driver.findElement(By.xpath("//button[(text()='Collapse All')and(@ng-disabled='!vm.allowCollapseExpand()')]")).click();
	    	Thread.sleep(1000);
	    	String ROCreationDate = driver.findElement(By.xpath("//input[@ng-model='vm.vehicle_ro_information.PostDate']")).getAttribute("value");
	    	String Date = (new SimpleDateFormat("MM/dd/yyyy")).format(new Date());
	    	//Ro Creation Date
	    	if(ROCreationDate.equalsIgnoreCase(Date))
	            queryObjects.logStatus(driver, Status.PASS, "Reference Ro Creation date displayed","Correctly", null);
	    	else 
	            queryObjects.logStatus(driver, Status.FAIL, "Reference Ro Creation date  displayed","is not correct" ,null);

	    	RC_Global.clickLink(driver, "RO Details",endRun,false);
	    	Thread.sleep(1000);
	    	String RORef = driver.findElement(By.xpath("//input[@name='referenceRONumber']")).getAttribute("value");
	    	//Reference RO Number validation
	    	if(RORef.equalsIgnoreCase(ROReferenceNum))
	            queryObjects.logStatus(driver, Status.PASS, "Reference Ro displayed","Correctly", null);
	    	else 
	            queryObjects.logStatus(driver, Status.FAIL, "Reference Ro displayed","is not correct" ,null);
	    	RC_Global.clickLink(driver, "RO Details",endRun,false);
	    	Thread.sleep(1000);
	    	
	    	RoCreatedBy = driver.findElement(By.xpath("//input[@name='userFullname']")).getAttribute("value");
	    	/*if(Cred.UserName.contains(RoCreatedBy))
	            queryObjects.logStatus(driver, Status.PASS, "RO created by displaying","Correctly", null);
	    	else 
	            queryObjects.logStatus(driver, Status.FAIL, "RO created by displaying","is not correct" ,null);*/
	    	RC_Global.clickLink(driver, "User Information",endRun,false);
	    	Thread.sleep(1000);
	    	
	    	RC_Global.clickLink(driver, "Generic RO Details",endRun,false);
	    	Thread.sleep(1000);
	    	GLtemplatefromTV = driver.findElement(By.xpath("//select[@name='glTemplates']/option[@selected='selected']")).getAttribute("value");
			Thread.sleep(1000);
			BillproductfromTV = driver.findElement(By.xpath("//select[@name='billBackProducts']/option[@selected='selected']")).getAttribute("value");
			Thread.sleep(1000);
			BillinvoicefromTV = driver.findElement(By.xpath("//select[@name='billBackInvoiceGroups']/option[@selected='selected']")).getAttribute("value");
			Thread.sleep(1000);
	    	RC_Global.clickLink(driver, "Generic RO Details",endRun,false);
	    	Thread.sleep(1000);
            queryObjects.logStatus(driver, Status.PASS, "Repair Order Edit/Create page validation","Repair Order Edit/Create page validation Successfull" , null);
	    	
		  }
		  catch(NoSuchElementException nse) {
				queryObjects.logStatus(driver, Status.FAIL, "Repair Order Edit/Create page validation ---> Required fields are not available to perform any action at the moment", nse.getLocalizedMessage(), nse);
				if(endRun)
					RC_Global.endTestRun(driver);
		  }
		  catch(TimeoutException te) {
				queryObjects.logStatus(driver, Status.FAIL, "Navigate to the required screen failed -> Unable to load the current/previous screen", te.getLocalizedMessage(), te);
				if(endRun)
					RC_Global.endTestRun(driver);    
		  }
		  catch(Exception e) {
	            queryObjects.logStatus(driver, Status.FAIL, "Repair Order Edit/Create page validation Failed",e.getLocalizedMessage() , e);
	            if(endRun)
					RC_Global.endTestRun(driver);     
		  }
	}

	public static void checkBoxValidation(WebDriver driver,String CheckboxLabel,boolean endRun) throws Exception{
	  try {
        WebElement checkbox = driver.findElement(By.xpath("//label[text()='"+CheckboxLabel+"']"));
        boolean isSelected = checkbox.isSelected();
        if(!isSelected)
        queryObjects.logStatus(driver, Status.PASS,"The checkbox selection state is - " + checkbox.isSelected(), null, null);
        else if (checkbox.isSelected())
        queryObjects.logStatus(driver, Status.FAIL,"The checkbox not selection state is - " + checkbox.isSelected(), null, null);
	  }
	  catch(Exception e) {
          queryObjects.logStatus(driver, Status.FAIL, "Unable to validate the checkbox----> The checkbox selection state is not found",e.getLocalizedMessage() , e);
          if(endRun)
				RC_Global.endTestRun(driver);     
	  }
    }

	private static void vendorSearchOrCreateInRepairOrderScreen(WebDriver driver,String vendorSearchOrCreate,String VendorName,String VendorStoreNumber,String GoogleValidation,boolean endRun) throws Exception
	{
		
		try {
		switch(vendorSearchOrCreate)
        {
        case "Search":
        	RC_Global.clickButton(driver, "Search",endRun,false);
        	RC_Global.waitElementVisible(driver, 30, "(//div[@role='rowgroup'])[2]/div/div[1]", "First Record of Vendor Search Result grid", endRun,false);
        	if(GoogleValidation.equalsIgnoreCase("Yes")) {
        	RC_Global.googleRoutePageValidation(driver, VendorNearYou,endRun);
    		Thread.sleep(2000);}
    		if(driver.findElements(By.xpath("//button[text()='Select Vendor' and @disabled='disabled']")).size()>0) {
    		driver.findElement(By.xpath("(//div[@role='rowgroup'])[2]/div/div[1]")).click();}
        	RC_Global.clickButton(driver,"Select Vendor",endRun,false);
	        queryObjects.logStatus(driver, Status.PASS,"Vendor Search in Create/Edit RO Page","Vendor Search in Create/Edit RO Page Successful", null);
        break;
        case "Create":
        	RC_Global.clickButton(driver, "Create Vendor",endRun,false);
        	RC_Global.waitElementVisible(driver, 30, "//h3[text()='Create Vendor']", "Create Vendor pop up", endRun,false);
        	
        	driver.findElement(By.xpath("//div//input[contains(@name,'vendorName')]")).sendKeys(VendorName);
        	driver.findElement(By.xpath("//div//input[contains(@name,'vendorStoreNumber')]")).sendKeys(VendorStoreNumber);
			WebDriverWait wait = new WebDriverWait(driver, 30);												
        	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[text()='Save'])")));
        	driver.findElement(By.xpath("(//button[text()='Save'])")).click();
	        queryObjects.logStatus(driver, Status.PASS,"Create Vendor in Create/Edit RO Page","Create Vendor in Create/Edit RO Page Successful", null);
        	break;
        	
        }}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "Navigate to the required screen failed -> Unable to load the current/previous screen", te.getLocalizedMessage(), te);
			if(endRun)
				RC_Global.endTestRun(driver);
		}
		catch (Exception e) {
	        queryObjects.logStatus(driver, Status.FAIL,"Create/Search Vendor in Create/Edit RO Page Failed",e.getLocalizedMessage(), e);
	        if(endRun)
				RC_Global.endTestRun(driver);  
		}			 
	}
 
	private static void addOrEditRoLineItem(WebDriver driver, String addOrEdit, boolean vmrs,boolean endRun) throws Exception{
		
		try {																																																	   
	        driver.findElement(By.xpath("//input[contains(@ng-click,'showVmrsGrid')]")).click();
	        Thread.sleep(2000);
	        String[] radiobtnvalue = new String[2];
			int i=0;
			if(driver.findElements(By.xpath("//label/input[@type='radio']")).size()==2) {
				List<WebElement>radiolist = driver.findElements(By.xpath("//label/input[@type='radio']"));
				for(WebElement rl:radiolist) {
					radiobtnvalue[i] = rl.getText();
					i++;
				}
		       	queryObjects.logStatus(driver, Status.INFO, "Validating the presence of Radio Buttons", "There are 2 radio buttons present on the RO Line Items: "+radiobtnvalue[0]+", "+radiobtnvalue[1], null);
			}
	        if(addOrEdit.equalsIgnoreCase("Add")) {
		        RC_Global.waitElementVisible(driver, 30, "(//div[contains(@ng-style,'Viewport')])[2]", "Add Line Items Service Code", endRun,false);
		        Thread.sleep(2000);
		        driver.findElement(By.xpath("(//div[contains(@ng-style,'Viewport')])[2]")).click();
	        }     
	        RC_Manage.waitUntilMethods(driver, "//select[@name='status']","value","", "attribute available");
			driver.findElement(By.xpath("//label[text()='Total Line Item ']/following::input[@ng-model='input.val'][1]")).clear();
            WebElement partsCost = driver.findElement(By.xpath("//label[text()='Parts Cost']/following::input[1]"));
            WebElement laborCost = driver.findElement(By.xpath("//label[text()='Labor Cost']/following::input[1]"));
            WebElement laborHours = driver.findElement(By.xpath("//label[text()='Labor Hours']/following::input[1]"));
            WebElement partsQuantity = driver.findElement(By.xpath("//label[text()='Parts Quantity ']/following::input[1]"));
            String sPartsCost = RandomStringUtils.randomNumeric(1);
            String sLaborCost = RandomStringUtils.randomNumeric(1);
            String sPartsQuantity = RandomStringUtils.randomNumeric(1);
            String sLaborHours = RandomStringUtils.randomNumeric(1);
            if(sPartsCost.equalsIgnoreCase("0"))
                sPartsCost="1";
            if(sLaborCost.equalsIgnoreCase("0"))
                sLaborCost="1";
            if(sPartsQuantity.equalsIgnoreCase("0"))
                sPartsQuantity="1";
            if(sLaborHours.equalsIgnoreCase("0"))
                sLaborHours="1";
           
            RC_Global.enterInput(driver,sPartsCost, partsCost, endRun,false);
            RC_Global.enterInput(driver,sPartsQuantity, partsQuantity, endRun,false);
            
            if(vmrs) {
            	RC_Global.enterInput(driver,sLaborCost, laborCost, endRun,false);
            	RC_Global.enterInput(driver,sLaborHours, laborHours, endRun,false);
                
	            double lineItemRequestedAmount = (Double.parseDouble(sPartsCost)*Double.parseDouble(sPartsQuantity))+(Double.parseDouble(sLaborHours)*Double.parseDouble(sLaborCost));
	                 
	            //float f = 4.21777 * 100;
//	            int solution = (int)f;
//	            f = solution/100;

	            double totalLineItemCost=lineItemRequestedAmount*100/Double.parseDouble(sPartsQuantity);
	            int dTotalLineItemCost = (int) totalLineItemCost;
	            totalLineItemCost = (double)dTotalLineItemCost/100;
//	            System.out.format("double : %.2f", input); // 3.14
	            if(driver.findElement(By.xpath("//label[text()='Total Line Item ']/following::input[1]")).getAttribute("value").contains(Double.toString(totalLineItemCost)))
	                queryObjects.logStatus(driver, Status.PASS, "Verifying 'Total Line Items Cost' value: "+totalLineItemCost, "Successful", null);
	            else
	                queryObjects.logStatus(driver, Status.FAIL, "Verifying 'Total Line Items Cost' value: "+totalLineItemCost, "Actual value differs from Expected value", null);
	            
	            if(driver.findElement(By.xpath("//span[text()='Requested Amount']/following::input[1]")).getAttribute("value").contains(Double.toString(lineItemRequestedAmount)))
	                queryObjects.logStatus(driver, Status.PASS, "Verifying 'Line Item Requested Amount' value: "+lineItemRequestedAmount, "Successful", null);
	            else
	                queryObjects.logStatus(driver, Status.FAIL, "Verifying 'Line Item Requested Amount' value: "+lineItemRequestedAmount, "Actual value differs from Expected value", null);
            }
            Thread.sleep(500);
            
            
	}	catch(TimeoutException te) {
		queryObjects.logStatus(driver, Status.FAIL, "Navigate to the required screen failed -> Unable to load the current/previous screen", te.getLocalizedMessage(), te);
		 if(endRun)
				RC_Global.endTestRun(driver);
	}
		catch (Exception e) {
        queryObjects.logStatus(driver, Status.FAIL,"Create/Search Vendor in Create/Edit RO Page Failed",e.getLocalizedMessage(), e);
        if(endRun)
			RC_Global.endTestRun(driver);
	}
	}
	
	public static void enterSubmitMileageFormInputs(WebDriver driver, String StartDate, String EndDate, String StartingOdometer, String EndingOdometer, String PersonalMiles,boolean endRun) throws Exception {
		RC_Global.createNode(driver, "Submit Mileage Form");
		try {
		WebElement wStartDate = RC_Global.accessInputBoxViaLabel(driver,"Start Date *",endRun);
		WebElement wEndDate = RC_Global.accessInputBoxViaLabel(driver,"End Date *",endRun);
		WebElement wStartingOdometer = RC_Global.accessInputBoxViaLabel(driver,"Starting Odometer *",endRun);
		WebElement wEndingOdometer =  RC_Global.accessInputBoxViaLabel(driver,"Ending Odometer *",endRun);
		WebElement wPersonalMiles = RC_Global.accessInputBoxViaLabel(driver,"Personal Miles *",endRun);
		
		RC_Global.enterInput(driver, StartDate, wStartDate,endRun,false);
		RC_Global.enterInput(driver, EndDate, wEndDate,endRun,false);
		Thread.sleep(1000);
		RC_Global.enterInput(driver, StartingOdometer, wStartingOdometer,endRun,false);
		RC_Global.enterInput(driver, EndingOdometer, wEndingOdometer,endRun,false);
		Thread.sleep(1000);
		RC_Global.enterInput(driver, PersonalMiles, wPersonalMiles,endRun,false);
		Thread.sleep(1000);
        queryObjects.logStatus(driver, Status.PASS,"Entering Submit Mileage Form Inputs","Enter Submit Mileage Form Inputs Successfull", null);
		}
		catch (Exception e) {
	    queryObjects.logStatus(driver, Status.FAIL,"Entering Submit Mileage Form Inputs Failed",e.getLocalizedMessage(), e);
	    if(endRun)
			RC_Global.endTestRun(driver);
		}
		
	}

	public static String[] getPersonalUseMissingMileageStartAndEndDates(WebDriver driver,boolean endRun) throws Exception {
		RC_Global.createNode(driver, "PersonalUse Missing Mileage Start And End Date Retrive");
		String[] startEndDate = {"",""};	 
		try {
			String dateDuration = "";
			if(driver.findElements(By.xpath("//div[strong[text()='Missing Mileage Submissions: ']]/following-sibling::div//span")).size()>0) {
				dateDuration = driver.findElement(By.xpath("//div[strong[text()='Missing Mileage Submissions: ']]/following-sibling::div//span")).getText();
				startEndDate = dateDuration.split(" - ");
				String stringDate=startEndDate[0];  
				if(stringDate.equalsIgnoreCase(RC_Global.getDateTime(driver, "MM/dd/yyyy", 0, endRun))){         
					queryObjects.logStatus(driver, Status.WARNING, "Setting Mileage Start and End Date failed", "No remaining missing mileage dates", null);
					RC_Global.endTestRun(driver);
				}
				Date date1=new SimpleDateFormat("MM/dd/yyyy").parse(stringDate);  
				Calendar cal = Calendar.getInstance();
				cal.setTime(date1);
				    
				cal.add(Calendar.DATE, 0); 
				Date sDate = cal.getTime();
				
				SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
				startEndDate[0] = sdf.format(sDate);
				
				Date date2=new SimpleDateFormat("MM/dd/yyyy").parse(stringDate);  
				Calendar cal1 = Calendar.getInstance();
				cal1.setTime(date2);
				    
				cal1.add(Calendar.DATE, 1); 
				Date sDate2 = cal.getTime();
				
				SimpleDateFormat sdf2 = new SimpleDateFormat("MM/dd/yyyy");
				startEndDate[1] = sdf2.format(sDate2);
			}
			else {
				startEndDate[0] = RC_Global.accessInputBoxViaLabel(driver,"Start Date *",endRun).getAttribute("value");
				startEndDate[1] = RC_Global.getDateTime(driver,"MM/dd/yyyy", 0,endRun);
				String stringDate=startEndDate[0];  
				if(stringDate.equalsIgnoreCase(RC_Global.getDateTime(driver, "MM/dd/yyyy", 0, endRun))){         
					queryObjects.logStatus(driver, Status.WARNING, "Setting Mileage Start and End Date failed", "No remaining missing mileage dates", null);
					RC_Global.endTestRun(driver);
				}
				Date date1=new SimpleDateFormat("MM/dd/yyyy").parse(stringDate);  
				Calendar cal = Calendar.getInstance();
				cal.setTime(date1);
				    
				cal.add(Calendar.DATE, 0); 
				Date sDate = cal.getTime();
				
				SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
				startEndDate[0] = sdf.format(sDate);
				
				Date date2=new SimpleDateFormat("MM/dd/yyyy").parse(stringDate);  
				Calendar cal1 = Calendar.getInstance();
				cal1.setTime(date2);
				    
				cal1.add(Calendar.DATE,1); 
				Date sDate2 = cal.getTime();
				
				SimpleDateFormat sdf2 = new SimpleDateFormat("MM/dd/yyyy");
				startEndDate[1] = sdf2.format(sDate2);
				
			}
		queryObjects.logStatus(driver, Status.PASS, "Start and End Dates for mileage submission retrieved", "Start and End Dates for mileage submission retrieved sucessfully", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Start and End Dates could not be retrieved/ No mileage dates are available", e.getLocalizedMessage(), e);
			if(endRun)
				RC_Global.endTestRun(driver);
		}
		return startEndDate;
		
	}
	
	public static String[] personalUseStartAndEndDate(WebDriver driver, boolean endRun) throws Exception {
		RC_Global.createNode(driver, "Get personaluse start and end date for mileage submission");
		Thread.sleep(2000);
		List<String> startDate = new ArrayList<String>();
		List<String> endDate = new ArrayList<String>();
		List<Date> startDates = new ArrayList<Date>();
		List<Date> endDates = new ArrayList<Date>();
		String[] startEndDate = new String[2];
		String fStartDate = new String();
		String fEndDate = new String();
		if(driver.findElements(By.xpath("//table//tr/td[2]")).size()==0) {
			fStartDate = RC_Global.getDateTime(driver, "MM/dd/yyyy", -10, endRun);
			fEndDate = RC_Global.getDateTime(driver, "MM/dd/yyyy", -9, endRun);
		}
		else {
			List<WebElement> submittedMileageDates = driver.findElements(By.xpath("//table//tr/td[2]"));
	
			// SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			String[] startEnd = new String[2];
			int iter = 0;
			int dateItr= -10;
			
			for(WebElement smd: submittedMileageDates) {
				startEnd = smd.getText().split(" - ");
				startDate.add(startEnd[0]);
				endDate.add(startEnd[1]);
				startDates.add(sdf.parse(startDate.get(iter)));
				endDates.add(sdf.parse(endDate.get(iter)));
				
				iter++;
			}
			
			
			while(!RC_Global.getDateTime(driver, "MM/dd/yyyy", dateItr, endRun).equalsIgnoreCase(RC_Global.getDateTime(driver, "MM/dd/yyyy", 0, endRun))){
				iter =0;
				boolean flag = false;
				for(Date sd:startDates) {
					String date = RC_Global.getDateTime(driver, "MM/dd/yyyy", dateItr, endRun);
					Date testDate = sdf.parse(date);
					Date testDateEnd = sdf.parse(RC_Global.getDateTime(driver, "MM/dd/yyyy", dateItr+1, endRun));
					if(!RC_Global.isWithinRange(testDate, sd, endDates.get(iter))) {
						fStartDate = date;
						if(!RC_Global.isWithinRange(testDateEnd, sd, endDates.get(iter))||flag==true)
								fEndDate = RC_Global.getDateTime(driver, "MM/dd/yyyy", dateItr+1, endRun);
								
						else {
							fEndDate = date;
							flag=true;
						}
					}
					else {
						dateItr++;
						break;
					}
				iter++;
				
				}
				if(iter==startDates.size())
					break;
				
			}
			
			for(Date sd:startDates) {
				if(RC_Global.getDateTime(driver, "MM/dd/yyyy", dateItr, endRun).equalsIgnoreCase(RC_Global.getDateTime(driver, "MM/dd/yyyy", 0, endRun))) {
					if(!RC_Global.isWithinRange(sdf.parse(RC_Global.getDateTime(driver, "MM/dd/yyyy", 0, endRun)), startDates.get(iter), endDates.get(iter))) {
						fStartDate = RC_Global.getDateTime(driver, "MM/dd/yyyy", 0, endRun);
						fEndDate = RC_Global.getDateTime(driver, "MM/dd/yyyy", 0, endRun);
					}
				}
				else if(RC_Global.getDateTime(driver, "MM/dd/yyyy", dateItr, endRun).equalsIgnoreCase(RC_Global.getDateTime(driver, "MM/dd/yyyy", 1, endRun))) {
					queryObjects.logStatus(driver, Status.FAIL, "Personal Use Submission Dates", "Start Date and End Date cannot be for future dates - All the other dates already have submitted mileage", null);
					RC_Global.endTestRun(driver);
				}
			}
		}
		startEndDate [0] = fStartDate;
		startEndDate [1] = fEndDate;
		queryObjects.logStatus(driver, Status.PASS, "Personal Use Submission Dates", "Start Date: "+startEndDate[0]+" End Date: "+startEndDate[1], null);
		return startEndDate;
	}
	public static void verifyMileageSubmission(WebDriver driver, String ColumnName, String EnteredMileageValue,boolean endRun) throws Exception {
	RC_Global.createNode(driver, "Mileage Submission Verification");
	try {
		int columnNumber = RC_Global.findColumnNumber(driver, ColumnName,endRun);
		String milesValue = driver.findElement(By.xpath("//tr[1]/td["+columnNumber+"]")).getText();
		if(milesValue.equalsIgnoreCase(EnteredMileageValue)) 
			queryObjects.logStatus(driver, Status.PASS, "Mileage Submission Validation", "Mileage Submission Successful", null);
	}
	catch(Exception e) {
		queryObjects.logStatus(driver, Status.FAIL, "Unable to find the mileage submission", e.getLocalizedMessage(), e);
		if(endRun)
			RC_Global.endTestRun(driver);
	}
	}
	
	
	public static void multiSelectDropDown(WebDriver driver, boolean endRun) throws Exception {
		RC_Global.createNode(driver, "Multiple Option Selection from dropdown");
		try {
		WebElement element2 = driver.findElement(By.name("vehicleStatus"));
		Select sl = new Select(element2);
		List<WebElement> vehstatus = sl.getAllSelectedOptions();
		for (WebElement webElement : vehstatus) {
			queryObjects.logStatus(driver, Status.PASS, "PreSelected Vehicle status "+webElement.getText()+" is ", "displayed", null);
		}
		List<WebElement> allvehstatus = sl.getOptions();
		for (WebElement webElement : allvehstatus) {									
			queryObjects.logStatus(driver, Status.PASS, "List of Vehicle status "+webElement.getText()+" is ", "displayed", null);
		}
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to validate multi select dropdown values status -> The vehicle status selection is not found", e.getLocalizedMessage(), e);
			if(endRun)
				RC_Global.endTestRun(driver);
		}
	}
	
	public static void addEmployeeFromPool(WebDriver driver,boolean endRun) throws Exception{
	RC_Global.createNode(driver,"Add Employee From Fuel PIN Pool");
	
	try{
        JavascriptExecutor executor = (JavascriptExecutor)driver;
        executor.executeScript("document.body.style.zoom = '80%'");
        Thread.sleep(1000);
        executor.executeScript("document.body.style.zoom = '100%'");
        RC_Global.clickButton(driver, "Add Employee",endRun,false);
        RC_Global.clickButton(driver, "Search",endRun,false);
        RC_Global.waitElementVisible(driver, 30, "(//div[form]/div[1]//tbody//tr)[2]", "Second Record from 'Select Employees to Add to Pool' grid", endRun,false);
        List<WebElement> checkbox = driver.findElements(By.xpath("//div[form]/div[1]//tbody//tr//td[1]//input"));
        for(WebElement cb:checkbox) {
               if(!cb.isSelected())
               {
                     cb.click();
               break;
               }
        }
        RC_Global.clickButton(driver, "Add Employees",endRun,false);
        executor.executeScript("document.body.style.zoom = '80%'");
        Thread.sleep(1000);
        executor.executeScript("document.body.style.zoom = '100%'");
        RC_Global.clickUsingXpath(driver, "//div[@is-active='isEmployeesPinPoolTabActive']//button[normalize-space(text())='Save']","Save", endRun,false);
        executor.executeScript("document.body.style.zoom = '30%'");
        Thread.sleep(1000);
		executor.executeScript("document.body.style.zoom = '100%'");
		
		Thread.sleep(1000);
		RC_Global.verifyDisplayedMessage(driver, "Save Successfull",endRun);
        queryObjects.logStatus(driver, Status.PASS, "Adding Employee to the Pool", "Employee added to the Pool Successful", null);
       
	}catch (Exception e) {
               queryObjects.logStatus(driver, Status.FAIL, "Adding Employee to the Pool Failed", e.getLocalizedMessage(), e);
               if(endRun)
   				RC_Global.endTestRun(driver);    
	}
	}
	
	public static void resultBasedOnToggleOption (WebDriver driver,String TogglebuttonName, String ColumnNames,boolean endRun) throws Exception{
	RC_Global.createNode(driver, "Column Names Validation Based on "+TogglebuttonName+" Button search result");
	try {
			String[] ColumnName = ColumnNames.split(";");
			int ColumnNumber = RC_Global.findColumnNumber(driver,ColumnName[0],endRun);
			boolean Flag= false;
			for(int i=0; i< ColumnName.length; i++) {
			
			Thread.sleep(500);
			String Columnname = driver.findElement(By.xpath("(//th/div/span[1])["+ColumnNumber+"]")).getText();
			if(Columnname.equalsIgnoreCase(ColumnName[i])) {
				Flag= true;
				Thread.sleep(100);
			}
			ColumnNumber++;
			}
			if(Flag)
			queryObjects.logStatus(driver, Status.PASS, "Columnnames are displayed Correctly with the toggle option", "", null);
			else
			queryObjects.logStatus(driver, Status.FAIL, "Columnnames are not displayed Correctly with the toggle option", "", null);
	}
	catch(NoSuchElementException nse) {
		queryObjects.logStatus(driver, Status.FAIL, "Failed to verify all column names -> Unable to find the element on the screen", nse.getLocalizedMessage(), nse);
		if(endRun)
			RC_Global.endTestRun(driver);
	}
	catch(TimeoutException te) {
		queryObjects.logStatus(driver, Status.FAIL, "Failed to verify all column names -> The grid/column names of the grid not loaded completely on the screen", te.getLocalizedMessage(), te);
		if(endRun)
			RC_Global.endTestRun(driver);
	}
	catch (Exception e) {
        queryObjects.logStatus(driver, Status.FAIL, "Column validation failed -> Columnnames are not displayed correctly", e.getLocalizedMessage(), e);
        if(endRun)
			RC_Global.endTestRun(driver);    
		}
	
	}
	
		
	public static void driverSelection(WebDriver driver, String applyAddressToVehicle,boolean endRun) throws Exception{
        RC_Global.createNode(driver, "Driver Selection");
        String CustomerName="";
        String DriverNameChange="";
        String message = "Changing states requires entering an accurate valid odometer. Most states require you to update your address on file within 30 days. Do you want to process a state change with this request?";
        JavascriptExecutor executor = (JavascriptExecutor) driver;
        WebDriverWait wait = new WebDriverWait(driver,30);
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table//tbody//tr[1]")));
            List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("//table//tbody//tr"));  
            Thread.sleep(2000);
            int rowcnt=Getgridrowcnt.size();
            boolean    firstpage=false;
            Thread.sleep(2000);
            for(int i=1; i<rowcnt;i++) {
                WebElement sub= driver.findElement(By.xpath("//tr["+i+"]//td[4]"));
                Thread.sleep(2000);
                String CVN = sub.getText();
                if(CVN.isEmpty()) {
                    WebElement driverclmn =driver.findElement(By.xpath("//tbody//tr["+i+"]//td[5]"));
                    Thread.sleep(2000);
                    drivername =driverclmn.getText();
                    Thread.sleep(1000);
                    if(!(drivername.equalsIgnoreCase("Unassigned") || drivername.contains("Pool")||drivername.contains("Unknown")||drivername.contains("Catering")) ) {
                    //    driver.findElement(By.xpath("//tbody//tr["+i+"]//td[5]")).click();
                    executor.executeScript("arguments[0].click();", driverclmn);
                    Thread.sleep(1000);
                    firstpage = true;
                    break;}
                  }  
            }
            if(firstpage)
            queryObjects.logStatus(driver, Status.PASS, "Searching Required grid record from Webtable", "Successful", null);
            
        }catch (Exception e){
            queryObjects.logStatus(driver, Status.FAIL, "Searching Required grid record from Webtable", e.getLocalizedMessage(), e);
             if(endRun)
            	 RC_Global.endTestRun(driver);
        }
        Thread.sleep(2000);
        RC_Global.waitElementVisible(driver, 30, "//h5//span[text()='Driver Details']", "Driver Details panel", endRun,false);
        RC_Global.clickUsingXpath(driver,"(//i[contains(@ng-class,' !panel.maximized')])[2]", "Expand DDriver Details panel", endRun,false);
        
        
        CustomerName =    driver.findElement(By.xpath("//span[@id='driver-change-header-customer-name']")).getText();
        UnitNumber =    driver.findElement(By.xpath("//a[@id='driver-change-header-vehicle-id']")).getText();
        VehicleStatus = driver.findElement(By.xpath("//span[contains(@id,'vehicle-status')]")).getText();
        queryObjects.logStatus(driver, Status.PASS, "Vehicle status is",""+VehicleStatus, null);
        DriverNameChange ="Yes" ;
        
         if(DriverNameChange.equalsIgnoreCase("Yes")) {
            try {
                RC_Global.clickUsingXpath(driver,"//button[@id='driverSearch']", "Driver Search button", endRun,false);
                RC_Global.waitElementVisible(driver, 30, "//h3[text()='Select Driver']", "Select Driver pop up", endRun,false);
                RC_Global.clickUsingXpath(driver,"(//button[@id='driver-change-search'])[1]", "Driver Change Search button", endRun,false);
                RC_Global.waitElementVisible(driver, 30, "//table//tbody//tr[1]", "Driver Names List", endRun,false);
                List<WebElement> selectdriver= driver.findElements(By.xpath("//table//tbody//tr"));
                Thread.sleep(3000);
                for(int i=0; i<=selectdriver.size(); i++) {
                List<WebElement> fullname= driver.findElements(By.xpath("//td[contains(@ng-if,'FullName')]"));
                executor.executeScript("document.body.style.zoom = '30%'");
                Thread.sleep(2000);
                executor.executeScript("document.body.style.zoom = '100%'");
                if(!fullname.get(i).getText().equalsIgnoreCase(drivername)) {
                    fullname.get(i).click();                
                if(!applyAddressToVehicle.equalsIgnoreCase("")) {
                    WebElement element = driver.findElement(By.xpath("//h3[1][text()='Driver Information']"));
                    
                    Thread.sleep(2000);
                    String driverState = driver.findElement(By.xpath("(//select[contains(@ng-options,'state.AddressStateCode')])[2]/option[@selected='selected' and @label]")).getText();
                    Thread.sleep(2000);
                    String VehicleState = driver.findElement(By.xpath("(//select[contains(@ng-options,'state.AddressStateCode')])[3]//option[@selected='selected' and @label]")).getText();
                    Thread.sleep(2000);
                    executor.executeScript("arguments[0].scrollIntoView();", element);
                    
                     RC_Global.clickUsingXpath(driver, "//a[normalize-space(text())='Apply Address To Vehicle']", "Apply Address to Vehicle link", endRun,false);
                    executor.executeScript("document.body.style.zoom = '30%'");
                    Thread.sleep(2000);
                    executor.executeScript("document.body.style.zoom = '100%'");
                    Thread.sleep(2000);
                    RC_Global.waitElementVisible(driver, 30, "//input[@name='driverFullName']", "Driver Full Name", endRun,false);
                   if(!driverState.equalsIgnoreCase(VehicleState)) {
                    if(applyAddressToVehicle.equalsIgnoreCase("Yes")){
                    	Thread.sleep(2000);
                        RC_Global.clickUsingXpath(driver, "(//button[normalize-space(text())='Yes'])[1]", "Yes button", endRun,false);
                        WebElement odometer = driver.findElement(By.xpath("(//div[label[text()='Odometer']]/input)[1]"));
                        Thread.sleep(2000);
                        RC_Global.enterInput(driver, "1000", odometer, endRun,false);
                    }
                    else if(applyAddressToVehicle.equalsIgnoreCase("No"))
                        RC_Global.clickUsingXpath(driver, "(//button[normalize-space(text())='No'])[1]", "No button", endRun,false);
                    }
                }
                break;
                }
                }
                 drivername = driver.findElement(By.xpath("//input[@name='driverFullName']")).getAttribute("value");
                DriverAddress = driver.findElement(By.xpath("//input[@name='residentialAddress1Text']")).getAttribute("value");
                driver.findElement(By.xpath("//button[contains(@id,'topDriverSaveButton')]")).click();
                
                if(driver.findElements(By.xpath("//div[@data-ng-repeat='errorMessage in errorList | limitTo:5' and @ng-show='topSave']//h4")).size()>0) {
                String errorMsg =     driver.findElement(By.xpath("//div[@data-ng-repeat='errorMessage in errorList | limitTo:5' and @ng-show='topSave']//h4")).getText();
                Thread.sleep(2000);
                RC_Global.verifyDisplayedMessage(driver, errorMsg, endRun);
                String[] mssg = errorMsg.split(" ");
                WebElement button = driver.findElement(By.xpath("//button[contains(@id,'topDriverSaveButton')]"));
                if(!button.isEnabled() || button.isEnabled()) {
                driver.findElement(By.xpath("//label[text()='"+mssg[0]+"']/following::div[2]//input")).sendKeys("abc");
                Thread.sleep(1000);
                RC_Global.clickUsingXpath(driver,"//button[contains(@id,'topDriverSaveButton')]","Top Save button", endRun,false);
                Thread.sleep(1000);
                }}
                Thread.sleep(2000);
                 if(driver.findElements(By.xpath("//span[text()=' address entered.']")).size()>0){
                        RC_Global.clickButton(driver, "Save As Entered", endRun,false);
                    }
                Thread.sleep(2000);
                RC_Global.waitElementVisible(driver, 30, "//div[@id='driver-change-top-success']//h4[text()='Update Successful']", "Update Successful message", endRun,false);
                queryObjects.logStatus(driver, Status.PASS, "Driver Name change is"," Successfull with updated "+drivername+","+DriverAddress+" ", null);
            }
                
            catch (Exception e) {
                queryObjects.logStatus(driver, Status.FAIL, "Driver Name change Failed", e.getLocalizedMessage(), e);
                 if(endRun)
                           RC_Global.endTestRun(driver);
                }
         }
    }
		public static void verifyGridColumnsByName(WebDriver driver, String ColumnNames,String ModuleName,boolean endRun)throws Exception {
	       try{
	              String[] aColNames = ColumnNames.split(";");
	              int colCount=aColNames.length;
	              JavascriptExecutor js = (JavascriptExecutor) driver;
	              
	              
	              switch(ModuleName) 
	              {
	                 case "CardShipment":
	                           for(int iter=0;iter<colCount;iter++)
	                           {
	                                 if(driver.findElements(By.xpath("//div[contains(text(),'"+aColNames[iter]+"')]")).size()>0)
	                                  {
	                                         js.executeScript("arguments[0].scrollIntoView();", ((WebElement)driver.findElement(By.xpath("//div[contains(text(),'"+aColNames[iter]+"')]"))));
	                                         queryObjects.logStatus(driver, Status.PASS, "Column Validation", aColNames[iter]+" Column is verified", null);
	                                  }
	                                  else
	                                  {
	                                         queryObjects.logStatus(driver, Status.FAIL, "Column Validation ", " Column"+aColNames[iter]+" is not available", null);
	                                  }
	                                  Thread.sleep(900);
	                           }
	                     break;
	                     case "ManageFuelPINPool":
	                             for(int iter=0;iter<colCount;iter++)
	                             {
	                                 if(driver.findElements(By.xpath("//span[contains(text(),'"+aColNames[iter]+"')]")).size()>0 && aColNames[iter].length()>0)
	                                         {
	                                                queryObjects.logStatus(driver, Status.PASS, "Column Validation", aColNames[iter]+" Column is verified", null);
	                                         }
	                                  else
	                                  {
	                                         queryObjects.logStatus(driver, Status.FAIL, "Column Validation ", " Column"+aColNames[iter]+" is not available", null);
	                                  }
	                                  
	                           }
	                             break;
	                     }
	                     
	              }catch(Exception e) {
	                     queryObjects.logStatus(driver, Status.FAIL, "Grid column validation failed", e.getLocalizedMessage(), e);
	                     if(endRun)
	 		   				RC_Global.endTestRun(driver);     
	              }
	}
	
	public static void verifyNotificationMessage(WebDriver driver,String Notification,String action,boolean endRun)throws Exception{
		RC_Global.createNode(driver, "Verifying Notification Messages");
		
	       try
	       {
	              switch(action)
	              {
	                     case "SaveUser":
	                     RC_Global.waitElementVisible(driver, 30, "//h4[contains(text(),'Save Successful')]", "Save Successful message", endRun,false);
	                     queryObjects.logStatus(driver, Status.INFO.PASS, "New user added","Successfully", null);
	                     break;
	              }
	       }catch(Exception e) {
	              queryObjects.logStatus(driver, Status.FAIL, "Notification message failed to display", e.getLocalizedMessage(), e);
	              if(endRun)
		   				RC_Global.endTestRun(driver);  
	       }
	}
	
	public static String getUnitNumbers(WebDriver driver, String altCheckVal, boolean endRun) throws Exception {
		
		RC_Global.createNode(driver, "Get the Unit Numbers with Alternate Checked In value as '"+altCheckVal+"'");
		String lastPg = ""; int pgNos = 1; boolean isData=false; String unitNum = "";
		try {
				
				List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("//div[contains(@ng-repeat,'rowContainer')]"));
				Thread.sleep(500);
				JavascriptExecutor executor = (JavascriptExecutor)driver;
				executor.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.xpath("//a[text()='Last']")));
				driver.findElement(By.xpath("//a[text()='Last']")).click();
				Thread.sleep(2000);
				lastPg = driver.findElement(By.xpath("//li[@class='pagination-page ng-scope active']/a")).getText().trim();
				pgNos = Integer.parseInt(lastPg)-1;
				Thread.sleep(2000);
				driver.findElement(By.xpath("//a[text()='First']")).click();				
				for (int p = 1; p <= pgNos; p++) {
					executor.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.xpath("//div[contains(text(),'Alternate Checked In')]")));
					driver.findElement(By.xpath("//div[contains(text(),'Alternate Checked In')]")).click();
					Thread.sleep(4000);
					driver.findElement(By.xpath("//div[contains(text(),'Alternate Checked In')]")).click();
					Thread.sleep(4000);
					int rowcnt=Getgridrowcnt.size();
					isData=false;
					Thread.sleep(2000);
					for(int i=1; i<rowcnt;i++) {
						if (driver.findElement(By.xpath("((//div[contains(@ng-repeat,'rowContainer')])["+i+"]//div[contains(@class,'ui-grid-cell-contents')])[9]")).getText().trim().equalsIgnoreCase(altCheckVal)) {
							isData = true;
							unitNum = driver.findElement(By.xpath("((//div[contains(@ng-repeat,'rowContainer')])["+i+"]//div[contains(@class,'ui-grid-cell-contents')])[3]")).getText().trim();
							break;
						}
					}
					if(isData) {
						queryObjects.logStatus(driver, Status.PASS, "Searching Required UnitNum", "Successful", null);
						break;
					} else {
						executor.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.xpath("//a[text()='Last']")));
						Thread.sleep(2000);
						driver.findElement(By.xpath("//li/a[text()='Next']")).click();
					}
				}
			}catch (Exception e){
				queryObjects.logStatus(driver, Status.FAIL, "Searching Required grid record from Webtable", e.getLocalizedMessage(), e);
				if(endRun)
					RC_Global.endTestRun(driver);
			}
		return unitNum;
		}

	public static void verifyGridColumnByNameAndValue(WebDriver driver, String ColumnName,String GridContetntToValidate,boolean endRun) throws Exception {
	
		RC_Global.createNode(driver, ""+ColumnName+" Content Validation as "+GridContetntToValidate+" ");
		try {
			boolean Flag = false;
			
			
			switch (ColumnName) {
			case "Alternate Checked In":
				RC_Global.waitElementVisible(driver, 40, "(//div[contains(@ng-repeat,'rowContainer')])[1]", "Grid Results", endRun,false);
				if (driver.findElements(By.xpath("//div[contains(@title,'" + ColumnName + "')]")).size() > 0) {
					//RC_Global.waitElementVisible(driver, 30, "//div[contains(text(),'" + GridContetntToValidate + "')]", "Validate "+GridContetntToValidate, endRun,false);
					JavascriptExecutor js = (JavascriptExecutor) driver;
					WebElement Element = driver.findElement(By.xpath("//div[contains(@title,'" + ColumnName + "')]"));
					js.executeScript("arguments[0].scrollIntoView();", Element);
//					RC_Global.waitElementVisible(driver, 30, "//div[@title='" + ColumnName + "']", "Column Name: "+ColumnName, endRun,false);
					if (driver.findElements(By.xpath("//div[contains(text(),'" + GridContetntToValidate + "')]")).size() > 0) {
						Flag = true;
					}
				}
				break;
			case "RO Status":
				RC_Global.waitElementVisible(driver, 30, "//div[contains(text(),'" + ColumnName + "')]", "Column: "+ColumnName, endRun,false);
				RC_Global.waitElementVisible(driver, 30, "(//div[contains(text(),'Open')])[1]//button", "Open button", endRun,false);
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("window.scrollTo(0,-1300)");

				Thread.sleep(2000);
				if (driver.findElements(By.xpath("//div[contains(text(),'" + ColumnName + "')]")).size() == 1&& GridContetntToValidate.equalsIgnoreCase("Pendind Invoice/Open")) {
					if (driver.findElements(By.xpath("//div[contains(text(),'Open')]")).size() > 0) {
						RC_Global.clickUsingXpath(driver, "(//div[contains(text(),'Open')])[1]//button","Open button", endRun,false);
						Flag = true;
						queryObjects.logStatus(driver, Status.INFO, " Edit button clicked ", "Edit RO Screen Opened",null);

					} else if (driver.findElements(By.xpath("//div[contains(text(),'Pending Invoice')]")).size() > 0) {
						RC_Global.clickUsingXpath(driver, "(//div[contains(text(),'Pending Invoice')])[1]//button","Pending Invoice", endRun,false);

						Flag = true;
						queryObjects.logStatus(driver, Status.INFO, " Edit button clicked ","Pending Invoice is opened in Edit RO Screen Opened", null);
					}
				}
				break;
			}

			if (Flag)
				queryObjects.logStatus(driver, Status.PASS, ColumnName + " has the value", GridContetntToValidate + "",null);
			else
				queryObjects.logStatus(driver, Status.FAIL, ColumnName + " doesn't have the value",GridContetntToValidate + "", null);
		} catch (Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, ColumnName + "column value validation failed",e.getLocalizedMessage(), e);
			 if(endRun)
	   				RC_Global.endTestRun(driver); 
		}
	}

	public static void sectionValidation(WebDriver driver, String sectionxpath,boolean endRun) throws Exception {
		try {
	
		WebElement section= driver.findElement(By.xpath("'"+sectionxpath+"'"));
		List<WebElement> sectionLinks = section.findElements(By.tagName("a"));
		
		for(int i=1;i<sectionLinks.size()+1;i++)
			{

				String Name = driver.findElement(By.xpath("("+section+"//h4/a)["+i+"]")).getText();
				queryObjects.logStatus(driver, Status.PASS, "Section(s) "+Name+" is ", "Displayed", null);
			}	
		}
		catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver,Status.FAIL,"Search Section Validation Failed -> The Search Section(s) is/ are not available", nse.getLocalizedMessage(), nse);
			 if(endRun)
	   				RC_Global.endTestRun(driver);
		}
		catch(NullPointerException npe) {
			queryObjects.logStatus(driver,Status.FAIL,"Search Section Validation Failed -> The Search Section(s) or the respective Xpath is/are not available", npe.getLocalizedMessage(), npe);
			 if(endRun)
	   				RC_Global.endTestRun(driver);
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver,Status.FAIL,"Search Section Validation Failed-> The Search Section(s) is/ are not available", te.getLocalizedMessage(), te);
			 if(endRun)
	   				RC_Global.endTestRun(driver);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver,Status.FAIL,"Search Section Validation Failed", e.getLocalizedMessage(), e);
			 if(endRun)
	   				RC_Global.endTestRun(driver);
		}
		
	}
public static void validateTheGridData(WebDriver driver, String ColumnNames , String ColumnData,boolean endRun ) throws Exception {
        RC_Global.createNode(driver, "Validate "+ColumnNames+" Content As "+ColumnData+" ");
        WebDriverWait wait = new WebDriverWait(driver,30);

        List<WebElement> rowCount;
        List<WebElement> colCount;
        String Xpath="";
        String data= "";
        int i;
        int j;
        String[] ColNames = ColumnNames.split(";");
        boolean Flag = false;
		try {
			rowCount = driver.findElements(By.xpath("//form//table/tbody/tr[@class='ng-scope']"));
			colCount = driver.findElements(By.xpath("//form//div[1]//div/table/tbody/tr[1]/td"));
			Flag = false;
			for (i = 1; i <= rowCount.size(); i++) {
				for (j = 0; j < colCount.size(); j++) {
					Xpath = driver.findElement(By.xpath("//form//table/tbody/tr[@class='ng-scope'][" + i+ "]/td[count(//table/thead/tr/th/div/span[text()='" + ColNames[j]+ "']/preceding-sibling::th)+1]")).getText();

					if (Xpath.equalsIgnoreCase(ColumnData)) {
						for (int a = 1 + j; a <= colCount.size(); a++) {
							data = driver.findElement(By.xpath("//form//table/tbody/tr[@class='ng-scope'][" + i+ "]/td[count(//table/thead/tr/th/div/span[text()='" + ColNames[j]+ "']/preceding-sibling::th)+" + a + "]")).getText();
							queryObjects.logStatus(driver, Status.PASS, ColNames[j] + " has the value", data + "",null);
							break;
						}
					}

				}
				break;
			}
		}
        catch(TimeoutException te) {
                     queryObjects.logStatus(driver, Status.FAIL, "Grid column data validation failed","No record found", null);
			if (endRun)
				RC_Global.endTestRun(driver);
		}
        catch(Exception e) {
                     queryObjects.logStatus(driver, Status.FAIL, "Grid column data validation Not Found","", e);
			if (endRun)
				RC_Global.endTestRun(driver);
		}

	}

public static void fuelCardHistory(WebDriver driver, String cardNumber) throws Exception {
    boolean firstpage=false;
    boolean pagination=false;
    WebDriverWait wait = new WebDriverWait(driver,30);
    RC_Global.createNode(driver, "Fuel Card Events History validation");
    List<WebElement> HistoryData = driver.findElements(By.xpath("//tbody//tr"));
    Thread.sleep(1000);
    int rowcnt=HistoryData.size();
    for(int i=1; i<rowcnt;i++) {
    String CardNum=driver.findElement(By.xpath("(//tbody//tr//td[1])["+i+"]")).getText();
    Thread.sleep(2000);
    if(CardNum.contains(cardNumber)) {
        driver.findElement(By.xpath("(//tbody//tr//td[@title='Open Card Event History'])["+i+"]")).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//legend[text()='Card Event History']")));
        firstpage = false;
        break;
    }
    firstpage = true;
    }
    if(firstpage) {
        String NextBttn = driver.findElement(By.xpath("//a[text()='Next']")).getAttribute("disabled");
        while(NextBttn.equals("disabled")) {
            driver.findElement(By.xpath("//a[text()='Next']")).click();
            Thread.sleep(2000);
             for(int i=1; i<rowcnt;i++) {
                    String CardNum=driver.findElement(By.xpath("(//tbody//tr//td[1])["+i+"]")).getText();
                    Thread.sleep(2000);
                    if(CardNum.contains(cardNumber)) {
                        driver.findElement(By.xpath("(//tbody//tr//td[@title='Open Card Event History'])["+i+"]")).click();
                        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//legend[text()='Card Event History']")));
                        pagination=false;
                        break;
                    }else
                    pagination=true;}
             if(pagination)    NextBttn =  driver.findElement(By.xpath("//a[text()='Next']")).getAttribute("ng-disabled");    
             else break;
        }
    } 
  
    List<WebElement> CardEvent = driver.findElements(By.xpath("//div[@history-list='eventHistoryList']//tbody[@data-ng-repeat='data in tableProperties.currentPageData']"));
    String userName = ((WebElement)(driver.findElement(By.xpath("//div[@class='bottom-nav bottom-right-menu']//div/ul[@class='nav-right list-unstyled pull-right user-menu']/li/a")))).getText();
    Thread.sleep(1000);
    int Events=CardEvent.size();
    for(int i=1; i<Events;i++) {
    String Event=driver.findElement(By.xpath("//td[text()='Terminate and Remove From Fuel Program']")).getText();

 

    if(Event.contains("Terminate and Remove From Fuel Program")) {
        queryObjects.logStatus(driver, Status.PASS,"Fuel Card Event History Validation","Successful",null);

 

        String CreatedBy = driver.findElement(By.xpath("//td[text()='Terminate and Remove From Fuel Program']/following::td[1]")).getText();
        if(CreatedBy.contains(userName)) 
           queryObjects.logStatus(driver, Status.PASS,"Fuel Card Event History Validation cretedBy validation","Successful",null);
        else
           queryObjects.logStatus(driver, Status.FAIL,"Fuel Card Event History Validation cretedBy validation","Failed",null);

 

    }else
        queryObjects.logStatus(driver, Status.FAIL,"Fuel Card Event History Event validation","Failed",null);

 

    }  	
}


}
