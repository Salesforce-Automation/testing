package tools.TotalView;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;
import MF.FrameworkCode.BFrameworkQueryObjects;
import MF.Source.Cred;

public class RC_Billing {
	
	public static String drivername = "";
	public static String unitnumber = "";
	static BFrameworkQueryObjects queryObjects = new BFrameworkQueryObjects();
	
	public static void InputFieldVisibilityStatus(WebDriver driver, String InputfieldName, String InputfieldStatus,boolean endRun) throws Exception {
		try {
			switch (InputfieldStatus) {
		    case "Enable":
		    	List<WebElement> inputEn = driver.findElements(By.xpath("//input[@placeholder='"+InputfieldName+"']"));
		    	if(inputEn.size()>0) 
					queryObjects.logStatus(driver,Status.PASS,""+InputfieldName+" Button is", "Enabled", null);
			
			break;
		    case "Disable":		
		    List<WebElement> inputfieldD = driver.findElements(By.xpath("//input[@disabled and @placeholder='"+InputfieldName+"']"));
		    if(inputfieldD.size()>0) 
					queryObjects.logStatus(driver,Status.PASS,""+InputfieldName+" Button is", "Disabled", null);
		    break;	
			}		}
			catch(Exception e) {
				queryObjects.logStatus(driver,Status.FAIL,"Input Status Validation Failed", e.getLocalizedMessage(), e);
				if(endRun)
					RC_Global.endTestRun(driver);
				}
			}

	public static void selectRowWithDriverNameFromGrid(WebDriver driver, boolean endRun) throws Exception{
				
			WebDriverWait wait = new WebDriverWait(driver,60);
		try {
			Thread.sleep(1000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tbody//tr")));
			List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("//table//tbody//tr"));  
			int rowcnt=Getgridrowcnt.size();
			boolean	firstpage=false;
			
			for(int i=1; i<rowcnt;i++) {
				WebElement sub = driver.findElement(By.xpath("//tr["+i+"]//td[4]"));
				String CVN = sub.getText();
				if(!CVN.isEmpty()) {
					WebElement driverclmn = driver.findElement(By.xpath("//tbody//tr["+i+"]//td[5]"));
					WebElement clmn = driver.findElement(By.xpath("//tbody//tr["+i+"]//td[7]"));
					drivername = driverclmn.getText();
					if(!(drivername.equalsIgnoreCase("Unassigned") || drivername.contains("Pool")||drivername.contains("Unkown")) ) {
					Thread.sleep(2000);
					clmn.click();
					firstpage = false;
					break;}
				}
				else if(CVN.isEmpty()) {
					WebElement driverclmn = driver.findElement(By.xpath("//tbody//tr["+i+"]//td[5]"));
					WebElement clmn = driver.findElement(By.xpath("//tbody//tr["+i+"]//td[7]"));
					drivername = driverclmn.getText();
					if(!(drivername.equalsIgnoreCase("Unassigned") || drivername.contains("Pool")||drivername.contains("Unkown")) ) {
					Thread.sleep(2000);
					clmn.click();
					firstpage = false;
					break;}
				}
				firstpage = true;
			}		
			queryObjects.logStatus(driver, Status.PASS, "Searching Required grid record from Webtable", "Successful", null);
			
					   
																														   
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "Failed to Search Required grid record -> Unable to Search Required grid record screen", te.getLocalizedMessage(), te);
			if(endRun)
				RC_Global.endTestRun(driver);
			}
		catch (Exception e){
			
			queryObjects.logStatus(driver, Status.FAIL, "Searching Required grid record from Webtable", e.getLocalizedMessage(), e);
			if(endRun)
				RC_Global.endTestRun(driver);
			}
	}
	
	public static void selectnodefromCustomerAssignment(WebDriver driver, boolean endRun) throws Exception{
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		WebDriverWait wait = new WebDriverWait(driver,60);
	try {
		
		executor.executeScript("window.scrollBy(0,1400)");

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div/span[@ng-if='originalCustomerId !== node.CustomerId']")));
		List<WebElement> Getnodecnt = driver.findElements(By.xpath("//div/span[@ng-if='originalCustomerId !== node.CustomerId']"));  
		int nodecnt=Getnodecnt.size();
		boolean	firstpage=false;
		boolean pagination=false;
		
		for(int i=2; i<nodecnt;i++) {	
	
	String CurrentlyAssigned = driver.findElement(By.xpath("//span[contains(text(),'Currently Assigned')]")).getText();
	String cusnode = driver.findElement(By.xpath("(//div/span[@ng-if='originalCustomerId !== node.CustomerId'])[1]")).getText();
	
		queryObjects.logStatus(driver, Status.INFO, "Currently assigned customer structure assignment ", CurrentlyAssigned, null);
	if(!(CurrentlyAssigned.equalsIgnoreCase("Currently Assigned")||(cusnode).contains("cusnode")) ) {
		WebElement node = driver.findElement(By.xpath("(//div/span[@ng-if='originalCustomerId !== node.CustomerId'])["+i+"]"));
		Thread.sleep(2000);
		
		node.click();
		firstpage = false;
		break;
			}
		firstpage = true;
		}
		
		executor.executeScript("window.scrollBy(0,-1000)", "");
		queryObjects.logStatus(driver, Status.PASS, "Selecting node from new customer structure assignment ", "Successful", null);
		
		}
	catch(TimeoutException te) {
		queryObjects.logStatus(driver, Status.FAIL, "Failed to Select node from new customer structure assignment -> Unable to Select node from new customer structure assignment screen", te.getLocalizedMessage(), te);
		if(endRun)
			RC_Global.endTestRun(driver);
	}
	catch (Exception e){
		queryObjects.logStatus(driver, Status.FAIL, "Selecting node from new customer structure assignment", e.getLocalizedMessage(), e);
		if(endRun)
			RC_Global.endTestRun(driver);
		}
	}

    public static void VerifyHyperlinkPanel(WebDriver driver, String ColumnName,String header, boolean endRun) throws Exception {
        try {    
        
            Thread.sleep(2000);
             int ColumnNum = RC_Global.findColumnNumber(driver,ColumnName, endRun);
            if(driver.findElements(By.xpath("//div[div[@role='row']][1]//div[@role='gridcell'][" + ColumnNum + "]//a[@href]")).size()>0) {
                driver.findElement(By.xpath("//div[div[@role='row']][1]//div[@role='gridcell'][" + ColumnNum + "]//a[@href]")).click();
            }
            else if(driver.findElements(By.xpath("(//table/tbody/tr[1]/td[2])[" + ColumnNum + "]")).size() > 0) {
                driver.findElement(By.xpath("(//table/tbody/tr[1]/td[2])[" + ColumnNum + "]")).click();           //Unit Number hyperlink  
            }
            queryObjects.logStatus(driver, Status.PASS, "Clicked Hyperlink page navigation is passed","with the navigated page header as "+header+" " , null);
            Thread.sleep(2000);
            }
        catch(Exception e) {
            queryObjects.logStatus(driver, Status.FAIL, "Clicked Hyperlink page navigation is failed",e.getLocalizedMessage() , e);
            if(endRun)
				RC_Global.endTestRun(driver);
        }
    }

    public static void confirmationscreen(WebDriver driver, String Msg1, String Msg2, boolean endRun ) throws Exception {
    	List<WebElement> elements = null;
		boolean msgPresent = false;
		try {	
				unitnumber = driver.findElement(By.xpath("//a[@ng-click='openVehicleDetails()']")).getText();
			elements = driver.findElements(By.xpath("//*[normalize-space(text())='"+Msg1+"' and a[text()='"+unitnumber+"'] and text()='"+Msg2+"']"));
		
			if(elements.size()>0) {
				queryObjects.logStatus(driver, Status.PASS, "Message to be verified", "The following message has been verified: "+Msg1+unitnumber+Msg2, null);
				msgPresent=true;			
				}
			}
		catch(NullPointerException npe) {
			queryObjects.logStatus(driver, Status.FAIL, "Message was not verified -> The following message : "+Msg1+Msg2+" is not present on the screen", npe.getLocalizedMessage(), npe);
			if(endRun)
				RC_Global.endTestRun(driver);
			
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "Message was not verified -> The following message : "+Msg1+Msg2+" failed to display on the screen", te.getLocalizedMessage(), te);
			if(endRun)
				RC_Global.endTestRun(driver);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Message was not verified -> The following message : "+Msg1+Msg2+" failed to display on the screen", e.getLocalizedMessage(), e);
			if(endRun)
				RC_Global.endTestRun(driver);
		}
		
		
	}
    
    public static void verifyGridColumnsByName(WebDriver driver, String ColumnNames, boolean endRun )throws Exception {
	       try{
	    	   int i;
	              String[] aColNames = ColumnNames.split(";");
	              int colCount=aColNames.length;
	              JavascriptExecutor js = (JavascriptExecutor) driver;
	              
	                           for( i=0;i<colCount;i++)
	                           {
	                                  if(driver.findElements(By.xpath("//div[@id='ctl00xFxPHxgrdListxgrdList_hdiv']/table//tr/th[normalize-space(text())='"+aColNames[i]+"']")).size()>0)
	                                  {
	                                         js.executeScript("arguments[0].scrollIntoView();", ((WebElement)driver.findElement(By.xpath("//div[@id='ctl00xFxPHxgrdListxgrdList_hdiv']/table//tr/th[normalize-space(text())='"+aColNames[i]+"']"))));
	                                         queryObjects.logStatus(driver, Status.PASS, "Column Validation", aColNames[i]+" Column is verified", null);
	                                  }
	                                 
	                                  Thread.sleep(900);
	                           }
	                           
	       }
	       catch (org.openqa.selenium.NoSuchElementException|org.openqa.selenium.StaleElementReferenceException| org.openqa.selenium.TimeoutException e)  
			{
				queryObjects.logStatus(driver, Status.FAIL, "Grid column validation failed", e.getLocalizedMessage(), e);
				if(endRun)
					RC_Global.endTestRun(driver);
			}
  
    }

    public static void screenSectionDetailsValidation(WebDriver driver,String sectioName,String labelText,String dataDetails, boolean endRun) throws Exception {
    	try{
    		switch (sectioName)
        {
        case "Selected Vehicle Details":
	        if(driver.findElements(By.xpath("//legend[text()='"+sectioName+"']/../following::div//div//label[text()='"+labelText+"']")).size()>0)
	            {
	                  dataDetails = driver.findElement(By.xpath("//legend[text()='"+sectioName+"']/../following::div//div//label[text()='"+labelText+"']/following-sibling::div")).getText();       
	                  queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with value",dataDetails, null);
	            }
	            else
	            {
                     queryObjects.logStatus(driver,Status.FAIL,"The lable :"+labelText+" is not found in section "+sectioName, null,null);
	            }
	        break;
        case "Current Customer Structure Assignment":
        case "New Customer Structure Assignment":
            if(driver.findElements(By.xpath("(//legend[text()='Current Customer Structure Assignment']/../following::div//div//label[text()='"+labelText+"'])[1]")).size()>0)
               {
                     dataDetails=driver.findElement(By.xpath("((//legend[text()='Current Customer Structure Assignment'])[1]/../following::div//div//label[text()='"+labelText+"'])[1]/../following::div[1]//div[1]")).getText();
                     queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with value",dataDetails, null);
               }
               else
               {
                     queryObjects.logStatus(driver,Status.FAIL,"The lable :"+labelText+" is not found in section "+sectioName, null,null);
               }
            break;
        case "Driver Information":   //By Vijay for TID_5_2_0_08  
            if(driver.findElements(By.xpath("//legend[normalize-space(text())='"+sectioName+"']/..//following::div//div//div//div//label[normalize-space(text())='"+labelText+"']")).size()>0)
               {
                     dataDetails = driver.findElement(By.xpath("//legend[normalize-space(text())='"+sectioName+"']/..//following::div//div//div//div//label[normalize-space(text())='"+labelText+"']/../following-sibling::div//div")).getText();      
                     queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with value",dataDetails, null);
               }
               else
               {
                     queryObjects.logStatus(driver,Status.FAIL,"The lable :"+labelText+" is not found in section "+sectioName, null,null);
               }
            break;
       case "Residential Address":  //By Vijay for TID_5_2_0_08
            if(driver.findElements(By.xpath("//legend[normalize-space(text())='"+sectioName+"']/../div//div//label[contains(text(),'"+labelText+"')]")).size()>0)
               {
                       dataDetails = driver.findElement(By.xpath("((//legend[normalize-space(text())='"+sectioName+"']/../div//div//label[contains(text(),'"+labelText+"')]/following::div//div)[1])")).getText();                   
                       queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with value",dataDetails, null);
               }
                else
               {
                       queryObjects.logStatus(driver,Status.FAIL,"The lable :"+labelText+" is not found in section "+sectioName, null,null);
               }
	      break;
       case "Pool Information":   //By Vijay for TID_5_2_0_08  
           if(driver.findElements(By.xpath("//legend[normalize-space(text())='"+sectioName+"']/..//following::div//div//div//div//label[normalize-space(text())='"+labelText+"']")).size()>0)
              {
                    dataDetails = driver.findElement(By.xpath("//legend[normalize-space(text())='"+sectioName+"']/..//following::div//div//div//div//label[normalize-space(text())'"+labelText+"']/../following-sibling::div//div")).getText();      
                    queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with value",dataDetails, null);
              }
              else
              {
                    queryObjects.logStatus(driver,Status.FAIL,"The lable :"+labelText+" is not found in section "+sectioName, null,null);
              }
           break;
      case "Pool Address":  //By Vijay for TID_5_2_0_08
           if(driver.findElements(By.xpath("//legend[normalize-space(text())='"+sectioName+"']/../div//div//label[contains(text(),'"+labelText+"')]")).size()>0)
              {
                      dataDetails = driver.findElement(By.xpath("((//legend[normalize-space(text())='"+sectioName+"']/../div//div//label[contains(text(),'"+labelText+"')]/following::div//div)[1])")).getText();                   
                      queryObjects.logStatus(driver,Status.PASS,"Section :"+sectioName+" has label "+labelText+" with value",dataDetails, null);
              }
               else
              {
                      queryObjects.logStatus(driver,Status.FAIL,"The lable :"+labelText+" is not found in section "+sectioName, null,null);
              }
	      break;
	      
        }
    	}
        catch(NullPointerException npe) {
			queryObjects.logStatus(driver, Status.FAIL, "The lable :"+labelText+" is not found in section "+sectioName, npe.getLocalizedMessage(), npe);
			if(endRun)
				RC_Global.endTestRun(driver);
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "The lable :"+labelText+" is not found in section "+sectioName, te.getLocalizedMessage(), te);
			if(endRun)
				RC_Global.endTestRun(driver);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "The lable :"+labelText+" is not found in section "+sectioName, e.getLocalizedMessage(), e);
			if(endRun)
				RC_Global.endTestRun(driver);
		}
        
    }
    
   public static int selectCustomerStructure(WebDriver driver, int itr ,boolean endRun) throws Exception
    {
	   
	   		try {
	   			
           RC_Global.createNode(driver, "Select Customer Number from tree structure");	
           RC_Global.waitElementVisible(driver,10,"(//treeitem//ul//li/div)","Grid Row", endRun,false);
           int intCustCount = driver.findElements(By.xpath("(//treeitem//ul//li/div)")).size();
           for( itr = itr + 1;itr<intCustCount;itr++)
           {
                  WebElement ele= ((WebElement)(driver.findElement(By.xpath("(//treeitem//ul//li/div)["+itr+"]"))));
                  if((ele.getAttribute("class").contains("tree-unselectable")==true))
                  {
                        continue;
                  }
                  else
                  {
                        RC_Global.clickUsingXpath(driver, "(//treeitem//ul//li/div)["+itr+"]", "Select customer", endRun,false);
                        queryObjects.logStatus(driver,Status.PASS,"Selected customer structure is ",ele.getText(), null);
                        Thread.sleep(2000);
                        break;
                  }
           }
	   		}
	   		catch(Exception e) {
	   			queryObjects.logStatus(driver, Status.FAIL, "Selection of customer node structure unsuccessful", e.getLocalizedMessage(), e);
	   		}
           return itr;
    }

    public static void getUserHistory(WebDriver driver, String custNode, boolean endRun) throws Exception{
    	try {
        Thread.sleep(1000);
        String userName = ((WebElement)(driver.findElement(By.xpath("//div[@class='bottom-nav bottom-right-menu']//div/ul[@class='nav-right list-unstyled pull-right user-menu']/li/a")))).getText();
        List<WebElement> userList = driver.findElements(By.xpath("//tbody//tr[contains(@data-toggle,'collapse')]//td[3]"));
        String updatedDate ="";
        int updateStatus =0;
        String matchUser = "";
        String custNo ="";
        String custName="";
        String fleetNo ="";
        String fleetName="";
        String account ="";
        String accountName="";
        String subAccount="";
        String subAccountNam="";
        
        for(WebElement user : userList)
        {
               matchUser=user.getText();
               if(matchUser.equalsIgnoreCase(userName))
               {
                 updatedDate = driver.findElement(By.xpath("(//td[contains(text(),'"+matchUser+"')])[1]/../td[1]")).getText();
                     RC_Global.createNode(driver,"Vehicle movement history is update by user - "+matchUser+" in the date "+updatedDate);
                     RC_Global.clickUsingXpath(driver, "(//td[contains(text(),'"+matchUser+"')])[1]/../td[2]", "UserName", endRun,false);
                     custNo=driver.findElement(By.xpath("(//td[contains(text(),'"+matchUser+"')])[1]/../..//tr[2]//td//table//tr[2]//td[1]")).getText();
                     custName=driver.findElement(By.xpath("(//td[contains(text(),'"+matchUser+"')])[1]/../..//tr[2]//td//table//tr[2]//td[2]")).getText();
                     fleetNo=driver.findElement(By.xpath("(//td[contains(text(),'"+matchUser+"')])[1]/../..//tr[2]//td//table//tr[2]//td[3]")).getText();
                     fleetName=driver.findElement(By.xpath("(//td[contains(text(),'"+matchUser+"')])[1]/../..//tr[2]//td//table//tr[2]//td[4]")).getText();
                     account=driver.findElement(By.xpath("(//td[contains(text(),'"+matchUser+"')])[1]/../..//tr[2]//td//table//tr[2]//td[5]")).getText();
                     accountName=driver.findElement(By.xpath("(//td[contains(text(),'"+matchUser+"')])[1]/../..//tr[2]//td//table//tr[2]//td[6]")).getText();
                     subAccount=driver.findElement(By.xpath("(//td[contains(text(),'"+matchUser+"')])[1]/../..//tr[2]//td//table//tr[2]//td[7]")).getText();
                     subAccountNam=driver.findElement(By.xpath("(//td[contains(text(),'"+matchUser+"')])[1]/../..//tr[2]//td//table//tr[2]//td[8]")).getText();
                     
                     if(fleetNo.length()>0 && fleetName.length()>0)
                     queryObjects.logStatus(driver,Status.INFO,"Fleet detail "+fleetNo,fleetName, null);
                     

                     if(account.length()>0 && accountName.length()>0)
                     queryObjects.logStatus(driver,Status.INFO,"Account detail "+account,accountName, null);
                     
                     if(subAccount.length()>0 && subAccountNam.length()>0)
                         queryObjects.logStatus(driver,Status.INFO,"Fleet detail "+subAccount,subAccountNam, null);
                     
                     updateStatus=1; 
               }
               
               break; 
        }
        
        if(updateStatus==1)
        {
               queryObjects.logStatus(driver,Status.PASS,"Vehicle movement details are updated by user ",matchUser, null);
        }
        else
        {
               queryObjects.logStatus(driver,Status.FAIL,"Vehicle movement details not updated",null, null);
        }
        
        Thread.sleep(2000);
        
        if(updateStatus==1)
        {
               queryObjects.logStatus(driver,Status.PASS,"Vehicle movement details updated for customer node"+custNode+" by user ",matchUser, null);
        }
        else
        {
               queryObjects.logStatus(driver,Status.FAIL,"Vehicle movement details not for customer node "+custNode+" by user ",matchUser, null);
        }
    	}
    	catch(NullPointerException npe) {
 			queryObjects.logStatus(driver, Status.FAIL, "Vehicle movement details not updated", npe.getLocalizedMessage(), npe);
 			if(endRun)
 				RC_Global.endTestRun(driver);
 		}
 		catch(TimeoutException te) {
 			queryObjects.logStatus(driver, Status.FAIL, "Vehicle movement details not updated-> Unable to fetch updated Vehicle movement details", te.getLocalizedMessage(), te);
 			if(endRun)
 				RC_Global.endTestRun(driver);
 		}
 		catch(Exception e) {
 			queryObjects.logStatus(driver, Status.FAIL, "Vehicle movement details not updated", e.getLocalizedMessage(), e);
 			if(endRun)
 				RC_Global.endTestRun(driver);
    }

    }
    
    public static void waitForloadingIconToDisappear(WebDriver driver, String xpath) throws Exception {
    	int count = 0;
    	List<WebElement> loadingIcon = driver.findElements(By.xpath(xpath));
    	while(loadingIcon.size()!=0 && count<30) {
    		Thread.sleep(2000);
    		count++;
    	}
    }
    
    
}
