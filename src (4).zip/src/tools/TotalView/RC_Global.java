package tools.TotalView;

import java.io.File;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import MF.FrameworkCode.StartFramework;
import MF.Source.Cred;
import totalview.Util.url_path;
import totalview.Utilities.ConnectionToDB;

public class RC_Global extends url_path{
	static String UserName = "";
	static String PassWord = "";
	public static String unitNum;
	public static String userLogged;
	static BFrameworkQueryObjects queryObjects = new BFrameworkQueryObjects();
	
	public static void createNode(WebDriver driver, String LogMessageOnNodes) throws Exception{
		try{
			StartFramework.child = StartFramework.logger.createNode("<b><font color=green size=5>"+LogMessageOnNodes+"</font></b>");
			//queryObjects.logStatus(driver, Status.INFO, "Creating Node","Creating Node Passed",null);
		   }catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Creating Node Failed", e.getLocalizedMessage(), e);
		}
	}
	
	public static void login(WebDriver driver) throws Exception{
		createNode(driver, "Login To Application");
		String username = Cred.UserName; 
		String password =Cred.PassWord;
		String Env=Cred.ENV;
		WebDriverWait wait = new WebDriverWait(driver, 30);											 
		try{
			
			if (Env.equalsIgnoreCase("QA")) 
				driver.get(QAurl);
			else if (Env.equalsIgnoreCase("UAT"))
				driver.get(UATurl);
			else if (Env.equalsIgnoreCase("DEV")) 
				driver.get(Devurl);
			else if (Env.equalsIgnoreCase("OC5QA"))
				driver.get(OC5QAurl);
			else if (Env.equalsIgnoreCase("PROD")) 
				driver.get(PRODURL);
			Thread.sleep(2000);
			driver.findElement(By.xpath("//input[@placeholder='User Name']")).sendKeys(username);
			driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys(password);
			driver.findElement(By.xpath("//button[@type='submit']")).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Acquisition')]")));
			queryObjects.logStatus(driver, Status.PASS, "Login has been successful using", username, null);
			RC_Manage.waitUntilCustomerFocus(driver);
			String currentWindow = driver.getWindowHandle();
		     driver.switchTo().window(currentWindow);
		     if (username.toUpperCase().contains("TESTAUTOMATION")) {
		    	 userLogged = "AUTOMATION";				
			} else {
				userLogged = driver.findElement(By.xpath("//span[contains(@ng-show,'user.FullName') and @id='Span1']")).getText().toUpperCase();
			}
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "Failed to login to the Application -> Unable to load the current/previous screen", te.getLocalizedMessage(), te);
			endTestRun(driver);
		}
		catch(Exception e) { 
			try {
				String errorMsg = driver.findElement(By.xpath("//div[div[button[normalize-space(text())='Log In']]]/div[3]/h4")).getText();
				if(verifyDisplayedMessage(driver, "Username and/or password is incorrect.",true)) {
					queryObjects.logStatus(driver, Status.FAIL, "Failed to login to the Application -> Provide the right username/password", e.getLocalizedMessage(), e);
					endTestRun(driver);
				}
				else if(verifyDisplayedMessage(driver, "User is not enabled.  Please contact your administrator.",true)) {
					queryObjects.logStatus(driver, Status.FAIL, "Failed to login to the Application -> The username is locked. Please enable the username.", e.getLocalizedMessage(), e);
					endTestRun(driver);
				}
				else {
					queryObjects.logStatus(driver, Status.FAIL, "Failed to login to the Application -> The following error occurs: "+errorMsg, e.getLocalizedMessage(), e);
					endTestRun(driver);
				}
			}
			catch(Exception ce) {
				queryObjects.logStatus(driver, Status.FAIL, "Failed to login to the Application -> No error message present", e.getLocalizedMessage(), e);
				endTestRun(driver);
			}
		}
	}
	
	static String[] externalCredentials(String username) {
		UserName = username;
		switch(username) {
			case "appleuser":
				PassWord = "Masha2$";
				break;			
				
			default:
				PassWord = "Masha2$";
				break;
		}
		String[] extCredentials = {username,PassWord};
		return extCredentials;
	}
	
	public static void externalUserLogin(WebDriver driver, String username, String firstLogin) throws Exception{
        createNode(driver, "Login To Application with External Credentials");
        WebDriverWait wait = new WebDriverWait(driver,30);                                                                       
        try{
               
               String Env=Cred.ENV;
               if (Env.equalsIgnoreCase("QA")) 
                     driver.get(QAurl);
               else if (Env.equalsIgnoreCase("UAT"))
                     driver.get(UATurl);
               else if (Env.equalsIgnoreCase("DEV")) 
                     driver.get(Devurl);
               else if (Env.equalsIgnoreCase("OC5QA"))
      				driver.get(OC5QAurl);
               else if (Env.equalsIgnoreCase("PROD")) 
                     driver.get(PRODURL);
               
               String password = externalCredentials(username)[1];//Index 1 represents the second element from the array returned via the method

               driver.findElement(By.xpath("//input[@placeholder='User Name']")).sendKeys(username);
               driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys(password);
               driver.findElement(By.xpath("//button[@type='submit']")).click();
               Thread.sleep(2000);
               if (driver.findElements(By.xpath("//input[@placeholder='Confirm Password']")).size()>0) {
            	   changePassword(driver, username, true);
               }
               RC_Manage.waitUntilCustomerFocus(driver);
               try {
            	   userLogged = driver.findElement(By.xpath("//span[contains(@ng-show,'user.FullName') and @id='Span1']")).getText().toUpperCase();
				} catch (Exception e) {}               
               try {
               wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//i[contains(@class,'fa-search') and @data-toggle='dropdown']"))));
               }
               catch(Exception e) {
                    } try {
               wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//span[contains(text(),'Reporting')]"))));
                     }
               catch(Exception ex) {
            	   try {
                       wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//span[contains(text(),'"+Env+"')]"))));
                             }
                       catch(Exception ex1) {
                              wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//h4[text()='User account is locked.  Please contact your administrator.']"))));
                       }
               }
               queryObjects.logStatus(driver, Status.PASS, "Login Successful using the external user",username, null);
               
        }
        catch(TimeoutException te) {
               queryObjects.logStatus(driver, Status.FAIL, "Failed to login to the Application -> Unable to load the current/previous screen", te.getLocalizedMessage(), te);
               endTestRun(driver);
        }
        catch(Exception e) {
               try {
                     String errorMsg = driver.findElement(By.xpath("//div[div[button[normalize-space(text())='Log In']]]/div[3]/h4")).getText();
                     if(verifyDisplayedMessage(driver, "Username and/or password is incorrect.",true)) {
                            queryObjects.logStatus(driver, Status.FAIL, "Failed to login to the Application -> Provide the right username/password", e.getLocalizedMessage(), e);
                            endTestRun(driver);
                     }
                     else if(verifyDisplayedMessage(driver, "User is not enabled.  Please contact your administrator.",true)) {
                            queryObjects.logStatus(driver, Status.FAIL, "Failed to login to the Application -> The username is locked. Please enable the username.", e.getLocalizedMessage(), e);
                            endTestRun(driver);
                     }
                     else {
                            queryObjects.logStatus(driver, Status.FAIL, "Failed to login to the Application -> The following error occurs: "+errorMsg, e.getLocalizedMessage(), e);
                            endTestRun(driver);
                     }
               }
               catch(Exception ce) {
                     queryObjects.logStatus(driver, Status.FAIL, "Failed to login to the Application -> No error message present", e.getLocalizedMessage(), e);
                     endTestRun(driver);
               }
        }
 }


	public static void loginUsing(String username) {
		UserName = username;
		if(username.equalsIgnoreCase("navirasainath")) {
			PassWord = "NaAd@Merchants.2153";
		}
		else if(username.equalsIgnoreCase("yashodhab")) {
			PassWord = "Mphasis@012";
		} 
	}
	
	public static void navigateTo(WebDriver driver, String menu, String frstSubMenu, String scndSubMenu) throws Exception {
		try {
			createNode(driver, "Navigate To: " + menu + ">" + frstSubMenu + ">" + scndSubMenu + "");

			Thread.sleep(1000);
			driver.findElement(By.xpath("//span[text()='" + menu + "']")).click();
			Thread.sleep(1000);
		driver.findElement(By.xpath("//a[span[text()='"+menu+"']]/following-sibling::div//span[text()='"+frstSubMenu+"']")).click();//First click does

		if(!scndSubMenu.equals("")) {
		driver.findElement(By.xpath("//a[span[text()='"+menu+"']]/following-sibling::div//span[text()='"+frstSubMenu+"']")).click();//First click does
		Thread.sleep(1000);
		if(driver.findElement(By.xpath("(//span[contains(text(),'"+scndSubMenu+"')])[1]")).isDisplayed())
		driver.findElement(By.xpath("(//span[contains(text(),'"+scndSubMenu+"')])[1]")).click();
		else if(driver.findElement(By.xpath("(//span[contains(text(),'"+scndSubMenu+"')])[2]")).isDisplayed())
		driver.findElement(By.xpath("(//span[contains(text(),'"+scndSubMenu+"')])[2]")).click();
		else if(driver.findElement(By.xpath("(//span[contains(text(),'"+scndSubMenu+"')])[3]")).isDisplayed())
			driver.findElement(By.xpath("(//span[contains(text(),'"+scndSubMenu+"')])[3]")).click();
		//
		//else if(driver.findElements(By.xpath("//span[contains(text(),'"+scndSubMenu+"')]")).size()>0)
		//driver.findElement(By.xpath("//span[contains(text(),'"+scndSubMenu+"')]")).click();
				Thread.sleep(1000);
			}
			Thread.sleep(1000);
			if (!scndSubMenu.equals("")) {
				if (scndSubMenu.equalsIgnoreCase("Vehicle Segment Management")) {
					if(driver.findElement(By.xpath("//h5/span[contains(text(),'Segment Management')]")).isDisplayed()) {
						queryObjects.logStatus(driver, Status.PASS, "Navigation to "+scndSubMenu+" module ", "Navigation Successfull", null);
					} else {
						queryObjects.logStatus(driver, Status.FAIL, "Navigation to "+frstSubMenu+" module ", "Navigation Successfull", null);
						endTestRun(driver);
					}
				} else {
					if(driver.findElement(By.xpath("//h5/span[contains(text(),'"+scndSubMenu+"')]")).isDisplayed()) {
						queryObjects.logStatus(driver, Status.PASS, "Navigation to "+scndSubMenu+" module ", "Navigation Successfull", null);
					} else {
						queryObjects.logStatus(driver, Status.FAIL, "Navigation to "+frstSubMenu+" module ", "Navigation Successfull", null);
						endTestRun(driver);
					}
				}
				
				
			} else {
				if(driver.findElement(By.xpath("//h5/span[contains(text(),'"+frstSubMenu+"')]")).isDisplayed()) {
					queryObjects.logStatus(driver, Status.PASS, "Navigation to "+frstSubMenu+" module ", "Navigation Successfull", null);
				} else {
					queryObjects.logStatus(driver, Status.FAIL, "Navigation to "+frstSubMenu+" module ", "Navigation Successfull", null);
					endTestRun(driver);
				}
			}

		} catch (NoSuchElementException nse) {
		queryObjects.logStatus(driver, Status.FAIL, "Navigate to the required screen failed -> Kindly provide right fields for navigation", nse.getLocalizedMessage(), nse);
			endTestRun(driver);
		} catch (TimeoutException te) {
		queryObjects.logStatus(driver, Status.FAIL, "Navigate to the required screen failed -> Unable to load the current/previous screen", te.getLocalizedMessage(), te);
		endTestRun(driver);
		}
		catch(Exception e) {
		queryObjects.logStatus(driver, Status.FAIL, "Navigation to Screen Failed", e.getLocalizedMessage(),e);
			endTestRun(driver);
		}
	}
	
	public static void waitUntilPanelVisibility(WebDriver driver, String panelTitle, String Application, boolean endRun, boolean createND) throws Exception{
	       
		WebDriverWait wait = new WebDriverWait(driver,30);
		if(createND)
        createNode(driver,"Wait Until Visibility of Panel ---> "+panelTitle);
        try {
            if(Application.equalsIgnoreCase("OM")||Application.equalsIgnoreCase("Order Management")) //Heading in  Order Management
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(), '"+panelTitle+"')]")));
           
            else if(Application.equalsIgnoreCase("TV")||Application.equalsIgnoreCase("Total View")){//Heading in TotalView
                try {
                    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h5/span[contains(text(), '"+panelTitle+"')]")));
                }
                catch(Exception e) {
                    try {
                        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h4/u[contains(text(), '"+panelTitle+"')]")));
                    }
                    catch(TimeoutException te) {
                        queryObjects.logStatus(driver, Status.FAIL, "Waiting for the Screen Display -> Unable to load/locate "+panelTitle, te.getLocalizedMessage(), te);
                        if(endRun)
                            endTestRun(driver);
                    }
                    catch(Exception ce) {
                        queryObjects.logStatus(driver, Status.FAIL, "Waiting for the Screen Display -> Unable to load/locate "+panelTitle, e.getLocalizedMessage(), ce);
                        if(endRun)
                            endTestRun(driver);
                    }
                }
            }
            else {
                queryObjects.logStatus(driver, Status.FAIL, "Waiting for the Screen Display", "Not successful in navigating to the screen or "+panelTitle+" has not loaded on the screen", null);
                if(endRun)
                    endTestRun(driver);
            }
            queryObjects.logStatus(driver, Status.PASS, "Wait Until Visibility of Panel"+panelTitle, "Navigated to "+panelTitle+" successfully", null);
        }
        catch(TimeoutException te) {
            queryObjects.logStatus(driver, Status.FAIL, "Waiting for the Screen Display -> Unable to load/locate "+panelTitle, te.getLocalizedMessage(), te);
            if(endRun)
                endTestRun(driver);
        }
        catch(Exception e) {
            queryObjects.logStatus(driver, Status.FAIL, "Waiting for the Screen Display -> Not successful in navigating to the screen or "+panelTitle+" has not loaded/not available on the screen", e.getLocalizedMessage(), e);
            if(endRun)
                endTestRun(driver);
        }
    }
	
	public static boolean waitElementVisible(WebDriver driver, int sec, String xpath, String Element, boolean endRun, boolean createND)throws Exception{
		if(createND)
		createNode(driver, "Wait Element is Visible-->"+Element);
		
		try {
			WebDriverWait wait = new WebDriverWait(driver,sec);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "After waiting for-->"+sec+" sec, Element: "+Element+"-->Is NOT Visible", e.getLocalizedMessage(), e);
			if(endRun)
				endTestRun(driver);
			return false;		
		}
		return true;
	}

	public static boolean waitElementNotVisible(WebDriver driver, int sec, String xpath, String Element, boolean endRun, boolean createND)throws Exception{
		if(createND)
		createNode(driver, "Wait Element is NOT Visible-->"+Element);
		
		try {
			WebDriverWait wait = new WebDriverWait(driver,sec);
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(xpath)));
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "After waiting for-->"+sec+" sec, Element: "+Element+"-->Is Visible", e.getLocalizedMessage(), e);
			if(endRun)
				endTestRun(driver);
			return false;		
		}
		return true;
	}
	public static void validateHeaderName(WebDriver driver, String Header, boolean endRun) throws Exception {
		RC_Global.createNode(driver, "Validating the Header "+Header+""); 
		try {	
			Thread.sleep(1000);
			if(driver.findElements(By.xpath("//*[text()='"+Header+"']")).size()==1) {//Heading in  Order Management
				queryObjects.logStatus(driver, Status.PASS, "Validate the header", "The header "+Header+" is correct", null);
			}
			else if(driver.findElements(By.xpath("//h5/*[text()='"+Header+"']")).size()==1){//Heading in TotalView
				queryObjects.logStatus(driver, Status.PASS, "Validate the header", "The header "+Header+" is correct", null);
	
			}
			else if(driver.findElements(By.xpath("//*[text()=' "+Header+"']")).size()>0) {//Heading in  Order Management
				queryObjects.logStatus(driver, Status.INFO, "Validate the header", "The xpath has more than 1 value", null);
			}
			else if(driver.findElements(By.xpath("//h5/*[text()='"+Header+"']")).size()>0){//Heading in TotalView
				queryObjects.logStatus(driver, Status.INFO, "Validate the header", "The xpath has more than 1 value", null);
	
			}
			else
				queryObjects.logStatus(driver, Status.FAIL, "Validate the header", "The header "+Header+" is not the correct one", null);
		}
		
		catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver, Status.FAIL, "Validate the header -> Unable to locate the "+Header+" in the current screen", nse.getLocalizedMessage(), nse);
			if(endRun)
				endTestRun(driver);
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "Validate the header -> Unable to load the current/previous screen", te.getLocalizedMessage(), te);
			if(endRun)
				endTestRun(driver);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Validate the header -> The header "+Header+" is not available", e.getLocalizedMessage(), e);
			if(endRun)
				endTestRun(driver);
		}
		
	}
	
	public static String[] enterCustomerNumber(WebDriver driver, String custNum, String custHierarchy, String lowerLevel, boolean endRun) throws Exception {
		createNode(driver, "Enter Customer Number in Customer Number Input Field");
		String[] CustNumName = {"",""};
		String customerNo = "";
		
		List<WebElement> iCustNum6 = driver.findElements(By.xpath("//div[@class='input-group' and @ng-show='customerChosen']//input[@name='customerInput']"));
		List<WebElement> iCustNum = driver.findElements(By.xpath("//label[normalize-space(text())='Customer Number']/following-sibling::input"));
		List<WebElement> iCustNum2 = driver.findElements(By.xpath("//label[normalize-space(text())='Customer #']/following-sibling::input"));
		List<WebElement> iCustNum3 = driver.findElements(By.xpath("//div[@class='tree-container']/label[normalize-space(text())='Customer #']/following-sibling::input"));
		List<WebElement> iCustNum4 = driver.findElements(By.xpath("//div[span[normalize-space(text())='Customer Number']]//input"));//For OM Home Page Customer Number
		 List<WebElement> iCustNum5 = driver.findElements(By.xpath("//label[normalize-space(text())='Customer Number:']/following-sibling::div//input"));//For Reporting Customer Number
		WebElement wCustNum = null;
		Thread.sleep(2000);
		try {
			/*if(!custNum.isEmpty()) {
				iCustNum.click();
				iCustNum.clear();
				iCustNum.sendKeys(custNum);
				Thread.sleep(2000);*/
			if(iCustNum6.size()==1) 
				wCustNum = iCustNum6.get(0);
			else if(iCustNum.size()==1) 
				wCustNum = iCustNum.get(0);
			else if(iCustNum2.size()==1)
				wCustNum = iCustNum2.get(0);
			else if(iCustNum3.size()==1)
				wCustNum = iCustNum3.get(0);
			else if(iCustNum4.size()==1)
				wCustNum = iCustNum4.get(0);
			else if(iCustNum5.size()==1)
				wCustNum = iCustNum5.get(0);
			else if(iCustNum6.size()==1)
				wCustNum = iCustNum6.get(0);
			if(custNum.equalsIgnoreCase("DB")) {
				Thread.sleep(3000);
				String Sql ="select AccountName FROM [TotalView].[dbo].[Customer] where CompanyName ='Kentucky Farm Bureau Mutual Insurance Company'";
				//custNum = database(Sql);
				customerNo = custNum;
			}
			
			
			enterInput(driver, custNum, wCustNum, endRun,false);
			Thread.sleep(2000);
//			WebElement iCustSel = driver.findElement(By.xpath("//label[normalize-space(text())='Customer Number']/following-sibling::ul//a"));
//			WebElement iCustSelOM = driver.findElement(By.xpath("//li[contains(text(),'"+custNum+"')]"));
			WebElement iCustSel = null;
			if(iCustNum.size()==1||iCustNum2.size()==1||iCustNum3.size()==1 ||iCustNum5.size()==1 || iCustNum6.size()==1) {
				if(iCustNum2.size()==1||iCustNum3.size()==1)
					iCustSel = driver.findElement(By.xpath("//label[normalize-space(text())='Customer #']/following-sibling::ul//a"));
				else if(iCustNum6.size()==1)
					iCustSel = driver.findElement(By.xpath("//div[@class='input-group' and @ng-show='customerChosen']//input[@name='customerInput']/..//a"));
				else
					iCustSel = driver.findElement(By.xpath("//label[normalize-space(text())='Customer Number']/following-sibling::ul//a"));
				iCustSel.click();
				queryObjects.logStatus(driver, Status.PASS, "Customer Number ", " "+custNum, null);
				Thread.sleep(2000);
				
				if(custNum.isEmpty())
					queryObjects.logStatus(driver, Status.FAIL, "Enter Customer Number", "Customer Number has not been provided", null);

				if(custHierarchy.equalsIgnoreCase("Customer") || custHierarchy.equalsIgnoreCase("")){
					if (lowerLevel.equalsIgnoreCase("Fleet level")|| lowerLevel.equalsIgnoreCase("Account level") || lowerLevel.equalsIgnoreCase("Sub-account level")) {
						if(driver.findElements(By.xpath("//button[@ng-click='toggleHierarchy()']")).size()>0){
							driver.findElement(By.xpath("//button[@ng-click='toggleHierarchy()']")).click();
							int arrDown = driver.findElements(By.xpath("//i[contains(@class,'glyphicon-chevron-down')]")).size();
							if (arrDown>1) {
								for (int i = arrDown; i >1 ; i--) {
									driver.findElement(By.xpath("(//i[contains(@class,'glyphicon-chevron-down')])["+i+"]")).click();
								}
							}
						}
					}				
					
                    if(driver.findElements(By.xpath("//h4[text()='Customer selected cannot have units assigned to it.']")).size()>0) {
                           queryObjects.logStatus(driver, Status.INFO, "Customer-level Number selected", "Lower Hierarchy should be selected", null);
                    }
                    if(lowerLevel.equalsIgnoreCase("Fleet level")) {
                    	try {
                    		driver.findElement(By.xpath("//treecontrol//treeitem/ul/li[1]//span")).click();//Fleet-level first number                            
						} catch (Exception e) {}
                    	Thread.sleep(2000);                    
                    }
                    else if(lowerLevel.equalsIgnoreCase("Account level")) {
                    	driver.findElement(By.xpath("//treecontrol//treeitem/ul/li[1]//i[contains(@class,'chevron-right')]")).click();//Expanding Fleet-level first number
                        driver.findElement(By.xpath("//treecontrol//treeitem/ul/li[1]//ul/li[1]//span")).click();//Account-level first number                        
                    }
                    
                    else if(lowerLevel.equalsIgnoreCase("Sub-account level")) {
                    	driver.findElement(By.xpath("//treecontrol//treeitem/ul/li[1]//i[contains(@class,'chevron-right')]")).click();//Expanding Fleet-level first number
                    	Thread.sleep(100);
                    	try {
							driver.findElement(By.xpath("(//treecontrol//treeitem/ul/li[1]//ul/li[1]//i[contains(@class,'chevron-right')])[1]")).click();//Expanding Account-level first number
						} catch (Exception e) {}						
						driver.findElement(By.xpath("//treecontrol//treeitem/ul/li[1]//ul/li[1]//ul/li[1]//span")).click();//Sub-account-level first number
					}
					
				}
			}
			else if(iCustNum4.size()==1){
				WebElement iCustSelOM = driver.findElement(By.xpath("//li[contains(text(),'"+custNum+"')]"));
				customerNo = iCustSelOM.getText();
				iCustSelOM.click();
				
				if(lowerLevel.equalsIgnoreCase("Fleet level")) {
					driver.findElement(By.xpath("//button[@ptooltip='Customer tree']")).click();
					customerNo = driver.findElement(By.xpath("//ul//ul/p-treenode[1]//div[@role='treeitem']/span")).getText();
					driver.findElement(By.xpath("//ul//ul/p-treenode[1]//div[@role='treeitem']/span")).click();//Fleet-level first number
					Thread.sleep(2000);
					
					}
				else if(lowerLevel.equalsIgnoreCase("Account level")) {
					driver.findElement(By.xpath("//button[@ptooltip='Customer tree']")).click();
					if(driver.findElements(By.xpath("//ul//ul/p-treenode[1]//div[@role='treeitem']/button")).size()==1) {
						driver.findElement(By.xpath("//ul//ul/p-treenode[1]//div[@role='treeitem']/button")).click();//Expanding Fleet-level first number
					}
					else if(driver.findElements(By.xpath("//ul//ul/p-treenode[2]//div[@role='treeitem']/button")).size()==1) {
						driver.findElement(By.xpath("//ul//ul/p-treenode[2]//div[@role='treeitem']/button")).click();//Expanding Fleet-level first number
					}
					else {
						queryObjects.logStatus(driver, Status.FAIL, "Select Account level number available", "No Account level number available", null);
					}
					customerNo = driver.findElement(By.xpath("//ul//ul//ul/p-treenode[1]//div[@role='treeitem']/span")).getText();
					driver.findElement(By.xpath("//ul//ul//ul/p-treenode[1]//div[@role='treeitem']/span")).click();//Account-level first number

				}
				
				else if(lowerLevel.equalsIgnoreCase("Sub-account level")) {
					driver.findElement(By.xpath("//button[@ptooltip='Customer tree']")).click();
					if(driver.findElements(By.xpath("//ul//ul/p-treenode[1]//div[@role='treeitem']/button")).size()==1) {
						driver.findElement(By.xpath("//ul//ul/p-treenode[1]//div[@role='treeitem']/button")).click();//Expanding Fleet-level first number
					}
					else if(driver.findElements(By.xpath("//ul//ul/p-treenode[2]//div[@role='treeitem']/button")).size()==1) {
						driver.findElement(By.xpath("//ul//ul/p-treenode[2]//div[@role='treeitem']/button")).click();//Expanding Fleet-level first number
					}
					if(driver.findElements(By.xpath("//ul//ul//ul/p-treenode[1]//div[@role='treeitem']/button")).size()==1) {
						driver.findElement(By.xpath("//ul//ul//ul/p-treenode[1]//div[@role='treeitem']/button")).click();//Expanding Fleet-level first number
					}
					else if(driver.findElements(By.xpath("//ul//ul//ul/p-treenode[2]//div[@role='treeitem']/button")).size()>0) {
						driver.findElement(By.xpath("//ul//ul//ul/p-treenode[2]//div[@role='treeitem']/button")).click();//Expanding Fleet-level first number
					}
					
//						driver.findElement(By.xpath("//treecontrol//treeitem/ul/li[1]//i[contains(@class,'chevron-right')]")).click();
//						driver.findElement(By.xpath("//treecontrol//treeitem/ul/li[1]//ul/li[1]//i[contains(@class,'chevron-right')]")).click();//Expanding Account-level first number
					customerNo = driver.findElement(By.xpath("//ul//ul//ul//ul/p-treenode[1]//div[@role='treeitem']/span")).getText();
					driver.findElement(By.xpath("//ul//ul//ul//ul/p-treenode[1]//div[@role='treeitem']/span")).click();//Sub-account-level first number
					
				}
			}
			else {
				queryObjects.logStatus(driver, Status.FAIL, "Failed to select Customer Number", "Unable to enter the correct customer number", null);
				if(endRun)
					endTestRun(driver);
			}
   
			if(customerNo.contains(" - ")) {
				CustNumName = customerNo.split(" - ");
			}
			else
				CustNumName[0] = customerNo;
		}
		catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver, Status.FAIL, "Failed to select Customer Number -> Unable to find the correct inputbox to enter the number", nse.getLocalizedMessage(), nse);
			if(endRun)
				endTestRun(driver);
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "Failed to select Customer Number -> Unable to load the current/previous screen", te.getLocalizedMessage(), te);
			if(endRun)
				endTestRun(driver);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Failed to select Customer Number -> Verify and enter the correct Customer Number or number of the respective hierarchy", e.getLocalizedMessage(), e);
			if(endRun)
				endTestRun(driver);

		}
		
		
		return CustNumName;
	}


	public static void enterInput(WebDriver driver, String input, WebElement element,boolean endRun, boolean createND) throws Exception{
		if(createND)
			 createNode(driver,"Enter "+input+" in the input box");
		try {	
			if(input.equalsIgnoreCase("")) {
				queryObjects.logStatus(driver, Status.INFO, "Input to be entered", "No input available to enter", null);
			}
			else {
				element.click();
				element.clear();
				element.sendKeys(input);
				queryObjects.logStatus(driver, Status.INFO, "Input to be entered", "Input entry successful", null);
			}
		}
		catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver, Status.FAIL, "Input failed to enter -> Unable to find the correct inputbox to enter the value", nse.getLocalizedMessage(), nse);
			if(endRun)
				endTestRun(driver);
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "Input failed to enter -> Unable to load the the element or the current/previous screen", te.getLocalizedMessage(), te);
			if(endRun)
				endTestRun(driver);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Input failed to enter -> Enter the right input", e.getLocalizedMessage(), e);
			if(endRun)
				endTestRun(driver);
		}
	}
	
	public static String getTrimTdata(String inp1) throws Exception{
		String returnstring = "";
		if (inp1!=null){
			returnstring=inp1.trim();
		}
		return returnstring;
	}

	public static void switchToWindowTab(WebDriver driver, int i,String MenuTab,boolean endRun) throws Exception {
		try{
			WebDriverWait wait = new WebDriverWait(driver,30);
			ArrayList<String> getWindows = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(getWindows.get(i-1));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='"+MenuTab+"']")));
			queryObjects.logStatus(driver, Status.INFO, "Switch To New Window", "Successfully switched to the correct ", null);
		}
		catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver, Status.FAIL, "Switch To New Window -> Unable to find the specified window to switch", nse.getLocalizedMessage(), nse);
			if(endRun)
				endTestRun(driver);
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "Switch To New Window -> Failed to switch to a new window or the "+MenuTab+" did not appear", te.getLocalizedMessage(), te);
			if(endRun)
				endTestRun(driver);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Switch To New Window Failed", e.getLocalizedMessage(), e);
			if(endRun)
				endTestRun(driver);
		}																	   
	}

	public static void clickButton(WebDriver driver, String btnName,boolean endRun, boolean createND) throws Exception{
		if(createND)
			RC_Global.createNode(driver, "Click Button-->"+btnName);
	 try {
																 
            WebDriverWait wait = new WebDriverWait(driver,30);
            WebElement element = null;
            
            if(driver.findElements(By.xpath("//button/span[normalize-space(text())='"+btnName+"']")).size()==1)
            {
                element = driver.findElement(By.xpath("//button/span[normalize-space(text())='"+btnName+"']"));
            }
            else if(driver.findElements(By.xpath("//button[normalize-space(text())='"+btnName+"']")).size()==1)
            {
                element = driver.findElement(By.xpath("//button[normalize-space(text())='"+btnName+"']"));
            }
            else if(driver.findElements(By.xpath("//button[text()=' "+btnName+" ']")).size()==1)
            {
                element = driver.findElement(By.xpath("//button[text()=' "+btnName+" ']"));
            }
            else if(driver.findElements(By.xpath("//button[1][text()='"+btnName+"']")).size()==1)  
            {
                element = driver.findElement(By.xpath("//button[1][text()='"+btnName+"']"));
            }
            else if(driver.findElements(By.xpath("//label[text()='"+btnName+"']")).size()==1)    
            {
                element = driver.findElement(By.xpath("//label[text()='"+btnName+"']"));
            }
            else if(driver.findElements(By.xpath("//div[7]/button[1][normalize-space(text())='"+btnName+"']")).size()==1)      
            {
                element = driver.findElement(By.xpath("//div[7]/button[1][normalize-space(text())='"+btnName+"']"));
            }
            else if(driver.findElements(By.xpath("//span[normalize-space(text())='"+btnName+"']")).size()==1)
            {
                element = driver.findElement(By.xpath("//span[normalize-space(text())='"+btnName+"']"));
            }
            else if(driver.findElements(By.xpath("//button[@aria-label='"+btnName+"']")).size()==1)
            {
                element = driver.findElement(By.xpath("//button[@aria-label='"+btnName+"']"));
            }
            else if(driver.findElements(By.xpath("//form/div[1]/div/button[contains(@class,'"+btnName+"')]")).size()==1)
            {
                element = driver.findElement(By.xpath("//form/div[1]/div/button[contains(@class,'"+btnName+"')]"));
            }
            else if(driver.findElements(By.xpath("//span[normalize-space(text())='"+btnName+"']")).size()==1)
			{
				element = driver.findElement(By.xpath("//span[normalize-space(text())='"+btnName+"']"));
			}
            else if(driver.findElements(By.xpath("//button[@title='"+btnName+"']")).size()==1) {
				  
				element = driver.findElement(By.xpath("//button[@title='"+btnName+"']"));																	 
			}
			else if(driver.findElements(By.xpath("//form//div/button[normalize-space(text())='"+btnName+"']")).size()==1) {
				  
				element = driver.findElement(By.xpath("//form//div/button[normalize-space(text())='"+btnName+"']"));
			}
			else if(driver.findElements(By.xpath("(//button[contains(text(),'"+btnName+"')])[1]")).size()==1)
            {
                  element = driver.findElement(By.xpath("(//button[contains(text(),'"+btnName+"')])[1]"));
            }

			else {
                queryObjects.logStatus(driver, Status.FAIL, btnName+ "button does not exist", "Enter the valid button info", null);
                return;
            }
            wait.until(ExpectedConditions.elementToBeClickable(element));
            element.click();
        }
        catch(ElementNotInteractableException e) {
            queryObjects.logStatus(driver, Status.FAIL, btnName+ " button is not clickable", e.getLocalizedMessage(), e);
            if(endRun)
				endTestRun(driver);
        }
        catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver, Status.FAIL, "Failed to click on the "+btnName+" -> Unable to find "+btnName+" button", nse.getLocalizedMessage(), nse);
			if(endRun)
				endTestRun(driver);
		}
        catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "Failed to click on the "+btnName+" -> It is disabled or did not appear on the screen", te.getLocalizedMessage(), te);
			if(endRun)
				endTestRun(driver);
		}
        catch(Exception e) {
            queryObjects.logStatus(driver, Status.FAIL, btnName+ " button does not exist or is not clickable", e.getLocalizedMessage(), e);
            if(endRun)
				endTestRun(driver);
        }
    }
 
	public static void verifyColumnNames(WebDriver driver, String ColumnNmes,boolean endRun) throws Exception{
		
		RC_Global.createNode(driver, "Verify Column Names");
		
		String expColName = null;
		
		try {
			Thread.sleep(2000);
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			if(driver.findElements(By.xpath("//span[text()='Expand']")).size()>0)
				   driver.findElement(By.xpath("//span[text()='Expand']")).click();
			   Thread.sleep(2000);
			   String[] aColNames = ColumnNmes.split(";");
			   List<WebElement> colNames = null;
				if(driver.findElements(By.xpath("//tr[th[text()=' Actions ']]/th")).size()>0)
					colNames = driver.findElements(By.xpath("//tr[th[text()=' Actions ']]/th"));
				else if(driver.findElements(By.xpath("//cell-template//div[1]")).size()>0)
					colNames = driver.findElements(By.xpath("//cell-template//div[1]"));
				else if(driver.findElements(By.xpath("//div[@id='Customer Document Attributes History']/following-sibling::div//span[contains(@class, 'column-header')]")).size()>0) //by jaya for TID_2_2_2_02
					colNames = driver.findElements(By.xpath("//div[@id='Customer Document Attributes History']/following-sibling::div//span[contains(@class, 'column-header')]"));
				else if(driver.findElements(By.xpath("//div//table//th")).size()>0)
					colNames = driver.findElements(By.xpath("//div//table//th"));
				else if(driver.findElements(By.xpath("//div//table//th//span[1]")).size()>0)
					colNames = driver.findElements(By.xpath("//div//table//th//span[1]"));
				else if(driver.findElements(By.xpath("//standard-grid//div[1]//span[contains(@id,'header-text')]")).size()>0)
					colNames = driver.findElements(By.xpath("//standard-grid//div[1]//span[contains(@id,'header-text')]"));
				else if(driver.findElements(By.xpath("//tr//th")).size()>0)
	                colNames = driver.findElements(By.xpath("//tr//th")); 
				else if(driver.findElements(By.xpath("//table/thead/tr/th/div/span[contains(@class,'column-header-value')]")).size()>0)     
	            	colNames = driver.findElements(By.xpath("//table/thead/tr/th/div/span[contains(@class,'column-header-value')]"));
				else if(driver.findElements(By.xpath("(//div[@ng-controller='driverHistoryCtrl']//table//tr)[1]")).size()>0)     
	            	colNames = driver.findElements(By.xpath("(//div[@ng-controller='driverHistoryCtrl']//table//tr)[1]"));
				
				String[] sColNames = new String[colNames.size()];
				boolean flag = false;
				int scrollCount = 0;
				for(int iter=0;iter<aColNames.length;iter++) {
				   
				   sColNames[iter] = colNames.get(iter).getText();
				   expColName=sColNames[iter];
				   for(int iter1=0;iter1<colNames.size();iter1++) {
					   
					   if(sColNames[iter1].equalsIgnoreCase(aColNames[iter])) {
						   if((aColNames.length>6&&iter==6)||(aColNames.length>11&&iter==11)||(aColNames.length>16&&iter==16)||(aColNames.length>20&&iter==20)) {
							   if(driver.findElements(By.xpath("//div[contains(@class,'wrapper')]")).size()>0) {
								   WebElement scrollBar =null;
								   WebElement perscrollBar =null;
								   if(driver.findElements(By.xpath("//standard-grid/div/div/div[contains(@class,'ng-isolate-scope')]")).size()==1) {
									   
									  if(driver.findElements(By.xpath("//div[@id='view-maintenancerepairorders']")).size()==1)
										  scrollBar= driver.findElement(By.xpath("//div[@id='view-maintenancerepairorders']"));
									  else if(driver.findElements(By.xpath("(//div[@role='rowgroup'])[1]")).size()==1)
										  scrollBar= driver.findElement(By.xpath("(//div[@role='rowgroup'])[1]"));
									  else if(driver.findElements(By.xpath("//div[@ng-controller='PersonalUseUserSearchCtrl as vm']")).size()==1)
										 perscrollBar= driver.findElement(By.xpath("//div[@ng-controller='PersonalUseUserSearchCtrl as vm']")); 
									  WebElement scrollBar2= driver.findElement(By.xpath("//div[@style='overflow: scroll;']"));
									  executor.executeScript("arguments[0].scrollIntoView(true);",scrollBar);
									  executor.executeScript("arguments[0].scrollLeft += 400",scrollBar2);
									  scrollCount++;
	//								  executor.executeScript("arguments[0].scrollTop -= 600",scrollBar);
								   }
								   else if(driver.findElements(By.xpath("//div[contains(@class,'wrapper')]")).size()==1) {
									   scrollBar= driver.findElement(By.xpath("//div[contains(@class,'wrapper')]"));
									   executor.executeScript("window.scrollTo(0,800)");
									   executor.executeScript("arguments[0].scrollLeft += 1000",scrollBar);
					                   executor.executeScript("window.scrollTo(0,-800)");
					                   for(int i=0;i<4;i++){
					                       executor.executeScript("window.scrollTo(0,800)");
					                       WebElement scrollBar1 = driver.findElement(By.xpath("//div[contains(@class,'wrapper')]"));					                   
					                       executor.executeScript("arguments[0].scrollLeft -= 1000",scrollBar);
					                       executor.executeScript("window.scrollTo(0,-800)");
					                   }
								   }
								   else if(driver.findElements(By.xpath("//div[@table-scroll]")).size()==1) {
									   scrollBar= driver.findElement(By.xpath("//div[@table-scroll]"));
									   executor.executeScript("arguments[0].scrollLeft += 500",scrollBar);
					                   scrollCount++;
								   }
								   else if(driver.findElements(By.xpath("//div[contains(@class,'fixed-table-bottom')]")).size()==1) { 
	                                   perscrollBar= driver.findElement(By.xpath("//div[contains(@class,'fixed-table-bottom')]")); 
	                                   executor.executeScript("window.scrollBy(0,900)");
	                                   executor.executeScript("arguments[0].scrollLeft += 1500",perscrollBar);
	                                   executor.executeScript("window.scrollBy(0,-900)");
	                                 
	                               }
							   }
						   }
						   Thread.sleep(1000);
			               flag = true;
			               break;
					   }
				}   
			   }
			   Thread.sleep(2000);
				   if(flag)
					   queryObjects.logStatus(driver, Status.PASS, "Column Names Validation", "Column Names are verified", null);
					else
					   queryObjects.logStatus(driver, Status.FAIL, "Column Names Validation", "Column Names Validation Failed", null);
			  
			   
			   for(int iter=0;iter<scrollCount;iter++) {
				   WebElement scrollBar= null;
				   if(driver.findElements(By.xpath("//div[@id='view-maintenancerepairorders']")).size()>0) {
					   scrollBar = driver.findElement(By.xpath("//div[@id='view-maintenancerepairorders']"));
					   WebElement scrollBar2= driver.findElement(By.xpath("//div[@style='overflow: scroll;']"));
					   executor.executeScript("arguments[0].scrollTop += 400",scrollBar);
					   executor.executeScript("arguments[0].scrollLeft -= 400",scrollBar2);					   
					   executor.executeScript("arguments[0].scrollTop -= 400",scrollBar);
					}	   
		 
				   else if(driver.findElements(By.xpath("//div[@table-scroll]")).size()>0) {
					   scrollBar= driver.findElement(By.xpath("//div[@table-scroll]"));
					   executor.executeScript("arguments[0].scrollLeft -= 500",scrollBar);
				   }   
			 
			   }
   
		}
		catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver, Status.FAIL, "Failed to verify all column names-->Unable to find element-->"+expColName, nse.getLocalizedMessage(), nse);
			if(endRun)
				endTestRun(driver);
		}
		catch(NullPointerException npe) {
			queryObjects.logStatus(driver, Status.FAIL, "Failed to verify all column names-->Unable to find column-->"+expColName, npe.getLocalizedMessage(), npe);
			if(endRun)
				endTestRun(driver);
		}//
        catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "Failed to verify all column names-->The grid/expected column of the grid did load completely or did not appear on the screen", te.getLocalizedMessage(), te);
			if(endRun)
				endTestRun(driver);
		}
        catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "ColumnName Validation failed-->Enter valid column name-->"+expColName, e.getLocalizedMessage(),e);
			if(endRun)
				endTestRun(driver);
		}
	}
  
	public static int noOfColumns(WebDriver driver,boolean endRun) throws Exception{
		List<WebElement> Columns = null;
			try {	
			if(driver.findElements(By.xpath("//table//tr[1]/th")).size()>0)
				Columns = driver.findElements(By.xpath("//table//tr[1]/th"));
			else if(driver.findElements(By.xpath("//div//cell-template/div")).size()>0)
				Columns = driver.findElements(By.xpath("//div//cell-template/div"));
		}
		catch(NullPointerException npe) {
			queryObjects.logStatus(driver, Status.FAIL, "One or more columns are not available or empty", npe.getLocalizedMessage(), npe);
			if(endRun)
				endTestRun(driver);
		}
		catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver, Status.FAIL, "The columns cannot be located", nse.getLocalizedMessage(), nse);
			if(endRun)
				endTestRun(driver);
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "The grid has not been loaded completely", te.getLocalizedMessage(), te);
			if(endRun)
				endTestRun(driver);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to fetch the number of columns", e.getLocalizedMessage(), e);
			if(endRun)
				endTestRun(driver);
		}
			return Columns.size();
	}
	
	public static int findColumnNumber(WebDriver driver, String columnName,boolean endRun) throws Exception{
		try {
			int colNum = 0;
			List<WebElement> colName = null;
			String sColumnName = "";
			int scrollCount = 0;
			
			if(driver.findElements(By.xpath("//div[cell-template]")).size()>0) {
	        	colName = driver.findElements(By.xpath("//div[cell-template]"));	
	        }
	        
	        else if(driver.findElements(By.xpath("//tr[1]/th")).size()>0) {
	        	colName = driver.findElements(By.xpath("//tr[1]/th"));	
	        }
	        else if(driver.findElements(By.xpath("//tr//th")).size()>0) {		
	        	colName = driver.findElements(By.xpath("//tr//th"));
	        }
			
			int iter = 0;
			for(WebElement col:colName) {
				sColumnName = getTrimTdata(col.getText());
				iter++;
				
				if(sColumnName.contains(columnName)) {
					
					return iter;
				}
			}
		}
		catch(NullPointerException npe) {
			queryObjects.logStatus(driver, Status.FAIL, "One or more columns are not available or empty", npe.getLocalizedMessage(), npe);
			if(endRun)
				endTestRun(driver);
		}
		catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver, Status.FAIL, "The columns cannot be located", nse.getLocalizedMessage(), nse);
			if(endRun)
				endTestRun(driver);
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "The grid has not been loaded completely", te.getLocalizedMessage(), te);
			if(endRun)
				endTestRun(driver);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to fetch the number of columns", e.getLocalizedMessage(), e);
			if(endRun)
				endTestRun(driver);
		}
		return -1;
	}
	
	public static void scrollBarScrollAction(WebDriver driver) {
	       
        JavascriptExecutor executor = (JavascriptExecutor)driver;
        int scrollCount = 0;
        if(driver.findElements(By.xpath("//div[contains(@class,'wrapper')]")).size()>0) {
               WebElement scrollBar =null;
               WebElement perscrollBar =null;
               if(driver.findElements(By.xpath("//standard-grid/div/div/div[contains(@class,'ng-isolate-scope')]")).size()==1) {
                  
                  if(driver.findElements(By.xpath("//div[@id='view-maintenancerepairorders']")).size()==1)
                      scrollBar= driver.findElement(By.xpath("//div[@id='view-maintenancerepairorders']"));
                  else if(driver.findElements(By.xpath("(//div[@role='rowgroup'])[1]")).size()==1)
                      scrollBar= driver.findElement(By.xpath("(//div[@role='rowgroup'])[1]"));
                  else if(driver.findElements(By.xpath("//div[@ng-controller='PersonalUseUserSearchCtrl as vm']")).size()==1)
                     perscrollBar= driver.findElement(By.xpath("//div[@ng-controller='PersonalUseUserSearchCtrl as vm']"));
                  WebElement scrollBar2= driver.findElement(By.xpath("//div[@style='overflow: scroll;']"));
                  executor.executeScript("arguments[0].scrollIntoView(true);",scrollBar);
                  executor.executeScript("arguments[0].scrollLeft += 400",scrollBar2);
                  scrollCount++;
               }
               else if(driver.findElements(By.xpath("//div[contains(@class,'wrapper')]")).size()==1) {
                   scrollBar= driver.findElement(By.xpath("//div[contains(@class,'wrapper')]"));
                   executor.executeScript("window.scrollTo(0,800)");
                   executor.executeScript("arguments[0].scrollLeft += 1000",scrollBar);
                executor.executeScript("window.scrollTo(0,-800)");
                for(int i=0;i<4;i++){
                    executor.executeScript("window.scrollTo(0,800)");
                    WebElement scrollBar1 = driver.findElement(By.xpath("//div[contains(@class,'wrapper')]"));                                      
                    executor.executeScript("arguments[0].scrollLeft -= 1000",scrollBar);
                    executor.executeScript("window.scrollTo(0,-800)");
                }
               }
               else if(driver.findElements(By.xpath("//div[@table-scroll]")).size()==1) {
                   scrollBar= driver.findElement(By.xpath("//div[@table-scroll]"));
                   executor.executeScript("arguments[0].scrollLeft += 500",scrollBar);
                scrollCount++;
               }
               else if(driver.findElements(By.xpath("//div[contains(@class,'fixed-table-bottom')]")).size()==1) { 
                perscrollBar= driver.findElement(By.xpath("//div[contains(@class,'fixed-table-bottom')]"));
                executor.executeScript("window.scrollBy(0,900)");
                executor.executeScript("arguments[0].scrollLeft += 1500",perscrollBar);
                executor.executeScript("window.scrollBy(0,-900)");
             
            }
        }
    }
	
	public static boolean verifyGridFieldIsAvailable(WebDriver driver, String columnName,boolean endRun)throws Exception
    {
		
		try {
	        List<WebElement> colName = null;
	        String sColumnName = null;
	        WebElement sortColumn = null;
	        String tableXpath = "";
	        
	        if(driver.findElements(By.xpath("//th[text()=' "+columnName+"']")).size()>0) {
	        	sortColumn = driver.findElement(By.xpath("//th[text()=' "+columnName+"']"));
	        	colName = driver.findElements(By.xpath("//tr[1]/th"));
	        	tableXpath = "//tbody//tr[1]";
	        	
	        }
	        
	        else if(driver.findElements(By.xpath("//cell-template/div[@title='" + columnName + "']")).size()>0) {
	        	sortColumn = driver.findElement(By.xpath("//cell-template/div[@title='"+columnName+"']"));
	        	colName = driver.findElements(By.xpath("//div[cell-template]"));
	        	tableXpath = "//standard-grid//div[2]/div/div[1]";
	        	
	        }
	        
	        else if(driver.findElements(By.xpath("//cell-template//div[@title='" + columnName + "']")).size()>0) {
	        	sortColumn = driver.findElement(By.xpath("//cell-template//div[@title='"+columnName+"']"));
	        	colName = driver.findElements(By.xpath("//div[cell-template]"));
	        	tableXpath = "//standard-grid//div[2]/div/div[1]";
	        	
	        }
	        else if(driver.findElements(By.xpath("//div/span[text()='"+columnName+"']")).size()>0) {	
	        	sortColumn = driver.findElement(By.xpath("//div/span[text()='"+columnName+"']"));
	        	colName = driver.findElements(By.xpath("//tr/th"));
	        	tableXpath = "//table//tr/th";
	        	
	        }
	        //Sort function
	        sortColumn.click();
	        Thread.sleep(3000);
	        sortColumn.click();
	        Thread.sleep(3000);
	        RC_Global.waitElementVisible(driver, 30, tableXpath, "Table xpath", endRun, false);
	        
	        for(WebElement col:colName)
	        {
	        	sColumnName = col.getText();
	             if(sColumnName.contains(columnName)) {
	                    return true;
	                }
	        }
	    }
		catch(NullPointerException npe) {
			queryObjects.logStatus(driver, Status.FAIL, "One or more columns/fields or the grid table itself are not available or empty", npe.getLocalizedMessage(), npe);
			if(endRun)
				endTestRun(driver);
		}
		catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver, Status.FAIL, "The columns/fields cannot be located", nse.getLocalizedMessage(), nse);
			if(endRun)
				endTestRun(driver);
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "The grid has not been loaded completely", te.getLocalizedMessage(), te);
			if(endRun)
				endTestRun(driver);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to verify the grid fields", e.getLocalizedMessage(), e);
			if(endRun)
				endTestRun(driver);
		}
        return false;
    }
	
	public static void verifySortFunction(WebDriver driver, String ColumnName,boolean endRun) throws Exception{

		RC_Global.createNode(driver, "Sort the "+ColumnName+" in Ascending/Desending Order");
		try {
			WebElement sortColumn = null;
			if(driver.findElements(By.xpath("//cell-template//div[@title='" + ColumnName + "']")).size()>0) 
		       	sortColumn = driver.findElement(By.xpath("//cell-template//div[@title='"+ColumnName+"']"));
			else if(driver.findElements(By.xpath("//div/span[text()='"+ ColumnName +"']")).size()>0) 
		       	sortColumn = driver.findElement(By.xpath("//div/span[text()='"+ ColumnName +"']"));
			sortColumn.click();
			Thread.sleep(2000);
			if(driver.findElements(By.xpath("//div[span[text()='"+ColumnName+"']]/i[contains(@class,'chevron-up')]")).size()>0)
				queryObjects.logStatus(driver, Status.PASS, "Verify Sort Functionality", "Column Sort - Ascending", null);
			else if(driver.findElements(By.xpath("//div[span[text()='"+ColumnName+"']]/i[contains(@class,'chevron-down')]")).size()>0)
				queryObjects.logStatus(driver, Status.PASS, "Verify Sort Functionality", "Column Sort - Descending", null);
	        Thread.sleep(3000);
	        sortColumn.click();
	        Thread.sleep(2000);
			if(driver.findElements(By.xpath("//div[span[text()='"+ColumnName+"']]/i[contains(@class,'chevron-up')]")).size()>0)
				queryObjects.logStatus(driver, Status.PASS, "Verify Sort Functionality", "Column Sort - Ascending", null);
			else if(driver.findElements(By.xpath("//div[span[text()='"+ColumnName+"']]/i[contains(@class,'chevron-down')]")).size()>0)
				queryObjects.logStatus(driver, Status.PASS, "Verify Sort Functionality", "Column Sort - Descending", null);
	        Thread.sleep(3000);	
        }
		catch(NullPointerException npe) {
			queryObjects.logStatus(driver, Status.FAIL, "One or more columns/fields or the grid table itself are not available or empty", npe.getLocalizedMessage(), npe);
			if(endRun)
				endTestRun(driver);
		}
		catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver, Status.FAIL, "The columns/fields cannot be located", nse.getLocalizedMessage(), nse);
			if(endRun)
				endTestRun(driver);
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "The grid has not been loaded completely", te.getLocalizedMessage(), te);
			if(endRun)
				endTestRun(driver);
		}
		catch(ElementNotInteractableException e) {
            queryObjects.logStatus(driver, Status.FAIL, "The column is not clickable", e.getLocalizedMessage(), e);
            if(endRun)
				endTestRun(driver);
        }
        catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to verify the grid fields", e.getLocalizedMessage(), e);
			if(endRun)
				endTestRun(driver);
		}
	}

	public static void verifyAsHyperlinkByLinkName(WebDriver driver,String HyperlinkFields,boolean endRun) throws Exception {
		try {
			
			WebElement element = null;
			String[] HyperlinkField = HyperlinkFields.split(";");
			String TagName ="";
			for(int i=0; i<HyperlinkField.length; i++ ) {
				Thread.sleep(2000);
				if(driver.findElements(By.xpath("//span[normalize-space(text())='"+HyperlinkField[i]+"']")).size()>0)
				{
					TagName = driver.findElement(By.xpath("//span[normalize-space(text())='"+HyperlinkField[i]+"']")).getText();
					if(TagName.equalsIgnoreCase(HyperlinkField[i]))
						queryObjects.logStatus(driver, Status.PASS, ""+TagName,"is Hyperlink " , null);
					else
						queryObjects.logStatus(driver, Status.FAIL, ""+TagName,"is Not Hyperlink " , null);
				}
				else if(driver.findElements(By.xpath("//label[normalize-space(text())='"+HyperlinkField[i]+"']")).size()>0)
                {
                    TagName = driver.findElement(By.xpath("//label[normalize-space(text())='"+HyperlinkField[i]+"']")).getText();
                    if(TagName.equalsIgnoreCase(HyperlinkField[i]))
                        queryObjects.logStatus(driver, Status.PASS, ""+TagName,"is Hyperlink " , null);
                    else
                        queryObjects.logStatus(driver, Status.FAIL, ""+TagName,"is Not Hyperlink " , null);
                }
				else if(driver.findElements(By.xpath("//button[normalize-space(text())='"+HyperlinkField[i]+"']")).size()>0)
                {
                    TagName = driver.findElement(By.xpath("//button[normalize-space(text())='"+HyperlinkField[i]+"']")).getText();
                    if(TagName.equalsIgnoreCase(HyperlinkField[i]))
                        queryObjects.logStatus(driver, Status.PASS, ""+TagName,"is Hyperlink " , null);
                    else
                        queryObjects.logStatus(driver, Status.FAIL, ""+TagName,"is Not Hyperlink " , null);
                }				
				else if(driver.findElements(By.xpath("//div[normalize-space(text())='"+HyperlinkField[i]+"']")).size()>0)
                {
                    TagName = driver.findElement(By.xpath("//div[normalize-space(text())='"+HyperlinkField[i]+"']")).getText();
                    if(TagName.equalsIgnoreCase(HyperlinkField[i]))
                        queryObjects.logStatus(driver, Status.PASS, ""+TagName,"is Hyperlink " , null);
                    else
                        queryObjects.logStatus(driver, Status.FAIL, ""+TagName,"is Not Hyperlink " , null);
                }
				
			}
			
		}
		catch(NullPointerException npe) {
			queryObjects.logStatus(driver, Status.FAIL, "One or more columns/fields or the grid table itself are not available or empty", npe.getLocalizedMessage(), npe);
			if(endRun)
				endTestRun(driver);
		}
		catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver, Status.FAIL, "The columns/fields cannot be located or is not a hyperlink", nse.getLocalizedMessage(), nse);
			if(endRun)
				endTestRun(driver);
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "The grid has not been loaded completely", te.getLocalizedMessage(), te);
			if(endRun)
				endTestRun(driver);
		}
		catch(ElementNotInteractableException e) {
            queryObjects.logStatus(driver, Status.FAIL, "The column/field is not clickable", e.getLocalizedMessage(), e);
            if(endRun)
				endTestRun(driver);
        }
        catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to verify the grid fields", e.getLocalizedMessage(), e);
			if(endRun)
				endTestRun(driver);
		}
	}
	
	public static void verifyFieldAsHyperLink(WebDriver driver, String ColumnName,boolean endRun) throws Exception{	
	    int ColumnNum = findColumnNumber(driver,ColumnName, endRun);
		boolean columnVerification = verifyGridFieldIsAvailable(driver, ColumnName, endRun);
		Thread.sleep(2000);
		try {
			if(columnVerification) {
				List<WebElement> ColHyp = null;
				
				if(driver.findElements(By.xpath("//tr[1]//td["+ColumnNum+"]//a[@href]")).size()>0)
					ColHyp = driver.findElements(By.xpath("//tr[1]//td["+ColumnNum+"]//a[@href]"));
				else if(driver.findElements(By.xpath("//div[div[@role='row']][2]//div[@role='gridcell']["+ColumnNum+"]//a[@href]")).size()>0)
					ColHyp = driver.findElements(By.xpath("//div[div[@role='row']][2]//div[@role='gridcell'][" + ColumnNum + "]//a[@href]"));
				else if(driver.findElements(By.xpath("//standard-grid//div[1]//span[contains(@id,'header-text')]["+ColumnNum+"]//a[@href]")).size()>0)
					ColHyp = driver.findElements(By.xpath("//standard-grid//div[1]//span[contains(@id,'header-text')]["+ColumnNum+"]//a[@href]"));
				else if(driver.findElements(By.xpath("(//table/tbody/tr[1]/td[2])[" + ColumnNum + "]")).size()>0)
					ColHyp = driver.findElements(By.xpath("(//table/tbody/tr[1]/td[2])[" + ColumnNum + "]"));																					 																				  
				if(ColHyp.size()>0)
				{
					queryObjects.logStatus(driver, Status.PASS, "Verify if field is displayed as a Hyperlink",ColumnName+" is displayed as hyperlink", null);
				}
				else
				{
					queryObjects.logStatus(driver, Status.FAIL, "Verify if field is displayed as a Hyperlink", ColumnName+" is not displayed as hyperlink", null);
				}
			}
			else
				queryObjects.logStatus(driver, Status.FAIL, ColumnName+" is not displayed","Failed", null);
		Thread.sleep(2000);
		}
		catch(NullPointerException npe) {
			queryObjects.logStatus(driver, Status.FAIL, "One or more columns/fields or the grid table itself are not available or empty", npe.getLocalizedMessage(), npe);
			if(endRun)
				endTestRun(driver);
		}
		catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver, Status.FAIL, "The columns/fields cannot be located or is not a hyperlink", nse.getLocalizedMessage(), nse);
			if(endRun)
				endTestRun(driver);
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "The grid has not been loaded completely", te.getLocalizedMessage(), te);
			if(endRun)
				endTestRun(driver);
		}
		catch(ElementNotInteractableException e) {
            queryObjects.logStatus(driver, Status.FAIL, "The column/field is not clickable", e.getLocalizedMessage(), e);
            if(endRun)
				endTestRun(driver);
        }
        catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to verify the grid fields", e.getLocalizedMessage(), e);
			if(endRun)
				endTestRun(driver);
		}
	}
	
	public static void screenNavigation(WebDriver driver, String string,boolean endRun) throws Exception{
		try {	
			switch(string) {
				case "back": driver.navigate().back(); break;
				case "forward": driver.navigate().forward(); break;
				case "refresh": driver.navigate().refresh(); break;
			}
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Screen Navigation Unsuccessful", string+" is not available or clickable", e);
			if(endRun)
				endTestRun(driver);
		}
	}

	public static void downloadAndVerifyFileDownloaded(WebDriver driver, String DwnFileNm,String CreateNodeMessage, boolean endRun) throws Exception {
		RC_Global.createNode(driver, CreateNodeMessage);
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		WebElement eElement = null;
			boolean isSel = true;		   
		try {
			boolean flag = false;
			String home = System.getProperty("user.home");
			File listofFiles = new File(home + "/Downloads/");
			WebDriverWait wait = new WebDriverWait(driver, 30);
			Thread.sleep(500);
		if(driver.findElements(By.xpath("//button[@label='EXCEL']")).size()>0)
		eElement = driver.findElement(By.xpath("//button[@label='EXCEL']"));

		else if(driver.findElements(By.xpath("//button[contains(@ng-click,'exportToExcel()')]")).size()==1)
		eElement = driver.findElement(By.xpath("//button[contains(@ng-click,'exportToExcel()')]"));
		
		else if(driver.findElements(By.xpath("(//button[contains(@ng-click,'exportToExcel()')])[1]")).size()==1)
            eElement = driver.findElement(By.xpath("(//button[contains(@ng-click,'exportToExcel()')])[1]"));

		else if(driver.findElements(By.xpath("(//button[contains(@ng-click,'exportToExcel()')])[6]")).size()>0)
		eElement = driver.findElement(By.xpath("(//button[contains(@ng-click,'exportToExcel()')])[6]"));
		
		else if(driver.findElements(By.xpath("(//button[@ng-click='exportToExcel()'])[1]")).size()>0)
            eElement = driver.findElement(By.xpath("(//button[@ng-click='exportToExcel()'])[1]"));

		else if(driver.findElements(By.xpath("(//button[@ng-click='exportToExcel()'])[1]")).size()>0)
		eElement = driver.findElement(By.xpath("(//button[@ng-click='exportToExcel()'])[1]"));
		
		else if(driver.findElements(By.xpath("//button[text()='Maintenance RO History']")).size()>0)
			eElement = driver.findElement(By.xpath("//button[text()='Maintenance RO History']"));
		
		else if(driver.findElements(By.xpath("//button[text()='Download PDF']")).size()>0)
			eElement = driver.findElement(By.xpath("//button[text()='Download PDF']"));		

		else if(driver.findElements(By.xpath("(//button[@ng-click='exportToExcel()'])[2]")).size()>0)
		eElement = driver.findElement(By.xpath("(//button[@ng-click='exportToExcel()'])[2]"));

		else if(driver.findElements(By.xpath("//button[@ng-show='displayExcelButton']")).size()>0)
		eElement = driver.findElement(By.xpath("//button[@ng-show='displayExcelButton']"));

		else if(driver.findElements(By.xpath("//button[text()=' Open ']")).size()>0)
		eElement = driver.findElement(By.xpath("//button[text()=' Open ']"));

		else if(driver.findElements(By.xpath("//standard-grid[@ng-if='!vm.denyAccess']//button[contains(@ng-click,'vm.exportToExcel')]")).size()>0)
		eElement = driver.findElement(By.xpath("//standard-grid[@ng-if='!vm.denyAccess']//button[contains(@ng-click,'vm.exportToExcel')]"));
        else {
			queryObjects.logStatus(driver, Status.FAIL, "Element is not available", "", null);
			isSel = false;
		}
		if (isSel) { 
			executor.executeScript("arguments[0].click();", eElement);

			Thread.sleep(5000);
			// Check for the files available
			for (File file : listofFiles.listFiles()) {
				String filename = file.getName();
				if (filename.contains(DwnFileNm)) {
					flag = true;
					file.delete();
					break;
				}
			}
			if (flag)
				queryObjects.logStatus(driver, Status.PASS, "" + CreateNodeMessage + "", "Successfully", null);
			else
				queryObjects.logStatus(driver, Status.FAIL, ""+CreateNodeMessage+"", "Failed", null);
		}
   
		}
		catch(ElementNotInteractableException enie) {
		        queryObjects.logStatus(driver, Status.FAIL, "Download and verify failed -> Failed to click on the button to download", enie.getLocalizedMessage(),enie);
			if (endRun)
				endTestRun(driver);
		} catch (TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "Download and verify failed -> The button has not loaded",te.getLocalizedMessage(), te);
			if (endRun)
				endTestRun(driver);
		} catch (Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Download and verify failed", e.getLocalizedMessage(), e);
			if (endRun)
				endTestRun(driver);
		}
	}
	
	
	public static void buttonVisibilityStatus(WebDriver driver, String ButtonName,boolean endRun) throws Exception { //Check with Yashodha for Exception
		try {	
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("window.scrollTo(0,-800)");
			Thread.sleep(2000);
			  List<WebElement> DisSlctordr= driver.findElements(By.xpath("//button[@disabled and @label='"+ButtonName+"']"));
			  List<WebElement> DisSlctordr1= driver.findElements(By.xpath("(//button[@disabled and text()='" +ButtonName+ "'])[1]"));
			  if(DisSlctordr.size()>0)
				  queryObjects.logStatus(driver, Status.PASS, "Select Order button is present and is Disabled by default.","", null);
			  else if(DisSlctordr1.size()>0)
				  queryObjects.logStatus(driver, Status.PASS, "Select Order button is present and is Disabled by default.","", null);
			  else 
				  queryObjects.logStatus(driver, Status.FAIL, "Select Order' button is not present and is Disabled by default.","Failed", null);
				
			  
			  driver.findElement(By.xpath("//tbody//tr[1]")).click();
			  Thread.sleep(2000);
			  List<WebElement> SlctOrdrbttn= driver.findElements(By.xpath("//button[@label='"+ButtonName+"']"));
			  if(SlctOrdrbttn.size()>0)
				  queryObjects.logStatus(driver, Status.PASS, "Select Order button gets ENABLED when any record is selected.","", null);
			  else
				  queryObjects.logStatus(driver, Status.FAIL, "Select Order button didnot gets ENABLED when any record is selected.","Failed", null);
				
			  Thread.sleep(2000);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "", "", e);
			if(endRun)
				endTestRun(driver);
		}
	}

	public static void selectOrderFun(WebDriver driver) throws Exception { //Used only in a Demo case - Order Management
		
		Thread.sleep(2000);
	    RC_Global.waitElementVisible(driver, 30, "//span[text()='Submit Order']", "Submit Order", false,false);
	    List<WebElement> Summarytab =  driver.findElements(By.xpath("//span[text()='Submit Order']"));
	    Thread.sleep(1000);
	  if(Summarytab.size()>0)
		  queryObjects.logStatus(driver, Status.PASS, "Summary Tab is displayed for the selected order.","Passed", null); 
	  else
		  queryObjects.logStatus(driver, Status.FAIL, "Summary Tab is not displayed for the selected order.","Failed", null);
		
	}
	
	public void waitUntilVisibility(WebDriver driver, String button,boolean endRun) throws Exception{
		try {	
			WebDriverWait wait = new WebDriverWait(driver,30);
		    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[normalize-space(text())='"+button+"']")));
		}
		catch(Exception e) {
			if(endRun)
				endTestRun(driver);
		}
	}
	
	public static void radioButton(WebDriver driver, String functionality,String radioBtnOption,boolean endRun) throws Exception {
		RC_Global.createNode(driver, "Select radio option ---> "+radioBtnOption);
		String xpath = radioSelection(functionality, radioBtnOption);
		try {
			if(!radioBtnOption.equalsIgnoreCase("")) {
				if(driver.findElements(By.xpath(xpath)).size()>0) {
					driver.findElement(By.xpath(xpath)).click();
				}
				else
					queryObjects.logStatus(driver, Status.FAIL, "The radio button does not exist", "Enter the valid radio button info", null);
	
			}
			else {
				driver.findElement(By.xpath("//table[1]/tbody/tr[1]/td/input")).click();
			}
		}
		catch(ElementNotInteractableException enie) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to select the radio button", enie.getLocalizedMessage(), enie);
			if(endRun)
				endTestRun(driver);
		}
		catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver, Status.FAIL, "The radio button does not exist", nse.getLocalizedMessage(), nse);
			if(endRun)
				endTestRun(driver);
		}
		catch(TimeoutException te) {			
			queryObjects.logStatus(driver, Status.FAIL, "Download and verify failed -> The button has not loaded", te.getLocalizedMessage(),te);
			if(endRun)
				endTestRun(driver);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Failed to select the Radio Button", e.getLocalizedMessage(), e);
			if(endRun)
				endTestRun(driver);
		}
	}
	
	public static String radioSelection(String functionality, String radioBtnOption) { //Method supporting radioButton() method
		switch(functionality) {
			case "OrderSelection":
				return "//label[text()='"+radioBtnOption+"']/input[@type='radio']";
			case "Pricing":
				return "//label[text()=' "+radioBtnOption+" ']/input[@type='radio']";
			case "Trim":
				return "//tr[td[div[text()='"+radioBtnOption+"']]]/td[1]/input[@type='radio']";
			case "Terminate Card":
				return "(//div[text()='"+radioBtnOption+" ']/input)[1]";
			case "Terminate Vehicle":
				return "//div[label[text()='"+radioBtnOption+"']]/input";
			case "Mailing Information":
				return "(//label[text()='"+radioBtnOption+" ']/input)[1]";
			case "Create Employee":
				return "//div[label[text()='"+radioBtnOption+"']]/preceding-sibling::div[1]/input";
		}
		return null;
	}
	
	public static void selectDropdownOption(WebDriver driver, String idOrText,String option,boolean endRun, boolean createND) throws Exception{
		if(createND)
		createNode(driver, "Select from: '" +idOrText+ "' DD, Option-->"+option);
		Thread.sleep(2000);
		String xpath = "";//selectionXpath(driver,functionality);
		try {
			if(driver.findElements(By.xpath("//select[@id='"+idOrText+"']")).size()>0)
				xpath = "//select[@id='"+idOrText+"']";
			else if(driver.findElements(By.xpath("//label[text()='"+idOrText+"']/following-sibling::select")).size()>0)
				xpath = "//label[text()='"+idOrText+"']/following-sibling::select";
			else if(driver.findElements(By.xpath("//label[contains(text(),'"+idOrText+"')]/following-sibling::div/select")).size()>0) //fuel
                xpath = "//label[contains(text(),'"+idOrText+"')]/following-sibling::div/select";
			else if(driver.findElements(By.xpath("(//div[div[label[text()='"+idOrText+" ']]]/div/select)[1]")).size()>0)
				xpath = "(//div[div[label[text()='"+idOrText+" ']]]/div/select)[1]";
			else if(driver.findElements(By.xpath("//div[div[label[text()='"+idOrText+" ']]]/div/select")).size()>0)
				xpath = "//div[div[label[text()='"+idOrText+" ']]]/div/select";
			else if(driver.findElements(By.xpath("//span[text()=' "+idOrText+" ']/select")).size()>0)
				xpath = "//span[text()=' "+idOrText+" ']/select";
			else if(driver.findElements(By.xpath("//select[@name='"+idOrText+"']")).size()>0)
				xpath = "//select[@name='"+idOrText+"']";
			else if(driver.findElements(By.xpath("//select[contains(@id,'"+idOrText+"')]")).size()>0)
				xpath = "//select[contains(@id,'"+idOrText+"')]";
			else if(driver.findElements(By.xpath("//select[contains(@ng-model,'"+idOrText+"')]")).size()>0)
                xpath = "//select[contains(@ng-model,'"+idOrText+"')]";
			
			driver.findElement(By.xpath(xpath)).click();
			waitElementVisible(driver, 10, xpath+"/option", idOrText+" Options", true,false); //Wait Options are available in DropDown to select
			driver.findElement(By.xpath(xpath+"/option[text()='"+option+"']")).click();
			Thread.sleep(2000);
		}
		catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver, Status.FAIL, "Failed to select "+option+" -> Unable to find "+option, nse.getLocalizedMessage(), nse);
			if(endRun)
				endTestRun(driver);
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "Failed to select "+option+" -> Unable to load/locate "+option, te.getLocalizedMessage(), te);
			if(endRun)
				endTestRun(driver);
		}
		catch(ElementNotInteractableException enie) {
			queryObjects.logStatus(driver, Status.FAIL, "Failed to select "+option+" -> Unable to click "+option, enie.getLocalizedMessage(), enie);
			if(endRun)
				endTestRun(driver);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Failed to select "+option, e.getLocalizedMessage(), e);
			if(endRun)
				endTestRun(driver);
		}
	}
	
	public static String database(String Sql) throws SQLException {
        String cn=null;
        String Env=Cred.ENV;
        try {
               
               Thread.sleep(3000);
               String Con="";
               Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");    
               switch(Env)
               {
               case "QA":
               case "OC5QA":
                     Con = ConnectionToDB.QaConn;
                     break; 
               case "UAT":
            	     Con = ConnectionToDB.UatConn;
                     break; 
               case "DEV":
            	     Con = ConnectionToDB.DevConn;
                     break;
               case "PROD":
            	     Con = ConnectionToDB.ProdConn;
               }
               Connection conn = DriverManager.getConnection(Con);
               
               Statement sta = conn.createStatement();
        
               ResultSet rs = sta.executeQuery(Sql);
               while (rs.next()) {
                     cn=rs.getString("AccountName").toString();
//                     unitNum = rs.getString("UnitNumber");
//                     if (unitNum!=null && unitNum!="") {
//                    	 break;
//                     }                     
               }
        conn.close();
        Thread.sleep(5000); 
        }
        catch(Exception e) {
               e.printStackTrace();
               }
        return cn;
        
    }

	public static void panelAction(WebDriver driver, String action, String headerORXpath,boolean endRun,boolean createND)throws Exception {
		if(createND)  
		createNode(driver, "Panel Action-->"+action+" to be performed on -->"+headerORXpath);
		
		boolean isClick = true;				 
		String actionType = "";
		try {
		Thread.sleep(2000);
			switch(action) {
	            case "compress":
	            	actionType = action;
	                if(driver.findElement(By.xpath("//h5[span[text()='"+headerORXpath+"']]/i[contains(@class,'fa-compress') and @ng-click='maximize(panel)']")).isDisplayed()) {
	                    driver.findElement(By.xpath("//h5[span[text()='"+headerORXpath+"']]/i[contains(@class,'fa-compress') and @ng-click='maximize(panel)']")).click();
	                }
	                else if(driver.findElement(By.xpath("//h5[span[contains(text(),'"+headerORXpath+"')]]/i[contains(@class,'fa-compress') and @ng-click='maximize(panel)']")).isDisplayed())   {   
	                    driver.findElement(By.xpath("//h5[span[contains(text(),'"+headerORXpath+"')]]/i[contains(@class,'fa-compress') and @ng-click='maximize(panel)']")).click();
	                }
					  else { isClick = false; }					  
	                break;
	            case "expand":
	            	actionType = action;
	            	try {
	            		if(driver.findElement(By.xpath("//h5[span[text()='"+headerORXpath+"']]/i[contains(@class,'fa-expand') and @ng-click='maximize(panel)']")).isDisplayed())
		                    driver.findElement(By.xpath("//h5[span[text()='"+headerORXpath+"']]/i[contains(@class,'fa-expand') and @ng-click='maximize(panel)']")).click();
		                
		                else if(driver.findElement(By.xpath("//h5[span[contains(text(),'"+headerORXpath+"')]]/i[contains(@class,'fa-expand') and @ng-click='maximize(panel)']")).isDisplayed())      
		                    driver.findElement(By.xpath("//h5[span[contains(text(),'"+headerORXpath+"')]]/i[contains(@class,'fa-expand') and @ng-click='maximize(panel)']")).click();
					  else { isClick = false; }						  
		                break;
					} catch (Exception e) {
						if(driver.findElement(By.xpath("//h5[span[contains(text(),'"+headerORXpath+"')]]/i[contains(@class,'fa-expand') and @ng-click='maximize(panel)']")).isDisplayed())      
		                    driver.findElement(By.xpath("//h5[span[contains(text(),'"+headerORXpath+"')]]/i[contains(@class,'fa-expand') and @ng-click='maximize(panel)']")).click();
					  else { isClick = false; }						  
		                break;
					}
	                
	                
	            case "close":
	            	actionType = action;
	            	try {
	            		if(driver.findElement(By.xpath("//h5[span[text()='"+headerORXpath+"']]/i[@ng-click='closePanel()']")).isDisplayed())
	    	                driver.findElement(By.xpath("//h5[span[text()='"+headerORXpath+"']]/i[@ng-click='closePanel()']")).click();
	    	                
	    	                else if(driver.findElement(By.xpath("//h5[span[contains(text(),'"+headerORXpath+"')]]/i[@ng-click='closePanel()']")).isDisplayed())
	    	                    driver.findElement(By.xpath("//h5[span[contains(text(),'"+headerORXpath+"')]]/i[@ng-click='closePanel()']")).click();
	    					else { isClick = false; }					  
	    	                break;
					} catch (Exception e) {
						if(driver.findElement(By.xpath("//h5[span[contains(text(),'"+headerORXpath+"')]]/i[@ng-click='closePanel()']")).isDisplayed())
    	                    driver.findElement(By.xpath("//h5[span[contains(text(),'"+headerORXpath+"')]]/i[@ng-click='closePanel()']")).click();
    					else { isClick = false; }					  
    	                break;
					}
	            	
                case "xpathcompress":
                	actionType = "compress";
                    if(driver.findElement(By.xpath(headerORXpath+"/i[contains(@class,'fa-compress') and @ng-click='maximize(panel)']")).isDisplayed())
                        driver.findElement(By.xpath(headerORXpath+"/i[contains(@class,'fa-compress') and @ng-click='maximize(panel)']")).click();
					 else { isClick = false; }						 
                    break;
                case "xpathexpand":
                	actionType = "expand";
                    if(driver.findElement(By.xpath(headerORXpath+"/i[contains(@class,'fa-expand') and @ng-click='maximize(panel)']")).isDisplayed())
                        driver.findElement(By.xpath(headerORXpath+"/i[contains(@class,'fa-expand') and @ng-click='maximize(panel)']")).click();
					else { isClick = false; }						 
                    break;
                case "xpathclose":
                	actionType = "close";
                	try {
                		if(driver.findElement(By.xpath(headerORXpath+"/i[@ng-click='closePanel()']")).isDisplayed())
                            driver.findElement(By.xpath(headerORXpath+"/i[@ng-click='closePanel()']")).click();
                        else if(driver.findElement(By.xpath(headerORXpath+"//i[@ng-click='closePanel()']")).isDisplayed())
    	                    driver.findElement(By.xpath(headerORXpath+"//i[@ng-click='closePanel()']")).click();
    											 
    	                break;
					} catch (Exception e) {
						if(driver.findElement(By.xpath(headerORXpath+"//i[@ng-click='closePanel()']")).isDisplayed())
    	                    driver.findElement(By.xpath(headerORXpath+"//i[@ng-click='closePanel()']")).click();
    											 
    	                break;
					} 
	            }
				if (isClick) {
					Thread.sleep(3000);
				} else { queryObjects.logStatus(driver, Status.INFO, "No action performed", "May be element already in the "+actionType+" state", null); }
	        	
	    		//queryObjects.logStatus(driver, Status.INFO, "Panel Action to be performed", "Panel Action Successful", null);
		}
		catch(ElementNotInteractableException enie) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to click on the "+actionType+" icon", enie.getLocalizedMessage(), enie);
			if(endRun)
				endTestRun(driver);
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to locate the "+actionType+" icon", te.getLocalizedMessage(), te);
			if(endRun)
				endTestRun(driver);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to "+actionType+" the panel", e.getLocalizedMessage(), e);
			if(endRun)
				endTestRun(driver);
		}
	}
    
	public static void checkSuccessMessage(WebDriver driver, String SuccessMessage,boolean endRun) throws Exception {
    	RC_Global.createNode(driver, "SuccessMessage-Displayed-->"+SuccessMessage);
		
    	List<WebElement> elements = null;
        boolean errorPresent = false;
        try {   
                elements = driver.findElements(By.xpath("//div[@ng-show='vm.showSuccessfulSave']//h4["+SuccessMessage+"]"));
       
            if(elements.size()>0) {
                queryObjects.logStatus(driver, Status.PASS, "Success message to be verified", "The following Message has been verified: "+SuccessMessage, null);
                errorPresent=true;
            }
        }
        catch(NullPointerException npe) {
            queryObjects.logStatus(driver, Status.FAIL, "Success message was not verified -> The following Message : "+SuccessMessage+" is not present on the screen", npe.getLocalizedMessage(), npe);
            if(endRun)
				endTestRun(driver);
        }
        catch(TimeoutException te) {
            queryObjects.logStatus(driver, Status.FAIL, "Success message was not verified -> The following Message : "+SuccessMessage+" failed to display on the screen", te.getLocalizedMessage(), te);
            if(endRun)
				endTestRun(driver);
        }
        catch(Exception e) {
            queryObjects.logStatus(driver, Status.FAIL, "Success message was not verified -> The following Message : "+SuccessMessage+" failed to display on the screen", e.getLocalizedMessage(), e);
            if(endRun)
				endTestRun(driver);
        }  
    }
	
	public static boolean verifyDisplayedMessage(WebDriver driver, String expectedMessage,boolean endRun) throws Exception{
		List<WebElement> elements = null; List<WebElement> elements1 = null;
		boolean errorPresent = false;
		
		try {	
			try {
				elements = driver.findElements(By.xpath("//*[normalize-space(text())='"+expectedMessage+"']"));
			}
			catch(Exception e) {
				elements1 = driver.findElements(By.xpath("//*[normalize-space(text())=\""+expectedMessage+"\"]"));
			}
			if(elements1!=null && elements1.size()>0) {
				queryObjects.logStatus(driver, Status.INFO, "Message to be verified", "The following message has to be displayed: "+expectedMessage, null);
				errorPresent=true;
				if(elements1.size()==1) {
					if (driver.findElement(By.xpath("//*[normalize-space(text())=\""+expectedMessage+"\"]")).isDisplayed()) {
						queryObjects.logStatus(driver, Status.PASS, "Message to be verified -"+expectedMessage, "Message is displayed on the screen", null);
					} else {
						queryObjects.logStatus(driver, Status.FAIL, "Message to be verified -"+expectedMessage, "Message is not displayed on the screen", null);
					}
					//queryObjects.logStatus(driver, Status.INFO, "Message to be verified", "The following message has been verified: "+expectedMessage+" and is present once on the screen", null);
					return true;
				}
				else if(elements1.size()==2) {
					try {
						if (driver.findElement(By.xpath("(//*[normalize-space(text())=\""+expectedMessage+"\"])[1]")).isDisplayed()) {
							queryObjects.logStatus(driver, Status.PASS, "Message to be verified -"+expectedMessage, "Message is displayed on the screen", null);
						} else if (driver.findElement(By.xpath("(//*[normalize-space(text())=\""+expectedMessage+"\"])[2]")).isDisplayed()) {
							queryObjects.logStatus(driver, Status.PASS, "Message to be verified -"+expectedMessage, "Message is displayed on the screen", null);							
						} else {
							queryObjects.logStatus(driver, Status.FAIL, "Message to be verified -"+expectedMessage, "Message is not displayed on the screen", null);
						}
					} catch (Exception e) {
						try {
							if (driver.findElement(By.xpath("(//*[normalize-space(text())=\""+expectedMessage+"\"])[2]")).isDisplayed()) {
								queryObjects.logStatus(driver, Status.PASS, "Message to be verified -"+expectedMessage, "Message is displayed on the screen", null);
							}
						} catch (Exception e2) {
							queryObjects.logStatus(driver, Status.FAIL, "Message to be verified -"+expectedMessage, "Message is not displayed on the screen", null);
						}
					}
					//queryObjects.logStatus(driver, Status.INFO, "Message to be verified", "The following message has been verified: "+expectedMessage+" and is present twice on the screen", null);
					return true;
				}
			} else {
				if(elements.size()==1) {
					if (driver.findElement(By.xpath("//*[normalize-space(text())='"+expectedMessage+"']")).isDisplayed()) {
						queryObjects.logStatus(driver, Status.PASS, "Message to be verified -"+expectedMessage, "Message is displayed on the screen", null);
					} else {
						queryObjects.logStatus(driver, Status.FAIL, "Message to be verified -"+expectedMessage, "Message is not displayed on the screen", null);
					}
					//queryObjects.logStatus(driver, Status.INFO, "Message to be verified", "The following message has been verified: "+expectedMessage+" and is present once on the screen", null);
					return true;
				}
				else if(elements.size()==2) {
					try {
						if (driver.findElement(By.xpath("//*[normalize-space(text())='"+expectedMessage+"']")).isDisplayed()) {
							queryObjects.logStatus(driver, Status.PASS, "Message to be verified -"+expectedMessage, "Message is displayed on the screen", null);
						} else if (driver.findElement(By.xpath("(//*[normalize-space(text())=\""+expectedMessage+"\"])[2]")).isDisplayed()) {
							queryObjects.logStatus(driver, Status.PASS, "Message to be verified -"+expectedMessage, "Message is displayed on the screen", null);							
						} else {
							queryObjects.logStatus(driver, Status.FAIL, "Message to be verified -"+expectedMessage, "Message is not displayed on the screen", null);
						}
					} catch (Exception e) {
						try {
							if (driver.findElement(By.xpath("//*[normalize-space(text())='"+expectedMessage+"']")).isDisplayed()) {
								queryObjects.logStatus(driver, Status.PASS, "Message to be verified -"+expectedMessage, "Message is displayed on the screen", null);
							}
						} catch (Exception e2) {
							queryObjects.logStatus(driver, Status.FAIL, "Message to be verified -"+expectedMessage, "Message is not displayed on the screen", null);
						}
					}
					//queryObjects.logStatus(driver, Status.INFO, "Message to be verified", "The following message has been verified: "+expectedMessage+" and is present twice on the screen", null);
					return true;
				}
			}
		}
		catch(NullPointerException npe) {
			queryObjects.logStatus(driver, Status.FAIL, "Message was not verified -> The following error : "+expectedMessage+" is not present on the screen", npe.getLocalizedMessage(), npe);
			if(endRun)
				endTestRun(driver);
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "Message was not verified -> The following error : "+expectedMessage+" failed to display on the screen", te.getLocalizedMessage(), te);
			if(endRun)
				endTestRun(driver);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Message was not verified -> The following error : "+expectedMessage+" failed to display on the screen", e.getLocalizedMessage(), e);
			if(endRun)
				endTestRun(driver);
		}
		return errorPresent;
		
	}
	
	public static void selectOptionsFromMultipleSelectionSearchFilter(WebDriver driver, String multSelection, String selectionValue,boolean endRun) throws Exception{
		createNode(driver,"Select Multiple options from "+multSelection+" search filter");
		try {
			int flag = 0;
			int flags = 0;
			String[] sSelectionValue = new String[10];
			String[] ssSelectionValue = new String[20];
			
			String attributeType = "";
			
			if(selectionValue.contains(";")) {			//The selections of each multiSelection value is separated by ";" 
				sSelectionValue = selectionValue.split(";");
			}
			else {
				sSelectionValue[0] = selectionValue;
				flags = 1;
			}
			String multiSelection = new String();
			String[] aMultiSelection = new String[20];
			if(multSelection.contains(";")) {
				aMultiSelection = multSelection.split(";");
			}
			else {
				aMultiSelection[0] = multSelection;
				flag = 1;
			}
				
			for(int index=0; index<aMultiSelection.length;index++) {
				if(index==1 && flag==1)break;	
				multSelection = aMultiSelection[index];
				if(multSelection.equalsIgnoreCase("Vehicle Status")) {
					multiSelection = "vehicleStatus";
					attributeType = "id";
				}
					else if(multSelection.equalsIgnoreCase("Vehicle Status Advanced")) {   // added newly - 9/4/2021
					multiSelection = "vehicleStatusAdvanced";
					attributeType = "id";
				}																					   
				else if(multSelection.equalsIgnoreCase("Request Type")) {
					multiSelection = "requestType";
					attributeType = "id";
				}
				else if(multSelection.equalsIgnoreCase("Sale Status")) {
					multiSelection = "saleStatus";
					attributeType = "id";
				}
				else if(multSelection.equalsIgnoreCase("Agreement Type")) {
					multiSelection = "agreementType";
					attributeType = "id";
				}
				else if(multSelection.equalsIgnoreCase("3rd Party Inspection Required")) {
					multiSelection = "thirdPartyInspectionRequired";
					attributeType = "id";
				}
				else if(multSelection.equalsIgnoreCase("Select Available Groups")) {
					multiSelection = "selectedAvailableGroups";
					attributeType = "ng-model";
				}
				else if(multSelection.equalsIgnoreCase("Select Selected Groups")) {
					multiSelection = "selectedSelectedGroups";
					attributeType = "ng-model";
				}
				else if(multSelection.equalsIgnoreCase("Vehicle Status Advanced")) {
	                multiSelection = "vehicleStatusAdvanvanced";
	                attributeType = "id";
	            }
				else if(multSelection.equalsIgnoreCase("Customer Maintenance Program(s) Elected")) {
	                multiSelection = "enrollmentSelected";                                        
	                attributeType = "name";                                                      
	            }
				else if (multSelection.equalsIgnoreCase("Order Type ")) {
					multiSelection = "CustomerVehicleOrderProfileOrderTypeAssignments";
					attributeType = "name";
				} else if (multSelection.equalsIgnoreCase("courtesyDeliveryFees")) {
					multiSelection = "courtesyDeliveryFees";
					attributeType = "name";
				} else if (multSelection.equalsIgnoreCase("telematicsDeviceType")) {
					multiSelection = "telematicsDeviceType";
					attributeType = "name";
				}
				else if(multSelection.equalsIgnoreCase("Maintenance Agreement Type")) {
	                multiSelection = "maintenanceAgreemenType";                                        
	                attributeType = "name";                                                      
	            }
				else if(multSelection.equalsIgnoreCase("Card Type *")) {
					multiSelection = "Fuel Only";
					attributeType = "id";
				}
				
				else if(multSelection.equalsIgnoreCase("Acceptable Transaction Location(s) *")) {
					multiSelection = "Car Wash";
					attributeType = "id";
				}
				WebElement ele = null;//driver.findElement(By.xpath("//select[@"+attributeType+"='"+multiSelection+"']"));
				List<WebElement> lElem = new ArrayList<WebElement>();//driver.findElements(By.xpath("//select[@"+attributeType+"='"+multiSelection+"']/option"));
				
				if(driver.findElements(By.xpath("//select[@"+attributeType+"='"+multiSelection+"']")).size()>0) {
					ele = driver.findElement(By.xpath("//select[@"+attributeType+"='"+multiSelection+"']"));
					lElem = driver.findElements(By.xpath("//select[@"+attributeType+"='"+multiSelection+"']/option"));
				}
				else if(driver.findElements(By.xpath("//div[label[text()='"+multSelection+":']]//select")).size()>0) {
					ele = driver.findElement(By.xpath("//div[label[text()='"+multSelection+":']]//select"));
					lElem = driver.findElements(By.xpath("//div[label[text()='"+multSelection+":']]//select/option"));
				}
				else if(driver.findElements(By.xpath("//div[label[text()='"+multSelection+"']]//select")).size()>0) {
					ele = driver.findElement(By.xpath("//div[label[text()='"+multSelection+"']]//select"));
					lElem = driver.findElements(By.xpath("//div[label[text()='"+multSelection+"']]//select/option"));
				}
				
				Select iSelectionValue = new Select(ele);
				iSelectionValue = new Select(ele);
				
				
				if(driver.findElements(By.xpath("//select[@"+attributeType+"='"+multiSelection+"']/option[@value][1]")).size()>0)
					driver.findElement(By.xpath("//select[@"+attributeType+"='"+multiSelection+"']/option[@value][1]")).click();
				else if(driver.findElements(By.xpath("//div[label[text()='"+multSelection+":']]//select/option[@value][1]")).size()>0)
					driver.findElement(By.xpath("//div[label[text()='"+multSelection+":']]//select/option[@value][1]")).click();
				else if(driver.findElements(By.xpath("//div[label[text()='"+multSelection+"']]//select/option[@value][1]")).size()>0)
					driver.findElement(By.xpath("//div[label[text()='"+multSelection+"']]//select/option[@value][1]")).click();

				iSelectionValue.deselectAll();
				
				JavascriptExecutor executor = (JavascriptExecutor)driver;
					   Thread.sleep(1000);
				executor.executeScript("document.body.style.zoom = '30%'");
					   Thread.sleep(2000);
				executor.executeScript("document.body.style.zoom = '100%'");
				ssSelectionValue = new String[20];
				if(sSelectionValue[index].contains("--")) {			//The selections within each multiSelection value is separated by "," 
					ssSelectionValue = sSelectionValue[index].split("--");
				}
				else {
					ssSelectionValue[0] = sSelectionValue[index];
				}
				
				for(int iter=0;iter<ssSelectionValue.length;iter++) {
					if(!sSelectionValue[index].contains("--")&&iter==1) break;
					for(int i=0;i<lElem.size();i++){
						if(iSelectionValue.isMultiple()) {
							if(ssSelectionValue[iter].equalsIgnoreCase(lElem.get(i).getText())) { 
								iSelectionValue.selectByVisibleText(ssSelectionValue[iter]);
								queryObjects.logStatus(driver, Status.INFO, "Vehicle Status", ssSelectionValue[iter], null);
								break;
							}
						} 
					}
				}
			}
		}
		catch(NullPointerException npe) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to select the required options -> The expected options are not present in the selection box - Verify the xpath", npe.getLocalizedMessage(), npe);
			if(endRun)
				endTestRun(driver);
		}
		catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to select the required options -> The expected options are not present in the selection box.", nse.getLocalizedMessage(), nse);
			if(endRun)
				endTestRun(driver);
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to select the required options -> The expected options were not selected", te.getLocalizedMessage(), te);
			if(endRun)
				endTestRun(driver);
		}
		catch(ElementNotInteractableException enie) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to select the required options -> The expected options could not be selected", enie.getLocalizedMessage(), enie);
			if(endRun)
				endTestRun(driver);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to select the required options", e.getLocalizedMessage(), e);
			if(endRun)
				endTestRun(driver);
		}
	}

	public static void buttonStatusValidation(WebDriver driver, String ButtonName, String ButtnStatus,boolean endRun)throws Exception {
		try {
		    switch (ButtnStatus) {
		    case "Enable":
		    	List<WebElement> ButtonEn = driver.findElements(By.xpath("//button[normalize-space(text())='"+ButtonName+"']"));
		    	List<WebElement> Toggle = driver.findElements(By.xpath("(//button[text()='"+ButtonName+"'])[2]"));
		    	List<WebElement> Toggle1 = driver.findElements(By.xpath("//label[text()='"+ButtonName+"']"));    
		    	List<WebElement> Toggle2 = driver.findElements(By.xpath("//button[text()='"+ButtonName+"']"));	 
		    	
				if(ButtonEn.size()>0) 
					queryObjects.logStatus(driver,Status.INFO,""+ButtonName+" Button is", "Enabled", null);
				else if(Toggle.size()>0)
		            queryObjects.logStatus(driver,Status.INFO,""+ButtonName+" Toggle is ", "Enabled", null);
				else if(Toggle1.size()>0)
					queryObjects.logStatus(driver,Status.INFO,""+ButtonName+" Toggle is ", "Enabled", null);
				else if(Toggle2.size()>0) 
					queryObjects.logStatus(driver,Status.INFO,""+ButtonName+" Button is", "Enabled", null);
				
			break;
		    case "Disable":		
			    List<WebElement> ButtonD = driver.findElements(By.xpath("//button[(text()='"+ButtonName+"') and (@disabled = 'disabled')]"));
			    if(ButtonD.size()>0) 
						queryObjects.logStatus(driver,Status.INFO,""+ButtonName+" Button is", "Disabled", null);
			break;
		    case "Presence":
		    	List<WebElement> Button1 = driver.findElements(By.xpath("//button[text()='"+ButtonName+"']"));
			    if(Button1.size()>0) 
						queryObjects.logStatus(driver,Status.INFO,""+ButtonName+" Button is", "Present", null);
			    break;	
		    default:
		    	List<WebElement> Button = driver.findElements(By.xpath("//button[normalize-space((text())='"+ButtonName+"') and (contains(@ng-disabled, 'disableEdit(row.entity.POStatus)'))]"));
		    	Thread.sleep(2000);
		    	if(Button.size()>0)
		    		queryObjects.logStatus(driver,Status.INFO,""+ButtonName+" Button is", "Enabled", null);
		    	else
		    		queryObjects.logStatus(driver,Status.INFO,""+ButtonName+" Button is", "Disabled", null);
		    	break;
		    }		
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver,Status.FAIL,"Button Status Validation Failed -> Unable to verify the button status", te.getLocalizedMessage(), te);
			if(endRun)
				endTestRun(driver);
		}
		catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver,Status.FAIL,"Button Status Validation Failed -> The button could not be found", nse.getLocalizedMessage(), nse);
			if(endRun)
				endTestRun(driver);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver,Status.FAIL,"Button Status Validation Failed", e.getLocalizedMessage(), e);
			if(endRun)
				endTestRun(driver);
		}
	}
	
	public void moveSelectedOptionFromOneSelectionBoxToAnother(WebDriver driver, String sAddorRemove, String label,String Selection,boolean endRun) throws Exception {//addremove...
		 try
		  {
			String str1 = "";
			String str2 = "";
			String attributeValue = "";
			
			if(label.equalsIgnoreCase("Select Available Groups")) {
				attributeValue = "selectedAvailableGroups";
			}
			else if(label.equalsIgnoreCase("Select Selected Groups")) {
				attributeValue = "selectedSelectedGroups";
			}
			
			if(sAddorRemove.equalsIgnoreCase("Add")) {
				if(Selection.equalsIgnoreCase("")) {
					str1 = driver.findElement(By.xpath("//div/select[@ng-model='"+attributeValue+"']/option[1]")).getText();
					str2 = driver.findElement(By.xpath("//div/select[@ng-model='"+attributeValue+"']/option[3]")).getText();
					Selection = str1+"--"+str2;
					
				}
				selectOptionsFromMultipleSelectionSearchFilter(driver, label, Selection, endRun);
				driver.findElement(By.xpath("//button[text()='Add >>']")).click();
			}
			else if(sAddorRemove.equalsIgnoreCase("Remove")) {
				if(Selection.equalsIgnoreCase("")) {
					if(driver.findElements(By.xpath("//div/select[@ng-model='"+attributeValue+"']/option[1]")).size()>0) {
						str1 = driver.findElement(By.xpath("//div/select[@ng-model='"+attributeValue+"']/option[1]")).getText();
						Selection = str1;
					}
					else if(driver.findElements(By.xpath("//div/select[@ng-model='"+attributeValue+"']/option[2]")).size()>0) {
						str1 = driver.findElement(By.xpath("//div/select[@ng-model='"+attributeValue+"']/option[1]")).getText();
						str2 = driver.findElement(By.xpath("//div/select[@ng-model='"+attributeValue+"']/option[2]")).getText();
						Selection = str1+"--"+str2;
					}
				}
				selectOptionsFromMultipleSelectionSearchFilter(driver, label, Selection, endRun);
			driver.findElement(By.xpath("//button[text()='<< Remove']")).click();
			}
			Thread.sleep(3000);
			queryObjects.logStatus(driver, Status.PASS, "Add/Remove Options", "Options added/removed successfully", null);

		  }
		 catch(TimeoutException te) {
				queryObjects.logStatus(driver,Status.FAIL,"Failed to add or remove options -> Unable to add/remove or move options from one selection box to another", te.getLocalizedMessage(), te);
				if(endRun)
					endTestRun(driver);
		}
		catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver,Status.FAIL,"Failed to add or remove options -> Unable to locate options to be added, removed or moved", nse.getLocalizedMessage(), nse);
			if(endRun)
				endTestRun(driver);
		}
		 catch(NullPointerException npe) {
				queryObjects.logStatus(driver,Status.FAIL,"Failed to add or remove options -> Unable to locate options to be added, removed or moved", npe.getLocalizedMessage(), npe);
				if(endRun)
					endTestRun(driver);
			}
		catch(Exception e) {
			queryObjects.logStatus(driver,Status.FAIL,"Failed to add or remove options", e.getLocalizedMessage(), e);
			if(endRun)
				endTestRun(driver);
		}
	}

	public static void validateSpecifiedSearchFilters(WebDriver driver, String searchFilters,boolean endRun) throws Exception {
	
		try {
			createNode(driver,"Validate Search Filters Names");
			Thread.sleep(1000);
			String[] FilterName = searchFilters.split(";");
			String FilterNam = null; boolean isAvail = true;
			for(int i=0; i< FilterName.length; i++) {
				FilterNam =""; isAvail = true;				  
				if(driver.findElements(By.xpath("//label[normalize-space(text())='"+FilterName[i]+"']")).size()>0)
					FilterNam = driver.findElement(By.xpath("//label[normalize-space(text())='"+FilterName[i]+"']")).getText();
				else if(driver.findElements(By.xpath("//label[contains(text(),'"+FilterName[i]+"')]")).size()>0)
	                FilterNam = driver.findElement(By.xpath("//label[contains(text(),'"+FilterName[i]+"')]")).getText();
				else if(driver.findElements(By.xpath("//span[normalize-space(text())='"+FilterName[i]+"']")).size()>0)
	                FilterNam = driver.findElement(By.xpath("//span[normalize-space(text())='"+FilterName[i]+"']")).getText();
				else if(driver.findElements(By.xpath("//span[contains(text(),'"+FilterName[i]+"')]")).size()>0)
	                FilterNam = driver.findElement(By.xpath("//span[contains(text(),'"+FilterName[i]+"')]")).getText();
				else if(driver.findElements(By.xpath("//button[normalize-space(text())='"+FilterName[i]+"']")).size()>0)
	                FilterNam = driver.findElement(By.xpath("//button[normalize-space(text())='"+FilterName[i]+"']")).getText();
				
				if(FilterName[i].contains(FilterNam)) 
					queryObjects.logStatus(driver,Status.INFO,"Filter field(s) "+FilterName[i]+" is ", "displayed", null);
				else if(FilterNam.contains(FilterName[i]))		
					queryObjects.logStatus(driver,Status.INFO,"Filter field(s) "+FilterName[i]+" is ", "displayed", null);
				else if(FilterNam.equalsIgnoreCase(FilterName[i]))		
					queryObjects.logStatus(driver,Status.INFO,"Filter field(s) "+FilterName[i]+" is ", "displayed", null);
				else {
																										   
														
																														   
		
					queryObjects.logStatus(driver,Status.FAIL,"Filter field(s) "+FilterName[i]+" is ", "Not displayed", null);
					isAvail = false;
				}
				 
				if (isAvail) {
					if(FilterName[i].contains(FilterNam)) 
						queryObjects.logStatus(driver,Status.INFO,"Filter field(s) "+FilterName[i]+" is ", "displayed", null);
					else if(FilterNam.contains(FilterName[i]))		
						queryObjects.logStatus(driver,Status.INFO,"Filter field(s) "+FilterName[i]+" is ", "displayed", null);
					else if(FilterNam.equalsIgnoreCase(FilterName[i]))		
						queryObjects.logStatus(driver,Status.INFO,"Filter field(s) "+FilterName[i]+" is ", "displayed", null);
					else
						queryObjects.logStatus(driver,Status.FAIL,"Filter field(s) "+FilterName[i]+" is ", "Not displayed", null);
				Thread.sleep(1000);
				}				
			}
		}
		catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver,Status.FAIL,"Search Filter Validation Failed -> The Search Field(s) is/ are not available", nse.getLocalizedMessage(), nse);
			if(endRun)
				endTestRun(driver);
		}
		catch(NullPointerException npe) {
			queryObjects.logStatus(driver,Status.FAIL,"Search Filter Validation Failed -> The Search Field(s) or the respective label is/are not available", npe.getLocalizedMessage(), npe);
			if(endRun)
				endTestRun(driver);
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver,Status.FAIL,"Search Filter Validation Failed -> The Search Field(s) is/ are not available", te.getLocalizedMessage(), te);
			if(endRun)
				endTestRun(driver);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver,Status.FAIL,"Search Filter Validation Failed", e.getLocalizedMessage(), e);
			if(endRun)
				endTestRun(driver);
		}
	}
	
	public static void validateMultipleSelectionFilter(WebDriver driver, String SelectionOptions,boolean endRun)throws Exception {
        
		createNode(driver,"Validate MultiSelect Filter Options");
		
		try {
			String[] SelectionOption = SelectionOptions.split(";");
			String SelectionOption1 = null; 
			for(int i=0; i< SelectionOption.length; i++) {
			SelectionOption1 = driver.findElement(By.xpath("//option[normalize-space(text())='"+SelectionOption[i]+"']")).getText();
			
			if(SelectionOption[i].contains(SelectionOption1)) 
				queryObjects.logStatus(driver,Status.INFO,"Multiple Selection field "+SelectionOption[i]+" is ", "displayed", null);
			else if(SelectionOption1.contains(SelectionOption[i]))		
				queryObjects.logStatus(driver,Status.INFO,"Multiple Selection field"+SelectionOption[i]+" is ", "displayed", null);
			else
				queryObjects.logStatus(driver,Status.FAIL,"Multiple Selection field "+SelectionOption[i]+" is ", "Notdisplayed", null);

			}
		}
		catch(NullPointerException npe) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to find the required options -> The expected options are not present in the selection box - Verify the xpath", npe.getLocalizedMessage(), npe);
			if(endRun)
				endTestRun(driver);
		}
		catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to find the required options -> The expected options are not present in the selection box.", nse.getLocalizedMessage(), nse);
			if(endRun)
				endTestRun(driver);
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to find the required options -> The expected options were not validated", te.getLocalizedMessage(), te);
			if(endRun)
				endTestRun(driver);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to find the required options", e.getLocalizedMessage(), e);
			if(endRun)
				endTestRun(driver);
		}
	}
  
	public static void clickUsingXpath(WebDriver driver, String xpathExpression,String XpathName,boolean endRun, boolean createND) throws Exception{
		if(createND)
			createNode(driver, "Click Element Using Xpath-->"+XpathName);
		
		try {
			WebDriverWait wait = new WebDriverWait(driver,30);
			Thread.sleep(3000);
			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath(xpathExpression))));
			driver.findElement(By.xpath(xpathExpression)).click();
			queryObjects.logStatus(driver, Status.PASS, "Click the "+XpathName+" xpath", "Clicked Successfully", null);
		}
		catch(ElementNotInteractableException e) {
            queryObjects.logStatus(driver, Status.FAIL, "The xpath expected to be clicked on, is not clickable", e.getLocalizedMessage(), e);
        	if(endRun)
				endTestRun(driver);
        }
        catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver, Status.FAIL, "The xpath could not be clicked on -> Unable to find the xpath", nse.getLocalizedMessage(), nse);
			if(endRun)
				endTestRun(driver);
        }
        catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "The xpath could not be clicked on -> It did not appear on the screen", te.getLocalizedMessage(), te);
			if(endRun)
				endTestRun(driver);
		}
        catch(Exception e) {
            queryObjects.logStatus(driver, Status.FAIL, "The xpath could not be clicked on", e.getLocalizedMessage(), e);
        	if(endRun)
				endTestRun(driver);
        }
	}
	
	
	public static void verifyScreenComponents(WebDriver driver, String sectionType, String sectionToVerify,boolean endRun) throws Exception{
		try {
			switch(sectionType) {
				case "lable": 
 					String strValue ="";
					String strXpath =sectionToVerify;
					String strXpath1 =sectionToVerify;
					String strXpath2 =sectionToVerify;
		            int intQuotesPos=0;
		            if (sectionToVerify.contains("'"))
		            {
		                   intQuotesPos = sectionToVerify.indexOf("'");
		                   strXpath = strXpath.substring(0, intQuotesPos-1);
		                   strXpath = "//label[contains(text(),'"+strXpath+"')]";
		                   
		            }
		            else
		            {
		                   strXpath ="//label[text()='"+sectionToVerify+"']";		                   
		            }
		          if(driver.findElements(By.xpath(strXpath)).size()>0) 
		            {
		                 if(driver.findElements(By.xpath("//div"+strXpath+"/../following-sibling::div/span")).size()>0)
		                 {
		                        strValue = driver.findElement(By.xpath("//div"+strXpath+"/../following-sibling::div/span")).getText();
		                        if(strValue.length()==0)
		                        {
		                               queryObjects.logStatus(driver, Status.PASS, "To verify label "+sectionToVerify+" is available with ", "empty value", null);
		                        }
		                        else
		                        {
		                               queryObjects.logStatus(driver, Status.PASS, "To verify label "+sectionToVerify+" is available with value ", strValue, null);
		                        }
		                 }  
		         
		                 else if(driver.findElements(By.xpath("//div"+strXpath+"/../following-sibling::div/button")).size()>0)
		                 {
		                        strValue = driver.findElement(By.xpath("//div"+strXpath+"/../following-sibling::div/button")).getText();
		                        if(strValue.length()==0)
		                               {
		                                      queryObjects.logStatus(driver, Status.PASS, "To verify label "+sectionToVerify+" is available with ", "empty value", null);
		                               }
		                               else
		                               {
		                                      queryObjects.logStatus(driver, Status.PASS, "To verify label "+sectionToVerify+" is available with Hyperlink value ", strValue, null);
		                               }
		                 }
		                 else if(driver.findElements(By.xpath("//div"+strXpath+"[1]")).size()>0)
		                 {
		                 strValue = driver.findElement(By.xpath("//div"+strXpath+"[1]")).getText();
		                 if(strValue.length()==0)

		                 queryObjects.logStatus(driver, Status.PASS, "To verify label "+sectionToVerify+" is available with ", "empty value", null);

		                 else

		                 queryObjects.logStatus(driver, Status.PASS, "To verify label "+sectionToVerify+" is available with ", strValue, null);

		                 }
		                 else if(driver.findElements(By.xpath("//div"+strXpath+"/../following-sibling::div/a/span")).size()>0)
		                 {
		                        strValue = driver.findElement(By.xpath("//div"+strXpath+"/../following-sibling::div/a/span")).getText();
		                        if(strValue.length()==0)
		                               
		                                      queryObjects.logStatus(driver, Status.PASS, "To verify label "+sectionToVerify+" is available with ", "empty value", null);
		                               
		                               else
		                               
		                                      queryObjects.logStatus(driver, Status.PASS, "To verify label "+sectionToVerify+" is available with Hyperlink value ", strValue, null);
		                               
		                 }                        
		                 Thread.sleep(2000);
		                 break;
		            }
		          strXpath1 = "//div[contains(text(),'"+strXpath1+"')]";
		          if(driver.findElements(By.xpath(strXpath1)).size()>0) 
		            {
               if(driver.findElements(By.xpath(strXpath1)).size()>0) 
		            {
		                 if(driver.findElements(By.xpath(""+strXpath1+"")).size()>0)
		                 {
		                        strValue = driver.findElement(By.xpath(""+strXpath1+"")).getText();
		                        if(strValue.length()==0)
		                        {
		                               queryObjects.logStatus(driver, Status.PASS, "To verify label "+sectionToVerify+" is available with ", "empty value", null);
		                        }
		                        else
		                        {
		                               queryObjects.logStatus(driver, Status.PASS, "To verify label "+sectionToVerify+" is available with value ", strValue, null);
		                        }
		                 } 
						Thread.sleep(2000);
					}break;
				}
               strXpath2 = "//label[contains(text(),'"+strXpath2+"')]";
		          if(driver.findElements(By.xpath(strXpath2)).size()>0) 
		            {
            if(driver.findElements(By.xpath(strXpath2)).size()>0) 
		            {
		                 if(driver.findElements(By.xpath(""+strXpath2+"")).size()>0)
		                 {
		                        strValue = driver.findElement(By.xpath(""+strXpath2+"")).getText();
		                        if(strValue.length()==0)
		                               queryObjects.logStatus(driver, Status.PASS, "To verify label "+sectionToVerify+" is available with ", "empty value", null);
		                        else
		                               queryObjects.logStatus(driver, Status.PASS, "To verify label "+sectionToVerify+" is available with value ", strValue, null);
						}
						Thread.sleep(2000);
					}
				}break;
				case "input": 
					if(driver.findElements(By.xpath("//label[normalize-space(text())='"+sectionToVerify+"']/following-sibling::input")).size()>0) {
						queryObjects.logStatus(driver, Status.PASS, "To verify input "+sectionToVerify+" is available", "The input is available", null);
					
					}
					break;	
				case "link": 
					if(driver.findElements(By.xpath("//a[*[normalize-space(text())='"+sectionToVerify+"']]")).size()>0) {
						queryObjects.logStatus(driver, Status.PASS, "To verify link "+sectionToVerify+" is available", "The link is available", null);
					
					}
					else if(driver.findElements(By.xpath("//a[normalize-space(text())='"+sectionToVerify+"']")).size()>0) {
						queryObjects.logStatus(driver, Status.PASS, "To verify link "+sectionToVerify+" is available", "The link is available", null);
					
					}	break;
				case "image":
					if(driver.findElements(By.xpath("//img[contains(@src,'"+sectionToVerify+"')]")).size()>0) {
						queryObjects.logStatus(driver, Status.PASS, "To verify image "+sectionToVerify+" is available", "The image is available", null);
						
					}break;
				case "button":
					if(driver.findElements(By.xpath("//button/span[text()='"+sectionToVerify+"']")).size()==1)
					{
					queryObjects.logStatus(driver, Status.PASS, "To verify button "+sectionToVerify+" is available", "The image is available", null);

					}
					else if(driver.findElements(By.xpath("//button[text()='"+sectionToVerify+"']")).size()==1)
					{
					queryObjects.logStatus(driver, Status.PASS, "To verify button "+sectionToVerify+" is available", "The image is available", null);

					}

					else if(driver.findElements(By.xpath("//button[text()=' "+sectionToVerify+" ']")).size()==1)
					{
					queryObjects.logStatus(driver, Status.PASS, "To verify button "+sectionToVerify+" is available", "The image is available", null);

					}
					else if(driver.findElements(By.xpath("//button[text()='"+sectionToVerify+"']")).size()>0)
					{
					queryObjects.logStatus(driver, Status.PASS, "To verify button "+sectionToVerify+" is available", "The image is available", null);

					}
					else if(driver.findElements(By.xpath("//span[normalize-space(text())='"+sectionToVerify+"']")).size()==1)
					{
					queryObjects.logStatus(driver, Status.PASS, "To verify button "+sectionToVerify+" is available", "The image is available", null);

					}
					else if(driver.findElements(By.xpath("//span[normalize-space(text())='"+sectionToVerify+"']")).size()>0)
					{
					queryObjects.logStatus(driver, Status.PASS, "To verify button "+sectionToVerify+" is available", "The image is available", null);

					}
					else if(driver.findElements(By.xpath("//button[@aria-label='"+sectionToVerify+"']")).size()==1)
					{
					queryObjects.logStatus(driver, Status.PASS, "To verify button "+sectionToVerify+" is available", "The image is available", null);
					}
					else {
					queryObjects.logStatus(driver, Status.FAIL, sectionToVerify+ "button does not exist", "Enter the valid button info", null);

					}break;
					case "grid":
					if(driver.findElements(By.xpath("//div[contains(@class,'div-grid')]")).size()>0) {
					queryObjects.logStatus(driver, Status.PASS, "To verify grid "+sectionToVerify+" is available", "The grid is available", null);

					} break;
				case "sectionHeading":
				if(driver.findElements(By.xpath("//legend[normalize-space(text())='"+sectionToVerify+"']")).size()>0) {
					queryObjects.logStatus(driver, Status.PASS, "To verify section heading "+sectionToVerify+" is available", "The section heading is verified", null);
				
				}
				else if(driver.findElements(By.xpath("//h4[normalize-space(text())='"+sectionToVerify+"']")).size()>0) {
					queryObjects.logStatus(driver, Status.PASS, "To verify section heading "+sectionToVerify+" is available", "The section heading is verified", null);
					
				}
				else if(driver.findElements(By.xpath("//span[normalize-space(text())='"+sectionToVerify+"']")).size()>0) {
                    queryObjects.logStatus(driver, Status.PASS, "To verify section heading "+sectionToVerify+" is available", "The section heading is verified", null);
                    break;
				}
				else if(driver.findElements(By.xpath("//strong[normalize-space(text())='"+sectionToVerify+"']")).size()>0) {
					queryObjects.logStatus(driver, Status.PASS, "To verify section heading "+sectionToVerify+" is available", "The section heading is verified", null);					
				}break;
				
				case "labelValue":
					strXpath ="//label[text()='"+sectionToVerify+"']";
					if(driver.findElements(By.xpath("//div"+strXpath+"/../a")).size()>0)
					{
					strValue = driver.findElement(By.xpath("//div"+strXpath+"/../a")).getText();
					if(strValue.length()==0)

					queryObjects.logStatus(driver, Status.PASS, "To verify label "+sectionToVerify+" is available with ", "empty value", null);

					else

					queryObjects.logStatus(driver, Status.PASS, "To verify label "+sectionToVerify+" is available with Hyperlink value ", strValue, null);

					}
					else if(driver.findElements(By.xpath("//div"+strXpath+"/../span")).size()>0)
					{
					strValue = driver.findElement(By.xpath("//div"+strXpath+"/../span")).getText();
					if(strValue.length()==0)

					queryObjects.logStatus(driver, Status.PASS, "To verify label "+sectionToVerify+" is available with ", "empty value", null);

					else

					queryObjects.logStatus(driver, Status.PASS, "To verify label "+sectionToVerify+" is available with Hyperlink value ", strValue, null);

					}
					Thread.sleep(2000);
					break;
				
			}
		}
		
		catch(NullPointerException npe) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to find the required "+sectionType+" -> The expected "+sectionType+" is not present in the selection box - Verify the xpath", npe.getLocalizedMessage(), npe);
			if(endRun)
				endTestRun(driver);
		}
		catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to find the required "+sectionType+" -> The expected "+sectionType+" is not present in the selection box.", nse.getLocalizedMessage(), nse);
			if(endRun)
				endTestRun(driver);
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to find the required "+sectionType+" -> The expected "+sectionType+" were not validated", te.getLocalizedMessage(), te);
			if(endRun)
				endTestRun(driver);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to find the required "+sectionType, e.getLocalizedMessage(), e);
			if(endRun)
				endTestRun(driver);
		}
	}

	public static void clickLink(WebDriver driver, String link,boolean endRun,boolean createND) throws Exception{
		if(createND)
			createNode(driver,"Click Link -"+link);
		try {
			if(driver.findElements(By.xpath("//a[*[normalize-space(text())='"+link+"']]")).size()>0) {
				driver.findElement(By.xpath("//a[*[normalize-space(text())='"+link+"']]")).click();
			}
			else if(driver.findElements(By.xpath("//a[normalize-space(text())='"+link+"']")).size()>0) {
				driver.findElement(By.xpath("//a[normalize-space(text())='"+link+"']")).click();
			}
			else if(driver.findElements(By.xpath("//span[normalize-space(text())='"+link+"']")).size()>0) {
				driver.findElement(By.xpath("//span[normalize-space(text())='"+link+"']")).click();
			}
			else if(driver.findElements(By.xpath("//td[normalize-space(text())='"+link+"']")).size()>0) {
				driver.findElement(By.xpath("(//td[normalize-space(text())='"+link+"'])[5]")).click();
			}
			else if(driver.findElements(By.xpath("//label[normalize-space(text())='"+link+"']")).size()>0) {
                driver.findElement(By.xpath("//label[normalize-space(text())='"+link+"']")).click();
            }
		 else {
				queryObjects.logStatus(driver, Status.FAIL, "Link did not appear on the screen", "", null);
            } 
			Thread.sleep(3000);
		}
		catch(ElementNotInteractableException e) {
            queryObjects.logStatus(driver, Status.FAIL, "The link expected to be clicked on, is not clickable", e.getLocalizedMessage(), e);
            if(endRun)
				endTestRun(driver);
        }
        catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver, Status.FAIL, "The link could not be clicked on -> Unable to find the link", nse.getLocalizedMessage(), nse);
			if(endRun)
				endTestRun(driver);
		}
        catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "The link could not be clicked on -> It did not appear on the screen", te.getLocalizedMessage(), te);
			if(endRun)
				endTestRun(driver);
		}
        catch(Exception e) {
            queryObjects.logStatus(driver, Status.FAIL, "The link could not be clicked on", e.getLocalizedMessage(), e);
            if(endRun)
				endTestRun(driver);
        }
	}

	public static void logout(WebDriver driver,boolean endRun) throws Exception {
		RC_Global.createNode(driver, "Logging out of Application");
		WebDriverWait wait = new WebDriverWait(driver,30);
		try {
			driver.findElement(By.xpath("//span[span[@id='user-menu-name']]")).click();
			driver.findElement(By.xpath("//span[text()='Log Out']")).click();
			
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//strong[text()='Sign In']"))));
			
			Thread.sleep(3000);
		}
		catch(ElementNotInteractableException enie) {
			queryObjects.logStatus(driver, Status.FAIL, "Logout Failed -> The Name or logout button was not clickable", enie.getLocalizedMessage(), enie);
			if(endRun)
				endTestRun(driver);
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "Logout Failed -> Page not loaded successfully or unable to locate the Name or logout button", te.getLocalizedMessage(), te);
			if(endRun)
				endTestRun(driver);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Logout Failed", e.getLocalizedMessage(), e);
			if(endRun)
				endTestRun(driver);
		}
	}
	
	public static String getDateTime(WebDriver driver, String DateTimeformat, int noOfDaysFromToday,boolean endRun) throws Exception{
		String inputText="";

		try {
			LocalDateTime now = LocalDateTime().now().plusDays(noOfDaysFromToday);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DateTimeformat);
			inputText=now.format(formatter);
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to fetch Date and/or Time -> Wait time expired",te.getLocalizedMessage(), te);
			if (endRun)
				endTestRun(driver);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to fetch Date and/or Time", e.getLocalizedMessage(), e);
			if (endRun)
				endTestRun(driver);
		}
		return inputText;
	}
	private static LocalDateTime LocalDateTime() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public static String clickCellLinkVerifyPanelTitle(WebDriver driver, String ColumnName, String panelTitle,boolean endRun) throws Exception {
  
		createNode(driver, "Click Cell Link "+ColumnName+"-->Verify PanelTitle-->"+panelTitle);
		
		String cellValue="";
		try {
			Thread.sleep(2000);
			int ColumnNum = RC_Global.findColumnNumber(driver,ColumnName, endRun);
			if(driver.findElements(By.xpath("//div[div[@role='row']][2]//div[@role='gridcell'][" + ColumnNum + "]//a[@href]")).size()>0) {
				Thread.sleep(1000);	   
				cellValue = driver.findElement(By.xpath("//div[div[@role='row']][2]//div[@role='gridcell'][" + ColumnNum + "]//a[@href]")).getText();
				
				driver.findElement(By.xpath("//div[div[@role='row']][2]//div[@role='gridcell'][" + ColumnNum + "]//a[@href]")).click();
				Thread.sleep(1000);
			}
			else if(driver.findElements(By.xpath("//tr[1]/td[" + ColumnNum + "]")).size() > 0) {
			cellValue = driver.findElement(By.xpath("//tr[1]/td[" + ColumnNum + "]")).getText();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//tr[1]/td[" + ColumnNum + "]")).click();
			Thread.sleep(1000);//Unit Number hyperlink
			}
			Thread.sleep(2000);
			waitUntilPanelVisibility(driver, panelTitle, "TV",false,false);
		}
		catch(Exception e) {
		queryObjects.logStatus(driver, Status.FAIL, "Clicked Hyperlink page navigation is failed",e.getLocalizedMessage() , e);
		if(endRun)
				endTestRun(driver);
		}
		return cellValue;
		}
	 
	public static void clickicon(WebDriver driver, String IconName,boolean endRun,boolean createND) throws Exception{
		if(createND)
			createNode(driver,"Click Icon -"+IconName);
		try {    
			if(driver.findElements(By.xpath("(//i[@title='"+IconName+"'])[1]")).size()>0) {
				driver.findElement(By.xpath("(//i[@title='"+IconName+"'])[1]")).click();
			}
		}
		catch(ElementNotInteractableException e) {
            queryObjects.logStatus(driver, Status.FAIL, "The icon expected to be clicked on, is not clickable", e.getLocalizedMessage(), e);
            if(endRun)
				endTestRun(driver);
        }
        catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver, Status.FAIL, "The icon could not be clicked on -> Unable to find the icon", nse.getLocalizedMessage(), nse);
			if(endRun)
				endTestRun(driver);
		}
        catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "The icon could not be clicked on -> It did not appear on the screen", te.getLocalizedMessage(), te);
			if(endRun)
				endTestRun(driver);
		}
        catch(Exception e) {
            queryObjects.logStatus(driver, Status.FAIL, "The icon could not be clicked on", e.getLocalizedMessage(), e);
            if(endRun)
				endTestRun(driver);
        }
	}

	public static void validateSearchFilterAction(WebDriver driver, String FilterName,String FilterValue,String SubModuleName,boolean endRun,boolean createND) throws Exception {//Check with Yashodha
		if(createND)
			createNode(driver,FilterName+" input fields validation");
		try {
			WebDriverWait wait = new WebDriverWait(driver,120);//BILLING
			WebDriverWait wait1 = new WebDriverWait(driver,40);
			WebDriverWait wait2 = new WebDriverWait(driver,10);
			WebElement SearchFilter  = null;
			if(driver.findElements(By.xpath("//input[@placeholder='"+FilterName+"']")).size()>0) { 
				SearchFilter= driver.findElement(By.xpath("//input[@placeholder='"+FilterName+"']"));
				SearchFilter.sendKeys(FilterValue);
			}
			Thread.sleep(2000);
			RC_Global.clickButton(driver, "Search", endRun,false);
			Thread.sleep(2000);
			if(SubModuleName.equalsIgnoreCase("Maintenance")||SubModuleName.equalsIgnoreCase("Vendor Locate")) {
				wait1.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='table-status-container ng-scope']//div[@class='spinner ng-scope']")));
	        	wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='ui-grid-row ng-scope'])[1]")));
			} else {
				wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//tbody/tr)[1]")));
			}
			List<WebElement> Table1 =driver.findElements(By.xpath("//div[(@role='rowgroup') and (@ng-style='colContainer.getViewportStyle()')]"));
			List<WebElement> Table2 =driver.findElements(By.xpath("//tbody/tr"));
	
			List<WebElement> Table3 = driver.findElements(By.xpath("//legend[text()='Submission History']"));
		       
            if(Table1.size()>0 || Table2.size()>0) {
            	queryObjects.logStatus(driver, Status.PASS, "Search Results are", "Found", null);
            }
            else if(Table3.size()>0)
            {
                queryObjects.logStatus(driver, Status.PASS, "Search Results are", "Found", null);
            }         
        }
        catch(Exception e) {
            if(driver.findElements(By.xpath("//span[text()='No Results']")).size()>0) {
            	if (SubModuleName.equalsIgnoreCase("Personal Use Submission")) {
            		if(driver.findElements(By.xpath("//legend[text()='Submission History']")).size()==0) {
                		queryObjects.logStatus(driver, Status.FAIL, "No search results returned for the given input", "Search field is "+FilterName+" and input is"+FilterValue, null);
                	}
				} else {            	
                queryObjects.logStatus(driver, Status.PASS, "Search Results are", "Not Found", null);
            	}
                return;
            }
            queryObjects.logStatus(driver, Status.FAIL, "Unable to validate Search Filters", e.getLocalizedMessage(), e);
            if(endRun)
				endTestRun(driver);
        }
	}
	
	public static void scrollBackAction(WebDriver driver, int scrollCount) {
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		for(int iter=0;iter<scrollCount;iter++) {
			   WebElement scrollBar= null;
			   if(driver.findElements(By.xpath("//div[@id='view-maintenancerepairorders']")).size()>0) {
				   scrollBar = driver.findElement(By.xpath("//div[@id='view-maintenancerepairorders']"));
				   WebElement scrollBar2= driver.findElement(By.xpath("//div[@style='overflow: scroll;']"));
				   executor.executeScript("arguments[0].scrollTop += 400",scrollBar);
				   executor.executeScript("arguments[0].scrollLeft -= 400",scrollBar2);					   
				   executor.executeScript("arguments[0].scrollTop -= 400",scrollBar);
				}
					   
			   else if(driver.findElements(By.xpath("//div[@table-scroll]")).size()>0) {
				   scrollBar= driver.findElement(By.xpath("//div[@table-scroll]"));
				   executor.executeScript("arguments[0].scrollLeft -= 500",scrollBar);
			   }
	        
		   }
	}
	
	public static void dropdownValuesValidation(WebDriver driver, String dropDownValues, String Xpath,boolean endRun,boolean createND) throws Exception {
        if(createND)
               createNode(driver,"Validate dropdown values");
        try {

      String[] dropDownValue = dropDownValues.split(";");
      driver.findElement(By.xpath("" + Xpath + "")).click();
      Thread.sleep(3000);
      String[] dropvalues = dropDownValues.split(";");
      boolean flag = false;
      for (int i = 0; i < dropDownValue.length; i++) {
            for (int j = 0; j < dropvalues.length; j++) {
                String Drpdwn = "";
                if(driver.findElements(By.xpath(Xpath + "//option[@label='" + dropvalues[j] + "']")).size()>0)
                {  Drpdwn = driver.findElement(By.xpath(Xpath + "//option[@label='" + dropvalues[j] + "']")).getText();
                }  // List<WebElement> Drpdwn= driver.findElements(By.xpath(xpath));
                else if(driver.findElements(By.xpath(Xpath + "//option[normalize-space(text())='"+ dropvalues[j] +"']")).size()>0)
                {  Drpdwn = driver.findElement(By.xpath(Xpath + "//option[normalize-space(text())='"+ dropvalues[j] +"']")).getText();
                }
                   if (Drpdwn.equalsIgnoreCase(dropDownValue[i]))
                          flag = true;
            }break;
      	}
	      if (flag)
	            queryObjects.logStatus(driver, Status.PASS, "Dropdown Values validation", "Successful", null);
	      else
	            queryObjects.logStatus(driver, Status.FAIL, "Dropdown Values validation", "Failed", null);
	
	      driver.findElement(By.xpath("" + Xpath + "")).click();
	      Thread.sleep(2000);

        }
        catch(NullPointerException npe) {
               queryObjects.logStatus(driver, Status.FAIL, "Unable to validate dropdown values -> The expected options are not present in the selection box - Verify the xpath", npe.getLocalizedMessage(), npe);
                 if(endRun)
                            endTestRun(driver);
        }
        catch(NoSuchElementException nse) {
               queryObjects.logStatus(driver, Status.FAIL, "Unable to validate dropdown values -> The expected dropdown values are not present on the selection box.", nse.getLocalizedMessage(), nse);
                 if(endRun)
                            endTestRun(driver);
        }
        catch(TimeoutException te) {
               queryObjects.logStatus(driver, Status.FAIL, "Unable to validate dropdown values -> Wait time expired before the expected dropdown values were validated", te.getLocalizedMessage(), te);
                 if(endRun)
                            endTestRun(driver);
        }
        catch(Exception e) {
               queryObjects.logStatus(driver, Status.FAIL, "Unable to validate dropdown values", e.getLocalizedMessage(), e);
                 if(endRun)
                            endTestRun(driver);
        }

	}

    
	public static void googleRoutePageValidation(WebDriver driver, String vendorNearYou,boolean endRun) throws Exception {
	RC_Global.createNode(driver, "Google Map Page Validation");
		try{
			driver.findElement(By.xpath("(//div[@role='row'])[2]/div/div/a")).click();
			Thread.sleep(2000);
			switchToWindowTab(driver,2," Add destination ", endRun);
			String Vendor = driver.findElement(By.xpath("//input[contains(@aria-label,'Starting point')]")).getAttribute("aria-label");
			Thread.sleep(2000);
			if(Vendor.contains(vendorNearYou)) 
				queryObjects.logStatus(driver, Status.PASS, "Google Map Starting point is Same as the Vendor Address",""+Vendor, null);
			else
			    queryObjects.logStatus(driver, Status.FAIL, "Google Map Starting point is not Same as the Vendor Address","" , null);
			
			switchToWindowTab(driver,1,"Acquisition", endRun);
	
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Google Map link Validation is failed", e.getLocalizedMessage(), e);
			  if(endRun)
					endTestRun(driver);
		}
	}
	
	public static WebElement accessInputBoxViaLabel(WebDriver driver, String label,boolean endRun) throws Exception{
		   
		WebElement inputBox = null;
		try {
			if(driver.findElements(By.xpath("//div[label[text()='"+label+"']]/div//input")).size()>0) {
				inputBox = driver.findElement(By.xpath("//div[label[text()='"+label+"']]/div//input"));																					 
			}
			else if(driver.findElements(By.xpath("//div[strong[text()='"+label+"']]/span//input")).size()>0) {
				inputBox = driver.findElement(By.xpath("//div[strong[text()='"+label+"']]/span//input"));
			}
			else if(driver.findElements(By.xpath("//div[label[text()='"+label+"']]/input")).size()>0) {
				inputBox = driver.findElement(By.xpath("//div[label[text()='"+label+"']]/input"));																					 
			}
			else if(driver.findElements(By.xpath("//div[div[label[text()='"+label+" ']]]/div//input")).size()>0) {
				if(driver.findElements(By.xpath("(//div[div[label[text()='"+label+" ']]]/div//input)[1]")).size()>0) 
					inputBox = driver.findElement(By.xpath("(//div[div[label[text()='"+label+" ']]]/div//input)[1]"));
				else
					inputBox = driver.findElement(By.xpath("//div[div[label[text()='"+label+" ']]]/div//input"));																					 
			}
		}
		catch(NullPointerException npe) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to access the input box -> Input box associated with "+label+" is not available or verify the element locator (xpath)", npe.getLocalizedMessage(), npe);
			  if(endRun)
					endTestRun(driver);
		}
		catch(NoSuchElementException nse) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to access the input box -> Input box associated with "+label+" is not available", nse.getLocalizedMessage(), nse);
			  if(endRun)
					endTestRun(driver);
		}
		catch(TimeoutException te) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to access the input box -> Input box associated with "+label+" could not be located", te.getLocalizedMessage(), te);
			  if(endRun)
					endTestRun(driver);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Unable to access the input box", e.getLocalizedMessage(), e);
			  if(endRun)
					endTestRun(driver);
		}
		return inputBox;
	}

	public static void validateTheGridColumnContent(WebDriver driver, String ColumnName , String GridContetntToValidate, String Module,boolean endRun) throws Exception {
		RC_Global.createNode(driver, "Validate "+ColumnName+" Content As "+GridContetntToValidate+"");
		WebDriverWait wait = new WebDriverWait(driver,60);
		WebDriverWait wait1 = new WebDriverWait(driver,10);
		List<WebElement> recordContent;
		List<WebElement> rowCount;
		List<WebElement> deleColContent = null;
		WebElement noResults = null;
		boolean Flag = false;
		
		try{
		if(Module.equalsIgnoreCase("Maintenance")) {
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='table-status-container ng-scope']//div[@class='spinner ng-scope']")));
			if (driver.findElements(By.xpath("//div[@class='table-status-container ng-scope']//div[@class='spinner ng-scope']")).size()>0) {
				wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='table-status-container ng-scope']//div[@class='spinner ng-scope']")));
			}
			wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='ui-grid-row ng-scope'])[1]")));
			Thread.sleep(2000);
			recordContent = driver.findElements(By.xpath("//div[@ui-grid-row='row']/div[14]/div[1]"));
			deleColContent = driver.findElements(By.xpath("//div[@ui-grid-row='row']//div[text()='Deleted']"));
			rowCount = driver.findElements(By.xpath("//div[@role='rowgroup']//div[@ui-grid-row='row']"));}
			
		else {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table//tbody")));
			Thread.sleep(1000);
			int ColumnNum = RC_Global.findColumnNumber(driver, ColumnName, endRun);
			recordContent = driver.findElements(By.xpath("//tbody//tr//td["+ColumnNum+"]"));
			rowCount = driver.findElements(By.xpath("//table/tbody//tr"));
		}

		for(int i=1; i < rowCount.size();i++) {
			Flag = false;			
			try {
				//String RoStatusVal = deleColContent.get(i).getText();
				if(!GridContetntToValidate.contains("Deleted")) {
				if(GridContetntToValidate.equalsIgnoreCase(recordContent.get(i).getText())) 
					Flag = true;
					break;
				}
				String RoStatusVal = deleColContent.get(i).getText();
				 if(GridContetntToValidate.equalsIgnoreCase(RoStatusVal)) {
					Flag = true;
					break;
				}
				else {
					 queryObjects.logStatus(driver, Status.FAIL, ColumnName+" doesn't have the value", GridContetntToValidate+" in row "+(i+1) , null);
					 Thread.sleep(500);
				}
			}
			catch(Exception e) {
				
				noResults = driver.findElement(By.xpath("//span[text()='No Results']"));
				if(noResults.isDisplayed()) {
					queryObjects.logStatus(driver, Status.INFO, "Search Results Not Found","No Results", null);
				}
			}
		}
		
		if(Flag)
			 queryObjects.logStatus(driver, Status.PASS, ColumnName+" has the value",GridContetntToValidate+"", null);		
		}
		catch(TimeoutException te) {
			
			noResults = driver.findElement(By.xpath("//span[text()='No Results']"));
			if(noResults.isDisplayed()) {
				queryObjects.logStatus(driver, Status.INFO, "Search Results Not Found","No Results", null);
			}
		}
		catch(Exception e) {
			
			noResults = driver.findElement(By.xpath("//span[text()='No Results']"));
			//if (driver.findElements(By.xpath("//span[text()='No Results']")).size()>0) {
			if(noResults.isDisplayed()) {	
				queryObjects.logStatus(driver, Status.INFO, "Search Results Not Found","No Results", null);
			}
		}
	}
			
	public static void createExternalUserInUserSetup(WebDriver driver,String userName, String firstName, String lastName, String email,boolean endRun) throws Exception{
		try{
           driver.findElement(By.xpath("//input[@name='username']")).sendKeys(userName);
           driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys(firstName);
           driver.findElement(By.xpath("//input[@name='lastName']")).sendKeys(lastName);
           driver.findElement(By.xpath("//input[@name='email']")).sendKeys(email);
           clickUsingXpath(driver,"//label[text()='Active User']//following::label[@uib-btn-radio='true' and @ng-model='user.IsEnabled']","Active User", endRun,false);
           
           queryObjects.logStatus(driver, Status.PASS,"Enter the user details for user: "+userName, userName+" - User details entered", null);
		}
		catch(NullPointerException npe) {
			queryObjects.logStatus(driver, Status.FAIL, userName +" - User details failed to entered", npe.getLocalizedMessage(), npe);	
			 if(endRun)
					endTestRun(driver);
		}
		catch (Exception e){
			queryObjects.logStatus(driver, Status.FAIL, userName +" - User details failed to entered", e.getLocalizedMessage(), e);
			 if(endRun)
					endTestRun(driver);
		}   
	}
	
	public static void scrollById(WebDriver driver,String elementXpath)throws Exception
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement Element = driver.findElement(By.xpath(elementXpath));
		js.executeScript("arguments[0].scrollIntoView();", Element);
																													   
	}
 
 
	public static void enterCustomerFocus(WebDriver driver,String custNum,boolean endRun)throws Exception 
    {
           createNode(driver, "Enter Customer Number in Customer Number Input Focus");
           try {
            WebDriverWait wait = new WebDriverWait(driver,10);
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@ng-click='customerFocusClicked()']")));
            RC_Global.clickUsingXpath(driver,"//a[@ng-click='customerFocusClicked()']","Customer Focus", endRun,false);
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//label[contains(@for,'allCustomersCheckbox')]//input")));
            ((WebElement)(driver.findElement(By.xpath("//label[contains(@for,'allCustomersCheckbox')]//input")))).click();
            RC_Global.clickUsingXpath(driver,"//a[@ng-click='customerFocusClicked()']","Customer Focus Click", endRun,false);
            RC_Global.enterInput(driver,custNum,(WebElement)(driver.findElement(By.xpath("//div[@ng-show='customerChosen']//input"))), endRun,false);
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(@title,'"+custNum+"')]")));
            RC_Global.clickUsingXpath(driver,"//a[contains(@title,'"+custNum+"')]","Customer Number", endRun,false);
            queryObjects.logStatus(driver, Status.PASS, "Entered customer number available","Customer Focus set with "+custNum, null);
           }
           catch(NoSuchElementException nse) {
                  queryObjects.logStatus(driver, Status.FAIL, "Failed to select Customer Number -> Unable to find the correct inputbox to enter the number", nse.getLocalizedMessage(), nse);
                  if(endRun)
  					endTestRun(driver);
           }
           catch(TimeoutException te) {
                  queryObjects.logStatus(driver, Status.FAIL, "Failed to select Customer Number -> Unable to load the current/previous screen", te.getLocalizedMessage(), te);
                  if(endRun)
  					endTestRun(driver);
           }
           catch(Exception e) {
                  queryObjects.logStatus(driver, Status.FAIL, "Failed to select Customer Number -> Verify and enter the correct Customer Number or number of the respective hierarchy", e.getLocalizedMessage(), e);
                  if(endRun)
  					endTestRun(driver);
           }
    }
	
	public static void modalHandler(WebDriver driver, String modalName, String modalAction) throws Exception{
		
		if(driver.findElements(By.xpath("//div[@class='modal-dialog'][contains(., '"+modalName+"')]")).size()==0) {
			return;
		}
		else {
			createNode(driver, "Modal Handler - ModalName: " + modalName + ", ModalAction: " + modalAction);
			switch (modalName) {
			
			case "Selector Out Of Date":
				RC_Global.clickButton(driver, modalAction, true, false);
				Thread.sleep(500);
				break;
			case "Email Documents":
				RC_Global.clickButton(driver, modalAction, true, false);
				Thread.sleep(500);
				break;
			default:
				
			}

		}
		
	}
	
	public static boolean isWithinRange(Date testDate, Date startDate, Date endDate) {
		return !(testDate.before(startDate)||testDate.after(endDate));
	}

	
	  public static void endTestRun(WebDriver driver) throws Exception {
		  StartFramework sf = new StartFramework(); //sf.closeBrowser();		  
		  driver.close();
		  driver.quit();
		Thread.currentThread().stop();
	   }
	  
	  public static void mouseHoverElement(WebDriver driver,WebElement element,String eleName) throws Exception
	     {
	         RC_Global.createNode(driver, "Mouse Hover to "+eleName+"");
	         try {
	         JavascriptExecutor executor = (JavascriptExecutor)driver;
	         Thread.sleep(1000);
	         executor.executeScript("if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover',true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject) { arguments[0].fireEvent('onmouseover');}",element);
	         Thread.sleep(1000);
	         queryObjects.logStatus(driver, Status.PASS, "Mouse Hover to the "+eleName+"", "Successful", null);
	         }
	         catch(Exception e){
	             queryObjects.logStatus(driver, Status.FAIL, "Mouse Hover to the "+eleName+"", "Failed", null);
	         }
	     }
	  
	  public static void changePassword(WebDriver driver, String userName, boolean endRun) throws Exception {
			WebDriverWait wait = new WebDriverWait(driver,30);
			String currentPwd = externalCredentials(userName)[1];
			String tempPwd = "";String newPassword = "";
			try {
//				driver.findElement(By.xpath("//span[span[@id='user-menu-name']]")).click();
//				driver.findElement(By.xpath("//span[text()='Change Password']")).click();				
//				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//input[@placeholder='Current Password']"))));
				Thread.sleep(1000);
				for (int i = 1; i <= 5; i++) {
					if (i==5) {
						tempPwd = newPassword;
						newPassword = currentPwd;
					} else if (i==1) {
						newPassword = "Masha"+(i+5)+"$";
						tempPwd = currentPwd;
					} else {
						tempPwd = newPassword;
						newPassword = "Masha"+(i+5)+"$";
					}
					driver.findElement(By.xpath("//input[@placeholder='Current Password']")).clear();
					driver.findElement(By.xpath("//input[@placeholder='Current Password']")).sendKeys(tempPwd);
					driver.findElement(By.xpath("//input[@placeholder='New Password']")).clear();
					driver.findElement(By.xpath("//input[@placeholder='New Password']")).sendKeys(newPassword);
					driver.findElement(By.xpath("//input[@placeholder='Confirm Password']")).clear();
					driver.findElement(By.xpath("//input[@placeholder='Confirm Password']")).sendKeys(newPassword);
					driver.findElement(By.xpath("//button[text()='Change Password']")).click();
					RC_Manage.waitUntilMethods(driver, "//h5[@ng-show='changePasswordProcess']","class","ng-hide", "attribute visible");
					
					if (i==5) {
						if (driver.findElements(By.xpath("//h4[text()='Update Successful']")).size()>0) {
							queryObjects.logStatus(driver, Status.PASS, "Password change is successful for User -"+userName, "", null);
						} else {
							queryObjects.logStatus(driver, Status.FAIL, "Password change failed for User -"+userName, "", null);
						}
						driver.findElement(By.xpath("//button[text()='Close']")).click();
						Thread.sleep(2000);
					}
				}
			}
			catch(ElementNotInteractableException enie) {
				queryObjects.logStatus(driver, Status.FAIL, "Change Password Failed -> Unable to update the password for user "+userName, enie.getLocalizedMessage(), enie);
				if(endRun)
					endTestRun(driver);
			}
			
		}
	 
}