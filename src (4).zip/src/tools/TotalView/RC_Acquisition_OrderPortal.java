package tools.TotalView;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;
import MF.FrameworkCode.BFrameworkQueryObjects;


public class RC_Acquisition_OrderPortal {
	
	static BFrameworkQueryObjects queryObjects = new BFrameworkQueryObjects();

}
