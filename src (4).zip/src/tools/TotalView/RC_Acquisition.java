package tools.TotalView;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;
import MF.FrameworkCode.BFrameworkQueryObjects;

public class RC_Acquisition {
	
	static BFrameworkQueryObjects queryObjects = new BFrameworkQueryObjects();
	
	
	public static void PriceAVehicle(WebDriver driver, String year, String make, String model, String drive, String pricing, String trim) throws Exception{
		try{
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//select[@id='selectYear']")));
			queryObjects.logStatus(driver, Status.INFO, "Navigate to Price a Vehicle screen", "Successfully navigated to Price a Vehicle screen", null);
			
			RC_Global.selectDropdownOption(driver, "Year", year,true, true);
			RC_Global.selectDropdownOption(driver, "Make", make,true, true);
			RC_Global.selectDropdownOption(driver, "Model", model,true, true);
			
			
			if(!drive.isEmpty())
				RC_Global.selectDropdownOption(driver, "Drive", drive,true, false);
			
			
			if(!pricing.isEmpty())
				RC_Global.radioButton(driver, "Pricing", pricing,false);
			
			Thread.sleep(5000);
			
			RC_Global.radioButton(driver, "trim",  trim,false);
			
			queryObjects.logStatus(driver, Status.PASS, "Vehicle Selection", "Vehicle Selection successfully", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Vehicle Selection", e.getLocalizedMessage(), e);
		}
		driver.findElement(By.xpath("//button/span[text()='Next']")).click();
		Thread.sleep(2000);
	}
	
	public static void configureVehicleOptions(WebDriver driver, String ConfigurationTab,String InteriorColor, String ExteriorColor) throws Exception {
		WebDriverWait wait = new WebDriverWait(driver,60);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='Options']")));
		
		List<String> ExtColors = new ArrayList<String>();
		List<String> IntColors = new ArrayList<String>();
		
		queryObjects.logStatus(driver, Status.INFO, "Navigate to Configure Vehicle Options screen", "Successfully navigated to Configure Vehicle Options screen", null);
		Thread.sleep(1500);
		
		if(ConfigurationTab.equalsIgnoreCase("Options"))
		{
			//Options Flow
		}
		
		//ColorsTab (Mandatory irrespective of value of sConfigurationTab)
		driver.findElement(By.xpath("//a[text()='Colors']")).click();		
		executor.executeScript("document.body.style.zoom = '60%'");
		
		int row = 1;
		int col = 1;
		
		if(!ExteriorColor.isEmpty()) {
			
			//Fetching Exterior Color column
			List<WebElement> extColors = driver.findElements(By.xpath("//table[thead[tr[th[text()=' Interior Colors ']]]]/thead/tr//h5"));
			
			//for(WebElement eCol:extColors) {
			for(int iter1=0;iter1<extColors.size();iter1++) {
				ExtColors.add(extColors.get(iter1).getText());
			}
			System.out.println(ExtColors);
			
			
			for(int iter2=1;iter2<ExtColors.size();iter2++) {
				if(ExtColors.get(iter2).contains(ExteriorColor)) { //Test Date: Mention the whole name of the color, can ignore what is given in [...] in Application
					col = iter2+1;
					break;
				}
			}
		}
		if(!InteriorColor.isEmpty()){
			//Selecting color using the row of the interior color
			List<WebElement> intColors = driver.findElements(By.xpath("//table[thead[tr[th[text()=' Interior Colors ']]]]/tbody/tr//h5"));
			
			for(int iter1=0;iter1<intColors.size();iter1++) {
				IntColors.add(intColors.get(iter1).getText());
			}
			System.out.println(IntColors);
			
			
			for(int iter2=0;iter2<IntColors.size();iter2++) {
				if(IntColors.get(iter2).contains(InteriorColor)) { //Test Data: Mention the color along with code or just code
					row = iter2+1;
					break;
				}
			}
		}
		
		
		if(!driver.findElement(By.xpath("//table[thead[tr[th[text()=' Interior Colors ']]]]/tbody/tr["+row+"]/td["+(col+1)+"]//span")).isSelected()){
			
			WebElement color = driver.findElement(By.xpath("//table[thead[tr[th[text()=' Interior Colors ']]]]/tbody/tr["+row+"]/td["+(col+1)+"]//span"));
			
			executor.executeScript("arguments[0].click()",color);
			
			Thread.sleep(3000);
			Thread.sleep(3000);
			
			queryObjects.logStatus(driver, Status.PASS, "Color Selection", "Vehicle Color Selected", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "Color Selection", "Vehicle Color not selected - Color not available for selection/ Select a valid color", null);
		
		executor.executeScript("document.body.style.zoom = '100%'");
		
		driver.findElement(By.xpath("//button[text()=' Next ']")).click();
		
	
	}

	public static void selectMethodToSendInfoToUser(WebDriver driver, String infoMethod) throws Exception{
		switch(infoMethod) {
		case "Open": driver.findElement(By.xpath("//button[@ng-click='open()']")).click();break;
		case "Email": driver.findElement(By.xpath("//button[@ng-click='email()']")).click();break;
		case "Print": driver.findElement(By.xpath("//button[@ng-click='print()']")).click();break;
		}
	}

	public static void saveSelectorOrOrder(WebDriver driver, String saveOrOrder) throws Exception {
		Thread.sleep(3000);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		switch(saveOrOrder) {
			//case "Save": RC_Global.buttonClick(driver, "Next");break;
			case "Order": 
				executor.executeScript("document.body.style.zoom = '100%'");
				
		//		RC_Global.buttonClick(driver, "Order");
				//executor.executeScript("document.body.style.zoom = '100%'");
				break;
		}
	}

	public static void enterDriverOrPoolDetails(WebDriver driver, String driverOrPool, String Name, String location) throws Exception{
		try
		{
			//Select a Driver 
			WebDriverWait wait = new WebDriverWait(driver,60);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h5/span[text()='Select a Driver']")));
			if(driverOrPool.equalsIgnoreCase("Pool")) {
				
			}
			driver.findElement(By.xpath("//div//button[contains(text(),'Search')]")).click();
			Thread.sleep(2000);
			if(!Name.isEmpty()) {
				
			}
			else
				driver.findElement(By.xpath("//div//tbody//tr[1]")).click();
			driver.findElement(By.xpath("//div[@id='selectCancelDiv']//button[contains(text(),'Select')]")).click();
			if(location.equalsIgnoreCase("No")){
				
			}
			else if(location.equalsIgnoreCase("Yes"))
				driver.findElement(By.xpath("//div//label//input[@id='matchEmployeeAddress']")).click();
//			driver.findElement(By.xpath("//div//button[contains(text(),'Save As Draft')]")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//div//button[contains(text(),'Next')]")).click();
			queryObjects.logStatus(driver, Status.PASS, "Driver Selection completed ", "Driver Selection successfully completed", null);
		}catch(Exception e) {
			 queryObjects.logStatus(driver, Status.FAIL, "Error in driver selection screen", e.getLocalizedMessage(), e);
		}
		
		
	}

	public static void enterOrderingProfileDetails(WebDriver driver, String FuelEnrollment) throws Exception{
		try
		{
			//Ordering Profile
			WebDriverWait wait = new WebDriverWait(driver,60);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h5/span[text()='Ordering Profile']")));
			Thread.sleep(2000);
			driver.findElement(By.xpath("//div[label[text()='Profile Name: ']]//select//option[2]")).click();
			 Thread.sleep(2000);
			 if(FuelEnrollment.equalsIgnoreCase("Yes")) {
				 
			 }
			driver.findElement(By.xpath("//div//button[contains(text(),'Next')]")).click();
			queryObjects.logStatus(driver, Status.PASS, "Ordering Profile ", "Profile selected", null);
		}catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Error Ordering Profile Screen", e.getLocalizedMessage(), e);
		}
		
	}	 
	
	public void viewOrEditOrderReviewDetails(WebDriver driver) throws Exception{
		try {
			//Order Review
			WebDriverWait wait = new WebDriverWait(driver,60);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h5/span[text()='Order Review']")));
			Thread.sleep(2000);
			queryObjects.logStatus(driver, Status.PASS, "Order Review ", "Order Review completed", null);
			
			}catch(Exception e)
			{
				queryObjects.logStatus(driver, Status.FAIL, "Error in Order Review", e.getLocalizedMessage(), e);
			}
	}

}
