package Billing.VehicleMovement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Billing;
import tools.TotalView.RC_Global;
public class TID_5_2_0_07 {
	public void VehicleMovementReviewPanel_ValidateInformationAndDestinationSectionsData(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String menu = "Billing";
        String firstSubMenu = "Vehicle Movement";
        String unitNumber ="";
        
        
        RC_Global.login(driver);
        RC_Global.navigateTo(driver,menu,firstSubMenu,"");
        RC_Global.enterCustomerNumber(driver, "LS008737", "", "",false);
    	RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Active lease",false);
        RC_Global.clickButton(driver, "Search",false,true);
        RC_Global.createNode(driver,"Select Grid row");
        RC_Global.waitElementVisible(driver, 60, "//tbody//tr", "Search Result Grid",true,true);
        RC_Global.clickUsingXpath(driver, "//tbody//tr[1]//td[2]","Select record from grid",true,true);
        Thread.sleep(1000);
        unitNumber = driver.findElement(By.xpath("//tbody//tr[1]//td[3]")).getText();
        RC_Global.clickButton(driver, "Initiate Vehicle Movement",true,true);
        
        RC_Global.validateHeaderName(driver, "Vehicle Movement - Request",false);
        RC_Global.createNode(driver,"Select customer node from the tree");
   //   RC_Global.clickUsingXpath(driver, "(//treeitem//ul//li/div)[1]","Select record from grid");
        RC_Billing.selectnodefromCustomerAssignment(driver, true);
        RC_Global.clickButton(driver, "Next",false,false);
        RC_Global.waitUntilPanelVisibility(driver, "Vehicle Movement - Review", "TV", true,false);
        RC_Global.validateHeaderName(driver, "Vehicle Movement - Review",false);
        Thread.sleep(1000);
        RC_Global.createNode(driver,"Validate section : Selected Vehicle Details");
        RC_Billing.screenSectionDetailsValidation(driver, "Selected Vehicle Details", "Unit", "",true);
        RC_Billing.screenSectionDetailsValidation(driver, "Selected Vehicle Details", "VIN", "",true);
        RC_Billing.screenSectionDetailsValidation(driver, "Selected Vehicle Details", "CVN", "",true);
        RC_Billing.screenSectionDetailsValidation(driver, "Selected Vehicle Details", "Year", "",true);
        RC_Billing.screenSectionDetailsValidation(driver, "Selected Vehicle Details", "Plate", "",true);
        RC_Billing.screenSectionDetailsValidation(driver, "Selected Vehicle Details", "Make", "",true);
        RC_Billing.screenSectionDetailsValidation(driver, "Selected Vehicle Details", "Vehicle Status", "",true);
        RC_Billing.screenSectionDetailsValidation(driver, "Selected Vehicle Details", "Model", "",true);
        
        RC_Global.createNode(driver,"Click Unit");
        RC_Global.clickUsingXpath(driver, "(//div[text()='"+unitNumber+"' and @ng-click='!Permissions.CanLinkToVehicleDetails || openVehicleDetails()'])[2]","Unit Number",true,false);
        RC_Global.validateHeaderName(driver, "Vehicle Details",false);
        RC_Global.panelAction(driver,"close", "Vehicle Details",false,true);
        
        
        RC_Global.clickUsingXpath(driver, "//button[contains(text(),'Edit')][1]","Edit button",true,true);
        RC_Global.validateHeaderName(driver, "Vehicle Movement - Request",false);
        RC_Global.clickButton(driver, "Next",true,true);
        RC_Global.validateHeaderName(	driver, "Vehicle Movement - Review",false);
        RC_Global.panelAction(driver, "expand", "Vehicle Movement - Review",false,true); 
        
        RC_Global.createNode(driver,"Validate section : Current Customer Structure Assignment");
        RC_Billing.screenSectionDetailsValidation(driver, "Current Customer Structure Assignment", "Customer", "",true);
        RC_Billing.screenSectionDetailsValidation(driver, "Current Customer Structure Assignment", "Fleet", "",true);
        RC_Billing.screenSectionDetailsValidation(driver, "Current Customer Structure Assignment", "Account", "",true);
        RC_Billing.screenSectionDetailsValidation(driver, "Current Customer Structure Assignment", "Sub-Account", "",true);
        RC_Billing.screenSectionDetailsValidation(driver, "Current Customer Structure Assignment", "Customer #", "",true);
        RC_Billing.screenSectionDetailsValidation(driver, "Current Customer Structure Assignment", "Fleet #", "",true);
        RC_Billing.screenSectionDetailsValidation(driver, "Current Customer Structure Assignment", "Account #", "",true);
        RC_Billing.screenSectionDetailsValidation(driver, "Current Customer Structure Assignment", "Sub-Account #", "",true);
        
        RC_Global.createNode(driver,"Validate section : New Customer Structure Assignment");
        RC_Billing.screenSectionDetailsValidation(driver, "New Customer Structure Assignment", "Customer", "",true);
        RC_Billing.screenSectionDetailsValidation(driver, "New Customer Structure Assignment", "Fleet", "",true);
        RC_Billing.screenSectionDetailsValidation(driver, "New Customer Structure Assignment", "Account", "",true);
        RC_Billing.screenSectionDetailsValidation(driver, "New Customer Structure Assignment", "Sub-Account", "",true);
        RC_Billing.screenSectionDetailsValidation(driver, "New Customer Structure Assignment", "Customer #", "",true);
        RC_Billing.screenSectionDetailsValidation(driver, "New Customer Structure Assignment", "Fleet #", "",true);
        RC_Billing.screenSectionDetailsValidation(driver, "New Customer Structure Assignment", "Account #", "",true);
        RC_Billing.screenSectionDetailsValidation(driver, "New Customer Structure Assignment", "Sub-Account #", "",true);
      
        RC_Global.clickUsingXpath(driver, "//button[contains(text(),'Edit')][1]","Edit button",true,true);
        RC_Global.validateHeaderName(driver, "Vehicle Movement - Request",false);
        RC_Global.panelAction(driver,"close", "Vehicle Movement - Request",false,true);
        
        queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}