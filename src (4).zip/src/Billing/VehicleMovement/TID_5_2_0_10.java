package Billing.VehicleMovement;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_5_2_0_10 {
	public void VehicleMovement_ValidateVehicleStatusSearchFilters(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		
		WebDriverWait wait = new WebDriverWait(driver,90);
	    RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Billing", "Vehicle Movement", "");
		
		RC_Global.createNode(driver, "Vehicle Movement - Validation of 'Active lease' Vehicle Status search filters");
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Active lease",true);
		RC_Global.clickUsingXpath(driver, "//button[text()='Search']","Search button",false,false);
		RC_Global.waitElementVisible(driver, 90, "//tbody/tr[1]", "Search Grid Record", false,true);
		Thread.sleep(1000);

		RC_Global.createNode(driver, "Vehicle Movement - Validation of 'Active services only' Vehicle Status search filters");
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Active services only",true);
		RC_Global.clickUsingXpath(driver, "//button[text()='Search']","Search button",false,false);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tbody/tr[1]")));
		
		RC_Global.createNode(driver, "Vehicle Movement - Validation of 'Closed' Vehicle Status search filters");
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Closed",true);
		RC_Global.clickUsingXpath(driver, "//button[text()='Search']","Search button",false,false);
		RC_Global.waitElementVisible(driver, 90, "//tbody/tr[1]", "Search Grid Record", false,true);

		RC_Global.createNode(driver, "Vehicle Movement - Validation of 'On Order' Vehicle Status search filters");
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "On Order",true);
		RC_Global.clickUsingXpath(driver, "//button[text()='Search']","Search button",false,false);
		RC_Global.waitElementVisible(driver, 90, "//tbody/tr[1]", "Search Grid Record", false,true);

		RC_Global.createNode(driver, "Vehicle Movement - Validation of 'Pending Activation' Vehicle Status search filters");
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Pending Activation",true);
		RC_Global.clickUsingXpath(driver, "//button[text()='Search']","Search button",false,false);
		RC_Global.waitElementVisible(driver, 90, "//tbody/tr[1]", "Search Grid Record", false,true);

		RC_Global.createNode(driver, "Vehicle Movement - Validation of 'Pending termination' Vehicle Status search filters");
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Pending termination",true);
		RC_Global.clickUsingXpath(driver, "//button[text()='Search']","Search button",false,false);
		RC_Global.waitElementVisible(driver, 90, "//tbody/tr[1]", "Search Grid Record", false,true);

		RC_Global.createNode(driver, "Vehicle Movement - Validation of 'Sold' Vehicle Status search filters");
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Sold",true);
		RC_Global.clickUsingXpath(driver, "//button[text()='Search']","Search button",false,false);
		RC_Global.waitElementVisible(driver, 90, "//tbody/tr[1]", "Search Grid Record", false,true);

		RC_Global.createNode(driver, "Vehicle Movement - Validation of 'Terminated lease' Vehicle Status search filters");
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Terminated lease",true);
		RC_Global.clickUsingXpath(driver, "//button[text()='Search']","Search button",false,false);
		RC_Global.waitElementVisible(driver, 90, "//tbody/tr[1]", "Search Grid Record", false,true);

		RC_Global.createNode(driver, "Vehicle Movement - Validation of 'Terminated service only' Vehicle Status search filters");
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Terminated service only",true);
		RC_Global.clickUsingXpath(driver, "//button[text()='Search']","Search button",true,false);
		RC_Global.waitElementVisible(driver, 90, "//tbody/tr[1]", "Search Grid Record", false,true);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}