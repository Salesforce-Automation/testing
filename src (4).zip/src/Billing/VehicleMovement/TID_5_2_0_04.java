package Billing.VehicleMovement;


import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Billing;
import tools.TotalView.RC_Global;

public class TID_5_2_0_04 {
	public void VehicleMovement_ValidateTheSearchFiltersFunctionality(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String SearchFilters = "Customer Number;Unit Number;Customer Vehicle Number;Full VIN or Last 8;Driver First Name;Driver Last Name;Pool Name;Plate State;Plate Number;Vehicle Status";
		WebDriverWait wait = new WebDriverWait(driver,120);
		String errorMsg = "Please enter a minimum of 8 characters for a VIN.";
		
	    RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Billing", "Vehicle Movement", "");
		RC_Global.verifyDisplayedMessage(driver, "Please note: Vehicle Movements are processed immediately and may have an impact on billing.", false);
		RC_Global.validateSpecifiedSearchFilters(driver, SearchFilters, false);
		RC_Global.enterCustomerNumber(driver, "LS010116", "", "", true);
		RC_Global.clickButton(driver, "Search", false,true);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tbody/tr")));
		String UnitNumber = driver.findElement(By.xpath("(//td[contains(@ng-click,'ToVehicleDetails')])[1]")).getText();
		String CVN = driver.findElement(By.xpath("(//td[contains(@ng-click,'ToVehicleDetails')])[2]")).getText();
		String VIN = driver.findElement(By.xpath("(//td[contains(@ng-click,'ToVehicleDetails')]/following-sibling::td[3])[1]")).getText();
		
		RC_Global.clickUsingXpath(driver, "(//tr[1]/td[3][contains(@ng-click,'LinkToVehicleDetails')])[1]", "Unit Number", false,true);
        RC_Global.waitUntilPanelVisibility(driver, "Vehicle Details", "TV", false,true);
        RC_Global.waitElementVisible(driver, 120, "//div[text()='LS010116 - ACRT Services']", "Vehicle Details",true,true);
        String DriverName = driver.findElement(By.xpath("(//button[contains(@title,'Open Driver Change')])[1]")).getText();
        RC_Global.panelAction(driver, "close", "Vehicle Details", false,true);
        RC_Global.panelAction(driver, "expand", "Vehicle Movement - Search", false,true);
        String[] Driver = DriverName.split(" ");
		

		queryObjects.logStatus(driver, Status.INFO, "Unit Number data---->", UnitNumber, null);
		queryObjects.logStatus(driver, Status.INFO, "CVN data---->", CVN, null);
		queryObjects.logStatus(driver, Status.INFO, "VIN data---->", VIN, null);
		queryObjects.logStatus(driver, Status.INFO, "DriverName data---->", DriverName, null);

		RC_Global.clickButton(driver, "Reset", false,true);
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Active lease", false);
		RC_Global.clickButton(driver, "Search", false,true);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tbody/tr")));
		RC_Billing.selectRowWithDriverNameFromGrid(driver, false);
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		Thread.sleep(1000);
		executor.executeScript("document.body.style.zoom = '10%'");
		Thread.sleep(2000);
		executor.executeScript("document.body.style.zoom = '100%'");
	
		
		RC_Global.createNode(driver,"Verify Buttons Available in the Screen");
		RC_Global.buttonStatusValidation(driver, "Search", "Enable", false);
		RC_Global.buttonStatusValidation(driver, "Reset", "Enable", false);
		RC_Global.buttonStatusValidation(driver, "Initiate Vehicle Movement", "Enable", false);
		
		RC_Global.createNode(driver,"Verify Hyperlink Field");
		RC_Global.verifyAsHyperlinkByLinkName(driver, "History", false);
		RC_Global.clickLink(driver, "History", false,true);
		executor.executeScript("document.body.style.zoom = '10%'");
		Thread.sleep(2000);
		executor.executeScript("document.body.style.zoom = '100%'");
		RC_Global.waitUntilPanelVisibility(driver, "Vehicle Movement History", "TV", false,true);
		RC_Global.panelAction(driver, "close", "Vehicle Movement History", false,true);
		RC_Global.panelAction(driver, "expand", "Vehicle Movement - Search", false,true);
		RC_Global.clickButton(driver, "Reset", false,true);
		
		RC_Global.createNode(driver, "Vehicle Movement -- Unit Number Search Filter Functionality Validation");
		RC_Global.validateSearchFilterAction(driver, "Unit Number",  UnitNumber,"", false,false);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tbody/tr")));
		RC_Global.clickButton(driver, "Reset", false,false);
		RC_Global.createNode(driver, "Vehicle Movement -- Customer Vehicle Number Search Filter Functionality Validation");
		RC_Global.validateSearchFilterAction(driver, "Customer Vehicle Number",  CVN,"",false,false);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tbody/tr")));
		RC_Global.clickButton(driver, "Reset", false,false);
		RC_Global.createNode(driver, "Vehicle Movement -- VIN Search Filter Functionality Validation");
		WebElement element2 = driver.findElement(By.xpath("//input[@placeholder='VIN']"));
		String Vinfst5dig = VIN.substring(0, 4);  
		RC_Global.enterInput(driver, Vinfst5dig, element2, false,false);
		RC_Global.clickButton(driver, "Search", false,false);
		RC_Global.verifyDisplayedMessage(driver, errorMsg, false);
		RC_Global.clickButton(driver, "Reset", false,false);
		RC_Global.validateSearchFilterAction(driver, "VIN",VIN,"",false,false);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tbody/tr")));
		RC_Global.clickButton(driver, "Reset", false,false);
		RC_Global.createNode(driver, "Vehicle Movement -- Driver First Name Search Filter Functionality Validation");
		RC_Global.validateSearchFilterAction(driver, "Driver First Name", Driver[0], "", false,false);
	    RC_Global.clickButton(driver, "Reset",false,false);
	    RC_Global.createNode(driver, "Vehicle Movement -- Driver Last Name Search Filter Functionality Validation");
	    RC_Global.validateSearchFilterAction(driver, "Driver Last Name", Driver[1], "",false,false);
        RC_Global.clickButton(driver, "Reset",false,false);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
