package Billing.VehicleMovement;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Billing;
import tools.TotalView.RC_Global;

public class TID_5_2_0_06 {
	
	public void VehicleMovement_ExternalFleetManagerMoveRequestNotEnrolledInFuel(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		String msg = "Please note: Vehicle Movements are processed immediately and may have an impact on billing.";
		String confirmationmsg = "Your vehicle move is complete!";
		String Msg1 = "View the vehicle details for unit";
		String Msg2 = ".";
	
		WebDriverWait wait = new WebDriverWait(driver,30);
		RC_Global.externalUserLogin(driver, "TestAutomationExtfleet","Yes");
		RC_Global.navigateTo(driver, "Billing", "Vehicle Movement", "");
		
		RC_Global.createNode(driver,"Verify search function and selection of row from grid");
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Active lease",false);
		RC_Global.clickButton(driver, "Search",false,true);
		RC_Billing.selectRowWithDriverNameFromGrid(driver,true);
		RC_Global.clickButton(driver, "Initiate Vehicle Movement",true,true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Movement - Request","TV", true,true);
		
		RC_Global.createNode(driver,"Verify node selection from new customer structure assignment");
		RC_Billing.selectnodefromCustomerAssignment(driver,true);
		WebElement element = driver.findElement(By.xpath("(//p[text()='"+msg+"'])[1]"));
		executor.executeScript("arguments[0].scrollIntoView();", element);
		RC_Global.clickUsingXpath(driver, "(//button[text()='Next'])[1]","Next button",false,true);
		
		RC_Global.createNode(driver,"Verify vehicle movement review screen sections");
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Movement - Review","TV", true,true);
		RC_Global.verifyAsHyperlinkByLinkName(driver, "Vehicle Information;Vehicle Destination;Driver Assignment;Client Data Fields;Current Program Enrollment",false);
	
		RC_Global.createNode(driver,"Button Validation in Vehicle Movemnet Review Screen");
		//button validation 
		RC_Global.buttonStatusValidation(driver, "Back", "Enable",false);
		RC_Global.buttonStatusValidation(driver, "Cancel", "Enable",false);
		RC_Global.buttonStatusValidation(driver, "Submit ", "Enable",false);
		RC_Global.clickUsingXpath(driver, "(//button[normalize-space(text())='Submit'])[1]","Submit button",true,true);
		
		RC_Global.createNode(driver,"Verify vehicle movement confirmation screen");
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Movement - Confirmation","TV", true,true);
		RC_Global.verifyDisplayedMessage(driver, confirmationmsg,true);
		RC_Billing.confirmationscreen(driver, Msg1, Msg2,true);
		RC_Global.clickLink(driver, RC_Billing.unitnumber,false,true);
		RC_Global.waitElementVisible(driver, 60, "//h5/span[text()='Vehicle Details']", "Vehicle Details",true,true);	
		RC_Global.panelAction(driver, "close", "Vehicle Details",false,true);
		RC_Global.buttonStatusValidation(driver, "Driver Data Change", "Presence",false);
		RC_Global.buttonStatusValidation(driver, "Move Another Unit", "Presence",false);
		RC_Global.clickButton(driver, "Driver Data Change",true,true);
		RC_Global.waitElementVisible(driver, 60, "//h5/span[text()='Driver Details']", "Driver Details",false,true);
		RC_Global.panelAction(driver, "close", "Driver Details",false,true);
		RC_Global.clickButton(driver, "Move Another Unit",false,true);
		RC_Global.waitElementVisible(driver, 60, "//h5/span[text()='Vehicle Movement - Search']", "Vehicle Movement - Search",false,true);
		RC_Global.panelAction(driver, "close", "Vehicle Movement - Search",false,true);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
