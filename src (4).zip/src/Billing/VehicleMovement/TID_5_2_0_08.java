package Billing.VehicleMovement;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Billing;
import tools.TotalView.RC_Global;

public class TID_5_2_0_08 {
	public void VehicleMovementReviewPanel_ValidateDriverAssignmentSection(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		
		String menu = "Billing";
        String firstSubMenu = "Vehicle Movement";
        String poolName ="";
        WebDriverWait wait = new WebDriverWait(driver,60);
        RC_Global.login(driver);
        RC_Global.navigateTo(driver,menu,firstSubMenu,"");
        RC_Global.enterCustomerNumber(driver, "LS008742", "", "",false);
        RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Active lease",false);
        RC_Global.clickButton(driver, "Search",false,true);
        RC_Global.createNode(driver,"Select Grid row");
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tbody//tr")));
        RC_Global.clickUsingXpath(driver, "//tbody//tr[4]//td[2]","Select record from grid",true,false);
        RC_Global.clickButton(driver, "Initiate Vehicle Movement",true,false);
       
        
        RC_Global.validateHeaderName(driver, "Vehicle Movement - Request",false);
        RC_Global.createNode(driver,"Select customer node from the tree");
        RC_Billing.selectnodefromCustomerAssignment(driver, true);
        RC_Global.clickButton(driver, "Next",false,true);
        Thread.sleep(2000);
        try {
        	driver.findElement(By.xpath("//button[text()='Yes']")).click();        
        }
        catch(Exception e) {
        RC_Global.waitElementVisible(driver, 60, "//span[text()='Vehicle Movement - Review']", "Vehicle Movement - Review",false,true);
        RC_Global.validateHeaderName(driver, "Vehicle Movement - Review",false);
        Thread.sleep(2000);
        }
        WebElement element = driver.findElement(By.xpath("(//div/fieldset/legend)[8]"));
        executor.executeScript("arguments[0].scrollIntoView();", element);
        
        if(driver.findElements(By.xpath("//legend[text()='Driver Information']")).size()>0){

        	RC_Global.createNode(driver,"Validate section : Driver Information ");
		        RC_Billing.screenSectionDetailsValidation(driver, "Driver Information", "Employee ID:", "",true);
		        RC_Billing.screenSectionDetailsValidation(driver, "Driver Information", "First Name:", "",true);
		        RC_Billing.screenSectionDetailsValidation(driver, "Driver Information", "Last Name:", "",true);
		        RC_Billing.screenSectionDetailsValidation(driver, "Driver Information", "Cell Phone:", "",true);
		        RC_Billing.screenSectionDetailsValidation(driver, "Driver Information", "Work Phone:", "",true);
		        RC_Billing.screenSectionDetailsValidation(driver, "Driver Information", "Home Phone:", "",true);
		        RC_Billing.screenSectionDetailsValidation(driver, "Driver Information", "Email:", "",true);

    		RC_Global.createNode(driver,"Validate section : Residential Address ");
		        RC_Billing.screenSectionDetailsValidation(driver, "Residential Address", "Address 1:", "",true);
		        RC_Billing.screenSectionDetailsValidation(driver, "Residential Address", "Address 2:", "",true);
		        RC_Billing.screenSectionDetailsValidation(driver, "Residential Address", "City:", "",true);
		        RC_Billing.screenSectionDetailsValidation(driver, "Residential Address", "State:", "",true);
		        RC_Billing.screenSectionDetailsValidation(driver, "Residential Address", "Zip:", "",true);
		        RC_Billing.screenSectionDetailsValidation(driver, "Residential Address", "County:", "",true);
		        RC_Billing.screenSectionDetailsValidation(driver, "Residential Address", "Country:", "",true);

			String FirstName = driver.findElement(By.xpath("//div[label='First Name:']/following-sibling::div")).getText();
		    RC_Global.clickUsingXpath(driver, "//div[normalize-space(text())='"+FirstName+"' and @ng-click='!Permissions.CanLinkToDriverDetails || editCurrentEmployee()']","First Name",true,true);
		    if(driver.findElements(By.xpath("//h5/span[text()='Edit Employee']")).size()>0){
		    	RC_Global.validateHeaderName(driver, "Edit Employee",false);
		        RC_Global.panelAction(driver,"close", "Edit Employee",false,true);
			}
			else if(driver.findElements(By.xpath("//h5/span[text()='Driver Details']")).size()>0){
				RC_Global.validateHeaderName(driver, "Driver Details",false);
		        RC_Global.panelAction(driver,"close", "Driver Details",false,true);
	        }
        }
        else if(driver.findElements(By.xpath("//legend[text()='Pool Information']")).size()>0){
    		RC_Global.createNode(driver,"Validate section : Pool Information ");

		        RC_Billing.screenSectionDetailsValidation(driver, "Pool Information", "Pool Name:", "",true);
		        RC_Billing.screenSectionDetailsValidation(driver, "Pool Information", "First Name:", "",true);
		        RC_Billing.screenSectionDetailsValidation(driver, "Pool Information", "Last Name:", "",true);
		        RC_Billing.screenSectionDetailsValidation(driver, "Pool Information", "Cell Phone:", "",true);
		        RC_Billing.screenSectionDetailsValidation(driver, "Pool Information", "Work Phone:", "",true);
		        RC_Billing.screenSectionDetailsValidation(driver, "Pool Information", "Home Phone:", "",true);
		        RC_Billing.screenSectionDetailsValidation(driver, "Pool Information", "Email:", "",true);
        		        
        		        
        	RC_Global.createNode(driver,"Validate section : Pool Address ");
		        RC_Billing.screenSectionDetailsValidation(driver, "Pool Address", "Address 1:", "",true);
		        RC_Billing.screenSectionDetailsValidation(driver, "Pool Address", "Address 2:", "",true);
		        RC_Billing.screenSectionDetailsValidation(driver, "Pool Address", "City:", "",true);
		        RC_Billing.screenSectionDetailsValidation(driver, "Pool Address", "State:", "",true);
		        RC_Billing.screenSectionDetailsValidation(driver, "Pool Address", "Zip:", "",true);
		        RC_Billing.screenSectionDetailsValidation(driver, "Pool Address", "County:", "",true);
		        RC_Billing.screenSectionDetailsValidation(driver, "Pool Address", "Country:", "",true);
        		        
        			
			String PoolName = driver.findElement(By.xpath("//div[normalize-space(label)='Pool Name:']/following-sibling::div")).getText();
			RC_Global.clickUsingXpath(driver, "//div[normalize-space(text())='"+PoolName+"' and @ng-click='openCurrentPoolManagement()']","Pool Name",true,true);
			RC_Global.validateHeaderName(driver, "Pool Management",false);
			RC_Global.panelAction(driver,"close", "Pool Management",false,true);
       }
       RC_Global.panelAction(driver, "close", "Vehicle Movement - Review",false,true);
	}
}