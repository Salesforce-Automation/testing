package Billing.VehicleMovement;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Billing;
import tools.TotalView.RC_Global;

public class TID_5_2_0_11 {
	
	public void VehicleMovement_CancelMoveRequest(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		String msg = "Please note: Vehicle Movements are processed immediately and may have an impact on billing.";
		
		WebDriverWait wait = new WebDriverWait(driver,30);
	    RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Billing", "Vehicle Movement", "");
		
		RC_Global.createNode(driver,"Verify search function and selection of row from grid");
		RC_Global.enterCustomerNumber(driver, "LS010120", "", "",false);
		RC_Global.selectDropdownOption(driver, "Vehicle Status", "Active lease",false,true);
		RC_Global.clickButton(driver, "Search",false,true);
		RC_Billing.selectRowWithDriverNameFromGrid(driver,true);
		RC_Global.clickButton(driver, "Initiate Vehicle Movement",true,true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Movement - Request","TV",true,true);
		
		RC_Global.createNode(driver,"Verify node selection from new customer structure asignment");
		executor.executeScript("document.body.style.zoom = '60%'");
        executor.executeScript("document.body.style.zoom = '100%'");
        
		RC_Billing.selectnodefromCustomerAssignment(driver,true);
		RC_Global.clickUsingXpath(driver, "(//button[text()='Next'])[1]","Next button",false,true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Movement - Review","TV",true,true);
		
		RC_Global.createNode(driver,"Verify vehicle movement review screen and cancel move request");
		executor.executeScript("window.scrollBy(0,1800)");
		RC_Global.buttonStatusValidation(driver, "Cancel", "Enable",false);
		executor.executeScript("window.scrollBy(1800,0)");
		RC_Global.buttonStatusValidation(driver, "Cancel", "Enable",false);
		
		RC_Global.clickUsingXpath(driver, "(//button[text()='Cancel'])[1]","Cancel button",true,true);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
