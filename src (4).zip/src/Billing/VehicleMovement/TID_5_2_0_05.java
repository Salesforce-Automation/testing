package Billing.VehicleMovement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Billing;
import tools.TotalView.RC_Global;

public class TID_5_2_0_05 {
	public void ValidateTheResultGridAndHyperlinks(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String menu = "Billing";
        String firstSubMenu = "Vehicle Movement";
        String columnName ="Customer #;Customer Name;Unit Number;CVN;Driver/Pool Name;VIN;Year;Make;Model;Plate;Address;City;State;Zip;Vehicle Status;Fleet #;Fleet Name;Account #;Account Name;Sub-Account #;Sub-Account Name";
        
        RC_Global.login(driver);
        RC_Global.navigateTo(driver,menu,firstSubMenu,"");
        RC_Global.enterCustomerNumber(driver, "LS008737", "", "",false);
        RC_Global.clickButton(driver, "Search",false,true);
        RC_Global.verifyColumnNames(driver, columnName,true);
        
        RC_Global.verifySortFunction(driver, "Unit Number",false);
        RC_Global.verifySortFunction(driver, "Year",false);
        RC_Global.verifySortFunction(driver, "Make",false);
        RC_Global.verifySortFunction(driver, "Model",false);
        
        RC_Global.createNode(driver,"Select Grid row");
        RC_Global.clickUsingXpath(driver, "//tbody//tr[2]//td[2]","",true,false);
        RC_Global.createNode(driver,"Verify Unit Number as hypertext and navigate to Vehicle Details page");
        RC_Global.clickUsingXpath(driver,"(//tbody//tr[1]/td[3])[1]", "Unit Number",false,false);
        RC_Global.validateHeaderName(driver, "Vehicle Details",true);
        RC_Global.panelAction(driver, "close","Vehicle Details",false,true);
        RC_Global.panelAction(driver, "expand", "Vehicle Movement - Search",false,true);
       
        RC_Global.createNode(driver,"Verify CVN displayed as hypertext and navigate to Vehicle Details page");
        RC_Global.clickUsingXpath(driver,"(//tbody//tr[1]/td[4])[1]", "CVN",false,false);
        RC_Global.validateHeaderName(driver, "Vehicle Details",true);
        RC_Global.panelAction(driver, "close","Vehicle Details",false,true);
        RC_Global.panelAction(driver, "expand", "Vehicle Movement - Search",false,true);
        
        RC_Global.createNode(driver,"Verify Driver/Pool Name displayed as hypertext and navigate to Driver Details page");
        RC_Global.clickUsingXpath(driver,"(//tbody//tr[1]/td[5])[1]", "Driver/Pool Name",false,false);
        RC_Global.validateHeaderName(driver, "Driver Details",true);
        RC_Global.panelAction(driver, "close","Driver Details",false,true);
        RC_Global.panelAction(driver, "expand", "Vehicle Movement - Search",false,true);
        
        RC_Global.downloadAndVerifyFileDownloaded(driver, "Export", "Export to Excel Functionality",true);
        
        queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}

}
