package Billing.VehicleMovement;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Billing;
import tools.TotalView.RC_Global;

public class TID_5_2_0_01 {
	public void VehicleMovement_SubmitMoveRequest(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{

		String menu = "Billing";
        String firstSubMenu = "Vehicle Movement";
        String newUnitNo="";

        RC_Global.login(driver);
        RC_Global.navigateTo(driver,menu,firstSubMenu,"");
        RC_Global.enterCustomerNumber(driver, "LS010087", "", "", false);
        RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Active lease",false);
        RC_Global.clickButton(driver, "Search",true,true);
        RC_Global.createNode(driver,"Select a row from result grid");
        RC_Global.waitElementVisible(driver,90,"//tbody//tr[2]//td[2]","Grid Row",false,false);
        RC_Global.clickUsingXpath(driver, "//tbody//tr[2]//td[2]","Selct Record from grid",true,false);
       
        RC_Global.clickButton(driver, "Initiate Vehicle Movement",true,true);
        RC_Global.validateHeaderName(driver, "Vehicle Movement - Request",false);
        RC_Global.createNode(driver,"Select customer node from the tree");
        
        int custNodeId = RC_Billing.selectCustomerStructure(driver,0,false);
        String currentlyAssigned = driver.findElement(By.xpath("//span[contains(text(),'Currently Assigned')]")).getText();
        
        currentlyAssigned = currentlyAssigned.replace("(Currently Assigned)", "");
        Thread.sleep(3000);
        RC_Global.clickUsingXpath(driver, "//button[contains(text(),'Next')]","Next button",true,true);
        
        RC_Global.validateHeaderName(driver, "Vehicle Movement - Review",true);
        RC_Global.clickButton(driver, "Back",false,true);
        custNodeId = RC_Billing.selectCustomerStructure(driver,custNodeId,false);
        String clientNode=driver.findElement(By.xpath("(//treeitem//ul//li/div)["+custNodeId+"]/span")).getText();
        queryObjects.logStatus(driver, Status.PASS, "Selected client node is ", clientNode, null);
        Thread.sleep(1000);
        RC_Global.clickUsingXpath(driver, "//button[contains(text(),'Next')]","Next button",true,true);
       
        RC_Global.validateHeaderName(driver, "Vehicle Movement - Review",false);
        String submitButtonBelowWarning = "//div[div[p[normalize-space(text())='Please note: Vehicle Movements are processed immediately and may have an impact on billing.']]]/div[2]/div/button[normalize-space(text())='Submit']";
        RC_Global.clickUsingXpath(driver, submitButtonBelowWarning,"Submit button",true,true); //The xpath validates that Submot button is present below the warning message - Navira
        
        RC_Global.waitUntilPanelVisibility(driver,"Vehicle Movement - Confirmation","TV", true,true);
        RC_Global.validateHeaderName(driver, "Vehicle Movement - Confirmation",false);
        newUnitNo=driver.findElement(By.xpath("//p[contains(text(),'View the vehicle details for unit')]//a")).getText();
        queryObjects.logStatus(driver, Status.PASS, "Vehicle Movement confirmation screen displays New Unit Number", newUnitNo, null);
        RC_Global.createNode(driver,"Select Unit Number");
        RC_Global.clickUsingXpath(driver, "//p[contains(text(),'View the vehicle details for unit')]//a","View the Vehicle Details for unit",true,true);
        RC_Global.validateHeaderName(driver, "Vehicle Details",false);
        RC_Global.panelAction(driver, "close", "Vehicle Details",false,true);
        
        RC_Global.verifyDisplayedMessage(driver, "If you wish to change the Driver, Vehicle Location or Client Data click here.",true);// Navira
        RC_Global.verifyDisplayedMessage(driver, "View the vehicle details for unit "+newUnitNo+".",false);//Navira
        RC_Global.clickButton(driver, "Move Another Unit",true,true);
        RC_Global.validateHeaderName(driver, "Vehicle Movement - Search",false);
        RC_Global.panelAction(driver, "expand", "Vehicle Movement - Search",false,true);
        RC_Global.enterInput(driver, newUnitNo, ((WebElement)(driver.findElement(By.xpath("//input[@id='unitNumber']")))),true,true);
        RC_Global.clickButton(driver, "Search",false,true);
        RC_Global.createNode(driver,"Select a row from result grid");
        RC_Global.waitElementVisible(driver,60,"//tbody//tr[1]//td[2]","Grid Row",false,true);
        RC_Global.clickUsingXpath(driver, "//tbody//tr[1]//td[2]","Select record from grid",true,true);
        RC_Global.clickButton(driver, "Initiate Vehicle Movement",true,true);
        RC_Global.validateHeaderName(driver, "Vehicle Movement - Request",false);
        RC_Global.createNode(driver,"Select customer node from the tree");
        Thread.sleep(3000);
        RC_Global.clickUsingXpath(driver, "//span[contains(text(),'"+currentlyAssigned.trim()+"')]","Currently Assigned",true,true);
        Thread.sleep(3000);
        
        queryObjects.logStatus(driver, Status.PASS, "Selected client node is ", currentlyAssigned, null);
        RC_Global.validateHeaderName(driver, "Vehicle Movement - Request",false);
        
        RC_Global.clickUsingXpath(driver, "//button[contains(text(),'Next')]","Next button",true,true);
        RC_Global.validateHeaderName(driver, "Vehicle Movement - Review",false);
        RC_Global.clickButton(driver, "Submit",false,true);
        Thread.sleep(2000);
        RC_Global.waitUntilPanelVisibility(driver,"Vehicle Movement - Confirmation","TV", true,true);
        RC_Global.validateHeaderName(driver, "Vehicle Movement - Confirmation",false);
        newUnitNo=driver.findElement(By.xpath("//p[contains(text(),'View the vehicle details for unit')]//a")).getText();
        queryObjects.logStatus(driver, Status.PASS, "Vehicle Movement confirmation screen opened and details updated with Unit Number", newUnitNo, null);
        RC_Global.clickButton(driver, "Move Another Unit",false,true);
        RC_Global.validateHeaderName(driver, "Vehicle Movement - Search",false);
        RC_Global.enterInput(driver, newUnitNo, ((WebElement)(driver.findElement(By.xpath("//input[@id='unitNumber']")))),false,true);
        RC_Global.clickButton(driver, "Search",false,true);
        
        RC_Global.createNode(driver,"Select a row from result grid");
        RC_Global.waitElementVisible(driver,60,"//tbody//tr[1]//td[2]","Grid Row",false,true);
        RC_Global.clickUsingXpath(driver, "//tbody//tr[1]//td[2]","Select record from grid",false,true);
        RC_Global.clickUsingXpath(driver, "//div//label[contains(text(),'History')]","history",true,true);
        RC_Global.validateHeaderName(driver, "Vehicle Movement History",false);
        RC_Global.panelAction(driver, "close","Vehicle Movement - Search",false,true);
        RC_Global.panelAction(driver, "expand", "Vehicle Movement History",false,true); 
        RC_Billing.getUserHistory(driver, clientNode,true);
        
        queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
