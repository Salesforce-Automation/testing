package Billing.EBilling.ViewBilling;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Billing;
import tools.TotalView.RC_Global;

public class TID_5_1_3_03 {

	public void ValidationOfTotalNON_RentalChargeForInvoice(WebDriver driver, BFrameworkQueryObjects queryObjects)throws Exception
	{
		String month = "March 2021";
		
		WebDriverWait wait = new WebDriverWait(driver,60);
	    RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Billing", "E-Billing", "View Billing");
		
		RC_Global.createNode(driver,"Verify Total Non Rental Charge For Invoice");
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		
		RC_Global.createNode(driver,"Verify Total NON Rental Charge For Invoice");
		RC_Global.waitElementVisible(driver, 120, "(//tbody/tr[1])[2]", "Grid Result",false,true);
		RC_Global.clickUsingXpath(driver, "//tr/td[contains(text(),'"+month+"')]/../td[@ng-click='openSummariesByInvoice(data)']", "Total Amount Billed",true,false);
		
		RC_Global.panelAction(driver, "expand", "E-Billing Summary By Invoice",true,true);
		RC_Global.waitElementVisible(driver, 120, "//span[text()='E-Billing Summary By Invoice']", "E-Billing Summary By Invoice",false,true);
		RC_Global.waitElementVisible(driver, 120, "(//table/tbody//tr)[15]", "Grid Result",false,true);
		RC_Global.clickUsingXpath(driver, "(//td[@title='Open Summary By Non-Rental Charge'])[1]", "Total Non-Rental Charges",true,true);
		RC_Global.panelAction(driver, "close", "E-Billing Summary By Invoice",true,true);
		
		RC_Global.waitElementVisible(driver, 120, "//span[text()='E-Billing Summary By Non-Rental Charge']", "E-Billing Summary By Non-Rental Charge",false,true);
		RC_Global.panelAction(driver, "expand", "E-Billing Summary By Non-Rental Charge",true,true);
		RC_Global.waitElementVisible(driver, 120, "(//table/tbody//tr)[15]", "Grid Result",false,true);
		RC_Global.clickUsingXpath(driver, "(//td[@title='Open Summary By Charge Description By Vehicle'])[1]", "Total Amount Billed",true,true);
		
		RC_Global.waitElementVisible(driver, 120, "//span[text()='E-Billing Summary by Charge Description by Vehicle']", "E-Billing Summary By Charge Description By Vehicle",false,true);
		RC_Global.waitElementVisible(driver, 120, "//table/tbody/tr[1]/td[1]/div", "Grid Result",false,true);
		RC_Global.clickUsingXpath(driver, "(//td[@title='Open Summary By Charge Description'])[1]", "Charge Amount",true,true);
		
		RC_Global.waitElementVisible(driver, 120, "//span[text()='E-Billing Summary by Charge Description']", "E-Billing Summary By Charge Description",false,true);
		RC_Global.waitElementVisible(driver, 120, "//table/tbody/tr[1]/td[1]/div", "Grid Result",false,true);
		RC_Global.clickUsingXpath(driver, "(//td[@title='Open Vehicle Details'])[1]", "Unit #",true,true);
		
		RC_Global.waitUntilPanelVisibility(driver, "Vehicle Details", "TV",false,true);
		RC_Global.panelAction(driver, "close", "Vehicle Details",false,true);
		RC_Global.panelAction(driver, "close", "E-Billing Summary by Charge Description",false,true);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}

}
