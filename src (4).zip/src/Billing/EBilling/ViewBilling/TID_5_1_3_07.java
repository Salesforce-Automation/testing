package Billing.EBilling.ViewBilling;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.LeaseWave.RC_LW_Global;
import tools.TotalView.RC_Billing;
import tools.TotalView.RC_Global;

public class TID_5_1_3_07 {
	
	public void ValidateTotalAmountBilledInTotalViewMatchesLeasewave(WebDriver driver, BFrameworkQueryObjects queryObjects)throws Exception
	{
		String month = "March 2021";
		String CustomerNumber = "LS008742";
		//String errorMsg = "Attached are copies of select E-Billing documentation from Merchants Fleet Management";
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		
	    RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Billing", "E-Billing", "View Billing");
		RC_Global.enterCustomerNumber(driver, CustomerNumber, "", "", true);
		
		RC_Global.createNode(driver,"Validate Total Amount Billed In TotalView");
		RC_Global.waitElementVisible(driver, 120, "(//tbody/tr[1])[2]", "Grid Result",false,false);
		RC_Global.clickUsingXpath(driver, "//tr/td[contains(text(),'"+month+"')]/../td[@ng-click='openSummariesByInvoice(data)']", "Total Amount Billed",true,false);
		
		//get total amount billed text
		RC_Global.waitElementVisible(driver, 120, "//span[text()='E-Billing Summary By Invoice']", "E-Billing Summary By Invoice",false,true);
		RC_Global.panelAction(driver, "expand", "E-Billing Summary By Invoice",true,true);
		RC_Global.waitElementVisible(driver, 120, "(//table//tbody//tr[1])[2]", "Grid Result",false,true);
		String TotalNonRentalcharges = driver.findElement(By.xpath("//table//tr[1]/td[4]")).getText();
		String Invoiceno = driver.findElement(By.xpath("//table//tr[1]/td[2]/div/span")).getText();
		Thread.sleep(1000);
		queryObjects.logStatus(driver, Status.INFO, "Particular month TotalNonRentalcharges", TotalNonRentalcharges, null);
		queryObjects.logStatus(driver, Status.INFO, "Particular month Invoiceno", Invoiceno, null);
		
		
		RC_LW_Global.leaseWaveLogin(driver,true);
		RC_Global.clickUsingXpath(driver,"//a[contains(text(),'Portfolio Management')]", "Portfolio Management",true,true);
		RC_Global.waitElementVisible(driver, 120, "//a[contains(text(),'Portfolio Management')]", "Portfolio Management",false,true);
	    	String home =  driver.findElement(By.xpath("//a[contains(text(),'Portfolio Management')]")).getText();
	    	
	   	if(home.contains("Portfolio Management")) {
	    	queryObjects.logStatus(driver, Status.PASS, "Navigation to Portfolio Management Menu", "Successfully", null);
	    }
		RC_Global.clickUsingXpath(driver,"//td[@accesskey='4' and text()='.Receivables / Receipts']", "Receivables / Receipts",true,true);
	    RC_Global.clickUsingXpath(driver,"//tr[contains(@igurl,'Invoicing')]/td/div[text()='View Invoice']", "View Invoice",true,true);
	   	
	   	RC_Global.createNode(driver, "Validate Total Amount Billed In TotalView Matches Leasewave");
	   	RC_Global.waitElementVisible(driver, 120, "//span[text()='Invoice Search' and @id='ctl00_PageTitle']", "Invoice Search",false,false);
		RC_Global.clickUsingXpath(driver,"//input[contains(@onclick,'AccountNo')]", "AccountNo",true,false);
		WebElement element = driver.findElement(By.xpath("//span/input[contains(@name,'AccountNo') and @onchange='AccountNumber_OnChange()']"));
		RC_Global.enterInput(driver, CustomerNumber, element,true ,true);
		
		WebElement element1 =  driver.findElement(By.xpath("//span/input[contains(@name,'InvoiceNoFrom')]"));
        RC_Global.enterInput(driver, Invoiceno, element1,true,true );
		Thread.sleep(1000);
	   	RC_Global.clickUsingXpath(driver,"//button[text()='Searc']", "Search",true,true);
	    
	    //validate the amount and columns
        RC_Billing.verifyGridColumnsByName(driver,"Select;Account Number;Invoice Number (PDF);Invoice Number(Excel);Invoice Group;Collection Group;Due Date;Original Memo Balance;Original Non Memo Balance;Outstanding Memo Balance;Outstanding Non Memo Balance;Receivable Amount;Receivable Balance;Run Date",true);
        
	    String OriginalNonMemoBalance = driver.findElement(By.xpath("//table//tr[1]/td[10]/nobr")).getText();
	    
	    if(TotalNonRentalcharges.equalsIgnoreCase(OriginalNonMemoBalance)) {
	    	queryObjects.logStatus(driver, Status.PASS, "Total Amount Billed -"+OriginalNonMemoBalance+" in totalview matches leasewave", "Successfully", null);
	    }
	    else 
	    	queryObjects.logStatus(driver, Status.FAIL, "Total Amount Billed - "+OriginalNonMemoBalance+" in totalview not matches leasewave", "", null);
	    
	    RC_LW_Global.leaseWaveLogOut(driver,false);
	    
	    queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}	

}
