package Billing.EBilling.ViewBilling;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_5_1_3_08 {


	public void BillingAdvanceSearchUsingExternalUser (WebDriver driver, BFrameworkQueryObjects queryObjects)throws Exception
	{
		
	    RC_Global.externalUserLogin(driver, "kentuckytest", "Yes");
		RC_Global.navigateTo(driver, "Billing", "E-Billing", "View Billing");
		RC_Global.validateHeaderName(driver, "View Billing", false);
		RC_Global.buttonStatusValidation(driver, "Advanced Search", "Presence", false);
		RC_Global.clickButton(driver, "Advanced Search",true,true);
		RC_Global.validateHeaderName(driver, "Search E-Billing", false);
		RC_Global.selectDropdownOption(driver, "receivableTypes", "Fleet Sundry (Lease-Based)", true,true);
		RC_Global.clickButton(driver, "Search",true,true);
		Thread.sleep(2000);
		RC_Global.waitElementVisible(driver, 120, "//span[text()='E-Billing Summary By Non-Rental Charge']", "E-Billing Summary By Non-Rental Charge",false,true);
		RC_Global.panelAction(driver, "expand", "E-Billing Summary By Non-Rental Charge", false,true);
		String DwnFileNm = driver.findElement(By.xpath("(//td[@invoice-number='data.InvoiceNumber']//span)[1]")).getText();
        RC_Global.clickUsingXpath(driver,"//table/tbody/tr[1]/td[2]/div/img[@src='assets/img/pdf-icon.png']", "Invoice #",true,true);
        Thread.sleep(5000);
       
        try {
        String home = System.getProperty("user.home");
             
        boolean flag = false;
        File listofFiles= new File(home+"/Downloads/" );
        for (File file :listofFiles.listFiles() ) {
            String filename= file.getName();
            if(filename.contains(DwnFileNm)) {
                flag = true;
                file.delete();
                break;
        }
        }
        if(flag) {
           queryObjects.logStatus(driver, Status.PASS, "Invoice PDF download", "Successfully", null);
           }
         else{ 			
             queryObjects.logStatus(driver, Status.FAIL, "Invoice PDF download", "Failed", null);
        }
        }
        catch(Exception e) {			
        	queryObjects.logStatus(driver, Status.FAIL, "Download and verify failed", e.getLocalizedMessage(), e);
        }
       
        
        RC_Global.clickUsingXpath(driver, "(//td/input[@ng-click='toggleInvoiceSelected(data)'])[1]", "Invoice",true,true);
        Thread.sleep(2000);
        RC_Global.createNode(driver,"Validate Open Email & Print Buttons Functionalities");
        RC_Global.buttonStatusValidation(driver, "Open", "Enable",true);
        RC_Global.buttonStatusValidation(driver, "Email", "Enable",true);
        RC_Global.buttonStatusValidation(driver, "Print", "Enable",true);
        RC_Global.downloadAndVerifyFileDownloaded(driver,"Export","Export To Excel Functionality", true);
        RC_Global.panelAction(driver, "close", "E-Billing Summary By Non-Rental Charge", false,true);
        RC_Global.logout(driver, false);
	}
}
