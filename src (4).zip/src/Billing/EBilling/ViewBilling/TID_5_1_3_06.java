package Billing.EBilling.ViewBilling;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Billing;
import tools.TotalView.RC_Global;

public class TID_5_1_3_06 {
	public void ViewBillingAdvanceSearch(WebDriver driver, BFrameworkQueryObjects queryObjects)throws Exception
	{
		WebDriverWait wait = new WebDriverWait(driver,120);
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Billing", "E-Billing", "View Billing");
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "",false);
		
		RC_Global.createNode(driver,"View Billing - Advance Search Function");
		RC_Global.panelAction(driver, "expand", "View Billing",false,false);
		RC_Global.clickButton(driver, "Advanced Search",true,false);
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		String Element1 = "Search E-Billing";
		RC_Global.waitElementVisible(driver, 120, "//span[text()='Search E-Billing']", Element1,false,true);
		String input="01/02/2021" ;
		WebElement element1 = driver.findElement(By.xpath("//input[@placeholder='Invoice Date Range Start']"));
		RC_Global.enterInput(driver, input, element1,true ,true);
		String input1="01/20/2021" ;
		WebElement element2 = driver.findElement(By.xpath("//input[@placeholder='Invoice Date Range End']"));
		RC_Global.enterInput(driver, input1, element2,true,true);
		RC_Global.clickButton(driver, "Search",true,true);
		RC_Billing.waitForloadingIconToDisappear(driver, "//button[contains(text(),'Search') and @type='submit']");
		
		RC_Global.waitElementVisible(driver, 120, "//span[text()='E-Billing Summary By Invoice']", "E-Billing Summary By Invoice",false,true);
		RC_Global.panelAction(driver, "close", "E-Billing Summary By Invoice",false,true);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
