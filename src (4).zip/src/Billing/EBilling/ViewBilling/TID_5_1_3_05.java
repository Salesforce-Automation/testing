package Billing.EBilling.ViewBilling;

import java.io.File;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.aventstack.extentreports.Status;
import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Billing;
import tools.TotalView.RC_Global;


public class TID_5_1_3_05 {

    public void Validate_Open_Email_PrintButtonsFunctionalitiesInEBilling(WebDriver driver, BFrameworkQueryObjects queryObjects)throws Exception
    {
        String month = "March 2021";
        String errorMsg = "Attached are copies of select E-Billing documentation from Merchants Fleet Management";
        String DwnFileNm = null;
        JavascriptExecutor executor = (JavascriptExecutor)driver;
        
         RC_Global.login(driver);
         RC_Global.navigateTo(driver, "Billing", "E-Billing", "View Billing");
            RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
            RC_Global.createNode(driver,"Validate Open Email & Print Buttons Functionalities");
            RC_Global.waitElementVisible(driver, 120, "(//tbody/tr[1])[2]", "Grid Result",false,false);
            RC_Global.clickUsingXpath(driver, "//tr/td[contains(text(),'"+month+"')]/../td[@ng-click='openSummariesByInvoice(data)']", "Total Amount Billed",true,false);
            Thread.sleep(2000);
            RC_Global.waitElementVisible(driver, 120, "//span[text()='E-Billing Summary By Invoice']", "E-Billing Summary By Invoice",false,false);
            RC_Global.panelAction(driver, "expand", "E-Billing Summary By Invoice",true,true);
            RC_Global.waitElementVisible(driver,120,"((//tbody)[2]//tr[1])/td[3]","Grid Row", false,true);
        DwnFileNm = driver.findElement(By.xpath("(//td[@invoice-number='data.InvoiceNumber']//span)[1]")).getText();
        RC_Global.clickUsingXpath(driver,"//table/tbody/tr[1]/td[2]/div/img[@src='assets/img/pdf-icon.png']", "Invoice #",true,false);
        Thread.sleep(5000);
        RC_Global.createNode(driver,"Validate File Download");
        try {
        String home = System.getProperty("user.home");
             
        boolean flag = false;
        File listofFiles= new File(home+"/Downloads/" );
        for (File file :listofFiles.listFiles() ) {
            String filename= file.getName();
            if(filename.contains(DwnFileNm)) {
                flag = true;
                file.delete();
                break;
        }
        }
        if(flag) {
           queryObjects.logStatus(driver, Status.PASS, "Invoice PDF download", "Successfully", null);
           }
         else{ 			
             queryObjects.logStatus(driver, Status.FAIL, "Invoice PDF download", "Failed", null);
        }
        }
        catch(Exception e) {			
        	queryObjects.logStatus(driver, Status.FAIL, "Download and verify failed", e.getLocalizedMessage(), e);
        }
            
        RC_Global.clickUsingXpath(driver, "(//td/input[@ng-click='toggleInvoiceSelected(data)'])[1]", "Invoice",true,true);
        
        RC_Global.createNode(driver,"Validate Open Email & Print Buttons Functionalities");
        RC_Global.buttonStatusValidation(driver, "Open", "Enable",false);
        RC_Global.buttonStatusValidation(driver, "Email", "Enable",false);
        RC_Global.buttonStatusValidation(driver, "Print", "Enable",false);
        RC_Global.clickButton(driver, "Open",false,true);
		Thread.sleep(1000);
		RC_Global.waitElementNotVisible(driver, 60, "//div[@ng-show='isOpening']/i", "OpenButton-Spinner", false, true);
		RC_Global.createNode(driver,"Validate File Download");
        try {
            String home = System.getProperty("user.home");
            
            boolean flag = false;
            File listofFiles= new File(home+"/Downloads/" );
            for (File file :listofFiles.listFiles() ) {
                String filename= file.getName();
                if(filename.contains(DwnFileNm)) {
                    flag = true;
                    file.delete();
                    break;
            }
            }
            if(flag) {
               queryObjects.logStatus(driver, Status.PASS, "Invoice PDF download", "Successfully", null);
               }
             else{ 			
                 queryObjects.logStatus(driver, Status.FAIL, "Invoice PDF download", "Failed", null);
            }
            }
    		catch(Exception e) {			
    			queryObjects.logStatus(driver, Status.FAIL, "PDF is not downloaded", e.getLocalizedMessage(), e);
    		}
    		RC_Billing.waitForloadingIconToDisappear(driver, "//button[@ng-disabled='buttonsDisabled() || !Permissions.CanViewInvoice']");
        
        Thread.sleep(1000);
        RC_Global.waitElementVisible(driver, 120, "//span[text()='E-Billing Summary By Invoice']", "E-Billing Summary By Invoice",false,true);
        RC_Global.clickUsingXpath(driver, "(//td/input[@ng-click='toggleInvoiceSelected(data)'])[1]", "Invoice",true,true);     
//        RC_Global.clickUsingXpath(driver, "(//td/input[@ng-click='toggleInvoiceSelected(data)'])[1]", "Invoice",true);     
        RC_Global.clickButton(driver, "Email",true,true);
        RC_Global.waitElementVisible(driver, 120, "//h3[text()='Email Documents']", "Email Documents",false,true);
        RC_Global.verifyDisplayedMessage(driver, errorMsg,true);
        Thread.sleep(1000);
        RC_Global.scrollById(driver, "(//div[4]//button[2][normalize-space(text()='Cancel')])[2]");
        RC_Global.clickUsingXpath(driver, "(//div[4]//button[2][normalize-space(text()='Cancel')])[2]", "Cancel",false,true);
        Thread.sleep(1000);
        RC_Global.waitElementVisible(driver, 120, "//span[text()='E-Billing Summary By Invoice']", "E-Billing Summary By Invoice",false,true);
       
        RC_Global.panelAction(driver, "close", "E-Billing Summary By Invoice",false,true);
        
        queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
    }
}