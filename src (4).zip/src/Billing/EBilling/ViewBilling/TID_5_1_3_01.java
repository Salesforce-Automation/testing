package Billing.EBilling.ViewBilling;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Billing;
import tools.TotalView.RC_Global;

public class TID_5_1_3_01 {
	public void ValidationOfViewBillingInformationAndInvoiceDetail(WebDriver driver, BFrameworkQueryObjects queryObjects)throws Exception
	{
		String month = "March 2021";
		String ColumnNmes = "Invoice Month;Invoice #;Total Rental Charges;Total Non-Rental Charges;Total Amount Billed;Supporting Documents;Invoice";
	
	    WebDriverWait wait = new WebDriverWait(driver,120);
	    RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Billing", "E-Billing", "View Billing");
		
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		RC_Global.createNode(driver,"Verify View Billing Information And Invoice Detail");
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//tbody/tr[1])[2]")));
		RC_Global.verifyColumnNames(driver, "Invoice Month;Total Amount Billed",false);
		RC_Global.verifyFieldAsHyperLink(driver, "Total Amount Billed",true);
		RC_Global.clickUsingXpath(driver, "//tr/td[contains(text(),'"+month+"')]/../td[@ng-click='openSummariesByInvoice(data)']", "Invoice Month",true,true);
		RC_Global.waitElementVisible(driver, 120, "//span[text()='E-Billing Summary By Invoice']", "E-Billing Summary By Invoice",false,true);
		RC_Billing.waitForloadingIconToDisappear(driver, "//div[@ng-show='tableDataLoading || !tableDataLoaded']/i");
		RC_Global.verifyColumnNames(driver, ColumnNmes,true);		
		RC_Global.panelAction(driver, "expand", "E-Billing Summary By Invoice",true,true);
		RC_Global.clickUsingXpath(driver, "(//td/input[@ng-click='toggleInvoiceSelected(data)'])[1]", "Invoice Checkbox",true,false);
		RC_Global.buttonStatusValidation(driver, "Open", "Enable",false);
		RC_Global.buttonStatusValidation(driver, "Email", "Enable",false);
		RC_Global.buttonStatusValidation(driver, "Print", "Enable",true);
		RC_Global.panelAction(driver, "close", "E-Billing Summary By Invoice",false,true);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
