package Billing.EBilling.UploadInvoice;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Billing;
import tools.TotalView.RC_Global;
public class TID_5_1_2_01 {
	public void BillingUploadInvoice(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
        String CustomerNumber = "LS007728";
        String InvoiceNumber = null;
        
        RC_Global.login(driver);
        RC_Global.enterCustomerFocus(driver,CustomerNumber,true);
        RC_Global.navigateTo(driver,"Billing","E-Billing","Upload Invoice");
        RC_Global.panelAction(driver, "expand", "Upload Invoice",true,true);
   
        RC_Global.createNode(driver,"Validate Upload Invoice screen and Upload Invoice file");
        String Header =  driver.findElement(By.xpath("//h5/span[text()='Upload Invoice']/../span[2]/span[1]")).getText();
        String UploadDate = driver.findElement(By.id("invoiceDate")).getText();
        RC_Global.buttonStatusValidation(driver, "Upload", "Disable",false);
        queryObjects.logStatus(driver, Status.INFO, "Upload Invoice screen ---->", "Screen Header as"+Header+" and Upload Date as "+UploadDate+"", null);
        
		InvoiceNumber=driver.findElement(By.xpath("//select[@ng-model='invoiceUploadRequest.InvoiceIds']//option[2]")).getText();
		Thread.sleep(2000);
		WebElement InvoiceUpload= driver.findElement(By.id("invoiceFile"));
        String UploadfileName="Sample_Invoiceupdate.xlsx";
		InvoiceUpload.sendKeys(String.valueOf(String.valueOf(String.valueOf(System.getProperty("user.dir")))) + File.separator +"Uploadfiles\\"+UploadfileName+"");
		Thread.sleep(2000);
		RC_Global.buttonStatusValidation(driver, "Upload", "Disable",false);
		driver.findElement(By.xpath("//select[@ng-model='invoiceUploadRequest.InvoiceIds']//option[2]")).click();
		RC_Global.buttonStatusValidation(driver, "Upload", "Enable",true);
		RC_Global.clickUsingXpath(driver, "//button[normalize-space(text())='Upload']", "Upload",true,true);
		Thread.sleep(1000);
		RC_Global.waitElementVisible(driver, 60, "//p[text()='Upload succeeded']", "Upload succeeded",false,true);
		
		String Successmsg = driver.findElement(By.xpath("//p[text()='Upload succeeded']")).getText();
		if (Successmsg.trim().equals("Upload succeeded")) {
			queryObjects.logStatus(driver, Status.PASS, "Invoice uploaded", "Successfully", null);
		}
		driver.findElement(By.xpath("//i[@ng-click='closePanel()']")).click();
		Thread.sleep(2000);		
		
		RC_Global.navigateTo(driver,"Billing","E-Billing","View Billing");
		RC_Global.clickButton(driver, "Advanced Search",true,true);
		
		RC_Global.createNode(driver,"Validate the Uploaded Invoice number and File");

		RC_Global.waitElementVisible(driver, 120, "//span[text()='Search E-Billing']", "Search E-Billing",false,true);
		RC_Global.panelAction(driver, "expand", "Search E-Billing",false,true);
	
		WebElement Invoiceno = driver.findElement(By.xpath("//label[@for='invoiceNumber']/following-sibling::input"));
		RC_Global.enterInput(driver, InvoiceNumber, Invoiceno,true,true);
		RC_Global.clickButton(driver, "Search",true,true);
		Thread.sleep(2000);
		RC_Global.waitElementVisible(driver, 120, "//span[text()='E-Billing Summary By Invoice']", "E-Billing Summary By Invoice",false,true);

		driver.findElement(By.xpath("//span[text()='"+InvoiceNumber+"']/following::img[@src='assets/img/excel.ico']")).click();
		Thread.sleep(2000);		
		String home = System.getProperty("user.home");
		File listofFiles= new File(home+"/Downloads/" );
		for (File file :listofFiles.listFiles() ) {
			String filename= file.getName();
			if(filename.contains(UploadfileName)) {
			queryObjects.logStatus(driver, Status.PASS, "Uploaded "+UploadfileName+" for the "+InvoiceNumber+" is Downloaded", "Successfully", null);
			break;}
		}
		RC_Global.panelAction(driver, "close", "E-Billing Summary By Invoice",false,true);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
		
	}

}
