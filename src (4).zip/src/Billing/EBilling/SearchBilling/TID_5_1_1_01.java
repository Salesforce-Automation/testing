package Billing.EBilling.SearchBilling;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Billing;
import tools.TotalView.RC_Global;

public class TID_5_1_1_01 {
	public void SearchBilling_Validate_Filters_And_EBilling_SummaryPage(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		String menu = "Billing";
		String firstSubMenu = "E-Billing";
		String secondSubMenu = "Search Billing";
		String SearchFilters = "Customer Number;Invoice Number;Billing Month;Unit Number;Invoice Date Range Start;Invoice Date Range End;Customer Vehicle Number;Amount Range Start;Amount Range End;VIN;Receivable Type;Client Data Field;Client Data Value";
		String errorMsg = "Customer Number is a required field.";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.validateSpecifiedSearchFilters(driver, SearchFilters, false);
		RC_Global.clickButton(driver, "Search", true, true);
		RC_Billing.waitForloadingIconToDisappear(driver, "//button[contains(text(),'Search') and @type='submit']");
		RC_Global.verifyDisplayedMessage(driver, errorMsg, true); 
		RC_Global.clickButton(driver, "Reset", true, true);
		
		RC_Global.createNode(driver,"Verify Search Filters Functionalities");
		WebElement UnitNumIn = driver.findElement(By.xpath("//input[@placeholder='Unit Number']"));
		RC_Global.enterInput(driver, "571800", UnitNumIn, true, false);
		Thread.sleep(1000);
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		RC_Global.clickButton(driver, "Search", true, false);
		RC_Billing.waitForloadingIconToDisappear(driver, "//button[contains(text(),'Search') and @type='submit']");
		RC_Global.verifyDisplayedMessage(driver, "No results", false);
		
		RC_Global.clickButton(driver, "Reset", true ,false);
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		String dropdownvalues = "Manager;Charge Code;Fuel GL;Job Title;Owner;Store Ops Chg Code Y/N;Vehicle Segment";
		RC_Global.dropdownValuesValidation(driver,dropdownvalues,"//select[@ng-model='clientDataField']",false,true);
		RC_Billing.InputFieldVisibilityStatus(driver, "Client Data Value", "Disable", false);
		RC_Global.selectDropdownOption(driver, "Client Data Field", "Owner", false,true);
		RC_Billing.InputFieldVisibilityStatus(driver, "Client Data Value", "Enable", false);
		RC_Global.clickButton(driver, "Reset", true,true);
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		RC_Global.clickButton(driver, "Search", true,true);
		RC_Global.waitElementVisible(driver, 120, "//span[text()='E-Billing Summary By Month']", "E-Billing Summary By Month", true,true);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
	
}
