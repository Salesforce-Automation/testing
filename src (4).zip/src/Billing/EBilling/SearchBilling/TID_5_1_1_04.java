package Billing.EBilling.SearchBilling;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_5_1_1_04 {

	public void ValidateSearchFieldsResult(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception {
		
		String errorMsg = "Customer Number is a required field";
		WebDriverWait wait = new WebDriverWait(driver, 120);

		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Billing", "Vehicle Movement", "");
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		RC_Global.clickButton(driver, "Search", false,true);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tbody/tr")));
		String Customerno = driver.findElement(By.xpath("(//tr[contains(@ng-click,'setSelected')]/td[1])[1]")).getText();
		String UnitNumber = driver.findElement(By.xpath("(//td[contains(@ng-click,'ToVehicleDetails')])[1]")).getText();
		RC_Global.clickUsingXpath(driver, "//span[text()='CVN']","CVN", false,false);
		String CVN = driver.findElement(By.xpath("(//td[contains(@ng-click,'ToVehicleDetails')])[2]")).getText();
		String VIN = driver.findElement(By.xpath("(//td[contains(@ng-click,'ToVehicleDetails')]/following-sibling::td[3])[1]")).getText();
		

		queryObjects.logStatus(driver, Status.INFO, "Customer Number data---->", Customerno, null);
		queryObjects.logStatus(driver, Status.INFO, "Unit Number data---->", UnitNumber, null);
		queryObjects.logStatus(driver, Status.INFO, "CVN data---->", CVN, null);
		queryObjects.logStatus(driver, Status.INFO, "VIN data---->", VIN, null);

		Thread.sleep(2000);
		RC_Global.panelAction(driver, "close", "Vehicle Movement - Search", true,true);

		RC_Global.navigateTo(driver, "Billing", "E-Billing", "Search Billing");
		RC_Global.createNode(driver, "Search Billing -- Unit Number Search Filter Functionality Validation");
		WebElement element = driver.findElement(By.xpath("//input[@placeholder='Unit Number']"));
        RC_Global.enterInput(driver, UnitNumber, element,false,true);
        RC_Global.clickButton(driver, "Search",false,true);
		RC_Global.verifyDisplayedMessage(driver, errorMsg, false);
		RC_Global.clickButton(driver, "Reset", false,true);
		
		WebElement elementcus = driver.findElement(By.xpath("(//input[@name='customerInput'])[1]"));
		RC_Global.enterInput(driver, Customerno, elementcus, false,true);
		RC_Global.clickUsingXpath(driver, "//label[normalize-space(text())='Customer Number']/following-sibling::ul//a","Customer#", false,false);
		RC_Global.validateSearchFilterAction(driver, "Unit Number",  UnitNumber,"", false,true);
		String Element = "E-Billing Summary By Vehicle";
		RC_Global.waitElementVisible(driver, 120, "//span[text()='E-Billing Summary By Vehicle']", Element, false,true);
		RC_Global.clickButton(driver, "Advanced Search", false,true);
		RC_Global.clickButton(driver, "Reset", false,true);
		
		RC_Global.createNode(driver, "Search Billing -- CVN Search Filter Functionality Validation");
		WebElement elementcus1 = driver.findElement(By.xpath("(//input[@name='customerInput'])[1]"));
		RC_Global.enterInput(driver, Customerno, elementcus1, true,false);
		RC_Global.clickUsingXpath(driver, "//label[normalize-space(text())='Customer Number']/following-sibling::ul//a","Customer#", false,false);
		RC_Global.validateSearchFilterAction(driver, "Customer Vehicle Number",  CVN,"",false,false);
		String Element1 = "E-Billing Summary By Vehicle";
		RC_Global.waitElementVisible(driver, 120, "//span[text()='E-Billing Summary By Vehicle']", Element1, false,true);
		String invoiceno = driver.findElement(By.xpath("(//td[contains(@invoice-number,'InvoiceNumber')]/div/span)[1]")).getText();
		queryObjects.logStatus(driver, Status.INFO, "Invoice number data---->", invoiceno, null);
		RC_Global.clickButton(driver, "Advanced Search", false,true);
		RC_Global.clickButton(driver, "Reset", false,true);
		
		RC_Global.createNode(driver, "Search Billing -- VIN Search Filter Functionality Validation");
		WebElement elementcus2 = driver.findElement(By.xpath("(//input[@name='customerInput'])[1]"));
		RC_Global.enterInput(driver, Customerno, elementcus2, true,false);
		RC_Global.clickUsingXpath(driver, "//label[normalize-space(text())='Customer Number']/following-sibling::ul//a","Customer#", false,false);
		RC_Global.validateSearchFilterAction(driver, "VIN",VIN,"",false,false);
		String Element2 = "E-Billing Summary By Vehicle";
		RC_Global.waitElementVisible(driver, 120, "//span[text()='E-Billing Summary By Vehicle']", Element2, false,false);
		RC_Global.clickButton(driver, "Advanced Search", false,false);
		RC_Global.clickButton(driver, "Reset", false,false);
		
		RC_Global.createNode(driver, "Search Billing -- Invoice Number Search Filter Functionality Validation");
		WebElement elementcus3 = driver.findElement(By.xpath("(//input[@name='customerInput'])[1]"));
		RC_Global.enterInput(driver, Customerno, elementcus3, true,false);
		RC_Global.clickUsingXpath(driver, "//label[normalize-space(text())='Customer Number']/following-sibling::ul//a","Customer#", false,false);
		RC_Global.validateSearchFilterAction(driver, "Invoice Number",invoiceno,"",false,false);
		String Element3 = "E-Billing Summary By Invoice";
		RC_Global.waitElementVisible(driver, 120, "//span[text()='E-Billing Summary By Invoice']", Element3, false,false);
		RC_Global.clickButton(driver, "Advanced Search", false,false);
		RC_Global.clickButton(driver, "Reset", false,false);
		
		RC_Global.createNode(driver, "Search Billing -- Amount Range Start & End Search Filter Functionality Validation");
		RC_Global.enterCustomerNumber(driver, "LS008693", "", "", true);
		WebElement amountrangestart = driver.findElement(By.xpath("//input[@placeholder='Amount Range Start']"));
        RC_Global.enterInput(driver, "10000", amountrangestart,false,false);
        WebElement amountrangeend = driver.findElement(By.xpath("//input[@placeholder='Amount Range End']"));
        RC_Global.enterInput(driver, "15000", amountrangeend,false,false);
        RC_Global.clickButton(driver, "Search",false,false);
		RC_Global.waitElementVisible(driver, 120, "//span[text()='E-Billing Summary By Invoice']", Element3, false,false);
		
		RC_Global.panelAction(driver, "close", "E-Billing Summary By Invoice", false,false);

		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
