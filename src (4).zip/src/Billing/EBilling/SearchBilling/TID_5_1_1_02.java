package Billing.EBilling.SearchBilling;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Billing;
import tools.TotalView.RC_Global;

public class TID_5_1_1_02 {
	public void ValidatePageNavigationForEBillingSummaryByMonth(WebDriver driver,BFrameworkQueryObjects queryobjects)throws Exception{
		 String ColumnNmes = "Invoice Month;Total Amount Billed";
		
		 RC_Global.login(driver);              
	     RC_Global.navigateTo(driver, "Billing", "E-Billing", "Search Billing");  
	     RC_Global.enterCustomerNumber(driver, "LS008737", "", "", true);
	     RC_Global.clickButton(driver, "Search", true,true);
	     RC_Global.waitElementVisible(driver, 120, "//span[text()='E-Billing Summary By Month']", "E-Billing Summary By Month", false,true);
	     
		 RC_Global.createNode(driver,"Verify Buttons Available in the Screen");
		 RC_Global.buttonStatusValidation(driver, "Advanced Search", "Enable", false);
		 RC_Global.buttonStatusValidation(driver, " Back ", "Enable", false);
		 RC_Global.validateSpecifiedSearchFilters(driver, "LS008737 - Kentucky Farm Bureau Mutual Insurance Company", true);
		 RC_Global.clickButton(driver, "Advanced Search", true,true);
		 RC_Global.waitElementVisible(driver, 120, "//span[text()='Search E-Billing']", "Search E-Billing", false,true); 
		 RC_Global.panelAction(driver, "expand", "Search E-Billing", true,true);
		 Thread.sleep(1000);
		 RC_Global.clickButton(driver, "Search", true,true);
		 
		 RC_Global.createNode(driver,"Validate EBilling Summary By Month screen and Page Navigation");
		 RC_Global.waitElementVisible(driver, 120, "//span[text()='E-Billing Summary By Month']", "E-Billing Summary By Month", false,true);
		 RC_Global.panelAction(driver, "expand", "E-Billing Summary By Month", true,true);
		 RC_Global.verifyColumnNames(driver, ColumnNmes, false);
         RC_Billing.VerifyHyperlinkPanel(driver, "Total Amount Billed", "E-Billing Summary By Invoice", true);
         RC_Global.waitElementVisible(driver, 120, "//span[text()='E-Billing Summary By Invoice']", "E-Billing Summary By Invoice", false,true);
         RC_Global.panelAction(driver, "close", "E-Billing Summary By Invoice", false,true);
         
         queryobjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}

}
