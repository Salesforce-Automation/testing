package Billing.EBilling.SearchBilling;

import java.util.List;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_5_1_1_05 {
	public static void ValidateReceivableTypeSearchFilters(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Billing", "E-Billing", "Search Billing");
		
		RC_Global.createNode(driver, "Verify that 'Receivable Type' dropdown  has no values wothout Customer Number");
		RC_Global.clickUsingXpath(driver, "//div[label[text()='Receivable Type']]/select", "Receivable Type", false,false);
		if(driver.findElements(By.xpath("//div[label[text()='Receivable Type']]/select/option")).size()==1) {
			if(driver.findElement(By.xpath("//div[label[text()='Receivable Type']]/select/option[1]")).getText().equalsIgnoreCase(""))
				queryObjects.logStatus(driver, Status.PASS, "Validating no options available before entering Customer Number", "No Options are avialable", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "Validating no options available before entering Customer Number", "Options are avialable", null);
	
		RC_Global.enterCustomerNumber(driver, "LS008737", "", "", true);
		RC_Global.clickUsingXpath(driver, "//div[label[text()='Receivable Type']]/select", "Receivable Type", false,true);
		String receivableType = driver.findElement(By.xpath("//div[label[text()='Receivable Type']]/select/option[2]")).getText();
		
		RC_Global.createNode(driver, "Select and validate the 'Receivable Type' ---> "+receivableType);
		RC_Global.clickUsingXpath(driver, "//div[label[text()='Receivable Type']]/select/option[2]", "Receivable Type Selection", false,false);
		
		RC_Global.clickButton(driver, "Search", true,false);
		
		RC_Global.waitElementVisible(driver, 30, "//tr[1]/td[3]", "First row of Description column", false,false);
		
		if(driver.findElement(By.xpath("//tr[td[text()='Receivable Type: ']]/td[2]")).getText().equalsIgnoreCase(receivableType))
			queryObjects.logStatus(driver, Status.PASS, "Validation of Receivable Type: ", "Receivable Type is "+receivableType, null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Validation of Description failed ", "Receivable Type is not "+receivableType, null);
		
		List<WebElement> receivableTypeDescription = new ArrayList<WebElement>();
		receivableTypeDescription = driver.findElements(By.xpath("//tr/td[3]"));
		
		int iter = 0;
		boolean flag = true;
		for(iter=0; iter<receivableTypeDescription.size();iter++) {
			if(receivableTypeDescription.get(iter).getText().equalsIgnoreCase(receivableType))
				continue;
			else {
				queryObjects.logStatus(driver, Status.FAIL, "Validation of Description failed at row ", ""+iter, null);
				flag = false;
			}
			if(flag)
				queryObjects.logStatus(driver, Status.PASS, "Validation of Description at all rows are ", receivableType, null);
			
		}
		if(flag)
			queryObjects.logStatus(driver, Status.PASS, "Validation of Description at all rows are ", receivableType, null);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}
}
