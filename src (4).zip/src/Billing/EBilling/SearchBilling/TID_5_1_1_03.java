package Billing.EBilling.SearchBilling;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Billing;
import tools.TotalView.RC_Global;

public class TID_5_1_1_03 {
	public void ValidateNavigationInEBillingSummaryByInvoice(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String menu = "Billing";
        String firstSubMenu = "E-Billing";
        String secondSubMenu = "Search Billing";
        String CustomerNumber = "LS008742";
        String ColumnNmes ="Invoice Month;Invoice #;Total Rental Charges;Total Non-Rental Charges;Total Amount Billed;Supporting Documents;Invoice";
        
        RC_Global.login(driver);
        RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
        RC_Global.enterCustomerNumber(driver, CustomerNumber, "", "", true);
        RC_Global.clickButton(driver, "Search", true,true);
        RC_Global.waitElementVisible(driver, 120, "//h5/span[text()='E-Billing Summary By Month']", "E-Billing Summary By Month", false,true);
        RC_Global.createNode(driver, "Verfy customer details");
        String cusDetails=driver.findElement(By.xpath("//td[contains(text(),'Customer Number: ')]/following::td[1]")).getText();
        queryObjects.logStatus(driver, Status.PASS, "The screen has customer details ", cusDetails, null);
        RC_Global.clickButton(driver, "Advanced Search", true,true);
        RC_Global.validateHeaderName(driver,"Search E-Billing", true);
        RC_Global.clickButton(driver, "Reset", true,true);
        RC_Global.enterCustomerNumber(driver, CustomerNumber, "", "", true);
        RC_Global.clickButton(driver, "Search", true,true);
        RC_Global.waitElementVisible(driver, 120, "//h5/span[text()='E-Billing Summary By Month']", "E-Billing Summary By Month", false,true);
        
   
        RC_Global.clickButton(driver, "Back", false,true);
        RC_Global.validateHeaderName(driver,"Search E-Billing", false);
        RC_Global.clickButton(driver, "Reset", false,true);
        RC_Global.enterCustomerNumber(driver, CustomerNumber, "", "", true);
        RC_Global.clickButton(driver, "Search", false,true);
        RC_Global.waitElementVisible(driver, 120, "//h5/span[text()='E-Billing Summary By Month']", "E-Billing Summary By Month", false,true);
        RC_Global.clickUsingXpath(driver, "((//tbody)[2]//tr[1])/td[2]", "Total Amount Billed", true,true);
        RC_Global.validateHeaderName(driver,"E-Billing Summary By Invoice", true);
        
        RC_Global.waitElementVisible(driver,120,"((//tbody)[2]//tr[1])/td[3]","Grid Row", false,true);
        RC_Global.verifyColumnNames(driver, ColumnNmes, true);
         
        RC_Global.clickUsingXpath(driver, "((//tbody)[2]//tr[1])/td[3]", "Total Rental Charges", true,true);
        RC_Global.validateHeaderName(driver,"E-Billing Summary By Rental Charge", true);
        RC_Global.panelAction(driver, "close", "E-Billing Summary By Rental Charge", true,true);
        RC_Global.clickUsingXpath(driver, "((//tbody)[2]//tr[1])/td[4]", "Total Non-Rental Charges", true,true);
        RC_Global.validateHeaderName(driver,"E-Billing Summary By Non-Rental Charge", true);
        RC_Global.panelAction(driver, "close", "E-Billing Summary By Non-Rental Charge", true,true);
        RC_Global.clickUsingXpath(driver, "((//tbody)[2]//tr[1])/td[5]", "Total Amount Billed", true,true);
        RC_Global.validateHeaderName(driver,"E-Billing Summary By Vehicle", true);
        RC_Global.panelAction(driver, "close", "E-Billing Summary By Vehicle", false,true);
        
        queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}

}