package FleetServices.Fuel.CardShipment;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;
public class TID_2_2_1_01 {
	public void Fuel_ValidatSearchFieldResultAndExceptionsErrors(WebDriver driver, BFrameworkQueryObjects queryObjects)throws Exception
	{
		String menu = "Fleet Services";
		String firstSubMenu = "Fuel";
		String secondSubMenu = "Card Shipment";
		String customerNumber = "LS008737";
		String unitNumber = "577032";
		String FromDate = "";//RC_Global.getDateTime(driver,"MM/dd/yyyy",-5, true);
		String ToDate = "";//RC_Global.getDateTime(driver,"MM/dd/yyyy",-10, true);
		String searchFilters = "Unit Number;Shipped From Date:;Shipped To Date:;Customer Number;Received From Date:;Received To Date:;Customer Card #;Ordered From Date:;Ordered To Date:";
		String gridResultHeader = "Customer #;Customer Name;Unit Number;Card Number;Ordered Date;Vendor Ship Date;Vendor Ship To;Tracking Number;Alternate Checked In;Check-In By;Check-In Date;Alternate Ship Date;Alternate Ship To;Alternate Attention To;Alternate Ship To Address 1;Alternate Ship To City;Alternate Ship To State;Alternate Ship To Zip;Alternate Tracking Number;Fleet #;Fleet Name;Account #;Account Name;Sub-Account #;Sub-Account Name";
		
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.validateSpecifiedSearchFilters(driver,searchFilters, true);
		
		RC_Global.createNode(driver, "Unit Number Search Filter Functionality");
		RC_Global.enterInput(driver, unitNumber, (WebElement)(driver.findElement(By.xpath("//input[contains(@placeholder,'Unit Number')]"))), false,true);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.waitElementVisible(driver, 60, "//cell-template//div[@title='Unit Number']", "Unit Number", false,true);
		RC_Global.clickButton(driver, "Reset", false,false);
		
		RC_Global.createNode(driver, "Error Message --> Please enter 6 characters for Unit Number Validation");
		RC_Global.enterInput(driver, "133", (WebElement)(driver.findElement(By.xpath("//input[contains(@placeholder,'Unit Number')]"))), false,true);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.verifyDisplayedMessage(driver,"Please enter 6 characters for Unit Number.", false);
		RC_Global.clickButton(driver, "Reset", false,false);
		FromDate = RC_Global.getDateTime(driver,"MM/dd/yyyy",-5, true);
		ToDate =  RC_Global.getDateTime(driver,"MM/dd/yyyy",-10, true);
		RC_Global.createNode(driver, "Error Message --> From date must not be later than To date on Shipped dates Validation");
		RC_Global.enterInput(driver, FromDate, (WebElement)(driver.findElement(By.xpath("//*[@placeholder='Shipped From Date']"))), false,true);
		RC_Global.enterInput(driver, ToDate, (WebElement)(driver.findElement(By.xpath("//*[@placeholder='Shipped To Date']"))), false,true);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.verifyDisplayedMessage(driver,"From date must not be later than To date on Shipped dates", false);
		RC_Global.clickButton(driver, "Reset", false,false);
		
		RC_Global.createNode(driver, "Error Message --> From date must not be later than To date on Received dates Validation");
		RC_Global.enterInput(driver, FromDate, (WebElement)(driver.findElement(By.xpath("//*[@placeholder='Received From Date']"))), false,true);
		RC_Global.enterInput(driver, ToDate, (WebElement)(driver.findElement(By.xpath("//*[@placeholder='Received To Date']"))), false,true);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.verifyDisplayedMessage(driver,"From date must not be later than To date on Received dates", false);
		RC_Global.clickButton(driver, "Reset", false,false);
		
		RC_Global.createNode(driver, "Error Message --> From date must not be later than To date on Ordered dates Validation");
		RC_Global.enterInput(driver, FromDate, (WebElement)(driver.findElement(By.xpath("//*[@placeholder='Ordered From Date']"))), false,true);
		RC_Global.enterInput(driver, ToDate, (WebElement)(driver.findElement(By.xpath("//*[@placeholder='Ordered To Date']"))), false,true);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.verifyDisplayedMessage(driver,"From date must not be later than To date on Ordered dates", false);
		RC_Global.clickButton(driver, "Reset", false,false);
		
		RC_Global.enterCustomerNumber(driver, "LS010143", "Customer", "", true);
		RC_Global.clickButton(driver, "Search", true,true);
		RC_Global.waitElementVisible(driver, 60, "//cell-template//div[contains(@title,'Customer #')]", "Customer #", true,true);
		RC_FleetServices.verifyGridColumnsByName(driver,gridResultHeader,"CardShipment", true);
		RC_Global.downloadAndVerifyFileDownloaded(driver,"Export","Export To Excel Functionality", true);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		Thread.sleep(1000);
		executor.executeScript("document.body.style.zoom = '30%'");
		   Thread.sleep(2000);
		executor.executeScript("document.body.style.zoom = '100%'");
		 Thread.sleep(2000);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}

}
