package FleetServices.Fuel.CardShipment;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;

public class TID_2_2_1_02 {
	public void Fuel_ValidateFuelCardShipmentDetailsBasedOnAlternateCheckedInStatus(WebDriver driver, BFrameworkQueryObjects queryObjects)throws Exception
	{
		String menu = "Fleet Services";
		String firstSubMenu = "Fuel";
		String secondSubMenu = "Card Shipment";
		String customerNumber = "LS008737";

//		String unitNumber1 = "595561";
//		String unitNumber2 = "599294";
//		String unitNumber3 = "608267";
		String unitNumber1 = "";
		String unitNumber2 = "";
		String unitNumber3 = "";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.enterCustomerNumber(driver, customerNumber, "Customer", "", false);
		RC_Global.clickButton(driver, "Search", false,true);
		unitNumber1 = RC_FleetServices.getUnitNumbers(driver, "Yes", false);
		unitNumber2 = RC_FleetServices.getUnitNumbers(driver, "No", false);
		unitNumber3 = RC_FleetServices.getUnitNumbers(driver, "N/A", false);		
		RC_Global.waitElementVisible(driver, 30, "(//div[contains(@ng-repeat,'rowContainer')])[1]", "Grid Results", true,false);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
//		executor.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.xpath("//div//input[@placeholder='Unit Number']")));
		RC_Global.clickButton(driver, "Reset", false,false);
		RC_Global.enterCustomerNumber(driver, customerNumber, "Customer", "", false);
		RC_Global.enterInput(driver, unitNumber1, (WebElement)(driver.findElement(By.xpath("//div//input[@placeholder='Unit Number']"))), false,true);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_FleetServices.verifyGridColumnByNameAndValue(driver,"Alternate Checked In","Yes", false);
		RC_Global.clickButton(driver, "Reset", false,false);
		
		RC_Global.enterCustomerNumber(driver, customerNumber, "Customer", "", false);
		RC_Global.enterInput(driver, unitNumber2, (WebElement)(driver.findElement(By.xpath("//div//input[@placeholder='Unit Number']"))), false,true);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_FleetServices.verifyGridColumnByNameAndValue(driver,"Alternate Checked In","No", false);
		RC_Global.clickButton(driver, "Reset", false,false);
		
		RC_Global.enterCustomerNumber(driver, customerNumber, "Customer", "", false);
		RC_Global.enterInput(driver, unitNumber3, (WebElement)(driver.findElement(By.xpath("//div//input[@placeholder='Unit Number']"))), true,true);
		RC_Global.clickButton(driver, "Search", true,true);
		RC_FleetServices.verifyGridColumnByNameAndValue(driver,"Alternate Checked In","N/A", true);
		RC_Global.clickButton(driver, "Reset", false,false);
			
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}
}