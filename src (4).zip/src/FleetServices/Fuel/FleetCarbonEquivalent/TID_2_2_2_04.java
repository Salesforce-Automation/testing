package FleetServices.Fuel.FleetCarbonEquivalent;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_2_2_2_04 {
	 public void Fuel_FleetCarbonEquivalentSearchResultBasedOnVehicle(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
		 
		 String ColumnNmes = "Customer #;Customer Name;Unit #;CVN;VIN;Year;Make;Model;Vehicle Status;# of Transactions;# of Gallons;Carbon Output (lbs);DOT;Company;Owner;Activity Code;Division;SAP Cost Center;Account Name;Fleet #;Fleet Name;Account #;Account Name;Sub-Account #;Sub-Account Name";
		 JavascriptExecutor executor = (JavascriptExecutor)driver;

		 RC_Global.login(driver);
	     RC_Global.navigateTo(driver, "Fleet Services", "Fuel", "Fleet Carbon Equivalent");
		 RC_Global.enterCustomerNumber(driver, "LS010143", "", "", true);
		 RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Active lease", true);
		 RC_Global.clickButton(driver, "Search", true,true);
		 executor.executeScript("document.body.style.zoom = '80%'");
		 RC_Global.waitElementVisible(driver, 60, "//tbody/tr", "Search Result Grid", true,true);
		 RC_Global.verifyColumnNames(driver, ColumnNmes, true);
		 executor.executeScript("document.body.style.zoom = '30%'");
		 executor.executeScript("document.body.style.zoom = '100%'");
		 RC_Global.clickCellLinkVerifyPanelTitle(driver, "Unit #", "Vehicle Details", true);
		RC_Global.waitUntilPanelVisibility(driver, "Vehicle Details", "TV", true,true);
		RC_Global.panelAction(driver, "close", "Vehicle Details", true,true);
		RC_Global.panelAction(driver, "expand", "Fleet Carbon Equivalent", true,false);
		RC_Global.clickCellLinkVerifyPanelTitle(driver, "CVN", "Vehicle Details", true);
		RC_Global.waitUntilPanelVisibility(driver, "Vehicle Details", "TV", false,true);
		RC_Global.panelAction(driver, "close", "Vehicle Details", true,true);
		RC_Global.panelAction(driver, "expand", "Fleet Carbon Equivalent", true,false);
		RC_Global.clickCellLinkVerifyPanelTitle(driver, "Carbon Output (lbs)", "Fleet Carbon Equivalent", true);
		RC_Global.waitUntilPanelVisibility(driver, "Fleet Carbon Equivalent", "TV",true,true);

		RC_Global.panelAction(driver, "expand", "Fleet Carbon Equivalent", false,false);
		RC_Global.panelAction(driver, "close", "Fleet Carbon Equivalent", false,true);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	 }
}
