package FleetServices.Fuel.FleetCarbonEquivalent;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_2_2_2_02 {
public void Fuel_FleetCarbonEquivalentSummaryForVehicle(WebDriver driver,BFrameworkQueryObjects queryObjects)throws Exception{
		
		String searchFilters = "Total Transactions;Total Gallons";
		String searchFilters1 = "Total Transactions;Total Gallons;Total Carbon Output (lbs)";
		String ColumnNmes = "Date;Time;Unit #;CVN;Fuel Type;Gallons;Carbon Output (lbs)";
		
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Fleet Services", "Fuel", "Fleet Carbon Equivalent");
	
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		RC_Global.buttonStatusValidation(driver, "Vehicle", "Enable", true);
		RC_Global.clickButton(driver, "Search", true,false);
		RC_Global.waitElementVisible(driver, 60, "//tbody/tr", "Search Result Grid",true,false);
		
		RC_Global.validateSpecifiedSearchFilters(driver, searchFilters,true );
		RC_Global.verifyAsHyperlinkByLinkName(driver,"Total Carbon Output (lbs)",true);
		RC_Global.clickUsingXpath(driver, "//*[contains(@ng-click,'allCarbonSelected')]", "Total Carbon Output (lbs)", true,false);//click on Total Carbon Output (lbs) hyperlink
		RC_Global.clickUsingXpath(driver,"(//h5[span[text()='Fleet Carbon Equivalent']]/i[@ng-click='closePanel()'])[1]", "Fleet Carbon Equivalent", true,false);
		
		RC_Global.waitElementVisible(driver, 60, "(//h5//span[text()='Fleet Carbon Equivalent'])", "Fleet Carbon Equivalent", true,false);
		RC_Global.clickUsingXpath(driver, "//h5[span[text()='Fleet Carbon Equivalent']]/i[contains(@class,'fa-expand') and @ng-click='maximize(panel)']", "Fleet Carbon Equivalent", true,false);
		RC_Global.validateSpecifiedSearchFilters(driver, searchFilters1, true );
		RC_Global.verifyColumnNames(driver, ColumnNmes, true);
		RC_Global.panelAction(driver, "close", "Fleet Carbon Equivalent", false,true);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}	
}
