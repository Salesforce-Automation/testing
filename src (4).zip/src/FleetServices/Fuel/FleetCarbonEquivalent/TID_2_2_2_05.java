package FleetServices.Fuel.FleetCarbonEquivalent;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_2_2_2_05 {
	public void Fuel_FleetCarbonEquivalentSearchResultBasedOnEmployee_Driver(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
		  
	      String ColumnNmes = "Customer #;Customer Name;Employee/Driver Name;Employee ID;Employee Status;# of Transactions;# of Gallons;Carbon Output (Lbs);Fleet #;Fleet Name;Account #;Account Name;Sub-Account #;Sub-Account Name";
	         
	      	 RC_Global.login(driver);
	         RC_Global.navigateTo(driver, "Fleet Services", "Fuel", "Fleet Carbon Equivalent");
	         RC_Global.enterCustomerNumber(driver, "LS010143", "", "", true);
	         RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Active lease", true);
	         RC_Global.clickButton(driver, "Employee/Driver", true,true);
	         RC_Global.clickButton(driver, "Search", true,false);
	         RC_Global.waitElementVisible(driver, 60, "//tbody/tr", "Search Result Grid", true,true);
	         RC_Global.verifyColumnNames(driver, ColumnNmes, true);
	         RC_Global.clickCellLinkVerifyPanelTitle(driver, "Employee/Driver Name", "Driver Details", true);
	         RC_Global.waitUntilPanelVisibility(driver, "Driver Details", "TV", false,true);
	         RC_Global.panelAction(driver, "expand", "Driver Details", false,false);
	         RC_Global.panelAction(driver, "close", "Driver Details", false,true);
	         RC_Global.panelAction(driver, "close", "Fleet Carbon Equivalent", false,true);

	         queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}

}

