package FleetServices.Fuel.FleetCarbonEquivalent;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;

public class TID_2_2_2_03 {
	  public void Fuel_ValidateFleeCarbonEquivalentSummaryForEmployeeOrDriver(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{         
	                   
	        String ColumnNmes = "Date;Time;Employee/Driver Name;Fuel Type;Gallons;Carbon Output (lbs)";                     
	        JavascriptExecutor executor = (JavascriptExecutor)driver;
	        
	        RC_Global.login(driver);              
	        RC_Global.navigateTo(driver, "Fleet Services", "Fuel", "Fleet Carbon Equivalent");  
	        RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);                     
	        RC_Global.clickButton(driver, "Employee/Driver", true,true);             
	        RC_Global.clickButton(driver, "Search", true,false);        
			RC_Global.waitElementVisible(driver, 60, "//table/tbody", "Search Result Grid", true,false);
	        RC_Global.clickUsingXpath(driver, "//*[contains(@ng-click,'allCarbonSelected')]", "Total Carbon Output (lbs) value",true,false);
	        RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='Fleet Carbon Equivalent']])[1]",true,false);
	                  
	        //validate Fleet Carbon equivalent page opens       
	        RC_Global.panelAction(driver,"expand","Fleet Carbon Equivalent",true,false);    
	        
	        RC_Global.verifyColumnNames(driver, ColumnNmes,true);
	        RC_Global.waitElementVisible(driver, 60, "//tbody/tr", "Search Result Grid",true,false);
	        executor.executeScript("document.body.style.zoom = '100%';");
	        RC_Global.clickUsingXpath(driver, "//table/tbody/tr[8]/td[3]", "Employee/Driver Name",true,false); 
	        Thread.sleep(4000);
	        if(driver.findElements(By.xpath("//h5//span[text()='Edit Employee']")).size()>0) {
		        RC_Global.panelAction(driver, "expand", "Edit Employee",true,false);
				executor.executeScript("document.body.style.zoom = '30%'");
				executor.executeScript("document.body.style.zoom = '100%'");
		        driver.findElement(By.xpath("//select[@name='status']")).click();
		        Thread.sleep(1000);
		        driver.findElement(By.xpath("//select[@name='status']/option[1]")).click();
		        driver.findElement(By.xpath("(//button[text()=' Save '])[1]")).click();
		        RC_Global.verifyDisplayedMessage(driver, "Employee Updated Successfully",true);
		        RC_Global.panelAction(driver, "close", "Edit Employee",true,false);
	        }
	        else if(driver.findElements(By.xpath("//h5//span[text()='Driver Details']")).size()>0) {
	        	RC_Global.waitUntilPanelVisibility(driver, "Driver Details", "TV", true,true);              
		        RC_Global.panelAction(driver, "expand", "Driver Details",true,false);
		        RC_Global.clickUsingXpath(driver, "(//*[contains(@ng-click,'setDriverType(assignmentTypes.driver)')])", "Driver Type",true,false);              

		        RC_FleetServices.driverSelection(driver,"",true);         
		        RC_Global.panelAction(driver, "close", "Driver Details",false,true);
	        }
	        
	        queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}
}