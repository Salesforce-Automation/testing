package FleetServices.Fuel.FleetCarbonEquivalent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;

public class TID_2_2_2_01 {
public void Fuel_ValidateSearchFieldsAndResultsGridForVehicleAndEmployee_Driver(WebDriver driver,BFrameworkQueryObjects queryObjects)throws Exception{
		
		String searchFilters = "Customer Number;From Date;To Date;Vehicle Status;View Results By";
		String searchFilters1 = "Total Transactions;Total Gallons;Total Carbon Output (lbs)";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Fleet Services", "Fuel", "Fleet Carbon Equivalent");		
		RC_Global.validateSpecifiedSearchFilters(driver, searchFilters, true);
			
		RC_Global.buttonStatusValidation(driver, "Vehicle", "Enable", false);
		RC_Global.buttonStatusValidation(driver, "Employee/Driver", "Enable", false);
		
		WebElement FromDate = driver.findElement(By.xpath("//*[contains(@name,'fromDate')]"));//from date
		RC_Global.enterInput(driver, RC_Global.getDateTime(driver,"MM/dd/yyyy",1, false), FromDate, false,true);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.verifyDisplayedMessage(driver, "The To Date must be after the From Date.", false);
	
		WebElement ToDate = driver.findElement(By.xpath("//*[contains(@name,'toDate')]"));//To date
		RC_Global.enterInput(driver, RC_Global.getDateTime(driver,"MM/dd/yyyy",0, false), ToDate, false,true);		
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.verifyDisplayedMessage(driver, "The From Date is out of range.", false);
	
		RC_FleetServices.multiSelectDropDown(driver, false);
		RC_Global.clickButton(driver, "Reset", false,true);
		RC_Global.buttonStatusValidation(driver, "Search", "Enable", false);
		RC_Global.buttonStatusValidation(driver, "Reset", "Enable", false);
		
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.verifyDisplayedMessage(driver, "Customer is a required field.", false);
		RC_Global.clickButton(driver, "Reset", false,true);		
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		RC_Global.clickButton(driver, "Search", true,false);
		RC_Global.waitElementVisible(driver, 60, "//tbody/tr", "Search Result Grid", true,false);
		RC_Global.validateSpecifiedSearchFilters(driver, searchFilters1, true);
		RC_Global.buttonStatusValidation(driver, "Vehicle", "enable", true);		
		RC_FleetServices.resultBasedOnToggleOption(driver, "Vehicle", "Unit #;CVN;VIN;Year;Make;Model;Vehicle Status", true);
		
		RC_Global.clickButton(driver, "Employee/Driver", true,false);
		RC_Global.clickButton(driver, "Search",true,false);
		Thread.sleep(2000);
        RC_Global.waitElementVisible(driver, 60, "//table/tbody", "Search Result Grid",true,true);
		RC_FleetServices.resultBasedOnToggleOption(driver,"Employee/Driver","Employee/Driver Name;Employee ID;Employee Status",true);

		RC_Global.downloadAndVerifyFileDownloaded(driver,"Export","Export To Excel Functionality",true);	
		RC_Global.panelAction(driver, "close", "Fleet Carbon Equivalent", false,true);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}
}
