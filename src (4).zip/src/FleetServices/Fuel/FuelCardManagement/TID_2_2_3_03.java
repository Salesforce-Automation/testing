package FleetServices.Fuel.FuelCardManagement;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;

public class TID_2_2_3_03 {
	public void Fuel_RemoveCardFromFuelProgramAndValidateHistory(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
		
        JavascriptExecutor executor = (JavascriptExecutor) driver;
		String HistoryScreenClmns = "Card Number;Number of Transactions;Total Spend;Transaction Active Dates;Number of Card Events;Number of Shipment Events";
		String CardEventHistory = "Date;Event;Completed By";
		
		
		RC_Global.login(driver);
	    RC_Global.navigateTo(driver, "Fleet Services", "Fuel", "Fuel Card Management");
	    RC_Global.enterCustomerNumber(driver, "LS010116", "", "", false);
        RC_Global.clickButton(driver, "Search",true,true);
        RC_Global.waitElementVisible(driver, 30, "//table//tbody//tr", "Search Result Grid",true,true);
        RC_FleetServices.selectRecordOrValueFromGrid(driver, "Last4digit",true);
        RC_Global.waitElementVisible(driver, 30, "//h5[span[contains(text(),'Manage Card')]]", "Order Card",true,true);
        
        RC_Global.panelAction(driver, "expand", "Manage Card",true,false);
        executor.executeScript("window.scrollBy(0,800)",true);
        RC_Global.createNode(driver, "Remove Card From Fuel Program");
        RC_Global.clickButton(driver, "Terminate Card",true,true);  
        RC_Global.waitElementVisible(driver, 30, "(//h5[span[contains(text(),'Manage Card')]])[2]", "Order Card",true,true);
        RC_Global.panelAction(driver, "close", "Fuel Card Management",true,true);
        WebElement terminateAndRemoveRadioButton = driver.findElement(By.xpath("//input[@value='terminateAndRemove']"));
        RC_Global.clickUsingXpath(driver, "(//h5[span[contains(text(),'Manage Card')]])[2]/i[@ng-click='maximize(panel)']", "Order Card",true,false);
        String CardNumber = driver.findElement(By.xpath("//strong[text()='Card Number: ']/following::span[@id='card-number']")).getText();
        Thread.sleep(1000);
        executor.executeScript("arguments[0].scrollIntoView(true);",terminateAndRemoveRadioButton);
        executor.executeScript("document.body.style.zoom = '30%'");
        Thread.sleep(2000);
        executor.executeScript("document.body.style.zoom = '100%'");
        terminateAndRemoveRadioButton.click();
        Thread.sleep(2000);
        RC_Global.clickButton(driver, "Submit",true,true);
//        RC_Global.verifyDisplayedMessage(driver, "Card was successfully terminated.",true);
        try {
        	RC_Global.waitElementVisible(driver, 30, "//h4[text()='Card was successfully terminated.']", "Card Termination Message", true, true);
        	queryObjects.logStatus(driver, Status.PASS, "Verify Card Terminated message is displayed", "Card Terminated message is displayed", null);
        	}
        	catch(Exception e) {
        	queryObjects.logStatus(driver, Status.FAIL, "Verify Card Terminated message is displayed", "Card Terminated message is not displayed", null);
        	}
        RC_Global.clickUsingXpath(driver, "(//h5[span[contains(text(),'Manage Card')]])[2]/i[@ng-click='closePanel()']", "Order Card",true,true);
        RC_Global.clickUsingXpath(driver, "//h5[span[contains(text(),'Manage Card')]]/i[@ng-click='maximize(panel)']", "Order Card",true,false);
        
        RC_Global.clickButton(driver, "History",true,true);
        RC_Global.waitElementVisible(driver, 30, "(//h5[span[contains(text(),'Manage Card')]])[2]", "Manage Card - Card History",true,true);
        RC_Global.clickUsingXpath(driver, "//h5[span[contains(text(),'Manage Card')]]/i[@ng-click='closePanel()']", "Order Card",true,false);
        RC_Global.clickUsingXpath(driver, "//h5[span[contains(text(),'Manage Card - Card History')]]/i[@ng-click='maximize(panel)']", "Manage Card - Card History",true,false);
        RC_FleetServices.fuelCardHistory(driver,CardNumber);
        queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);


	}
}
