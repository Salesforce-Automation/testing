package FleetServices.Fuel.FuelCardManagement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_2_2_3_01 {
	 public void ValidateTheFuelCardManagementSearchGridResult (WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
		
		 String SearchFilters ="Unit Number;Customer Vehicle Number;Pool Name;Customer Number;Full VIN or Last 8;Driver First Name;Driver Last Name;Plate Number;Card Number - Last 4;Plate Number;Customer Card Data;Fuel PIN Pool;Vehicle Status";
		 
		 RC_Global.login(driver);
		 RC_Global.enterCustomerFocus(driver, "LS010116", true);
	     RC_Global.navigateTo(driver, "Fleet Services", "Fuel", "Fuel Card Management");
		 RC_Global.validateSpecifiedSearchFilters(driver, SearchFilters, false);
		 
		 RC_Global.clickButton(driver, "Search",false,true);
		 RC_Global.waitElementVisible(driver,30,"//tbody//tr[1]//td[6]","Unit Number",false,true);
		 String UnitNumber = driver.findElement(By.xpath("(//tbody//tr[1]/td[6])[1]")).getText();
		 String OrderNumberOrLast4Digit = driver.findElement(By.xpath("(//tbody//tr[1]/td[3])[1]")).getText();
		 String DriverNam[] = driver.findElement(By.xpath("//tbody//tr[1]//td[8]")).getText().split(" ");
		 String DriFirstName = DriverNam[0];
		 String DriLastName = DriverNam[1];
		 String PlateState[] = driver.findElement(By.xpath("//tbody//tr[1]//td[13]")).getText().split(" ");
		 String Plate = PlateState[0];
		 String CardLst4="";
		 String custCardData = driver.findElement(By.xpath("(//tbody//tr[1]/td[4])[1]")).getText();
		
		 int TotRow = driver.findElements(By.xpath("//tbody//tr")).size();
		 for(int itr=1;itr<=TotRow;itr++)
		 {
			 Thread.sleep(500);
			 
			 CardLst4=driver.findElement(By.xpath("//tbody//tr["+itr+"]//td[3]//span[2]")).getText();
			 if(CardLst4.equalsIgnoreCase("Order Fuel Card"))
			 {
				 if(itr == TotRow) {
					 CardLst4 = "";
					 queryObjects.logStatus(driver, Status.INFO, "Searching for a record with Last 4 Digit of a fuel card number", "No Fuel Cards Created", null);
					 break;
				 }
				continue;
			 }
			else{
				 CardLst4=driver.findElement(By.xpath("//tbody//tr["+itr+"]//td[3]//span[1]")).getText();
				 break;
			 }
			 
		 }
		RC_Global.clickButton(driver, "Reset",false,true);
		
		RC_Global.createNode(driver, "Fuel Card Management Screen Unit Number Search Filter Funcionality Validation");
		WebElement UnitNumberSearchFilter = driver.findElement(By.xpath("//input[@placeholder='Unit Number']"));
		RC_Global.enterInput(driver, UnitNumber, UnitNumberSearchFilter, false,true);
		RC_Global.clickButton(driver, "Search",false,true);
		
		if(OrderNumberOrLast4Digit.equalsIgnoreCase("Order Fuel Card"))
			RC_Global.waitUntilPanelVisibility(driver, "Order Card- Unit "+UnitNumber, "TV", false,true);
		else
			RC_Global.waitUntilPanelVisibility(driver, "Manage Card- Unit "+UnitNumber, "TV", false,true);
		String VehicleNum = driver.findElement(By.xpath("//div//strong[contains(text(),'Customer Vehicle Number')]/../span")).getText();
		String VinNum = driver.findElement(By.xpath("//div//strong[contains(text(),'VIN')]/../span")).getText();
		
		RC_Global.panelAction(driver, "close", "Manage Card- Unit "+UnitNumber, false,false);
		Thread.sleep(2000);
		
		if(driver.findElements(By.xpath("//h3[text()='This customer has no profiles that are active and finalized.']")).size()>0)
			RC_Global.clickButton(driver, "OK", true, false);
		RC_Global.navigateTo(driver, "Fleet Services", "Fuel", "Fuel Card Management");
		
		RC_Global.createNode(driver, "Fuel Card Management Screen Vehicle Number Search Filter Funcionality Validation");
		WebElement VehicleNumSearchFilter = driver.findElement(By.xpath("//input[@placeholder='Vehicle Number']"));
		RC_Global.enterInput(driver, VehicleNum, VehicleNumSearchFilter,true,true);
		RC_Global.clickButton(driver, "Search",true,true);
		if(driver.findElements(By.xpath("//h3[text()='This customer has no profiles that are active and finalized.']")).size()>0)
			RC_Global.clickButton(driver, "OK", true, false);
		
		RC_Global.waitUntilPanelVisibility(driver, "Manage Card- Unit "+UnitNumber, "TV",true,true);
		
		RC_Global.panelAction(driver, "close", "Manage Card- Unit "+UnitNumber,true,true);
		
		RC_Global.navigateTo(driver, "Fleet Services", "Fuel", "Fuel Card Management");
		
		RC_Global.createNode(driver, "Fuel Card Management Screen VIN Search Filter Funcionality Validation");
		WebElement VINSearchFilter = driver.findElement(By.xpath("//input[@placeholder='VIN']"));
		RC_Global.enterInput(driver, VinNum, VINSearchFilter,true,true);
	
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.waitUntilPanelVisibility(driver, "Manage Card- Unit "+UnitNumber, "TV",true,true);
		
		RC_Global.panelAction(driver, "close", "Manage Card- Unit "+UnitNumber,true,true);
		
		RC_Global.navigateTo(driver, "Fleet Services", "Fuel", "Fuel Card Management");
		RC_Global.createNode(driver, "Fuel Card Management Screen Card Number - Last 4 Search Filter Funcionality Validation");
		WebElement CardLast4digtFilter = driver.findElement(By.xpath("//input[@placeholder='Card Number - Last 4']"));
		RC_Global.enterInput(driver, CardLst4, CardLast4digtFilter,true,true);
		
		RC_Global.clickButton(driver, "Search",true,true);
		Thread.sleep(2000);		
		RC_Global.panelAction(driver, "close", "Manage Card- Unit",false,true);
		
		
		RC_Global.createNode(driver, "Fuel Card Management Screen Driver First Name and Last Name Search Filters Funcionality Validation");
		RC_Global.navigateTo(driver, "Fleet Services", "Fuel", "Fuel Card Management");
		
		WebElement DriverFirstNameSearchFilter = driver.findElement(By.xpath("//input[@placeholder='Driver First Name']"));
		WebElement DriverLastNameSearchFilter = driver.findElement(By.xpath("//input[@placeholder='Driver Last Name']"));
		RC_Global.enterInput(driver, DriFirstName, DriverFirstNameSearchFilter,true,true);
		RC_Global.enterInput(driver, DriLastName, DriverLastNameSearchFilter,true,true);
		RC_Global.clickButton(driver, "Search",true,true);
		
		RC_Global.clickButton(driver, "Reset",true,true);
		Thread.sleep(2000);
		
		RC_Global.panelAction(driver, "close", "Fuel Card Management", true, false);
		
		
		RC_Global.createNode(driver, "Fuel Card Management Plate Number Search Filter Funcionality Validation");
		RC_Global.navigateTo(driver, "Fleet Services", "Fuel", "Fuel Card Management");
		WebElement PlateFilter = driver.findElement(By.xpath("//input[@placeholder='Plate Number']"));
		RC_Global.enterInput(driver, Plate, PlateFilter,true,true);
		RC_Global.clickButton(driver, "Search",true,true);
		
		RC_Global.panelAction(driver, "close", "Manage Card- Unit",false,true);
		
		RC_Global.createNode(driver, "Fuel Card Management Plate Number Search Filter Funcionality Validation");
		RC_Global.navigateTo(driver, "Fleet Services", "Fuel", "Fuel Card Management");
		WebElement CustomerCardData = driver.findElement(By.xpath("//input[@placeholder='Customer Card Data']"));
		RC_Global.enterInput(driver, custCardData, CustomerCardData,true,true);
		RC_Global.clickButton(driver, "Search",true,true);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	 }
}