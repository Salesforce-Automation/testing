package FleetServices.Fuel.FuelCardManagement;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;

public class TID_2_2_3_10 {
public void Validate_FuelCard_FinalizedProfile_SelectOptions_In_OrderCard (WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
		 
		String profileOptions="";
		String profiles = "";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
		RC_Global.validateHeaderName(driver, "Customer Administration", true);
		RC_Global.enterCustomerNumber(driver, "LS008737", "", "", true);
		Thread.sleep(2000);
		RC_Global.clickUsingXpath(driver, "//a[text()='Fuel']", "Fuel Tab", true,true);
		RC_Global.buttonStatusValidation(driver, "Yes", "Enable", false);
		RC_Global.buttonStatusValidation(driver, "Fuel Attributes", "Enable", false);
		RC_Global.clickButton(driver, "Fuel Card Profile", true,true);
			
		RC_Global.waitElementVisible(driver, 10, "//legend[text()='Card Profile(s)']", "Card Profile(s)", true,true);
		List<WebElement> Activegridrowcnt= driver.findElements(By.xpath("//div[div[div[fieldset[legend[text()='Card Profile(s)']]]]]//tr[td[text()='Finalized' and 'Active']]/td[1]"));
		
		Thread.sleep(1000);
		for(int i=1; i<=Activegridrowcnt.size();i++) {
		 profiles=driver.findElement(By.xpath("(//div[div[div[fieldset[legend[text()='Card Profile(s)']]]]]//tr[td[text()='Finalized' and 'Active']]/td[1])["+i+"]")).getText();
		Thread.sleep(2000); 
		queryObjects.logStatus(driver, Status.INFO, "Fuel card profile with Finalized and Active status ", profiles, null);
		}
		
		RC_Global.panelAction(driver, "close", "Customer Administration", false,true);
		
		RC_Global.navigateTo(driver, "Fleet Services", "Fuel", "Fuel Card Management");
		RC_Global.validateHeaderName(driver, "Fuel Card Management", true);
		RC_Global.enterCustomerNumber(driver, "LS008737", "", "",true);
		RC_Global.clickButton(driver, "Search",true,true);
		RC_Global.waitElementVisible(driver, 30, "//table//tbody//tr", "Records of the Grid",true,true);
		RC_FleetServices.selectRecordOrValueFromGrid(driver, "Order Fuel Card",true);
		RC_Global.waitElementVisible(driver, 30, "//h5/span[contains(text(),'Order Card')]", "Order Card",true,true);
		
		RC_Global.panelAction(driver, "close", "Fuel Card Management",true,true);
		RC_Global.panelAction(driver, "xpathexpand", "//h5[span[contains(text(),'Order Card')]]",true,false);
		
		RC_Global.selectDropdownOption(driver, "replacementReason", "Fuel Only",true,true);
		
		RC_Global.clickUsingXpath(driver, "//select[@name='profile']", "Profile Dropdown",true,true);
		Thread.sleep(2000);
		List<WebElement> profileOptionsrowcnt = driver.findElements(By.xpath("//select[@name='profile']/option[@label]"));
		for(int i=1; i<=profileOptionsrowcnt.size();i++) {
		 profileOptions=driver.findElement(By.xpath("(//select[@name='profile']/option[@label])["+i+"]")).getText();
		Thread.sleep(2000); 
		queryObjects.logStatus(driver, Status.INFO, "Order Card profile as ", profileOptions, null);
		}
		
			if(profiles.equalsIgnoreCase(profileOptions)) 
				queryObjects.logStatus(driver, Status.PASS, "Profiles displayed in fuel card profile matches under Order Card Profile field ", "", null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "profiles displayed in fuel card profile not matches", "", null);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}

}
