package FleetServices.Fuel.FuelCardManagement;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;

public class TID_2_2_3_09 {
	public void Fuel_AddFuelCardprofile (WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Manage", "Administration", "Customer Administration");
		RC_Global.validateHeaderName(driver, "Customer Administration", false);
		RC_Global.enterCustomerNumber(driver, "LS008737", "", "", false);
	//	RC_Global.clickButton(driver, "Fuel");
		RC_Global.clickUsingXpath(driver, "//div/ul/li[3]/a[text()='Fuel']", "Fuel Tab", false,true);
		RC_Global.buttonStatusValidation(driver, "Yes", "Enable", false);
		RC_Global.buttonStatusValidation(driver, "Fuel Attributes", "Enable", false);
		RC_Global.clickButton(driver, "Fuel Card Profile", true,true);
		
		RC_Global.waitElementVisible(driver, 30, "//legend[text()='Card Profile(s)']", "Card Profile(s)", false,true);
		RC_Global.clickButton(driver, "Add Card Profile", true,true);
		RC_Global.scrollById(driver, "//legend[text()='Profile Information']");
		
		String Profile = driver.findElement(By.xpath("//div/label[text()='Profile Name *']/../div/input")).getAttribute("value");
		RC_Global.clickButton(driver, "Fuel Only", true,true);
		RC_Global.selectDropdownOption(driver, "Card Assignment", "Fuel PIN Pool", true,true);
		Thread.sleep(2000);
		RC_Global.clickButton(driver, "Active",true,true);
		
		WebElement DailyTranscationLimit = driver.findElement(By.xpath("//label[text()='Daily Transaction Limit *']/following-sibling::div/input"));
		RC_Global.enterInput(driver, "10", DailyTranscationLimit ,true,true);
		
		WebElement DailySpendLimit = driver.findElement(By.xpath("//input[contains(@ng-model,'DailySpendLimitAmount')]"));
		RC_Global.enterInput(driver, "5", DailySpendLimit,true,true );
		
		RC_Global.clickButton(driver, "Save Selected Card Profile",true,true);
		RC_Global.verifyDisplayedMessage(driver, "Daily Spend Limit must be over $45", true);
		RC_Global.enterInput(driver, "50", DailySpendLimit ,true,true);
		RC_Global.clickButton(driver, "Save Selected Card Profile",true,true);
		RC_Global.verifyDisplayedMessage(driver, "Update Successful",true);
		Thread.sleep(2000);
		//RC_Global.scrollById(driver, "//table//tr/th[1]/div/span[1][text()='Profile']");
		RC_Global.scrollById(driver, "//legend[text()='Card Profile(s)']");
		RC_Global.createNode(driver, "Validate Profile ColumnData");
		RC_FleetServices.validateTheGridData(driver, "Profile;Description;Status at Provider;Active Status",Profile,true);
		
		RC_Global.downloadAndVerifyFileDownloaded(driver, "Export", "Export to excel functionality validation",true);
		//RC_Global.scrollById(driver, "//h5[span[text()='Customer Administration']]");
		//RC_Global.panelAction(driver, "close", "Customer Administration",true);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	
		}
}
