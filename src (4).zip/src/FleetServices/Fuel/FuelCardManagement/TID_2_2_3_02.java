package FleetServices.Fuel.FuelCardManagement;

import org.openqa.selenium.WebDriver;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;

public class TID_2_2_3_02 {
	public void Fuel_TerminateAExistingFuelCard (WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Fleet Services", "Fuel", "Fuel Card Management");
		RC_Global.enterCustomerNumber(driver, "LS010116", "", "", false);//Customer Number ---> LS010116
		RC_Global.clickButton(driver, "Search",true,true);
		RC_Global.waitElementVisible(driver, 60, "//table//tbody//tr", "Search Result Grid",true,true);
		RC_FleetServices.selectRecordOrValueFromGrid(driver, "Last4digit",true);
	//	RC_Global.clickUsingXpath(driver, "(//span[@title='Open Fuel Management'])[1]", "CellLink: Card#-Last4", true,true);
		
		RC_Global.waitElementVisible(driver, 5, "//h5[span[contains(text(),'Manage Card')]]", "Manage Card panel",true,true);
		RC_Global.panelAction(driver, "close", "Fuel Card Management",true,true);
		RC_Global.panelAction(driver, "expand", "Manage Card",true,false);
		RC_Global.clickButton(driver, "Terminate Card",true,true);
		
		RC_Global.waitElementVisible(driver, 5, "//h5[span[contains(text(),'Manage Card - Terminate Card')]]", "Manage Card - Terminate Card panel",true,true);
		RC_Global.panelAction(driver, "Close Panel", "//h5[span[contains(text(),'Manage Card- Unit')]]",true,true);
		RC_Global.panelAction(driver, "Expand Panel", "Terminate Card",true,false);
		RC_Global.radioButton(driver, "Terminate Card", "Terminate Card Only",true);
		
		RC_Global.clickButton(driver, "Submit",true,true);
		RC_Global.verifyDisplayedMessage(driver, "Card was successfully terminated",true);
		
	}
}
