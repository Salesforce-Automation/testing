package FleetServices.Fuel.FuelCardManagement;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;

public class TID_2_2_3_04 {

    public void  Fuel_PerformRecycleCardLimit(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
    
        JavascriptExecutor js = (JavascriptExecutor) driver;
        
        RC_Global.login(driver);
        RC_Global.navigateTo(driver, "Fleet Services", "Fuel", "Fuel Card Management");
        RC_Global.enterCustomerNumber(driver, "HO1017", "", "", false);
        RC_Global.clickButton(driver, "Search", true,true);
        RC_Global.waitElementVisible(driver, 30, "//table//tbody//tr", "Search Result Grid", true,true);
        RC_FleetServices.selectRecordOrValueFromGrid(driver, "Last4digit", true);
        
        RC_Global.waitElementVisible(driver, 30, "//h5[span[contains(text(),'Manage Card')]]", "Manage Card Panel", true,true);
        Thread.sleep(1000);
        RC_Global.panelAction(driver, "close", "Fuel Card Management", true,true);
        Thread.sleep(1000);
        RC_Global.panelAction(driver, "expand", "Manage Card", true,false);
        js.executeScript("window.scrollBy(0,800)");
        RC_Global.createNode(driver, "Recycle Card Limit Functionality Validation");
        RC_Global.clickButton(driver, "Manage Card Profile", true,true);
        RC_Global.waitElementVisible(driver, 30, "//h5[span[contains(text(),'Manage Card - Manage Card Profile')]]", "Manage Card - Manage Card Profile Panel", true,true);
        
        RC_Global.clickUsingXpath(driver, "(//h5[span[contains(text(),'Manage Card')]])[1]/i[@ng-click='closePanel()']", "Order Card", true,false);
        //WebElement element1 = driver.findElement(By.xpath("//button[text()='Recycle Card Limit']"));
        RC_Global.clickUsingXpath(driver, "//h5[span[contains(text(),'Manage Card - Manage Card Profile')]]/i[@ng-click='maximize(panel)']", "Expend-->Manage Card - Manage Card Profile Panel", true,false);
        Thread.sleep(1000);
        //js.executeScript("arguments[0].scrollIntoView(true);",element1);
        //js.executeScript("document.body.style.zoom = '50%'");
        Thread.sleep(2000);
        //js.executeScript("document.body.style.zoom = '100%'");
        RC_Global.clickButton(driver, "Recycle Card Limit", true,true);
        RC_Global.waitElementVisible(driver, 30, "//h4[text()='Card limits have been reset.']", "Card Limit Reset Successfully", true,false);
        RC_Global.verifyDisplayedMessage(driver, "Card limits have been reset", true);
        //js.executeScript("document.body.style.zoom = '50%'");
        //Thread.sleep(2000);
        //js.executeScript("document.body.style.zoom = '100%'");
        //js.executeScript("window.scrollBy(0,-800)");
        //RC_Global.clickUsingXpath(driver, "//h5[span[contains(text(),'Manage Card')]]/i[@ng-click='closePanel()']", "Order Card",true);
        
        queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

 

    }
}