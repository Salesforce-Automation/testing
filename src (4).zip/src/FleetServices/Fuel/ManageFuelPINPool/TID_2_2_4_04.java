package FleetServices.Fuel.ManageFuelPINPool;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;

public class TID_2_2_4_04 {

	public static void AddFuelPINPool(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		String CusNum = "LS008737";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,"Fleet Services","Fuel","Manage Fuel PIN Pool");
		RC_Global.enterCustomerNumber(driver, CusNum, "", "", true);
		RC_Global.clickButton(driver, "Add Pool", true, true);
		RC_Global.waitElementVisible(driver, 60, "(//h5/span[text()='Manage Fuel PIN Pool'])[2]", "Manage Fuel PIN Pool", false, false);
		RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='Manage Fuel PIN Pool']])[1]", false, false);
		RC_Global.panelAction(driver, "expand", "Manage Fuel PIN Pool", false, false);
		
		String poolName = "Test Automation Pool"+RandomStringUtils.randomNumeric(2);
		String poolDescription = "Sample Pool"+RandomStringUtils.randomNumeric(2);
		WebElement inputBox = RC_Global.accessInputBoxViaLabel(driver, "Pool Name: ",true);
		RC_Global.enterInput(driver, poolName, inputBox,true,true);
		WebElement inputBox1 = RC_Global.accessInputBoxViaLabel(driver, "Description: ", false);
		RC_Global.enterInput(driver, poolDescription, inputBox1,false,true);
		Thread.sleep(1000);

		RC_FleetServices.addEmployeeFromPool(driver,true);
		
		if(driver.findElements(By.xpath("//h4[contains(text(),'PIN Pool names must be unique.')]")).size()>0)
		{
			RC_Global.enterInput(driver, poolName, inputBox,true,true);
			RC_Global.verifyDisplayedMessage(driver, "Save Successfull",false);			
		}
		
		String Employeecount = driver.findElement(By.xpath("//strong[normalize-space(text())='Employee Count:']/../span")).getText();
		queryObjects.logStatus(driver, Status.INFO, "Employee Count for the '"+poolName+"' ", Employeecount, null);
		RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='Manage Fuel PIN Pool']])[2]",true,true);
		RC_Global.panelAction(driver,"expand","Manage Fuel PIN Pool",true,false);
		RC_Global.panelAction(driver,"close","Manage Fuel PIN Pool",true,true);
		
		RC_Global.navigateTo(driver, "Fleet Services", "Fuel", "Manage Fuel PIN Pool");
		RC_Global.enterCustomerNumber(driver, CusNum, "", "", true);
		Thread.sleep(1000);

		RC_Global.createNode(driver, "Validation of Newly added Pool");
		boolean flag = false;
		List<WebElement> rowcnt = driver.findElements(By.xpath("//tr/td[1]"));
		Thread.sleep(2000);
		for(int i=1; i<=rowcnt.size();i++)
		{
			String PoolNm = driver.findElement(By.xpath("(//tr//td[1])["+i+"]")).getText();
			String Descrptn = driver.findElement(By.xpath("(//tr//td[2])["+i+"]")).getText();
			String empcnt = driver.findElement(By.xpath("(//tr//td[6])["+i+"]")).getText(); 
			Thread.sleep(2000);
			if((PoolNm.equals(poolName)) && (Descrptn.equals(poolDescription)) )
			{		flag=true;
					queryObjects.logStatus(driver, Status.PASS, "Verified newly added PoolName & Description", "Successfully", null);
				if(empcnt.equals(Employeecount))
				{
					queryObjects.logStatus(driver, Status.PASS, "Newly added pool Employee count matches", "Successfully", null);
				}
			}break;
		}
		if(!flag)
		{
		queryObjects.logStatus(driver, Status.FAIL, "Not found changes in Newly added pool", "Verification Failed", null);
		}	
		RC_Global.panelAction(driver, "close", "Manage Fuel PIN Pool",true,true);
		RC_Global.logout(driver, false);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
