package FleetServices.Fuel.ManageFuelPINPool;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;

public class TID_2_2_4_03 {
	public void Fuel_EditFuelPINPool(WebDriver driver, BFrameworkQueryObjects queryObjects)throws Exception
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		String menu = "Fleet Services";
		String firstSubMenu = "Fuel";
		String secondSubMenu = "Manage Fuel PIN Pool";
		String customerNumber = "LS008742";
		
		String description = "Test Pool Description"+RandomStringUtils.randomNumeric(2);
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.enterCustomerNumber(driver, customerNumber, "Customer", "", true);
		RC_Global.clickUsingXpath(driver, "//span[text()='Edit Pool']", "Edit Pool", false,true);
		RC_Global.panelAction(driver,"xpathexpand","(//h5[span[text()='Manage Fuel PIN Pool']])[2]", false,false);
		WebElement inputBox = RC_Global.accessInputBoxViaLabel(driver, "Description: ", true);
		RC_Global.enterInput(driver, description,inputBox,true,true);
		executor.executeScript("document.body.style.zoom = '30%'");
		executor.executeScript("document.body.style.zoom = '100%'");
        RC_FleetServices.addEmployeeFromPool(driver,true);
        RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='Manage Fuel PIN Pool']])[2]",true,true);
		RC_Global.panelAction(driver,"expand","Manage Fuel PIN Pool",true,false);
//		RC_Global.clickUsingXpath(driver, "//tbody//tr[1]//td[1]");
		RC_Global.panelAction(driver,"close","Manage Fuel PIN Pool",true,true);
		
		RC_Global.navigateTo(driver, menu, firstSubMenu, secondSubMenu);
		RC_Global.enterCustomerNumber(driver, customerNumber, "Customer", "", true);
		Thread.sleep(1000);
		List<WebElement> descriptions = driver.findElements(By.xpath("//tr/td["+RC_Global.findColumnNumber(driver, "Description", true)+"]"));
		Thread.sleep(1000);
		boolean flag = false;
		int iter = 0;
		for(WebElement desc:descriptions) {
			if(desc.getText().equals(description)) {
				
				queryObjects.logStatus(driver, Status.PASS, "Verify change in description", "Verified Successfully", null);
				flag=true;
				iter++;
				break;
			}	
			
		}
		RC_Global.clickUsingXpath(driver, "//tbody//tr["+iter+"]//td[1]", "Pool Name",true,true);
		if(!flag)
			queryObjects.logStatus(driver, Status.FAIL, "Verify change in description", "Verification Failed", null);

		Thread.sleep(2000);
		RC_Global.panelAction(driver,"xpathexpand","(//h5[span[text()='Manage Fuel PIN Pool']])[2]",true,true);	

		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}

}
