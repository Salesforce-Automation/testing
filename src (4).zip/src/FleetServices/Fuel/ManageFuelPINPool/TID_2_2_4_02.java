package FleetServices.Fuel.ManageFuelPINPool;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_2_2_4_02 {
	public static void CloneFuelPINPool(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		String poolName = "Sample Pool Name"+RandomStringUtils.randomNumeric(2);
		String poolDescription = "Sample Pool Description"+RandomStringUtils.randomNumeric(2);
		RC_Global.login(driver);

		for(int iterator=0;iterator<2;iterator++) {
			RC_Global.navigateTo(driver, "Fleet Services", "Fuel", "Manage Fuel PIN Pool");
			RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
			
			if(iterator==0) {
				WebElement element= driver.findElement(By.xpath("//tr[1]/td/span[text()='Clone Pool']"));
				executor.executeScript("arguments[0].scrollIntoView(true);",element);
				element.click();
				executor.executeScript("document.body.style.zoom = '30%'");
				executor.executeScript("document.body.style.zoom = '100%'");
				
				RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='Manage Fuel PIN Pool']])[1]", true,true);
				RC_Global.panelAction(driver, "expand", "Manage Fuel PIN Pool",true,false);
				WebElement inputBox = RC_Global.accessInputBoxViaLabel(driver, "Description: ", false);
				RC_Global.enterInput(driver, poolDescription, inputBox,false,true);
				Thread.sleep(1000);
				RC_Global.clickUsingXpath(driver, "//div[@is-active='isEmployeesPinPoolTabActive']//button[normalize-space(text())='Save']", "Save", false,true);
				
				executor.executeScript("document.body.style.zoom = '30%'");
				executor.executeScript("document.body.style.zoom = '100%'");
				RC_Global.verifyDisplayedMessage(driver, "PIN Pool names must be unique. Please enter a unique name and try again.",false);
				
				inputBox = RC_Global.accessInputBoxViaLabel(driver, "Pool Name: ",true);
				RC_Global.enterInput(driver, poolName, inputBox,true,true);
				
				Thread.sleep(1000);
				RC_Global.clickUsingXpath(driver, "//div[@is-active='isEmployeesPinPoolTabActive']//button[normalize-space(text())='Save']", "Save",true,true);
				
				executor.executeScript("document.body.style.zoom = '30%'");
				executor.executeScript("document.body.style.zoom = '100%'");
				RC_Global.verifyDisplayedMessage(driver, "Save Successfull",true);
				Thread.sleep(1000);
				RC_Global.panelAction(driver, "close", "Manage Fuel PIN Pool",true,true);
			}
			if(iterator==1) {
				Thread.sleep(1000);
				List<WebElement> descriptions = driver.findElements(By.xpath("//tr/td["+RC_Global.findColumnNumber(driver, "Description", true)+"]"));
				List<WebElement> poolNames = driver.findElements(By.xpath("//tr/td["+RC_Global.findColumnNumber(driver, "Pool Name", true)+"]"));
				boolean flag = false;
				for(WebElement desc:descriptions) {
					if(desc.getText().equals(poolDescription)) {
						queryObjects.logStatus(driver, Status.PASS, "Verify change in description", "Verified Successfully", null);
						flag=true;
						break;
					}	
				}
				if(!flag)
					queryObjects.logStatus(driver, Status.FAIL, "Verify change in description", "Verification Failed", null);

				Thread.sleep(2000);
				flag = false;
				for(WebElement pool:poolNames) {
					if(pool.getText().equals(poolName)) {
						
						queryObjects.logStatus(driver, Status.PASS, "Verify change in Pool Name", "Verified Successfully", null);
						flag=true;
						break;
					}
						
				}
				if(!flag)
					queryObjects.logStatus(driver, Status.FAIL, "Verify change in description", "Verification Failed", null);

			}
		}

		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}
}
