package FleetServices.Fuel.ManageFuelPINPool;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;


public class TID_2_2_4_01 {
	public void Fuel_Validate_FuelPinPool_ResultsGrid(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
		
		String ColumnNmes1 = "Pool Name;Description;Customer #;Customer Name;Vehicle Count;Employee Count;Creation Status;Status;Created By;Created Date";
		String ColumnNmes2 = "Fleet #;Fleet Name;Account #;Account Name;Sub-Account #;Sub-Account Name";
			
		
		RC_Global.login(driver);
        RC_Global.navigateTo(driver, "Fleet Services", "Fuel", "Manage Fuel PIN Pool");
        RC_Global.enterCustomerNumber(driver, "LS008737", "", "", true);
        RC_Global.waitElementVisible(driver, 60, "//tbody/tr", "Search Result Grid", true,true);
        RC_FleetServices.verifyGridColumnsByName(driver, ColumnNmes1,"ManageFuelPINPool", true);
        RC_Global.verifyAsHyperlinkByLinkName(driver, "Edit Pool", true);
        RC_Global.verifyAsHyperlinkByLinkName(driver, "Clone Pool", true);
        RC_FleetServices.verifyGridColumnsByName(driver, ColumnNmes2,"ManageFuelPINPool",true);
        RC_Global.downloadAndVerifyFileDownloaded(driver, "Export","Export To Excel Functionality",true);
		RC_Global.panelAction(driver, "close", "Manage Fuel PIN Pool",false,true);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}
}