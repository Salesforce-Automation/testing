package FleetServices.Maintenance.VendorLocate;

	import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;

	public class TID_2_3_3_01 {
	    public void Maintenance_VendorLocateVendorSearchNationalAccountsAndPreferredVendorsOptions(WebDriver driver,BFrameworkQueryObjects queryObjects)throws Exception{
	        
	        String searchFilters = "Enter an Address, Zip Code, City, State to find a Vendor Near You;Within X Miles;Vendor Name;Vendor Phone Number;Vendor Code;Services Offered;Vehicles Serviced;Rating";
	        String errorMsg = "'Address/Zip Code/City/State' is a required field.";
	        String ColumnNames = "Vendor Name;Rating;Distance;Address;City;State;Zip;Appointment Link;Phone Number;National Account;Preferred Vendor;Services Offered;Vehicles Serviced";
	        String VendorNearYou="New York";
	        JavascriptExecutor executor = (JavascriptExecutor)driver;
	        
	        RC_Global.login(driver);
	        RC_Global.navigateTo(driver, "Fleet Services", "Maintenance", "Vendor Locate");
	        RC_Global.validateSpecifiedSearchFilters(driver, searchFilters,false);
	        RC_FleetServices.checkBoxValidation(driver, "National Accounts",true);
	        RC_Global.buttonStatusValidation(driver, " Search ", "Enable",true);
	        RC_Global.buttonStatusValidation(driver, " Reset ", "Enable",true);
	        RC_Global.clickButton(driver, "Search",true,true);
	        RC_Global.verifyDisplayedMessage(driver, errorMsg,false);
	        RC_Global.validateSearchFilterAction(driver, "Enter an Address, Zip Code, City, State to find a Vendor Near You", VendorNearYou , "Vendor Locate",false,true);
	        executor.executeScript("window.scrollTo(0,800)");
//	        RC_Global.verifyColumnNames(driver, ColumnNmes,false);
	        
	        String [] expColName = ColumnNames.split(";");
	        RC_Global.waitElementVisible(driver, 30, "//div/span[normalize-space(text())='Vendor Name']", "Result Grid", true, false);
	        
			for(int i=0; i<expColName.length; i++) {
				try {
					driver.findElement(By.xpath("//div/span[normalize-space(text())='"+expColName[i]+"']"));				
				}
				catch(Exception e) {
				queryObjects.logStatus(driver, Status.FAIL, "Validate Report Column Names--->Column: " + expColName[i] + "--->Was NOT Found", e.getLocalizedMessage(), e);
				}
			}
	        executor.executeScript("document.body.style.zoom = '30%'");
	        executor.executeScript("document.body.style.zoom = '100%'");
	        RC_Global.googleRoutePageValidation(driver, VendorNearYou,true);
	        RC_Global.panelAction(driver, "close", "Vendor Locate",true,true);   
			queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	    }

	 

	}

