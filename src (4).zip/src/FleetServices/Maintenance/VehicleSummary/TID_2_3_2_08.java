package FleetServices.Maintenance.VehicleSummary;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;
public class TID_2_3_2_08 {
	public void MaintenanceValidateTheServiceProgramsSection(WebDriver driver,BFrameworkQueryObjects queryobjects) throws Exception
	{
		String menu = "Fleet Services";
		String firstSubMenu = "Maintenance";
		String secondSubMenu = "Vehicle Summary";
		String CustomerNumber = "LS010143";
		String DriverName = "";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.enterCustomerNumber(driver, CustomerNumber, "", "",false);
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Active lease", false);
		RC_Global.clickButton(driver, "Search", false, true);
		RC_Global.waitElementVisible(driver, 30, "//tbody//tr[1]", "Search Result Grid", false, true);
		
		RC_Global.clickUsingXpath(driver,"//tbody//tr[1]","Select Record from grid", true, true);
		RC_Global.clickButton(driver, "Select Vehicle", false,true);
		RC_Global.waitElementVisible(driver, 30, "(//h5/span[text()='Vehicle Summary'])[2]", "Vehicle Summary screen after clicking on Select Vehicle", false, true);
		
		RC_Global.verifyScreenComponents(driver,"lable","Service Interval:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Expected Maturity:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Upfit Information:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Maintenance Program:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Customer Limit:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Roadside Enrollment:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Non-Preferred Vendors Permitted:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Rental Vehicle Permitted:", true);
		
		RC_Global.verifyScreenComponents(driver,"lable","Glass Repairs Permitted:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Glass Replacements Permitted:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Tire Program:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Snow Tires Permitted:", true);
		
		RC_Global.verifyScreenComponents(driver,"lable","Kevlar Tires Permitted:",true);
		RC_Global.verifyScreenComponents(driver,"lable","Retreads Permitted:",true);
		RC_Global.verifyScreenComponents(driver,"lable","Total Tires Allowed:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Total Tires Used:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Enrolled In Fleet Assist:", true);
		
		RC_Global.verifyScreenComponents(driver,"lable","Maintenance Repairs Tax Exempt:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Merchants Insurance:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Notes:", true);
		
		
		
	}

}
