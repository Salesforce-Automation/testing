package FleetServices.Maintenance.VehicleSummary;
import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.LeaseWave.RC_LW_FleetServices;
import tools.LeaseWave.RC_LW_Global;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;
public class TID_2_3_2_02 {
    public void Maintenance_Create_EditRepairOrderOverVehicleSummary(WebDriver driver, BFrameworkQueryObjects queryObjects)throws Exception
    {        
        String GLtemplatefromTV = null;
           String BillproductfromTV = null;
           String BillinvoicefromTV = null;
           String CustomerNumber = "LS007656";
           String RO_Number = "";
           String ColumnNmes ="Unit Number;Customer Vehicle Number;Pool Name;Customer Number;Full VIN or Last 8;Driver First Name;Driver Last Name;Plate Number;Plate State;Vehicle Status";
           String SelectionOptions = "Active lease;Active services only;Closed;On Order;Pending Activation;Pending termination;Sold;Terminated lease;Terminated services only";
           String errorMsg ="An RO can not be created for units in On Order, Pending Activation, or Cancelled status.";
           
     RC_Global.login(driver);
     //-----------Starts Fetching Unit Number and Edit RO ----------------------------------\\
     RC_Global.navigateTo(driver,"Fleet Services","Maintenance","Repair Order");
     RC_Global.enterCustomerNumber(driver, CustomerNumber, "Customer", "",false);
     RC_Global.selectDropdownOption(driver, "RO Status", "Open",false, true);
     RC_Global.clickButton(driver, "Search",false, true);
     RC_Global.waitElementVisible(driver, 30, "(//div[contains(@role,'gridcell')]//a)[2]", "Search Result Grid",false,false);
     String unitNumber = ((WebElement)driver.findElement(By.xpath("(//div[contains(@role,'gridcell')]//a)[2]"))).getText();
     RC_Global.panelAction(driver, "close", "Repair Order",false, false);
   
     RC_Global.navigateTo(driver,"Fleet Services","Maintenance","Vehicle Summary");
     RC_Global.enterCustomerNumber(driver, CustomerNumber, "Customer", "", false);
     RC_Global.enterInput(driver, unitNumber, (WebElement)(driver.findElement(By.xpath("//*[@placeholder='Unit Number']"))),true, true);
     RC_Global.clickButton(driver, "Search",false, true);
     Thread.sleep(2000);
     RC_Global.waitElementVisible(driver, 30, "(//h5[span[text()='Vehicle Summary']])[2]", "Vehicle Summary",false, true);
     RC_Global.scrollById(driver, "//legend[text()='RO Summary']");
     RC_Global.waitElementVisible(driver, 30, "//button[(contains(@ng-disabled, 'disableEdit(row.entity.POStatus)'))]", "PO Status",false, false);
     RC_Global.buttonStatusValidation(driver, "Edit", "",false);
     
            if(driver.findElements(By.xpath("//button[normalize-space((text())='Edit') and (contains(@ng-disabled, 'disableEdit(row.entity.POStatus)'))]")).size()>0){
                 driver.findElement(By.xpath("(//button[normalize-space((text())='Edit') and (contains(@ng-disabled, 'disableEdit(row.entity.POStatus)'))])[1]")).click();
            }
            else {
                 RC_Global.clickButton(driver, "Create RO",false, true);
            }
    RO_Number =RC_FleetServices.createRepairOrderPageOptions(driver,RC_Global.getDateTime(driver,"MM/dd/yyyy",0, false),"","","", "Search","","", "",true,true);
    String[] TotalViewValuesValidation = {RC_FleetServices.VendorNameFromTV,RC_FleetServices.RoCreatedBy,null,null,null};

    RC_LW_Global.leaseWaveLogin(driver,true);
    RC_LW_FleetServices.leaseWaveRepairOrderNumberValidation(driver,RO_Number,TotalViewValuesValidation,true);
    RC_LW_Global.leaseWaveLogOut(driver,false);
	
           queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

    
    }
}
