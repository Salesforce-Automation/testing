package FleetServices.Maintenance.VehicleSummary;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;

public class TID_2_3_2_10 {
	public void ValidateTheRepairHistorySection(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
		String menu = "Fleet Services";
		String firstSubMenu = "Maintenance";
		String secondSubMenu = "Vehicle Summary";
		String CustomerNumber = "LS010143";
		String ColumnNmes = "Service Date;RO Number;Repair Type(s);Vendor Name;Total;Savings;Odometer;RO Status";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.enterCustomerNumber(driver, CustomerNumber, "", "", false);
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Active lease", false);
		RC_Global.clickButton(driver, "Search", false, true);
		RC_Global.waitElementVisible(driver, 30, "//tbody//tr[1]", "Search Result Grid", false, true);
		RC_Global.clickUsingXpath(driver, "//tbody//tr[1]","Select Record from grid", true, true);
		RC_Global.clickButton(driver, "Select Vehicle", false, true);
		RC_Global.waitElementVisible(driver, 30, "(//h5[span[text()='Vehicle Summary']])[2]", "Vehicle Summary Page", false, true);
		RC_Global.scrollById(driver, "//legend[text()='RO Summary']");
		RC_Global.clickUsingXpath(driver, "(//*[contains(@ng-disabled,'vm.loadingTab1')])[5]","", false, false);
		
		RC_Global.panelAction(driver,"close","Vehicle Details", true, false);
		RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='Vehicle Summary']])[1]", false, false);

		RC_Global.panelAction(driver, "expand", "Vehicle Summary", false, false);
		RC_Global.clickButton(driver, "Create RO", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Create RO", "TV", false, true);
		RC_Global.panelAction(driver,"close","Create RO", false, false);
 
		RC_Global.panelAction(driver, "expand", "Vehicle Summary", false, false);
		RC_Global.clickUsingXpath(driver, "(//a[contains(@class,'clickable ng-binding')])[1]","Vehicle Summary", true, true);
		RC_Global.waitUntilPanelVisibility(driver, "Maintenance PO Detail", "TV", false, true);
		RC_Global.panelAction(driver,"close","Maintenance PO Detail", false, false);
		RC_Global.panelAction(driver, "expand", "Vehicle Summary", false, false);
		RC_Global.verifyColumnNames(driver, ColumnNmes, true);
		
		
		RC_Global.clickUsingXpath(driver, "(//div[contains(@ng-show,'grid.appScope.vm.isMROEnabledFlag')])[1]","MRO Flag", true, false);
		RC_Global.clickUsingXpath(driver, "(//div[contains(@ng-show,'grid.appScope.vm.isMROEnabledFlag')])[1]","MRO Flag", false, false);

		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

}
}