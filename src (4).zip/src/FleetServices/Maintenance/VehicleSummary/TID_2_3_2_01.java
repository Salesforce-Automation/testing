package FleetServices.Maintenance.VehicleSummary;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Manage;

public class TID_2_3_2_01 {
	public void Maintenance_CreateROUsingAdvanceSearchInVehicleSummary(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception {
		String menu = "Fleet Services";
	    String firstSubMenu = "Maintenance";
	    String secondSubMenu = "Vehicle Summary";
	    String getDate = "";
		String errorMsg = " An RO can not be created for units in On Order, Pending Activation, or Cancelled status.";
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		String SearchFilters = "Vehicle Status;Fuel Program;Roadside Card #;Agreement Type;Maintenance Agreement Type;Telematics Serial #";
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.enterCustomerNumber(driver, "LS007656", "", "", false);
		RC_Global.clickButton(driver, "Advanced Search",false, true);
		RC_Global.validateSpecifiedSearchFilters(driver, SearchFilters,true);
		Thread.sleep(3000);
		
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver,"Vehicle Status Advanced","Active lease;Active Service Only",false);
        RC_Global.clickButton(driver, "Search",false, true);
        RC_Global.waitElementVisible(driver, 30, "//tbody//tr[1]", "Search Result Grid",false, true);
        RC_Global.clickUsingXpath(driver,"//tbody//tr[1]","Select Record",false, false);
        RC_Global.clickButton(driver, "Select Vehicle",true, true);
        RC_Global.waitElementVisible(driver, 30, "//button[@title='Open Driver Details']","Open Driver Details",false, false);
		RC_Global.scrollById(driver, "//legend[text()='RO Summary']");
        RC_Global.clickButton(driver, "Create RO",false,true); 
        RC_Global.waitElementVisible(driver, 30, "//h5//span[text()='Create RO']","Create RO Page",true,false);
        getDate = RC_Manage.AddDateStr(0, "MM/dd/yyyy", "", null, "");
        RC_FleetServices.createRepairOrderPageOptions(driver, getDate, "", "", "Add", "Search", "", "", "",true,true);

		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}
}
