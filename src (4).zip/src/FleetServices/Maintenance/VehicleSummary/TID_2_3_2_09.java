package FleetServices.Maintenance.VehicleSummary;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;
public class TID_2_3_2_09 {
	public void MaintenanceValidateTheMaintenanceDetailsSection(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception
	{
		String menu = "Fleet Services";
		String firstSubMenu = "Maintenance";
		String secondSubMenu = "Vehicle Summary";
		String CustomerNumber = "LS010143";
		String DriverName = "";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.createNode(driver, "Vehicle Summary");
		RC_Global.enterCustomerNumber(driver, CustomerNumber, "", "", false);
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Active lease", false);
		RC_Global.clickButton(driver, "Search", false, true);
		RC_Global.waitElementVisible(driver, 30, "//tbody//tr[1]", "Search Result Grid", false, true);
		
		RC_Global.clickUsingXpath(driver,"//tbody//tr[1]","Select Record from grid", true, true);
		RC_Global.clickButton(driver, "Select Vehicle", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Summary","TV", true, true);
		Thread.sleep(3000);
		RC_Global.verifyScreenComponents(driver,"lable","Pending Approval RO's:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Open RO's:",true);
		RC_Global.verifyScreenComponents(driver,"lable","Closed RO's LTD:",true);
		RC_Global.verifyScreenComponents(driver,"lable","Spend LTD:", true);
		RC_Global.verifyScreenComponents(driver,"lable","PM Spend LTD:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Brakes LTD:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Tires LTD:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Non-Preventive LTD:", true);
		
		RC_Global.verifyScreenComponents(driver,"lable","Last PM Date:",true);
		RC_Global.verifyScreenComponents(driver,"lable","Last PM Service Odometer:",true);
		RC_Global.clickUsingXpath(driver, "//legend[contains(text(),'Maintenance Details')]/..","Maintenance Details",true, true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details - Maintenance","TV", false, true);
		RC_Global.panelAction(driver, "close", "Vehicle Details - Maintenance", false, false);
		RC_Global.panelAction(driver,"xpathexpand","(//h5[span[text()='Vehicle Summary']])[2]", false, false);
		RC_Global.clickUsingXpath(driver, "//label[contains(text(),'Pending Approval RO')]/../following-sibling::div/button","Pending Approval RO", true, true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details - Maintenance","TV", false, true);
		RC_Global.panelAction(driver, "close", "Vehicle Details - Maintenance", false, false);
		RC_Global.panelAction(driver,"xpathexpand","(//h5[span[text()='Vehicle Summary']])[2]", false, false);
		RC_Global.clickUsingXpath(driver, "//label[contains(text(),'Spend LTD:')]/../following-sibling::div/button","Spend LTD", true, true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details - Maintenance","TV", false, true);
		RC_Global.panelAction(driver, "close", "Vehicle Details - Maintenance", false, false);
		RC_Global.panelAction(driver,"xpathexpand","(//h5[span[text()='Vehicle Summary']])[2]", false, false);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}

}
