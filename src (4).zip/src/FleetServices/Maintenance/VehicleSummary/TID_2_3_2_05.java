package FleetServices.Maintenance.VehicleSummary;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;

public class TID_2_3_2_05 {
	public void Maintenance_ValidateTheUIExceptionBasedOnStatus_OnOrder_PendingActivation_Or_CancelledStatus(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
		String menu = "Fleet Services";
		String firstSubMenu = "Maintenance";
		String secondSubMenu = "Vehicle Summary";
		String CustomerNumber = "LS010143";
		String errorMsg ="An RO can not be created for units in On Order, Pending Activation, or Cancelled status.";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.enterCustomerNumber(driver, CustomerNumber, "", "",true);
		RC_Global.clickButton(driver, "Search", false, true);
		RC_Global.waitElementVisible(driver, 30, "//tbody//tr[1]", "Search Result Grid", false, true);
		RC_Global.clickUsingXpath(driver,"//tbody//tr[1]","Select Record from grid", false, true);
		RC_Global.clickButton(driver, "Select Vehicle", true, true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Summary","TV", false, true);
		RC_Global.waitElementVisible(driver, 30, "//button[@title='Open Driver Details']", "Hyperlink Open Driver Details under Vehicle Summary", false, false);
		RC_Global.scrollById(driver, "//legend[text()='RO Summary']");
		RC_Global.clickButton(driver, "Create RO", false, true);	
//		RC_Global.verifyDisplayedMessage(driver, errorMsg, true);
		
		try {
			RC_Global.waitElementVisible(driver, 30, "//span[normalize-space(text())='An RO can not be created for units in On Order, Pending Activation, or Cancelled status.']", "Error message validation", true, true);
			queryObjects.logStatus(driver, Status.PASS, "Verify error message is displayed", "Error message is displayed", null);
			}
			catch(Exception e) {
			queryObjects.logStatus(driver, Status.PASS, "Verify error message is displayed", "Error message is not displayed", null);
			}
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}
}
