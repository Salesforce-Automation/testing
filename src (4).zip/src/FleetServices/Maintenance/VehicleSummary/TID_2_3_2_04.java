package FleetServices.Maintenance.VehicleSummary;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;

public class TID_2_3_2_04 {
	public void VehicleSummary_ValidateTheSearchFieldResult(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{

		String menu = "Fleet Services";
		String frstSubMenu = "Maintenance";
		String scndSubMenu = "Vehicle Summary";
		WebElement element = null;
		String errorMsg = "Please enter a minimum of 8 characters for a VIN.";
		String searchFilters = "Unit Number;Customer Vehicle Number;Pool Name;Customer Number;Full VIN or Last 8;Driver First Name;Driver Last Name;Plate Number;Plate State;Vehicle Status";
		String SelectionOptions = "Active lease;Active services only;Closed;On Order;Pending Activation;Pending termination;Sold;Terminated lease;Terminated services only";
		String ColumnNmes = "Customer #;Customer Name;Unit Number;CVN;Driver/Pool Name;VIN;Year;Make;Model;Plate;Address;City;State;Zip;Vehicle Status;Email Address;Fleet #;Fleet Name;Account #;Account Name;Sub-Account #;Sub-Account Name";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, menu, frstSubMenu, scndSubMenu);
		RC_Global.createNode(driver, "Vehicle Summary Search Functionality Validation");
		RC_Global.validateSpecifiedSearchFilters(driver, searchFilters, false);
		RC_Global.validateMultipleSelectionFilter(driver, SelectionOptions, false);
		RC_Global.buttonStatusValidation(driver, "Search", "Enable", false);
		RC_Global.buttonStatusValidation(driver, "Reset", "Enable", false);
		RC_Global.buttonStatusValidation(driver, "Advanced Search", "Enable", false);
		
		RC_Global.validateSearchFilterAction(driver, "Unit Number",  "571195","Maintenance", true, true);
		RC_Global.panelAction(driver,"xpathclose","(//h5[span[text()='Vehicle Summary']])[2]", false, false);
		RC_Global.clickButton(driver, "Reset", false, false);
		RC_Global.validateSearchFilterAction(driver, "CVN",  "2491","Maintenance", true, true);
		RC_Global.waitElementVisible(driver, 30, "//table//tr/th", "Search Result Grid", false, true);
		RC_Global.clickButton(driver, "Reset", false, false);
		RC_Global.validateSearchFilterAction(driver,"VIN","2NKH","Maintenance", false, true);
		RC_Global.verifyDisplayedMessage(driver, errorMsg, true);
		RC_Global.clickButton(driver, "Reset", false, false);
		RC_Global.validateSearchFilterAction(driver, "VIN", "2NKHLJ9X0GM128279","Maintenance", true, true);
		RC_Global.waitElementVisible(driver, 30, "//table//tr/th", "Search Result Grid", false, true);
		RC_Global.panelAction(driver,"xpathclose","(//h5[span[text()='Vehicle Summary']])[2]", false, false);
		RC_Global.panelAction(driver, "close", "Vehicle Summary", false, false);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}
}
