package FleetServices.Maintenance.VehicleSummary;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;

public class TID_2_3_2_03 {
	public void VehicleSummary_ValidateResultGrid_HyperLinks(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception {
		String menu = "Fleet Services";
		String firstSubMenu = "Maintenance";
		String secondSubMenu = "Vehicle Summary";
		String CustomerNumber = "LS010143";
		String ColumnNmes = "Customer #;Customer Name;Unit Number;CVN;Driver/Pool Name;VIN;Year;Make;Model;Plate;Address;City;State;Zip;Vehicle Status;Email Address;Fleet #;Fleet Name;Account #;Account Name;Sub-Account #;Sub-Account Name";
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, menu, firstSubMenu, secondSubMenu);
		RC_Global.enterCustomerNumber(driver, CustomerNumber, "", "", true);
		RC_Global.clickButton(driver, "Search", false, true);
		RC_Global.waitElementVisible(driver, 30, "(//table/tbody/tr)[1]", "Search Result Grid", false, true);
		executor.executeScript("document.body.style.zoom = '80%'");
		RC_Global.verifyColumnNames(driver, ColumnNmes, true);
		executor.executeScript("document.body.style.zoom = '100%'");
		RC_Global.clickCellLinkVerifyPanelTitle(driver, "Unit Number", "Vehicle Details", true);
		RC_Global.panelAction(driver, "close", "Vehicle Details", false, false);
		RC_Global.panelAction(driver, "expand", "Vehicle Summary", false, false);
		
		RC_FleetServices.drivername = RC_Global.clickCellLinkVerifyPanelTitle(driver, "Driver/Pool Name", "Driver Details", true);
		RC_Global.panelAction(driver, "close", "Driver Details", false, false);
		RC_Global.panelAction(driver, "expand", "Vehicle Summary", false, false);
		Thread.sleep(1000);
		
		RC_Global.downloadAndVerifyFileDownloaded(driver, "Export", "Export to Excel Functionality",true);
		RC_Global.panelAction(driver, "close", "Vehicle Summary", false, true);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}
}
