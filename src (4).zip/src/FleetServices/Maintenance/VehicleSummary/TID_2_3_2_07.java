package FleetServices.Maintenance.VehicleSummary;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;

public class TID_2_3_2_07 {
	public void MaintenanceValidateDriverInformationSectionFields(WebDriver driver,BFrameworkQueryObjects queryobjects) throws Exception{
		String menu = "Fleet Services";
		String firstSubMenu = "Maintenance";
		String secondSubMenu = "Vehicle Summary";
		String CustomerNumber = "LS010143";
		String DriverName = "";
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.createNode(driver, "Vehicle Summary");
		RC_Global.enterCustomerNumber(driver, CustomerNumber, "", "", false);
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Active lease", false);
		RC_Global.clickButton(driver, "Search", false, true);
		RC_Global.waitElementVisible(driver, 30, "//tbody//tr[1]", "Search Result Grid", false,true);
		
		RC_Global.clickUsingXpath(driver,"//tbody//tr[1]","Select Record from grid", true,false);
		DriverName = driver.findElement(By.xpath("//tbody//tr[1]//td[5]")).getText();
		executor.executeScript("document.body.style.zoom = '30%'");
		Thread.sleep(2000);
		executor.executeScript("document.body.style.zoom = '100%'");
		RC_Global.clickButton(driver, "Select Vehicle", false,true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Summary","TV", true,true);
		RC_Global.waitElementVisible(driver, 30, "//button[contains(text(),'"+DriverName+"')]", "Hyperlink "+DriverName+" under Vehicle Summary", false,false);

		RC_Global.verifyScreenComponents(driver,"lable","Employee ID:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Driver:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Cell Phone:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Work Phone:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Home Phone:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Email:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Address 1:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Address 2:", true);
		RC_Global.verifyScreenComponents(driver,"lable","City:", true);
		RC_Global.verifyScreenComponents(driver,"lable","State:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Zip:", true);
		RC_Global.verifyScreenComponents(driver,"lable","County:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Country:", true);
		
		RC_Global.clickUsingXpath(driver, "//button[contains(text(),'"+DriverName+"')]",""+DriverName, true,true);
		RC_Global.waitUntilPanelVisibility(driver,"Driver Details","TV", false, true);
		RC_Global.panelAction(driver,"close","Driver Details", false,false);
		RC_Global.panelAction(driver,"xpathexpand","(//h5[span[text()='Vehicle Summary']])[2]", false,false);
		RC_Global.clickUsingXpath(driver, "//div//label[text()='Email:']/../following-sibling::div/a/span","Email", false,true);
	}
}
