package FleetServices.Maintenance.VehicleSummary;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;

public class TID_2_3_2_06 {
	public void MaintenanceValidateVehicleInformationSectionFields(WebDriver driver,BFrameworkQueryObjects queryobjects) throws Exception{
		String menu = "Fleet Services";
		String firstSubMenu = "Maintenance";
		String secondSubMenu = "Vehicle Summary";
		String CustomerNumber = "LS010143";
		String selUnitNumber ="";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.createNode(driver, "Vehicle Summary");
		RC_Global.enterCustomerNumber(driver, CustomerNumber, "", "", false);
		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Active lease", false);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.waitElementVisible(driver, 30, "//tbody//tr[1]", "Search Result Grid", false,true);
		selUnitNumber = driver.findElement(By.xpath("//tbody//tr[1]//td[3]")).getText();
		RC_Global.clickUsingXpath(driver,"//tbody//tr[1]","Select Record from grid", true,false);
				
		RC_Global.clickButton(driver, "Select Vehicle", false, true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Summary","TV", true,true);
		RC_Global.waitElementVisible(driver, 30, "//button[contains(text(),'"+selUnitNumber+"')]", "Hyperlink Unit Number selection under Vehicle Summary Page", false,false);
		
		RC_Global.verifyScreenComponents(driver,"lable","Customer Number:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Unit Number:", true);
		RC_Global.verifyScreenComponents(driver,"lable","CVN:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Agreement Type:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Vehicle Status:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Replacement Unit:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Last Odometer:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Latest Engine Hours:", true);
		RC_Global.verifyScreenComponents(driver,"lable","VIN:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Plate/State:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Year:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Make:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Model:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Trim level:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Engine Size:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Fuel Type:", true);
		RC_Global.verifyScreenComponents(driver,"lable","Key Code:", true);
		
		RC_Global.clickUsingXpath(driver, "//button[contains(text(),'"+selUnitNumber+"')]", "Unit Number selection", true,true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details","TV", false, true);
		RC_Global.panelAction(driver,"close","Vehicle Details", false,false);
		RC_Global.waitElementVisible(driver, 30, "//button[@id='LastOdometer']", "Last Odometer button", false,false);

		RC_Global.clickUsingXpath(driver, "//button[@id='LastOdometer']","Last Odometer Button", true,true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details - Odometer","TV", false,true);
		RC_Global.panelAction(driver,"close","Vehicle Details - Odometer", false,false);
		RC_Global.panelAction(driver,"close","Vehicle Summary", false,false);
		
	}
		

}
