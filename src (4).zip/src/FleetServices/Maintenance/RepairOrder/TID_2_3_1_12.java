package FleetServices.Maintenance.RepairOrder;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;

public class TID_2_3_1_12 {
	
	public void MaintenanceRO_ValidateTheVehicleAndServiceProgramDetailSections(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
		
		String ROInformation ="";
		String ServicePrograms ="";
		String MaintenanceDetails="";
		String Sections = "RO Information;Service Programs;Maintenance Details";
		
		String PendingApproval = "";
		String SpendLTD = "";
		String LastPMDate = "";
		
		WebDriverWait wait = new WebDriverWait(driver,60);
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,"Fleet Services","Maintenance","Repair Order");
		RC_Global.enterCustomerNumber(driver, "LS010143", "", "",true);
		RC_Global.clickButton(driver, "Search",true,true);
		//JavascriptExecutor executor = (JavascriptExecutor)driver;
		//executor.executeScript("document.body.style.zoom = '70%'");
		RC_Global.waitElementVisible(driver, 30, "(//div[contains(@class,'ui-grid-row')])[1]", "MRO Search Result",true,true);
		Thread.sleep(2000);
		RC_FleetServices.selectRecordOrValueFromGrid(driver, "Pending Invoice",true);
		RC_Global.clickButton(driver, "Create RO",true,true);
		RC_Global.waitUntilPanelVisibility(driver, "Create RO", "TV",true,true);
		RC_Global.clickUsingXpath(driver, "(//button[(text()='Collapse All')and(@ng-click='vm.setGroupsOpenClosed()')])[1]","Collapse All",true,true);
		RC_Global.verifyAsHyperlinkByLinkName(driver, Sections,true);
		RC_Global.clickUsingXpath(driver, "//button[(text()='Expand All')and(@ng-click='vm.setGroupsOpenClosed()')]","Expand All", true,true);
		
		ROInformation = driver.findElement(By.xpath("//span[contains(text(),'RO Information')]")).getText();
		RC_Global.verifyScreenComponents(driver,"lable","Lease Number:",false);
		RC_Global.verifyScreenComponents(driver,"lable","Approval Limits:",false);
		RC_Global.verifyScreenComponents(driver,"lable","RO Number:",false);
		RC_Global.verifyScreenComponents(driver,"lable","RO Status:",true);
		RC_Global.verifyScreenComponents(driver,"lable","Post Date:",true);
		
		ServicePrograms = driver.findElement(By.xpath("//span[contains(text(),'Service Programs')]")).getText();
		RC_Global.verifyScreenComponents(driver,"lable","Service Interval:",false);
		RC_Global.verifyScreenComponents(driver,"lable","Expected Maturity:",false);
		RC_Global.verifyScreenComponents(driver,"lable","Upfit Information:",false);
		RC_Global.verifyScreenComponents(driver,"lable","Maintenance Program:",false);
		RC_Global.verifyScreenComponents(driver,"lable","Roadside Enrollment:",false);
		RC_Global.verifyScreenComponents(driver,"lable","Non-preferred Vendors Permitted:",false);
		RC_Global.verifyScreenComponents(driver,"lable","Rental Vehicle Permitted:",false);
		RC_Global.verifyScreenComponents(driver,"lable","Glass Repairs Permitted:",false);
		RC_Global.verifyScreenComponents(driver,"lable","Glass Replacements Permitted:",false);
		RC_Global.verifyScreenComponents(driver,"lable","Tire Program:",false);
		RC_Global.verifyScreenComponents(driver,"lable","Snow Tires Permitted:",false);
		RC_Global.verifyScreenComponents(driver,"lable","Kevlar Tires Permitted:",false);
		RC_Global.verifyScreenComponents(driver,"lable","Retreads Permitted:",false);
		RC_Global.verifyScreenComponents(driver,"lable","Total Tires Allowed:",true);
		RC_Global.verifyScreenComponents(driver,"lable","Total Tires Used:",true);
		RC_Global.verifyScreenComponents(driver,"lable","Enrolled In Fleet Assist:",true);
		RC_Global.verifyScreenComponents(driver,"lable","Maintenance Repairs Tax Exempt:",true);
		RC_Global.verifyScreenComponents(driver,"lable","Merchants Insurance:",true);
		RC_Global.verifyScreenComponents(driver,"lable","Notes:",true);
		RC_Global.verifyScreenComponents(driver,"lable","Tire Program:",true);
		
//		JavascriptExecutor js = (JavascriptExecutor) driver;
//		WebElement Element = driver.findElement(By.xpath("//span[contains(text(),'Maintenance Details')]"));
//		js.executeScript("arguments[0].scrollIntoView();", Element);
		RC_Global.scrollById(driver, "//span[contains(text(),'Maintenance Details')]");
		MaintenanceDetails = driver.findElement(By.xpath("//span[contains(text(),'Maintenance Details')]")).getText();
		RC_Global.verifyScreenComponents(driver,"lable","Pending Approval RO's:",false);
		RC_Global.verifyScreenComponents(driver,"lable","Open RO's:",false);
		RC_Global.verifyScreenComponents(driver,"lable","Closed RO's LTD:",false);
		RC_Global.verifyScreenComponents(driver,"lable","Spend LTD:",false);
		RC_Global.verifyScreenComponents(driver,"lable","PM Spend LTD:",false);
		RC_Global.verifyScreenComponents(driver,"lable","Brakes LTD:",true);
		RC_Global.verifyScreenComponents(driver,"lable","Tires LTD:",true);
		RC_Global.verifyScreenComponents(driver,"lable","Non-Preventive LTD:",true);
		RC_Global.verifyScreenComponents(driver,"lable","Last PM Date:",true);
		RC_Global.verifyScreenComponents(driver,"lable","Last PM Service Odometer:",true);
		
		PendingApproval = driver.findElement(By.xpath("//button[contains(@title,'Pending Customer Approval')]")).getText();
		RC_Global.clickUsingXpath(driver, "//button[contains(text(),'"+PendingApproval+"')]","'Pending Customer Approval Button",true,true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details - Maintenance","TV",true,true);
		RC_Global.panelAction(driver,"close","Vehicle Details - Maintenance",false,true);
		
		SpendLTD = driver.findElement(By.xpath("(//button[contains(@title,'Open Maintenance Category')])[1]")).getText();
		RC_Global.clickUsingXpath(driver, "//button[contains(text(),'"+SpendLTD+"')]","Open Maintenance Category",true,true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details - Maintenance","TV",true,true);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='Maintenance Category']")));
		RC_Global.panelAction(driver,"close","Vehicle Details - Maintenance",false,true);
		
		if(driver.findElements(By.xpath("//button[contains(@ng-if,'LastPM_Date')]")).size()>0) {
		LastPMDate = driver.findElement(By.xpath("//button[contains(@ng-if,'LastPM_Date')]")).getText();
		//LastPMDate = driver.findElement(By.xpath("//button[contains(@title,'Open Maintenance PO Detail')]")).getText();
		RC_Global.clickUsingXpath(driver, "//button[contains(text(),'"+LastPMDate+"')]","Last PM Date",true,true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details - Maintenance","TV",true,true);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h3[text()='PO Detail']")));
		RC_Global.panelAction(driver,"close","Vehicle Details - Maintenance",false,true);
		}
		else {
			queryObjects.logStatus(driver, Status.INFO, "Last PM Date", "value is not displayed", null);
		}
		
		//RC_Global.clickUsingXpath(driver, "//button[text()='MAINTENANCE RO HISTORY']","MAINTENANCE RO HISTORY",true);
			
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
