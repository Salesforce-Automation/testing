package FleetServices.Maintenance.RepairOrder;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_2_3_1_04 {
public void MaintenanceRO_ValidateSearchFilters(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
        
        String menu = "Fleet Services";
        String frstSubMenu = "Maintenance";
        String scndSubMenu = "Repair Order";
        String err = "1FT7X2";
        WebDriverWait wait = new WebDriverWait(driver,40);
		WebDriverWait wait1 = new WebDriverWait(driver,10);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
	
        String errorMsg = "Please enter a minimum of 8 characters for a VIN.";
        
    	String SearchFilters = "Customer Number;Unit Number;CVN;Full VIN or Last 8;RO Number;RO Status;RO Created By;Plate Number;"
				+ "Driver Last Name;Driver First Name;Driver Phone Number;Plate State;Vendor WorkOrder Number";
    	
        String ColumnNmes= "RO Number;Receivable IDs;Service Date;Unit Number;CVN;VIN;RO Odometer Reading;Year;Make;Model;Plate Number;"
        		+ "Vendor Name;Vendor Store Number;RO Status;RO Created By";
        
        RC_Global.login(driver);
        RC_Global.navigateTo(driver, menu, frstSubMenu, scndSubMenu);
        RC_Global.validateSpecifiedSearchFilters(driver, SearchFilters,false);
        
        RC_Global.enterCustomerNumber(driver, "LS008737", "", "", false);
        RC_Global.selectDropdownOption(driver, "RO Status", "Pending Invoice",true,true);
        RC_Global.clickButton(driver, "Search",true,true);
        //RC_Global.waitElementVisible(driver, 60, "//div[contains(@ng-style,'Viewport.rowStyle')]", "Search Record",true,true);
        //executor.executeScript("document.body.style.zoom = '70%'");
        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='table-status-container ng-scope']//div[@class='spinner ng-scope']")));
        wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class='ui-grid-row ng-scope'])[1]")));
        
        RC_Global.clickUsingXpath(driver, "(//div[contains(@class,'ui-grid-row')]//div[text()='Pending Invoice'])[1]", "Select Grid Row",true,true);
        String RONumber = driver.findElement(By.xpath("(//div[1]/a[contains(@ng-click,'editMRO')])[1]")).getText();
        String UnitNumber = driver.findElement(By.xpath("(//div[1]/a[contains(@ng-click,'openVehicleDetails')])[1]")).getText(); //The final index must always be odd number for Unit Number
        //String CVN = driver.findElement(By.xpath("(//div[1]/a[contains(@ng-click,'openVehicleDetails')])[2]")).getText(); //The final index must always be even number for CVN
        String VIN = driver.findElement(By.xpath("(//div[@role='gridcell']/following-sibling::div[5])[1]/div")).getText();
        String Vinfst8dig = VIN.substring(0,4);
        
        RC_Global.clickUsingXpath(driver, "(//div[1]/a[contains(@ng-click,'openVehicleDetails')])[1]", "Unit Number",false,true);
        RC_Global.waitUntilPanelVisibility(driver, "Vehicle Details", "TV", false,true);
        WebDriverWait wait2 = new WebDriverWait(driver, 30);
        wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id ='vehicle-details-unit-number' and text()='"+UnitNumber+"']")));      
        String DriverName = driver.findElement(By.xpath("(//button[contains(@title,'Open Driver Change')])[1]")).getText();
        RC_Global.panelAction(driver, "close", "Vehicle Details",true,true);
        RC_Global.panelAction(driver, "expand", "Repair Order",true,true);
        String[] Driver = DriverName.split(" ");
              
        queryObjects.logStatus(driver, Status.INFO, "RO Number data---->", RONumber, null);    
        queryObjects.logStatus(driver, Status.INFO, "Unit Number data---->", UnitNumber, null);
        //Was - CVN
        queryObjects.logStatus(driver, Status.INFO, "VIN data---->", VIN, null);
        queryObjects.logStatus(driver, Status.INFO, "DriverName data---->", DriverName, null);
                       
        RC_Global.clickButton(driver, "Reset",true,true);
        RC_Global.createNode(driver, "Maintenance Repair Order -- RO Number Search Filter Functionality Validation");
        RC_Global.validateSearchFilterAction(driver, "RO Number",  RONumber,"Maintenance",true,true);
//        RC_Global.verifyColumnNames(driver, ColumnNmes,true); //Code below      
        String [] expColName = ColumnNmes.split(";");

		for(int i=0; i<expColName.length; i++) {
			try {
				driver.findElement(By.xpath("//cell-template//div[normalize-space(text())='"+expColName[i]+"']"));				
			}
			catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Validate Report Column Names--->Column: " + expColName[i] + "--->Was NOT Found", e.getLocalizedMessage(), e);
			}
		}
		
        RC_Global.clickButton(driver, "Reset",true,true);
        
        RC_Global.createNode(driver, "Maintenance Repair Order -- Unit Number Search Filter Functionality Validation");
        RC_Global.validateSearchFilterAction(driver, "Unit Number",  UnitNumber,"Maintenance",true,true);      
        RC_Global.clickButton(driver, "Reset",true,true);
        
        //RC_Global.createNode(driver, "Maintenance Repair Order -- CVN Search Filter Functionality Validation");
        //RC_Global.validateSearchFilterAction(driver, "CVN",  CVN,"Maintenance",true);
        //RC_Global.clickButton(driver, "Reset",true);
        
        RC_Global.createNode(driver, "Error Message Validation for wrongly entered VIN Number");
        WebElement element2 = driver.findElement(By.xpath("(//input[@placeholder='VIN' and @ng-model='searchCriteria.VIN'])[1]"));
        RC_Global.enterInput(driver, Vinfst8dig, element2,false,true);
        RC_Global.clickButton(driver, "Search",true,true);
        RC_Global.verifyDisplayedMessage(driver, errorMsg,true);
        RC_Global.clickButton(driver, "Reset",true,true);
       
        
        RC_Global.createNode(driver, "Maintenance Repair Order -- VIN Search Filter Functionality Validation");
        RC_Global.validateSearchFilterAction(driver, "VIN",  VIN,"Maintenance",true,true);      
        RC_Global.clickButton(driver, "Reset",true,true);
       
        RC_Global.createNode(driver, "Maintenance Repair Order -- Driver First Name Search Filter Functionality Validation");
        RC_Global.validateSearchFilterAction(driver, "Driver First Name", Driver[0], "Maintenance",true,true);	
        RC_Global.clickButton(driver, "Reset",true,true);
        
        RC_Global.createNode(driver, "Maintenance Repair Order -- Driver Last Name Search Filter Functionality Validation");
        RC_Global.validateSearchFilterAction(driver, "Driver Last Name", Driver[1], "Maintenance",true,true);      
    
        queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
    }
}
