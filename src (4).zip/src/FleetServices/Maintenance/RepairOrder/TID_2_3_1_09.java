package FleetServices.Maintenance.RepairOrder;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;

public class TID_2_3_1_09 {
public void MaintenanceRO_Details_Reference_RO_Number_Search(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
	    WebDriverWait wait = new WebDriverWait(driver,30);

		String menu = "Fleet Services";
		String firstSubMenu = "Maintenance";
		String secondSubMenu = "Repair Order";
		String errorMsg = "Minimum of 1 search criteria is required. Please specify data in at least one field and click 'Search'.";
		String CustomerNumber = "LS007656";
		String RO_Number;
		
		RC_Global.login(driver);
        RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
        RC_Global.enterCustomerNumber(driver, CustomerNumber, "Customer", "",true);
        RC_Global.selectDropdownOption(driver, "RO Status", "Open",true,true);
        RC_Global.clickButton(driver, "Search",true,true);
        RC_Global.waitElementVisible(driver, 60, "//div[contains(@ng-style,'Viewport.rowStyle')]", "Search Record",true,true);
        RC_Global.clickUsingXpath(driver, "(//div[contains(@ng-style,'Viewport.rowStyle')]//div[text()='Open'])[1]", "Select Grid Row",true,true);
		RC_Global.clickButton(driver, "Create RO",true,true);
		RC_Global.waitUntilPanelVisibility(driver,"Create RO","TV",true,true);
		RC_Global.panelAction(driver, "compress", "Create RO",false,false);
		RC_Global.panelAction(driver, "close", "Repair Order",false,true);
		RC_Global.panelAction(driver, "expand", "Create RO",false,false);
		RO_Number = RC_FleetServices.createRepairOrderPageOptions(driver,RC_Global.getDateTime(driver,"MM/dd/yyyy",0,true),"RO_Details_Hyperlink","Yes","","Search","","","",true,true);
		RC_Global.panelAction(driver, "close", "Edit RO",false,true);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.enterCustomerNumber(driver, CustomerNumber, "Customer", "",false);
		RC_Global.validateSearchFilterAction(driver, "RO Number", RO_Number, "Maintenance",false,true);
		RC_Global.clickLink(driver, RO_Number,true,true);
		RC_FleetServices.createOrEditRepairOrderPageInputsValidation(driver,false);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}

}
