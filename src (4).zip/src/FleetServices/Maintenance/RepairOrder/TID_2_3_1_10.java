package FleetServices.Maintenance.RepairOrder;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;
public class TID_2_3_1_10 {
	public void MaintenanceRO_AddROLineItems(WebDriver driver, BFrameworkQueryObjects queryObjects)throws Exception
	{
		String menu = "Fleet Services";
		String firstSubMenu = "Maintenance";
		String secondSubMenu = "Repair Order";
		String CustomerNumber = "LS007656";
		String VendorName = "Express Oil Change - Tire Engineers";
		String VendorStoreNumber = "12345";
		String errorMsg = "Minimum of 1 search criteria is required. Please specify data in at least one field and click 'Search'.";
		String RO_Number = "";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.enterCustomerNumber(driver, CustomerNumber, "Customer", "",true);
		RC_Global.selectDropdownOption(driver, "RO Status", "Open", true,true);
		RC_Global.clickButton(driver, "Search",true,true);
		RC_Global.waitElementVisible(driver, 30, "(//div[@ng-style='colContainer.getViewportStyle()'])[1]//div[@role='row']", "Search Result Grid",true,true);
    	Thread.sleep(2000);
		RC_Global.clickUsingXpath(driver, "//div[@role='rowgroup'][2]//div[div[@role='row']][1]","Select Grid Row",true,true);
		RC_Global.clickButton(driver, "Create RO",true,true);
		RO_Number=RC_FleetServices.createRepairOrderPageOptions(driver,RC_Global.getDateTime(driver, "MM/dd/yyyy",0,true),"RO_Details_Hyperlink","","AddAndEdit","Search",VendorName,VendorStoreNumber,"",true,true);
		RC_Global.clickLink(driver, "RO Line Items",true,true);
		RC_Global.clickButton(driver, "Remove",true,true);
		
		RC_Global.clickButton(driver, "Add Line Items",true,true);
		RC_Global.validateSpecifiedSearchFilters(driver, "Service Code;Repair Group;Parts Cost;Labor Cost;Total Line Item;Requested Amount;Status;Billing Type;Parts Quantity;Labor Hours;Approved Amount;Type;Comments",false);
		RC_Global.clickButton(driver, "Cancel",false,false);

		RC_Global.panelAction(driver, "close", "Edit RO",true,true);
		RC_Global.panelAction(driver, "expand", "Repair Order",true,false);
		RC_Global.clickButton(driver, "Reset",false,false);
		RC_Global.validateSearchFilterAction(driver, "RO Number", RO_Number,"Maintenance",true,true);
		
		RC_Global.clickLink(driver, RO_Number,true,true);
		RC_FleetServices.createOrEditRepairOrderPageInputsValidation(driver,true);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}
}
