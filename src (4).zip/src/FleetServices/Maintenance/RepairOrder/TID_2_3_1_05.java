package FleetServices.Maintenance.RepairOrder;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;

public class TID_2_3_1_05 {
	
	public static void CreateRepairOrderExceptionErrorForTheVehicle_UIChanges(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception {
		
		String errorMsg1 = "Minimum of 1 search criteria is required. Please specify data in at least one field and click 'Search'."; 
		String errorMsg2 = "Please fix the error fields in red below.";
		
		RC_Global.login(driver); 
		RC_Global.navigateTo(driver, "Fleet Services","Maintenance", "Repair Order"); 
		RC_Global.clickButton(driver, "Search",true,true);
		RC_Global.verifyDisplayedMessage(driver,errorMsg1,true);
		RC_Global.enterCustomerNumber(driver, "LS007656", "", "", true);
		RC_Global.selectDropdownOption(driver, "RO Status", "Open",true,true);
		RC_Global.clickButton(driver, "Search",true,true);
		RC_Global.verifyFieldAsHyperLink(driver, "RO Number",true);
		RC_Global.verifyFieldAsHyperLink(driver, "Unit Number",true);
		RC_Global.verifyFieldAsHyperLink(driver, "CVN",true);
		RC_Global.clickUsingXpath(driver, "//div[@role='rowgroup'][2]//div[div[@role='row']][1]","Select Record",true,true);
		RC_Global.clickButton(driver, "Create RO",true,true);
		RC_Global.waitUntilPanelVisibility(driver, "Create RO", "TV", true,true);
		RC_Global.clickUsingXpath(driver, "//button[text()='Collapse All']/following-sibling::div/button","Collapse All button",true,true);
		RC_Global.createNode(driver, "Validate Error Message --> Please fix the error fields in red below.");
		RC_Global.verifyDisplayedMessage(driver, errorMsg2,true);
		RC_FleetServices.verifyEntryOfRequiredFieldInForm(driver,true);
		RC_FleetServices.createRepairOrderPageOptions(driver,RC_Global.getDateTime(driver,"MM/dd/yyyy",1,true),"","","","Search","","","",true,true);
		RC_Global.panelAction(driver, "close", "Edit RO",true,true);
		RC_Global.panelAction(driver, "close", "Repair Order",true,true);

		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}
}
