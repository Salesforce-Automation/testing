package FleetServices.Maintenance.RepairOrder;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;
public class TID_2_3_1_11 {
	
	public void MaintenanceRO_CreateVendorToLocateTheVendorForRepairOrder(WebDriver driver, BFrameworkQueryObjects queryObjects)throws Exception
	{
		String menu = "Fleet Services";
		String firstSubMenu = "Maintenance";
		String secondSubMenu = "Repair Order";
		String CustomerNumber = "LS007656";//As per test case - 151208
		String VendorName = "Express Oil Change - Tire Engineers";
		String VendorStoreNumber = "12345";
		String RoStatus = queryObjects.getTestData("RoStatus");
		String errorMsg = "Minimum of 1 search criteria is required. Please specify data in at least one field and click 'Search'.";
		String[] CustNumb_CustName = {"",""};
		String CreatedRo = "";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.buttonStatusValidation(driver, "Search", "Enable",false);
		RC_Global.buttonStatusValidation(driver, "Reset", "Enable",false);
		RC_Global.buttonStatusValidation(driver, " Create RO ", "Disable",false);
		RC_Global.clickButton(driver, "Search",true,true);
		RC_Global.verifyDisplayedMessage(driver, errorMsg,false);
		RC_Global.enterCustomerNumber(driver, CustomerNumber, "Customer", "",true);
		RC_Global.selectDropdownOption(driver, "RO Status", "Open",true,true);
		RC_Global.clickButton(driver, "Search",true,true);
		RC_Global.waitElementVisible(driver, 30, "(//div[@ng-style='colContainer.getViewportStyle()'])[1]//div[@role='row']", "Search Result Grid",true,true);
    	Thread.sleep(2000);
		RC_Global.clickUsingXpath(driver, "//div[@role='rowgroup'][2]//div[div[@role='row']][1]","Select Grid Row",true,true);
		RC_Global.clickButton(driver, "Create RO",true,true);
		CreatedRo=RC_FleetServices.createRepairOrderPageOptions(driver,RC_Global.getDateTime(driver,"MM/dd/yyyy",0,true),"","","","Create",VendorName,VendorStoreNumber,"",true,true);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}
}
