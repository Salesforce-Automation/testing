package FleetServices.Maintenance.RepairOrder;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;


public class TID_2_3_1_01 {
	
public void MaintenanceROCreateRepairOrderForTheVehicle(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{

		String menu = "Fleet Services";
		String firstSubMenu = "Maintenance";
		String secondSubMenu = "Repair Order";		
		String CustomerNumber = "LS007656"; //String CustomerNumber = "151208";
		String ColumnNmes ="RO Number;Receivable IDs;Service Date;Unit number;CVN;VIN;RO Odometer Reading;Year;Make;Model;Plate Number;"
				+ "Vendor Name;Vendor Store Number;RO Status;RO Created By";
		String RO_Number = null;
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
			
		RC_Global.enterCustomerNumber(driver, CustomerNumber, "Customer", "", true);		
		RC_Global.selectDropdownOption(driver, "RO Status", "Pending Invoice",true,true);		
		RC_Global.clickButton(driver, "Search",true,true);	
		RC_Global.waitElementVisible(driver, 30, "(//div[@ng-style='colContainer.getViewportStyle()'])[1]//div[@role='row']", "Search Result Grid",true,true);
    	Thread.sleep(2000);
        
		RC_FleetServices.selectRecordOrValueFromGrid(driver, "Pending Invoice",true);		
		RC_Global.clickButton(driver, "Create RO",true,true);
		RO_Number = RC_FleetServices.createRepairOrderPageOptions(driver,RC_Global.getDateTime(driver,"MM/dd/yyyy",0,false),"","","","Search","","","",true, true);
		RC_Global.panelAction(driver, "close", "Edit RO",false,true);
		RC_Global.panelAction(driver, "close", "Repair Order",false,true);
		
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.enterCustomerNumber(driver, CustomerNumber, "Customer", "", true);
		RC_Global.validateSearchFilterAction(driver, "RO Number",  RO_Number,"Maintenance",true,true);
		
		RC_Global.clickButton(driver, "Search",true,true);
		RC_Global.waitElementVisible(driver, 30, "(//div[@ng-style='colContainer.getViewportStyle()'])[1]//div[@role='row']", "Search Result Grid",true,true);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}
}
