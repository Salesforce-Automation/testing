package FleetServices.Maintenance.RepairOrder;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;

public class TID_2_3_1_13 {
	public void MaintenanceRO_ValidateTheVehicle_DriverInformationAndCreateROSections(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{

		String UnitNumber = "";
		String VIN = "";
		String LastOdometer = "";
		String Driver = "";
		String Sections = "Generic RO Details;Vendor Details;RO Details;Tread Depth;Service Advisor Details;ODOMETER READINGS;RO Line Items;User Information";
		
		WebDriverWait wait = new WebDriverWait(driver,60);
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,"Fleet Services","Maintenance","Repair Order");
		RC_Global.enterCustomerNumber(driver, "LS010143", "", "",true);
		RC_Global.clickButton(driver, "Search",true,true);
		RC_Global.waitElementVisible(driver, 30, "(//div[@ng-style='colContainer.getViewportStyle()'])[1]//div[@role='row']", "MRO Search Result",true,true);
		Thread.sleep(2000);
		RC_FleetServices.selectRecordOrValueFromGrid(driver, "Pending Invoice",true);
		RC_Global.clickButton(driver, "Create RO",true,true);
		RC_Global.waitUntilPanelVisibility(driver, "Create RO", "TV",true,true);
		UnitNumber = driver.findElement(By.xpath("(//button[contains(@ng-click,'unitNumberSelected')])[1]")).getText();
		VIN = driver.findElement(By.xpath("//button[contains(@ng-click,'openAcquisition')]")).getText();
		LastOdometer = driver.findElement(By.xpath("//button[contains(@ng-disabled,'LastOdometer')]")).getText();
		Driver = driver.findElement(By.xpath("//button[contains(@ng-click,'driverName')]")).getText();
		
		RC_Global.verifyScreenComponents(driver,"lable","Unit Number",false);
		RC_Global.verifyScreenComponents(driver,"lable","CVN",false);
		RC_Global.verifyScreenComponents(driver,"lable","Replacement Unit",false);
		RC_Global.verifyScreenComponents(driver,"lable","Agreement Type",false);
		RC_Global.verifyScreenComponents(driver,"lable","Customer",false);
		RC_Global.verifyScreenComponents(driver,"lable","Fleet",false);
		RC_Global.verifyScreenComponents(driver,"lable","Account",false);
		RC_Global.verifyScreenComponents(driver,"lable","Sub Account",false);
		RC_Global.verifyScreenComponents(driver,"lable","VIN",false);
		RC_Global.verifyScreenComponents(driver,"lable","Plate/State",false);
		RC_Global.verifyScreenComponents(driver,"lable","Vehicle Description",false);
		RC_Global.verifyScreenComponents(driver,"lable","Trim Level",false);
		RC_Global.verifyScreenComponents(driver,"lable","Engine Size",false);
		RC_Global.verifyScreenComponents(driver,"lable","Fuel Type",false);
		RC_Global.verifyScreenComponents(driver,"lable","Key Code",false);
		RC_Global.verifyScreenComponents(driver,"lable","Last Odometer",false);
		RC_Global.verifyScreenComponents(driver,"lable","Last Odometer Date",false);
		RC_Global.verifyScreenComponents(driver,"lable","Vehicle Status",false);
		RC_Global.verifyScreenComponents(driver,"lable","Driver/Pool",false);
		RC_Global.verifyScreenComponents(driver,"lable","Employee ID",false);
		RC_Global.verifyScreenComponents(driver,"lable","Cell Phone",false);
		RC_Global.verifyScreenComponents(driver,"lable","Work Phone",false);
		RC_Global.verifyScreenComponents(driver,"lable","Home Phone",false);
		RC_Global.verifyScreenComponents(driver,"lable","Email",true);
		RC_Global.verifyScreenComponents(driver,"lable","Address1",true);
		RC_Global.verifyScreenComponents(driver,"lable","Address2",true);
		RC_Global.verifyScreenComponents(driver,"lable","City",true);
		RC_Global.verifyScreenComponents(driver,"lable","State",true);
		RC_Global.verifyScreenComponents(driver,"lable","Zip",true);
		RC_Global.verifyScreenComponents(driver,"lable","County",true);
		RC_Global.verifyScreenComponents(driver,"lable","Country",true);
		RC_Global.clickUsingXpath(driver, "//button[(text()='Collapse All')and(@ng-disabled='!vm.allowCollapseExpand()')]","Collapse All",true,true);
		RC_Global.verifyAsHyperlinkByLinkName(driver, Sections,true);
		RC_Global.clickUsingXpath(driver, "//button[(text()='Expand All')and(@ng-disabled='!vm.allowCollapseExpand()')]","Expand All",true,true);
		RC_FleetServices.verifyEntryOfRequiredFieldInForm(driver,true);
		RC_Global.clickUsingXpath(driver, "//button[contains(text(),'"+UnitNumber+"')]","Unit Number",true,true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details","TV",true,true);
		RC_Global.panelAction(driver,"close","Vehicle Details",false,true);
		RC_Global.clickUsingXpath(driver,"//button[contains(text(),'"+VIN+"')]","VIN",true,true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details - Acquisition","TV",true,true);
		RC_Global.panelAction(driver,"close","Vehicle Details - Acquisition",false,true);
		RC_Global.clickUsingXpath(driver,"//button[contains(text(),'"+LastOdometer+"')]","Last Odometer",true,true);
		RC_Global.waitUntilPanelVisibility(driver,"Vehicle Details - Odometer","TV",true,true);
		RC_Global.panelAction(driver,"close","Vehicle Details - Odometer",false,true);
		RC_Global.clickUsingXpath(driver,"//button[contains(text(),'"+Driver+"')]","Driver",true,true);
		RC_Global.waitUntilPanelVisibility(driver,"Driver Details","TV",true,true);
		//RC_Global.panelAction(driver,"close","Driver Details",false);
		//RC_Global.panelAction(driver, "close", "Create RO",false);
		//RC_Global.panelAction(driver, "close", "Repair Order",false);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}
}
