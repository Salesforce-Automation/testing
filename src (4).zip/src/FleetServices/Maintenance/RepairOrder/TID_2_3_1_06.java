package FleetServices.Maintenance.RepairOrder;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_2_3_1_06 {
    public void AssignApproverForMaintenance(WebDriver driver,BFrameworkQueryObjects queryObjects)throws Exception{

		String menu="Manage";
		String frstSubMenu = "Administration";
		String scndSubMenu = "Customer Administration";
		String[] CustNumb_CustName = {"",""};
		String errorMsg = "Please ensure the lowest approval limit equals the VMT amount in leasewave";
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, menu, frstSubMenu, scndSubMenu);
		RC_Global.enterCustomerNumber(driver, "LS010143", "", "", true);
		RC_Global.waitElementVisible(driver, 30, "//a[text()='Customer Summary']", "Customer Summary",true,true);
		driver.findElement(By.xpath("//a[text()='Maintenance']")).click();
		RC_Global.buttonStatusValidation(driver, " Yes ", "Enable",false);//Toggle button enabled -> Toggle option "Yes" is chosen		
		WebElement Element = driver.findElement(By.xpath("//legend[text()='Maintenance Approval Limit']"));
		executor.executeScript("arguments[0].scrollIntoView();", Element);
		executor.executeScript("document.body.style.zoom = '30%';");
		Thread.sleep(2000);
		executor.executeScript("document.body.style.zoom = '100%';");
		RC_Global.createNode(driver, "Validating Error Message - Please ensure the lowest approval limit equals the VMT amount in leasewave");
		RC_Global.verifyDisplayedMessage(driver, errorMsg,true );
		RC_Global.createNode(driver, "Assigning Approval for Limit");
		RC_Global.clickButton(driver, "Remove",true,true);
		RC_Global.clickButton(driver, "Add",true,true);
		RC_Global.waitUntilPanelVisibility(driver, "Assign Approver", "TV", true,true);
		RC_Global.clickButton(driver, "Search",true,true);
		RC_Global.waitElementVisible(driver, 30, "(//table//tbody/tr[1])[8]", "Search Result Grid",true,true);
		RC_Global.clickUsingXpath(driver, ("(//table//tbody/tr[1])[8]"),"Search Result Grid",true,true);
		RC_Global.clickButton(driver, "Select Approver",true,true);
		RC_Global.panelAction(driver, "expand", "Customer Administration",true,true);
		WebElement element = driver.findElement(By.xpath("(//*[@id='approvalLimit'])[2]"));

		RC_Global.enterInput(driver, "500", element,true,true);
		executor.executeScript("document.body.style.zoom = '80%';");
		WebElement Element1 = driver.findElement(By.xpath("(//label[text()='Customer Name'])[6]"));
		executor.executeScript("arguments[0].scrollIntoView();", Element1);
		Thread.sleep(1000);
		executor.executeScript("document.body.style.zoom = '100%';");
		RC_Global.clickUsingXpath(driver,"//form/div[1]/div/button[contains(@class,'attribute-tab-save')]","Save Button",true,true);
		RC_Global.verifyDisplayedMessage(driver, "Maintenance Attributes Saved",true);

		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

    }
}