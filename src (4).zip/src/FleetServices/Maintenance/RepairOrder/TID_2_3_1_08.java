package FleetServices.Maintenance.RepairOrder;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.LeaseWave.RC_LW_FleetServices;
import tools.LeaseWave.RC_LW_Global;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;

public class TID_2_3_1_08 {
	public void LeasewaveIntegrationForCreateRepairOrder(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception {
	   
		String GLtemplatefromTV = null;
		String BillproductfromTV = null;
		String BillinvoicefromTV = null;
		String menu = "Fleet Services";
		String firstSubMenu = "Maintenance";
		String secondSubMenu = "Repair Order";
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		ArrayList<String> getWindows = new ArrayList<String>(driver.getWindowHandles());

		RC_Global.login(driver);
		RC_Global.navigateTo(driver, menu, firstSubMenu, secondSubMenu);
		RC_Global.validateSearchFilterAction(driver, "RO Number", "2455168", "Maintenance",true,false);
		Thread.sleep(2000);
		RC_Global.clickUsingXpath(driver, "(//a[@href='#'])[1]", "Repair Order Number",true,false);
		executor.executeScript("document.body.style.zoom = '80%'");
		RC_Global.waitElementVisible(driver, 30, "//span[text()='Edit RO']", "Edit RO",true,false);
		GLtemplatefromTV = driver.findElement(By.xpath("//select[@name='glTemplates']/option[@selected='selected']")).getText();
		BillproductfromTV = driver.findElement(By.xpath("//select[@name='billBackProducts']/option[@selected='selected']")).getText();
		BillinvoicefromTV = driver.findElement(By.xpath("//select[@name='billBackInvoiceGroups']/option[@selected='selected']")).getText();
		Thread.sleep(2000);
		executor.executeScript("document.body.style.zoom = '100%'");
		driver.switchTo().window(getWindows.get(0));
		
		RC_LW_Global.leaseWaveLogin(driver,true);
        String[] TotalViewValuesValidation = {null,null,GLtemplatefromTV,BillproductfromTV,BillinvoicefromTV};
        RC_LW_FleetServices.leaseWaveRepairOrderNumberValidation(driver,"2455168",TotalViewValuesValidation,true);
        RC_LW_Global.leaseWaveLogOut(driver,false);
        
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}
}
