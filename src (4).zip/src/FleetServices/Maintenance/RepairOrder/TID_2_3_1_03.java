package FleetServices.Maintenance.RepairOrder;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_2_3_1_03 {
	public void ValidateTheResultGridBasedOnROStatusAndAlsoValidateTheHyperlinksFromGrid(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception {
		
		String ColumnNames = "RO Number;Receivable IDs;Service Date;Unit Number;CVN;VIN;RO Odometer Reading;Year;Make;Model;Plate Number;Vendor Name;Vendor Store Number;RO Status;RO Created By";//Modified		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Fleet Services", "Maintenance", "Repair Order"); 
		RC_Global.enterCustomerNumber(driver, "LS010143", "Customer", "", false);
		RC_Global.clickButton(driver, "Search", true,true);
		RC_Global.waitElementVisible(driver, 90, "//div[div[@role='row']]", "Search Result Grid", true,true);
		Thread.sleep(2000);
//		RC_Global.verifyColumnNames(driver, ColumnNames, false);
		
		String [] expColName = ColumnNames.split(";");

		for(int i=0; i<expColName.length; i++) {
			try {
				driver.findElement(By.xpath("//cell-template//div[normalize-space(text())='"+expColName[i]+"']"));				
			}
			catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Validate Report Column Names--->Column: " + expColName[i] + "--->Was NOT Found", e.getLocalizedMessage(), e);
			}
		}
		Thread.sleep(1000);
		RC_Global.clickCellLinkVerifyPanelTitle(driver, "RO Number","Edit RO", true);
		RC_Global.panelAction(driver, "close", "Edit RO", true,true);
		RC_Global.panelAction(driver, "expand", "Repair Order", true,false);
		RC_Global.clickCellLinkVerifyPanelTitle(driver, "Unit Number", "Vehicle Details", true);
		RC_Global.panelAction(driver, "close", "Vehicle Details", true,true);
		RC_Global.panelAction(driver, "expand", "Repair Order", true,false);
		
		RC_Global.selectDropdownOption(driver, "RO Status", "Open", false,true);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.validateTheGridColumnContent(driver,"RO Status","Open","Maintenance",false);
		Thread.sleep(1000);
		RC_Global.clickButton(driver, "Reset", true,false);

		RC_Global.selectDropdownOption(driver, "RO Status", "Pending Customer Approval", false,true);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.validateTheGridColumnContent(driver,"RO Status","Pending Customer Approval","Maintenance", false);
		Thread.sleep(2000);
		RC_Global.clickButton(driver, "Reset", false,false);

		RC_Global.selectDropdownOption(driver, "RO Status", "Pending Invoice", false,true);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.validateTheGridColumnContent(driver,"RO Status","Pending Invoice","Maintenance",false);
		Thread.sleep(2000);
		RC_Global.clickButton(driver, "Reset", false,false);

		RC_Global.selectDropdownOption(driver, "RO Status", "Invoice Not Matched", false,true);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.validateTheGridColumnContent(driver,"RO Status","Invoice Not Matched","Maintenance", false);
		Thread.sleep(2000);
		RC_Global.clickButton(driver, "Reset", false,false);

		RC_Global.selectDropdownOption(driver, "RO Status", "Disputed", false,true);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.validateTheGridColumnContent(driver,"RO Status","Disputed","Maintenance",false);
		Thread.sleep(2000);
		RC_Global.clickButton(driver, "Reset", false,false);

		RC_Global.selectDropdownOption(driver, "RO Status", "Closed", false,true);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.validateTheGridColumnContent(driver,"RO Status","Closed","Maintenance",false);
		Thread.sleep(2000);
		RC_Global.clickButton(driver, "Reset", false,false);

		RC_Global.selectDropdownOption(driver, "RO Status", "Declined", false,true);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.validateTheGridColumnContent(driver,"RO Status","Declined","Maintenance",false);
		Thread.sleep(2000);
		RC_Global.clickButton(driver, "Reset", false,false);

		RC_Global.selectDropdownOption(driver, "RO Status", "Deleted", false,true);
		RC_Global.clickButton(driver, "Search", false,true);
		RC_Global.validateTheGridColumnContent(driver,"RO Status","Deleted","Maintenance",false);
		Thread.sleep(2000);

		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}
}
