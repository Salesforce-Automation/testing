package FleetServices.Maintenance.RepairOrder;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.LeaseWave.RC_LW_FleetServices;
import tools.LeaseWave.RC_LW_Global;

public class TID_2_3_1_07 {
public void AddProfileInLeasewaveForPOUser(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
	  
	    RC_LW_Global.leaseWaveLogin(driver,true);
	    RC_LW_FleetServices.createPoProfileInLeaseWave(driver,true);
	    RC_LW_Global.leaseWaveLogOut(driver,false);

		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
   
	}	
}
