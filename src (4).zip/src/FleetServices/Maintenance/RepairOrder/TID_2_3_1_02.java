package FleetServices.Maintenance.RepairOrder;

import java.util.ArrayList;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.LeaseWave.RC_LW_FleetServices;
import tools.LeaseWave.RC_LW_Global;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;

public class TID_2_3_1_02 {
public void MaintenanceRO_VendorLocate_VendorSearchForRepairOrder(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{

		String menu = "Fleet Services";
		String firstSubMenu = "Maintenance";
		String secondSubMenu = "Repair Order";
		String errorMsg = "Minimum of 1 search criteria is required. Please specify data in at least one field and click 'Search'.";
		String CustomerNumber = "LS007656";//As per test case - 151208
		String ColumnNmes ="RO Number;Receivable IDs;Service Date;Unit number;CVN;VIN;RO Odometer Reading;Year;Make;Model;Plate Number;Vendor Name;Vendor Store Number;RO Status;RO Created By";
		String RO_Number;
		String HyperlinkFields ="RO Information;Service Programs;Maintenance Details;MAINTENANCE RO HISTORY;Generic RO Details;Vendor Details;RO Details;Tread Depth;Service Advisor Details;ODOMETER READINGS;RO Line Items;User Information";
		ArrayList<String> getWindows = new ArrayList<String>(driver.getWindowHandles());
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.enterCustomerNumber(driver, CustomerNumber, "Customer", "", true);
		RC_Global.selectDropdownOption(driver, "RO Status", "Pending Invoice", true,true);
		RC_Global.clickButton(driver, "Search", true,true);
		RC_Global.waitElementVisible(driver, 30, "(//div[@ng-style='colContainer.getViewportStyle()'])[1]//div[@role='row']", "Search Result Grid", true,true);
    	RC_Global.verifyFieldAsHyperLink(driver, "RO Number", true);
        RC_Global.verifyFieldAsHyperLink(driver, "Unit Number", true);
        RC_Global.verifyFieldAsHyperLink(driver, "CVN", true);
        Thread.sleep(2000);
		RC_FleetServices.selectRecordOrValueFromGrid(driver, "Pending Invoice", true);
		RC_Global.clickButton(driver, "Create RO", true,true);
		RC_Global.waitUntilPanelVisibility(driver,"Create RO","TV", true,true);
		RC_Global.panelAction(driver, "compress", "Create RO", true,false);
		RC_Global.panelAction(driver, "close", "Repair Order", true,true);
		RC_Global.panelAction(driver, "expand", "Create RO", true,false);
		RC_Global.validateSpecifiedSearchFilters(driver,HyperlinkFields, true);
		RC_Global.buttonStatusValidation(driver, "Collapse All", "Enable", true);
		RC_Global.buttonStatusValidation(driver, "Save", "Enable",false);
		RO_Number = RC_FleetServices.createRepairOrderPageOptions(driver, RC_Global.getDateTime(driver,"MM/dd/yyyy",0,true), "Vendor Details", "Yes", "", "Search", "", "","Yes",true, true);
		RC_Global.panelAction(driver, "close", "Edit RO", true,true);
		driver.switchTo().window(getWindows.get(0));
		
		RC_LW_Global.leaseWaveLogin(driver,true);
		String[] TotalViewValuesValidation = {RC_FleetServices.VendorNameFromTV,RC_FleetServices.RoCreatedBy,null,null,null};
		RC_LW_FleetServices.leaseWaveRepairOrderNumberValidation(driver,RO_Number,TotalViewValuesValidation,true);
		RC_LW_Global.leaseWaveLogOut(driver,false);
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}
}
