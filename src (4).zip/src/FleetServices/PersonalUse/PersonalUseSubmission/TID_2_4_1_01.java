package FleetServices.PersonalUse.PersonalUseSubmission;
import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import MF.Source.Cred;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;
public class TID_2_4_1_01 {
	public void PersonalUse_FunctionalityAsEnrolledUnAssignedOrAssignedDriver(WebDriver driver, BFrameworkQueryObjects queryObjects)throws Exception
	{
		String menu = "Fleet Services";
		String firstSubMenu = "Personal Use";
		String secondSubMenu = "Personal Use Submission";
		String odoMeterStartingValue = "2000";
		String odoMeterEndingValue = "4000";
		String personalUseMiles = "10";
		String[] startEndDate = new String[2];
		String submissionPeriodStartDate = "";
		String submissionPeriodEndDate = "";
		
		RC_Global.externalUserLogin(driver,"appleuser","Yes");
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.waitUntilPanelVisibility(driver,"Personal Use Submission", "TV", true, false);
		RC_Global.clickButton(driver, "Submit Mileage",true, true);
		RC_Global.clickButton(driver,"Add Vehicle",true, true);
		RC_Global.waitElementVisible(driver, 30, "//h3[text()='Add Vehicle']", "Add Vehicle screen",true, true);
		RC_Global.clickButton(driver, "Search",true, true);
		RC_Global.waitElementVisible(driver, 30, "(//tbody//tr[@ng-click='vehicleRowSelected(data)'])[1]", "First row of the table",true, true);
		RC_Global.clickUsingXpath(driver,"(//tbody//tr[@ng-click='vehicleRowSelected(data)'])[1]","Select first row of the table",true, true);
		
		startEndDate = RC_FleetServices.personalUseStartAndEndDate(driver,true);
		submissionPeriodStartDate = startEndDate[0];
		submissionPeriodEndDate = startEndDate[1];
		RC_FleetServices.enterSubmitMileageFormInputs(driver,submissionPeriodStartDate,submissionPeriodEndDate,odoMeterStartingValue,odoMeterEndingValue,personalUseMiles,true);
		RC_Global.clickButton(driver, "Save",true, true);
		Thread.sleep(3000);
//		RC_Global.verifyDisplayedMessage(driver, "Save Successful");
//		RC_Global.SuccessMessage(driver,"Save Successful");
		if(RC_Global.waitElementVisible(driver, 10, "//h4[contains(., 'Save Successful')]", "Green-Msg-->Save Successful",true, true)==false)
			RC_Global.endTestRun(driver);
		RC_Global.scrollById(driver,"//div//legend[text()='Submission History']");		
		RC_Global.logout(driver,false);
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,"Reporting","Personal Use Reports","Submitted Mileage");
		RC_Global.waitUntilPanelVisibility(driver,"Submitted Mileage", "TV", true, true);
		Thread.sleep(2000);
		RC_Global.waitElementVisible(driver, 30, "//input[@id='dateTimeField_Submitted From Date']", "Submitted From Date input box",true, false);
		WebElement element = RC_Global.accessInputBoxViaLabel(driver,"Submitted To Date:",true);
		RC_Global.enterInput(driver,submissionPeriodEndDate, element,true, true);
		RC_Global.enterCustomerNumber(driver, "LS008737", "Customer", "", true);
		RC_Global.clickButton(driver, "Generate Report",true, true);
		Thread.sleep(2000);//To be Completed once the bug is fixed
		
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}

}
