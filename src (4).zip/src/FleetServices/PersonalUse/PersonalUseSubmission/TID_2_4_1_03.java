package FleetServices.PersonalUse.PersonalUseSubmission;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_2_4_1_03 {
	public void ValidateThePersonalUseSubmissionSearchFilters(WebDriver driver,BFrameworkQueryObjects queryobjects) throws Exception{
		
	String custNum = "151141";	
	String drivername = "";
	String EmployeeID = "";
	String UnitNumber = "";
	String CustomerVehicleNumber = "";
	String VIN = "";
	String EmployeeName = "";
	String EmployeeAssignment = "";
	String[] Name;
	String searchFilters = "Customer Number;First Name;Last Name;Employee ID;Unit Number;Customer Vehicle Number;VIN or Last 8;Residential City;Residential State;Residential Zip;Enrolled in Personal Use;Client Data 1-7;Client Data Value;Exclude Client Data 1-7;Exclude Client Data Value;Employee Assignment";	
	
	RC_Global.login(driver);
	RC_Global.navigateTo(driver, "Fleet Services", "Personal Use", "Personal Use Submission");
	RC_Global.validateSpecifiedSearchFilters(driver, searchFilters,true);
	RC_Global.enterCustomerNumber(driver, custNum, "", "", false);
	RC_Global.clickButton(driver, "Search",true,true);
	
	RC_Global.waitElementVisible(driver, 30, "(//tbody/tr)[1]", "Search Record",true,true);

		List<WebElement> Getgridrowcnt= driver.findElements(By.xpath("//table//tbody//tr"));  
		int rowcnt=Getgridrowcnt.size();
		for(int i=1; i<rowcnt;i++) {
			WebElement sub = driver.findElement(By.xpath("//tr["+i+"]//td[4]"));
			WebElement EmpID = driver.findElement(By.xpath("//tr["+i+"]//td[5]"));
			WebElement EmpAss = driver.findElement(By.xpath("//tr["+i+"]//td[6]"));
			String CVN = sub.getText();
			String Emp = EmpID.getText();
		//	String EmpAssgn = EmpAss.getText();
			if(!(CVN.isEmpty() || Emp.isEmpty())) {
				WebElement driverclmn = driver.findElement(By.xpath("//tbody//tr["+i+"]//td[3]"));
				WebElement clmn = driver.findElement(By.xpath("//tbody//tr["+i+"]"));
				drivername = driverclmn.getText();
				if(!(drivername.equalsIgnoreCase("Unassigned") || drivername.contains("Pool")||drivername.contains("Unkown")) ) {
				Thread.sleep(2000);
				  
				EmployeeID = driver.findElement(By.xpath("//tbody//tr["+i+"]/td[5][contains(@ng-if,'EmployeeId')]")).getText();
				UnitNumber = driver.findElement(By.xpath("(//tbody//tr["+i+"]/td[@title='Open Vehicle Details'])[1]")).getText();
				CustomerVehicleNumber = driver.findElement(By.xpath("//tbody//tr["+i+"]/td[8][@title='Open Vehicle Details']")).getText();
				VIN = driver.findElement(By.xpath("//tbody//tr["+i+"]/td[9][@ng-if='personalUseUserSearch']")).getText();
				EmployeeName = driver.findElement(By.xpath("//tbody//tr["+i+"]/td[3][contains(@ng-if,'FullName')]")).getText();
				
				EmployeeAssignment = driver.findElement(By.xpath("//tbody//tr["+i+"]/td[contains(@ng-if,'EmployeeAssignment')]")).getText();
				
				queryobjects.logStatus(driver, Status.INFO, "Employee ID data---->", EmployeeID, null);    
		        queryobjects.logStatus(driver, Status.INFO, "Unit Number data---->", UnitNumber, null);
		        queryobjects.logStatus(driver, Status.INFO, "CustomerVehicleNumber data---->", CustomerVehicleNumber, null);
		        queryobjects.logStatus(driver, Status.INFO, "VIN Number data---->", VIN, null);
		        queryobjects.logStatus(driver, Status.INFO, "Employee Name data---->", EmployeeName, null);
		        queryobjects.logStatus(driver, Status.INFO, "Employee Assignment data---->", EmployeeAssignment, null);
		       
				} break;
			}}

	RC_Global.createNode(driver, "Personal use submission -- Employee ID Search Filter Functionality Validation");
	RC_Global.validateSearchFilterAction(driver, "Employee ID", EmployeeID, "Personal Use Submission", true,true);
	RC_Global.waitElementVisible(driver, 30, "(//span[text()='Personal Use Submission'])[2]", "Personal use submission header",true,true);
	RC_Global.panelAction(driver, "close", "Personal Use Submission",true,true);
	RC_Global.navigateTo(driver, "Fleet Services", "Personal Use", "Personal Use Submission");
	
	RC_Global.createNode(driver, "Personal use submission -- Unit Number Search Filter Functionality Validation");
	RC_Global.enterCustomerNumber(driver, custNum, "", "", false); 
	RC_Global.validateSearchFilterAction(driver, "Unit Number", UnitNumber, "Personal Use Submission",true,true);
	RC_Global.waitElementVisible(driver, 10, "(//span[text()='Personal Use Submission'])[2]", "Personal use submission header",true,true);
	RC_Global.panelAction(driver, "close", "Personal Use Submission",true,true);
	RC_Global.navigateTo(driver, "Fleet Services", "Personal Use", "Personal Use Submission");
	
	RC_Global.createNode(driver, "Personal use submission -- Customer Vehicle Number Search Filter Functionality Validation");
	RC_Global.enterCustomerNumber(driver, custNum, "", "", false);
	RC_Global.validateSearchFilterAction(driver, "Customer Vehicle Number", CustomerVehicleNumber, "Personal Use Submission",true,true);
	RC_Global.waitElementVisible(driver, 10, "(//span[text()='Personal Use Submission'])[2]", "Personal use submission header",true,true);
	RC_Global.panelAction(driver, "close", "Personal Use Submission",true,true);
	RC_Global.navigateTo(driver, "Fleet Services", "Personal Use", "Personal Use Submission");
	
	RC_Global.createNode(driver, "Personal use submission -- VIN Search Filter Functionality Validation");
	RC_Global.enterCustomerNumber(driver, custNum, "", "", false);
	RC_Global.validateSearchFilterAction(driver, "Vin or Last 8", VIN, "Personal Use Submission",true,true);
	RC_Global.waitElementVisible(driver, 10, "(//span[text()='Personal Use Submission'])[2]", "Personal use submission header",true,true);
	RC_Global.panelAction(driver, "close", "Personal Use Submission",true,true);
	RC_Global.navigateTo(driver, "Fleet Services", "Personal Use", "Personal Use Submission");
	
	RC_Global.createNode(driver, "Personal use submission -- VIN Last 8 digit Search Filter Functionality Validation");
	RC_Global.enterCustomerNumber(driver, custNum, "", "", false);
	String VinLst8dig = VIN.substring(VIN.length()-8);
	RC_Global.validateSearchFilterAction(driver, "Vin or Last 8", VinLst8dig, "Personal Use Submission",true,true);
	RC_Global.waitElementVisible(driver, 10, "(//span[text()='Personal Use Submission'])[2]", "Personal use submission header",true,true);
	RC_Global.panelAction(driver, "close", "Personal Use Submission",true,true);
	RC_Global.navigateTo(driver, "Fleet Services", "Personal Use", "Personal Use Submission");
	
	RC_Global.createNode(driver, "Personal use submission -- First Name Search Filter Functionality Validation");
	RC_Global.enterCustomerNumber(driver, custNum, "", "", false);
	Name = EmployeeName.split(" "); 
	RC_Global.validateSearchFilterAction(driver, "First Name", Name[0], "Personal Use Submission",true,true);
	RC_Global.waitElementVisible(driver, 10, "(//span[text()='Personal Use Submission'])[2]", "Personal use submission header",true,true);
	RC_Global.panelAction(driver, "close", "Personal Use Submission",true,true);
	RC_Global.navigateTo(driver, "Fleet Services", "Personal Use", "Personal Use Submission");
	
	RC_Global.createNode(driver, "Personal use submission -- Last Name Search Filter Functionality Validation");
	RC_Global.enterCustomerNumber(driver, custNum, "", "", false);
	RC_Global.validateSearchFilterAction(driver, "Last Name", Name[1], "Personal Use Submission",true,true);
	RC_Global.waitElementVisible(driver, 10, "(//span[text()='Personal Use Submission'])[2]", "Personal use submission header",true,true);
	RC_Global.panelAction(driver, "close", "Personal Use Submission",true,true);
	RC_Global.navigateTo(driver, "Fleet Services", "Personal Use", "Personal Use Submission");
	
	RC_Global.createNode(driver, "Personal use submission -- Employee Assignment Search Filter Functionality Validation");
	RC_Global.enterCustomerNumber(driver, custNum, "", "", false);
//	RC_Global.validateSearchFilterAction(driver, "Employee Assignment", EmployeeAssignment, "Personal Use Submission",true,true);
	driver.findElement(By.xpath("(//input[@placeholder='Employee Assignment'])[2]")).sendKeys(EmployeeAssignment);
	Thread.sleep(2000);
	RC_Global.clickButton(driver, "Search", true,false);
	Thread.sleep(2000);
	
	RC_Global.waitElementVisible(driver, 10, "(//span[text()='Personal Use Submission'])[2]", "Personal use submission header",true,true);
	RC_Global.panelAction(driver, "close", "Personal Use Submission",true,true);

	 queryobjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
