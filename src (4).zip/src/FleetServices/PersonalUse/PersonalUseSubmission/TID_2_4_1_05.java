package FleetServices.PersonalUse.PersonalUseSubmission;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;

public class TID_2_4_1_05 {
	public void PersonalUseMileageSubmissionByDriverEnrolledForPersonalUse(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception {
		String ColumnNames = "Customer #;Customer Name;Employee Name;Enrolled In Personal Use;Employee ID;Existing Active Unit Assignments;Employee Assignment;Unit Number;CVN;VIN;Residential Address;Residential City;Residential State;Residential Zip;Fleet #;Fleet Name;Account #;Account Name;Sub-Account #;Sub-Account Name";
		String startDate=null;
		String endDate=null;
		int startOdometer = 7600;
		int endOdometer = 8300;
		int totalMiles = endOdometer - startOdometer;
		String totalMilesReading = String.valueOf(totalMiles);
		
		String startOdometerReading = String.valueOf(startOdometer);
		String endOdometerreading = String.valueOf(endOdometer);
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Fleet Services", "Personal Use", "Personal Use Submission");
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		RC_Global.clickButton(driver, "Search", true, true);
		RC_Global.verifyColumnNames(driver, ColumnNames, false);
		
		RC_Global.clickUsingXpath(driver, "//span[text()='Enrolled In Personal Use']", "Sort Enrolled In Personal Use column", true, false);//Clicking to sort in Ascending Order
		RC_Global.clickLink(driver, "Enrolled", true, true);//Click on Enrolled hyperlink
		RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='Personal Use Submission']])[1]", true, false);
		RC_Global.panelAction(driver, "expand", "Personal Use Submission", false, false);
		RC_Global.clickButton(driver, "Submit Mileage", true, true);
		Thread.sleep(1000);
		RC_Global.clickButton(driver, "Add Vehicle", true, true);
		RC_Global.clickButton(driver, "Search", true, true);
		RC_Global.waitElementVisible(driver, 30, "//table/tbody/tr/td", "Table Grid Results", true, false);
		RC_Global.clickUsingXpath(driver, "(//tbody/tr[1])[1]","First Record of 'Add Vehicle' Result Grid", true, true);
		String[] startEndDate = RC_FleetServices.getPersonalUseMissingMileageStartAndEndDates(driver, true);
		startDate = startEndDate[0];
		endDate = startEndDate[1];
		
		RC_FleetServices.enterSubmitMileageFormInputs(driver,startDate,endDate,startOdometerReading,endOdometerreading,"200", true);
		
		RC_Global.clickButton(driver, "Odometer History", false, true);
		RC_Global.waitUntilPanelVisibility(driver, "Personal Use - Odometer", "TV", false, false);
		
		RC_Global.panelAction(driver, "close", "Personal Use - Odometer", false, false);
		RC_Global.panelAction(driver, "expand", "Personal Use Submission", false, false);
		
		RC_Global.clickButton(driver, "Save", true, true);
//		RC_Global.verifyDisplayedMessage(driver, "Save Successful", false);
		try {
			RC_Global.waitElementVisible(driver, 30, "//h4[text()='Save Successful']", "Save Successful", true, true);
			queryObjects.logStatus(driver, Status.PASS, "Verify Save Successful message is displayed", "Save Successful message is displayed", null);
			}
			catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify Save Successful message is displayed", "Save Successful message is not displayed", null);
			}
		
		RC_Global.clickButton(driver, "Close", true, true);
		RC_FleetServices.verifyMileageSubmission(driver,"Total Miles",totalMilesReading, false);
		
		RC_Global.panelAction(driver, "close", "Personal Use Submission", false, false);
		Thread.sleep(2000);
		
		RC_Global.navigateTo(driver, "Reporting", "Personal Use Reports", "Submitted Mileage");
		Thread.sleep(2000);
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		
		WebElement element = RC_Global.accessInputBoxViaLabel(driver,"Submitted To Date:", true);
		RC_Global.enterInput(driver,endDate, element, true, true);
		RC_Global.clickButton(driver, "Generate Report", true, true);//To be Completed once the bug is fixed
	
	}
}
