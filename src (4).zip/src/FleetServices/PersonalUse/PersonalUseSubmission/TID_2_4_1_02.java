package FleetServices.PersonalUse.PersonalUseSubmission;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;

public class TID_2_4_1_02 {
	public void PersonalUse_SetupUserAssociatedWithEmployee(WebDriver driver, BFrameworkQueryObjects queryObjects)throws Exception
	{
		String userName = "TestUser";
		String firstName = "External";
		String lastName ="User";
		String email = "vimalathithunb@merchantsfleet.com";
		String role = "Driver";
		String customerNumber = "LS008737";
		String customerName = "LS008737 - Kentucky Farm Bureau Mutual Insurance Company";
		
		String menu = "Manage";
		String firstSubMenu = "Utilities";
		String secondSubMenu = "User Setup";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
		RC_Global.clickButton(driver, "Add New User", true, true);
		RC_Global.panelAction(driver,"close","User Setup", false, false);
		RC_Global.waitUntilPanelVisibility(driver, "User Detail", "Total View", true, false);
		RC_Global.panelAction(driver,"expand","User Detail", false, false);

		RC_Global.selectDropdownOption(driver,"departments","External Customer", true, true);
		RC_Global.selectDropdownOption(driver,"roles",role, true, true);
		RC_Global.createExternalUserInUserSetup(driver, userName+RandomStringUtils.randomNumeric(3).toString(), firstName, lastName, email, true);
		
		RC_Global.enterCustomerNumber(driver, customerNumber, "Customer", "", true);
		RC_Global.waitElementVisible(driver, 30, "//span[@title='"+customerName+"']//preceding::input[@type='checkbox']", "Checkbox preceeding Customer Number in User Setup", true, true);
		RC_Global.clickUsingXpath(driver, "//span[@title='"+customerName+"']//preceding::input[@type='checkbox']", "Customer Number "+customerNumber+"selection CheckBox in User Setup", true, true);
		RC_Global.waitElementVisible(driver, 30, "//table//tbody//tr//td[contains(text(),'"+customerNumber+"')]", "Search grid record containing the value of a Customer Number", true, false);
		RC_Global.clickUsingXpath(driver, "//table//tbody//tr//td[contains(text(),'"+customerNumber+"')]", "First record of Vehicle Driver Assignment table grid", true, false);
		RC_Global.clickButton(driver, "Save", true, true);
		driver.switchTo().alert().accept();
		RC_FleetServices.verifyNotificationMessage(driver,"Save Successful","SaveUser", false);
		Thread.sleep(1000);
		
	}

}
