package FleetServices.PersonalUse.PersonalUseSubmission;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;

public class TID_2_4_1_04 {
	public void ValidateResultGridHyperlinksAndEnrolledInPersonalUseFilters(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception {
		String menu = "Fleet Services";
		String firstSubMenu = "Personal Use";
		String secondSubMenu = "Personal Use Submission";
		String ColumnNmes = "Customer #;Customer Name;Employee Name;Enrolled In Personal Use;Employee ID;Existing Active Unit Assignments;Employee Assignment;Unit Number;CVN;VIN;Residential Address;Residential City;Residential State;Residential Zip;Fleet #;Fleet Name;Account #;Account Name;Sub-Account #;Sub-Account Name";
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		
		
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, menu, firstSubMenu, secondSubMenu);
		RC_Global.enterCustomerNumber(driver, "LS008742", "Customer","",true);
		RC_Global.clickButton(driver, "Search", true, true);
		RC_Global.waitElementVisible(driver, 30, "//tbody/tr", "Search Result Grid", true, true);
		RC_Global.verifyColumnNames(driver, ColumnNmes, false);
		Thread.sleep(2000);
		RC_Global.clickCellLinkVerifyPanelTitle(driver, "Unit Number", "Vehicle Details", false);
		RC_Global.waitUntilPanelVisibility(driver, "Vehicle Details", "TV", false, false);
		RC_Global.panelAction(driver, "close", "Vehicle Details", true, false);
		RC_Global.panelAction(driver, "expand", "Personal Use Submission", false, false);
		RC_Global.clickCellLinkVerifyPanelTitle(driver, "Enrolled In Personal Use", "Personal Use Submission", false);
		RC_Global.waitUntilPanelVisibility(driver, "Personal Use Submission", "TV", true, true);
		RC_Global.panelAction(driver, "xpathclose", "(//h5[span[text()='Personal Use Submission']])[2]", true, false);
		RC_Global.panelAction(driver, "expand", "Personal Use Submission", false, false);
		RC_Global.selectDropdownOption(driver, "Enrolled in Personal Use", "Yes", false, true);
		RC_Global.clickButton(driver, "Search", false, true);
		RC_Global.waitElementVisible(driver, 30, "//tbody/tr", "Search Result Grid", true, true);
		//Validate the column test data *Enrolled
		RC_Global.validateTheGridColumnContent(driver , "Enrolled In Personal Use", "Enrolled", "Personal Use Submission", false);
		RC_Global.selectDropdownOption(driver, "Enrolled in Personal Use", "No", false, true);
		RC_Global.clickButton(driver, "Search", true, true);
		RC_Global.waitElementVisible(driver, 30, "//tbody/tr", "Search Result Grid", true, true);
		//Validate the column test data *Not - Enrolled
		RC_Global.validateTheGridColumnContent(driver , "Enrolled In Personal Use", "Not Enrolled", "Personal Use Submission", false);
		Thread.sleep(2000);
		RC_Global.panelAction(driver, "close", "Personal Use Submission", false, true);
		
		RC_Global.logout(driver, true);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
		
	}
}
