package FleetServices.PersonalUse.PersonalUseSubmission;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_FleetServices;
import tools.TotalView.RC_Global;

public class TID_2_4_1_06 {
	public void PersonalUseMileagesubmissionByExternalDriverEnrolledForPersonalUse(WebDriver driver,BFrameworkQueryObjects queryobjects) throws Exception{
		
		String startDate="";
		String endDate="";
		int startOdometer = 2500;
		int endOdometer = 3120;
		int totalMiles = endOdometer - startOdometer;
		String totalMilesReading = String.valueOf(totalMiles);
		String[] startEndDate = new String[2];
		String submissionPeriodStartDate = "";
		String submissionPeriodEndDate = "";
		String startOdometerReading = String.valueOf(startOdometer);
		String endOdometerreading = String.valueOf(endOdometer);
		
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		
		RC_Global.externalUserLogin(driver, "appleuser","Yes");
		RC_Global.navigateTo(driver, "Fleet Services", "Personal Use", "Personal Use Submission");
		RC_Global.clickButton(driver, "Submit Mileage", true, true);
		RC_Global.clickButton(driver, "Add Vehicle", true, true);
		RC_Global.clickButton(driver, "Search", true, true);
		RC_Global.clickUsingXpath(driver, "(//div/table/tbody/tr[1]/td)[2]", "First Record of 'Add Vehicle' Result Grid", true, true);
		Thread.sleep(2000);
		startEndDate = RC_FleetServices.personalUseStartAndEndDate(driver, true);
		submissionPeriodStartDate = startEndDate[0];
		submissionPeriodEndDate = startEndDate[1];
		RC_FleetServices.enterSubmitMileageFormInputs(driver,submissionPeriodStartDate,submissionPeriodEndDate,startOdometerReading,endOdometerreading,"120", true);
		RC_Global.clickButton(driver, "Save", true, true);
//		RC_Global.verifyDisplayedMessage(driver, "Save Successful", true);
		if(RC_Global.waitElementVisible(driver, 10, "//h4[contains(., 'Save Successful')]", "Green-Msg-->Save Successful",true, true)==false)
			RC_Global.endTestRun(driver);
		
		Thread.sleep(1000);
        RC_FleetServices.verifyMileageSubmission(driver,"Total Miles",totalMilesReading, false);
        
        RC_Global.panelAction(driver,"close","Personal Use Submission", true, false);
        RC_Global.navigateTo(driver,"Reporting","Personal Use Reports", "Submitted Mileage");
        WebElement element = RC_Global.accessInputBoxViaLabel(driver,"Submitted To Date:", true);
		RC_Global.enterInput(driver, RC_Global.getDateTime(driver,"MM/dd/yyyy", 0, true), element, true, true);
		
        RC_Global.clickButton(driver, "Generate Report", true, true);
    }
		
		
}
