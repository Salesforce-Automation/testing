package FleetServices.Administration.TransactionErrors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_2_1_1_01 {
	 public void Administration_ValidateSearchFilterResult(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
		 	String menu = "Fleet Services";
			String firstSubMenu = "Administration";
			String secondSubMenu = "Transaction Errors V2";
	        String ColumnNmes = "Card #;Customer #;Customer Name;Total Amount;Unit Number;Unit Assignment;Error Type;Error Detail;Days In Error;First Occurance;Fleet #;Fleet Name;Account #;Account Name;Sub-Account #;Sub-Account Name";   
    
	        RC_Global.login(driver);
	        RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
	        RC_Global.createNode(driver, "Transaction Errors V2 Screen Validation");
	        try {
	        	RC_Global.waitElementVisible(driver, 30, "//div[2]/div/table/tbody[1]/tr/td[1]", "Search Result Grid", false,false);
	        	WebElement element = driver.findElement(By.xpath("//input[contains(@placeholder,'Filter Results')]"));
		        RC_Global.enterInput(driver, "FedEx Office", element, false, false);
	        	RC_Global.waitElementVisible(driver, 30, "//div[2]/div/table/tbody[1]/tr/td[1]", "Search Result Grid", false,true);
		        RC_Global.verifyColumnNames(driver, ColumnNmes, false);
		 		        
		        element.clear();
		        Thread.sleep(1000);
		        RC_Global.enterInput(driver, "No ProductType in detail record", element, true,false);
	        	RC_Global.waitElementVisible(driver, 30, "//div[2]/div/table/tbody[1]/tr/td[1]", "Search Result Grid", true,true);
		        RC_Global.verifyColumnNames(driver, ColumnNmes, true);
	        }
	        catch (Exception e) {
	        	RC_Global.waitElementVisible(driver, 30, "//span[text()='No Results']", "No Results after search", false,false);
				queryObjects.logStatus(driver, Status.FAIL, "No Search Results are found in Transaction Errors V2","No Results", null);
	        }
	        RC_Global.panelAction(driver, "close", "Transaction Errors V2", false,true);
	        
	       queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	    }

}
