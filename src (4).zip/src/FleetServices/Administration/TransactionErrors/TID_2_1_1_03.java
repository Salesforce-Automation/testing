package FleetServices.Administration.TransactionErrors;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;

public class TID_2_1_1_03  {
    public void Administration_ValidateFuelTransactionErrorHistoryFromPriorityUnit(WebDriver driver,BFrameworkQueryObjects queryObjects)throws Exception{
        String menu = "Fleet Services";
        String firstSubMenu = "Administration";
        String secondSubMenu = "Transaction Errors V2";
        String searchFilters = "File In Process;Step;Status;Action";
        
        RC_Global.login(driver);
        RC_Global.navigateTo(driver,menu,firstSubMenu,secondSubMenu);
        RC_Global.createNode(driver, "Transaction Errors V2 Screen Functionality Validation");

        try {
        RC_Global.waitUntilPanelVisibility(driver,"Transaction Errors V2","TV", false,true);
        RC_Global.waitElementVisible(driver, 30, "//div[2]/div/table/tbody[1]/tr/td[1]", "Search Result Grid", true,false);
        RC_Global.clickUsingXpath(driver, "(//a[text()='view'])[1]","View", true,true);
        RC_Global.waitUntilPanelVisibility(driver,"Fuel Transaction Error - History","TV", false,true);
        RC_Global.panelAction(driver, "close", "Transaction Errors V2", true,false);
        RC_Global.panelAction(driver, "expand", "Fuel Transaction Error - History", true,false);
        RC_Global.validateSpecifiedSearchFilters(driver, searchFilters, true);
        RC_Global.downloadAndVerifyFileDownloaded(driver, "Export","Export To Excel Functionality", true);   
        } catch (Exception e) {
        	RC_Global.waitElementVisible(driver, 30, "//span[text()='No Results']", "No Results after search", true,false);
			queryObjects.logStatus(driver, Status.FAIL, "No Search Results are found in Transaction Errors V2","No Results", null);
        }
        RC_Global.panelAction(driver, "close", "Fuel Transaction Error - History", false,true);
        
       queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

    	}
    }
