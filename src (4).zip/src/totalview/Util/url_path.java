package totalview.Util;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class url_path {
		
	public static String QAurl="https://release-qa.merchantstotalview.com";
	public static String UATurl="https://release-uat.merchantstotalview.com/#/login";
	public static String Devurl="https://release-dev.merchantstotalview.com";
	public static String PRODURL="https://www.merchantstotalview.com/#/login";
	public static String OC5QAurl="https://www.merchantstotalview.com/#/login";
	
	//public static String OMQ="https://"+Username+":"+Password+"@sts.merchantsfleet.com/adfs/ls/wia?client-request-id=47c34997-126e-40e1-985e-fde184b6dd06&wa=wsignin1.0&wtrealm=urn%3afederation%3aMicrosoftOnline&wctx=LoginOptions%3D3%26estsredirect%3d2%26estsrequest%3drQIIAY2SP2gTUQDGc702jYFiqSJFHDJUkMq7vHf33v0JFHpNSrw0d7FJamwG5d3du-bSXC5eLm3SVQfHbhZHx44OUpwEt4LYUSoOdRK7iJOLYLI4Fz6-8YPv-33pGSRIAlrmRQHmllyieRq2GZARVQAWRRdQhkWgUdmhEDHHIVK0kJ5_ZXwsdhcuVo-e_L148e5b8pi724rjXj-XzYYBeEaFgEVOi3bjfhzGtLPns33BCYPsCcedcdwPjjueWhI14kDN1QCVsAowlSDQFOIA7GIq29ixbUU5n7pe0QdxS5xYGPkH7PdUyovoTsC68Wt-yEalXjNvyEZbh1Z7HTYDyy_XTWQWt2KruA0rNYibhWpQrm_uV-q7pNlYh1ZhG5sjo290qwdGOxxabZ1U6joxC_qwnC_FzcfV0BY3_Ypf2relNeSsdwZu8dFou2FB2tAGRheuHPPLtOeP27oYq44CPaBKigiwhyhQVQUCRqiiIoYdpJC3_JKCGZKhpAKmuC7AkiYCW1IpIFS0ZVdmEhXJKb9x9czxzE8HfRZlJiZEjLqZsMe6vpvpRaHnd9gXnvvO3xnRfit0W9Re_Q_E6zAWT2CcTXM_p2-luHl-kcsk7i1APpdKpecTi4lM4s8092ZmzPlrAXxuz93eOPl0-dy7LCVOZ7J0YNXqdtm4b8aFB6ruhKSRf2jm13ZgeUt3alV7V1X3skMtaG-tKDl0mEweJm-cJmfNml4WSrVfSe7lbOL9tav95SjNnadvilBEAI4lZyDJIZQjYvPDXOIf0&cbcxt=&username=yashodhab%40merchantsfleet.com&mkt=&lc=";
}
