package Acquisition.FactoryOrder.PriceVehicle;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.io.File;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;

import tools.TotalView.RC_Global;
import tools.TotalView.RC_Acquisition_OrderPortal;
import tools.TotalView.RC_Acquisition;

import MF.FrameworkCode.BFrameworkQueryObjects;

public class TID_1_1_3_02 {
	
	public void FactoryOrder_Validate_PriceVehicle_Display(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		String spinnerSelector = "//div[contains(@class, 'panel-loading-spinner')]/i";

		String[] vehiclePriceTableOptions = {"Base Price", "Total Options", "Additional Pricing", "Upfit Pricing", "Vehicle Subtotal",
				"Destination Charge", "Grand Total"};
		
		String[] standardEquipGroupNames = {"Dimensions", "Powertrain", "Suspension And Handling", "Body Exterior", "Convenience",
				"Seats and Trim", "Entertainment", "Lighting, Visibility and Instrumentation", "Safety", "Interior"};
		
		String[] warrantyTypeNames = {"Basic:", "Powertrain:", "Corrosion perforation:", "Roadside assistance:", "Accessories:"};		
		String vehicleType = "Acura MDX";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,"Acquisition", "Factory Order", "Price a Vehicle");
		
		RC_Global.waitElementVisible(driver, 30, "//select[@id='selectMake']", "'Make' DropDown", true, true);
		RC_Global.selectDropdownOption(driver, "selectMake", "Acura", true, true);
		Thread.sleep(500);
		RC_Global.selectDropdownOption(driver, "selectModel", "MDX", true, true);
		Thread.sleep(500);
		RC_Global.clickUsingXpath(driver, "(//input[@ng-click='trimSelected(trim)'])[1]", "Select Trim Radio Btn", true, true);
		RC_Global.clickButton(driver, "Next", true, true);
		Thread.sleep(500);
		RC_Global.waitElementNotVisible(driver, 30, spinnerSelector, "Spinner", true, true);
		RC_Global.waitElementVisible(driver, 30, "//div[@class='vehicle-default-image-container']/img", "Vehicle Image", false, true);
		RC_Global.waitElementVisible(driver, 5, "//span[contains(., '"+vehicleType+"')]", "Vehicle Make & Model", false, true);
		
		//Validate Vehicle Price Table Options
		RC_Global.createNode(driver, "Validate Vehicle Price Table Options");
		List<WebElement> vehiclePriceTable = driver.findElements(By.xpath("//table[@class='table vehicle-price-table']//tbody//tr"));
		String[] sVehiclePriceTable = new String[vehiclePriceTable.size()];
		for(int i=0; i<vehiclePriceTable.size(); i++) {
			sVehiclePriceTable[i]=vehiclePriceTable.get(i).getText();
			if(sVehiclePriceTable[i].contains(vehiclePriceTableOptions[i])) {
				BFrameworkQueryObjects.logStatus(driver, Status.INFO, "Vehicle Price Table has value", vehiclePriceTableOptions[i] , null);
			}
			else {
				BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Vehicle Price Table missing value", vehiclePriceTableOptions[i], null);
			}
		}
		
		//Validate Standard Equipment Options
		RC_Global.clickButton(driver, "Standard Equip.", true, true);
		Thread.sleep(500);
		RC_Global.waitUntilPanelVisibility(driver, "Standard Equipment", "TV", true, true);
		
		RC_Global.createNode(driver, "Validate Standard Equipment Options");
		List<WebElement> groupNames = driver.findElements(By.xpath("//div[@ng-controller='FactoryOrderStandardEquipmentCtrl']//div[contains(@class,'group-name')]"));
		String[] sGroupNames = new String[groupNames.size()];
		for(int i=0; i<groupNames.size(); i++) {
			sGroupNames[i]=groupNames.get(i).getText();
			if(sGroupNames[i].equalsIgnoreCase(standardEquipGroupNames[i])) {
				BFrameworkQueryObjects.logStatus(driver, Status.INFO, "Standard Equip Groups has option", standardEquipGroupNames[i] , null);
			}
			else {
				BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Standard Equip Groups missing option", standardEquipGroupNames[i], null);
			}
		}		
		RC_Global.panelAction(driver, "close", "Standard Equipment", true, true);
		
		//Validate Warranty Options
		RC_Global.clickButton(driver, "Warranty", true, true);
		Thread.sleep(500);
		RC_Global.waitUntilPanelVisibility(driver, "Warranty", "TV", true, true);
		
		RC_Global.createNode(driver, "Validate Warranty Types");
		List<WebElement> typeNames = driver.findElements(By.xpath("//div[@ng-controller='FactoryOrderWarrantyCtrl']//div[contains(@class,'warranty-type')]"));
		String[] sTypeNames = new String[typeNames.size()];
		for(int i=0; i<typeNames.size(); i++) {
			sTypeNames[i]=typeNames.get(i).getText();
			if(sTypeNames[i].equalsIgnoreCase(warrantyTypeNames[i])) {
				BFrameworkQueryObjects.logStatus(driver, Status.INFO, "Warranty Types has type", warrantyTypeNames[i] , null);
			}
			else {
				BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Warranty Types missing type", warrantyTypeNames[i], null);
			}
		}		
		RC_Global.panelAction(driver, "close", "Warranty", true, true);
		
		//Validate Additional Images
		RC_Global.clickButton(driver, "Additional Images", true, true);
		Thread.sleep(500);
		RC_Global.waitUntilPanelVisibility(driver, "Additional Images", "TV", true, true);
		RC_Global.waitElementVisible(driver, 5, "//div[@ng-controller='FactoryOrderAdditionalImagesCtrl']//span[contains(., '"+vehicleType+"')]", "Edditional Images displayed for-->" + vehicleType , false, true);
		RC_Global.panelAction(driver, "close", "Additional Images", true, true);
		
		RC_Global.panelAction(driver, "expand", "Configure Vehicle Options", true, true);
		RC_Global.clickUsingXpath(driver, "//a[text()='Colors']", "Select Colors Tab", true, true);
		
		//Validate Total Options - Grand Total price increase
		RC_Global.createNode(driver, "Validate Total Options - Grand Total price increase");		
		String invoiceGTbefore = driver.findElement(By.xpath("//tbody//tr[contains(., 'Grand Total')]//td[2]")).getText().replace("$", "").replace(",", "").trim();
		double invoiceTotalBefore = Double.parseDouble(invoiceGTbefore);
		
		String msrpGTbefore = driver.findElement(By.xpath("//tbody//tr[contains(., 'Grand Total')]//td[3]")).getText().replace("$", "").replace(",", "").trim();
		double msrpTotalBefore = Double.parseDouble(msrpGTbefore);
		
		//Select Color Option with Cost
		List<WebElement> colorCost = driver.findElements(By.xpath("//div[@class='cost ng-scope']"));
		String[] sColorCost = new String[colorCost.size()];
		for(int c=0; c<colorCost.size(); c++) {
			sColorCost[c]=colorCost.get(c).getText();
			if(!sColorCost[c].contains("$0.00 / $0.00")) {
				driver.findElement(By.xpath("(//span[contains(@ng-click, 'colorOptionClicked')])["+(c+1)+"]")).click();
				Thread.sleep(2000);
				break;
			}			
		}		
		String invoiceGTafter = driver.findElement(By.xpath("//tbody//tr[contains(., 'Grand Total')]//td[2]")).getText().replace("$", "").replace(",", "").trim();
		double invoiceTotalAfter = Double.parseDouble(invoiceGTafter);
		
		String msrpGTafter = driver.findElement(By.xpath("//tbody//tr[contains(., 'Grand Total')]//td[3]")).getText().replace("$", "").replace(",", "").trim();
		double msrpTotalAfter = Double.parseDouble(msrpGTafter);
		
		if(invoiceTotalBefore < invoiceTotalAfter && msrpTotalBefore < msrpTotalAfter) {
			BFrameworkQueryObjects.logStatus(driver, Status.PASS, "TotalOptions-ColorCost Added To", "GrandTotal Price" , null);
		}
		else {
			BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "TotalOptions-ColorCost was NOT Added To", "GrandTotal Price", null);
		}
					
	}
}
