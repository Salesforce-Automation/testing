package Acquisition.FactoryOrder.PriceVehicle;

import java.io.File;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;

import tools.TotalView.RC_Global;
import tools.TotalView.RC_Acquisition_OrderPortal;
import tools.TotalView.RC_Acquisition;

public class TID_1_1_3_01 {
	
	public void FactoryOrder_PriceVehicle_AddNew_Selector(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		String spinnerSelector = "//div[contains(@class, 'panel-loading-spinner')]/i";
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,"Acquisition", "Factory Order", "Price a Vehicle");
		
		RC_Global.waitElementVisible(driver, 30, "//select[@id='selectMake']", "'Make' DropDown", true, true);
		RC_Global.selectDropdownOption(driver, "selectMake", "Audi", true, true);
		Thread.sleep(500);
		RC_Global.selectDropdownOption(driver, "selectModel", "A3", true, true);
		Thread.sleep(500);
		RC_Global.clickUsingXpath(driver, "(//input[@ng-click='trimSelected(trim)'])[1]", "Select Trim Radio Btn", true, true);
		RC_Global.clickButton(driver, "Next", true, true);
		Thread.sleep(500);
		RC_Global.waitElementNotVisible(driver, 30, spinnerSelector, "Spinner", true, true);
		RC_Global.clickUsingXpath(driver, "//a[text()='Colors']", "Select Colors Tab", true, true);
		Thread.sleep(500);
		RC_Global.clickUsingXpath(driver, "(//span[contains(@ng-click, 'colorOptionClicked')])[1]", "Select Color CheckBox", true, true);
		Thread.sleep(500);
		RC_Global.clickButton(driver, "Next", true, true);
		Thread.sleep(500);
		RC_Global.waitElementVisible(driver, 5, "//div[@id='Review Selector']", "'Review Selector' panel", true, true);
		RC_Global.clickButton(driver, "Next", true, true);
		RC_Global.waitElementVisible(driver, 5, "//div[@id='Save Selector']", "'Save Selector' panel", true, true);
		RC_Global.enterCustomerNumber(driver, "LS010116", "", "", true);
		String SelectorNameValue = "AudiTest-" + RandomStringUtils.randomAlphanumeric(5);
		WebElement selectorName = driver.findElement(By.xpath("//input[@name='selectorNameInput']"));
		RC_Global.enterInput(driver, SelectorNameValue, selectorName, true, true);
		RC_Global.selectDropdownOption(driver, "Selector Status*", "Inactive", true, true);
		RC_Global.clickButton(driver, "Save", true, true);
		RC_Global.waitElementVisible(driver, 30, "//h4[text()='Save Succeeded']", "Msg: Save Succeeded", true, true);
		Thread.sleep(500);
		RC_Global.panelAction(driver, "close", "Save Selector", true, true);
		Thread.sleep(500);
		
		RC_Global.navigateTo(driver,"Acquisition", "Factory Order", "Manage Selectors");
		RC_Global.waitElementVisible(driver, 30, "(//input[@name='customerInput'])[1]", "Customer Number input", true, true);		
		RC_Global.enterCustomerNumber(driver, "LS010116", "", "", true);
		Thread.sleep(500);
		RC_Global.waitElementVisible(driver, 30, "//table/tbody", "Search Result Grid", true, true);
		Thread.sleep(500);
		RC_Global.selectDropdownOption(driver, "Status", " All ", true, true);
		Thread.sleep(500);
		RC_Global.selectDropdownOption(driver, "Use for Ordering", " All ", true, true);
		Thread.sleep(500);
		WebElement selectorName1 = driver.findElement(By.xpath("//input[@name='selectorNameInput']"));
		RC_Global.enterInput(driver, SelectorNameValue, selectorName1, true, true);
		Thread.sleep(500);
		RC_Global.waitElementVisible(driver, 30, "//td[text()='"+SelectorNameValue+"']", "New Selector Name: " + SelectorNameValue, true, true);
		
		
		


		//RC_Global.clickButton(driver, "Open", true, true);
		//RC_Global.waitElementNotVisible(driver, 30, "//div[@ng-show='isOpening']/i", "File Download - Open Btn Spinner", true, true);
		
	       //try {
	           //String home = System.getProperty("user.home");
	                
	           //boolean flag = false;
	           //File listofFiles= new File(home+"/Downloads/" );
	           //for (File file :listofFiles.listFiles() ) {
	               //String filename= file.getName();
	               //if(filename.contains("Export")) {
	                   //flag = true;
	                   //file.delete();
	                   //break;
	           //}
	           //}
	           //if(flag) {
	              //queryObjects.logStatus(driver, Status.PASS, "Download File", "Successfully", null);
	              //}
	            //else{ 			
	                //queryObjects.logStatus(driver, Status.FAIL, "Download File", "Failed", null);
	           //}
	           //}
	           //catch(Exception e) {			
	           	//queryObjects.logStatus(driver, Status.FAIL, "Download and verify failed", e.getLocalizedMessage(), e);
	           //}
		
	}

}
