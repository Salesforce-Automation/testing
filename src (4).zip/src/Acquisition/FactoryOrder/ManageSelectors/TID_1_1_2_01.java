package Acquisition.FactoryOrder.ManageSelectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;

import tools.TotalView.RC_Global;
import tools.TotalView.RC_Acquisition_OrderPortal;
import tools.TotalView.RC_Acquisition;

public class TID_1_1_2_01 {
	
	public void ManageSelectors_InitialPricing_OptionValidation(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,"Acquisition", "Factory Order", "Manage Selectors");
		
		RC_Global.waitElementVisible(driver, 5, "//div[@id='Manage Selectors']", "'Manage Selectors' panel", true, true);		
		RC_Global.waitElementVisible(driver, 10, "//div[@ng-show='showCustomerInput']", "Customer Number input", true, true);
		
		RC_Global.enterCustomerNumber(driver, "LS008737", "", "", true);
		RC_Global.waitElementVisible(driver, 30, "//table/tbody", "Search Result Grid", true, true);
		
		RC_Global.clickUsingXpath(driver, "(//tbody//td[i[@class='fa fa-info-circle green']])[1]", "Click Row to Select", true, true);
		Thread.sleep(2000);
		
		RC_Global.waitElementNotVisible(driver, 30, "//span[text()='Loading Selected Selector']//i", "Loading Selected Selector-Spinner", true, true);
		Thread.sleep(1000);
		
		RC_Global.clickButton(driver, "Edit", true, true);
		
		RC_Global.modalHandler(driver, "Selector Out Of Date", "Accept");
		
		RC_Global.waitElementVisible(driver, 5, "//div[@id='Review Selector']", "'Review Selector' panel", true, true);
		
		RC_Global.waitElementVisible(driver, 10, "//span[@class='initial-pricing-indicator']", "Initial-Pricing-Indicator", false, true);
		
		RC_Global.clickButton(driver, "Back", true, true);
		
		RC_Global.waitElementNotVisible(driver, 30, "//div[div[@id='Configure Vehicle Options']]//div[contains(@class,'panel-loading-spinner')]/i", "Spinner", true, true);
		Thread.sleep(1000);
		
		RC_Global.clickButton(driver, "Back", true, true);
		
		RC_Global.waitElementNotVisible(driver, 30, "//div[div[@id='Price Vehicle']]//div[contains(@class,'panel-loading-spinner')]/i", "Spinner", true, true);
		Thread.sleep(1000);
		
		RC_Global.waitElementVisible(driver, 2, "//label[text()=' Initial Pricing ']/input[@ng-value='true']", "Initial Pricing radio Btn Selected", true, true);
		
		RC_Global.logout(driver, true);
			
	}

}
