package Acquisition.FactoryOrder.ManageSelectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;

import tools.TotalView.RC_Global;
import tools.TotalView.RC_Acquisition_OrderPortal;
import tools.TotalView.RC_Acquisition;

public class TID_1_1_3_01 {
	
	public void ManageSelectors_InitialPricing_OptionValidation(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		
	}

}
