package Acquisition.OrderingPortal;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;

import tools.TotalView.RC_Global;
import tools.TotalView.RC_Acquisition_OrderPortal;
import tools.TotalView.RC_Acquisition;

public class TID_1_2_03 {
	
	public void OM_Verify_Dashboard_Search(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		String unitNum = "";
		String vinNum = "";
		String ordNum = "";
		String cvnNum = "";
		String customerNum = "LS010116";
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver,"Acquisition", "Ordering Portal", "");
		RC_Global.switchToWindowTab(driver, 2, " Look up Order #",  true);
		RC_Global.waitElementVisible(driver, 30, "//p[text()=' Ordering - All Customers']", "OM-Portal", true, false);
		RC_Global.enterCustomerNumber(driver, customerNum, "", "", true);
		Thread.sleep(2000);
		RC_Global.clickButton(driver, "Search", true, true);
		Thread.sleep(2000);
		RC_Global.waitElementVisible(driver, 30, "//table//tbody//td[@class='sticky-col']", "Search Result Grid", true, false);
		RC_Global.verifyGridFieldIsAvailable(driver, "Unit Number", true);
		
		unitNum = driver.findElement(By.xpath("(//td//a)[1]")).getText().trim();
		ordNum = driver.findElement(By.xpath("(//td)[5]")).getText().trim();
		//cvnNum = driver.findElement(By.xpath("(//td)[7]")).getText().trim();
		
		String[] vars = {unitNum, ordNum, "abc123"};  
		
		for	(String var: vars) {
			RC_Global.clickLink(driver, "Dashboard", true, true);
			Thread.sleep(2000);
			RC_Global.waitElementVisible(driver, 30, "//p-card[contains(@header, 'Make')]//canvas", "Order By V-Make Graph", true, true);
			RC_Global.enterInput(driver, var, (WebElement)(driver.findElement(By.xpath("(//div[contains(., 'or VIN')])[7]//input"))), true, true);
			RC_Global.clickButton(driver, "Search", true, true);
			Thread.sleep(2000);
			if(var!="abc123") {
				RC_Global.waitElementVisible(driver, 30, "//div[@class='box order-header']", "Order Details for Search Token: "+var, true, false);
			}
			else {
				RC_Global.waitElementVisible(driver, 30, "//span[text()='No Results']", "No Results for Search Token: "+var, true, false);
			}			
		 }
				
	}

}
