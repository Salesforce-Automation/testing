package MF.Source;

import java.net.InetAddress;

import com.aventstack.extentreports.ExtentReports;

import totalview.Utilities.TotalViewCredentials;

public class Cred {
	
	  public static String UserName = null;  
	  public static String PassWord = null;
	  public static String ENV = null;	  
	  public static String Browser1 = null;
	  public static boolean isVMRun = true;
	  

	public static void Credentials(String VMName, String BaseUrl) {

		ENV = BaseUrl;
	    switch (VMName) {
	    case "M1WAPPIE11-Q":
	        if (!BaseUrl.equals("PROD")) {
	        	UserName = "TestAutomation1";
		         PassWord = TotalViewCredentials.pwdTestAutomation1;
	        } 
	        else {
	        	 UserName = "TestAutomationA";
	    		 PassWord = TotalViewCredentials.pwdTestAutomationA;
	        	}
	    break;
      case "M1WAPPIE12-Q":
	        if (!BaseUrl.equals("PROD")) {
	        	UserName = "TestAutomation2";
		         PassWord = TotalViewCredentials.pwdTestAutomation1;
	        } 
	        else {
	        	 UserName = "TestAutomationB";
	    		 PassWord = TotalViewCredentials.pwdTestAutomationB;
	        	}
	    break;
      case "M1WAPPIE14-Q":
	        if (!BaseUrl.equals("PROD")) {
	        	UserName = "TestAutomation3";
		        PassWord = TotalViewCredentials.pwdTestAutomation1;
	        } 
	        else {
	        	UserName = "TestAutomationC";
	    		PassWord = TotalViewCredentials.pwdTestAutomationC;
	        	}
	    break;
      case "M1WAPPIE15-Q":
	        if (!BaseUrl.equals("PROD")) {
	        	UserName = "TestAutomation4";
		        PassWord = TotalViewCredentials.pwdTestAutomation1;
	        } 
	        else {
	        	UserName = "TestAutomationD";
	    		PassWord = TotalViewCredentials.pwdTestAutomationD;
	        	}
	    break;
      case "M1WAPPIE16-Q":
	        if (!BaseUrl.equals("PROD")) {
	        	UserName = "TestAutomation5";
		        PassWord = TotalViewCredentials.pwdTestAutomation1;
	        } 
	        else {
	        	UserName = "TestAutomatione";
	    		PassWord = TotalViewCredentials.pwdTestAutomationE;
	        	}
	    break;
      case "M1WAPPIE17-Q":
	        if (!BaseUrl.equals("PROD")) {
	        	UserName = "TestAutomation6";
		        PassWord = TotalViewCredentials.pwdTestAutomation1;
	        } 
	        else {
	        	UserName = "TestAutomationF";
	    		PassWord = TotalViewCredentials.pwdTestAutomationF;
	        	}
	    break;
      case "M1WAPPIE18-Q":
	        if (!BaseUrl.equals("PROD")) {		     
	        	UserName = "TestAutomation7";
	        	PassWord = TotalViewCredentials.pwdTestAutomation1;
	        } 
	        else {
	        	UserName = "TestAutomationG";
	    		PassWord = TotalViewCredentials.pwdTestAutomationG;
	        	}
	    break;
      case "M1WAPPIE19-Q":
	        if (!BaseUrl.equals("PROD")) {	       	
	      	UserName = "TestAutomation8";
	      	PassWord = TotalViewCredentials.pwdTestAutomation1;
	        } 
	        else {
	        	UserName = "TestAutomationH";
	    		PassWord = TotalViewCredentials.pwdTestAutomationH;
	        	}
	    break;
      case "M1WAPPIE20-Q":
	        if (!BaseUrl.equals("PROD")) {	       	
	      	UserName = "TestAutomation9";
	      	PassWord = TotalViewCredentials.pwdTestAutomation1;
	        } 
	        else {
	        	UserName = "TestAutomationI";
	    		PassWord = TotalViewCredentials.pwdTestAutomationI;
	        	}
	    break;
	      	default:
	      		isVMRun = false;
	    	 if(!BaseUrl.equals("PROD")) {
	    		 UserName = "jennysb";
		         PassWord = "Pa55w0rd4$";
//		         UserName = "TestAutomation1";
//		         PassWord = TotalViewCredentials.pwdTestAutomation1;
	    	 }
	    	 else {
	    		 UserName = "TestAutomationI";
	    		 PassWord = TotalViewCredentials.pwdTestAutomationI;
	    	 }	
	    }
	}}
