package MF.FrameworkCode;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class testmethod {
  static String Moduel = null;
  
  static String classname = null;
  
  static String testdclassnameatarow = null;
  
  static String TestData;
  
  static XSSFWorkbook TD = null;
  
  static XSSFSheet test = null;
  
  static XSSFRow row = null;
  
  static StringBuilder htmlBuilder = new StringBuilder();
  
  static String url = "suman";
  
  public static void test(List<String> ls, WebDriver driver, ExtentTest logger) throws IOException {
    int n = ls.size();
    int k = 0;
    int NoSeqCount = 1;
    for (int i = 0; i < n; i += 3) {
      Moduel = ls.get(i);
      classname = ls.get(i + 1);
      testdclassnameatarow = ls.get(i + 2);
      String[] NoSeq = testdclassnameatarow.split(",");
      System.out.println("Running--->" + Moduel + "--With class--->" + classname + "---Taking the test data row---" + testdclassnameatarow);
      String abcd = driver.getWindowHandle();
      url = "test";
      try {
        url = driver.getTitle();
      } catch (Exception e) {
        url = "";
      } 
      //if (driver != null && url == "")
        //BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Please check your browser", "May be your browser close incidentally", null); 
      k++;
      Class<?> cls = null;
      try {
        cls = Class.forName(classname);
      } catch (Exception e) {
        BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Checking the class", "Class not found exception", e);
      } 
      Object obj = null;
      try {
        obj = cls.newInstance();
      } catch (Exception e) {
        BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Checking the class", "Classs not found while object exception", e);
      } 
      Method method = null;
      try {
        method = obj.getClass().getMethod(Moduel, new Class[] { WebDriver.class, BFrameworkQueryObjects.class });
      } catch (Exception e) {
        BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Class not found exception", "", e);
      } 
      try {
        for (int s = 0; s < NoSeq.length; s++) {
          testdclassnameatarow = NoSeq[s];
          if (NoSeq.length > 1)
            BFrameworkQueryObjects.logStatus(driver, Status.PASS, "<b><font color=Yellow size=5>Start Test</font></b>", "<b><font color=green size=5>" + Moduel + "---" + classname + "---" + testdclassnameatarow + "</font></b>", null); 
          BFrameworkQueryObjects abc = new BFrameworkQueryObjects();
          double d = -1.0D;
          Object value = null;
          try {
            value = method.invoke(obj, new Object[] { driver, abc });
          } catch (InvocationTargetException ite) {
            BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "method not executed correctly", ite.getTargetException() + "-----" + ite.getCause() + "-->" + ite.getMessage(), ite);
          } 
        } 
      } catch (Exception e) {
        BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Class not found exception", "", e);
      } 
    } 
  }
}
