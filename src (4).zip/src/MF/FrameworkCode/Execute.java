package MF.FrameworkCode;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.google.common.collect.Iterables;
import com.google.common.collect.Multimap;

public class Execute {
  static String Moduel = null;
  
  static String classname = null;
  
  String testdclassnameatarow = null;
  
  public static void run(Multimap map, String TID, WebDriver driver, ExtentTest logger) throws IOException, ReflectiveOperationException {
    List<String> ls = new ArrayList<>();
    Collection<String> values = map.get(TID);
    for (int p = 1; p <= values.size(); p++)
      ls.add((String)Iterables.get(map.get(TID), p - 1)); 
    try {
      testmethod.test(ls, driver, logger);
      String str = driver.getTitle();
    } catch (Exception e) {
      BFrameworkQueryObjects.logStatus(driver, Status.FAIL, "Class not found exception", "THis issue will cone if browser gets closed incidentally", e);
    } 
  }
}
