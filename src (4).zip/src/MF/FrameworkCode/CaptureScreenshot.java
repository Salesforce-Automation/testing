package MF.FrameworkCode;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

public class CaptureScreenshot {

  public static String capture(WebDriver driver, String screenShotName) throws IOException {
    TakesScreenshot ts = (TakesScreenshot)driver;
    File source = (File)ts.getScreenshotAs(OutputType.FILE);
    String dest = "";
    if(!StartFramework.TestEnv.equalsIgnoreCase("PROD"))
    dest = "./Execution_Result/R" + StartFramework.TestEnv + "_" + StartFramework.TestSuiteselection + "_" + StartFramework.fileName + "/Screenshots/" + screenShotName;
    else
    dest = "./Execution_Result/" + StartFramework.TestSuiteselection + "_" + StartFramework.fileName + "/Screenshots/" + screenShotName;
    File destination = new File(dest);
    FileUtils.copyFile(source, destination);
    String newDest = "./Screenshots/" + screenShotName;
    return newDest;
  }
  
  public static String capture(WebDriver driver, String screenShotName, ExtentTest logger) throws IOException {
    TakesScreenshot ts = (TakesScreenshot)driver;
    File source = (File)ts.getScreenshotAs(OutputType.FILE);
    String dest = "";
    if(!StartFramework.TestEnv.equalsIgnoreCase("PROD"))
    dest = "./Execution_Result/R" + StartFramework.TestEnv + "_" + StartFramework.TestSuiteselection + "_" + StartFramework.fileName + "/Screenshots/" + screenShotName;
    else
    dest = ".//Execution_Result/" + StartFramework.TestSuiteselection + "_" + StartFramework.fileName + "/Screenshots/" + screenShotName;
    File destination = new File(dest);
    FileUtils.copyFile(source, destination);
    String newDest = "./Screenshots/" + screenShotName;
    return newDest;
  }
}
