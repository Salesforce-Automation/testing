package MF.FrameworkCode;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.events.WebDriverEventListener;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;

public class ActivityCapture implements WebDriverEventListener {
  public void afterAlertAccept(WebDriver arg0) {}
  
  public void afterAlertDismiss(WebDriver arg0) {}
  
  public void afterChangeValueOf(WebElement arg0, WebDriver arg1, CharSequence[] arg2) {}
  
  public void afterClickOn(WebElement arg0, WebDriver arg1) {}
  
  public void afterFindBy(By arg0, WebElement arg1, WebDriver arg2) {}
  
  public void afterNavigateBack(WebDriver arg0) {}
  
  public void afterNavigateForward(WebDriver arg0) {}
  
  public void afterNavigateRefresh(WebDriver arg0) {}
  
  public void afterNavigateTo(String arg0, WebDriver arg1) {}
  
  public void afterScript(String arg0, WebDriver arg1) {}
  
  public void beforeAlertAccept(WebDriver arg0) {}
  
  public void beforeAlertDismiss(WebDriver arg0) {}
  
  public void beforeChangeValueOf(WebElement arg0, WebDriver arg1, CharSequence[] arg2) {}
  
  public void beforeClickOn(WebElement arg0, WebDriver driver) {
    Date strDate = new Date();
    Calendar cal = Calendar.getInstance();
    String sDate = (new SimpleDateFormat("MMddyyyy")).format(cal.getTime());
    String screenShotName = "MF_" + sDate + RandomStringUtils.random(6, true, false) + ".png";
    try {
      String screenShotPath = CaptureScreenshot.capture(driver, screenShotName, StartFramework.logger);
      StartFramework.child.info("Clicking on element->" + arg0, MediaEntityBuilder.createScreenCaptureFromPath(screenShotPath).build());
    } catch (IOException e) {
      e.printStackTrace();
      StartFramework.child.log(Status.PASS, "Getting an Exception" + e);
    } 
  }
  
  public void beforeFindBy(By arg0, WebElement arg1, WebDriver arg2) {}
  
  public void beforeNavigateBack(WebDriver arg0) {}
  
  public void beforeNavigateForward(WebDriver arg0) {}
  
  public void beforeNavigateRefresh(WebDriver arg0) {}
  
  public void beforeNavigateTo(String arg0, WebDriver arg1) {}
  
  public void beforeScript(String arg0, WebDriver arg1) {}
  
  public void onException(Throwable arg0, WebDriver arg1) {}
  
  public void afterSwitchToWindow(String arg0, WebDriver arg1) {}
  
  public void beforeSwitchToWindow(String arg0, WebDriver arg1) {}
  
  public <X> void beforeGetScreenshotAs(OutputType<X> target) {}
  
  public <X> void afterGetScreenshotAs(OutputType<X> target, X screenshot) {}
  
  public void beforeGetText(WebElement element, WebDriver driver) {}
  
  public void afterGetText(WebElement element, WebDriver driver, String text) {}
}
