package Reporting.BakerRoofingReports;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_15_01 {
	
	public static void BakerRoofingReports_VerifyWeeklyFuelReportSearchFunctionalityAndUIExceptions(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{

		RC_Global.login(driver);
	
		String columnNames="Account Name;CVN;Transaction Date;Transaction Time;Transaction Odometer;Vendor Name;Vendor City;Vendor State;Vendor Zip Code;Buyer;Year;Make;Model;Trim;Fuel Type;Transaction Gallons;Total Transaction Cost;Price Per Gallon;Unit Number";

	      
		RC_Reporting.navigateTo(driver, "Reporting", "Baker Roofing Reports", "Weekly Fuel Report");
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);

		RC_Global.verifyScreenComponents(driver, "lable", "Customer Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "From Date", false);
		RC_Global.verifyScreenComponents(driver, "lable", "To Date", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Vehicle Status", false);
	
		
		
		WebElement fromDateElement = driver.findElement(By.xpath("//input[@id='dateTimeField_From Date']"));
		WebElement toDateElement = driver.findElement(By.xpath("//input[@id='dateTimeField_To Date']"));
		

		RC_Reporting.fromToDateErrorValidation(driver, fromDateElement, toDateElement);
		

		String fromDate = RC_Global.getDateTime(driver, "MM/dd/yyyy", -365, true);
		String toDate = RC_Global.getDateTime(driver, "MM/dd/yyyy", 0, true);
		RC_Global.enterInput(driver, fromDate, fromDateElement, true, true);
		RC_Global.enterInput(driver, toDate, toDateElement, true, true);
		
		String fDDate= fromDate.split("/")[1].split("")[0];
		String tDDate= toDate.split("/")[1].split("")[0];
		
		String fDMonth= fromDate.split("/")[0].split("")[0];
		String tDMonth= toDate.split("/")[0].split("")[0];
		
		if(fDDate.equalsIgnoreCase("0")&& !fDMonth.equalsIgnoreCase("0"))fromDate = RC_Global.getDateTime(driver, "MM/d/yyyy", -365, true);
		else if(!fDDate.equalsIgnoreCase("0")&& fDMonth.equalsIgnoreCase("0"))fromDate = RC_Global.getDateTime(driver, "M/dd/yyyy", -365, true);
		else if(fDDate.equalsIgnoreCase("0")&& fDMonth.equalsIgnoreCase("0"))fromDate = RC_Global.getDateTime(driver, "M/d/yyyy", -365, true);
		
		if(tDDate.equalsIgnoreCase("0")&& !tDMonth.equalsIgnoreCase("0"))toDate = RC_Global.getDateTime(driver, "MM/d/yyyy", 0, true);
		else if(!tDDate.equalsIgnoreCase("0")&& tDMonth.equalsIgnoreCase("0"))toDate = RC_Global.getDateTime(driver, "M/dd/yyyy", 0, true);
		else if(tDDate.equalsIgnoreCase("0")&& tDMonth.equalsIgnoreCase("0"))toDate = RC_Global.getDateTime(driver, "M/d/yyyy", 0, true);
		
		RC_Reporting.generateReportValidateResults(driver);
		
		
		
		RC_Global.verifyScreenComponents(driver, "button", "Excel", false);
		RC_Global.verifyScreenComponents(driver, "button", "CSV", false);
		RC_Global.verifyScreenComponents(driver, "button", "PDF", false);
		RC_Global.verifyScreenComponents(driver, "button", "XML", false);
		RC_Global.verifyScreenComponents(driver, "button", "Edit Columns", false);
		
		
		RC_Reporting.generateReportValidateResults(driver);

  		RC_Reporting.validateReportColumnNames(driver, columnNames);

  		
		RC_Reporting.clickReportCellHyperLink(driver, "CVN", "Vehicle Details");
		RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
		RC_Reporting.panelAction(driver, "expand", "Weekly Fuel Report",false, false);

	    

		Thread.sleep(3000);
		RC_Reporting.downloadAndVerifyFileDownloaded(driver, "Weekly Fuel Report - Baker Roofing Company_LS010153", "Excel button - Download validation", true);
		
		Thread.sleep(3000);
		RC_Reporting.reportParametersNavigate(driver);
		RC_Reporting.validateCustomerNumberParamData(driver, "LS010153");
		
		RC_Reporting.validateReportParameterData(driver, "From Date", fromDate+" 12:00:00 AM");
		RC_Reporting.validateReportParameterData(driver, "To Date", toDate+" 12:00:00 AM");
		RC_Reporting.validateReportParameterData(driver, "Fuel Type", "Regular, Midgrade, Premium, Diesel, DEF, Other Fuel, Non Fuel");
		RC_Reporting.validateReportParameterData(driver, "Vehicle Status", "Active lease, Active services only, Pending termination");
		
		
		RC_Reporting.panelAction(driver, "close", "Weekly Fuel Report", true, true);
		RC_Global.logout(driver, true);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

		
		
		
	}

}
