package Reporting.AllReports;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_1_01 {
	public static void Reporting_VerifyEditColumnsFunctionality(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		WebDriverWait wait = new WebDriverWait(driver, 30);
		
		RC_Global.login(driver);
		RC_Reporting.navigateTo(driver, "Reporting", "All Reports", "");
		RC_Global.clickUsingXpath(driver, "//div/span[contains(text(),'List Of Fleet')]", "List Of Fleet report", true, true);
		
		RC_Global.waitElementVisible(driver, 30, "//h5/span[contains(text(),'List Of Fleet')]", "List Of Fleet Report screen", true, false);
		RC_Reporting.panelAction(driver, "close", "All Reports", true, true);
		RC_Reporting.panelAction(driver, "expand", "List Of Fleet", true, true);
		
		RC_Global.verifyScreenComponents(driver, "button", "Edit Columns", false);
		RC_Global.clickButton(driver, "Edit Columns", true, true);
		
		RC_Global.waitElementVisible(driver, 30, "//h4[text()='List Of Fleet']", "List Of Fleet Edit Columns window", true, false);
		RC_Global.waitElementVisible(driver, 30, "//label[text()='Selected Data Fields']", "Window load", true, false);
		
		RC_Global.verifyScreenComponents(driver, "lable", "Selected Data Fields", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Available Data Fields", false);

		RC_Global.verifyScreenComponents(driver, "button", "<< Add", false);
		RC_Global.verifyScreenComponents(driver, "button", "Remove >>", false);
		
		RC_Global.verifyScreenComponents(driver, "button", "Clear All", false);
		RC_Global.verifyScreenComponents(driver, "button", "Save", false);
		RC_Global.verifyScreenComponents(driver, "button", "Back", false);
		
		RC_Global.clickUsingXpath(driver, "//ul[@id='availableColumnsContainer']/li[text()='Color']", "Color option", true, true);
		RC_Global.clickUsingXpath(driver, "//ul[@id='availableColumnsContainer']/li[text()='Segment']", "Segment option", true, true);
		RC_Global.clickUsingXpath(driver, "//ul[@id='availableColumnsContainer']/li[text()='Mileage']", "Mileage option", true, true);
	
		RC_Global.clickButton(driver, "Remove >>", true, true);
		
		RC_Global.clickButton(driver, "Save", true, true);
		
		try {
			wait.until(ExpectedConditions.alertIsPresent());
			String confMessage = driver.switchTo().alert().getText();
			if(confMessage.equalsIgnoreCase("The new report was successfully saved."))
				driver.switchTo().alert().accept();
			else {
				queryObjects.logStatus(driver, Status.FAIL, "Verify confirmation alert message", "Expected alert message did not appear", null);
				RC_Global.endTestRun(driver);
			}
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify confirmation alert message appears", "No Alert appeared", e);
			RC_Global.endTestRun(driver);
		}
		
		try {
			RC_Global.waitElementVisible(driver, 30, "//div[text()=' You modified this report. ']", "Report Modification Message", true, false);
			queryObjects.logStatus(driver, Status.PASS, "Verify that the report was modified", "The report was successfully modified", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify that the report was modified", "The report was not modified", null);
		}
		
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		
		if(driver.findElement(By.xpath("//div[label[text()='Use original report']]/input")).isSelected())
			RC_Global.clickUsingXpath(driver, "//div[label[text()='Use original report']]/input", "Use original report checkbox", true, true);
		
		RC_Reporting.generateReportValidateResults(driver);
		
		RC_Global.waitElementVisible(driver, 30, "(//*[@id='oReportCell']//td[contains(.,'Customer Number')])[1]", "Report table result", true, false);
		RC_Global.createNode(driver, "Validate the removed data fields do not appear in the Report");
		String[] removedDataFields = {"Color", "Segment", "Mileage"};
		for(int iter=0; iter<removedDataFields.length; iter++) {
			try {
				driver.findElement(By.xpath("(//*[@id='oReportCell']//td[text()='"+removedDataFields[iter]+"'])[1]"));
			}
			catch(Exception e) {
				queryObjects.logStatus(driver, Status.PASS, "Validate Report Column Name--->Column: " + removedDataFields[iter] + " does not exists", "Column: "+removedDataFields[iter]+" --->Was NOT Found", e);
			}
		}
		
		if(!driver.findElement(By.xpath("//div[label[text()='Use original report']]/input")).isSelected())
			RC_Global.clickUsingXpath(driver, "//div[label[text()='Use original report']]/input", "Use original report checkbox", true, true);
		RC_Reporting.generateReportValidateResults(driver);
		
		Thread.sleep(2000);
		RC_Global.waitElementVisible(driver, 30, "(//*[@id='oReportCell']//td[contains(.,'Customer Number')])[1]", "Report table result", true, false);
		
		RC_Global.createNode(driver, "Validate the removed data fields in the Report");
		for(int iter=0; iter<removedDataFields.length; iter++) {
			try {
				driver.findElement(By.xpath("(//*[@id='oReportCell']//td[text()='"+removedDataFields[iter]+"'])[1]"));
			}
			catch(Exception e) {
				queryObjects.logStatus(driver, Status.FAIL, "Validate Report Column Name--->Column: " + removedDataFields[iter] + " does not exists", "Column: "+removedDataFields[iter]+" --->Was NOT Found", e);
			}
		}
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//u[text()='Reset to default']")).click();
		
		try {
			wait.until(ExpectedConditions.alertIsPresent());
			String confMessage = driver.switchTo().alert().getText();
			if(confMessage.equalsIgnoreCase("Do you want to reset the data fields?"))
				driver.switchTo().alert().accept();
			else {
				queryObjects.logStatus(driver, Status.FAIL, "Verify confirmation alert message", "Expected alert message did not appear", null);
				RC_Global.endTestRun(driver);
			}
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify confirmation alert message appears", "No Alert appeared", e);
			RC_Global.endTestRun(driver);
		}
		
		try {
			RC_Global.waitElementVisible(driver, 30, "//div[text()=' You successfully reset the data fields ']", "Data field reset message", true, true);
			queryObjects.logStatus(driver, Status.PASS, "Verify data field reset confirmation message", "Data field reset confirmation message is displayed", null);
		}
		catch(Exception e) {
			queryObjects.logStatus(driver, Status.FAIL, "Verify data field reset confirmation message", "Data field reset confirmation message is not displayed", null);
		}
		
		RC_Reporting.generateReportValidateResults(driver);
		
		RC_Global.waitElementVisible(driver, 30, "(//*[@id='oReportCell']//td[contains(.,'Customer Number')])[1]", "Report table result", true, false);
		RC_Global.createNode(driver, "Validate the reset data fields appear in the Report");
		for(int iter=0; iter<removedDataFields.length; iter++) {
			try {
				driver.findElement(By.xpath("(//*[@id='oReportCell']//td[text()='"+removedDataFields[iter]+"'])[1]"));
			}
			catch(Exception e) {
				queryObjects.logStatus(driver, Status.FAIL, "Validate Report Column Name--->Column: " + removedDataFields[iter] + " does not exists", "Column: "+removedDataFields[iter]+" --->Was NOT Found", e);
			}
		}
		
		RC_Reporting.panelAction(driver, "close", "List Of Fleet", true, true);
		
		RC_Global.logout(driver, true);
	}

}
