package Reporting.StandardReports;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_2_05 {

	public static void StandardReports_VerifyPlateExpirationSearchFunctionalityAndUIExceptions(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
		
		
		RC_Global.login(driver);
        
		String columnClientData = RC_Reporting.retrieveClientData(driver, "LS007656", 0);
		
		RC_Reporting.navigateTo(driver, "Reporting", "Standard Reports", "Plate Expiration");
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);
		
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Number:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Driver Name:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Unit Number:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Vehicle Number:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "VIN:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Expiration Date From:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Expiration Date To:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Days To Expiration <:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Plate Number:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Value:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Number:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Value:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Number:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Agreement Type:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Plate State:", false);

		RC_Global.verifyScreenComponents(driver, "button", "Excel", false);
		RC_Global.verifyScreenComponents(driver, "button", "CSV", false);
		RC_Global.verifyScreenComponents(driver, "button", "PDF", false);
		RC_Global.verifyScreenComponents(driver, "button", "XML", false);
		RC_Global.verifyScreenComponents(driver, "button", "Edit Columns", false);
		
        RC_Global.dropdownValuesValidation(driver, "Open End;Closed End;Services Only", "(//select[@ng-model='param.ParameterValue'])[3]", false, true);    

		RC_Global.waitElementVisible(driver, 10, "//input[@name='customerInput']", "Input CustomerNumber",true, true);		
		RC_Global.enterCustomerNumber(driver, "LS007656", "", "",true);
		
		RC_Reporting.generateReportValidateResults(driver);

		Thread.sleep(5000);

		RC_Reporting.validateReportColumnNames(driver,"Customer Name;Customer Number;Unit Number;CVN;VIN;Year;Make;"
				+ "Model;Trim;Body;Drive;Color;Agreement Type;Vehicle Status;Driver Type;Driver/Pool;Pool Contact;Months In Service;Vehicle Address;Vehicle Address 2;"
				+ "Vehicle City;Vehicle State;Vehicle Zip Code;Vehicle County;Vehicle County;Current Odometer;Plate Number;Plate State;Plate Expiration Date;Days To Plate Expiration;"+columnClientData+";"
				+ "Employee Data 1;Employee Data 2;Employee Data 3;Fleet Number;Fleet Name;Account Number;Account Name;Sub-account Number;Sub-account Name");
		Thread.sleep(5000);
		
		RC_Reporting.verifySortFunction(driver, "Unit Number", true);
		RC_Reporting.verifySortFunction(driver, "Year", true);

		RC_Reporting.clickReportCellHyperLink(driver, "Unit Number", "Vehicle Details");
		RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
		RC_Reporting.panelAction(driver, "expand", "Plate Expiration",false, false);
		
		Thread.sleep(3000);
		
		RC_Reporting.verifySortFunction(driver, "CVN", false);
		if(driver.findElements(By.xpath("((//tbody//tbody)[1]/tr[@valign]/td[4]//a[@style and text()])[1]")).size()>0) {
			RC_Reporting.clickReportCellHyperLink(driver, "CVN", "Vehicle Details");
			RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
			RC_Reporting.panelAction(driver, "expand", "Plate Expiration",false, false);
		}
		Thread.sleep(3000);
			
		RC_Reporting.clickReportCellHyperLink(driver, "Driver/Pool", "Driver Details");
		RC_Reporting.panelAction(driver, "close", "Driver Details",false, false);
		RC_Reporting.panelAction(driver, "expand", "Plate Expiration",false, false);
		
		RC_Reporting.downloadAndVerifyFileDownloaded(driver, "Plate Expiration_LS007656", "Downloading Standard Report Validation", false);
		
		RC_Reporting.reportParametersNavigate(driver);
		
		RC_Reporting.validateCustomerNumberParamData(driver, "LS007656");
		RC_Reporting.panelAction(driver, "close", "Plate Expiration", true, true);
		RC_Global.logout(driver, true);
	}

		
}
