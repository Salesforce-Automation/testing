package Reporting.StandardReports;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_2_10 {
	
public static void StandardReports_VerifyMileageReportsearchfunctionalityandUIexceptions(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
		
		

		WebDriverWait wait = new WebDriverWait(driver,50);
		
		RC_Global.login(driver);

		
		RC_Reporting.navigateTo(driver, "Reporting", "Standard Reports", "Mileage Report");
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);
		
        Thread.sleep(5000);
        
        RC_Global.createNode(driver, "Verify Search Filters");
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Number:", false);//Customer Number (Mandatory)
		RC_Global.verifyScreenComponents(driver, "lable", "Driver Name:", false);//Driver Name
		RC_Global.verifyScreenComponents(driver, "lable", "Plate Expiration Date:", false);//Plate Expiration Date
		RC_Global.verifyScreenComponents(driver, "lable", "Plate State:", false);//Plate State
		RC_Global.verifyScreenComponents(driver, "lable", "Unit Number:", false);//Unit Number
		RC_Global.verifyScreenComponents(driver, "lable", "VIN:", false);//VIN
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Value:", false);//Client Data Value
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Value:", false);//Exclude Client Data Value
		RC_Global.verifyScreenComponents(driver, "lable", "Vehicle Status:", false);//Vehicle Status (Mandatory)
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Vehicle Number:", false);//Customer Vehicle Number 
		RC_Global.verifyScreenComponents(driver, "lable", "Plate Number:", false);//Plate Number
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Number:", false);//Client Data Number
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Number:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Pool Units:", false);
		
		RC_Global.createNode(driver, "Validate buttons");
		RC_Global.verifyScreenComponents(driver, "button", "Generate Report", false);
		RC_Global.verifyScreenComponents(driver, "button", "Excel", false);
		RC_Global.verifyScreenComponents(driver, "button", "CSV", false);
		RC_Global.verifyScreenComponents(driver, "button", "PDF", false);
		RC_Global.verifyScreenComponents(driver, "button", "XML", false);
		RC_Global.verifyScreenComponents(driver, "button", "Edit Columns", false);
		
		RC_Global.dropdownValuesValidation(driver, "Yes;No;", "//div[label[text()='Pool Units:']]//select", true, true);
		
		 RC_Global.enterCustomerNumber(driver, "LS008742", "", "",true);
		 	
		 RC_Reporting.downloadAndVerifyFileDownloaded(driver, "Mileage Report", "Excel button - Download validation", true);
		 
         Thread.sleep(4000);
	
         RC_Reporting.panelAction(driver, "close", "Mileage Report", false, true);
         RC_Global.logout(driver, true);
         
	}
}