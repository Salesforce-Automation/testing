package Reporting.StandardReports;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_2_15 {
	public static void StandardReports_VerifyTitleManagementExceptionReportSearchFunctionality(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		String columnNames_page1 ="Business Unit Summary;Missing Titles;Titles in Vault";WebDriverWait wait = new WebDriverWait(driver, 30);
		
		RC_Global.login(driver);
		String columnClientData = RC_Reporting.retrieveClientData(driver, "LS007656", 15);
		
		String columnNames_page2 = "Customer Name;Customer Number;Unit Number;CVN;VIN;Year;Make;Model;Vehicle Status;Title Status;;Fleet Number;Fleet Name;Account Number;Account Name;Sub Account Number;Sub Account Name";
		
		RC_Reporting.navigateTo(driver, "Reporting", "Standard Reports", "Title Management Exception Report");
		RC_Global.waitElementVisible(driver, 30, "//label[text()='Customer Number:']", "Customer Number label", true, false);
		
		RC_Global.createNode(driver, "Verify Search Filters");
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Unit Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Vehicle Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "VIN", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Title State", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Title Status", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Vehicle Status", false);
		
		RC_Global.createNode(driver, "Validate buttons");
		RC_Global.verifyScreenComponents(driver, "button", "Generate Report", false);
		RC_Global.verifyScreenComponents(driver, "button", "Excel", false);
		RC_Global.verifyScreenComponents(driver, "button", "CSV", false);
		RC_Global.verifyScreenComponents(driver, "button", "PDF", false);
		RC_Global.verifyScreenComponents(driver, "button", "XML", false);
		RC_Global.verifyScreenComponents(driver, "button", "Edit Columns", false);
		
		String sVehicleStatus = "Active lease, Active services only, Pending Activation, Pending termination, On Order";
		String sTitleStatus = "Out for Processing, Released From Title Management, Pending Original Title";
				
		RC_Global.clickButton(driver, "Generate Report", true, true);
		RC_Reporting.reportErrorValidation(driver,"//h4[text()='Customer Number is required']");
		
		RC_Global.enterCustomerNumber(driver, "LS007656", "", "", true);
		RC_Reporting.generateReportValidateResults(driver);
		
		RC_Reporting.validateReportColumnNames(driver, columnNames_page1);
		RC_Reporting.verifySortFunction(driver, "Business Unit Summary",true);
		RC_Reporting.verifySortFunction(driver, "Missing Titles",true);
		RC_Reporting.verifySortFunction(driver, "Titles in Vault",true);
		
		RC_Global.clickUsingXpath(driver, "//button[@ng-click='nextReportPage()']", "Next Page", false, true);
		RC_Global.waitElementVisible(driver, 10, "//td[text()='Customer Name']", "Grid loading", false, false);
		RC_Reporting.validateReportColumnNames(driver, columnNames_page2);
		
		WebElement eElement = driver.findElement(By.xpath("//button[text()='Excel']"));
		
		RC_Global.createNode(driver, "Ascending Order Sort ---> "+"Unit Number");
		queryObjects.logStatus(driver, Status.INFO, "Ascending order sort", "",null);
		RC_Global.clickUsingXpath(driver, "//td[text()='Unit Number']/following-sibling::td/a[img]/span", "Column Sort button", true, false);
		wait.until(ExpectedConditions.elementToBeClickable(eElement));
		RC_Global.clickUsingXpath(driver, "//button[@ng-click='nextReportPage()']", "Next Page", false, false);
		wait.until(ExpectedConditions.elementToBeClickable(eElement));
		RC_Global.createNode(driver, "Descending Order Sort ---> "+"Unit Number");
		queryObjects.logStatus(driver, Status.INFO, "Descending order sort", "",null);
		RC_Global.clickUsingXpath(driver, "//td[text()='Unit Number']/following-sibling::td/a[img]/span", "Column Sort button", true, false);
		wait.until(ExpectedConditions.elementToBeClickable(eElement));
		RC_Global.clickUsingXpath(driver, "//button[@ng-click='nextReportPage()']", "Next Page", false, false);
		wait.until(ExpectedConditions.elementToBeClickable(eElement));
		
		RC_Global.createNode(driver, "Ascending Order Sort ---> "+"Year");
		queryObjects.logStatus(driver, Status.INFO, "Ascending order sort", "",null);
		RC_Global.clickUsingXpath(driver, "//td[text()='Year']/following-sibling::td/a[img]/span", "Column Sort button", true, false);
		wait.until(ExpectedConditions.elementToBeClickable(eElement));
		RC_Global.clickUsingXpath(driver, "//button[@ng-click='nextReportPage()']", "Next Page", false, false);
		wait.until(ExpectedConditions.elementToBeClickable(eElement));
		RC_Global.createNode(driver, "Descending Order Sort ---> "+"Year");
		queryObjects.logStatus(driver, Status.INFO, "Descending order sort", "",null);
		RC_Global.clickUsingXpath(driver, "//td[text()='Year']/following-sibling::td/a[img]/span", "Column Sort button", true, false);
		wait.until(ExpectedConditions.elementToBeClickable(eElement));
		RC_Global.clickUsingXpath(driver, "//button[@ng-click='nextReportPage()']", "Next Page", false, false);
		wait.until(ExpectedConditions.elementToBeClickable(eElement));
		
		RC_Reporting.downloadAndVerifyFileDownloaded(driver, "Title Management Exception Report_LS007656", "Excel button - Download validation", true);
		
		RC_Reporting.reportParametersNavigate(driver);
		RC_Reporting.validateCustomerNumberParamData(driver, "LS007656");
		RC_Reporting.validateReportParameterData(driver, "Vehicle Status", sVehicleStatus);
		RC_Reporting.validateReportParameterData(driver, "Title Status", sTitleStatus);
		
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
