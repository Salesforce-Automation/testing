package Reporting.StandardReports;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_2_18 {
	public static void StandardReports_VerifyLeaseProjectionReportSearchFunctionalityAndUIExceptions(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		WebDriverWait wait = new WebDriverWait(driver,30);
		String message = "Historical report values not available at this time."; String cusno="LS007656";
		RC_Global.login(driver); 
		
		String columnClientData = RC_Reporting.retrieveClientData(driver, cusno, 7);
		String columnNames = "Customer Name;Customer Number;Unit Number;CVN;VIN;Year;Make;Model;Driver;Delivered Date;Agreement Type;Capitalized Cost;Book Depreciation Rate;Amortization Term;In Service Date;Expected Maturity;Residual Booked;Current Book Value;Interest Type;Finance Rate;Over Term Type;Unit Number;Months In Service;Month;Principal Amount;Interest Amount;Admin Amount;Total Lease Payment;NBV Amount;"+columnClientData;
		
		RC_Reporting.navigateTo(driver, "Reporting", "Standard Reports", "Lease Projection Report");
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);
		
		RC_Global.createNode(driver, "Verify Search Filters");
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Unit Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Vehicle Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Driver Name", false);
		RC_Global.verifyScreenComponents(driver, "lable", "VIN", false);
		RC_Global.verifyScreenComponents(driver, "lable", "From Date", false);
		RC_Global.verifyScreenComponents(driver, "lable", "To Date", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Agreement Type", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Value", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Value", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Number", false);
		
		RC_Global.createNode(driver, "Validate buttons");
		RC_Global.verifyScreenComponents(driver, "button", "Generate Report", false);
		RC_Global.verifyScreenComponents(driver, "button", "Excel", false);
		RC_Global.verifyScreenComponents(driver, "button", "CSV", false);
		RC_Global.verifyScreenComponents(driver, "button", "PDF", false);
		RC_Global.verifyScreenComponents(driver, "button", "XML", false);
		RC_Global.verifyScreenComponents(driver, "button", "Edit Columns", false);
		
		if(driver.findElements(By.xpath("//label[text()='Historical report values not available at this time.']")).size()>0)
			queryObjects.logStatus(driver, Status.PASS, "Verify message on Historical Date for From Date filter is displayed", "Message on Historical Date for From Date filter is displayed", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify message on Historical Date for From Date filter is displayed", "Message on Historical Date for From Date filter is not displayed", null);
		
		WebElement fromDateElement = driver.findElement(By.xpath("//input[@id='dateTimeField_From Date']"));
		WebElement toDateElement = driver.findElement(By.xpath("//input[@id='dateTimeField_To Date']"));
		
		String fromDate = RC_Global.getDateTime(driver, "MM/dd/yyyy", -5, true);
		String toDate = RC_Global.getDateTime(driver, "MM/dd/yyyy", 0, true);
		RC_Global.enterInput(driver, fromDate, fromDateElement, true, true);
		RC_Global.enterInput(driver, toDate, toDateElement, true, true);
		
		RC_Global.enterCustomerNumber(driver, cusno, "", "", true);
		RC_Global.clickButton(driver, "Generate Report", true, true);
		RC_Reporting.reportErrorValidation(driver, "//h4[text()='From Date required to be current date or future date.']");
		
		fromDate = RC_Global.getDateTime(driver, "MM/dd/yyyy", 0, true);
		toDate = RC_Global.getDateTime(driver, "MM/dd/yyyy", 370, true);
		RC_Global.enterInput(driver, fromDate, fromDateElement, true, true);
		RC_Global.enterInput(driver, toDate, toDateElement, true, true);
		
		String fDDate= fromDate.split("/")[1].split("")[0];
		String tDDate= toDate.split("/")[1].split("")[0];
		
		String fDMonth= fromDate.split("/")[0].split("")[0];
		String tDMonth= toDate.split("/")[0].split("")[0];
		
		if(fDDate.equalsIgnoreCase("0")&& !fDMonth.equalsIgnoreCase("0"))fromDate = RC_Global.getDateTime(driver, "MM/d/yyyy", 0, true);
		else if(!fDDate.equalsIgnoreCase("0")&& fDMonth.equalsIgnoreCase("0"))fromDate = RC_Global.getDateTime(driver, "M/dd/yyyy", 0, true);
		else if(fDDate.equalsIgnoreCase("0")&& fDMonth.equalsIgnoreCase("0"))fromDate = RC_Global.getDateTime(driver, "M/d/yyyy", 0, true);
		
		if(tDDate.equalsIgnoreCase("0")&& !tDMonth.equalsIgnoreCase("0"))toDate = RC_Global.getDateTime(driver, "MM/d/yyyy", 370, true);
		else if(!tDDate.equalsIgnoreCase("0")&& tDMonth.equalsIgnoreCase("0"))toDate = RC_Global.getDateTime(driver, "M/dd/yyyy", 370, true);
		else if(tDDate.equalsIgnoreCase("0")&& tDMonth.equalsIgnoreCase("0"))toDate = RC_Global.getDateTime(driver, "M/d/yyyy", 370, true);
		
		RC_Reporting.generateReportValidateResults(driver);
		RC_Global.waitElementVisible(driver, 60, "//td[@id='oReportCell']", "Report Results Grid",true, false);
		
		RC_Global.createNode(driver, "Validate Lease Projection Report");
		if(driver.findElement(By.xpath("(//tr[@valign='top']/td/div)[1]")).getText().equalsIgnoreCase("Lease Projection Report")) {
			queryObjects.logStatus(driver, Status.PASS, "Verify Lease Projection Report table is present", "The table is present", null);
			if(driver.findElement(By.xpath("//tr[td[div[text()='Client:']]]/td[2]/div")).getText().contains(cusno))
				queryObjects.logStatus(driver, Status.PASS, "Verify Customer Number is displayed against the 'Client'", "Verification Successful", null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify Customer Number is displayed against the 'Client'", "Verification not Successful", null);
			
			if(driver.findElement(By.xpath("//tr[td[div[text()='Interest Type:']]]/td[2]/div")).getText().contains("Fixed"))
				queryObjects.logStatus(driver, Status.PASS, "Verify the value is displayed against the 'Interest Type'", "Verification Successful", null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify the value is displayed against the 'Interest Type'", "Verification not Successful", null);
			
			if(driver.findElement(By.xpath("//tr[td[div[text()='Depreciation Type:']]]/td[2]/div")).getText().contains("Level Pay"))
				queryObjects.logStatus(driver, Status.PASS, "Verify the value is displayed against the 'Depreciation Type'", "Verification Successful", null);
			else
				queryObjects.logStatus(driver, Status.FAIL, "Verify the value is displayed against the 'Depreciation Type'", "Verification not Successful", null);
		}
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Lease Projection Report table is present", "The table is not present", null);
		
		Thread.sleep(2000);
		List<WebElement> tables = driver.findElements(By.xpath("//tr[td[div[table]]][@valign]/td[1]/div//td[1]"));
		String[] tableCompare = {"Year", "Total Spend by Month", "Principal by Month", "Interest by Month", "Admin by Month"};
		
		
		boolean flag = false;
		for(int iter=0; iter<tableCompare.length;iter++) {
			flag=false;
			for(WebElement tl: tables) {
				
				if(tl.getText().equalsIgnoreCase(tableCompare[iter])) {
					queryObjects.logStatus(driver, Status.INFO, "Validate the table containing "+tableCompare[iter], "The table is present as expected", null);
					flag = true;
					break;
				}
			}
			if(!flag)
				queryObjects.logStatus(driver, Status.FAIL, "Validate the table containing "+tableCompare[iter], "The table does not exist", null);
		
		}
		
		RC_Reporting.validateReportColumnNames(driver, "Year;Principal;Interest;Admin;Total");
		flag = true;
		for(int iter=1; iter<=4;iter++) {
			String XPath = "(//tr[td[div[table]]][@valign])["+(iter+1)+"]/td/div//td[1]";
			List<WebElement> columnNamesTable = driver.findElements(By.xpath(XPath));
			String[] expColName = {tableCompare[iter], "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
			for(int i=0; i<expColName.length; i++) {
				try {
					driver.findElement(By.xpath(XPath+"[text()='"+expColName[i]+"']"));				
				}
				catch(Exception e) {
					queryObjects.logStatus(driver, Status.FAIL, "Validate Report Column Names--->Column: " + expColName[i] + "--->Was NOT Found", e.getLocalizedMessage(), e);
					flag = false;
				}
			}
			if(flag)
				queryObjects.logStatus(driver, Status.PASS, "Validate Report"," Column Names", null);
			
		}
		
		RC_Global.clickUsingXpath(driver, "//button[@ng-click='nextReportPage()']", "Navigate to next page", true, false);
		RC_Global.waitElementNotVisible(driver, 30, "//div[@ng-show='executingReport']/i", "Spinner", true, false);
		RC_Reporting.validateReportColumnNames(driver, "Unit;Year;Principal Total;Interest Total;Admin Total;Total");
		
		String pageNumber = driver.findElement(By.xpath("//div[button[@ng-click='nextReportPage()']]")).getText().trim().split(" ")[3];
		int page = Integer.parseInt(pageNumber);
		boolean pageFlag = false;
		for(int j=3;j<=page;j++) {
			if(RC_Reporting.waitElementVisible(driver, 3, "//td[text()='Customer Number']", "Final Grid", false, false)==true){
				pageFlag=true;
				break;
			}
			driver.findElement(By.xpath("//button[@ng-click='nextReportPage()']")).click();
			RC_Global.waitElementNotVisible(driver, 30, "//div[@ng-show='executingReport']/i", "Spinner", true, false);
		}
		if(!pageFlag) {
			
			RC_Global.endTestRun(driver);
		}
		RC_Reporting.validateReportColumnNames(driver, columnNames);
		
		RC_Reporting.downloadAndVerifyFileDownloaded(driver, "Lease Projection Report_LS007656", "Excel download", false);
		
		RC_Reporting.reportParametersNavigate(driver);
		RC_Reporting.validateCustomerNumberParamData(driver, cusno);
		RC_Reporting.validateReportParameterData(driver, "From Date", fromDate);
		RC_Reporting.validateReportParameterData(driver, "To Date", toDate);
		RC_Reporting.validateReportParameterData(driver, "Agreement Type", "Closed End, Open End");
		
		RC_Reporting.panelAction(driver, "close", "Lease Projection Report", true, true);
		RC_Global.logout(driver, true);
		
	}
}
