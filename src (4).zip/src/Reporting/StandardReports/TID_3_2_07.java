package Reporting.StandardReports;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_2_07 {
	public static void StandardReports_VerifyMaintenanceHistorySummarySearchFunctionalityAndUIExceptions(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		RC_Global.login(driver);
		
		String columnClientData = RC_Reporting.retrieveClientData(driver, "LS008742", 7);
		
		String columnNames = "Customer Name;Customer Number;Unit Number;CVN;VIN;Year;Make;Model;Trim;Body;Drive;Color;Driver Type;Driver/Pool;Pool Contact;Vehicle Status;Delivered Date;Months In Service;Months Enrolled;Current Odometer;Maintenance Agreement Type;Service Date;Repair Mileage;PO Number;PO Status;Cost;Cost Savings;Vendor Name;Preferred Vendor;"+columnClientData+";Employee Data 1;Employee Data 2;Employee Data 3;Fleet Number;Fleet Name;Account Number;Account Name;Sub-Account Number;Sub-Account Name";
		
		RC_Reporting.navigateTo(driver, "Reporting", "Standard Reports", "Maintenance History Summary");
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);
		
		RC_Global.createNode(driver, "Verify Search Filters");
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Unit Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Vehicle Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Driver Name", false);
		RC_Global.verifyScreenComponents(driver, "lable", "VIN", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Value", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Value", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Vehicle Status", false);
		RC_Global.verifyScreenComponents(driver, "lable", "From Date", false);
		RC_Global.verifyScreenComponents(driver, "lable", "To Date", false);
		RC_Global.verifyScreenComponents(driver, "lable", "PO Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Preferred Vendor", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Maintenance Agreement Type", false);
		
		RC_Global.createNode(driver, "Validate buttons");
		RC_Global.verifyScreenComponents(driver, "button", "Generate Report", false);
		RC_Global.verifyScreenComponents(driver, "button", "Excel", false);
		RC_Global.verifyScreenComponents(driver, "button", "CSV", false);
		RC_Global.verifyScreenComponents(driver, "button", "PDF", false);
		RC_Global.verifyScreenComponents(driver, "button", "XML", false);
		RC_Global.verifyScreenComponents(driver, "button", "Edit Columns", false);
		
		RC_Global.dropdownValuesValidation(driver, "Y;N", "//div[label[text()='Preferred Vendor:']]//select", true, true);
		String fromDate = driver.findElement(By.xpath("//div[label[text()='From Date:']]//input")).getAttribute("value");
		String toDate = driver.findElement(By.xpath("//div[label[text()='To Date:']]//input")).getAttribute("value");
		
		String fDDate= fromDate.split("/")[1].split("")[0];
		String tDDate= toDate.split("/")[1].split("")[0];
		
		String fDMonth= fromDate.split("/")[0].split("")[0];
		String tDMonth= toDate.split("/")[0].split("")[0];
		
		if(fDDate.equalsIgnoreCase("0")&& !fDMonth.equalsIgnoreCase("0"))fromDate = RC_Global.getDateTime(driver, "MM/d/yyyy", -365, true);
		else if(!fDDate.equalsIgnoreCase("0")&& fDMonth.equalsIgnoreCase("0"))fromDate = RC_Global.getDateTime(driver, "M/dd/yyyy", -365, true);
		else if(fDDate.equalsIgnoreCase("0")&& fDMonth.equalsIgnoreCase("0"))fromDate = RC_Global.getDateTime(driver, "M/d/yyyy", -365, true);
		
		if(tDDate.equalsIgnoreCase("0")&& !tDMonth.equalsIgnoreCase("0"))toDate = RC_Global.getDateTime(driver, "MM/d/yyyy", 0, true);
		else if(!tDDate.equalsIgnoreCase("0")&& tDMonth.equalsIgnoreCase("0"))toDate = RC_Global.getDateTime(driver, "M/dd/yyyy", 0, true);
		else if(tDDate.equalsIgnoreCase("0")&& tDMonth.equalsIgnoreCase("0"))toDate = RC_Global.getDateTime(driver, "M/d/yyyy", 0, true);
		
		String sVehicleStatus = "Active lease, Active services only, Pending termination";
        String sMaintenanceAgreementType = "Full, Administered, Reserve, Any";
		
		
		RC_Global.clickButton(driver, "Generate Report", true, true);
		
		RC_Reporting.reportErrorValidation(driver,"//h4[text()='Customer Number is required']");
		
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		RC_Reporting.generateReportValidateResults(driver);
		
		RC_Global.waitElementVisible(driver, 60, "((//tbody//tbody)[1]/tr[@valign])[1]", "First Row Column", true, false);
		RC_Reporting.validateReportColumnNames(driver, columnNames);
		
		RC_Reporting.verifySortFunction(driver, "Unit Number",true);
		RC_Reporting.verifySortFunction(driver, "Year",true);
		
		RC_Reporting.clickReportCellHyperLink(driver, "Unit Number", "Vehicle Details");
		RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
		RC_Reporting.panelAction(driver, "expand", "Maintenance History Summary",false, false);
		
		RC_Reporting.verifySortFunction(driver, "CVN",false);
		if(driver.findElements(By.xpath("((//tbody//tbody)[1]/tr[@valign]/td[4]//a[@style and text()])[1]")).size()>0) {
			RC_Reporting.clickReportCellHyperLink(driver, "CVN", "Vehicle Details");
			RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
			RC_Reporting.panelAction(driver, "expand", "Maintenance History Summary",false, false);
		}
		
		RC_Reporting.clickReportCellHyperLink(driver, "Driver/Pool", "Driver Details");
		RC_Reporting.panelAction(driver, "close", "Driver Details",false, false);
		RC_Reporting.panelAction(driver, "expand", "Maintenance History Summary",false, false);
		
		RC_Reporting.downloadAndVerifyFileDownloaded(driver, "Maintenance History Summary_LS008742", "Excel button - Download validation", true);
		
		RC_Reporting.reportParametersNavigate(driver);
		RC_Reporting.validateCustomerNumberParamData(driver, "LS008742");
		RC_Reporting.validateReportParameterData(driver, "Vehicle Status", sVehicleStatus);
		RC_Reporting.validateReportParameterData(driver, "Maintenance Agreement Type", sMaintenanceAgreementType);
		RC_Reporting.validateReportParameterData(driver, "From Date", fromDate+" 12:00:00 AM");
		RC_Reporting.validateReportParameterData(driver, "To Date", toDate+" 12:00:00 AM");
		
		RC_Reporting.panelAction(driver, "close", "Maintenance History Summary", true, true);
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
