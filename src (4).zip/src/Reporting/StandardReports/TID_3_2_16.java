package Reporting.StandardReports;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_2_16 {
	
	
	public static void StandardReports_VerifyPreferredVendorUtilizationsearchfunctionality(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
			
		
		

			WebDriverWait wait = new WebDriverWait(driver,50);
			
			RC_Global.login(driver);
			String columnClientData = RC_Reporting.retrieveClientData(driver, "LS008742", 7);
			
			RC_Reporting.navigateTo(driver, "Reporting", "Standard Reports", "Preferred Vendor Utilization");
			RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);
	     
        
	        String ColumnNames="Customer Name;"
	        	    + "Customer Number;"
	        		+ "Unit Number;CVN;VIN;Year;"
	        		+ "Make;Model;Trim;Body;Drive;Color;Driver Type;"
	        		+ "Driver/Pool;Pool Contact;Vehicle Status;Included PO;"
	        		+ "Delivered Date;Months In Service;Months Enrolled;"
	        		+ "Current Odometer;Maintenance Agreement Type;"
	        		+ "Total # of Services;# of Preferred Vendor Services;"
	        		+ "# of Independent Vendor Services;Preferred Account Usage %;"
	        		+ columnClientData+";"
	        		+ "Employee Data 1;Employee Data 2;Employee Data 3;Fleet Number;Fleet Name;"
	        		+ "Account Number;Account Name;Sub-Account Number;Sub-Account Name";
	        
	        RC_Global.createNode(driver, "Verify Search Filters");
			RC_Global.verifyScreenComponents(driver, "lable", "Customer Number:", false);
			RC_Global.verifyScreenComponents(driver, "lable", "Unit Number:", false); 
			RC_Global.verifyScreenComponents(driver, "lable", "From Date:", false);
			RC_Global.verifyScreenComponents(driver, "lable", "To Date:", false);
	
			
			RC_Global.verifyScreenComponents(driver, "lable", "Customer Vehicle Number:", false);
			RC_Global.verifyScreenComponents(driver, "lable", "Included PO's:", false);
			
			RC_Global.verifyScreenComponents(driver, "lable", "VIN:", false);//5. VIN
			RC_Global.verifyScreenComponents(driver, "lable", "Driver Name:", false);//4. Driver Name
			RC_Global.verifyScreenComponents(driver, "lable", "Client Data Number:", false);//7. Client Data Number
			RC_Global.verifyScreenComponents(driver, "lable", "Client Data Value:", false);//6. Client Data Value
			RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Number:", false);//9. Exclude Client Data Number
			RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Value:", false);//8. Exclude Client Data Value
			RC_Global.verifyScreenComponents(driver, "lable", "Maintenance Agreement Type:", false);//10. Lease Type
			RC_Global.verifyScreenComponents(driver, "lable", "Vehicle Status:", false);//11. Vehicle Status (Mandatory)
			
			
			RC_Global.createNode(driver, "Validate buttons");
			RC_Global.verifyScreenComponents(driver, "button", "Generate Report", false);
			RC_Global.verifyScreenComponents(driver, "button", "Excel", false);
			RC_Global.verifyScreenComponents(driver, "button", "CSV", false);
			RC_Global.verifyScreenComponents(driver, "button", "PDF", false);
			RC_Global.verifyScreenComponents(driver, "button", "XML", false);
			RC_Global.verifyScreenComponents(driver, "button", "Edit Columns", false);
			
			
		   RC_Global.dropdownValuesValidation(driver, "All;Closed", "//label[contains(text(),'Included PO')]/following-sibling::div//select", true, true);
	     String sVehicleStatus = "Active lease, Active services only, Pending termination";
		String sMaintenanceAgreementType = "Full, Administered, Reserve";
			
			 String includedPO = driver.findElement(By.xpath("//label[contains(text(),'Included PO')]/following-sibling::div//select/option[@selected]")).getText();
						
		
			
	        
			RC_Global.waitElementVisible(driver, 10, "//input[@name='customerInput']", "Input CustomerNumber",true, true);
			
			
			RC_Global.enterCustomerNumber(driver, "LS008742", "", "",true);
			
			
			
			
			RC_Reporting.generateReportValidateResults(driver);
			
			RC_Reporting.validateReportColumnNames(driver, ColumnNames);
			

			
			
			 Thread.sleep(4000);
			 
			 RC_Reporting.verifySortFunction(driver, "Unit Number", true);
			 
			 RC_Reporting.clickReportCellHyperLink(driver, "Unit Number", "Vehicle Details");
			 RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
			 RC_Reporting.panelAction(driver, "expand", "Preferred Vendor Utilization",false, false);
		 
			 RC_Reporting.verifySortFunction(driver, "CVN", true);
		 
		 if(driver.findElements(By.xpath("((//tbody//tbody)[1]/tr[@valign]/td[4]//a[@style and text()])[1]")).size()>0) {
				   RC_Reporting.clickReportCellHyperLink(driver, "CVN", "Vehicle Details");
				   RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
				   RC_Reporting.panelAction(driver, "expand", "Preferred Vendor Utilization",false, false);
			   }
			  
			 Thread.sleep(4000);
			 
			 RC_Reporting.verifySortFunction(driver, "Driver/Pool",true);
			 
				RC_Reporting.clickReportCellHyperLink(driver, "Driver/Pool", "Driver Details");
				RC_Reporting.panelAction(driver, "close", "Driver Details",false, false);
				RC_Reporting.panelAction(driver, "expand", "Preferred Vendor Utilization",false, false);
				 Thread.sleep(4000);
				
				
				 
				 RC_Reporting.downloadAndVerifyFileDownloaded(driver, "Preferred Vendor Utilization_LS008742", "Excel button - Download validation", true);
			
		      
					
					RC_Reporting.reportParametersNavigate(driver);
					
					RC_Reporting.validateCustomerNumberParamData(driver, "LS008742");
					
					RC_Reporting.validateReportParameterData(driver, "Included PO\'s", includedPO);
					
					Thread.sleep(4000);
				
					RC_Reporting.validateReportParameterData(driver, "Vehicle Status", sVehicleStatus);
					
					Thread.sleep(4000);
				

					RC_Reporting.validateReportParameterData(driver, "Maintenance Agreement Type", sMaintenanceAgreementType);
					
					Thread.sleep(3000);
        		    RC_Global.logout(driver, false);

}
			}
	
	

