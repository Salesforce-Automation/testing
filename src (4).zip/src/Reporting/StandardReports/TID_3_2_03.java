package Reporting.StandardReports;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_2_03 {
	public static void StandardReports_VerifyUnitsOnLeaseSearchFunctionalityAndUIExceptions(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		
		RC_Global.login(driver);
		
		String columnClientData = RC_Reporting.retrieveClientData(driver, "LS008742", 7);
		
		String columnNames = "Customer Name;Customer Number;Unit Number;CVN;VIN;Year;Make;Model;Trim;Body;Drive;Color;Driver Type;Driver/Pool;Pool Contact;Vehicle Address;Vehicle Address 2;Vehicle City;Vehicle State;Vehicle Zip Code;Vehicle County;Vehicle Country;Delivered Date;In Service Date;Vehicle Status;Months In Service;Months Billed;Current Odometer;Lease Type;Last Month;Original Cost;Book Value;Book Depreciation Rate;Open End Amortization Months;Closed End Term Months;End of Term Date;Days to End of Term;"+columnClientData+";Employee Data 1;Employee Data 2;Employee Data 3;Assigned Date;Fleet Number;Fleet Name;Account Number;Account Name;Sub-account Number;Sub-account Name";
		
		RC_Reporting.navigateTo(driver, "Reporting", "Standard Reports", "Units On Lease");
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);
		
		RC_Global.createNode(driver, "Verify Search Filters");
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Number", false);//Customer Number (Mandatory)
		RC_Global.verifyScreenComponents(driver, "lable", "Unit Number", false);//		2. Unit Number
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Vehicle Number", false);//3. Customer Vehicle Number
		RC_Global.verifyScreenComponents(driver, "lable", "Driver Name", false);//4. Driver Name
		RC_Global.verifyScreenComponents(driver, "lable", "VIN", false);//5. VIN
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Value", false);//6. Client Data Value
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Number", false);//7. Client Data Number
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Value", false);//8. Exclude Client Data Value
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Number", false);//9. Exclude Client Data Number
		RC_Global.verifyScreenComponents(driver, "lable", "Lease Type", false);//10. Lease Type
		RC_Global.verifyScreenComponents(driver, "lable", "Vehicle Status", false);//11. Vehicle Status (Mandatory)
		
		RC_Global.createNode(driver, "Validate buttons");
		RC_Global.verifyScreenComponents(driver, "button", "Generate Report", false);
		RC_Global.verifyScreenComponents(driver, "button", "Excel", false);
		RC_Global.verifyScreenComponents(driver, "button", "CSV", false);
		RC_Global.verifyScreenComponents(driver, "button", "PDF", false);
		RC_Global.verifyScreenComponents(driver, "button", "XML", false);
		RC_Global.verifyScreenComponents(driver, "button", "Edit Columns", false);
		
		RC_Global.dropdownValuesValidation(driver, "Open End;Closed End", "//div[label[text()='Lease Type:']]//select", true, true);
		
		String sVehicleStatus = "Active lease, Active services only, Pending termination";
		
		RC_Global.clickButton(driver, "Generate Report", true, true);
		
		RC_Reporting.reportErrorValidation(driver,"//h4[text()='Customer Number is required']");
		
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		RC_Reporting.generateReportValidateResults(driver);
		
		RC_Global.waitElementVisible(driver, 30, "((//tbody//tbody)[1]/tr[@valign])[1]", "First Row Column", true, false);
		RC_Reporting.validateReportColumnNames(driver, columnNames);
		
		RC_Reporting.verifySortFunction(driver, "Unit Number", true);
		RC_Reporting.verifySortFunction(driver, "Year", true);
		RC_Reporting.verifySortFunction(driver, "Driver/Pool", true);
		
		RC_Reporting.clickReportCellHyperLink(driver, "Unit Number", "Vehicle Details");
		RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
		RC_Reporting.panelAction(driver, "expand", "Units On Lease",false, false);
		
		RC_Reporting.verifySortFunction(driver, "CVN", false);
		if(driver.findElements(By.xpath("((//tbody//tbody)[1]/tr[@valign]/td[4]//a[@style and text()])[1]")).size()>0) {
			RC_Reporting.clickReportCellHyperLink(driver, "CVN", "Vehicle Details");
			RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
			RC_Reporting.panelAction(driver, "expand", "Units On Lease",false, false);
		}
		
		RC_Reporting.clickReportCellHyperLink(driver, "Driver/Pool", "Driver Details");
		RC_Reporting.panelAction(driver, "close", "Driver Details",false, false);
		RC_Reporting.panelAction(driver, "expand", "Units On Lease",false, false);
		
		RC_Reporting.downloadAndVerifyFileDownloaded(driver, "Units On Lease_LS008742", "Excel button - Download validation", true);
		
		RC_Reporting.reportParametersNavigate(driver);
		RC_Reporting.validateCustomerNumberParamData(driver, "LS008742");
		RC_Reporting.validateReportParameterData(driver, "Vehicle Status", sVehicleStatus);

		RC_Reporting.panelAction(driver, "close", "Units On Lease", true, true);
		RC_Global.logout(driver, true);
	}
}
