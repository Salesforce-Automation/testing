package Reporting.StandardReports;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_2_13 {
	public void StandardReport_VerifyUnderUtilizedVehiclesSearchFunctionality(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
		
		
		
		RC_Global.login(driver);
		
		String columnClientData = RC_Reporting.retrieveClientData(driver, "LS008742", 16);
		
		RC_Reporting.navigateTo(driver, "Reporting", "Standard Reports", "Under Utilized Vehicles");
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);
		
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Unit Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Vehicle Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Driver Name", false);
		RC_Global.verifyScreenComponents(driver, "lable", "From Date", false);
		RC_Global.verifyScreenComponents(driver, "lable", "To Date", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Total Miles Accumulated Less Than", false);
		RC_Global.verifyScreenComponents(driver, "lable", "VIN", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Value", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Value", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Number", false);
		
		
		RC_Global.buttonStatusValidation(driver, "Generate Report", "Enable", false);
		RC_Global.buttonStatusValidation(driver, "Excel", "Enable", false);
		RC_Global.buttonStatusValidation(driver, "CSV", "Enable", false);
		RC_Global.buttonStatusValidation(driver, "PDF", "Enable", false);
		RC_Global.buttonStatusValidation(driver, "XML", "Enable", false);
		RC_Global.buttonStatusValidation(driver, "Edit Columns", "Enable", false);
		
		String fromDate = driver.findElement(By.xpath("//div[label[text()='From Date:']]//input")).getAttribute("value");
		String toDate = driver.findElement(By.xpath("//div[label[text()='To Date:']]//input")).getAttribute("value");
		
		String fDDate= fromDate.split("/")[1].split("")[0];
		String tDDate= toDate.split("/")[1].split("")[0];
		
		String fDMonth= fromDate.split("/")[0].split("")[0];
		String tDMonth= toDate.split("/")[0].split("")[0];
		
		if(fDDate.equalsIgnoreCase("0")&& !fDMonth.equalsIgnoreCase("0"))fromDate = RC_Global.getDateTime(driver, "MM/d/yyyy", -365, true);
		else if(!fDDate.equalsIgnoreCase("0")&& fDMonth.equalsIgnoreCase("0"))fromDate = RC_Global.getDateTime(driver, "M/dd/yyyy", -365, true);
		else if(fDDate.equalsIgnoreCase("0")&& fDMonth.equalsIgnoreCase("0"))fromDate = RC_Global.getDateTime(driver, "M/d/yyyy", -365, true);
		
		if(tDDate.equalsIgnoreCase("0")&& !tDMonth.equalsIgnoreCase("0"))toDate = RC_Global.getDateTime(driver, "MM/d/yyyy", 0, true);
		else if(!tDDate.equalsIgnoreCase("0")&& tDMonth.equalsIgnoreCase("0"))toDate = RC_Global.getDateTime(driver, "M/dd/yyyy", 0, true);
		else if(tDDate.equalsIgnoreCase("0")&& tDMonth.equalsIgnoreCase("0"))toDate = RC_Global.getDateTime(driver, "M/d/yyyy", 0, true);
		
		RC_Global.waitElementVisible(driver, 10, "//input[@name='customerInput']", "Input CustomerNumber",true,true);
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "",true);
        RC_Reporting.generateReportValidateResults(driver);
        RC_Reporting.validateReportColumnNames(driver, "Customer Name;Customer Number;Unit Number;CVN;VIN;Year;Make;Model;Trim;Body;Drive;Color;Driver Type;Driver/Pool;Pool Contact;Driver State;Driver County;Delivered Date;Current Odometer Reading;Beginning Odometer Date;Beginning Odometer Reading;Ending Odometer Date;Ending Odometer Reading;Total Accumulated Miles;"+columnClientData+";Employee Data 1;Employee Data 2;Employee Data 3;"
        		+  "Fleet Number;Fleet Name;Account Number;Account Name;Sub-Account Number;Sub-Account Name");

        RC_Reporting.verifySortFunction(driver, "Unit Number", false);
		RC_Reporting.verifySortFunction(driver, "Year", false);
		
		
		
			RC_Reporting.clickReportCellHyperLink(driver, "Unit Number", "Vehicle Details");
			RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
			RC_Reporting.panelAction(driver, "expand", "Under Utilized Vehicles",false, false);
			

			RC_Reporting.verifySortFunction(driver, "CVN", false);
			if(driver.findElements(By.xpath("((//tbody//tbody)[1]/tr[@valign]/td[4]//a[@style and text()])[1]")).size()>0) {
				RC_Reporting.clickReportCellHyperLink(driver, "CVN", "Vehicle Details");
				RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
				RC_Reporting.panelAction(driver, "expand", "Under Utilized Vehicles",false, false);
			}
			
			RC_Reporting.clickReportCellHyperLink(driver, "Driver/Pool", "Driver Details");
			RC_Reporting.panelAction(driver, "close", "Driver Details",false, false);
			RC_Reporting.panelAction(driver, "expand", "Under Utilized Vehicles",false, false);
			
			RC_Reporting.reportParametersNavigate(driver);
//			RC_Reporting.validateCustomerNumberParamData(driver, "LS008742", "");
			RC_Reporting.validateReportParameterData(driver, "Report Date Range", "Use Date Range");
			RC_Reporting.validateReportParameterData(driver, "From Date", fromDate+" 12:00:00 AM");
			RC_Reporting.validateReportParameterData(driver, "To Date", toDate+" 12:00:00 AM");
			
			RC_Reporting.downloadAndVerifyFileDownloaded(driver, "Under Utilized Vehicles_LS008742", "Downloading Standard Report Validation", false);

			RC_Global.logout(driver, true);
		
	}

}
