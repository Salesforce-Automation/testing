package Reporting.StandardReports;

import org.openqa.selenium.WebDriver;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_2_09 {
	public static void StandardReports_VerifyEmployeeDetailsSearchFunctionalityAndUIExceptions(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{

		
		RC_Global.login(driver);
        
		RC_Reporting.navigateTo(driver, "Reporting", "Standard Reports", "Employee Details");
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);
		
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Number:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "First Name:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Last Name:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "State:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Employee ID:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Status:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Distribution Method:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Fuel Driver:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Enrolled in Personal Use:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Enrolled in Driver Ordering:", false);
	
		
		RC_Global.verifyScreenComponents(driver, "button", "Excel", false);
		RC_Global.verifyScreenComponents(driver, "button", "CSV", false);
		RC_Global.verifyScreenComponents(driver, "button", "PDF", false);
		RC_Global.verifyScreenComponents(driver, "button", "XML", false);
		RC_Global.verifyScreenComponents(driver, "button", "Edit Columns", false);
		
        RC_Global.dropdownValuesValidation(driver, "Active;Inactive", "(//select[@ng-model='param.ParameterValue'])[2]", false, true);    
        
        RC_Global.dropdownValuesValidation(driver, "Email;Text Message;Email & Text Message", "(//select[@ng-model='param.ParameterValue'])[3]", false, true);    

        RC_Global.dropdownValuesValidation(driver, "Yes;No;All", "(//select[@ng-model='param.ParameterValue'])[4]", false, true);    

        RC_Global.dropdownValuesValidation(driver, "Yes;No;All", "(//select[@ng-model='param.ParameterValue'])[5]", false, true);    

        RC_Global.dropdownValuesValidation(driver, "Yes;No;All", "(//select[@ng-model='param.ParameterValue'])[6]", false, true);    

        RC_Global.clickButton(driver, "Generate Report", false, true);
        RC_Reporting.reportErrorValidation(driver, "//h4[text()='Customer Number is required']");
        
        RC_Global.waitElementVisible(driver, 60, "//input[@name='customerInput']", "Input CustomerNumber",true, true);		
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "",true);
		
		RC_Reporting.generateReportValidateResults(driver);

		Thread.sleep(4000);
		
		RC_Reporting.validateReportColumnNames(driver,"Customer Name;Customer Number;First Name;Last Name;Residential Address 1;Residential Address 2;City;State;Zip;Cell Phone;Work Phone;"
				+ "Extension;Home Phone;Contact Type;Employee ID;Email;Status;Distribution Method;Employee Data Field 1;Employee Assignment;Enrolled in Fuel;Fuel Driver ID;Enrolled in Personal Use;Enrolled in Driver Ordering;User Name;Associated Units");
		
		Thread.sleep(3000);
		
		RC_Reporting.verifySortFunction(driver, "First Name", true);
		RC_Reporting.verifySortFunction(driver, "City", true);

		
		
		RC_Reporting.downloadAndVerifyFileDownloaded(driver, "Employee Details", "Downloading Standard Report Validation", false);
		
		Thread.sleep(3000);

		RC_Reporting.reportParametersNavigate(driver);
		RC_Reporting.validateCustomerNumberParamData(driver, "LS008742");
			
		RC_Reporting.panelAction(driver, "close", "Employee Details", false, true);
		RC_Global.logout(driver, true);
	}

}
