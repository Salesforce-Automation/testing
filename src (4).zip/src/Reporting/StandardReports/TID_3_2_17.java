package Reporting.StandardReports;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_2_17 {
	public static void StandardReports_VerifyAssignedServiceIntervalsSearchFunctionality(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{

		
RC_Global.login(driver);
        
	RC_Reporting.navigateTo(driver, "Reporting", "Standard Reports", "Assigned Service Intervals");
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);

		RC_Global.verifyScreenComponents(driver, "lable", "Customer Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Unit Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Year", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Model", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Segment Not Assigned", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Make", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Segment", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Service Not Assigned:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Service", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Rule Level", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Rule Type", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Vehicle Status", false);
		
		
		RC_Global.verifyScreenComponents(driver, "button", "Excel", false);
		RC_Global.verifyScreenComponents(driver, "button", "CSV", false);
		RC_Global.verifyScreenComponents(driver, "button", "PDF", false);
		RC_Global.verifyScreenComponents(driver, "button", "XML", false);
		RC_Global.verifyScreenComponents(driver, "button", "Edit Columns", false);
		
		
        RC_Global.dropdownValuesValidation(driver, "Yes;No", "(//select[@ng-model='param.ParameterValue'])[1]", false, true);    
        
        RC_Global.dropdownValuesValidation(driver, "Yes;No", "(//select[@ng-model='param.ParameterValue'])[3]", false, true);   
        
        RC_Global.dropdownValuesValidation(driver, "Customer;Portfolio", "(//select[@ng-model='param.ParameterValue'])[4]", false, true); 
        
        RC_Global.dropdownValuesValidation(driver, "Segment;Unit;Year/Make/Model", "(//select[@ng-model='param.ParameterValue'])[5]", false, true); 

//        String segmentNotAssigned = driver.findElement(By.xpath("//div[label[text()='Segment Not Assigned:']]//select/option[@selected]")).getText();
//        String serviceNotAssigned = driver.findElement(By.xpath("//div[label[text()='Service Not Assigned:']]//select/option[@selected]")).getText();
//        
        RC_Global.waitElementVisible(driver, 60, "//input[@name='customerInput']", "Input CustomerNumber",true, true);		
      	RC_Global.enterCustomerNumber(driver, "LS008742", "", "",true);
      		
      		RC_Reporting.generateReportValidateResults(driver);
      		Thread.sleep(4000);
      		
      		RC_Reporting.validateReportColumnNames(driver,"Customer Name;Customer Number;Fleet Number;Account Number;Account Name;Sub-Account Number;Sub-Account Name;"
      				+ "Segment;Unit #;Rule Level;Rule Type;Service;Miles Value;Days Value;Year;Make;Model;VIN;Vehicle Status");
      		
      		Thread.sleep(4000);
      		
      		RC_Reporting.verifySortFunction(driver, "Unit #", true);
    		RC_Reporting.verifySortFunction(driver, "Rule Level", true);
    		
    		RC_Reporting.clickReportCellHyperLink(driver, "Unit #", "Vehicle Details");
    		RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
    		RC_Reporting.panelAction(driver, "expand", "Assigned Service Intervals",false, false);
    		
    		RC_Reporting.clickReportCellHyperLink(driver, "Rule Level", "");
    		RC_Reporting.panelAction(driver, "close", "",false, false);
    		RC_Reporting.panelAction(driver, "expand", "Assigned Service Intervals",false, false);
    		
    		RC_Reporting.downloadAndVerifyFileDownloaded(driver, "Assigned Service Intervals_LS008742", "Downloading Standard Report Validation", false);

    		RC_Reporting.reportParametersNavigate(driver);
			
			RC_Reporting.validateCustomerNumberParamData(driver, "LS008742");
			
			RC_Reporting.validateReportParameterData(driver, "Segment Not Assigned", "No");

			RC_Reporting.validateReportParameterData(driver, "Service Not Assigned", "No");
			
			RC_Reporting.validateReportParameterData(driver, "Vehicle Status", "Active lease;Active services only;Pending termination;On Order;Pending Activation");

			RC_Reporting.panelAction(driver, "close", "Assigned Service Intervals", false, true);

			RC_Global.logout(driver, true);
	}


}
