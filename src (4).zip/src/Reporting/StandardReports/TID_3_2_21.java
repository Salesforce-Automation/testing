package Reporting.StandardReports;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;


public class TID_3_2_21 {
	
	public void DriverChange_HistoryDetail_Report(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
		
		WebDriverWait wait = new WebDriverWait(driver,50);
		
		RC_Global.login(driver);
		
		RC_Reporting.navigateTo(driver, "Reporting", "Standard Reports", "Driver Change History Detail");
		
		RC_Global.waitElementVisible(driver, 10, "//input[@name='customerInput']", "Input CustomerNumber",true, true);
		
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "",true);
		
		RC_Reporting.generateReportValidateResults(driver);
		
		RC_Reporting.validateReportColumnNames(driver, "Customer Name;Customer Number;Unit Number;CVN;VIN;Year;Make;"
				+ "Model;Trim;Body;Drive;Color;Driver Type;Driver;Pool Contact Name;Vehicle Address;Vehicle Address2;"
				+ "Vehicle City;Vehicle State;Vehicle Zip Code;Vehicle Status;Plate Number;Plate State;From Date;"
				+ "To Date;Employee ID;Employee Data 1;Employee Data 2;Employee Data 3;Fleet Number;Fleet Name;"
				+ "Account Number;Account Name;Sub-account Number;Sub-account Name");
		
		RC_Reporting.clickReportCellHyperLink(driver, "Unit Number", "Vehicle Details");
		RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
		RC_Reporting.panelAction(driver, "expand", "Driver Change History Detail",false, false);
		
		RC_Reporting.clickReportCellHyperLink(driver, "Driver", "Driver Details");
		RC_Reporting.panelAction(driver, "close", "Driver Details",false, false);
		RC_Reporting.panelAction(driver, "expand", "Driver Change History Detail",false, false);
		
		RC_Reporting.reportParametersNavigate(driver);
		RC_Reporting.validateCustomerNumberParamData(driver, "LS008742");
		RC_Reporting.validateReportParameterData(driver, "Vehicle Status", "Active lease, Active services only, On Order,"
				+ " Pending Activation, Pending termination");
		RC_Reporting.downloadAndVerifyFileDownloaded(driver, "Driver Change History Detail_LS008742.xlsx", "Downloading Standard Report Validation",false);

	}

}
