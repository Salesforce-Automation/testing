package Reporting.StandardReports;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import MF.Source.Cred;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;


public class TID_3_2_01 {
	public void StandardReports_VerifyListofFleetSearchFunctionalityAndUIExceptions(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
		
			
		RC_Global.login(driver);
		
		String columnClientData = RC_Reporting.retrieveClientData(driver, "LS008737", 0);
		String Env=Cred.ENV;
		String reportNameInTest = null;
				
		if(Env.equalsIgnoreCase("PROD")) {reportNameInTest = "List of Fleet";}
			else {reportNameInTest = "List Of Fleet";}
		
			RC_Reporting.navigateTo(driver, "Reporting", "Standard Reports", reportNameInTest);

		
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);
		
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Number", false);
		
		
		RC_Global.verifyScreenComponents(driver, "lable", "Unit Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Vehicle Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Driver Name", false);
		RC_Global.verifyScreenComponents(driver, "lable", "VIN", false);

		RC_Global.verifyScreenComponents(driver, "lable", "Plate Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Plate Expiration Date", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Value", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Value", false);

		
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Plate State", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Segment", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Vehicle Status", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Pool Units", false);

		
		
		RC_Global.buttonStatusValidation(driver, "Generate Report", "Enable", false);
		RC_Global.buttonStatusValidation(driver, "Excel", "Enable", false);
		RC_Global.buttonStatusValidation(driver, "CSV", "Enable", false);
		RC_Global.buttonStatusValidation(driver, "PDF", "Enable", false);
		RC_Global.buttonStatusValidation(driver, "XML", "Enable", false);
		RC_Global.buttonStatusValidation(driver, "Edit Columns", "Enable", false);

		
		RC_Global.dropdownValuesValidation(driver, "Active lease;Active services only;Cancelled;Closed;On Order;Pending Activation;Pending termination;Sold;Terminated lease;Terminated services only","//div[label[text()='Vehicle Status:']]//select", true, true);
        RC_Global.dropdownValuesValidation(driver, "Yes;No", "//div[label[text()='Pool Units:']]//select", false, true);    
        RC_Reporting.selectMultipleOptionsFromSelection(driver, "Vehicle Status", "Active lease--Active services only--Pending termination", false);

        List<WebElement> vehicleStatus = driver.findElements(By.xpath("//div[label[text()='Vehicle Status:']]//select/option"));
		String sVehicleStatus = "";
		int iter = 0;
		for(WebElement vs:vehicleStatus) {
			if(vs.isSelected()) {
				if(!sVehicleStatus.equalsIgnoreCase(""))
					sVehicleStatus = sVehicleStatus+", "+vs.getText();
				else
					sVehicleStatus = vs.getText();
			}
		}
		
		List<WebElement> segment = driver.findElements(By.xpath("//div[label[text()='Segment:']]//select/option"));
		String sSegment = "";
		iter = 0;
		for(WebElement vs:segment) {
			if(vs.isSelected()) {
				if(!sSegment.equalsIgnoreCase(""))
					sSegment = sSegment+", "+vs.getText();
				else
					sSegment = vs.getText();
			}
		}
        RC_Global.clickButton(driver, "Generate Report", false, true);
       
        RC_Reporting.reportErrorValidation(driver, "//h4[text()='Customer Number is required']");
        
		RC_Global.waitElementVisible(driver, 10, "//input[@name='customerInput']", "Input CustomerNumber",true,true);
		
		RC_Global.enterCustomerNumber(driver, "LS008737", "", "",true);
		
		RC_Reporting.generateReportValidateResults(driver);
        
        RC_Reporting.validateReportColumnNames(driver, "Customer Name;Customer Number;Unit Number;CVN;VIN;Year;Make;Model;Trim;Body;Drive;Color;Segment;GVW;Driver Type;Driver/Pool;Pool Contact;Driver State;Delivered Date;In Service Date;Vehicle Address;Vehicle Address 2;Vehicle City;Vehicle State;Vehicle Zip Code;Vehicle County;Vehicle Country;Vehicle Status;Original Cost;Months in Service;Months Billed;Mileage;Agreement Type;Last Month;Plate Number;Plate State;Plate Expiration Date;Date Off Road;Replacement Unit Number;"+columnClientData+";Employee Data 1;Employee Data 2;Employee Data 3;"
        		+  "Fleet Number;Fleet Name;Account Number;Account Name;Sub-account Number;Sub-account Name");
        
        RC_Reporting.verifySortFunction(driver, "Unit Number", false);
		RC_Reporting.verifySortFunction(driver, "Year", false);
		RC_Reporting.verifySortFunction(driver, "Make", false);
		RC_Reporting.verifySortFunction(driver, "Driver/Pool", false);

        
        RC_Reporting.clickReportCellHyperLink(driver, "Unit Number", "Vehicle Details");
		RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
		RC_Reporting.panelAction(driver, "expand", reportNameInTest,false, false);
		
		RC_Reporting.verifySortFunction(driver, "CVN", false);
		if(driver.findElements(By.xpath("((//tbody//tbody)[1]/tr[@valign]/td[4]//a[@style and text()])[1]")).size()>0) {
			RC_Reporting.clickReportCellHyperLink(driver, "CVN", "Vehicle Details");
			RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
			RC_Reporting.panelAction(driver, "expand", reportNameInTest,false, false);
		}
		
		RC_Reporting.clickReportCellHyperLink(driver, "Driver/Pool", "Driver Details");
		RC_Reporting.panelAction(driver, "close", "Driver Details",false, false);
		RC_Reporting.panelAction(driver, "expand", reportNameInTest,false, false);

		RC_Reporting.downloadAndVerifyFileDownloaded(driver, "List Of Fleet_LS008737.xlsx", "Downloading Standard Report Validation", false);
		
		RC_Reporting.reportParametersNavigate(driver);
//		RC_Reporting.validateReportParameterData(driver, "Customer Number", "LS008737");
		RC_Reporting.validateCustomerNumberParamData(driver, "LS008737");
		
		if(Env.equalsIgnoreCase("PROD")) {
			RC_Reporting.validateReportParameterData(driver, "Segment", sSegment);
		}		
		RC_Reporting.validateReportParameterData(driver, "Vehicle Status", sVehicleStatus);		
		
		RC_Reporting.panelAction(driver, "close", reportNameInTest, true, true);
		
		RC_Global.logout(driver, true);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}

}
