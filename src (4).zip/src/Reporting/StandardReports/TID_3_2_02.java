package Reporting.StandardReports;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import MF.FrameworkCode.BFrameworkQueryObjects;

import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_2_02 {
	
public static void StandardReports_VerifyVehicleRecallSearchFunctionalityAndUIExceptions(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
	
	//String allColumnName="Customer Name;Customer Number;Unit Number;CVN;VIN;Year;Make;Model;Trim;Body;Drive;Color;Driver Type;Driver/Pool;Pool Contact;Vehicle Status;Vehicle Address;Vehicle Address 2;Vehicle City;Vehicle State;Vehicle Zip Code;Vehicle County;Vehicle Country;Delivered Date;Months In Service;Months Enrolled;Current Odometer;Maintenance Agreement Type;Service Date;Repair Mileage;PO Number;PO Status;Repair Type;Item Quantity;Cost;Cost Savings;Repaired System;Repaired Component;Repaired Item;Repaired Item;Comments;Vendor Name;Preferred Vendor;Employee ID Number;Fleet Drivers Location;ClientBillingData;Employee Job Title;Employee Data 1;Employee Data 2;Employee Data 3;Fleet Number;Fleet Name;Account Number;Account Name;Sub-Account Number;Sub-Account Name";
		
		WebDriverWait wait = new WebDriverWait(driver,50);
		
		RC_Global.login(driver);
		
		String columnClientData = RC_Reporting.retrieveClientData(driver, "LS008742", 7);
		
		RC_Reporting.navigateTo(driver, "Reporting", "Standard Reports", "Vehicle Recall");
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);
		
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Number:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "From Date:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "To Date:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Unit Number:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Vehicle Number:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Driver Name:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "VIN:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Value:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Number:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Value:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Number:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Preferred Vendor:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Maintenance Agreement Type:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Vehicle Status:", false);
		
		
		RC_Global.verifyScreenComponents(driver, "button", "Excel", false);
		RC_Global.verifyScreenComponents(driver, "button", "CSV", false);
		RC_Global.verifyScreenComponents(driver, "button", "PDF", false);
		RC_Global.verifyScreenComponents(driver, "button", "XML", false);
		RC_Global.verifyScreenComponents(driver, "button", "Edit Columns", false);
		
		RC_Global.dropdownValuesValidation(driver, "Y;N","//div[label[text()='Preferred Vendor:']]//select", true, true);
		
		String fromDate = driver.findElement(By.xpath("//div[label[text()='From Date:']]//input")).getAttribute("value");
		String toDate = driver.findElement(By.xpath("//div[label[text()='To Date:']]//input")).getAttribute("value");
		
		Thread.sleep(4000);
		
        String sVehicleStatus = "Active lease, Active services only, Pending termination";
        String sMaintenanceAgreementType = "Full, Administered, Reserve, Any";
		
        RC_Global.clickButton(driver, "Generate Report", true, true);
		
		RC_Reporting.reportErrorValidation(driver,"//h4[text()='Customer Number is required']");
		
        
		RC_Global.waitElementVisible(driver, 10, "//input[@name='customerInput']", "Input Customer Number",true, true);
		
		
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "",true);
		
		RC_Reporting.generateReportValidateResults(driver);
		
		
		RC_Global.waitElementVisible(driver, 30, "(//*[@id='oReportCell']//td[contains(.,'Customer Number')])[1]", "Report table result", true, false);
		
		RC_Reporting.validateReportColumnNames(driver,"Customer Name;Customer Number;Unit Number;CVN;VIN;Year;Make;"
				+ "Model;Trim;Body;Drive;Color;Driver Type;Driver/Pool;Pool Contact;Vehicle Status;Vehicle Address;Vehicle Address 2;"
				+ "Vehicle City;Vehicle State;Vehicle Zip Code;Vehicle County;Vehicle County;Delivered Date;Months In Service;Months Enrolled;Current Odometer;"
				+ "Maintenance Agreement Type;Service Date;Repair Mileage;PO Number;PO Status;Repair Type;Item Quantity;Cost;"
				+ "Cost Savings;Repaired System;Repaired Component;Repaired Item;Comments;Vendor Name;Preferred Vendor;"+columnClientData+";Employee Data 1;Employee Data 2;Employee Data 3;Fleet Number;Fleet Name;Account Number;Account Name;Sub-Account Number;Sub-Account Name");
		Thread.sleep(5000);
		
		
		RC_Reporting.verifySortFunction(driver, "Unit Number", true);
		RC_Reporting.verifySortFunction(driver, "Driver/Pool", true);
		
		RC_Reporting.clickReportCellHyperLink(driver, "Unit Number", "Vehicle Details");
		RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
		RC_Reporting.panelAction(driver, "expand", "Vehicle Recall",false, false);
		
		Thread.sleep(5000);
		
		RC_Reporting.verifySortFunction(driver, "CVN", false);
		if(driver.findElements(By.xpath("((//tbody//tbody)[1]/tr[@valign]/td[4]//a[@style and text()])[1]")).size()>0) {
			RC_Reporting.clickReportCellHyperLink(driver, "CVN", "Vehicle Details");
			RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
			RC_Reporting.panelAction(driver, "expand", "Vehicle Recall",false, false);
		}
		Thread.sleep(5000);
		
		RC_Reporting.clickReportCellHyperLink(driver, "Driver/Pool", "Driver Details");
		RC_Reporting.panelAction(driver, "close", "Driver Details",false, false);
		RC_Reporting.panelAction(driver, "expand", "Vehicle Recall",false, false);
		
		
      RC_Global.downloadAndVerifyFileDownloaded(driver, "Vehicle Recall_LS008742", "Excel button - Download validation", true);
		
		RC_Reporting.reportParametersNavigate(driver);

		RC_Reporting.validateCustomerNumberParamData(driver, "LS008742");
		RC_Reporting.validateReportParameterData(driver, "Vehicle Status", sVehicleStatus);
		RC_Reporting.validateReportParameterData(driver, "Maintenance Agreement Type", sMaintenanceAgreementType);
		RC_Reporting.validateReportParameterData(driver, "From Date", fromDate);
		RC_Reporting.validateReportParameterData(driver, "To Date", toDate);
		
		
		RC_Reporting.panelAction(driver, "close", "Vehicle Recall", true, true);
		RC_Global.logout(driver, true);
	}
}