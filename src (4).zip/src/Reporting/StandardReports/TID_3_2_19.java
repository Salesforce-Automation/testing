package Reporting.StandardReports;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_2_19 {
	public static void StandardReports_VerifyPMComplianceSearchFunctionalityAndUIExceptions(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		WebDriverWait wait = new WebDriverWait(driver, 30);
		
		RC_Global.login(driver);
		
		String columnClientData = RC_Reporting.retrieveClientData(driver, "LS008742", 7);
		String columnNames = "Customer Name;Customer Number;Unit Number;CVN;VIN;Year;Make;Model;Trim;Drive;Driver/Pool;Services Completed During Period;Compliant LOF / PM Services Completed During Period;LOF / PM Services Expected During Period;Percentage of Total Services Complete / PM Compliance Percentage;Segment;Accumulated Mileage;LOF Mileage Interval;LOF Days Interval;Average Mileage between LOF;Vehicle Status;Current Odometer;Maintenance Agreement Type;Last LOF Service Mileage;Last LOF Service Date;Last LOF PO Number;Miles Past Last Expected LOF;Days Past Last Expected LOF;Miles Since Last LOF;Days Since Last LOF;Last LOF Alert;Total LOF Alerts Since Prior Service;"+columnClientData+";Fleet Number;Fleet Name;Account Number;Account Name;Sub-Account Number;Sub-Account Name";
		
		RC_Reporting.navigateTo(driver, "Reporting", "Standard Reports", "PM Compliance");
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);
		
		RC_Global.createNode(driver, "Verify Search Filters");
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Unit Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Make", false);
		RC_Global.verifyScreenComponents(driver, "lable", "CVN", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Model", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Year", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Driver/Pool", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Period Start Date", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Period End Date", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Segment", false);
		RC_Global.verifyScreenComponents(driver, "lable", "PO Status", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Mileage Service Interval Tolerance", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Days Service Interval Tolerance", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Value", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Value", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Vehicle Status", false);
		
		RC_Global.createNode(driver, "Validate buttons");
		RC_Global.verifyScreenComponents(driver, "button", "Generate Report", false);
		RC_Global.verifyScreenComponents(driver, "button", "Excel", false);
		RC_Global.verifyScreenComponents(driver, "button", "CSV", false);
		RC_Global.verifyScreenComponents(driver, "button", "PDF", false);
		RC_Global.verifyScreenComponents(driver, "button", "XML", false);
		RC_Global.verifyScreenComponents(driver, "button", "Edit Columns", false);
		
		String eDate = driver.findElement(By.xpath("//input[@id='dateTimeField_Period End Date']")).getAttribute("value");
		String sDate = driver.findElement(By.xpath("//input[@id='dateTimeField_Period Start Date']")).getAttribute("value");
		
		String fDDate= sDate.split("/")[1].split("")[0];
		String tDDate= eDate.split("/")[1].split("")[0];
		
		String fDMonth= sDate.split("/")[0].split("")[0];
		String tDMonth= eDate.split("/")[0].split("")[0];
		
		if(fDDate.equalsIgnoreCase("0")&& !fDMonth.equalsIgnoreCase("0"))sDate = RC_Global.getDateTime(driver, "MM/d/yyyy", -365, true);
		else if(!fDDate.equalsIgnoreCase("0")&& fDMonth.equalsIgnoreCase("0"))sDate = RC_Global.getDateTime(driver, "M/dd/yyyy", -365, true);
		else if(fDDate.equalsIgnoreCase("0")&& fDMonth.equalsIgnoreCase("0"))sDate = RC_Global.getDateTime(driver, "M/d/yyyy", -365, true);
		
		if(tDDate.equalsIgnoreCase("0")&& !tDMonth.equalsIgnoreCase("0"))eDate = RC_Global.getDateTime(driver, "MM/d/yyyy", 0, true);
		else if(!tDDate.equalsIgnoreCase("0")&& tDMonth.equalsIgnoreCase("0"))eDate = RC_Global.getDateTime(driver, "M/dd/yyyy", 0, true);
		else if(tDDate.equalsIgnoreCase("0")&& tDMonth.equalsIgnoreCase("0"))eDate = RC_Global.getDateTime(driver, "M/d/yyyy", 0, true);
		
		RC_Global.dropdownValuesValidation(driver, "250;500;750;1000;1250;1500", "//div[label[text()='Mileage Service Interval Tolerance:']]//select", true, true);
		Select mSIntervalTolerance=new Select(driver.findElement(By.xpath("//div[label[text()='Mileage Service Interval Tolerance:']]//select")));
		String sMSIntervalTolerance=mSIntervalTolerance.getFirstSelectedOption().getText();
		
		RC_Global.dropdownValuesValidation(driver, "5;10;15;20;25;30", "//div[label[text()='Days Service Interval Tolerance:']]//select", true, true);
		Select dSIntervalTolerance=new Select(driver.findElement(By.xpath("//div[label[text()='Days Service Interval Tolerance:']]//select")));
		String sDSIntervalTolerance=dSIntervalTolerance.getFirstSelectedOption().getText();
		
		String sVehicleStatus = "Active lease, Active services only, Pending termination";
		
		String sPOStatus = "Closed, Pending Invoice";
		
		List<WebElement> segment = driver.findElements(By.xpath("//div[label[text()='Segment:']]//select/option"));
		String sSegment = "";
		int iter = 0;
		for(WebElement vs:segment) {
			if(vs.isSelected()) {
				if(!sSegment.equalsIgnoreCase(""))
					sSegment = sSegment+", "+vs.getText();
				else
					sSegment = vs.getText();
			}
		}
		
		RC_Global.clickButton(driver, "Generate Report", true, true);
		
		RC_Reporting.reportErrorValidation(driver,"//h4[text()='Customer Number is required']");
		
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		RC_Reporting.generateReportValidateResults(driver);
		RC_Global.clickUsingXpath(driver, "//button[@ng-click='nextReportPage()']", "Next Page", false, true);
		RC_Global.waitElementVisible(driver, 10, "//td[text()='Customer Name']", "Grid loading", false, false);
		RC_Reporting.validateReportColumnNames(driver, columnNames);
		
		WebElement eElement = driver.findElement(By.xpath("//button[text()='Excel']"));
		
		RC_Global.createNode(driver, "Ascending Order Sort ---> "+"Unit Number");
		queryObjects.logStatus(driver, Status.INFO, "Ascending order sort", "",null);
		RC_Global.clickUsingXpath(driver, "//td[text()='Unit Number']/following-sibling::td/a[img]/span", "Unit Number -> Column Sort button", true, false);
		wait.until(ExpectedConditions.elementToBeClickable(eElement));
		RC_Global.clickUsingXpath(driver, "//button[@ng-click='nextReportPage()']", "Next Page", false, false);
		wait.until(ExpectedConditions.elementToBeClickable(eElement));
		RC_Global.createNode(driver, "Descending Order Sort ---> "+"Unit Number");
		queryObjects.logStatus(driver, Status.INFO, "Descending order sort", "",null);
		RC_Global.clickUsingXpath(driver, "//td[text()='Unit Number']/following-sibling::td/a[img]/span", "Unit Number -> Column Sort button", true, false);
		wait.until(ExpectedConditions.elementToBeClickable(eElement));
		RC_Global.clickUsingXpath(driver, "//button[@ng-click='nextReportPage()']", "Next Page", false, false);
		wait.until(ExpectedConditions.elementToBeClickable(eElement));
		
		RC_Global.createNode(driver, "Ascending Order Sort ---> "+"Driver/Pool");
		queryObjects.logStatus(driver, Status.INFO, "Ascending order sort", "",null);
		RC_Global.clickUsingXpath(driver, "//td[text()='Driver/Pool']/following-sibling::td/a[img]/span", "Driver/Pool -> Column Sort button", true, false);
		wait.until(ExpectedConditions.elementToBeClickable(eElement));
		RC_Global.clickUsingXpath(driver, "//button[@ng-click='nextReportPage()']", "Next Page", false, false);
		wait.until(ExpectedConditions.elementToBeClickable(eElement));
		RC_Global.createNode(driver, "Descending Order Sort ---> "+"Unit Number");
		queryObjects.logStatus(driver, Status.INFO, "Descending order sort", "",null);
		RC_Global.clickUsingXpath(driver, "//td[text()='Driver/Pool']/following-sibling::td/a[img]/span", "Driver/Pool -> Column Sort button", true, false);
		wait.until(ExpectedConditions.elementToBeClickable(eElement));
		RC_Global.clickUsingXpath(driver, "//button[@ng-click='nextReportPage()']", "Next Page", false, false);
		wait.until(ExpectedConditions.elementToBeClickable(eElement));
		
		RC_Reporting.downloadAndVerifyFileDownloaded(driver, "PM Compliance_LS008742", "Excel button - Download validation", true);
		
		RC_Reporting.reportParametersNavigate(driver);
		RC_Reporting.validateCustomerNumberParamData(driver, "LS008742");
		RC_Reporting.validateReportParameterData(driver, "Period Start Date", sDate);
		RC_Reporting.validateReportParameterData(driver, "Period End Date", eDate);
		RC_Reporting.validateReportParameterData(driver, "PO Status", sPOStatus);
		RC_Reporting.validateReportParameterData(driver, "Mileage Service Interval Tolerance", sMSIntervalTolerance);
		RC_Reporting.validateReportParameterData(driver, "Days Service interval Tolerance", sDSIntervalTolerance);
		RC_Reporting.validateReportParameterData(driver, "Vehicle Status", sVehicleStatus);
		RC_Reporting.validateReportParameterData(driver, "Segment", sSegment);
		
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
