package Reporting.VehicleOrderReports;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_5_01 {
	public void VehicleOrderReports_VerifyReplacementReportSearchFunctionality(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		RC_Global.login(driver);
		String columnClientData = RC_Reporting.retrieveClientData(driver, "LS008742", 7);
		
		String columnNames = "Customer Name;Customer Number;Unit Number;CVN;VIN;Year;Make;Model;Trim;Body;Drive;Color;Upfit;Driver Type;Driver/Pool;Selector Group;Pool Contact;Enrolled in Driver Ordering;Driver State;Delivered Date;Vehicle Status;Original Cost;Months In Service;Months Billed;Current Odometer;Odometer Date;Agreement Type;Current Book Value;Book Depreciation Rate;Total Maintenance Spend;Closed End Term Months;End of Term Date;Closed End Days to End of Term;Order Number;Replacement Unit Number;"+columnClientData+";Driver Ordering;Order Replacement;Employee Data 1;Employee Data 2;Employee Data 3;Fleet Number;Fleet Name;Account Number;Account Name;Sub-Account Number;Sub-Account Name";
		
		RC_Reporting.navigateTo(driver, "Reporting", "Vehicle Order Reports", "Replacement Report");
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);

		RC_Global.createNode(driver, "Verify Search Filters");
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Unit Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Vehicle Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Driver Name", false);
		RC_Global.verifyScreenComponents(driver, "lable", "VIN", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Days To End Of Lease Term", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Months In Service", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Current Odometer", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Value", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Value", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Agreement Type", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Driver State", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Driver Invited to Order", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Enrolled in Driver Ordering", false);
		
		RC_Global.createNode(driver, "Validate buttons");
		RC_Global.verifyScreenComponents(driver, "button", "Generate Report", false);
		RC_Global.verifyScreenComponents(driver, "button", "Excel", false);
		RC_Global.verifyScreenComponents(driver, "button", "CSV", false);
		RC_Global.verifyScreenComponents(driver, "button", "PDF", false);
		RC_Global.verifyScreenComponents(driver, "button", "XML", false);
		RC_Global.verifyScreenComponents(driver, "button", "Edit Columns", false);
		
		RC_Global.dropdownValuesValidation(driver, "Open End;Closed End;Services Only", "//div[label[text()='Agreement Type:']]//select", true, true);
		RC_Global.dropdownValuesValidation(driver, "Yes;No", "//div[label[text()='Enrolled in Driver Ordering:']]//select", true, true);
		RC_Global.dropdownValuesValidation(driver, "Yes;No", "//div[label[text()='Driver Invited to Order:']]//select", true, true);
		
//		RC_Global.clickButton(driver, "Generate Report", true, true);
//		RC_Reporting.reportErrorValidation(driver,"//h4[text()='Customer Number is required']");
		
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		RC_Reporting.generateReportValidateResults(driver);
		
		RC_Reporting.validateReportColumnNames(driver, columnNames);
		
		RC_Reporting.clickReportCellHyperLink(driver, "Unit Number", "Vehicle Details");
		RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
		RC_Reporting.panelAction(driver, "expand", "Replacement Report",false, false);
		
		RC_Reporting.verifySortFunction(driver, "CVN",false);
		if(driver.findElements(By.xpath("((//tbody//tbody)[1]/tr[@valign]/td[4]//a[@style and text()])[1]")).size()>0) {
			RC_Reporting.clickReportCellHyperLink(driver, "CVN", "Vehicle Details");
			RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
			RC_Reporting.panelAction(driver, "expand", "Replacement Report",false, false);
		}
		
		RC_Global.createNode(driver, "Click Report Cell Link & Validate Panel Title--> Driver Details");
		if(driver.findElements(By.xpath("//tbody//tr[3]//td[15]//div/a")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Verify Driver/Pool is a link", "Driver/Pool is a link", null);
			driver.findElement(By.xpath("//tbody//tr[3]//td[15]//div/a")).click();
			RC_Global.waitElementVisible(driver, 30, "//h5/span[text()='Driver Details']", "Driver Details",true, false);
			RC_Reporting.panelAction(driver, "close", "Driver Details",false, false);
			RC_Reporting.panelAction(driver, "expand", "Replacement Report",false, false);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Verify Driver/Pool is a link", "Driver/Pool is not a link", null);
		}

		RC_Global.createNode(driver, "Click Report Cell Link & Validate Panel Title--> Driver Ordering");
		if(driver.findElements(By.xpath("//tbody//tr[3]//td[43]//div/a")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Verify Driver Ordering is a link", "Driver Ordering is a link", null);
			driver.findElement(By.xpath("//tbody//tr[3]//td[43]//div/a")).click();
			RC_Global.waitElementVisible(driver, 30, "//h5/span[text()='Driver Ordering']", "Driver Ordering",true, false);
			RC_Reporting.panelAction(driver, "close", "Driver Ordering",false, false);
			RC_Reporting.panelAction(driver, "expand", "Replacement Report",false, false);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Verify Driver Ordering is a link", "Driver Ordering is not a link", null);
		}
		
		RC_Global.createNode(driver, "Click Report Cell Link & Validate Panel Title--> New Vehicle Order");
		if(driver.findElements(By.xpath("//tbody//tr[3]//td[44]//div/a")).size()>0)
		{
			queryObjects.logStatus(driver, Status.PASS, "Verify Order Replacement is a link", "Order Replacement is a link", null);
			driver.findElement(By.xpath("//tbody//tr[3]//td[44]//div/a")).click();
			RC_Global.waitElementVisible(driver, 30, "//h5/span[text()='New Vehicle Order']", "New Vehicle Order",true, false);
			RC_Reporting.panelAction(driver, "close", "New Vehicle Order",false, false);
			RC_Reporting.panelAction(driver, "expand", "Replacement Report",false, false);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Verify Order Replacement is a link", "Order Replacement is not a link", null);
		}
		
		RC_Reporting.downloadAndVerifyFileDownloaded(driver, "Replacement Report_LS008742", "Excel button - Download validation", true);
		
		RC_Reporting.reportParametersNavigate(driver);
		RC_Reporting.validateCustomerNumberParamData(driver, "LS008742");
		
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
