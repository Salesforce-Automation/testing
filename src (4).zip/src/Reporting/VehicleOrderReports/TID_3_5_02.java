package Reporting.VehicleOrderReports;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_5_02 {
	public void VehicleOrderReports_VerifyVehiclesOrderedSearchFunctionality(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		RC_Global.login(driver);
		String columnClientData = RC_Reporting.retrieveClientData(driver, "LS008742", 7);
		
		String columnNames = "Customer Name;Customer Number;Unit Number;CVN;VIN;Year;Make;Model;Trim;Body;Drive;Color;Driver Type;Driver/Pool;Pool Contact;Agreement Type;Upfit;Order Type;Driver Order;Order Date;Delivered Date;Order Number;Order Status;Turn-In Vehicle Unit Number;Turn-In Vehicle Year;Turn-In Vehicle Make;Turn-In Vehicle Model;Turn-In Vehicle Trim;"+columnClientData+";Employee Data 1;Employee Data 2;Employee Data 3;Fleet Number;Fleet Name;Account Number;Account Name;Sub-Account Number;Sub-Account Name";
		
		RC_Reporting.navigateTo(driver, "Reporting", "Vehicle Order Reports", "Vehicles Ordered");
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);

		RC_Global.createNode(driver, "Verify Search Filters");
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Unit Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Vehicle Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Driver Name", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Vehicle Order Status", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Order Date From", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Order Date To", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Vehicle Delivered", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Vehicle Delivered from Date", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Vehicle Delivered to Date", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Turn-In Vehicle Unit Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Value", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Value", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Agreement Type", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Driver Order", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Priority Order", false);
		
		RC_Global.createNode(driver, "Validate buttons");
		RC_Global.verifyScreenComponents(driver, "button", "Generate Report", false);
		RC_Global.verifyScreenComponents(driver, "button", "Excel", false);
		RC_Global.verifyScreenComponents(driver, "button", "CSV", false);
		RC_Global.verifyScreenComponents(driver, "button", "PDF", false);
		RC_Global.verifyScreenComponents(driver, "button", "XML", false);
		RC_Global.verifyScreenComponents(driver, "button", "Edit Columns", false);
		
		RC_Global.dropdownValuesValidation(driver, "Yes;No", "//div[label[text()='Vehicle Delivered:']]//select", true, true);
		RC_Global.dropdownValuesValidation(driver, "Yes;No", "//div[label[text()='Driver Order:']]//select", true, true);
		RC_Global.dropdownValuesValidation(driver, "Yes;No", "//div[label[text()='Priority Order:']]//select", true, true);
		
//		RC_Global.clickButton(driver, "Generate Report", true, true);
//		RC_Reporting.reportErrorValidation(driver,"//h4[text()='Customer Number is required']");
		
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		RC_Reporting.generateReportValidateResults(driver);
		
		RC_Reporting.validateReportColumnNames(driver, columnNames);
		
		RC_Reporting.clickReportCellHyperLink(driver, "Unit Number", "Vehicle Details");
		RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
		RC_Reporting.panelAction(driver, "expand", "Vehicles Ordered",false, false);
		
		RC_Reporting.verifySortFunction(driver, "CVN",false);
		if(driver.findElements(By.xpath("((//tbody//tbody)[1]/tr[@valign]/td[4]//a[@style and text()])[1]")).size()>0) {
			RC_Reporting.clickReportCellHyperLink(driver, "CVN", "Vehicle Details");
			RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
			RC_Reporting.panelAction(driver, "expand", "Vehicles Ordered",false, false);
		}
		
		RC_Reporting.clickReportCellHyperLink(driver, "Driver/Pool", "Driver Details");
		RC_Reporting.panelAction(driver, "close", "Driver Details",false, false);
		RC_Reporting.panelAction(driver, "expand", "Vehicles Ordered",false, false);
		
		RC_Reporting.downloadAndVerifyFileDownloaded(driver, "Vehicles Ordered_LS008742", "Excel button - Download validation", true);
		
		RC_Reporting.reportParametersNavigate(driver);
		RC_Reporting.validateCustomerNumberParamData(driver, "LS008742");
		
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
