package Reporting.FuelReports;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_4_08 {
	public void FuelReports_VerifyFuelSummaryByDriverSearchFunctionality(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String columnNames = "Customer Name;Customer Number;Driver;Driver State;Total Gallons;Fuel Transaction Count;Total Fuel Spend;Total Non-Fuel Spend;Average Cost Per Gallon;Employee Data 1;Employee Data 2;Employee Data 3;Fleet Number;Fleet Name;Account Number;Account Name;Sub-Account Number;Sub-Account Name";
		
		RC_Global.login(driver);
		RC_Reporting.navigateTo(driver, "Reporting", "Fuel Reports", "Fuel Summary By Driver");
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);
		
		RC_Global.createNode(driver, "Verify Search Filters");
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Driver Name", false);
		RC_Global.verifyScreenComponents(driver, "lable", "From Date", false);
		RC_Global.verifyScreenComponents(driver, "lable", "To Date", false);
		
		RC_Global.createNode(driver, "Validate buttons");
		RC_Global.verifyScreenComponents(driver, "button", "Generate Report", false);
		RC_Global.verifyScreenComponents(driver, "button", "Excel", false);
		RC_Global.verifyScreenComponents(driver, "button", "CSV", false);
		RC_Global.verifyScreenComponents(driver, "button", "PDF", false);
		RC_Global.verifyScreenComponents(driver, "button", "XML", false);
		RC_Global.verifyScreenComponents(driver, "button", "Edit Columns", false);
				
		String fDate = driver.findElement(By.xpath("//input[@id='dateTimeField_From Date']")).getAttribute("value");
		
		String tDate = driver.findElement(By.xpath("//input[@id='dateTimeField_To Date']")).getAttribute("value");
		
		String fDDate= fDate.split("/")[1].split("")[0];
		String tDDate= tDate.split("/")[1].split("")[0];
		
		String fDMonth= fDate.split("/")[0].split("")[0];
		String tDMonth= tDate.split("/")[0].split("")[0];
		
		if(fDDate.equalsIgnoreCase("0")&& !fDMonth.equalsIgnoreCase("0"))fDate = RC_Global.getDateTime(driver, "MM/d/yyyy", -365, true);
		else if(!fDDate.equalsIgnoreCase("0")&& fDMonth.equalsIgnoreCase("0"))fDate = RC_Global.getDateTime(driver, "M/dd/yyyy", -365, true);
		else if(fDDate.equalsIgnoreCase("0")&& fDMonth.equalsIgnoreCase("0"))fDate = RC_Global.getDateTime(driver, "M/d/yyyy", -365, true);
		
		if(tDDate.equalsIgnoreCase("0")&& !tDMonth.equalsIgnoreCase("0"))tDate = RC_Global.getDateTime(driver, "MM/d/yyyy", 0, true);
		else if(!tDDate.equalsIgnoreCase("0")&& tDMonth.equalsIgnoreCase("0"))tDate = RC_Global.getDateTime(driver, "M/dd/yyyy", 0, true);
		else if(tDDate.equalsIgnoreCase("0")&& tDMonth.equalsIgnoreCase("0"))tDate = RC_Global.getDateTime(driver, "M/d/yyyy", 0, true);
		
		RC_Global.clickButton(driver, "Generate Report", true, true);
		RC_Reporting.reportErrorValidation(driver,"//h4[text()='Customer Number is required']");
		
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		RC_Reporting.generateReportValidateResults(driver);
		
		RC_Reporting.validateReportColumnNames(driver, columnNames);
				
		RC_Reporting.downloadAndVerifyFileDownloaded(driver, "Fuel Summary By Driver_LS008742", "Excel button - Download validation", true);
		
		RC_Reporting.reportParametersNavigate(driver);
		RC_Reporting.validateCustomerNumberParamData(driver, "LS008742");
		RC_Reporting.validateReportParameterData(driver, "From Date", fDate+" 12:00:00 AM");
		RC_Reporting.validateReportParameterData(driver, "To Date", tDate+" 12:00:00 AM");
		
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
