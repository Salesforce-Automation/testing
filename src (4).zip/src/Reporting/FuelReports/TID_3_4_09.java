package Reporting.FuelReports;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_4_09 {
	public void FuelReports_VerifyNonSequentialOdometerSearchFunctionality(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		RC_Global.login(driver);
		String columnClientData = RC_Reporting.retrieveClientData(driver, "LS008742", 7);
		String columnNames = "Customer Name;Customer Number;Unit Number;CVN;Driver Type;Driver/Pool;Pool Contact;Transaction Date;Odometer Reading;Validity;Gallon Amount Purchased;Fuel Type;Vendor Name;Vendor Address;Vendor City;Vendor State;Vendor Zip Code;Buyer;"+columnClientData+";Employee Data 1;Employee Data 2;Employee Data 3;Fleet Number;Fleet Name;Account Number;Account Name;Sub-Account Number;Sub-Account Name";
		RC_Reporting.navigateTo(driver, "Reporting", "All Reports", "");
		RC_Global.clickUsingXpath(driver, "(//span[contains(text(),'Seq')])[2]", "Non Sequential Odometer", false, true);
		RC_Reporting.panelAction(driver, "close", "All Reports", false, true);
		RC_Reporting.panelAction(driver, "expand", "Non Sequential Odometer", false, true);
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);
		
		RC_Global.createNode(driver, "Verify Search Filters");
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Unit Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Vehicle Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Odometer Validity", false);
		RC_Global.verifyScreenComponents(driver, "lable", "From Date", false);
		RC_Global.verifyScreenComponents(driver, "lable", "To Date", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Value", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Value", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Number", false);
		
		RC_Global.createNode(driver, "Validate buttons");
		RC_Global.verifyScreenComponents(driver, "button", "Generate Report", false);
		RC_Global.verifyScreenComponents(driver, "button", "Excel", false);
		RC_Global.verifyScreenComponents(driver, "button", "CSV", false);
		RC_Global.verifyScreenComponents(driver, "button", "PDF", false);
		RC_Global.verifyScreenComponents(driver, "button", "XML", false);
		RC_Global.verifyScreenComponents(driver, "button", "Edit Columns", false);
				
		RC_Global.dropdownValuesValidation(driver, "All;Valid;Invalid", "//div[label[text()='Odometer Validity:']]//select", true, true);
		Select oValidity=new Select(driver.findElement(By.xpath("//div[label[text()='Odometer Validity:']]//select")));
		String sOValidity=oValidity.getFirstSelectedOption().getText();
		
		String fDate = driver.findElement(By.xpath("//input[@id='dateTimeField_From Date']")).getAttribute("value");
		String tDate = driver.findElement(By.xpath("//input[@id='dateTimeField_To Date']")).getAttribute("value");
		String fDDate= fDate.split("/")[1].split("")[0];
		String tDDate= tDate.split("/")[1].split("")[0];
		
		String fDMonth= fDate.split("/")[0].split("")[0];
		String tDMonth= tDate.split("/")[0].split("")[0];
		
		if(fDDate.equalsIgnoreCase("0")&& !fDMonth.equalsIgnoreCase("0"))fDate = RC_Global.getDateTime(driver, "MM/d/yyyy", -365, true);
		else if(!fDDate.equalsIgnoreCase("0")&& fDMonth.equalsIgnoreCase("0"))fDate = RC_Global.getDateTime(driver, "M/dd/yyyy", -365, true);
		else if(fDDate.equalsIgnoreCase("0")&& fDMonth.equalsIgnoreCase("0"))fDate = RC_Global.getDateTime(driver, "M/d/yyyy", -365, true);
		
		if(tDDate.equalsIgnoreCase("0")&& !tDMonth.equalsIgnoreCase("0"))tDate = RC_Global.getDateTime(driver, "MM/d/yyyy", 0, true);
		else if(!tDDate.equalsIgnoreCase("0")&& tDMonth.equalsIgnoreCase("0"))tDate = RC_Global.getDateTime(driver, "M/dd/yyyy", 0, true);
		else if(tDDate.equalsIgnoreCase("0")&& tDMonth.equalsIgnoreCase("0"))tDate = RC_Global.getDateTime(driver, "M/d/yyyy", 0, true);
		
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		RC_Reporting.generateReportValidateResults(driver);
		
		RC_Reporting.validateReportColumnNames(driver, columnNames);
		
		RC_Reporting.clickReportCellHyperLink(driver, "Unit Number", "Vehicle Details");
		RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
		RC_Reporting.panelAction(driver, "expand", "Non Sequential Odometer",false, false);
		
		RC_Reporting.verifySortFunction(driver, "CVN",false);
		if(driver.findElements(By.xpath("(//tbody//tbody)[1]/tr[@valign]/td[1]/table/tbody/tr[@valign]/td[4]//a[@style and text()][1]")).size()>0) {
			RC_Reporting.clickReportCellHyperLink(driver, "CVN", "Vehicle Details");
			RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
			RC_Reporting.panelAction(driver, "expand", "Non Sequential Odometer",false, false);
		}
		
		RC_Reporting.verifySortFunction(driver, "Driver/Pool",false);
		RC_Reporting.clickReportCellHyperLink(driver, "Driver/Pool", "Driver Details");
		RC_Reporting.panelAction(driver, "close", "Driver Details",false, false);
		RC_Reporting.panelAction(driver, "expand", "Non Sequential Odometer",false, false);
		
		RC_Reporting.downloadAndVerifyFileDownloaded(driver, "Non Sequential Odometer_LS008742", "Excel button - Download validation", true);
		
		RC_Reporting.reportParametersNavigate(driver);
		RC_Reporting.validateCustomerNumberParamData(driver, "LS008742");
		RC_Reporting.validateReportParameterData(driver, "From Date", fDate+" 12:00:00 AM");
		RC_Reporting.validateReportParameterData(driver, "To Date", tDate+" 12:00:00 AM");
		RC_Reporting.validateReportParameterData(driver, "Odometer Validity", sOValidity);
		
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
