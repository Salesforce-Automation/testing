package Reporting.FuelReports;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import java.util.List;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_4_05 {
	public static void FuelReports_VerifyFuelCardInventorySearchFunctionalityAndUIExceptions(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
		
		RC_Global.login(driver);
      
		String columnClientData = RC_Reporting.retrieveClientData(driver, "LS008742", 17);
		String columnNames="Customer Name;Customer Number;Unit Number;CVN;Card Number;Customer Card Data;Card Type;Card Assignment;Card Prompting;Card Profile Name;Card Expiration Month;Card Expiration Year;Card Status;Activation Date;Deactivation Date;Total # Transactions;Total Spend;# Of Transactions Limit;Daily Limit;Weekly Limit;Monthly Limit;VIN;Year;Make;Model;Trim;Body;Drive;Color;Driver Type;Driver/Pool;Pool Contact;Driver State;Delivered Date;Vehicle Status;Current Odometer;"+columnClientData+";Employee Data 1;Employee Data 2;Employee Data 3;Fleet Number;Fleet Name;Account Number;Account Name;Sub-Account Number;Sub-Account Name";
		
		RC_Reporting.navigateTo(driver, "Reporting", "Fuel Reports", "Fuel Card Inventory");
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);
		
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Unit Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Driver Name", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Card Activation Date From", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Card Activation Date To", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Card Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Card Profile", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Card Expiration Year", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Card Status", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Vehicle Status", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Value", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Vehicle Number", false);
	     
	 	RC_Global.verifyScreenComponents(driver, "button", "Excel", false);
		RC_Global.verifyScreenComponents(driver, "button", "CSV", false);
		RC_Global.verifyScreenComponents(driver, "button", "PDF", false);
		RC_Global.verifyScreenComponents(driver, "button", "XML", false);
		RC_Global.verifyScreenComponents(driver, "button", "Edit Columns", false);
		
		String sVehicleStatus = "Active lease, Active services only, On Order, Pending Activation, Pending termination";
		String sCardStatus = "Active";		
		WebElement fromDateElement = driver.findElement(By.xpath("//input[@id='dateTimeField_Card Activation Date From']"));
		WebElement toDateElement = driver.findElement(By.xpath("//input[@id='dateTimeField_Card Activation Date To']"));
	
		RC_Global.clickButton(driver, "Generate Report", true, true);
		RC_Reporting.reportErrorValidation(driver,"//h4[text()='Customer Number is required']");
		
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		RC_Reporting.fromToDateErrorValidation(driver, fromDateElement, toDateElement);
		
		String fromDate = RC_Global.getDateTime(driver, "MM/dd/yyyy", -365, true);//"12/03/2020";
		String toDate = RC_Global.getDateTime(driver, "MM/dd/yyyy", 0, true);//"12/03/2021";
		RC_Global.enterInput(driver, fromDate, fromDateElement, true, true);
		RC_Global.enterInput(driver, toDate, toDateElement, true, true);
		
		String fDDate= fromDate.split("/")[1].split("")[0];
		String tDDate= toDate.split("/")[1].split("")[0];
		
		String fDMonth= fromDate.split("/")[0].split("")[0];
		String tDMonth= toDate.split("/")[0].split("")[0];
		
		if(fDDate.equalsIgnoreCase("0")&& !fDMonth.equalsIgnoreCase("0"))fromDate = RC_Global.getDateTime(driver, "MM/d/yyyy", -365, true);
		else if(!fDDate.equalsIgnoreCase("0")&& fDMonth.equalsIgnoreCase("0"))fromDate = RC_Global.getDateTime(driver, "M/dd/yyyy", -365, true);
		else if(fDDate.equalsIgnoreCase("0")&& fDMonth.equalsIgnoreCase("0"))fromDate = RC_Global.getDateTime(driver, "M/d/yyyy", -365, true);
		
		if(tDDate.equalsIgnoreCase("0")&& !tDMonth.equalsIgnoreCase("0"))toDate = RC_Global.getDateTime(driver, "MM/d/yyyy", 0, true);
		else if(!tDDate.equalsIgnoreCase("0")&& tDMonth.equalsIgnoreCase("0"))toDate = RC_Global.getDateTime(driver, "M/dd/yyyy", 0, true);
		else if(tDDate.equalsIgnoreCase("0")&& tDMonth.equalsIgnoreCase("0"))toDate = RC_Global.getDateTime(driver, "M/d/yyyy", 0, true);
	     
		RC_Reporting.generateReportValidateResults(driver);
		RC_Global.waitElementVisible(driver, 60, "//tbody//td[text()='Customer Name']", "Report Result grid", true, true);
		//Column Validation
		RC_Reporting.validateReportColumnNames(driver, columnNames);
		
		RC_Reporting.clickReportCellHyperLink(driver, "Unit Number", "Vehicle Details");
		RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
		RC_Reporting.panelAction(driver, "expand", "Fuel Card Inventory",false, false);
		
		RC_Reporting.verifySortFunction(driver, "CVN", false);
		if(driver.findElements(By.xpath("((//tbody//tbody)[1]/tr[@valign]/td[4]//a[@style and text()])[1]")).size()>0) {
			RC_Reporting.clickReportCellHyperLink(driver, "CVN", "Vehicle Details");
			RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
			RC_Reporting.panelAction(driver, "expand", "Fuel Card Inventory",false, false);
		}
		
		Thread.sleep(3000);
		RC_Reporting.downloadAndVerifyFileDownloaded(driver, "Fuel Card Inventory_LS008742", "Excel button - Download validation", true);
		Thread.sleep(3000);
		RC_Reporting.reportParametersNavigate(driver);
		RC_Reporting.validateCustomerNumberParamData(driver, "LS008742");
		
		RC_Reporting.validateReportParameterData(driver, "Card Activation Date From", fromDate+" 12:00:00 AM");
		RC_Reporting.validateReportParameterData(driver, "Card Activation Date To", toDate+" 12:00:00 AM");
		RC_Reporting.validateReportParameterData(driver, "Vehicle Status", sVehicleStatus);
		RC_Reporting.validateReportParameterData(driver, "Card Status", "Active");
		
		RC_Reporting.panelAction(driver, "close", "Fuel Card Inventory", true, true);
		RC_Global.logout(driver, true);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	     
	}

}
