package Reporting.FuelReports;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_4_11 {
	
	public static void FuelReports_VerifyOffHoursPurchasesSearchFunctionalityAndUIExceptions(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{

		
		RC_Global.login(driver);
	    
		String columnClientData = RC_Reporting.retrieveClientData(driver, "LS008742", 17);

		String columnNames ="Customer Name;Customer Number;Unit Number;CVN;VIN;Year;Make;Model;Trim;Body;Drive;Color;Driver Type;Driver/Pool;Pool Contact;Driver State;Delivered Date;Vehicle Status;Current Odometer;Transaction Date;Transaction Time;Transaction Time Zone;Transaction Gallons;Price Per Gallon;Total Transaction Cost;Purchase Type;Fuel Type;Vendor City;Vendor State;Vendor Zip Code;Buyer;"+columnClientData+";Employee Data 1;Employee Data 2;Employee Data 3;Fleet Number;Fleet Name;Account Number;Account Name;Sub-Account Number;Sub-Account Name";
		RC_Reporting.navigateTo(driver, "Reporting", "Fuel Reports", "Off Hours Purchases");
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);

		RC_Global.verifyScreenComponents(driver, "lable", "Customer Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Unit Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Vehicle Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Driver Name", false);
		RC_Global.verifyScreenComponents(driver, "lable", "From Date", false);
		RC_Global.verifyScreenComponents(driver, "lable", "To Date", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Transaction From Time", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Transaction To Time", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Value", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Value", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Purchase Type", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Fuel Type", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Vehicle Status", false);
		
		RC_Global.verifyScreenComponents(driver, "button", "Excel", false);
		RC_Global.verifyScreenComponents(driver, "button", "CSV", false);
		RC_Global.verifyScreenComponents(driver, "button", "PDF", false);
		RC_Global.verifyScreenComponents(driver, "button", "XML", false);
		RC_Global.verifyScreenComponents(driver, "button", "Edit Columns", false);
		
		String transactionFromTime = driver.findElement(By.xpath("//div[label[text()='Transaction From Time:']]//input[@ng-change='updateHours()']")).getAttribute("value");//"//div[label[text()='Transaction From Time:']]//input[@ng-change='updateHours()']")).getText();
		transactionFromTime = transactionFromTime + ":"+ driver.findElement(By.xpath("//div[label[text()='Transaction From Time:']]//input[@ng-change='updateMinutes()']")).getAttribute("value");
		transactionFromTime = transactionFromTime + " "+driver.findElement(By.xpath("//div[label[text()='Transaction From Time:']]//button[@ng-click='toggleMeridian()']")).getText();
		
		String transactionToTime = driver.findElement(By.xpath("//div[label[text()='Transaction To Time:']]//input[@ng-change='updateHours()']")).getAttribute("value");//"//div[label[text()='Transaction From Time:']]//input[@ng-change='updateHours()']")).getText();
		transactionToTime = transactionToTime + ":"+ driver.findElement(By.xpath("//div[label[text()='Transaction To Time:']]//input[@ng-change='updateMinutes()']")).getAttribute("value");
		transactionToTime = transactionToTime + " "+driver.findElement(By.xpath("//div[label[text()='Transaction To Time:']]//button[@ng-click='toggleMeridian()']")).getText();
		
		String fromDate = driver.findElement(By.xpath("//div[label[text()='From Date:']]//input")).getAttribute("value");
		String toDate = driver.findElement(By.xpath("//div[label[text()='To Date:']]//input")).getAttribute("value");
		
		String fDDate= fromDate.split("/")[1].split("")[0];
		String tDDate= toDate.split("/")[1].split("")[0];
		
		String fDMonth= fromDate.split("/")[0].split("")[0];
		String tDMonth= toDate.split("/")[0].split("")[0];
		
		if(fDDate.equalsIgnoreCase("0")&& !fDMonth.equalsIgnoreCase("0"))fromDate = RC_Global.getDateTime(driver, "MM/d/yyyy", -365, true);
		else if(!fDDate.equalsIgnoreCase("0")&& fDMonth.equalsIgnoreCase("0"))fromDate = RC_Global.getDateTime(driver, "M/dd/yyyy", -365, true);
		else if(fDDate.equalsIgnoreCase("0")&& fDMonth.equalsIgnoreCase("0"))fromDate = RC_Global.getDateTime(driver, "M/d/yyyy", -365, true);
		
		if(tDDate.equalsIgnoreCase("0")&& !tDMonth.equalsIgnoreCase("0"))toDate = RC_Global.getDateTime(driver, "MM/d/yyyy", 0, true);
		else if(!tDDate.equalsIgnoreCase("0")&& tDMonth.equalsIgnoreCase("0"))toDate = RC_Global.getDateTime(driver, "M/dd/yyyy", 0, true);
		else if(tDDate.equalsIgnoreCase("0")&& tDMonth.equalsIgnoreCase("0"))toDate = RC_Global.getDateTime(driver, "M/d/yyyy", 0, true);
		RC_Global.waitElementVisible(driver, 60, "//input[@name='customerInput']", "Input CustomerNumber",true, true);		
  		RC_Global.enterCustomerNumber(driver, "LS008742", "", "",true);
  		
  		RC_Reporting.generateReportValidateResults(driver);

  		Thread.sleep(4000);
  	
  		RC_Reporting.validateReportColumnNames(driver, columnNames);
  		
  		RC_Reporting.clickReportCellHyperLink(driver, "Unit Number", "Vehicle Details");
		RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
		RC_Reporting.panelAction(driver, "expand", "Off Hours Purchases",false, false);
		
		
		RC_Reporting.verifySortFunction(driver, "CVN", false);
		if(driver.findElements(By.xpath("((//tbody//tbody)[1]/tr[@valign]/td[4]//a[@style and text()])[1]")).size()>0) {
			RC_Reporting.clickReportCellHyperLink(driver, "CVN", "Vehicle Details");
			RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
			RC_Reporting.panelAction(driver, "expand", "Off Hours Purchases",false, false);
		}
//		RC_Reporting.clickReportCellHyperLink(driver, "Driver/Pool", "Driver Details");
//		RC_Reporting.panelAction(driver, "close", "Driver Details",false, false);
//		RC_Reporting.panelAction(driver, "expand", "Off Hours Purchases",false, false);
		
		RC_Reporting.downloadAndVerifyFileDownloaded(driver, "Off Hours Purchases_LS008742", "Downloading Standard Report Validation", false);

		RC_Reporting.reportParametersNavigate(driver);
		RC_Reporting.validateReportParameterData(driver, "Customer Number", "LS008742");
		
		RC_Reporting.validateReportParameterData(driver, "Vehicle Status", "Active lease, Active services only, On Order, Pending Activation, Pending termination");
		RC_Reporting.validateReportParameterData(driver, "Transaction From Time", transactionFromTime);
		RC_Reporting.validateReportParameterData(driver, "Transaction To Time", transactionToTime);
		RC_Reporting.validateReportParameterData(driver, "From Date", fromDate+" 12:00:00 AM");
		RC_Reporting.validateReportParameterData(driver, "To Date", toDate+" 12:00:00 AM");
		
		RC_Reporting.panelAction(driver, "close", "Off Hours Purchases", true, true);
		RC_Global.logout(driver, true);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}
	

}
