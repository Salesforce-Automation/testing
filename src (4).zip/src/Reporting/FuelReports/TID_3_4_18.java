package Reporting.FuelReports;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_4_18 {
	public static void FuelReports_ValidateFuelDetailsInVehicleDetailsScreen(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		RC_Global.login(driver);
		RC_Reporting.navigateTo(driver, "Reporting", "Fuel Reports", "Fuel Transaction Detail");
		RC_Global.waitUntilPanelVisibility(driver, "Fuel Transaction Detail", "TV", true, false);
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);

		RC_Global.enterCustomerNumber(driver, "Terminix - Corporate", "", "", true);
		
		String fromDate = RC_Global.getDateTime(driver, "MM/dd/yyyy", -150, true);
		String toDate = RC_Global.getDateTime(driver, "MM/dd/yyyy", 0, true);
		
		WebElement fromDateElement = driver.findElement(By.xpath("//input[@id='dateTimeField_From Date']"));
		WebElement toDateElement = driver.findElement(By.xpath("//input[@id='dateTimeField_To Date']"));
	
		RC_Global.enterInput(driver, fromDate, fromDateElement, true, false);
		RC_Global.enterInput(driver, toDate, toDateElement, true, false);
		
		RC_Reporting.generateReportValidateResults(driver);
		
		RC_Global.waitElementVisible(driver, 60, "//tbody//td[text()='Customer Name']", "Report Result grid", true, true);
		
		RC_Reporting.clickReportCellHyperLink(driver, "Unit Number", "Vehicle Details");
		RC_Reporting.panelAction(driver, "close", "Fuel Transaction Detail",false, false);
		RC_Reporting.panelAction(driver, "expand", "Vehicle Details",false, false);
		
		RC_Global.waitElementVisible(driver, 30, "//div[text()='Total Fuel Spend LTD:']", "Fuel Details", true, false);
		
		RC_Global.createNode(driver, "Validate values are available for all the labels");
		
		if(!driver.findElement(By.xpath("//div[div[text()='Total Fuel Spend LTD:']]/div[2]")).getText().equalsIgnoreCase(""))
			queryObjects.logStatus(driver, Status.PASS, "Verify the value against Total Fuel Spend LTD", "The value is displayed for the label", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify the value against Total Fuel Spend LTD", "The value is not displayed for the label", null);
		
		if(!driver.findElement(By.xpath("//div[div[text()='Total # of Transactions:']]/div[2]")).getText().equalsIgnoreCase(""))
			queryObjects.logStatus(driver, Status.PASS, "Verify the value against Total # of Transactions", "The value is displayed for the label", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify the value against Total # of Transactions", "The value is not displayed for the label", null);
		
		if(!driver.findElement(By.xpath("//div[div[text()='Last Transaction Date:']]/div[2]")).getText().equalsIgnoreCase(""))
			queryObjects.logStatus(driver, Status.PASS, "Verify the value against Last Transaction Date", "The value is displayed for the label", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify the value against Last Transaction Date", "The value is not displayed for the label", null);
		
		if(!driver.findElement(By.xpath("//div[div[text()='Last Mileage:']]/div[2]")).getText().equalsIgnoreCase(""))
			queryObjects.logStatus(driver, Status.PASS, "Verify the value against Last Mileage", "The value is displayed for the label", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify the value against Last Mileage", "The value is not displayed for the label", null);
		
		if(!driver.findElement(By.xpath("//div[div[text()='Total Gallons LTD:']]/div[2]")).getText().equalsIgnoreCase(""))
			queryObjects.logStatus(driver, Status.PASS, "Verify the value against Total Gallons LTD", "The value is displayed for the label", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify the value against Total Gallons LTD", "The value is not displayed for the label", null);
		
		if(!driver.findElement(By.xpath("//div[div[text()='Avg Cost Per Gallon:']]/div[2]")).getText().equalsIgnoreCase(""))
			queryObjects.logStatus(driver, Status.PASS, "Verify the value against Avg Cost Per Gallon", "The value is displayed for the label", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify the value against Avg Cost Per Gallon", "The value is not displayed for the label", null);
		
		if(!driver.findElement(By.xpath("//div[div[text()='Life to Date MPG:']]/div[2]")).getText().equalsIgnoreCase(""))
			queryObjects.logStatus(driver, Status.PASS, "Verify the value against Life to Date MPG", "The value is displayed for the label", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify the value against Life to Date MPG", "The value is not displayed for the label", null);
		
		if(!driver.findElement(By.xpath("//div[div[text()='Tank Size:']]/div[2]")).getText().equalsIgnoreCase(""))
			queryObjects.logStatus(driver, Status.PASS, "Verify the value against Tank Size", "The value is displayed for the label", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify the value against Tank Size", "The value is not displayed for the label", null);
		
		if(!driver.findElement(By.xpath("//div[div[text()='Carbon Output (lbs):']]/div[2]")).getText().equalsIgnoreCase(""))
			queryObjects.logStatus(driver, Status.PASS, "Verify the value against Carbon Output (lbs)", "The value is displayed for the label", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify the value against Carbon Output (lbs)", "The value is not displayed for the label", null);
		
		RC_Reporting.panelAction(driver, "close", "Vehicle Details", true, true);
		
		RC_Global.logout(driver, true);
	}
}
