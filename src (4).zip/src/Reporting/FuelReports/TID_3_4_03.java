package Reporting.FuelReports;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_4_03 {
	public void FuelReports_VerifyFuelTransactionDeclinesSearchFunctionality(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		RC_Global.login(driver);
		
		String columnClientData = RC_Reporting.retrieveClientData(driver, "LS008742", 0);
		String columnNames = "Customer Name;Customer Number;Buyer Name;Unit Number;CVN;VIN;Year;Make;Model;Vehicle Description;Card Number;Card Profile;Transaction Date;Transaction Time;Decline Reason;Decline Description;Vendor;"+columnClientData+";Fleet Number;Fleet Name;Account Number;Account Name;Sub-Account Number;Sub-Account Name";
		
		RC_Reporting.navigateTo(driver, "Reporting", "Fuel Reports", "Fuel Transaction Declines");
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);
		
		RC_Global.createNode(driver, "Verify Search Filters");
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Unit Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Vehicle Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Buyer Name", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Card Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Decline Reason", false);
		RC_Global.verifyScreenComponents(driver, "lable", "From Date", false);
		RC_Global.verifyScreenComponents(driver, "lable", "To Date", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Value", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Value", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Number", false);
		
		RC_Global.createNode(driver, "Validate buttons");
		RC_Global.verifyScreenComponents(driver, "button", "Generate Report", false);
		RC_Global.verifyScreenComponents(driver, "button", "Excel", false);
		RC_Global.verifyScreenComponents(driver, "button", "CSV", false);
		RC_Global.verifyScreenComponents(driver, "button", "PDF", false);
		RC_Global.verifyScreenComponents(driver, "button", "XML", false);
		RC_Global.verifyScreenComponents(driver, "button", "Edit Columns", false);
		
		RC_Global.dropdownValuesValidation(driver, "All;Incorrect POS Prompt;Invalid Purchase Location;Other;Profile Limit Exceeded;Terminated Card;Unauthorized Purchase", "//div[label[text()='Decline Reason:']]//select", true, true);
		Select declineReason=new Select(driver.findElement(By.xpath("//div[label[text()='Decline Reason:']]//select")));
		String sDeclineReason=declineReason.getFirstSelectedOption().getText();
		
		RC_Global.clickButton(driver, "Generate Report", true, true);
		RC_Reporting.reportErrorValidation(driver,"//h4[text()='Customer Number is required']");
		
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		RC_Reporting.generateReportValidateResults(driver);
		
		RC_Reporting.validateReportColumnNames(driver, columnNames);
		
		RC_Reporting.clickReportCellHyperLink(driver, "Unit Number", "Vehicle Details");
		RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
		RC_Reporting.panelAction(driver, "expand", "Fuel Transaction Declines",false, false);
		
		if(driver.findElements(By.xpath("((//tbody//tbody)[1]/tr[@valign]/td[4]//a[@style and text()])[1]")).size()>0) {
			RC_Reporting.clickReportCellHyperLink(driver, "CVN", "Vehicle Details");
			RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
			RC_Reporting.panelAction(driver, "expand", "Fuel Transaction Declines",false, false);
		}
		
		RC_Reporting.downloadAndVerifyFileDownloaded(driver, "Fuel Transaction Declines_LS008742", "Excel button - Download validation", true);
		
		RC_Reporting.reportParametersNavigate(driver);
		RC_Reporting.validateReportParameterData(driver, "Decline Reason", sDeclineReason);
		
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
