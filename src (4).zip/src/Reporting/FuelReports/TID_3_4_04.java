package Reporting.FuelReports;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_4_04 {
	public static void FuelReports_VerifyFuelSpendByBuyerDetailSearchFunctionality(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		
		RC_Global.login(driver);
		String columnClientData = RC_Reporting.retrieveClientData(driver, "LS008742", 17);
		String columnNames = "Customer Name;Customer Number;Buyer Name;Unit Number;CVN;VIN;Year;Make;Model;Trim;Body;Drive;Color;Card Number;Transaction Date;Transaction Time;Transaction Odometer;Transaction Gallons;Price Per Gallon;Total Transaction Cost;Purchase Type;Fuel Type;Vendor Name;Vendor City;Vendor State;Vendor County;Vendor Zip;"+columnClientData+";Fleet Number;Fleet Name;Account Number;Account Name;Sub-Account Number;Sub-Account Name";
		
		RC_Global.navigateTo(driver, "Reporting", "Fuel Reports", "Fuel Spend by Buyer Detail");
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);
		
		RC_Global.createNode(driver, "Verify Search Filters");
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Number", true);
		RC_Global.verifyScreenComponents(driver, "lable", "Unit Number", true);
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Vehicle Number", true);
		RC_Global.verifyScreenComponents(driver, "lable", "Buyer Name", true);
		RC_Global.verifyScreenComponents(driver, "lable", "From Date", true);
		RC_Global.verifyScreenComponents(driver, "lable", "To Date", true);
		
		RC_Global.createNode(driver, "Validate buttons");
		RC_Global.verifyScreenComponents(driver, "button", "Generate Report", false);
		RC_Global.verifyScreenComponents(driver, "button", "Excel", false);
		RC_Global.verifyScreenComponents(driver, "button", "CSV", false);
		RC_Global.verifyScreenComponents(driver, "button", "PDF", false);
		RC_Global.verifyScreenComponents(driver, "button", "XML", false);
		RC_Global.verifyScreenComponents(driver, "button", "Edit Columns", false);
		
		RC_Global.clickButton(driver, "Generate Report", true, true);
		RC_Reporting.reportErrorValidation(driver, "//h4[text()='Customer Number is required']");
		
		WebElement fromDateElement = driver.findElement(By.xpath("//input[@id='dateTimeField_From Date']"));
		WebElement toDateElement = driver.findElement(By.xpath("//input[@id='dateTimeField_To Date']"));
	
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		RC_Reporting.fromToDateErrorValidation(driver, fromDateElement, toDateElement);
		
		String fromDate = RC_Global.getDateTime(driver, "MM/dd/yyyy", -365, true);//"12/03/2020";
		String toDate = RC_Global.getDateTime(driver, "MM/dd/yyyy", 0, true);//"12/03/2021";
		RC_Global.enterInput(driver, fromDate, fromDateElement, true, true);
		RC_Global.enterInput(driver, toDate, toDateElement, true, true);
		
		String fDDate= fromDate.split("/")[1].split("")[0];
		String tDDate= toDate.split("/")[1].split("")[0];
		
		String fDMonth= fromDate.split("/")[0].split("")[0];
		String tDMonth= toDate.split("/")[0].split("")[0];
		
		if(fDDate.equalsIgnoreCase("0")&& !fDMonth.equalsIgnoreCase("0"))fromDate = RC_Global.getDateTime(driver, "MM/d/yyyy", -365, true);
		else if(!fDDate.equalsIgnoreCase("0")&& fDMonth.equalsIgnoreCase("0"))fromDate = RC_Global.getDateTime(driver, "M/dd/yyyy", -365, true);
		else if(fDDate.equalsIgnoreCase("0")&& fDMonth.equalsIgnoreCase("0"))fromDate = RC_Global.getDateTime(driver, "M/d/yyyy", -365, true);
		
		if(tDDate.equalsIgnoreCase("0")&& !tDMonth.equalsIgnoreCase("0"))toDate = RC_Global.getDateTime(driver, "MM/d/yyyy", 0, true);
		else if(!tDDate.equalsIgnoreCase("0")&& tDMonth.equalsIgnoreCase("0"))toDate = RC_Global.getDateTime(driver, "M/dd/yyyy", 0, true);
		else if(tDDate.equalsIgnoreCase("0")&& tDMonth.equalsIgnoreCase("0"))toDate = RC_Global.getDateTime(driver, "M/d/yyyy", 0, true);
		
		RC_Reporting.generateReportValidateResults(driver);
		RC_Global.waitElementVisible(driver, 60, "//tbody//td[text()='Customer Name']", "Report Result grid", true, true);
		//Column Validation
		RC_Reporting.validateReportColumnNames(driver, columnNames);
		
		RC_Reporting.clickReportCellHyperLink(driver, "Unit Number", "Vehicle Details");
		RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
		RC_Reporting.panelAction(driver, "expand", "Fuel Spend by Buyer Detail",false, false);
		
		RC_Reporting.verifySortFunction(driver, "CVN", false);
		if(driver.findElements(By.xpath("((//tbody//tbody)[1]/tr[@valign]/td[4]//a[@style and text()])[1]")).size()>0) {
			RC_Reporting.clickReportCellHyperLink(driver, "CVN", "Vehicle Details");
			RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
			RC_Reporting.panelAction(driver, "expand", "Fuel Spend by Buyer Detail",false, false);
		}
		
		Thread.sleep(3000);
		RC_Reporting.downloadAndVerifyFileDownloaded(driver, "Fuel Spend by Buyer Detail_LS008742", "Excel button - Download validation", true);
		Thread.sleep(3000);
		RC_Reporting.reportParametersNavigate(driver);
				
		RC_Reporting.validateCustomerNumberParamData(driver, "LS008742");
		RC_Reporting.validateReportParameterData(driver, "From Date", fromDate+" 12:00:00 AM");
		RC_Reporting.validateReportParameterData(driver, "To Date", toDate+" 12:00:00 AM");
		
		RC_Reporting.panelAction(driver, "close", "Fuel Spend by Buyer Detail", true, true);
		RC_Global.logout(driver, false);
	}
}
