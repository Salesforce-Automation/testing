package Reporting.FuelReports;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_4_14 {
	public void FuelReports_VerifyFuelEconomyTrendingByVehicleSearchFunctionality(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String sVehicleStatus = "Active lease, Active services only, Pending termination";
		String sInterval="Annually"; String sIntervalCount="1";String sIntervalStart="";WebDriverWait wait = new WebDriverWait(driver, 30);
		
		RC_Global.login(driver);
		String columnClientData = RC_Reporting.retrieveClientData(driver, "LS008742", 17);
		
		String columnNames = "Customer Name;Customer Number;Unit Number;CVN;VIN;Year;Make;Model;Trim;Body;Drive;Color;Driver Type;Driver;Driver State;Vehicle Status;Current Odometer;Interval Length;Interval Start Date;Interval End Date;Total Gallons;Fuel Transaction Count;Total Fuel Spend;Total Accumulated Miles;Total Miles Per Gallon;Total MPG Gallons;Total MPG Miles;Average Cost Per Gallon;Average Cost Per Transaction;"+columnClientData+";Employee Data 1;Employee Data 2;Employee Data 3;Fleet Number;Fleet Name;Account Number;Account Name;Sub-Account Number;Sub-Account Name";

		RC_Reporting.navigateTo(driver, "Reporting", "Fuel Reports", "Fuel Economy Trending By Vehicle");
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);

		RC_Global.createNode(driver, "Verify Search Filters");
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Unit Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Vehicle Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "VIN", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Driver Name", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Interval Start", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Interval Count", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Interval", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Vehicle Status", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Value", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Value", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Number", false);

		RC_Global.createNode(driver, "Validate buttons");
		RC_Global.verifyScreenComponents(driver, "button", "Generate Report", false);
		RC_Global.verifyScreenComponents(driver, "button", "Excel", false);
		RC_Global.verifyScreenComponents(driver, "button", "CSV", false);
		RC_Global.verifyScreenComponents(driver, "button", "PDF", false);
		RC_Global.verifyScreenComponents(driver, "button", "XML", false);
		RC_Global.verifyScreenComponents(driver, "button", "Edit Columns", false);

		WebElement eElement = driver.findElement(By.xpath("//button[text()='Generate Report']"));
		WebElement iCount = driver.findElement(By.xpath("//input[@id='integerField_IntervalCount']"));
		WebElement iStart = driver.findElement(By.xpath("//input[@id='dateTimeField_Interval Start']"));
		WebElement interval =driver.findElement(By.xpath("(//select)[1]"));
		Select dDInterval=new Select(interval);

		RC_Global.clickButton(driver, "Generate Report", true, true);
		RC_Reporting.reportErrorValidation(driver,"//h4[text()='Customer Number is required']");

		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		RC_Global.clickButton(driver, "Generate Report", true, true);
		wait.until(ExpectedConditions.elementToBeClickable(eElement));
		
		if(RC_Global.waitElementVisible(driver, 30, "//h4[text()='Interval Count is required']", "Error message", true, false))
		{
			queryObjects.logStatus(driver, Status.PASS, "Interval Count is required - Error Message", "Displayed", null);
			RC_Global.enterInput(driver, sIntervalCount, iCount, false, true);
			RC_Global.clickButton(driver, "Generate Report", true, true);
			wait.until(ExpectedConditions.elementToBeClickable(eElement));
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Interval Count is required - Error Message", "Is Not Displayed", null);
		}
		
		if(RC_Global.waitElementVisible(driver, 30, "//h4[text()='Interval is required']", "Error message", true, false))
		{
			queryObjects.logStatus(driver, Status.PASS, "Interval is required - Error Message", "Displayed", null);
			
			dDInterval.selectByVisibleText(sInterval);
			RC_Global.clickButton(driver, "Generate Report", true, true);
			wait.until(ExpectedConditions.elementToBeClickable(eElement));
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "Interval is required - Error Message", "Is Not Displayed", null);
		}

		if(RC_Global.waitElementVisible(driver, 30, "//h4[contains(text(),'IntervalStart')]", "Error message", true, false))
		{
			queryObjects.logStatus(driver, Status.PASS, "This report requires a default or user-defined value for the report parameter 'IntervalStart' - Error Message", "Displayed", null);
			String iStartDate = RC_Global.getDateTime(driver, "MM/dd/yyyy", -150, true);//"12/03/2021";
			RC_Global.clickUsingXpath(driver, "//div[@class='col-xs-2']/button", "Expand button", false, false);
			RC_Global.enterInput(driver, iStartDate, iStart, true, true);
			RC_Reporting.generateReportValidateResults(driver);

			sIntervalStart=iStart.getAttribute("value");
			sIntervalStart = sIntervalStart.replace("/", "-");
			
			RC_Global.clickUsingXpath(driver, "//div[@class='col-xs-2']/button", "Expand button", false, false);
		}
		else
		{
			queryObjects.logStatus(driver, Status.FAIL, "This report requires a default or user-defined value for the report parameter 'IntervalStart' - Error Message", "Is Not Displayed", null);
		}

		RC_Reporting.validateReportColumnNames(driver, columnNames);

		RC_Reporting.clickReportCellHyperLink(driver, "Unit Number", "Vehicle Details");
		RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
		RC_Reporting.panelAction(driver, "expand", "Fuel Economy Trending By Vehicle",false, false);
		
		if(driver.findElements(By.xpath("(//tbody//tbody)[1]/tr[@valign]/td[1]/table/tbody/tr[@valign]/td[4]//a[@style and text()][1]")).size()>0) {
			RC_Reporting.clickReportCellHyperLink(driver, "CVN", "Vehicle Details");
			RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
			RC_Reporting.panelAction(driver, "expand", "Fuel Economy Trending By Vehicle",false, false);
		}
		
		RC_Reporting.downloadAndVerifyFileDownloaded(driver, "Fuel Economy Trending By Vehicle_LS008742", "Excel button - Download validation", true);

		RC_Reporting.reportParametersNavigate(driver);
		RC_Reporting.validateCustomerNumberParamData(driver, "LS008742");
		RC_Reporting.validateReportParameterData(driver, "Intervals", sInterval);
		RC_Reporting.validateReportParameterData(driver, "Interval Start", sIntervalStart);
		RC_Reporting.validateReportParameterData(driver, "Number of Intervals", sIntervalCount);
		RC_Reporting.validateReportParameterData(driver, "Vehicle Status", sVehicleStatus);
		RC_Reporting.panelAction(driver, "close", "Fuel Economy Trending By Vehicle",false, true);

		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
