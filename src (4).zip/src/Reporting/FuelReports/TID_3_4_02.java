package Reporting.FuelReports;

import org.openqa.selenium.WebDriver;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_4_02 {
	
	public static void FuelReports_VerifyFuelTransactionBillingDetailSearchFunctionality(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{
		RC_Global.login(driver);
      
		String columnClientData = RC_Reporting.retrieveClientData(driver, "LS008742", 0);
		
		RC_Reporting.navigateTo(driver, "Reporting", "Fuel Reports", "Fuel Transaction Billing Detail");
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);
		
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Unit Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Vehicle Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Driver Name", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Employee ID", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Employee Assignment", false);
		RC_Global.verifyScreenComponents(driver, "lable", "From Date", false);
		RC_Global.verifyScreenComponents(driver, "lable", "To Date", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Vendor Name", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Vendor City", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Vendor State", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Vendor Zip Code", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Invoice Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Value", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Value", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Date Type", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Fuel Type", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Vehicle Status", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Purchase Type", false);
		
		
        RC_Global.dropdownValuesValidation(driver, "Regular;Midgrade;Premium;Diesel;DEF;Other Fuel;Non Fuel", "(//select[@ng-model='param.ParameterValue'])[6]", false, true);    

        RC_Global.dropdownValuesValidation(driver, "Transaction Date;Billed Date;Posted Date", "(//select[@ng-model='param.ParameterValue'])[4]", false, true);    

        RC_Global.dropdownValuesValidation(driver, "Fuel;Wash;Other;Fuel Adjustment", "(//select[@ng-model='param.ParameterValue'])[5]", false, true);    

        String sVehicleStatus = "Active lease, Active services only, Pending termination, Closed, On Order, Pending Activation, Sold, Terminated lease, Terminated services only";
		
		RC_Global.verifyScreenComponents(driver, "button", "Excel", false);
		RC_Global.verifyScreenComponents(driver, "button", "CSV", false);
		RC_Global.verifyScreenComponents(driver, "button", "PDF", false);
		RC_Global.verifyScreenComponents(driver, "button", "XML", false);
		RC_Global.verifyScreenComponents(driver, "button", "Edit Columns", false);
		
		RC_Global.waitElementVisible(driver, 60, "//input[@name='customerInput']", "Input CustomerNumber",true, true);		
  		RC_Global.enterCustomerNumber(driver, "LS008742", "", "",true);
  		
        RC_Reporting.generateReportValidateResults(driver);

  		Thread.sleep(4000);
  		
  		RC_Reporting.validateReportColumnNames(driver,"Customer Name;Customer Number;Unit Number;CVN;VIN;Year;Make;Model;Trim;Body;Drive;Color;Driver Type;Driver/Pool;Pool Contact;Driver State;Delivered Date;Vehicle Status;Current Odometer;Transaction Date;"
  				+ "Posted Date;Billed Date;Invoice Number;Transaction Odometer;Transaction Gallons;Price Per Gallon;Total Transaction Cost;Cost Adjustment;Purchase Type;Fuel Type;Vendor Name;Vendor City;Vendor State;Vendor Zip Code;Buyer;Employee ID;Employee Assignment;"+columnClientData+";" 
  				+ "Employee Data 1;Employee Data 2;Employee Data 3;Fleet Number;Fleet Name;Account Number;Account Name;Sub-Account Number;Sub-Account Name");
  		
  		Thread.sleep(4000);
  		
  		RC_Reporting.clickReportCellHyperLink(driver, "Unit Number", "Vehicle Details");
  		RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
  		RC_Reporting.panelAction(driver, "expand", "Fuel Transaction Billing Detail",false, false);
		
		RC_Reporting.clickReportCellHyperLink(driver, "CVN", "Vehicle Details");
		RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
		RC_Reporting.panelAction(driver, "expand", "Fuel Transaction Billing Detail",false, false);
		
		RC_Reporting.clickReportCellHyperLink(driver, "Driver/Pool", "Driver Details");
		RC_Reporting.panelAction(driver, "close", "Driver Details",false, false);
		RC_Reporting.panelAction(driver, "expand", "Fuel Transaction Billing Detail",false, false);
		
		RC_Reporting.downloadAndVerifyFileDownloaded(driver, "Fuel Transaction Billing Detail_LS008742", "Downloading Standard Report Validation", false);

		RC_Reporting.reportParametersNavigate(driver);
		RC_Reporting.validateReportParameterData(driver, "Customer Number", "LS008742");
		
		RC_Reporting.validateReportParameterData(driver, "Report Date Range", "Use Date Range");

		RC_Reporting.validateReportParameterData(driver, "Date Type", "Billed Date");
		
		RC_Reporting.validateReportParameterData(driver, "Vehicle Status", sVehicleStatus);

		RC_Reporting.panelAction(driver, "close", "Fuel Transaction Billing Detail", true, true);
		RC_Global.logout(driver, true);
		
	}
}
