package Reporting.FuelReports;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_4_17 {
	public void FuelReports_VerifyFuelSpendByBuyerSummarySearchFunctionality(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String columnNames = "Customer Name;Customer Number;Buyer Name;Total Fuel Transaction Spend;Total Non-Fuel Transaction Spend;Total Non-Fuel Transaction Count;Total Spend;Total Transactions;Total Gallons;Last Purchase Date";
		
		RC_Global.login(driver);
		RC_Reporting.navigateTo(driver, "Reporting", "Fuel Reports", "Fuel Spend by Buyer Summary");
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);

		RC_Global.createNode(driver, "Verify Search Filters");
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Buyer Name", false);
		RC_Global.verifyScreenComponents(driver, "lable", "From Date", false);
		RC_Global.verifyScreenComponents(driver, "lable", "To Date", false);
		
		RC_Global.createNode(driver, "Validate buttons");
		RC_Global.verifyScreenComponents(driver, "button", "Generate Report", false);
		RC_Global.verifyScreenComponents(driver, "button", "Excel", false);
		RC_Global.verifyScreenComponents(driver, "button", "CSV", false);
		RC_Global.verifyScreenComponents(driver, "button", "PDF", false);
		RC_Global.verifyScreenComponents(driver, "button", "XML", false);
		RC_Global.verifyScreenComponents(driver, "button", "Edit Columns", false);
		
		RC_Global.clickButton(driver, "Generate Report", true, true);
		RC_Reporting.reportErrorValidation(driver,"//h4[text()='Customer Number is required']");
		
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		RC_Reporting.generateReportValidateResults(driver);
		
		RC_Reporting.validateReportColumnNames(driver, columnNames);
		
		RC_Reporting.downloadAndVerifyFileDownloaded(driver, "Fuel Spend by Buyer Summary_LS008742", "Excel button - Download validation", true);
		
		RC_Reporting.reportParametersNavigate(driver);
		RC_Reporting.validateCustomerNumberParamData(driver, "LS008742");
	
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
