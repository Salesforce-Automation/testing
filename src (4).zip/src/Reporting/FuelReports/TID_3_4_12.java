package Reporting.FuelReports;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_4_12 {
	public static void FuelReports_VerifyFuelDaysSinceLastPurchaseSearchFunctionality(WebDriver driver, BFrameworkQueryObjects queryObjects)throws Exception{
		
		RC_Global.login(driver);
		String columnClientData = RC_Reporting.retrieveClientData(driver, "LS008742", 17);
		String columnNames = "Customer Name;Customer Number;Unit Number;CVN;VIN;Year;Make;Model;Last Fuel Card #;Total Transactions;Total Gallons;Total Fuel Spend;Days Since Last Fuel Purchase;Last Fuel Purchase Date;Last Fuel Purchase Buyer;Days Since Last Non Fuel Purchase;Last Non Fuel Purchase Date;Last Non Fuel Purchase Buyer;Card Status;"+columnClientData+";Fleet Number;Fleet Name;Account Number;Account Name;Sub-Account Number;Sub-Account Name";
		
		RC_Global.navigateTo(driver, "Reporting", "Fuel Reports", "Fuel Days Since Last Purchase");
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);
		
		RC_Global.createNode(driver, "Verify Search Filters");
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Number", true);
		RC_Global.verifyScreenComponents(driver, "lable", "Unit Number", true);
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Vehicle Number", true);
		RC_Global.verifyScreenComponents(driver, "lable", "Card Number", true);
		RC_Global.verifyScreenComponents(driver, "lable", "Days Since Last Purchase", true);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Value", true);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Number", true);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Value", true);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Number", true);
		RC_Global.verifyScreenComponents(driver, "lable", "Card Status", true);
		
		RC_Global.createNode(driver, "Validate buttons");
		RC_Global.verifyScreenComponents(driver, "button", "Generate Report", false);
		RC_Global.verifyScreenComponents(driver, "button", "Excel", false);
		RC_Global.verifyScreenComponents(driver, "button", "CSV", false);
		RC_Global.verifyScreenComponents(driver, "button", "PDF", false);
		RC_Global.verifyScreenComponents(driver, "button", "XML", false);
		RC_Global.verifyScreenComponents(driver, "button", "Edit Columns", false);
		
		String cardStatus = "Active, Terminated, Fraud, Termination Pending";
		String daysSinceLastPurchase = driver.findElement(By.xpath("//div[label[text()='Days Since Last Purchase:']]//input")).getAttribute("value");
		
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		
		RC_Reporting.generateReportValidateResults(driver);
		RC_Global.waitElementVisible(driver, 60, "//tbody//td[text()='Customer Name']", "Report Result grid", true, true);
		//Column Validation
		RC_Reporting.validateReportColumnNames(driver, columnNames);
		
		RC_Reporting.clickReportCellHyperLink(driver, "Unit Number", "Vehicle Details");
		RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
		RC_Reporting.panelAction(driver, "expand", "Fuel Days Since Last Purchase",false, false);
		
		RC_Reporting.verifySortFunction(driver, "CVN", false);
		if(driver.findElements(By.xpath("((//tbody//tbody)[1]/tr[@valign]/td[4]//a[@style and text()])[1]")).size()>0) {
			RC_Reporting.clickReportCellHyperLink(driver, "CVN", "Vehicle Details");
			RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
			RC_Reporting.panelAction(driver, "expand", "Fuel Days Since Last Purchase",false, false);
		}
		
		Thread.sleep(3000);
		RC_Reporting.downloadAndVerifyFileDownloaded(driver, "Fuel Days Since Last Purchase_LS008742", "Excel button - Download validation", true);
		Thread.sleep(3000);
		RC_Reporting.reportParametersNavigate(driver);
			
		RC_Reporting.validateCustomerNumberParamData(driver, "LS008742");
		RC_Reporting.validateReportParameterData(driver, "Days Since Last Purchase", daysSinceLastPurchase);
		RC_Reporting.validateReportParameterData(driver, "Card Status", cardStatus);
		
		RC_Reporting.panelAction(driver, "close", "Fuel Days Since Last Purchase", true, true);
		RC_Global.logout(driver, false);
	}
}
