package Reporting.ExceptionReports;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_3_01 {
	public static void ExceptionReports_VerifyMissingPreventativeMaintenanceSearchFunctionalityAndUIExceptions(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{

		
		
		RC_Global.login(driver);
	    
		String columnClientData = RC_Reporting.retrieveClientData(driver, "LS008742", 17);
		
		String columnNames="Customer Name;Customer Number;Unit Number;CVN;VIN;Year;Make;Model;Trim;Body;Drive;Color;Driver Type;Driver/Pool;Pool Contact;Vehicle Status;Delivered Date;Months In Service;Months Enrolled;Current Odometer;Maintenance Agreement Type;Last Service Date;Last Service Mileage;Last Service PO Number;Last PM Service Mileage;Last PM Service Date;Last PM PO Number;Miles Since Last LOF ;Days Since Last LOF ;Days Since Last LOF ;LOF Interval;Miles Since Last Tire Rotation;Days Since Last Tire Rotation;Tire Rotation Interval;Miles Since Last Service;Days Since Last Service;"+columnClientData+";Employee Data 1;Employee Data 2;Employee Data 3;Fleet Number;Fleet Name;Account Number;Account Name;Sub-Account Number;Sub-Account Name";
		RC_Reporting.navigateTo(driver, "Reporting", "Exception Reports", "Missing Preventative Maintenance");
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);

		RC_Global.verifyScreenComponents(driver, "lable", "Customer Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Unit Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Vehicle Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Driver Name", false);

		RC_Global.verifyScreenComponents(driver, "lable", "Miles Since Last LOF Interval", false);
		RC_Global.verifyScreenComponents(driver, "lable", "LOF Miles Filter", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Miles Since Last Tire Rotation Interval", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Tire Rotation Miles Filter", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Miles Since Last LOF Service", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Days Since Last LOF Service", false);
		RC_Global.verifyScreenComponents(driver, "lable", "VIN", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Vehicle Status", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Value", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Value", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Maintenance Agreement Types", false);
		
		
		RC_Global.verifyScreenComponents(driver, "button", "Excel", false);
		RC_Global.verifyScreenComponents(driver, "button", "CSV", false);
		RC_Global.verifyScreenComponents(driver, "button", "PDF", false);
		RC_Global.verifyScreenComponents(driver, "button", "XML", false);
		RC_Global.verifyScreenComponents(driver, "button", "Edit Columns", false);
		
		
		RC_Global.dropdownValuesValidation(driver, "Active lease;Active services only;Cancelled;Closed;On Order;Pending Activation;Pending termination;Sold;Terminated lease;Terminated serives only", "//div[label[text()='Vehicle Status:']]//select", false, true);    
	    RC_Reporting.selectMultipleOptionsFromSelection(driver, "Vehicle Status", "Active lease--Active services only--On Order--Pending Activation--Pending termination", false);

        List<WebElement> vehicleStatus = driver.findElements(By.xpath("//div[label[text()='Vehicle Status:']]//select/option"));
		String sVehicleStatus = "";
		int iter = 0;
		for(WebElement vs:vehicleStatus) {
			if(vs.isSelected()) {
				if(!sVehicleStatus.equalsIgnoreCase(""))
					sVehicleStatus = sVehicleStatus+", "+vs.getText();
				else
					sVehicleStatus = vs.getText();
			}
		}
	    RC_Global.dropdownValuesValidation(driver, "All;Greater than Interval;Less than Interval", "(//select[@ng-model='param.ParameterValue'])[1]", false, true);
	    
	    RC_Global.dropdownValuesValidation(driver, "All;Greater than Interval;Less than Interval", "(//select[@ng-model='param.ParameterValue'])[2]", false, true);
	    
	    RC_Global.dropdownValuesValidation(driver, "Full;Administered;Reserve", "//div[label[text()='Maintenance Agreement Types:']]//select", false, true);
	    RC_Reporting.selectMultipleOptionsFromSelection(driver, "Maintenance Agreement Types", "Full--Administered--Reserve", false);

        List<WebElement> maintenanceAgreementType = driver.findElements(By.xpath("//div[label[text()='Maintenance Agreement Types:']]//select/option"));
		String sMaintenanceAgreementType = "";
		iter = 0;
		for(WebElement vs:maintenanceAgreementType) {
			if(vs.isSelected()) {
				if(!sMaintenanceAgreementType.equalsIgnoreCase(""))
					sMaintenanceAgreementType = sMaintenanceAgreementType+", "+vs.getText();
				else
					sMaintenanceAgreementType = vs.getText();
			}
		}
	    
  		RC_Global.clickButton(driver, "Generate Report", false, true);

	    RC_Reporting.reportErrorValidation(driver, "//h4[text()='Customer Number is required']");
	    
	    RC_Global.waitElementVisible(driver, 60, "//input[@name='customerInput']", "Input CustomerNumber",true, true);		
  		RC_Global.enterCustomerNumber(driver, "LS008742", "", "",true);
  		
  		RC_Reporting.generateReportValidateResults(driver);
  		
  		RC_Reporting.validateReportColumnNames(driver, columnNames);
  		
  		RC_Reporting.verifySortFunction(driver, "Unit Number", true);
		RC_Reporting.verifySortFunction(driver, "Year", true);
		
		RC_Reporting.clickReportCellHyperLink(driver, "Unit Number", "Vehicle Details");
		RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
		RC_Reporting.panelAction(driver, "expand", "Missing Preventative Maintenance",false, false);
		
		RC_Reporting.verifySortFunction(driver, "CVN", false);
		if(driver.findElements(By.xpath("((//tbody//tbody)[1]/tr[@valign]/td[4]//a[@style and text()])[1]")).size()>0) {
			RC_Reporting.clickReportCellHyperLink(driver, "CVN", "Vehicle Details");
			RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
			RC_Reporting.panelAction(driver, "expand", "Missing Preventative Maintenance",false, false);
		}
		
		
		RC_Reporting.clickReportCellHyperLink(driver, "Driver/Pool", "Driver Details");
		RC_Reporting.panelAction(driver, "close", "Driver Details",false, false);
		RC_Reporting.panelAction(driver, "expand", "Missing Preventative Maintenance",false, false);
		
		Thread.sleep(3000);
		RC_Reporting.downloadAndVerifyFileDownloaded(driver, "Missing Preventative Maintenance_LS008742", "Excel button - Download validation", true);
		
		Thread.sleep(3000);
		RC_Reporting.reportParametersNavigate(driver);
		RC_Reporting.validateCustomerNumberParamData(driver, "LS008742");
		

		RC_Reporting.validateReportParameterData(driver, "Miles Since Last LOF Interval", "All");
		RC_Reporting.validateReportParameterData(driver, "Miles Since Last Tire Rotation Interval", "All");
		RC_Reporting.validateReportParameterData(driver, "Exclude Client Data Number", "Full");
		
		RC_Reporting.validateReportParameterData(driver, "Maintenace Agreement Types", sMaintenanceAgreementType);
		RC_Reporting.validateReportParameterData(driver, "Vehicle Statuses", sVehicleStatus);

		RC_Reporting.panelAction(driver, "close", "Missing Preventative Maintenance", true, true);
		RC_Global.logout(driver, true);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
		
	}
	

}
