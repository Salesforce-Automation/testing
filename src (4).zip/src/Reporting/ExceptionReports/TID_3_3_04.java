package Reporting.ExceptionReports;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_3_04 {
	
	public static void ExceptionReports_VerifyPurchaseOrdersPendingApprovalSearchFunctionalityAndUIExceptions(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{

		
		
		RC_Global.login(driver);
		
		String columnClientData = RC_Reporting.retrieveClientData(driver, "LS008742", 17);
		
		
		String columnNames="Customer Name;Customer Number;Unit Number;CVN;VIN;Year;Make;Model;Trim;Body;Drive;Color;Driver Type;Driver/Pool;Pool Contact;Vehicle Status;Delivered Date;Months In Service;Months Enrolled;Current Odometer;Maintenance Agreement Type;Service Date;Repair Mileage;PO Number;PO Status;Estimated Cost;Total Estimated PO Cost;Vendor Name;Preferred Vendor;Repaired System;Repaired Component;Repaired Item;"+columnClientData+";Employee Data 1;Employee Data 2;Employee Data 3;Fleet Number;Fleet Name;Account Number;Account Name;Sub-Account Number;Sub-Account Name";

	      
		RC_Reporting.navigateTo(driver, "Reporting", "Exception Reports", "Purchase Orders Pending Approval");
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);

		RC_Global.verifyScreenComponents(driver, "lable", "Customer Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Unit Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Vehicle Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Driver Name", false);
		RC_Global.verifyScreenComponents(driver, "lable", "VIN", false);
		RC_Global.verifyScreenComponents(driver, "lable", "PO Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Preferred Vendor", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Value", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Value", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Maintenance Agreement Types", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Vehicle Status", false);
		
		RC_Global.verifyScreenComponents(driver, "button", "Excel", false);
		RC_Global.verifyScreenComponents(driver, "button", "CSV", false);
		RC_Global.verifyScreenComponents(driver, "button", "PDF", false);
		RC_Global.verifyScreenComponents(driver, "button", "XML", false);
		RC_Global.verifyScreenComponents(driver, "button", "Edit Columns", false);
		
//		RC_Global.dropdownValuesValidation(driver, "Active lease;Active services only;Cancelled;Closed;On Order;Pending Activation;Pending termination;Sold;Terminated lease;Terminated serives only", "//div[label[text()='Vehicle Status:']]//select", false, true);    
//	    RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Vehicle Status", "Active lease;Active services only;Pending termination", false);
	    
	    
//	    RC_Global.dropdownValuesValidation(driver, "Full;Administered;Reserve", "//div[label[text()='Maintenance Agreement Types:']]//select", false, true);
//		RC_Global.selectOptionsFromMultipleSelectionSearchFilter(driver, "Maintenance Agreement Types", "Full;Administered;Reserve", false);
		
		
//		RC_Global.dropdownValuesValidation(driver, "Y;N", "(//select[@ng-model='param.ParameterValue'])[1]", false, true);
		
		RC_Global.clickButton(driver, "Generate Report", false, true);

		RC_Reporting.reportErrorValidation(driver, "//h4[text()='Customer Number is required']");
		
	    RC_Global.waitElementVisible(driver, 60, "//input[@name='customerInput']", "Input CustomerNumber",true, true);		
  		RC_Global.enterCustomerNumber(driver, "LS008742", "", "",true);
  		
  		RC_Reporting.generateReportValidateResults(driver);

  		Thread.sleep(4000);
  		
  		RC_Reporting.validateReportColumnNames(driver, columnNames);
  		
  		RC_Reporting.clickReportCellHyperLink(driver, "Unit Number", "Vehicle Details");
		RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
		RC_Reporting.panelAction(driver, "expand", "Purchase Orders Pending Approval",false, false);
		
		
		RC_Reporting.verifySortFunction(driver, "CVN", false);
		if(driver.findElements(By.xpath("((//tbody//tbody)[1]/tr[@valign]/td[4]//a[@style and text()])[1]")).size()>0) {
		RC_Reporting.clickReportCellHyperLink(driver, "CVN", "Vehicle Details");
		RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
		RC_Reporting.panelAction(driver, "expand", "Purchase Orders Pending Approval",false, false);
		}
		
		
		
		RC_Reporting.clickReportCellHyperLink(driver, "Driver/Pool", "Driver Details");
		RC_Reporting.panelAction(driver, "close", "Driver Details",false, false);
		RC_Reporting.panelAction(driver, "expand", "Purchase Orders Pending Approval",false, false);
		
		Thread.sleep(3000);
		RC_Reporting.downloadAndVerifyFileDownloaded(driver, "Purchase Orders Pending Approval_LS008742", "Excel button - Download validation", true);
		
		Thread.sleep(3000);
		RC_Reporting.reportParametersNavigate(driver);
		RC_Reporting.validateCustomerNumberParamData(driver, "LS008742");
		
		RC_Reporting.validateReportParameterData(driver, "Maintenance Agreement Type", "Full, Administered, Reserve");
		RC_Reporting.validateReportParameterData(driver, "Vehicle Status", "Active lease, Active services only, Pending termination");
	
		RC_Reporting.panelAction(driver, "close", "Purchase Orders Pending Approval", true, true);
		RC_Global.logout(driver, true);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);    
		
		
	}
	

}
