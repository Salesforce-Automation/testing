package Reporting.ExceptionReports;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import MF.Source.Cred;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_3_05 {
	
	public static void ExceptionReports_VerifyUnitsMissingLube_Oil_FilterServiceSearchFunctionalityAndUIExceptions(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{

		
		RC_Global.login(driver);
		
		String columnClientData = RC_Reporting.retrieveClientData(driver, "LS008742", 17);
		
		String columnNames="Customer Name;Customer Number;Unit Number;CVN;VIN;Year;Make;Model;Trim;Drive;Driver/Pool;Segment;LOF Mileage Interval;LOF Days Interval;"
				+ "Vehicle Status;Current Odometer;Maintenance Agreement Type;Last PM Service Mileage;Last PM Service Date;Last LOF Service Mileage;Last LOF Service Date;"
				+ "Last LOF PO Number;Miles Past LOF;Days Past LOF;Miles Since Last LOF;Days Since Last LOF;Last LOF Alert;Total LOF Alerts Since Prior Service;"+columnClientData+";"
						+ "Fleet Number;Fleet Name;Account Number;Account Name;Sub-Account Number;Sub-Account Name";

		String reportNameInTest = null;
		String Env=Cred.ENV;
		if(Env.equalsIgnoreCase("PROD")) {reportNameInTest = "Units Missing Lube Oil Filter Service";}
		else {reportNameInTest = "Units Missing Lube/Oil/Filter Service";}
	      
		RC_Reporting.navigateTo(driver, "Reporting", "Exception Reports", reportNameInTest);
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Unit Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Vehicle Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Segment", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Miles Past Assigned Interval", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Days Past Assigned Interval:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Driver/Pool Name:", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Vehicle Status", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Value", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Client Data Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Value", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Exclude Client Data Number", false);
		
		
		RC_Global.verifyScreenComponents(driver, "button", "Excel", false);
		RC_Global.verifyScreenComponents(driver, "button", "CSV", false);
		RC_Global.verifyScreenComponents(driver, "button", "PDF", false);
		RC_Global.verifyScreenComponents(driver, "button", "XML", false);
		RC_Global.verifyScreenComponents(driver, "button", "Edit Columns", false);
			
		  RC_Global.clickButton(driver, "Generate Report", true, true);			
		  RC_Reporting.reportErrorValidation(driver,"//h4[text()='Customer Number is required']");		  
		  Thread.sleep(4000);
	  		
		  List<WebElement> segment = driver.findElements(By.xpath("//div[label[text()='Segment:']]//select/option"));
			String sSegment = "";
			int iter = 0;
			for(WebElement vs:segment) {
				if(vs.isSelected()) {
					if(!sSegment.equalsIgnoreCase(""))
						sSegment = sSegment+", "+vs.getText();
					else
						sSegment = vs.getText();
				}
			}
		  RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		  
		  RC_Reporting.generateReportValidateResults(driver);
		  RC_Reporting.validateReportColumnNames(driver, columnNames);
		  
		  RC_Reporting.clickReportCellHyperLink(driver, "Unit Number", "Vehicle Details");
		  RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
		  RC_Reporting.panelAction(driver, "expand", reportNameInTest,false, false);
			
			RC_Reporting.verifySortFunction(driver, "CVN", false);
			if(driver.findElements(By.xpath("((//tbody//tbody)[1]/tr[@valign]/td[4]//a[@style and text()])[1]")).size()>0) {
			RC_Reporting.clickReportCellHyperLink(driver, "CVN", "Vehicle Details");
			RC_Reporting.panelAction(driver, "close", "Vehicle Details",false, false);
			RC_Reporting.panelAction(driver, "expand", reportNameInTest,false, false);
			}
						
			RC_Reporting.clickReportCellHyperLink(driver, "Driver/Pool", "Driver Details");
			RC_Reporting.panelAction(driver, "close", "Driver Details",false, false);
			RC_Reporting.panelAction(driver, "expand", reportNameInTest,false, false);
			
			Thread.sleep(3000);
			RC_Reporting.downloadAndVerifyFileDownloaded(driver, "Units Missing Lube Oil Filter Service_LS008742", "Excel button - Download validation", true);
			
			Thread.sleep(3000);
			RC_Reporting.reportParametersNavigate(driver);
			RC_Reporting.validateCustomerNumberParamData(driver, "LS008742");
			RC_Reporting.validateReportParameterData(driver, "Vehicle Statuses", "Active lease, Active services only, Pending termination");
			if(Env.equalsIgnoreCase("PROD")) {
				RC_Reporting.validateReportParameterData(driver, "Segment", sSegment);
			}			
			RC_Reporting.panelAction(driver, "close", reportNameInTest,false, false);
			
			RC_Global.logout(driver, true);
			queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

		
		
	}

}