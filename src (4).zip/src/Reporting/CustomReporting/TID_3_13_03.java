package Reporting.CustomReporting;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_CustomReporting;

public class TID_3_13_03 {
	public void ValidateReportDomainTableAndSavingTheReportFunctionality (WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception {
		String[] fieldsToBeSelected = {"Customer Name"};
		String[] fieldsToBeSelected2 = {"Driver","Driver Type"};
		String ReportName = "Sample Report"+RandomStringUtils.randomNumeric(3);
		
		WebDriverWait wait = new WebDriverWait(driver,120);
		
		
		RC_Global.login(driver);
		RC_Global.navigateTo(driver, "Reporting", "Custom Reporting", "");
		RC_Global.enterCustomerNumber(driver, "LS010143", "", "",false);
		RC_Global.waitUntilPanelVisibility(driver, "Dashboard", "Total View", true, true);
		RC_Global.clickButton(driver, "Create New Report", true, true);
		RC_CustomReporting.selectAReportingDomain(driver,"List of Fleet");
//		RC_Global.panelAction(driver, "close", "Fleet Domain");
		RC_Global.panelAction(driver, "expand", "Custom Report", false, false);
		Thread.sleep(5000);
		WebElement powerBIFrame = driver.findElement(By.xpath("//div[contains(@id,'report-container')]/iframe"));
		RC_CustomReporting.switchFrame(driver,powerBIFrame);
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//button[@aria-label='Visualizations']"))));
		RC_CustomReporting.selectPowerBIIcon(driver,"Table");
		RC_Global.clickButton(driver, "Focus mode", true, true);
		Thread.sleep(2000);
		
		RC_CustomReporting.selectFields(driver, "List of Fleet", "01-Customer Hierarchy", fieldsToBeSelected);
		
		RC_CustomReporting.selectFields(driver, "List of Fleet", "03-Driver - Pool", fieldsToBeSelected2);
		
		RC_Global.clickButton(driver, "Save", true, true);
		
		driver.switchTo().defaultContent();
		
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//input[@id='reportName']"))));
		
		RC_CustomReporting.saveReport(driver, ReportName);
		
		RC_Global.panelAction(driver, "expand", "Fleet Domain", false, false);
		
		RC_CustomReporting.reportGridActionsClick(driver, "View", ReportName);		
		
		Thread.sleep(10000);;
		RC_Global.panelAction(driver, "close", "Custom Report", false, false);
//		RC_Global.ClickButton(driver, "No");
		RC_Global.panelAction(driver, "expand", "Fleet Domain", false, false);
		Thread.sleep(1000);
		
		RC_Global.verifySortFunction(driver, "Customer Name", false);
		RC_Global.verifySortFunction(driver, "Report Name", false);
		RC_Global.verifySortFunction(driver, "Status", false);
		RC_Global.verifySortFunction(driver, "Last View Date", false);
		RC_Global.verifySortFunction(driver, "Created By", false);
		
	}
}
