package Reporting.CustomReporting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_CustomReporting;

public class TID_3_13_01 {
	public void CustomReportingDashboard_LOFOrFuelOrMaintenanceLandingPage(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception{
		String ColumnNames= "Customer Name;Report Name;Status;Actions;Last View Date;Created By";
		WebDriverWait wait = new WebDriverWait(driver,120);
		String[] reportingDomain = {"List of Fleet", "Fuel", "Maintenance"};
		
		for(int iterator=0;iterator<2;iterator++) {
			if(iterator==0)
				RC_Global.login(driver);
			else if(iterator==1)
				RC_Global.externalUserLogin(driver,"gentest", "No");
			RC_Global.navigateTo(driver, "Reporting", "Custom Reporting", "");
			RC_Global.waitUntilPanelVisibility(driver, "Custom Reporting", "Total View", true, false);
			Thread.sleep(5000);
			RC_Global.verifyScreenComponents(driver, "input", "Customer #", false);
			
			
			RC_Global.verifyScreenComponents(driver, "link", "List of Fleet", false);
			RC_Global.verifyScreenComponents(driver, "image", "cars", false);
			RC_Global.verifyScreenComponents(driver, "link", "Fuel", false);
			RC_Global.verifyScreenComponents(driver, "image", "fuel", false);
			RC_Global.verifyScreenComponents(driver, "link", "Maintenance", false);
			RC_Global.verifyScreenComponents(driver, "image", "maintenance", false);
			RC_Global.verifyScreenComponents(driver, "link", "Saved Reports", false);
			
			for(String rd:reportingDomain) {
				RC_CustomReporting.selectAReportingDomain(driver,rd);
				RC_Global.verifyScreenComponents(driver, "link", "Dashboard", false);
				RC_Global.verifyScreenComponents(driver, "input", "Customer #", false);
				RC_Global.verifyScreenComponents(driver, "button", "Create New Report", true);
				RC_Global.verifyScreenComponents(driver, "grid", "", true);
				
				RC_Global.verifyColumnNames(driver, ColumnNames, true);
				
				RC_Global.clickButton(driver, "Create New Report", true, true);
				
				RC_Global.panelAction(driver, "expand", "Custom Report", false, false);
				
				Thread.sleep(10000);
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//div[contains(@id,'report-container')]/iframe"))));
				RC_CustomReporting.switchFrame(driver,driver.findElement(By.xpath("//div[contains(@id,'report-container')]/iframe")));
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//button[@aria-label='Visualizations']"))));
				queryObjects.logStatus(driver, Status.PASS, "To verify that Power BI Frame screen is open", "Power BI Frame screen opens successfully", null);
				
				driver.switchTo().defaultContent();
				
				RC_Global.panelAction(driver, "close", "Custom Report", false, false);
				RC_Global.clickButton(driver, "No", false, false);
				if(rd.equalsIgnoreCase("List of Fleet"))
					RC_Global.panelAction(driver, "expand", "Fleet Domain", false, false);
				else if(rd.equalsIgnoreCase("Fuel"))
					RC_Global.panelAction(driver, "expand", "Fuel Domain", false, false);
				else if(rd.equalsIgnoreCase("Maintenance"))
					RC_Global.panelAction(driver, "expand", "Maintenance Domain", false, false);
				
				RC_Global.clickUsingXpath(driver, "//a[text()='Dashboard']","Dashboard", true, true);
				
				RC_Global.waitUntilPanelVisibility(driver, "Custom Report", "Total View", false, true);
				
				queryObjects.logStatus(driver, Status.PASS, "To navigate to Custom Reporting landing Page", "Navigation Successful", null);
				Thread.sleep(5000);
			}
			
			RC_Global.logout(driver, false);
		
		}
	}
}
