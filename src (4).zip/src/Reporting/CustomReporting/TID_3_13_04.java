package Reporting.CustomReporting;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_CustomReporting;

public class TID_3_13_04 {

	public void ViewEditActiveAndDeactivateReports(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception {
		WebDriverWait wait = new WebDriverWait(driver, 50);
		String[] fieldsToBeSelected = {"Body"};
		String ReportName = "Sample Report"+RandomStringUtils.randomNumeric(3);

		for (int iterator = 0; iterator < 2; iterator++) {
			if (iterator == 0)
			    RC_Global.login(driver);
			else if (iterator == 1)
				RC_Global.externalUserLogin(driver, "gentest","No");
			
			RC_CustomReporting.SearchReport(driver,ReportName);
			RC_Global.navigateTo(driver, "Reporting", "Custom Reporting", "");
			RC_Global.waitUntilPanelVisibility(driver, "Custom Reporting", "Total View", true, false);
			RC_Global.clickLink(driver, "Saved Reports", true, true);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//u[text()='Saved Reports']"))));
			RC_Global.clickicon(driver, "Edit", true, true);
				
			RC_Global.panelAction(driver, "expand", "Custom Report", false, false);
			Thread.sleep(5000);
			WebElement powerBIFrame = driver.findElement(By.xpath("//div[contains(@id,'report-container')]/iframe"));
			RC_CustomReporting.switchFrame(driver,powerBIFrame);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//button[@aria-label='Visualizations']"))));
			RC_CustomReporting.selectPowerBIIcon(driver,"Table");
			RC_Global.clickButton(driver, "Focus mode", true, true);
			Thread.sleep(2000);
			
			RC_CustomReporting.selectFields(driver, "List of Fleet", "04-Vehicle", fieldsToBeSelected);
			
			driver.switchTo().defaultContent();
			RC_Global.clickButton(driver, "Save this report", true, true);
			RC_Global.panelAction(driver, "expand", "Fleet Domain", false, false);
			Thread.sleep(5000);
		
			
			RC_Global.logout(driver, false);
		}
	}

}
