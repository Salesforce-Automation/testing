package Reporting.PersonalUseReports;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_8_03 {
	public void PersonalUseReports_VerifyEmployeesMissingMileageSearchFunctionality(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String columnNames = "Customer Name;Customer Number;Employee Name;Employee ID;Missing Period Start Date;Missing Period End Date;Employee Data 1;Employee Data 2;Employee Data 3;Fleet Number;Fleet Name;Account Number;Account Name;Sub-Account Number;Sub-Account Name";
		RC_Global.login(driver);
		RC_Reporting.navigateTo(driver, "Reporting", "Personal Use Reports", "Employees Missing Mileage");
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);
		
		RC_Global.createNode(driver, "Verify Search Filters");
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Employee Name", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Employee ID", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Missing Period From Date", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Missing Period To Date", false);
		
		RC_Global.createNode(driver, "Validate buttons");
		RC_Global.verifyScreenComponents(driver, "button", "Generate Report", false);
		RC_Global.verifyScreenComponents(driver, "button", "Excel", false);
		RC_Global.verifyScreenComponents(driver, "button", "CSV", false);
		RC_Global.verifyScreenComponents(driver, "button", "PDF", false);
		RC_Global.verifyScreenComponents(driver, "button", "XML", false);
		RC_Global.verifyScreenComponents(driver, "button", "Edit Columns", false);
		
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		RC_Reporting.generateReportValidateResults(driver);
		
		RC_Reporting.validateReportColumnNames(driver, columnNames);
		
		RC_Reporting.downloadAndVerifyFileDownloaded(driver, "Employees Missing Mileage_LS008742", "Excel button - Download validation", true);
		
		RC_Reporting.reportParametersNavigate(driver);
		RC_Reporting.validateCustomerNumberParamData(driver, "LS008742");
		
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
