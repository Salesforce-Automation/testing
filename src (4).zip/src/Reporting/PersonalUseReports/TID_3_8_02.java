package Reporting.PersonalUseReports;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_8_02 {
	public void PersonalUseReports_VerifyBusinessAndPersonalUseSearchFunctionality(WebDriver driver, BFrameworkQueryObjects queryObjects) throws Exception
	{
		String columnNames = "Customer Name;Customer Number;Employee Name;Employee ID;Total # of Days Enrolled;Total # of Days Reported;Total Miles;Total Personal Miles;Total Business Miles;Total Personal Use %;Total Vehicle Benefit;Total Personal Fuel;Year-End Total Benefit To Date;Employee Data 1;Employee Data 2;Employee Data 3";
		RC_Global.login(driver);
		RC_Reporting.navigateTo(driver, "Reporting", "Personal Use Reports", "Business and Personal Use");
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);

		RC_Global.createNode(driver, "Verify Search Filters");
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Number", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Employee Name", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Employee ID", false);
		RC_Global.verifyScreenComponents(driver, "lable", "Reporting Year", false);
		
		RC_Global.createNode(driver, "Validate buttons");
		RC_Global.verifyScreenComponents(driver, "button", "Generate Report", false);
		RC_Global.verifyScreenComponents(driver, "button", "Excel", false);
		RC_Global.verifyScreenComponents(driver, "button", "CSV", false);
		RC_Global.verifyScreenComponents(driver, "button", "PDF", false);
		RC_Global.verifyScreenComponents(driver, "button", "XML", false);
		RC_Global.verifyScreenComponents(driver, "button", "Edit Columns", false);
		
		RC_Global.dropdownValuesValidation(driver, "November 1 2020 - October 31 2021;November 1 2019 - October 31 2020;November 1 2018 - October 31 2019;November 1 2017 - October 31 2018;November 1 2016 - October 31 2017", "//select", true, true);
		Select rYear=new Select(driver.findElement(By.xpath("//select")));
		String sRYear = rYear.getFirstSelectedOption().getText();
		
		RC_Global.clickButton(driver, "Generate Report", true, true);
		RC_Reporting.reportErrorValidation(driver,"//h4[text()='Customer Number is required']");
		
		RC_Global.enterCustomerNumber(driver, "LS008742", "", "", true);
		RC_Reporting.generateReportValidateResults(driver);
		
		RC_Reporting.validateReportColumnNames(driver, columnNames);
		
		RC_Reporting.downloadAndVerifyFileDownloaded(driver, "Business and Personal Use_LS008742", "Excel button - Download validation", true);
		
		RC_Reporting.reportParametersNavigate(driver);
		RC_Reporting.validateCustomerNumberParamData(driver, "LS008742");
		
		RC_Reporting.validateReportParameterData(driver, "Reporting Year", sRYear);
		
		RC_Global.logout(driver, false);	
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);
	}
}
