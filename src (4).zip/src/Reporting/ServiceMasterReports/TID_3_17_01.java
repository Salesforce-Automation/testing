package Reporting.ServiceMasterReports;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import MF.FrameworkCode.BFrameworkQueryObjects;
import tools.TotalView.RC_Global;
import tools.TotalView.RC_Reporting;

public class TID_3_17_01 {
	
	public static void ServiceMasterReports_VerifyOpenRenewalRegistrationPrerequisiteSearchFunctionalityAndUIExceptions(WebDriver driver,BFrameworkQueryObjects queryObjects) throws Exception{

		RC_Global.login(driver);
		
		String columnNames="Customer Name;Customer Number;Unit Number;CVN;VIN;Year;Make;Model;Driver/Pool Name;Plate Number;Plate State;Renewal Date;Rejection by DMV Date;Rejection Reason;Inspections Required;Fleet Number;Fleet Name;Account Number;Account Name;Sub-account Number;Sub-account Name";
		
		RC_Reporting.navigateTo(driver, "Reporting", "ServiceMaster Reports", "Open Renewal Registration Prerequisite Report");
		RC_Global.waitElementVisible(driver, 30, "//div[label[text()='Customer Number:']]//input", "Customer Number Search Filter", true, false);

		RC_Global.createNode(driver, "Verify Search Filters");
		RC_Global.verifyScreenComponents(driver, "lable", "Customer Number", false);

		RC_Global.createNode(driver, "Validate buttons");
		RC_Global.verifyScreenComponents(driver, "button", "Generate Report", false);
		RC_Global.verifyScreenComponents(driver, "button", "Excel", false);
		RC_Global.verifyScreenComponents(driver, "button", "CSV", false);
		RC_Global.verifyScreenComponents(driver, "button", "PDF", false);
		RC_Global.verifyScreenComponents(driver, "button", "XML", false);
		RC_Global.verifyScreenComponents(driver, "button", "Edit Columns", false);
		
		Thread.sleep(2000);
		
		String customerNumber = driver.findElement(By.xpath("//div[label[text()=' Customer # ']]/input")).getAttribute("value");
		if(customerNumber.equalsIgnoreCase("LS007656"))
			queryObjects.logStatus(driver, Status.PASS, "Verify Customer Number is LS007656", "Customer Number is LS007656", null);
		else
			queryObjects.logStatus(driver, Status.FAIL, "Verify Customer Number is LS007656", "Customer Number is not LS007656", null);
		
  		RC_Reporting.generateReportValidateResults(driver);
  		RC_Reporting.validateReportColumnNames(driver, columnNames);
  		
  		Thread.sleep(3000);
		RC_Reporting.downloadAndVerifyFileDownloaded(driver, "Open Renewal Registration Prerequisite Report_LS007656", "Excel button - Download validation", true);
		

		RC_Reporting.panelAction(driver, "close", "Open Renewal Registration Prerequisite Report", true, true);
		RC_Global.logout(driver, true);
		queryObjects.logStatus(driver, Status.PASS, "Test Case execution", "Complete", null);

	}

}
